# 🚂 Locomotoras de Vapor y Diésel — mod para NeoForge 1.21.1

Locomotoras de trenes reales al estilo Traincraft, de **hasta 3 bloques de alto**, que andan sobre los rieles normales de Minecraft. Tienen marchas (incluida marcha atrás), silbato o bocina, humo, ruedas y bielas animadas, y empujan las vagonetas que tengan adelante. Cada una tiene **su cabina por dentro, con los controles que se mueven** (la palanca sigue a la marcha y la aguja del velocímetro a la velocidad) y **lugar para 2 a 4 jugadores**: el del puesto del maquinista maneja y los demás van de acompañantes. Además hay **14 vagones de carga con cofre** y **11 coches de pasajeros con asientos para varios jugadores**, que se enganchan a las locomotoras y van tirados (o empujados) por ellas, y **vías propias**: rectas, curvas redondas, de dos caminos y en subida, de hasta 30 bloques, que se ponen enteras de un clic. En el mundo aparecen **vías infinitas** con **estaciones de pueblo**, **estaciones abandonadas** con un tren abandonado (que se encuentran con `/locate structure locomotora:estacion_abandonada`) y **trenes que pasan solos** cada 5 minutos, cada uno con sus propios vagones de carga o coches de pasajeros (o solo, si no tiene), una vez para cada lado. De noche **las luces brillan** (faros, faroles, luces de cola, la boca del hogar, las lucecitas de los pupitres y los salones de los coches) y, ojo: **un tren en marcha atropella** a quien tenga delante. Y cuidado con el **tren artillero**: un tren blindado con torretas que a veces pasa por la línea y **te dispara si te ve**. Tiene 100 de vida; si lo derrotas, **es tuyo y te defiende**.

## Las locomotoras

Son 57 trenes reales: 16 de vapor, 17 diésel, 11 diésel abandonadas, 7 pequeñas antiguas de vapor y 6 diésel industriales y de minería.

![Las de vapor](docs/vapor.jpg)
![Vapor, segunda tanda](docs/vapor2.jpg)
![Las diésel](docs/diesel.jpg)
![Diésel, segunda tanda](docs/diesel2.jpg)
![Las abandonadas](docs/abandonadas.jpg)
![Las pequeñas antiguas](docs/antiguas.jpg)
![Las industriales y de minería](docs/industriales.jpg)

| Locomotora | Qué es | Velocidad máxima | Sonido |
|---|---|---|---|
| **Flying Scotsman** | Vapor británica de 1923 (Pacific 4-6-2), verde manzana, **con su ténder** | 16 bloques/s | silbato de campana |
| **A4 Mallard** | Vapor británica de 1938 con carenado aerodinámico azul: la más rápida del mundo (203 km/h), **con su ténder** | 16 bloques/s | silbato de acordes |
| **Big Boy** | Vapor norteamericana de 1941, articulada 4-8-8-4: **la unidad delantera gira en las curvas**, con ténder "ciempiés" | 14 bloques/s | silbato grave |
| **GS-4 Daylight** | Vapor norteamericana de 1941 (4-8-4) con la librea roja, naranja y negra del Daylight, **con su ténder** | 16 bloques/s | silbato grave |
| **BR 01** | Vapor alemana de 1926 (Pacific 4-6-2), negra con ruedas rojas y deflectores de humo, **con su ténder** | 16 bloques/s | silbato agudo |
| **Pannier** | Locomotora tanque británica de 1929 (0-6-0), con los tanques de agua a los costados de la caldera | 12 bloques/s, arranque rápido | silbato agudo |
| **Rocket** | La pionera británica de 1829 (0-2-2): caldera amarilla, chimenea blanca altísima y cilindros inclinados, **con su ténder** | 12 bloques/s | silbato agudo |
| **Jupiter** | 4-4-0 del Lejano Oeste de 1868: chimenea de globo, faro de cajón y quitapiedras, **con su ténder de leña** | 12 bloques/s | silbato agudo |
| **Hiawatha** | Aerodinámica norteamericana de 1935 (4-4-2) en gris, naranja y granate, con ruedas motrices de 2,13 m, **con su ténder** | 16 bloques/s | silbato |
| **PRR T1** | Duplex norteamericana de 1942 (4-4-4-4) con nariz de tiburón y dos juegos de bielas, **con su ténder** | 16 bloques/s | silbato grave |
| **N&W clase J** | Aerodinámica norteamericana de 1950 (4-8-4) con nariz de bala y franja roja, **con su ténder** | 16 bloques/s | silbato grave |
| **Merchant Navy** | Pacific británica de 1941 con carcasa lisa, verde, y ruedas de disco agujereadas, **con su ténder** | 16 bloques/s | silbato |
| **9F Evening Star** | La última vapor de British Railways (1960, 2-10-0), con diez ruedas motrices, **con su ténder** | 14 bloques/s | silbato |
| **D51** | La vapor japonesa más famosa (1936, 2-8-2), negra, **con su ténder** | 14 bloques/s | silbato agudo |
| **P36** | Soviética de 1950 (4-8-4), verde con franja roja y ruedas rojas, **con su ténder** | 16 bloques/s | silbato grave |
| **Garratt** | Articulada africana de 1955 (4-8-2+2-8-4): **la caldera va colgada entre dos unidades motrices** | 12 bloques/s | silbato grave |
| **EMD F7** | Diésel norteamericana de 1949: nariz "bulldog", verde con franja amarilla | 16 bloques/s | bocina americana |
| **V 200** | Diésel-hidráulica alemana de 1953: roja, con la "V" cromada y cabina en las dos puntas | 16 bloques/s, arranque rápido | bocina aguda |
| **InterCity 125** | Coche motor diésel británico de 1976 con nariz en cuña: el tren diésel más rápido del mundo (238 km/h) | 16 bloques/s, arranque rápido | bocina de dos tonos |
| **Deltic** | Diésel británica de 1961 con dos motores, verde en dos tonos y cabina en las dos puntas | 16 bloques/s | bocina británica |
| **EMD SD40-2** | Diésel de carga norteamericana de 1972, azul, con bogies de 3 ejes | 14 bloques/s | bocina americana |
| **GE ES44AC** | Diésel de carga norteamericana de 2003, cabina ancha y radiador grande atrás | 14 bloques/s | bocina grave |
| **DD51** | Diésel-hidráulica japonesa de 1962, roja, con la cabina en el medio entre dos capós | 14 bloques/s | bocina aguda |
| **Class 08** | Diésel de maniobras británica de 1952 (0-6-0 con bielas), azul con rayas de avispa | 10 bloques/s, arranque muy rápido | bocina |
| **Pioneer Zephyr** | Tren diésel aerodinámico norteamericano de 1934, de acero inoxidable acanalado: **dos coches articulados** | 16 bloques/s | bocina |
| **Fliegender Hamburger** | El primer tren diésel rápido del mundo (Alemania, 1933), violeta y crema: **dos coches articulados** | 16 bloques/s | bocina aguda |
| **V 160 «Lollo»** | Diésel-hidráulica alemana de 1960, roja, con las puntas muy redondeadas | 16 bloques/s | bocina aguda |
| **CC 72000** | Diésel francesa de 1967, azul, con los «bigotes» de acero inoxidable | 16 bloques/s | bocina |
| **ChME3** | Diésel de maniobras de 1963, la más fabricada de la historia, roja con franjas crema | 10 bloques/s, arranque muy rápido | bocina aguda |
| **DF4 «Dongfeng»** | Diésel de carga china de 1969, verde con franja amarilla y cabina en las dos puntas | 14 bloques/s | bocina |
| **WDM-2** | Diésel de la India de 1962, de diseño ALCO, roja y crema | 14 bloques/s | bocina |
| **P42 «Genesis»** | Diésel de pasajeros norteamericana de 1996, plateada con banda azul | 16 bloques/s, arranque rápido | bocina grave |
| **DF200 «Red Bear»** | Diésel de carga japonesa de 1992 con tres bogies, roja con el frente negro | 14 bloques/s | bocina |
| **EMD GP9 abandonada** | Diésel de carga norteamericana de 1954, azul desteñida, oxidada y con pasto | 14 bloques/s | bocina |
| **EMD E8 abandonada** | Diésel de pasajeros norteamericana de 1949 con la nariz inclinada, granate y oxidada | 16 bloques/s | bocina |
| **ALCO RS-3 abandonada** | Diésel norteamericana de 1950, naranja casi toda oxidada, con una baranda caída | 12 bloques/s | bocina |
| **Budd RDC abandonado** | Coche motor diésel norteamericano de 1949, de acero inoxidable mugriento | 14 bloques/s | bocina aguda |
| **Class 37 abandonada** | Diésel británica de 1960, azul y amarilla, con las narices oxidadas | 14 bloques/s | bocina |
| **Class 20 abandonada** | Diésel británica de 1957 con una sola cabina, gris y oxidada | 12 bloques/s | bocina |
| **M62 abandonada** | Diésel soviética de 1965, verde con franja amarilla, oxidada | 14 bloques/s | bocina grave |
| **TEP60 abandonada** | Diésel de pasajeros soviética de 1960, roja y crema desteñida | 16 bloques/s | bocina |
| **T478.3 abandonada** | Diésel checoslovaca de 1968 con los parabrisas de «anteojos», roja y oxidada | 12 bloques/s | bocina aguda |
| **KiHa 40 abandonado** | Coche motor diésel japonés de 1977, rojo y crema desteñido | 12 bloques/s | bocina aguda |
| **Sharknose abandonada** | Diésel norteamericana de 1950 con la nariz de tiburón, negra y oxidada | 14 bloques/s | bocina |
| **Locomotion No. 1** | La del primer ferrocarril público a vapor (Inglaterra, 1825): cilindros verticales con bielas larguísimas que bajan a las ruedas, **con su ténder de tonel** | 8 bloques/s | silbato |
| **Best Friend of Charleston** | La primera hecha en EE. UU. (1830): caldera parada en forma de botella y el maquinista adelante, **con su ténder de leña** | 10 bloques/s | silbato agudo |
| **John Bull** | Inglesa de 1831 que se volvió americana: quitapiedras, faro de cajón, campana y caldera forrada de madera, **con su ténder** | 10 bloques/s | silbato |
| **Adler** | La primera de Alemania (1835, 2-2-2), verde, con una sola rueda motriz grande, **con su ténder** | 12 bloques/s | silbato agudo |
| **Coppernob** | 0-4-0 inglesa de 1846, roja, con el hogar redondo forrado de cobre, **con su ténder** | 10 bloques/s | silbato |
| **La Porteña** | La primera que corrió en la Argentina (1857): locomotora tanque verde con ruedas rojas | 10 bloques/s | silbato agudo |
| **Shay** | Engranada de aserradero de la década de 1880: cilindros verticales que mueven un árbol con cardanes y coronas dentadas | 8 bloques/s, mucha fuerza | silbato grave |
| **Motor Rail Simplex** | Diésel inglesa de minas y canteras (década de 1930), chiquita y roja, con el radiador de panal y el maquinista sentado de costado | 8 bloques/s, arranque rápido | bocina aguda |
| **Deutz OMZ 117** | Diésel alemana de vía angosta (década de 1930), verde, con bielas y un techito sobre cuatro postes | 8 bloques/s, arranque rápido | bocina aguda |
| **GE de 44 toneladas** | Diésel de maniobras norteamericana de 1940, azul, con la cabina al medio entre dos capós y dos bogies | 12 bloques/s | bocina |
| **Plymouth** | Diésel de canteras y aserraderos (década de 1940), gris acero con las puntas a rayas de cebra y bielas | 8 bloques/s, arranque rápido | bocina aguda |
| **TGM23** | Diésel-hidráulica soviética de maniobras (1960-1990), granate con franja crema, tres ejes con bielas y eje ciego | 10 bloques/s | bocina |
| **Locomotora de túnel** | Diésel moderna de las obras de túneles y minas, naranja, muy baja, con una cabina en cada punta, faros LED y balizas | 8 bloques/s, arranque muy rápido | bocina aguda |

Más imágenes de cada una: [Flying Scotsman](docs/reales_1.jpg) · [EMD F7](docs/reales_2.jpg) · [V 200](docs/reales_3.jpg) ·
[A4 Mallard](docs/tren_1.jpg) · [Big Boy](docs/tren_2.jpg) · [GS-4](docs/tren_3.jpg) · [BR 01](docs/tren_4.jpg) ·
[Pannier](docs/tren_5.jpg) · [InterCity 125](docs/tren_6.jpg) · [Deltic](docs/tren_7.jpg) · [SD40-2](docs/tren_8.jpg) ·
[ES44AC](docs/tren_9.jpg) · [DD51](docs/tren_10.jpg) · [Class 08](docs/tren_11.jpg) ·
[Rocket](docs/vapor_rocket.jpg) · [Jupiter](docs/vapor_jupiter.jpg) · [Hiawatha](docs/vapor_hiawatha.jpg) ·
[PRR T1](docs/vapor_t1.jpg) · [N&W J](docs/vapor_nwj.jpg) · [Merchant Navy](docs/vapor_merchant.jpg) ·
[9F](docs/vapor_br9f.jpg) · [D51](docs/vapor_d51.jpg) · [P36](docs/vapor_p36.jpg) · [Garratt](docs/vapor_garratt.jpg) ·
[Pioneer Zephyr](docs/diesel_zephyr.jpg) · [Fliegender Hamburger](docs/diesel_hamburger.jpg) · [V 160](docs/diesel_v160.jpg) ·
[CC 72000](docs/diesel_cc72000.jpg) · [ChME3](docs/diesel_chme3.jpg) · [DF4](docs/diesel_df4.jpg) · [WDM-2](docs/diesel_wdm2.jpg) ·
[P42 Genesis](docs/diesel_p42.jpg) · [DF200](docs/diesel_df200.jpg) ·
Abandonadas: [GP9](docs/abandonada_gp9.jpg) · [E8](docs/abandonada_e8.jpg) · [RS-3](docs/abandonada_rs3.jpg) ·
[RDC](docs/abandonada_rdc.jpg) · [Class 37](docs/abandonada_class37.jpg) · [Class 20](docs/abandonada_class20.jpg) ·
[M62](docs/abandonada_m62.jpg) · [TEP60](docs/abandonada_tep60.jpg) · [T478.3](docs/abandonada_t478.jpg) ·
[KiHa 40](docs/abandonada_kiha40.jpg) · [Sharknose](docs/abandonada_sharknose.jpg) ·
Antiguas: [Locomotion No. 1](docs/antigua_locomotion.jpg) · [Best Friend of Charleston](docs/antigua_best_friend.jpg) ·
[John Bull](docs/antigua_john_bull.jpg) · [Adler](docs/antigua_adler.jpg) · [Coppernob](docs/antigua_coppernob.jpg) ·
[La Porteña](docs/antigua_portena.jpg) · [Shay](docs/antigua_shay.jpg) ·
Industriales: [Simplex](docs/industrial_simplex.jpg) · [Deutz](docs/industrial_deutz.jpg) · [GE 44 t](docs/industrial_ge44.jpg) ·
[Plymouth](docs/industrial_plymouth.jpg) · [TGM23](docs/industrial_tgm23.jpg) · [De túnel](docs/industrial_tunel.jpg)

- Las **industriales y de minería** son locomotoras de trabajo: chicas, lentas y con mucha fuerza para mover vagones en minas, canteras, fábricas, puertos y túneles.
- Las **pequeñas antiguas** son las de los comienzos del ferrocarril: chiquitas, lentas y llenas de mecanismos a la vista. La Locomotion tiene los cilindros parados arriba de la caldera, la Best Friend lleva la caldera de botella y la Shay es engranada: sus cilindros verticales hacen girar un árbol a lo largo de la máquina que mueve las ruedas con coronas dentadas.
- Las **abandonadas** andan igual que las demás diésel, pero se ven viejas: óxido con chorreaduras, pintura desteñida y descascarada, vidrios rotos, faros quebrados, musgo, enredaderas y pasto creciendo.
- Están hechas en la escala de Traincraft (16 píxeles por bloque) y con **superficies curvas de verdad**: narices, calderas, carenados, domos y techos lisos, sin escalones. Los faros son redondos. No llevan logos de empresas reales.
- Miden de 2,5 a 24 bloques de largo y **siguen la vía con sus bogies**: en las curvas y en las subidas cada cuerpo se apoya en los rieles como un tren de verdad. Los ténderes van articulados detrás de la locomotora, la unidad motriz delantera de la Big Boy gira debajo de la caldera, como en la real, en la Garratt la caldera va colgada entre sus dos unidades motrices, y el Pioneer Zephyr y el Fliegender Hamburger son dos coches articulados que comparten el bogie del medio.
- Las curvas de Minecraft giran 90° en un solo bloque, así que en una curva los trenes largos cortan camino por adentro. Se lucen en rectas largas.
- Las de vapor usan carbón; las diésel, bidones de diésel. Las bielas de las de vapor se mueven con la cinemática real: biela motriz, cruceta y pistón (la Big Boy y la T1 tienen dos juegos; la Rocket y la Best Friend, cilindros inclinados; la Locomotion, cilindros verticales con contramanivelas; la Shay, cigüeñal y árboles que giran a lo largo).

## La cabina

![Las cabinas por dentro](docs/cabinas.jpg)

- **Todas las locomotoras tienen la cabina armada por dentro** (menos las abandonadas): desde el asiento se ve el paisaje por las ventanas y el parabrisas de verdad, y desde afuera se ve a los que van adentro.
- **Los controles se mueven**: la **palanca** (el cambio de marcha en las de vapor, el acelerador en las diésel) se corre con cada marcha que pones con **W** / **S**, y la **aguja del velocímetro** sube con la velocidad.
- En las de **vapor**: el frente de la caldera con los relojes, el nivel de agua, el regulador, las válvulas, la **puerta del hogar encendida** y la palanca de cambio de marcha saliendo del piso. En las **diésel**: el **pupitre** con el tablero de relojes, las lucecitas de colores (brillan de noche), el acelerador y el freno.
- Las **pequeñas antiguas** (1825-1850) no tenían cabina: se va en el estribo, con el manómetro y los controles en el fondo de la caldera. La Best Friend se maneja desde adelante, en su baranda, y la Simplex de costado, en su cajón.
- En las **aerodinámicas** de vapor (Merchant Navy, PRR T1, Hiawatha) la carcasa tapa el frente: el maquinista mira por las ventanas de los costados, como en las de verdad.

**Cuántos entran:** el primero que sube va al **puesto del maquinista** y maneja; los demás se sientan en los otros asientos, **de 2 a 4 según el tamaño** (la Big Boy lleva 4; las chicas, 2). Si el maquinista se baja, el próximo que sube toma el puesto. Un golpe de alguien que va arriba no le hace nada a la locomotora.

## Los vagones

Son 14 vagones de carga, cada uno pensado para una de las locomotoras, pero se pueden enganchar a **cualquier locomotora** y entre sí, todos los que quieras. Son ítems aparte de las locomotoras y tienen su propia pestaña en el modo creativo.

![Los vagones](docs/vagones.jpg)
![Los vagones de las líneas](docs/vagones_linea.jpg)
![Un tren enganchado en las curvas y en la subida](docs/tren_enganchado.jpg)

| Vagón | Qué es | Va con |
|---|---|---|
| **Vagoneta volcadora en V** | La de las minas y canteras de vía angosta, con piedra y mineral | Simplex |
| **Vagón de ladrillera** | Plataforma de madera con dos pilas de ladrillos | Deutz |
| **Vagoneta de carbón** | Cajón de acero de las minas de carbón, lleno hasta el tope | Locomotora de túnel |
| **Tolva de mineral** | Tolva de mineral de hierro con las puntas inclinadas, sobre dos bogies | GE de 44 toneladas |
| **Vagón de volteo lateral** | Volquete de cantera con la caja sobre balancines y los pistones | Plymouth |
| **Vagón cisterna** | Tanque industrial con domo, pasarela, barandas y escaleras, sobre dos bogies | TGM23 |
| **Portadovelas de túnel** | Lleva las dovelas curvas de hormigón de las tuneladoras | Locomotora de túnel |
| **Vagón cerrado G10** | Alemán, de tablas con el armazón de acero y la casilla del guardafrenos | BR 01 |
| **Furgón refrigerado** | Furgón de fruta fresca con cuatro escotillas de hielo en el techo | EMD F7 |
| **Vagón de troncos** | Cinco troncos encadenados entre estacas, de un aserradero del monte | Shay |
| **Portacontenedores** | Plataforma moderna con tres contenedores de 20 pies | GE ES44AC |
| **Cisterna remachada** | Tanque negro remachado de un domo, con pasarelas y escaleras | Big Boy |
| **Cisterna japonesa** | Tanque azul de nafta sin bastidor, más grueso al medio y de lomo recto | DD51 |
| **Cisterna de gas** | Tanque moderno de gas licuado a presión, con cintas reflectivas y rombo de peligro | EMD SD40-2 |

- Cada vagón tiene un **cofre de 27 espacios** (clic derecho para abrirlo). Las tolvas de Minecraft pueden cargarlos y descargarlos desde abajo de la vía, igual que a una vagoneta con cofre.
- **Se enganchan solos**: si pones un vagón en la vía pegado a una locomotora o a otro vagón, queda enganchado. Si pones una locomotora pegada a vagones sueltos, también.
- **Shift + clic derecho** en un vagón lo desengancha, o lo engancha a lo que tenga al lado.
- La locomotora tira de los vagones enganchados y, en marcha atrás, los empuja. Siguen la vía a la distancia justa también en las curvas cerradas, en las vueltas en U y en las subidas.
- Si rompes una locomotora o un vagón, los vagones que tenía enganchados quedan sueltos. Al romper un vagón se cae lo que llevaba en el cofre.
- Los vagones largos (la tolva, la cisterna y los de las líneas) **siguen la vía con sus dos bogies** y se les puede hacer clic en cualquier parte.

## Los coches de pasajeros

Son 11 coches de pasajeros, cada uno pensado para una de las locomotoras (y de su época), pero se enganchan a **cualquier locomotora**, entre sí y con los vagones de carga. Tienen su propia pestaña en el modo creativo.

![Los coches de pasajeros](docs/coches.jpg)

| Coche | Qué es | Asientos | Va con |
|---|---|---|---|
| **Coche diligencia** | Inglaterra, 1830: tres cajas de diligencia sobre cuatro ruedas, equipaje atado en el techo y el asiento del guarda | 6 | Rocket |
| **Coche del Oeste** | EE. UU., década de 1870: madera barnizada, plataformas con barandas y escalones, techo de linterna en «pico de pato» | 8 | Jupiter |
| **Coche de teca** | Inglaterra, década de 1930: teca barnizada, una puerta por compartimiento con su «3» dorado, techo blanco | 8 | Flying Scotsman |
| **Coche cama de lujo** | Europa, 1929: azul oscuro con filetes dorados, cortinas, camas tendidas y bogies de tres ejes | 8 | BR 01 |
| **Coche «Daylight»** | EE. UU., 1937: rojo y naranja con filetes blancos, faldones y butacas reclinables | 8 | GS-4 |
| **Coche mirador «cola de castor»** | EE. UU., 1938: la cola baja en pendiente llena de ventanas con aletas, con sillones mirando para atrás | 8 | Hiawatha (al final del tren) |
| **Coche domo panorámico** | EE. UU., 1949: acero inoxidable acanalado y un domo de vidrio en el techo (con asientos adentro) | 8 | F7 |
| **Coche dormitorio indio** | India, década de 1970: azul con filetes crema, ventanas con barrotes y literas de tres pisos | 8 | WDM-2 |
| **Coche cama «Tren Azul»** | Japón, década de 1970: azul con filetes blancos, literas y aire acondicionado en el techo | 8 | DD51 |
| **Coche Mk3** | Inglaterra, 1976: el coche del InterCity 125, azul y gris perla, con mesas en cada fila | 8 | HST |
| **Coche de dos pisos** | EE. UU., 1979: acero inoxidable con franjas roja, blanca y azul, dos pisos de asientos | 8 | P42 |

- Las **ventanas son de verdad** (huecos) y adentro está armado el salón: asientos, mesas, camas o literas. Desde afuera se ve a los que van sentados, y ellos ven el paisaje.
- **Clic derecho** en cualquier parte del coche: te sientas en el asiento libre más cercano, frente a una ventana. Se pueden sentar **varios jugadores a la vez** (6 en la diligencia, 8 en los demás). **Shift** para levantarte: bajas por el costado de tu asiento.
- **Animales y aldeanos**: si los traes atados con una **correa**, clic derecho en el coche y suben ellos (la correa te vuelve). Con una correa en la mano, clic derecho los hace bajar.
- Se enganchan igual que los vagones (solos al ponerlos, o con **Shift + clic derecho**). Un golpe de alguien que va sentado no le hace nada al coche.
- Los **trenes que pasan solos** muchas veces son de pasajeros: la locomotora con 2 a 4 de sus propios coches. **Puedes subirte a uno** y viajar: mientras vaya gente sentada el tren sigue viaje por la línea.
- **De noche el salón está iluminado**: desde afuera se ven las ventanas encendidas (el coche del Oeste, además, tiene sus faroles colgados del techo).

## De noche, y cuidado con los trenes

![Trenes de noche, con las luces encendidas](docs/noche.jpg)

- **Las luces brillan en la oscuridad**: los faros y faroles de adelante, las luces rojas de cola y de las puntas, las balizas de las industriales, la boca del hogar de las de vapor y los salones de los coches de pasajeros. Las abandonadas no: sus faros están rotos.
- **Un tren en marcha atropella** a quien tenga delante: jugadores, animales, aldeanos y monstruos. Pasado el paso de hombre **mata**, y no te salva la armadura ni una poción (un **tótem** sí). Muy despacio solo empuja y lastima un poco. Los que van sentados en el tren no corren peligro, y en **creativo** no pasa nada.
- Los trenes que pasan solos **tocan bocina o silbato** si hay alguien parado en la vía delante... pero **no frenan**.

## El tren artillero

![El tren artillero](docs/artillero_tren.jpg)
![El tren artillero de cerca](docs/artillero_piezas.jpg)

Es un tren blindado con camuflaje de tres colores (sin insignias, solo su número pintado), y tiene tres piezas:

- **Locomotora blindada:** lleva una torreta con cañón, y el maquinista va asomado por la escotilla.
- **Vagón cañón:** tiene una torreta grande con un cañón largo.
- **Vagón antiaéreo:** lleva dos caños que giran, suben y tiran ráfagas.

Las torretas **giran hacia el blanco** y los cañones suben y bajan para apuntar. Los obuses dejan una estela de humo y **explotan sin romper bloques**.

- **Aparece solo**: uno de cada seis trenes que pasan solos es el tren artillero, con 2 o 3 de sus vagones. Nunca aparece en pacífico, y se apaga con `/gamerule locomotoraTrenArtillero false`.
- **Es hostil y te mata si te ve**:
  - Ve a los jugadores hasta a 48 bloques si no hay paredes en el medio. Agachado te ve de más cerca, e invisible casi nada.
  - Te persigue por la vía, frena a tiro y te dispara con todas sus torretas.
  - Cubrirte detrás de una pared sirve, porque la explosión lastima mucho menos.
  - Pega según la dificultad. En creativo no te ataca.
- **Tiene 100 de vida** y una **barra de jefe**:
  - La vida es una sola para todo el tren: le puedes pegar a la locomotora o a cualquiera de sus vagones, con la espada, con flechas o con TNT.
  - Un solo golpe no le saca más de 25, y el fuego y la lava no le hacen nada.
- **No te puedes subir** ni abrir sus vagones hasta derrotarlo.
- **Si lo derrotas, es tuyo**:
  - Queda quieto, con la vida entera.
  - Los cofres de sus vagones traen **botín**: pólvora, hierro, TNT, oro, esmeraldas y diamantes.
  - El maquinista va en la escotilla de la torreta y se maneja como cualquier diésel. Entran 3.
- **Tu tren artillero te defiende**:
  - Sus torretas disparan solas a todo lo que **te ataque o te tenga de blanco**: monstruos, un jugador que te pegue u otro tren artillero hostil. También defienden a los que van en el tren.
  - Sus obuses no te lastiman a ti, a tus mascotas ni a tu tren.
  - Lo que lo golpea le baja el blindaje, que se ve en el estado del maquinista y se repara solo de a poco.
  - A mano lo rompes para llevártelo, como a cualquier locomotora.
- **No tiene receta: se gana derrotándolo.** En creativo hay dos ítems:
  - **Tren artillero hostil**: pone en el riel uno hostil con sus vagones, para probarlo. Te ataca cuando sales del creativo.
  - **Tren artillero**: pone uno que ya es tuyo. Sus vagones también están en la pestaña de vagones.

## Las vías

Además de los rieles de Minecraft, el mod trae **4 vías propias**, con durmientes de madera y rieles de acero. Cada una se pone **entera de un solo clic** y se configura con un menú: **Shift + clic derecho** con la vía en la mano y se eligen las medidas, **hasta 30 bloques**.

![Las vías nuevas](docs/vias.jpg)
![Trenes en las vías nuevas](docs/trenes_vias.jpg)
![El menú de las vías](docs/menu_vias.jpg)

| Vía | Qué se elige en el menú |
|---|---|
| **Vía recta** | El largo: de 1 a 30 bloques |
| **Vía curva** | El radio (de 2 a 30 bloques) y para qué lado dobla. Es un cuarto de vuelta redondo, no en escalones |
| **Vía de dos caminos** | El largo de la recta, el radio de la curva y para qué lado sale. Tiene un poste con un disco: verde = derecho, amarillo = desviado |
| **Vía en subida** | Cuánto sube y la pendiente: un bloque cada 1, 2, 3 o 4. También se puede poner desde arriba, **para bajar** |

- **Clic derecho en el piso** pone la pieza entera hacia donde miras. Si haces clic en la punta de otra vía, la nueva sigue desde ahí.
- Con la vía en la mano se ve **dónde va a quedar**: un contorno verde en cada bloque (rojo si hay algo en el camino) y la línea de los rieles.
- Donde no hay piso pone **balasto** debajo (debajo de la subida hace el terraplén entero). Si rompes cualquier bloque de la pieza se quita toda y te devuelve la vía con las mismas medidas.
- **Vía de dos caminos**: clic derecho **con la mano vacía** en la aguja (o en el tramo de antes) cambia el camino. También con **redstone** al lado: con señal va por la curva, sin señal derecho. Mientras pasa un tren no se puede cambiar (espera a que pase). Si un tren llega **de talón** desde el otro ramal, la aguja se pone sola para dejarlo pasar.
- Andan las locomotoras, los vagones y también las vagonetas comunes. Los trenes se dibujan **sobre los rieles redondos**: en las curvas, en la aguja y en la rampa pareja de la subida (la locomotora se inclina al subir), y el maquinista va sentado en la cabina aunque la vía doble.
- Las vías comunes de Minecraft se pueden conectar a las puntas de estas, pero no les cambian la forma.

## El mundo: vías infinitas, estaciones y trenes que pasan solos

Al explorar zonas nuevas del mundo aparece una **red de vías** hecha con las vías del mod:

- **Vías infinitas**: cada unos 550 bloques (de norte a sur) hay una línea que cruza el mundo de oeste a este sin fin. Van de estación en estación y doblan con curvas redondas cuando tienen que correrse. Siguen el terreno con **subidas y bajadas**, cortan las lomas, van sobre **terraplenes** en los pozos, cruzan ríos, lagos y el mar por **puentes de piedra con pilares**, y atraviesan las montañas por **túneles** revestidos e iluminados con antorchas.
- **Estación de pueblo**: al lado de cada aldea (a unos 100 bloques del centro, para no pisar las casas) hay una estación con andén, techito con faroles y una campana, bancos, y la casa de la estación con boletería, sala de espera y un **cofre**. Los materiales cambian según la aldea: ladrillo y roble en la llanura, arenisca en el desierto, acacia en la sabana, abeto en la nieve y la taiga. De la puerta de atrás sale un **camino** hasta la aldea.
- **Estación abandonada**: grande (más de 100 bloques de largo), con tres vías, andenes bajo un **galpón de arcos** con el techo de vidrio medio caído, el edificio de dos pisos con su **torre del reloj**, el tanque de agua, la cabina de señales y la carbonera. Todo con musgo, enredaderas, telarañas, escombros, pasto y árboles creciendo entre las vías. En la vía muerta quedó un **tren abandonado**: una de las 11 diésel abandonadas con 2 a 4 vagones (con carga adentro), enganchados y listos: si le cargas diésel, te lo puedes llevar por el desvío. Hay cofres con cosas viejas del ferrocarril. Para encontrar la más cercana: `/locate structure locomotora:estacion_abandonada` (o `#locomotora:abandoned_station`).
- **Trenes que pasan solos**: cada 5 minutos, si estás cerca de una línea, aparece un tren cualquiera a unos 80 bloques: una locomotora **con sus propios vagones** (los que se hicieron para ella: sus vagones de carga o sus coches de pasajeros), o **sola** si no tiene ninguno. Viene por la vía a toda marcha, toca bocina o silbato al acercarse (y cada vez que hay alguien parado en la vía) y sigue de largo; cuando se aleja desaparece. Pasan **una vez para cada lado**: si uno vino del este, el próximo viene del oeste. Si te subes a la locomotora, deja de andar solo y queda para ti; si te sientas en un coche, viajas con él. (Tus trenes los armas como quieras: a cualquier locomotora se le engancha cualquier vagón.)

Se maneja con reglas del juego:

| Regla | Qué hace | De fábrica |
|---|---|---|
| `/gamerule locomotoraTrenes false` | Apaga los trenes que pasan solos | `true` |
| `/gamerule locomotoraMinutosTren 10` | Cada cuántos minutos pasa un tren | `5` |
| `/gamerule locomotoraRedDeVias false` | No genera más vías ni estaciones en lo que falta explorar | `true` |
| `/gamerule locomotoraTrenArtillero false` | No manda más trenes artilleros hostiles | `true` |

- Solo aparecen en **zonas nuevas** del mundo (lo ya explorado antes de instalar esta versión queda igual; ahí la vía se corta).
- `/locate structure` encuentra las estaciones abandonadas de las zonas que se generan desde la versión 13 (las que ya estaban generadas antes no las conoce).
- En un mundo que ya existía con el tren cada 10 minutos (lo de antes), al abrirlo con esta versión pasa solo a cada 5.
- Las vías de la red son las mismas del mod: si rompes una, te da la pieza.

## Cómo se usan

| Acción | Qué hace |
|---|---|
| Clic derecho **sobre un riel** con el ítem | Coloca la locomotora mirando hacia donde miras |
| Clic derecho con **carbón / carbón vegetal** (vapor) | Carga 1 pieza en la caldera (un **bloque de carbón** carga 9) |
| Clic derecho con un **bidón de diésel** (diésel) | Carga el tanque (un bidón rinde como 6 carbones) |
| Clic derecho con la **mano vacía** | Te subes a la cabina: si el puesto del maquinista está libre vas ahí y manejas; si no, de acompañante en el asiento libre más cercano |
| **Shift + clic derecho** | Arranca (alejándose de ti) o frena, sin subirte |
| Montado: **W** / **S** | Sube / baja la marcha: atrás ◀, freno ■, 1, 2, 3 |
| Montado: **A** o **D** | Suena el silbato o la bocina 🎵 |
| Montado: **Shift** | Te bajas por el costado de tu asiento |
| Clic derecho **sobre un riel** con un vagón | Lo coloca y se engancha solo a la locomotora o al vagón que tenga pegado |
| Clic derecho en un **vagón** | Abre su carga (27 espacios) |
| Clic derecho en un **coche de pasajeros** | Te sientas frente a una ventana (o suben los animales que traes con correa) |
| Sentado en un coche: **Shift** | Te levantas y bajas por el costado |
| **Shift + clic derecho** en un **vagón** | Lo desengancha, o lo engancha a lo que tenga al lado |
| Clic derecho **en el piso** con una vía | Pone la pieza entera mirando hacia donde miras |
| **Shift + clic derecho** con una vía | Abre el menú para elegir las medidas (hasta 30 bloques) |
| Clic derecho con la **mano vacía** en la aguja | Cambia el camino de la vía de dos caminos |

- **Van al doble de rápido que una vagoneta**: hasta 16 bloques por segundo las más rápidas. En las esquinas de los rieles (un bloque que dobla 90°) aflojan solas el paso para no salirse de la vía, y al salir siguen a la misma velocidad.
- Gastan más combustible cuanto más rápido van. Con una pieza de carbón andan 4 minutos en marcha 1.
- La caldera o el tanque guarda hasta 40 carbones (casi 7 bidones). Si rompes la locomotora te devuelve lo que quedaba.
- Si choca contra algo y queda trabada, se frena sola.
- Un riel propulsor **apagado** la detiene (sirve como estación).
- Empuja a las vagonetas que tenga delante (o detrás, en marcha atrás) sin que se metan dentro del modelo.
- Necesita **2 bloques libres de alto** sobre la vía para pasar (aunque se vea de 3, el techo de los túneles puede atravesarla).
- Miden de 2,5 a 24 bloques de largo y siguen la vía con sus bogies.

## Recetas

**Bidón de diésel** (sin forma): 1 lingote de hierro + 2 carbones (o carbón vegetal) + 1 alga seca.

**Locomotoras** — con un riel arriba:

```
             [Riel]
[Lingote de hierro] [Horno, Alto horno, Pistón o Pistón pegajoso] [Lingote de hierro]
   [ X ]          [Vagoneta]          [ X ]
```

| Locomotora | Al medio | X (tinte) |
|---|---|---|
| Flying Scotsman | Horno | verde lima |
| A4 Mallard | Horno | azul |
| Big Boy | Horno | negro |
| GS-4 Daylight | Horno | naranja |
| BR 01 | Horno | rojo |
| Pannier | Horno | verde |
| EMD F7 | Pistón | verde |
| V 200 | Pistón | rojo |
| InterCity 125 | Pistón | amarillo |
| Deltic | Pistón | verde lima |
| EMD SD40-2 | Pistón | azul |
| GE ES44AC | Pistón | gris claro |
| DD51 | Pistón | naranja |
| Class 08 | Pistón | cian |
| Rocket | Alto horno | amarillo |
| Jupiter | Alto horno | azul |
| Hiawatha | Alto horno | naranja |
| PRR T1 | Alto horno | verde |
| N&W clase J | Alto horno | negro |
| Merchant Navy | Alto horno | verde lima |
| 9F Evening Star | Alto horno | gris |
| D51 | Alto horno | blanco |
| P36 | Alto horno | rojo |
| Garratt | Alto horno | violeta |
| Pioneer Zephyr | Pistón | blanco |
| Fliegender Hamburger | Pistón | violeta |
| V 160 Lollo | Pistón | rosa |
| CC 72000 | Pistón | azul claro |
| ChME3 | Pistón | marrón |
| DF4 | Pistón pegajoso | verde |
| WDM-2 | Pistón | magenta |
| P42 Genesis | Pistón | gris |
| DF200 | Pistón | negro |
| EMD GP9 (abandonada) | Pistón | azul |
| EMD E8 (abandonada) | Pistón | marrón |
| ALCO RS-3 (abandonada) | Pistón | naranja |
| Budd RDC (abandonada) | Pistón | gris claro |
| Class 37 (abandonada) | Pistón | cian |
| Class 20 (abandonada) | Pistón | gris |
| M62 (abandonada) | Pistón | verde |
| TEP60 (abandonada) | Pistón | blanco |
| T478.3 (abandonada) | Pistón | rojo |
| KiHa 40 (abandonada) | Pistón | rosa |
| Sharknose (abandonada) | Pistón | negro |
| Locomotion No. 1 (antigua) | Horno | negro |
| Best Friend of Charleston (antigua) | Horno | rojo |
| John Bull (antigua) | Horno | marrón |
| Adler (antigua) | Horno | verde |
| Coppernob (antigua) | Horno | naranja |
| La Porteña (antigua) | Horno | azul claro |
| Shay (antigua) | Horno | gris |
| Motor Rail Simplex (industrial) | Pistón | rojo |
| Deutz OMZ 117 (industrial) | Pistón | verde |
| GE de 44 toneladas (industrial) | Pistón | azul |
| Plymouth (industrial) | Pistón | gris |
| TGM23 (industrial) | Pistón | marrón |
| Locomotora de túnel (industrial) | Pistón | naranja |

En las **abandonadas** van **bloques de musgo** en lugar de los lingotes de hierro, y en las **antiguas** y en las **industriales**, **lingotes de cobre**.

**Vagones** — con un cofre al medio:

```
                    [ X ]
[Lingote de hierro] [Cofre]    [Lingote de hierro]
[Lingote de hierro] [Vagoneta] [Lingote de hierro]
```

| Vagón | X |
|---|---|
| Vagoneta volcadora en V | Hierro en bruto |
| Vagón de ladrillera | Ladrillo |
| Vagoneta de carbón | Carbón |
| Tolva de mineral | Tolva |
| Vagón de volteo lateral | Roca (cobblestone) |
| Vagón cisterna | Cubo |
| Portadovelas de túnel | Piedra lisa |
| Vagón cerrado G10 | Tablas de abeto |
| Furgón refrigerado | Hielo |
| Vagón de troncos | Tronco de roble |
| Portacontenedores | Barril |
| Cisterna remachada | Cubo de lava |
| Cisterna japonesa | Lapislázuli |
| Cisterna de gas | Carga de fuego |

**Coches de pasajeros:**

```
               [ X ]
[Panel de vidrio]  [Lana]  [Panel de vidrio]
[Lingote de hierro] [Vagoneta] [Lingote de hierro]
```

| Coche | X |
|---|---|
| Coche diligencia | Tinte amarillo |
| Coche del Oeste | Tablas de abeto |
| Coche de teca | Tablas de jungla |
| Coche cama de lujo | Cama (cualquier color) |
| Coche «Daylight» | Tinte naranja |
| Coche mirador «cola de castor» | Catalejo |
| Coche domo panorámico | Vidrio |
| Coche dormitorio indio | Barrotes de hierro |
| Coche cama «Tren Azul» | Tinte azul |
| Coche Mk3 | Tinte gris |
| Coche de dos pisos | Escalera de mano |

**Vías:**

```
[Lingote de hierro]     [ ]       [Lingote de hierro]
[Lingote de hierro]   [Palo]      [Lingote de hierro]
[Lingote de hierro]  [Grava]      [Lingote de hierro]
```

Eso da una **vía recta**. Las demás salen de ella (sin forma):

| Vía | Receta (sin forma) |
|---|---|
| Vía curva | Vía recta + 2 lingotes de hierro |
| Vía de dos caminos | Vía recta + vía curva + palanca |
| Vía en subida | Vía recta + 2 gravas + 1 roca (cobblestone) |
| 8 balastos | 5 gravas y 4 rocas alternadas (grava en las esquinas y el centro) |
| 6 losas de balasto | 3 balastos en fila |

Cada vía sirve para **una pieza de hasta 30 bloques**; al romperla te la devuelve con las mismas medidas.

Todo está también en el modo creativo, en cuatro pestañas propias: **Locomotoras** (con el bidón de diésel y el tren artillero hostil), **Vagones**, **Coches de pasajeros** y **Vías** (con el balasto). El **tren artillero** y sus dos vagones no tienen receta: se ganan derrotándolo.

## Compilar el mod en GitHub (sin instalar nada)

**Una sola vez:**

1. Entra a <https://github.com/new>, ponle un nombre (por ejemplo `locomotora-mod`) y toca **Create repository**.
2. En la página del repositorio vacío toca el enlace **creating a new file**.
3. Como nombre del archivo escribe `.github/workflows/build.yml` (cada `/` crea una carpeta).
4. Pega adentro el contenido del archivo `.github/workflows/build.yml` de este zip y toca **Commit changes**.

**Cada vez que tengas una versión nueva del mod:**

1. En el repositorio toca **Add file → Upload files**.
2. Arrastra el archivo `locomotora-mod.zip` **tal cual, sin descomprimirlo**, y toca **Commit changes**. Si ya había uno, se reemplaza; si quedan varios, se usa el último que subiste.
3. Ve a la pestaña **Actions**. Vas a ver "Compilar mod" corriendo (tarda unos 3–5 minutos la primera vez).
4. Cuando tenga el tilde verde ✅, entra a esa ejecución y abajo, en **Artifacts**, descarga **locomotora-mod**. Es un `.zip` que adentro tiene `locomotora-15.0.0.jar`.

También funciona si subes los archivos ya descomprimidos en vez del `.zip`, o un `.rar`.

Si sale una cruz roja ❌, entra a la ejecución, abre el paso que falló y copia el error para arreglarlo.

## Instalar en Minecraft

1. Instala **NeoForge para 1.21.1** desde <https://neoforged.net>.
2. Copia `locomotora-15.0.0.jar` a la carpeta `mods` de tu `.minecraft` (borra la versión vieja si la tenías).
3. Abre el juego con el perfil de NeoForge.

## Compilar en tu computadora (opcional)

Con Java 21 instalado:

```
./gradlew build          (Linux / Mac)
gradlew.bat build        (Windows)
```

El `.jar` queda en `build/libs/`. Para probarlo directamente: `./gradlew runClient`.

## Estructura del código

```
src/main/java/com/locomotora/
├── LocomotoraMod.java                 clase principal
├── entidad/LocomotoraEntity.java      la locomotora: motor, marchas, combustible, controles, humo, sonidos
├── entidad/TipoLocomotora.java        medidas, velocidades y tipo (vapor o diésel) de cada modelo
├── entidad/AsientosCabina.java        los asientos de la cabina de cada locomotora (generado con los modelos)
├── entidad/VagonEntity.java           el vagón o coche: cofre o asientos, enganche y cómo sigue a su líder
├── entidad/ParteCoche.java            los tramos de la caja de un coche (para hacerle clic en cualquier parte)
├── entidad/TipoVagon.java             medidas de cada vagón y los asientos de cada coche
├── entidad/Enganches.java             enganchar, soltar y buscar vecinos sobre la vía; topes entre vagonetas
├── entidad/Atropello.java             un tren en marcha atropella a quien tenga delante
├── entidad/Via.java                   recorre los rieles: los trenes largos siguen la vía y los vagones miden la distancia
├── item/LocomotoraItem.java           el ítem que coloca la locomotora sobre los rieles
├── item/VagonItem.java                el ítem que coloca el vagón (y lo engancha)
├── via/Pieza.java                     las piezas de vía: qué bloques ocupan, la forma de riel de cada uno y el trazo redondo
├── via/DibujoVia.java                 durmientes, rieles, terraplén y poste del cambio que dibuja cada bloque
├── via/ViaBlock.java (y Via*Block)    los bloques de las vías; ViaDesvioBlock tiene la aguja (clic, redstone, de talón)
├── via/ViaItem.java, ViaMenu.java     el ítem que pone la pieza entera y el menú para elegir las medidas
├── cliente/ViaRenderer.java           dibuja las curvas, los desvíos y las subidas (la recta usa su modelo de bloque)
├── cliente/ViaScreen.java             la pantalla del menú, con la vista previa de la pieza
├── cliente/VistaPrevia.java           el contorno de dónde va a quedar la pieza, con la vía en la mano
├── cliente/LocomotoraRenderer.java    dibuja locomotoras y vagones, anima ruedas, bielas y los controles de la cabina
│                                      y enciende las luces
│                                      (la textura <modelo>_luces.png de cada uno se dibuja sin sombra)
├── cliente/LocomotoraCliente.java     registra los modelos y renderers
├── cliente/modelos/Modelo*.java       los modelos 3D (generados desde el estudio de diseño)
├── mundo/Red.java                     la red: regiones, nodos (aldea, abandonada o de paso), trazado con curvas y perfil
├── mundo/Generador.java               pone en cada chunk la línea (terraplén, corte, puente, túnel), estaciones y caminos
├── mundo/EstacionAldea.java           la estación de pueblo (con la paleta de cada aldea, Paleta.java)
├── mundo/EstacionAbandonada.java      la estación abandonada grande y su tren
├── mundo/Plano.java, Bloque.java      el plano de una estación (bloques, terreno nivelado, taludes, conexiones)
├── generacion/                        lo que conecta la red con Minecraft: la feature, el terreno, las aldeas del juego y
│                                      la estación abandonada como estructura (para /locate)
├── tren/Despachante.java              los trenes que pasan solos cada tantos minutos (cada uno con sus vagones)
├── artillero/ArtilleroEntity.java     la locomotora blindada: vida, hostil o de alguien, a quién le tira, cómo persigue,
│                                      la barra de jefe y qué pasa al derrotarla
├── artillero/VagonArmadoEntity.java   los vagones con torreta: le tiran al blanco de la locomotora y comparten su vida
├── artillero/Torreta.java             medidas de cada torreta, cómo gira y apunta (con la caída del obús) y cada cuánto tira
├── artillero/ObusEntity.java          el obús: vuela, explota (sin romper bloques) y no lastima a su tren ni a su dueño
├── artillero/TrenArtillero.java       de qué tren es cada uno, el botín y cómo se pone un tren artillero hostil
├── artillero/ParteBlindada.java       los tramos del casco (para pegarle o tirarle en cualquier parte)
└── registro/                          bloques, ítems (incluido el bidón), entidades, sonidos, menú, pestañas, feature y reglas
```

Las velocidades, la aceleración y el tono del silbato o bocina de cada locomotora están en `TipoLocomotora.java`; el consumo, la capacidad y lo que rinde un bidón, al principio de `LocomotoraEntity.java`.
