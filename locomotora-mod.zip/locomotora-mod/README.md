# 🚂 Locomotoras de Vapor y Diésel — mod para NeoForge 1.21.1

Locomotoras de trenes reales al estilo Traincraft, de **hasta 3 bloques de alto**, que andan sobre los rieles normales de Minecraft. Tienen marchas (incluida marcha atrás), silbato o bocina, humo, ruedas y bielas animadas, y empujan las vagonetas que tengan adelante.

## Las locomotoras

Son 51 trenes reales: 16 de vapor, 17 diésel, 11 diésel abandonadas y 7 pequeñas antiguas de vapor.

![Las de vapor](docs/vapor.jpg)
![Vapor, segunda tanda](docs/vapor2.jpg)
![Las diésel](docs/diesel.jpg)
![Diésel, segunda tanda](docs/diesel2.jpg)
![Las abandonadas](docs/abandonadas.jpg)
![Las pequeñas antiguas](docs/antiguas.jpg)

| Locomotora | Qué es | Velocidad máxima | Sonido |
|---|---|---|---|
| **Flying Scotsman** | Vapor británica de 1923 (Pacific 4-6-2), verde manzana, **con su ténder** | 8 bloques/s | silbato de campana |
| **A4 Mallard** | Vapor británica de 1938 con carenado aerodinámico azul: la más rápida del mundo (203 km/h), **con su ténder** | 8 bloques/s | silbato de acordes |
| **Big Boy** | Vapor norteamericana de 1941, articulada 4-8-8-4: **la unidad delantera gira en las curvas**, con ténder "ciempiés" | 7 bloques/s | silbato grave |
| **GS-4 Daylight** | Vapor norteamericana de 1941 (4-8-4) con la librea roja, naranja y negra del Daylight, **con su ténder** | 8 bloques/s | silbato grave |
| **BR 01** | Vapor alemana de 1926 (Pacific 4-6-2), negra con ruedas rojas y deflectores de humo, **con su ténder** | 8 bloques/s | silbato agudo |
| **Pannier** | Locomotora tanque británica de 1929 (0-6-0), con los tanques de agua a los costados de la caldera | 6 bloques/s, arranque rápido | silbato agudo |
| **Rocket** | La pionera británica de 1829 (0-2-2): caldera amarilla, chimenea blanca altísima y cilindros inclinados, **con su ténder** | 6 bloques/s | silbato agudo |
| **Jupiter** | 4-4-0 del Lejano Oeste de 1868: chimenea de globo, faro de cajón y quitapiedras, **con su ténder de leña** | 6 bloques/s | silbato agudo |
| **Hiawatha** | Aerodinámica norteamericana de 1935 (4-4-2) en gris, naranja y granate, con ruedas motrices de 2,13 m, **con su ténder** | 8 bloques/s | silbato |
| **PRR T1** | Duplex norteamericana de 1942 (4-4-4-4) con nariz de tiburón y dos juegos de bielas, **con su ténder** | 8 bloques/s | silbato grave |
| **N&W clase J** | Aerodinámica norteamericana de 1950 (4-8-4) con nariz de bala y franja roja, **con su ténder** | 8 bloques/s | silbato grave |
| **Merchant Navy** | Pacific británica de 1941 con carcasa lisa, verde, y ruedas de disco agujereadas, **con su ténder** | 8 bloques/s | silbato |
| **9F Evening Star** | La última vapor de British Railways (1960, 2-10-0), con diez ruedas motrices, **con su ténder** | 7 bloques/s | silbato |
| **D51** | La vapor japonesa más famosa (1936, 2-8-2), negra, **con su ténder** | 7 bloques/s | silbato agudo |
| **P36** | Soviética de 1950 (4-8-4), verde con franja roja y ruedas rojas, **con su ténder** | 8 bloques/s | silbato grave |
| **Garratt** | Articulada africana de 1955 (4-8-2+2-8-4): **la caldera va colgada entre dos unidades motrices** | 6 bloques/s | silbato grave |
| **EMD F7** | Diésel norteamericana de 1949: nariz "bulldog", verde con franja amarilla | 8 bloques/s | bocina americana |
| **V 200** | Diésel-hidráulica alemana de 1953: roja, con la "V" cromada y cabina en las dos puntas | 8 bloques/s, arranque rápido | bocina aguda |
| **InterCity 125** | Coche motor diésel británico de 1976 con nariz en cuña: el tren diésel más rápido del mundo (238 km/h) | 8 bloques/s, arranque rápido | bocina de dos tonos |
| **Deltic** | Diésel británica de 1961 con dos motores, verde en dos tonos y cabina en las dos puntas | 8 bloques/s | bocina británica |
| **EMD SD40-2** | Diésel de carga norteamericana de 1972, azul, con bogies de 3 ejes | 7 bloques/s | bocina americana |
| **GE ES44AC** | Diésel de carga norteamericana de 2003, cabina ancha y radiador grande atrás | 7 bloques/s | bocina grave |
| **DD51** | Diésel-hidráulica japonesa de 1962, roja, con la cabina en el medio entre dos capós | 7 bloques/s | bocina aguda |
| **Class 08** | Diésel de maniobras británica de 1952 (0-6-0 con bielas), azul con rayas de avispa | 5 bloques/s, arranque muy rápido | bocina |
| **Pioneer Zephyr** | Tren diésel aerodinámico norteamericano de 1934, de acero inoxidable acanalado: **dos coches articulados** | 8 bloques/s | bocina |
| **Fliegender Hamburger** | El primer tren diésel rápido del mundo (Alemania, 1933), violeta y crema: **dos coches articulados** | 8 bloques/s | bocina aguda |
| **V 160 «Lollo»** | Diésel-hidráulica alemana de 1960, roja, con las puntas muy redondeadas | 8 bloques/s | bocina aguda |
| **CC 72000** | Diésel francesa de 1967, azul, con los «bigotes» de acero inoxidable | 8 bloques/s | bocina |
| **ChME3** | Diésel de maniobras de 1963, la más fabricada de la historia, roja con franjas crema | 5 bloques/s, arranque muy rápido | bocina aguda |
| **DF4 «Dongfeng»** | Diésel de carga china de 1969, verde con franja amarilla y cabina en las dos puntas | 7 bloques/s | bocina |
| **WDM-2** | Diésel de la India de 1962, de diseño ALCO, roja y crema | 7 bloques/s | bocina |
| **P42 «Genesis»** | Diésel de pasajeros norteamericana de 1996, plateada con banda azul | 8 bloques/s, arranque rápido | bocina grave |
| **DF200 «Red Bear»** | Diésel de carga japonesa de 1992 con tres bogies, roja con el frente negro | 7 bloques/s | bocina |
| **EMD GP9 abandonada** | Diésel de carga norteamericana de 1954, azul desteñida, oxidada y con pasto | 7 bloques/s | bocina |
| **EMD E8 abandonada** | Diésel de pasajeros norteamericana de 1949 con la nariz inclinada, granate y oxidada | 8 bloques/s | bocina |
| **ALCO RS-3 abandonada** | Diésel norteamericana de 1950, naranja casi toda oxidada, con una baranda caída | 6 bloques/s | bocina |
| **Budd RDC abandonado** | Coche motor diésel norteamericano de 1949, de acero inoxidable mugriento | 7 bloques/s | bocina aguda |
| **Class 37 abandonada** | Diésel británica de 1960, azul y amarilla, con las narices oxidadas | 7 bloques/s | bocina |
| **Class 20 abandonada** | Diésel británica de 1957 con una sola cabina, gris y oxidada | 6 bloques/s | bocina |
| **M62 abandonada** | Diésel soviética de 1965, verde con franja amarilla, oxidada | 7 bloques/s | bocina grave |
| **TEP60 abandonada** | Diésel de pasajeros soviética de 1960, roja y crema desteñida | 8 bloques/s | bocina |
| **T478.3 abandonada** | Diésel checoslovaca de 1968 con los parabrisas de «anteojos», roja y oxidada | 6 bloques/s | bocina aguda |
| **KiHa 40 abandonado** | Coche motor diésel japonés de 1977, rojo y crema desteñido | 6 bloques/s | bocina aguda |
| **Sharknose abandonada** | Diésel norteamericana de 1950 con la nariz de tiburón, negra y oxidada | 7 bloques/s | bocina |
| **Locomotion No. 1** | La del primer ferrocarril público a vapor (Inglaterra, 1825): cilindros verticales con bielas larguísimas que bajan a las ruedas, **con su ténder de tonel** | 4 bloques/s | silbato |
| **Best Friend of Charleston** | La primera hecha en EE. UU. (1830): caldera parada en forma de botella y el maquinista adelante, **con su ténder de leña** | 5 bloques/s | silbato agudo |
| **John Bull** | Inglesa de 1831 que se volvió americana: quitapiedras, faro de cajón, campana y caldera forrada de madera, **con su ténder** | 5 bloques/s | silbato |
| **Adler** | La primera de Alemania (1835, 2-2-2), verde, con una sola rueda motriz grande, **con su ténder** | 6 bloques/s | silbato agudo |
| **Coppernob** | 0-4-0 inglesa de 1846, roja, con el hogar redondo forrado de cobre, **con su ténder** | 5 bloques/s | silbato |
| **La Porteña** | La primera que corrió en la Argentina (1857): locomotora tanque verde con ruedas rojas | 5 bloques/s | silbato agudo |
| **Shay** | Engranada de aserradero de la década de 1880: cilindros verticales que mueven un árbol con cardanes y coronas dentadas | 4 bloques/s, mucha fuerza | silbato grave |

Más imágenes de cada una: [Flying Scotsman](docs/reales_1.jpg) · [EMD F7](docs/reales_2.jpg) · [V 200](docs/reales_3.jpg) ·
[A4 Mallard](docs/tren_1.jpg) · [Big Boy](docs/tren_2.jpg) · [GS-4](docs/tren_3.jpg) · [BR 01](docs/tren_4.jpg) ·
[Pannier](docs/tren_5.jpg) · [InterCity 125](docs/tren_6.jpg) · [Deltic](docs/tren_7.jpg) · [SD40-2](docs/tren_8.jpg) ·
[ES44AC](docs/tren_9.jpg) · [DD51](docs/tren_10.jpg) · [Class 08](docs/tren_11.jpg) ·
[Rocket](docs/vapor_rocket.jpg) · [Jupiter](docs/vapor_jupiter.jpg) · [Hiawatha](docs/vapor_hiawatha.jpg) ·
[PRR T1](docs/vapor_t1.jpg) · [N&W J](docs/vapor_nwj.jpg) · [Merchant Navy](docs/vapor_merchant.jpg) ·
[9F](docs/vapor_br9f.jpg) · [D51](docs/vapor_d51.jpg) · [P36](docs/vapor_p36.jpg) · [Garratt](docs/vapor_garratt.jpg) ·
[Pioneer Zephyr](docs/diesel_zephyr.jpg) · [Fliegender Hamburger](docs/diesel_hamburger.jpg) · [V 160](docs/diesel_v160.jpg) ·
[CC 72000](docs/diesel_cc72000.jpg) · [ChME3](docs/diesel_chme3.jpg) · [DF4](docs/diesel_df4.jpg) · [WDM-2](docs/diesel_wdm2.jpg) ·
[P42 Genesis](docs/diesel_p42.jpg) · [DF200](docs/diesel_df200.jpg) ·
Abandonadas: [GP9](docs/abandonada_gp9.jpg) · [E8](docs/abandonada_e8.jpg) · [RS-3](docs/abandonada_rs3.jpg) ·
[RDC](docs/abandonada_rdc.jpg) · [Class 37](docs/abandonada_class37.jpg) · [Class 20](docs/abandonada_class20.jpg) ·
[M62](docs/abandonada_m62.jpg) · [TEP60](docs/abandonada_tep60.jpg) · [T478.3](docs/abandonada_t478.jpg) ·
[KiHa 40](docs/abandonada_kiha40.jpg) · [Sharknose](docs/abandonada_sharknose.jpg) ·
Antiguas: [Locomotion No. 1](docs/antigua_locomotion.jpg) · [Best Friend of Charleston](docs/antigua_best_friend.jpg) ·
[John Bull](docs/antigua_john_bull.jpg) · [Adler](docs/antigua_adler.jpg) · [Coppernob](docs/antigua_coppernob.jpg) ·
[La Porteña](docs/antigua_portena.jpg) · [Shay](docs/antigua_shay.jpg)

- Las **pequeñas antiguas** son las de los comienzos del ferrocarril: chiquitas, lentas y llenas de mecanismos a la vista. La Locomotion tiene los cilindros parados arriba de la caldera, la Best Friend lleva la caldera de botella y la Shay es engranada: sus cilindros verticales hacen girar un árbol a lo largo de la máquina que mueve las ruedas con coronas dentadas.
- Las **abandonadas** andan igual que las demás diésel, pero se ven viejas: óxido con chorreaduras, pintura desteñida y descascarada, vidrios rotos, faros quebrados, musgo, enredaderas y pasto creciendo.
- Están hechas en la escala de Traincraft (16 píxeles por bloque) y con **superficies curvas de verdad**: narices, calderas, carenados, domos y techos lisos, sin escalones. Los faros son redondos. No llevan logos de empresas reales.
- Miden de 4 a 24 bloques de largo y **siguen la vía con sus bogies**: en las curvas y en las subidas cada cuerpo se apoya en los rieles como un tren de verdad. Los ténderes van articulados detrás de la locomotora, la unidad motriz delantera de la Big Boy gira debajo de la caldera, como en la real, en la Garratt la caldera va colgada entre sus dos unidades motrices, y el Pioneer Zephyr y el Fliegender Hamburger son dos coches articulados que comparten el bogie del medio.
- Las curvas de Minecraft giran 90° en un solo bloque, así que en una curva los trenes largos cortan camino por adentro. Se lucen en rectas largas.
- Las de vapor usan carbón; las diésel, bidones de diésel. Las bielas de las de vapor se mueven con la cinemática real: biela motriz, cruceta y pistón (la Big Boy y la T1 tienen dos juegos; la Rocket y la Best Friend, cilindros inclinados; la Locomotion, cilindros verticales con contramanivelas; la Shay, cigüeñal y árboles que giran a lo largo).

## Cómo se usan

| Acción | Qué hace |
|---|---|
| Clic derecho **sobre un riel** con el ítem | Coloca la locomotora mirando hacia donde miras |
| Clic derecho con **carbón / carbón vegetal** (vapor) | Carga 1 pieza en la caldera (un **bloque de carbón** carga 9) |
| Clic derecho con un **bidón de diésel** (diésel) | Carga el tanque (un bidón rinde como 6 carbones) |
| Clic derecho con la **mano vacía** | Te subes a la cabina como maquinista |
| **Shift + clic derecho** | Arranca (alejándose de ti) o frena, sin subirte |
| Montado: **W** / **S** | Sube / baja la marcha: atrás ◀, freno ■, 1, 2, 3 |
| Montado: **A** o **D** | Suena el silbato o la bocina 🎵 |
| Montado: **Shift** | Te bajas |

- Gastan más combustible cuanto más rápido van. Con una pieza de carbón andan 4 minutos en marcha 1.
- La caldera o el tanque guarda hasta 40 carbones (casi 7 bidones). Si rompes la locomotora te devuelve lo que quedaba.
- Si choca contra algo y queda trabada, se frena sola.
- Un riel propulsor **apagado** la detiene (sirve como estación).
- Empuja a las vagonetas que tenga delante (o detrás, en marcha atrás) sin que se metan dentro del modelo.
- Necesita **2 bloques libres de alto** sobre la vía para pasar (aunque se vea de 3, el techo de los túneles puede atravesarla).
- Miden de 4 a 24 bloques de largo y siguen la vía con sus bogies.

## Recetas

**Bidón de diésel** (sin forma): 1 lingote de hierro + 2 carbones (o carbón vegetal) + 1 alga seca.

**Locomotoras** — con un riel arriba:

```
             [Riel]
[Lingote de hierro] [Horno, Alto horno, Pistón o Pistón pegajoso] [Lingote de hierro]
   [ X ]          [Vagoneta]          [ X ]
```

| Locomotora | Al medio | X (tinte) |
|---|---|---|
| Flying Scotsman | Horno | verde lima |
| A4 Mallard | Horno | azul |
| Big Boy | Horno | negro |
| GS-4 Daylight | Horno | naranja |
| BR 01 | Horno | rojo |
| Pannier | Horno | verde |
| EMD F7 | Pistón | verde |
| V 200 | Pistón | rojo |
| InterCity 125 | Pistón | amarillo |
| Deltic | Pistón | verde lima |
| EMD SD40-2 | Pistón | azul |
| GE ES44AC | Pistón | gris claro |
| DD51 | Pistón | naranja |
| Class 08 | Pistón | cian |
| Rocket | Alto horno | amarillo |
| Jupiter | Alto horno | azul |
| Hiawatha | Alto horno | naranja |
| PRR T1 | Alto horno | verde |
| N&W clase J | Alto horno | negro |
| Merchant Navy | Alto horno | verde lima |
| 9F Evening Star | Alto horno | gris |
| D51 | Alto horno | blanco |
| P36 | Alto horno | rojo |
| Garratt | Alto horno | violeta |
| Pioneer Zephyr | Pistón | blanco |
| Fliegender Hamburger | Pistón | violeta |
| V 160 Lollo | Pistón | rosa |
| CC 72000 | Pistón | azul claro |
| ChME3 | Pistón | marrón |
| DF4 | Pistón pegajoso | verde |
| WDM-2 | Pistón | magenta |
| P42 Genesis | Pistón | gris |
| DF200 | Pistón | negro |
| EMD GP9 (abandonada) | Pistón | azul |
| EMD E8 (abandonada) | Pistón | marrón |
| ALCO RS-3 (abandonada) | Pistón | naranja |
| Budd RDC (abandonada) | Pistón | gris claro |
| Class 37 (abandonada) | Pistón | cian |
| Class 20 (abandonada) | Pistón | gris |
| M62 (abandonada) | Pistón | verde |
| TEP60 (abandonada) | Pistón | blanco |
| T478.3 (abandonada) | Pistón | rojo |
| KiHa 40 (abandonada) | Pistón | rosa |
| Sharknose (abandonada) | Pistón | negro |
| Locomotion No. 1 (antigua) | Horno | negro |
| Best Friend of Charleston (antigua) | Horno | rojo |
| John Bull (antigua) | Horno | marrón |
| Adler (antigua) | Horno | verde |
| Coppernob (antigua) | Horno | naranja |
| La Porteña (antigua) | Horno | azul claro |
| Shay (antigua) | Horno | gris |

En las **abandonadas** van **bloques de musgo** en lugar de los lingotes de hierro, y en las **antiguas**, **lingotes de cobre**.

Todo está también en el modo creativo, en la pestaña **Herramientas y utilidades**.

## Compilar el mod en GitHub (sin instalar nada)

**Una sola vez:**

1. Entra a <https://github.com/new>, ponle un nombre (por ejemplo `locomotora-mod`) y toca **Create repository**.
2. En la página del repositorio vacío toca el enlace **creating a new file**.
3. Como nombre del archivo escribe `.github/workflows/build.yml` (cada `/` crea una carpeta).
4. Pega adentro el contenido del archivo `.github/workflows/build.yml` de este zip y toca **Commit changes**.

**Cada vez que tengas una versión nueva del mod:**

1. En el repositorio toca **Add file → Upload files**.
2. Arrastra el archivo `locomotora-mod.zip` **tal cual, sin descomprimirlo**, y toca **Commit changes**. Si ya había uno, se reemplaza; si quedan varios, se usa el último que subiste.
3. Ve a la pestaña **Actions**. Vas a ver "Compilar mod" corriendo (tarda unos 3–5 minutos la primera vez).
4. Cuando tenga el tilde verde ✅, entra a esa ejecución y abajo, en **Artifacts**, descarga **locomotora-mod**. Es un `.zip` que adentro tiene `locomotora-9.0.0.jar`.

También funciona si subes los archivos ya descomprimidos en vez del `.zip`, o un `.rar`.

Si sale una cruz roja ❌, entra a la ejecución, abre el paso que falló y copia el error para arreglarlo.

## Instalar en Minecraft

1. Instala **NeoForge para 1.21.1** desde <https://neoforged.net>.
2. Copia `locomotora-9.0.0.jar` a la carpeta `mods` de tu `.minecraft` (borra la versión vieja si la tenías).
3. Abre el juego con el perfil de NeoForge.

## Compilar en tu computadora (opcional)

Con Java 21 instalado:

```
./gradlew build          (Linux / Mac)
gradlew.bat build        (Windows)
```

El `.jar` queda en `build/libs/`. Para probarlo directamente: `./gradlew runClient`.

## Estructura del código

```
src/main/java/com/locomotora/
├── LocomotoraMod.java                 clase principal y pestaña creativa
├── entidad/LocomotoraEntity.java      la locomotora: motor, marchas, combustible, controles, humo, sonidos
├── entidad/TipoLocomotora.java        medidas, velocidades y tipo (vapor o diésel) de cada modelo
├── item/LocomotoraItem.java           el ítem que la coloca sobre los rieles
├── cliente/LocomotoraRenderer.java    dibuja el modelo y anima ruedas y bielas
├── cliente/LocomotoraCliente.java     registra los modelos y renderers
├── cliente/Via.java                   recorre los rieles para que los trenes largos sigan la vía
├── cliente/modelos/Modelo*.java       los modelos 3D (generados desde el estudio de diseño)
└── registro/                          ítems (incluido el bidón), entidades y sonidos
```

Las velocidades, la aceleración y el tono del silbato o bocina de cada locomotora están en `TipoLocomotora.java`; el consumo, la capacidad y lo que rinde un bidón, al principio de `LocomotoraEntity.java`.
