# 🚂 Locomotoras de Vapor y Diésel — mod para NeoForge 1.21.1

Locomotoras de trenes reales al estilo Traincraft, de **hasta 3 bloques de alto**, que andan sobre los rieles normales de Minecraft. Tienen marchas (incluida marcha atrás), silbato o bocina, humo, ruedas y bielas animadas, y empujan las vagonetas que tengan adelante. Además hay **vagones de carga con cofre** que se enganchan a las locomotoras y van tirados (o empujados) por ellas, y **vías propias**: rectas, curvas redondas, de dos caminos y en subida, de hasta 30 bloques, que se ponen enteras de un clic.

## Las locomotoras

Son 57 trenes reales: 16 de vapor, 17 diésel, 11 diésel abandonadas, 7 pequeñas antiguas de vapor y 6 diésel industriales y de minería.

![Las de vapor](docs/vapor.jpg)
![Vapor, segunda tanda](docs/vapor2.jpg)
![Las diésel](docs/diesel.jpg)
![Diésel, segunda tanda](docs/diesel2.jpg)
![Las abandonadas](docs/abandonadas.jpg)
![Las pequeñas antiguas](docs/antiguas.jpg)
![Las industriales y de minería](docs/industriales.jpg)

| Locomotora | Qué es | Velocidad máxima | Sonido |
|---|---|---|---|
| **Flying Scotsman** | Vapor británica de 1923 (Pacific 4-6-2), verde manzana, **con su ténder** | 8 bloques/s | silbato de campana |
| **A4 Mallard** | Vapor británica de 1938 con carenado aerodinámico azul: la más rápida del mundo (203 km/h), **con su ténder** | 8 bloques/s | silbato de acordes |
| **Big Boy** | Vapor norteamericana de 1941, articulada 4-8-8-4: **la unidad delantera gira en las curvas**, con ténder "ciempiés" | 7 bloques/s | silbato grave |
| **GS-4 Daylight** | Vapor norteamericana de 1941 (4-8-4) con la librea roja, naranja y negra del Daylight, **con su ténder** | 8 bloques/s | silbato grave |
| **BR 01** | Vapor alemana de 1926 (Pacific 4-6-2), negra con ruedas rojas y deflectores de humo, **con su ténder** | 8 bloques/s | silbato agudo |
| **Pannier** | Locomotora tanque británica de 1929 (0-6-0), con los tanques de agua a los costados de la caldera | 6 bloques/s, arranque rápido | silbato agudo |
| **Rocket** | La pionera británica de 1829 (0-2-2): caldera amarilla, chimenea blanca altísima y cilindros inclinados, **con su ténder** | 6 bloques/s | silbato agudo |
| **Jupiter** | 4-4-0 del Lejano Oeste de 1868: chimenea de globo, faro de cajón y quitapiedras, **con su ténder de leña** | 6 bloques/s | silbato agudo |
| **Hiawatha** | Aerodinámica norteamericana de 1935 (4-4-2) en gris, naranja y granate, con ruedas motrices de 2,13 m, **con su ténder** | 8 bloques/s | silbato |
| **PRR T1** | Duplex norteamericana de 1942 (4-4-4-4) con nariz de tiburón y dos juegos de bielas, **con su ténder** | 8 bloques/s | silbato grave |
| **N&W clase J** | Aerodinámica norteamericana de 1950 (4-8-4) con nariz de bala y franja roja, **con su ténder** | 8 bloques/s | silbato grave |
| **Merchant Navy** | Pacific británica de 1941 con carcasa lisa, verde, y ruedas de disco agujereadas, **con su ténder** | 8 bloques/s | silbato |
| **9F Evening Star** | La última vapor de British Railways (1960, 2-10-0), con diez ruedas motrices, **con su ténder** | 7 bloques/s | silbato |
| **D51** | La vapor japonesa más famosa (1936, 2-8-2), negra, **con su ténder** | 7 bloques/s | silbato agudo |
| **P36** | Soviética de 1950 (4-8-4), verde con franja roja y ruedas rojas, **con su ténder** | 8 bloques/s | silbato grave |
| **Garratt** | Articulada africana de 1955 (4-8-2+2-8-4): **la caldera va colgada entre dos unidades motrices** | 6 bloques/s | silbato grave |
| **EMD F7** | Diésel norteamericana de 1949: nariz "bulldog", verde con franja amarilla | 8 bloques/s | bocina americana |
| **V 200** | Diésel-hidráulica alemana de 1953: roja, con la "V" cromada y cabina en las dos puntas | 8 bloques/s, arranque rápido | bocina aguda |
| **InterCity 125** | Coche motor diésel británico de 1976 con nariz en cuña: el tren diésel más rápido del mundo (238 km/h) | 8 bloques/s, arranque rápido | bocina de dos tonos |
| **Deltic** | Diésel británica de 1961 con dos motores, verde en dos tonos y cabina en las dos puntas | 8 bloques/s | bocina británica |
| **EMD SD40-2** | Diésel de carga norteamericana de 1972, azul, con bogies de 3 ejes | 7 bloques/s | bocina americana |
| **GE ES44AC** | Diésel de carga norteamericana de 2003, cabina ancha y radiador grande atrás | 7 bloques/s | bocina grave |
| **DD51** | Diésel-hidráulica japonesa de 1962, roja, con la cabina en el medio entre dos capós | 7 bloques/s | bocina aguda |
| **Class 08** | Diésel de maniobras británica de 1952 (0-6-0 con bielas), azul con rayas de avispa | 5 bloques/s, arranque muy rápido | bocina |
| **Pioneer Zephyr** | Tren diésel aerodinámico norteamericano de 1934, de acero inoxidable acanalado: **dos coches articulados** | 8 bloques/s | bocina |
| **Fliegender Hamburger** | El primer tren diésel rápido del mundo (Alemania, 1933), violeta y crema: **dos coches articulados** | 8 bloques/s | bocina aguda |
| **V 160 «Lollo»** | Diésel-hidráulica alemana de 1960, roja, con las puntas muy redondeadas | 8 bloques/s | bocina aguda |
| **CC 72000** | Diésel francesa de 1967, azul, con los «bigotes» de acero inoxidable | 8 bloques/s | bocina |
| **ChME3** | Diésel de maniobras de 1963, la más fabricada de la historia, roja con franjas crema | 5 bloques/s, arranque muy rápido | bocina aguda |
| **DF4 «Dongfeng»** | Diésel de carga china de 1969, verde con franja amarilla y cabina en las dos puntas | 7 bloques/s | bocina |
| **WDM-2** | Diésel de la India de 1962, de diseño ALCO, roja y crema | 7 bloques/s | bocina |
| **P42 «Genesis»** | Diésel de pasajeros norteamericana de 1996, plateada con banda azul | 8 bloques/s, arranque rápido | bocina grave |
| **DF200 «Red Bear»** | Diésel de carga japonesa de 1992 con tres bogies, roja con el frente negro | 7 bloques/s | bocina |
| **EMD GP9 abandonada** | Diésel de carga norteamericana de 1954, azul desteñida, oxidada y con pasto | 7 bloques/s | bocina |
| **EMD E8 abandonada** | Diésel de pasajeros norteamericana de 1949 con la nariz inclinada, granate y oxidada | 8 bloques/s | bocina |
| **ALCO RS-3 abandonada** | Diésel norteamericana de 1950, naranja casi toda oxidada, con una baranda caída | 6 bloques/s | bocina |
| **Budd RDC abandonado** | Coche motor diésel norteamericano de 1949, de acero inoxidable mugriento | 7 bloques/s | bocina aguda |
| **Class 37 abandonada** | Diésel británica de 1960, azul y amarilla, con las narices oxidadas | 7 bloques/s | bocina |
| **Class 20 abandonada** | Diésel británica de 1957 con una sola cabina, gris y oxidada | 6 bloques/s | bocina |
| **M62 abandonada** | Diésel soviética de 1965, verde con franja amarilla, oxidada | 7 bloques/s | bocina grave |
| **TEP60 abandonada** | Diésel de pasajeros soviética de 1960, roja y crema desteñida | 8 bloques/s | bocina |
| **T478.3 abandonada** | Diésel checoslovaca de 1968 con los parabrisas de «anteojos», roja y oxidada | 6 bloques/s | bocina aguda |
| **KiHa 40 abandonado** | Coche motor diésel japonés de 1977, rojo y crema desteñido | 6 bloques/s | bocina aguda |
| **Sharknose abandonada** | Diésel norteamericana de 1950 con la nariz de tiburón, negra y oxidada | 7 bloques/s | bocina |
| **Locomotion No. 1** | La del primer ferrocarril público a vapor (Inglaterra, 1825): cilindros verticales con bielas larguísimas que bajan a las ruedas, **con su ténder de tonel** | 4 bloques/s | silbato |
| **Best Friend of Charleston** | La primera hecha en EE. UU. (1830): caldera parada en forma de botella y el maquinista adelante, **con su ténder de leña** | 5 bloques/s | silbato agudo |
| **John Bull** | Inglesa de 1831 que se volvió americana: quitapiedras, faro de cajón, campana y caldera forrada de madera, **con su ténder** | 5 bloques/s | silbato |
| **Adler** | La primera de Alemania (1835, 2-2-2), verde, con una sola rueda motriz grande, **con su ténder** | 6 bloques/s | silbato agudo |
| **Coppernob** | 0-4-0 inglesa de 1846, roja, con el hogar redondo forrado de cobre, **con su ténder** | 5 bloques/s | silbato |
| **La Porteña** | La primera que corrió en la Argentina (1857): locomotora tanque verde con ruedas rojas | 5 bloques/s | silbato agudo |
| **Shay** | Engranada de aserradero de la década de 1880: cilindros verticales que mueven un árbol con cardanes y coronas dentadas | 4 bloques/s, mucha fuerza | silbato grave |
| **Motor Rail Simplex** | Diésel inglesa de minas y canteras (década de 1930), chiquita y roja, con el radiador de panal y el maquinista sentado de costado | 4 bloques/s, arranque rápido | bocina aguda |
| **Deutz OMZ 117** | Diésel alemana de vía angosta (década de 1930), verde, con bielas y un techito sobre cuatro postes | 4 bloques/s, arranque rápido | bocina aguda |
| **GE de 44 toneladas** | Diésel de maniobras norteamericana de 1940, azul, con la cabina al medio entre dos capós y dos bogies | 6 bloques/s | bocina |
| **Plymouth** | Diésel de canteras y aserraderos (década de 1940), gris acero con las puntas a rayas de cebra y bielas | 4 bloques/s, arranque rápido | bocina aguda |
| **TGM23** | Diésel-hidráulica soviética de maniobras (1960-1990), granate con franja crema, tres ejes con bielas y eje ciego | 5 bloques/s | bocina |
| **Locomotora de túnel** | Diésel moderna de las obras de túneles y minas, naranja, muy baja, con una cabina en cada punta, faros LED y balizas | 4 bloques/s, arranque muy rápido | bocina aguda |

Más imágenes de cada una: [Flying Scotsman](docs/reales_1.jpg) · [EMD F7](docs/reales_2.jpg) · [V 200](docs/reales_3.jpg) ·
[A4 Mallard](docs/tren_1.jpg) · [Big Boy](docs/tren_2.jpg) · [GS-4](docs/tren_3.jpg) · [BR 01](docs/tren_4.jpg) ·
[Pannier](docs/tren_5.jpg) · [InterCity 125](docs/tren_6.jpg) · [Deltic](docs/tren_7.jpg) · [SD40-2](docs/tren_8.jpg) ·
[ES44AC](docs/tren_9.jpg) · [DD51](docs/tren_10.jpg) · [Class 08](docs/tren_11.jpg) ·
[Rocket](docs/vapor_rocket.jpg) · [Jupiter](docs/vapor_jupiter.jpg) · [Hiawatha](docs/vapor_hiawatha.jpg) ·
[PRR T1](docs/vapor_t1.jpg) · [N&W J](docs/vapor_nwj.jpg) · [Merchant Navy](docs/vapor_merchant.jpg) ·
[9F](docs/vapor_br9f.jpg) · [D51](docs/vapor_d51.jpg) · [P36](docs/vapor_p36.jpg) · [Garratt](docs/vapor_garratt.jpg) ·
[Pioneer Zephyr](docs/diesel_zephyr.jpg) · [Fliegender Hamburger](docs/diesel_hamburger.jpg) · [V 160](docs/diesel_v160.jpg) ·
[CC 72000](docs/diesel_cc72000.jpg) · [ChME3](docs/diesel_chme3.jpg) · [DF4](docs/diesel_df4.jpg) · [WDM-2](docs/diesel_wdm2.jpg) ·
[P42 Genesis](docs/diesel_p42.jpg) · [DF200](docs/diesel_df200.jpg) ·
Abandonadas: [GP9](docs/abandonada_gp9.jpg) · [E8](docs/abandonada_e8.jpg) · [RS-3](docs/abandonada_rs3.jpg) ·
[RDC](docs/abandonada_rdc.jpg) · [Class 37](docs/abandonada_class37.jpg) · [Class 20](docs/abandonada_class20.jpg) ·
[M62](docs/abandonada_m62.jpg) · [TEP60](docs/abandonada_tep60.jpg) · [T478.3](docs/abandonada_t478.jpg) ·
[KiHa 40](docs/abandonada_kiha40.jpg) · [Sharknose](docs/abandonada_sharknose.jpg) ·
Antiguas: [Locomotion No. 1](docs/antigua_locomotion.jpg) · [Best Friend of Charleston](docs/antigua_best_friend.jpg) ·
[John Bull](docs/antigua_john_bull.jpg) · [Adler](docs/antigua_adler.jpg) · [Coppernob](docs/antigua_coppernob.jpg) ·
[La Porteña](docs/antigua_portena.jpg) · [Shay](docs/antigua_shay.jpg) ·
Industriales: [Simplex](docs/industrial_simplex.jpg) · [Deutz](docs/industrial_deutz.jpg) · [GE 44 t](docs/industrial_ge44.jpg) ·
[Plymouth](docs/industrial_plymouth.jpg) · [TGM23](docs/industrial_tgm23.jpg) · [De túnel](docs/industrial_tunel.jpg)

- Las **industriales y de minería** son locomotoras de trabajo: chicas, lentas y con mucha fuerza para mover vagones en minas, canteras, fábricas, puertos y túneles.
- Las **pequeñas antiguas** son las de los comienzos del ferrocarril: chiquitas, lentas y llenas de mecanismos a la vista. La Locomotion tiene los cilindros parados arriba de la caldera, la Best Friend lleva la caldera de botella y la Shay es engranada: sus cilindros verticales hacen girar un árbol a lo largo de la máquina que mueve las ruedas con coronas dentadas.
- Las **abandonadas** andan igual que las demás diésel, pero se ven viejas: óxido con chorreaduras, pintura desteñida y descascarada, vidrios rotos, faros quebrados, musgo, enredaderas y pasto creciendo.
- Están hechas en la escala de Traincraft (16 píxeles por bloque) y con **superficies curvas de verdad**: narices, calderas, carenados, domos y techos lisos, sin escalones. Los faros son redondos. No llevan logos de empresas reales.
- Miden de 2,5 a 24 bloques de largo y **siguen la vía con sus bogies**: en las curvas y en las subidas cada cuerpo se apoya en los rieles como un tren de verdad. Los ténderes van articulados detrás de la locomotora, la unidad motriz delantera de la Big Boy gira debajo de la caldera, como en la real, en la Garratt la caldera va colgada entre sus dos unidades motrices, y el Pioneer Zephyr y el Fliegender Hamburger son dos coches articulados que comparten el bogie del medio.
- Las curvas de Minecraft giran 90° en un solo bloque, así que en una curva los trenes largos cortan camino por adentro. Se lucen en rectas largas.
- Las de vapor usan carbón; las diésel, bidones de diésel. Las bielas de las de vapor se mueven con la cinemática real: biela motriz, cruceta y pistón (la Big Boy y la T1 tienen dos juegos; la Rocket y la Best Friend, cilindros inclinados; la Locomotion, cilindros verticales con contramanivelas; la Shay, cigüeñal y árboles que giran a lo largo).

## Los vagones

Son 7 vagones de carga, cada uno pensado para una de las industriales, pero se pueden enganchar a **cualquier locomotora** y entre sí, todos los que quieras. Son ítems aparte de las locomotoras y tienen su propia pestaña en el modo creativo.

![Los vagones](docs/vagones.jpg)
![Un tren enganchado en las curvas y en la subida](docs/tren_enganchado.jpg)

| Vagón | Qué es | Va con |
|---|---|---|
| **Vagoneta volcadora en V** | La de las minas y canteras de vía angosta, con piedra y mineral | Simplex |
| **Vagón de ladrillera** | Plataforma de madera con dos pilas de ladrillos | Deutz |
| **Vagoneta de carbón** | Cajón de acero de las minas de carbón, lleno hasta el tope | cualquiera |
| **Tolva de mineral** | Tolva de mineral de hierro con las puntas inclinadas, sobre dos bogies | GE de 44 toneladas |
| **Vagón de volteo lateral** | Volquete de cantera con la caja sobre balancines y los pistones | Plymouth |
| **Vagón cisterna** | Tanque industrial con domo, pasarela, barandas y escaleras, sobre dos bogies | TGM23 |
| **Portadovelas de túnel** | Lleva las dovelas curvas de hormigón de las tuneladoras | Locomotora de túnel |

- Cada vagón tiene un **cofre de 27 espacios** (clic derecho para abrirlo). Las tolvas de Minecraft pueden cargarlos y descargarlos desde abajo de la vía, igual que a una vagoneta con cofre.
- **Se enganchan solos**: si pones un vagón en la vía pegado a una locomotora o a otro vagón, queda enganchado. Si pones una locomotora pegada a vagones sueltos, también.
- **Shift + clic derecho** en un vagón lo desengancha, o lo engancha a lo que tenga al lado.
- La locomotora tira de los vagones enganchados y, en marcha atrás, los empuja. Siguen la vía a la distancia justa también en las curvas cerradas, en las vueltas en U y en las subidas.
- Si rompes una locomotora o un vagón, los vagones que tenía enganchados quedan sueltos. Al romper un vagón se cae lo que llevaba en el cofre.

## Las vías

Además de los rieles de Minecraft, el mod trae **4 vías propias**, con durmientes de madera y rieles de acero. Cada una se pone **entera de un solo clic** y se configura con un menú: **Shift + clic derecho** con la vía en la mano y se eligen las medidas, **hasta 30 bloques**.

![Las vías nuevas](docs/vias.jpg)
![Trenes en las vías nuevas](docs/trenes_vias.jpg)
![El menú de las vías](docs/menu_vias.jpg)

| Vía | Qué se elige en el menú |
|---|---|
| **Vía recta** | El largo: de 1 a 30 bloques |
| **Vía curva** | El radio (de 2 a 30 bloques) y para qué lado dobla. Es un cuarto de vuelta redondo, no en escalones |
| **Vía de dos caminos** | El largo de la recta, el radio de la curva y para qué lado sale. Tiene un poste con un disco: verde = derecho, amarillo = desviado |
| **Vía en subida** | Cuánto sube y la pendiente: un bloque cada 1, 2, 3 o 4. También se puede poner desde arriba, **para bajar** |

- **Clic derecho en el piso** pone la pieza entera hacia donde miras. Si haces clic en la punta de otra vía, la nueva sigue desde ahí.
- Con la vía en la mano se ve **dónde va a quedar**: un contorno verde en cada bloque (rojo si hay algo en el camino) y la línea de los rieles.
- Donde no hay piso pone **balasto** debajo (debajo de la subida hace el terraplén entero). Si rompes cualquier bloque de la pieza se quita toda y te devuelve la vía con las mismas medidas.
- **Vía de dos caminos**: clic derecho **con la mano vacía** en la aguja (o en el tramo de antes) cambia el camino. También con **redstone** al lado: con señal va por la curva, sin señal derecho. Mientras pasa un tren no se puede cambiar (espera a que pase). Si un tren llega **de talón** desde el otro ramal, la aguja se pone sola para dejarlo pasar.
- Andan las locomotoras, los vagones y también las vagonetas comunes. Los trenes se dibujan **sobre los rieles redondos**: en las curvas, en la aguja y en la rampa pareja de la subida (la locomotora se inclina al subir), y el maquinista va sentado en la cabina aunque la vía doble.
- Las vías comunes de Minecraft se pueden conectar a las puntas de estas, pero no les cambian la forma.

## Cómo se usan

| Acción | Qué hace |
|---|---|
| Clic derecho **sobre un riel** con el ítem | Coloca la locomotora mirando hacia donde miras |
| Clic derecho con **carbón / carbón vegetal** (vapor) | Carga 1 pieza en la caldera (un **bloque de carbón** carga 9) |
| Clic derecho con un **bidón de diésel** (diésel) | Carga el tanque (un bidón rinde como 6 carbones) |
| Clic derecho con la **mano vacía** | Te subes a la cabina como maquinista |
| **Shift + clic derecho** | Arranca (alejándose de ti) o frena, sin subirte |
| Montado: **W** / **S** | Sube / baja la marcha: atrás ◀, freno ■, 1, 2, 3 |
| Montado: **A** o **D** | Suena el silbato o la bocina 🎵 |
| Montado: **Shift** | Te bajas |
| Clic derecho **sobre un riel** con un vagón | Lo coloca y se engancha solo a la locomotora o al vagón que tenga pegado |
| Clic derecho en un **vagón** | Abre su carga (27 espacios) |
| **Shift + clic derecho** en un **vagón** | Lo desengancha, o lo engancha a lo que tenga al lado |
| Clic derecho **en el piso** con una vía | Pone la pieza entera mirando hacia donde miras |
| **Shift + clic derecho** con una vía | Abre el menú para elegir las medidas (hasta 30 bloques) |
| Clic derecho con la **mano vacía** en la aguja | Cambia el camino de la vía de dos caminos |

- Gastan más combustible cuanto más rápido van. Con una pieza de carbón andan 4 minutos en marcha 1.
- La caldera o el tanque guarda hasta 40 carbones (casi 7 bidones). Si rompes la locomotora te devuelve lo que quedaba.
- Si choca contra algo y queda trabada, se frena sola.
- Un riel propulsor **apagado** la detiene (sirve como estación).
- Empuja a las vagonetas que tenga delante (o detrás, en marcha atrás) sin que se metan dentro del modelo.
- Necesita **2 bloques libres de alto** sobre la vía para pasar (aunque se vea de 3, el techo de los túneles puede atravesarla).
- Miden de 2,5 a 24 bloques de largo y siguen la vía con sus bogies.

## Recetas

**Bidón de diésel** (sin forma): 1 lingote de hierro + 2 carbones (o carbón vegetal) + 1 alga seca.

**Locomotoras** — con un riel arriba:

```
             [Riel]
[Lingote de hierro] [Horno, Alto horno, Pistón o Pistón pegajoso] [Lingote de hierro]
   [ X ]          [Vagoneta]          [ X ]
```

| Locomotora | Al medio | X (tinte) |
|---|---|---|
| Flying Scotsman | Horno | verde lima |
| A4 Mallard | Horno | azul |
| Big Boy | Horno | negro |
| GS-4 Daylight | Horno | naranja |
| BR 01 | Horno | rojo |
| Pannier | Horno | verde |
| EMD F7 | Pistón | verde |
| V 200 | Pistón | rojo |
| InterCity 125 | Pistón | amarillo |
| Deltic | Pistón | verde lima |
| EMD SD40-2 | Pistón | azul |
| GE ES44AC | Pistón | gris claro |
| DD51 | Pistón | naranja |
| Class 08 | Pistón | cian |
| Rocket | Alto horno | amarillo |
| Jupiter | Alto horno | azul |
| Hiawatha | Alto horno | naranja |
| PRR T1 | Alto horno | verde |
| N&W clase J | Alto horno | negro |
| Merchant Navy | Alto horno | verde lima |
| 9F Evening Star | Alto horno | gris |
| D51 | Alto horno | blanco |
| P36 | Alto horno | rojo |
| Garratt | Alto horno | violeta |
| Pioneer Zephyr | Pistón | blanco |
| Fliegender Hamburger | Pistón | violeta |
| V 160 Lollo | Pistón | rosa |
| CC 72000 | Pistón | azul claro |
| ChME3 | Pistón | marrón |
| DF4 | Pistón pegajoso | verde |
| WDM-2 | Pistón | magenta |
| P42 Genesis | Pistón | gris |
| DF200 | Pistón | negro |
| EMD GP9 (abandonada) | Pistón | azul |
| EMD E8 (abandonada) | Pistón | marrón |
| ALCO RS-3 (abandonada) | Pistón | naranja |
| Budd RDC (abandonada) | Pistón | gris claro |
| Class 37 (abandonada) | Pistón | cian |
| Class 20 (abandonada) | Pistón | gris |
| M62 (abandonada) | Pistón | verde |
| TEP60 (abandonada) | Pistón | blanco |
| T478.3 (abandonada) | Pistón | rojo |
| KiHa 40 (abandonada) | Pistón | rosa |
| Sharknose (abandonada) | Pistón | negro |
| Locomotion No. 1 (antigua) | Horno | negro |
| Best Friend of Charleston (antigua) | Horno | rojo |
| John Bull (antigua) | Horno | marrón |
| Adler (antigua) | Horno | verde |
| Coppernob (antigua) | Horno | naranja |
| La Porteña (antigua) | Horno | azul claro |
| Shay (antigua) | Horno | gris |
| Motor Rail Simplex (industrial) | Pistón | rojo |
| Deutz OMZ 117 (industrial) | Pistón | verde |
| GE de 44 toneladas (industrial) | Pistón | azul |
| Plymouth (industrial) | Pistón | gris |
| TGM23 (industrial) | Pistón | marrón |
| Locomotora de túnel (industrial) | Pistón | naranja |

En las **abandonadas** van **bloques de musgo** en lugar de los lingotes de hierro, y en las **antiguas** y en las **industriales**, **lingotes de cobre**.

**Vagones** — con un cofre al medio:

```
                    [ X ]
[Lingote de hierro] [Cofre]    [Lingote de hierro]
[Lingote de hierro] [Vagoneta] [Lingote de hierro]
```

| Vagón | X |
|---|---|
| Vagoneta volcadora en V | Hierro en bruto |
| Vagón de ladrillera | Ladrillo |
| Vagoneta de carbón | Carbón |
| Tolva de mineral | Tolva |
| Vagón de volteo lateral | Roca (cobblestone) |
| Vagón cisterna | Cubo |
| Portadovelas de túnel | Piedra lisa |

**Vías:**

```
[Lingote de hierro]     [ ]       [Lingote de hierro]
[Lingote de hierro]   [Palo]      [Lingote de hierro]
[Lingote de hierro]  [Grava]      [Lingote de hierro]
```

Eso da una **vía recta**. Las demás salen de ella (sin forma):

| Vía | Receta (sin forma) |
|---|---|
| Vía curva | Vía recta + 2 lingotes de hierro |
| Vía de dos caminos | Vía recta + vía curva + palanca |
| Vía en subida | Vía recta + 2 gravas + 1 roca (cobblestone) |
| 8 balastos | 5 gravas y 4 rocas alternadas (grava en las esquinas y el centro) |
| 6 losas de balasto | 3 balastos en fila |

Cada vía sirve para **una pieza de hasta 30 bloques**; al romperla te la devuelve con las mismas medidas.

Todo está también en el modo creativo, en tres pestañas propias: **Locomotoras** (con el bidón de diésel), **Vagones** y **Vías** (con el balasto).

## Compilar el mod en GitHub (sin instalar nada)

**Una sola vez:**

1. Entra a <https://github.com/new>, ponle un nombre (por ejemplo `locomotora-mod`) y toca **Create repository**.
2. En la página del repositorio vacío toca el enlace **creating a new file**.
3. Como nombre del archivo escribe `.github/workflows/build.yml` (cada `/` crea una carpeta).
4. Pega adentro el contenido del archivo `.github/workflows/build.yml` de este zip y toca **Commit changes**.

**Cada vez que tengas una versión nueva del mod:**

1. En el repositorio toca **Add file → Upload files**.
2. Arrastra el archivo `locomotora-mod.zip` **tal cual, sin descomprimirlo**, y toca **Commit changes**. Si ya había uno, se reemplaza; si quedan varios, se usa el último que subiste.
3. Ve a la pestaña **Actions**. Vas a ver "Compilar mod" corriendo (tarda unos 3–5 minutos la primera vez).
4. Cuando tenga el tilde verde ✅, entra a esa ejecución y abajo, en **Artifacts**, descarga **locomotora-mod**. Es un `.zip` que adentro tiene `locomotora-11.0.0.jar`.

También funciona si subes los archivos ya descomprimidos en vez del `.zip`, o un `.rar`.

Si sale una cruz roja ❌, entra a la ejecución, abre el paso que falló y copia el error para arreglarlo.

## Instalar en Minecraft

1. Instala **NeoForge para 1.21.1** desde <https://neoforged.net>.
2. Copia `locomotora-11.0.0.jar` a la carpeta `mods` de tu `.minecraft` (borra la versión vieja si la tenías).
3. Abre el juego con el perfil de NeoForge.

## Compilar en tu computadora (opcional)

Con Java 21 instalado:

```
./gradlew build          (Linux / Mac)
gradlew.bat build        (Windows)
```

El `.jar` queda en `build/libs/`. Para probarlo directamente: `./gradlew runClient`.

## Estructura del código

```
src/main/java/com/locomotora/
├── LocomotoraMod.java                 clase principal
├── entidad/LocomotoraEntity.java      la locomotora: motor, marchas, combustible, controles, humo, sonidos
├── entidad/TipoLocomotora.java        medidas, velocidades y tipo (vapor o diésel) de cada modelo
├── entidad/VagonEntity.java           el vagón: cofre, enganche y cómo sigue a su líder
├── entidad/TipoVagon.java             medidas de cada vagón
├── entidad/Enganches.java             enganchar, soltar y buscar vecinos sobre la vía; topes entre vagonetas
├── entidad/Via.java                   recorre los rieles: los trenes largos siguen la vía y los vagones miden la distancia
├── item/LocomotoraItem.java           el ítem que coloca la locomotora sobre los rieles
├── item/VagonItem.java                el ítem que coloca el vagón (y lo engancha)
├── via/Pieza.java                     las piezas de vía: qué bloques ocupan, la forma de riel de cada uno y el trazo redondo
├── via/DibujoVia.java                 durmientes, rieles, terraplén y poste del cambio que dibuja cada bloque
├── via/ViaBlock.java (y Via*Block)    los bloques de las vías; ViaDesvioBlock tiene la aguja (clic, redstone, de talón)
├── via/ViaItem.java, ViaMenu.java     el ítem que pone la pieza entera y el menú para elegir las medidas
├── cliente/ViaRenderer.java           dibuja las curvas, los desvíos y las subidas (la recta usa su modelo de bloque)
├── cliente/ViaScreen.java             la pantalla del menú, con la vista previa de la pieza
├── cliente/VistaPrevia.java           el contorno de dónde va a quedar la pieza, con la vía en la mano
├── cliente/LocomotoraRenderer.java    dibuja locomotoras y vagones y anima ruedas y bielas
├── cliente/LocomotoraCliente.java     registra los modelos y renderers
├── cliente/modelos/Modelo*.java       los modelos 3D (generados desde el estudio de diseño)
└── registro/                          bloques, ítems (incluido el bidón), entidades, sonidos, menú y pestañas
```

Las velocidades, la aceleración y el tono del silbato o bocina de cada locomotora están en `TipoLocomotora.java`; el consumo, la capacidad y lo que rinde un bidón, al principio de `LocomotoraEntity.java`.
