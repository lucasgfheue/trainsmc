package com.locomotora.tren;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.jetbrains.annotations.Nullable;

import com.locomotora.entidad.Enganches;
import com.locomotora.entidad.LocomotoraEntity;
import com.locomotora.entidad.TipoLocomotora;
import com.locomotora.entidad.TipoVagon;
import com.locomotora.entidad.VagonEntity;
import com.locomotora.entidad.VehiculoDeVia;
import com.locomotora.generacion.Redes;
import com.locomotora.mundo.Red;
import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModReglas;
import com.locomotora.via.ViaBlock;

import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/**
 * Los trenes que pasan solos por la red de vías: cada tantos minutos (regla {@code locomotoraMinutosTren}), a cada
 * jugador que esté cerca de una línea le pasa un tren cualquiera (una locomotora y algunos vagones). Aparece a unos
 * 70 a 100 bloques sobre la vía, viene hacia el jugador a toda marcha, toca bocina o silbato al acercarse (y cada vez
 * que hay alguien parado en la vía delante) y sigue de largo; cuando queda lejos de todos (o al rato) desaparece. A
 * cada jugador los trenes le pasan una vez para cada lado: si uno vino del este, el próximo viene del oeste. Si alguien
 * se sube, deja de andar solo y queda para él.
 */
public final class Despachante {
    /** Dato guardado en cada vehículo de un tren automático: cuándo apareció (tick del mundo). */
    public static final String MARCA = "locomotora_auto";
    /** En los vagones: la locomotora de su tren. */
    public static final String TREN = "locomotora_auto_tren";
    private static final String SILBO = "locomotora_auto_silbo";
    /** Lo más que vive un tren automático (ticks). */
    private static final int VIDA = 20 * 60 * 4;
    /** Más lejos que esto de todos los jugadores, el tren se va. */
    private static final double LEJOS = 128.0;

    /** Si por el lado que le toca no se puede (curvas, vías sin cargar, otro tren), se espera esto antes de mandarlo
     * igual por el mismo lado que el anterior (ticks). */
    private static final long ESPERA_DEL_OTRO_LADO = 20L * 30L;

    private static final Map<UUID, Long> ULTIMO = new HashMap<>();
    /** De qué lado vino el último tren de cada jugador (1 = del este, -1 = del oeste). */
    private static final Map<UUID, Integer> LADO = new HashMap<>();
    /** Desde cuándo se está esperando poder mandarle el tren por el otro lado. */
    private static final Map<UUID, Long> ESPERANDO = new HashMap<>();
    private static final Map<UUID, Integer> QUIETOS = new HashMap<>();
    private static final Set<UUID> ACTIVOS = new HashSet<>();
    private static final Set<Long> PEDIDOS = ConcurrentHashMap.newKeySet();

    private Despachante() {
    }

    // ================================================================= eventos
    public static void alTick(LevelTickEvent.Post evento) {
        if (!(evento.getLevel() instanceof ServerLevel nivel) || nivel.dimension() != Level.OVERWORLD) {
            return;
        }
        long ahora = nivel.getGameTime();
        if (ahora % 20L != 7L) {
            return;
        }
        administrar(nivel, ahora);
        if (!ModReglas.trenes(nivel.getGameRules())) {
            return;
        }
        long espera = 20L * 60L * Math.max(1, ModReglas.minutosTren(nivel.getGameRules()));
        for (ServerPlayer jugador : nivel.players()) {
            if (jugador.isSpectator()) {
                continue;
            }
            long ultimo = ULTIMO.computeIfAbsent(jugador.getUUID(), k -> ahora);
            if (ahora - ultimo < espera || jugador.isPassenger() || hayTrenCerca(nivel, jugador)) {
                continue;
            }
            if (intentar(nivel, jugador, ahora)) {
                ULTIMO.put(jugador.getUUID(), ahora);
            }
        }
    }

    /** Los trenes automáticos que quedaron guardados en el disco y ya pasaron su hora no vuelven al mundo. */
    public static void alEntrar(EntityJoinLevelEvent evento) {
        if (evento.getLevel().isClientSide() || !evento.loadedFromDisk()) {
            return;
        }
        Entity e = evento.getEntity();
        CompoundTag datos = e.getPersistentData();
        if (!datos.contains(MARCA)) {
            return;
        }
        long ahora = evento.getLevel().getGameTime();
        long nacio = datos.getLong(MARCA);
        if (ahora - nacio > VIDA || ahora < nacio) {
            evento.setCanceled(true);
        } else if (e instanceof LocomotoraEntity) {
            ACTIVOS.add(e.getUUID());
        }
    }

    // ================================================================= los trenes que andan
    private static double distanciaAlMasCercano(ServerLevel nivel, Entity e) {
        double mejor = Double.MAX_VALUE;
        for (ServerPlayer j : nivel.players()) {
            double dx = j.getX() - e.getX();
            double dz = j.getZ() - e.getZ();
            mejor = Math.min(mejor, Math.sqrt(dx * dx + dz * dz));
        }
        return mejor;
    }

    private static boolean hayTrenCerca(ServerLevel nivel, ServerPlayer jugador) {
        for (UUID id : ACTIVOS) {
            Entity e = nivel.getEntity(id);
            if (e != null && e.distanceToSqr(jugador) < 220.0 * 220.0) {
                return true;
            }
        }
        return false;
    }

    private static void administrar(ServerLevel nivel, long ahora) {
        Iterator<UUID> it = ACTIVOS.iterator();
        while (it.hasNext()) {
            UUID id = it.next();
            Entity e = nivel.getEntity(id);
            if (!(e instanceof LocomotoraEntity loco) || loco.isRemoved() || !loco.getPersistentData().contains(MARCA)) {
                it.remove();
                QUIETOS.remove(id);
                continue;
            }
            if (loco.getFirstPassenger() instanceof Player) {
                // alguien se subió: el tren es suyo
                liberar(nivel, loco);
                it.remove();
                QUIETOS.remove(id);
                continue;
            }
            if (llevaPasajeros(nivel, loco)) {
                // alguien va sentado en un coche: el tren sigue viaje (y no se borra mientras vaya gente)
                loco.getPersistentData().putLong(MARCA, ahora);
                QUIETOS.remove(id);
                continue;
            }
            long nacio = loco.getPersistentData().getLong(MARCA);
            double cerca = distanciaAlMasCercano(nivel, loco);
            int quieto = 0;
            if (loco.getDeltaMovement().horizontalDistance() < 0.01) {
                quieto = QUIETOS.merge(id, 20, Integer::sum);
            } else {
                QUIETOS.remove(id);
            }
            if (ahora - nacio > VIDA || cerca > LEJOS || quieto > 200) {
                quitar(nivel, loco);
                it.remove();
                QUIETOS.remove(id);
                continue;
            }
            if (cerca < 56.0 && !loco.getPersistentData().getBoolean(SILBO)) {
                loco.silbar();
                loco.getPersistentData().putBoolean(SILBO, true);
            } else if (alguienEnLaVia(nivel, loco)) {
                // ¡cuidado, que no frena! (silbar() no repite antes de dos segundos y medio)
                loco.silbar();
            }
        }
    }

    /** ¿Hay alguien parado sobre la vía delante del tren, a menos de 40 bloques? (en línea recta: es para avisar) */
    private static boolean alguienEnLaVia(ServerLevel nivel, LocomotoraEntity loco) {
        Vec3 m = loco.getDeltaMovement();
        double v = Math.sqrt(m.x * m.x + m.z * m.z);
        if (v < 0.05) {
            return false;
        }
        double ux = m.x / v;
        double uz = m.z / v;
        for (ServerPlayer j : nivel.players()) {
            if (j.isSpectator() || j.getRootVehicle() instanceof VehiculoDeVia) {
                continue;
            }
            double dx = j.getX() - loco.getX();
            double dz = j.getZ() - loco.getZ();
            double adelante = dx * ux + dz * uz;
            double costado = Math.abs(-dx * uz + dz * ux);
            if (adelante > 0.0 && adelante < 40.0 && costado < 2.0 && Math.abs(j.getY() - loco.getY()) < 3.0) {
                return true;
            }
        }
        return false;
    }

    private static List<VagonEntity> vagones(ServerLevel nivel, LocomotoraEntity loco) {
        return nivel.getEntitiesOfClass(VagonEntity.class, loco.getBoundingBox().inflate(64.0, 16.0, 64.0),
                w -> w.getPersistentData().hasUUID(TREN) && loco.getUUID().equals(w.getPersistentData().getUUID(TREN)));
    }

    /** ¿Va algún jugador sentado en los coches de este tren? */
    private static boolean llevaPasajeros(ServerLevel nivel, LocomotoraEntity loco) {
        for (VagonEntity w : vagones(nivel, loco)) {
            for (Entity p : w.getPassengers()) {
                if (p instanceof Player) {
                    w.getPersistentData().putLong(MARCA, nivel.getGameTime());
                    return true;
                }
            }
        }
        return false;
    }

    private static void quitar(ServerLevel nivel, LocomotoraEntity loco) {
        for (VagonEntity w : vagones(nivel, loco)) {
            w.discard();
        }
        loco.discard();
    }

    private static void liberar(ServerLevel nivel, LocomotoraEntity loco) {
        for (VagonEntity w : vagones(nivel, loco)) {
            w.getPersistentData().remove(MARCA);
            w.getPersistentData().remove(TREN);
        }
        loco.getPersistentData().remove(MARCA);
        loco.getPersistentData().remove(SILBO);
    }

    // ================================================================= hacer aparecer uno
    /** Las celdas de la línea (x, y, z, clase) de oeste a este cerca de la región rx, o null si falta calcularla. */
    private static List<int[]> linea(Red red, int rx, int rz) {
        List<int[]> celdas = new ArrayList<>();
        for (int k = rx - 1; k <= rx + 2; k++) {
            Red.Nodo n = red.nodoSiEsta(k, rz);
            if (n == null) {
                pedir(red, k, rz);
                return null;
            }
            if (n.medio > 0) {
                for (int x = n.x - n.medio; x <= n.x + n.medio; x++) {
                    celdas.add(new int[]{x, n.y, n.z, Red.EO});
                }
            }
            if (k == rx + 2) {
                break;
            }
            Red.Tramo t = red.tramoSiEsta(k, rz);
            if (t == null) {
                pedir(red, k, rz);
                return null;
            }
            for (int i = 0; i < t.n; i++) {
                celdas.add(new int[]{t.cx[i], t.cy[i], t.cz[i], t.clase[i]});
            }
        }
        return celdas;
    }

    /** Calcula el tramo en otro hilo (la primera vez puede tardar): el juego no se frena. */
    private static void pedir(Red red, int rx, int rz) {
        long clave = ((long) rx << 32) | (rz & 0xFFFFFFFFL);
        if (PEDIDOS.add(clave)) {
            Util.backgroundExecutor().execute(() -> {
                try {
                    red.tramo(rx, rz);
                } catch (RuntimeException ignorada) {
                    // si falla, se vuelve a intentar más tarde
                } finally {
                    PEDIDOS.remove(clave);
                }
            });
        }
    }

    private static boolean intentar(ServerLevel nivel, ServerPlayer jugador, long ahora) {
        Red red = Redes.de(nivel);
        int px = (int) Math.floor(jugador.getX());
        int pz = (int) Math.floor(jugador.getZ());
        int rz = Math.floorDiv(pz, Red.REGION);
        int enFila = pz - rz * Red.REGION;
        if (enFila < Red.BANDA0 - 96 || enFila > Red.BANDA1 + 96) {
            return false;
        }
        List<int[]> c = linea(red, Math.floorDiv(px, Red.REGION), rz);
        if (c == null || c.isEmpty()) {
            return false;
        }
        int ip = -1;
        double mejor = Double.MAX_VALUE;
        for (int i = 0; i < c.size(); i++) {
            int[] q = c.get(i);
            double dx = q[0] + 0.5 - jugador.getX();
            double dz = q[2] + 0.5 - jugador.getZ();
            double dy = q[1] - jugador.getY();
            double d = dx * dx + dz * dz + dy * dy * 0.25;
            if (d < mejor) {
                mejor = d;
                ip = i;
            }
        }
        if (ip < 0 || mejor > 80.0 * 80.0) {
            return false;
        }
        // el tren: cualquier locomotora (menos las abandonadas); si tiene coches de pasajeros, casi siempre los lleva
        // (de 2 a 4); si no, de 0 a 4 vagones de carga
        RandomSource azar = nivel.getRandom();
        List<TipoLocomotora> sirven = new ArrayList<>();
        for (TipoLocomotora t : TipoLocomotora.values()) {
            if (!t.id().contains("abandonad")) {
                sirven.add(t);
            }
        }
        TipoLocomotora tipo = sirven.get(azar.nextInt(sirven.size()));
        TipoVagon[] vagones = armarTren(tipo, azar);
        double largoAtras = tipo.largoAtras();
        for (TipoVagon v : vagones) {
            largoAtras += v.largoFrente() + v.largoAtras() + Enganches.HUECO;
        }
        int atras = (int) Math.ceil(largoAtras) + 2;
        int adelante = (int) Math.ceil(tipo.largoFrente()) + 2;
        // le toca venir del otro lado que el anterior; si por ahí no se puede, al rato viene igual por el mismo lado
        UUID quien = jugador.getUUID();
        Integer anterior = LADO.get(quien);
        int lado0 = anterior != null ? -anterior : (azar.nextBoolean() ? 1 : -1);
        Long esperando = ESPERANDO.get(quien);
        if (esperando == null || ahora - esperando > 4 * ESPERA_DEL_OTRO_LADO) {
            // (una espera vieja, de cuando el jugador se fue lejos de la vía, no cuenta)
            esperando = ahora;
            ESPERANDO.put(quien, ahora);
        }
        int[] lados = anterior == null || ahora - esperando >= ESPERA_DEL_OTRO_LADO ? new int[]{lado0, -lado0}
                : new int[]{lado0};
        for (int lado : lados) {
            for (int k = 100; k >= 64; k -= 6) {
                int is = ip + lado * k;
                int dir = -lado;
                int a = Math.min(is - dir * atras, is + dir * adelante);
                int b = Math.max(is - dir * atras, is + dir * adelante);
                if (a < 0 || b >= c.size() || !recto(c, a, b) || !hayVia(nivel, c, a, b, true)
                        || !hayVia(nivel, c, Math.min(is, ip), Math.max(is, ip), false)
                        || hayVehiculos(nivel, c, Math.max(0, Math.min(a, ip) - 20), Math.min(c.size() - 1, Math.max(b, ip) + 20))) {
                    continue;
                }
                poner(nivel, c, is, dir, tipo, vagones, ahora);
                LADO.put(quien, lado);
                ESPERANDO.remove(quien);
                return true;
            }
        }
        return false;
    }

    /** Los coches de pasajeros de cada locomotora (el último de la lista va al final del tren), o null. */
    @Nullable
    private static TipoVagon[] cochesDe(TipoLocomotora t) {
        return switch (t) {
            case ROCKET, ADLER, LOCOMOTION, COPPERNOB, BEST_FRIEND, PORTENA -> new TipoVagon[]{TipoVagon.DILIGENCIA};
            case JUPITER, JOHN_BULL -> new TipoVagon[]{TipoVagon.OESTE};
            case SCOTSMAN, MALLARD, MERCHANT, BR9F, PANNIER -> new TipoVagon[]{TipoVagon.TECA};
            case BR01, V200, V160, CC72000, P36 -> new TipoVagon[]{TipoVagon.CAMA};
            case GS4, T1, NWJ -> new TipoVagon[]{TipoVagon.DAYLIGHT};
            case HIAWATHA -> new TipoVagon[]{TipoVagon.DAYLIGHT, TipoVagon.MIRADOR};
            case F7, ZEPHYR -> new TipoVagon[]{TipoVagon.DOMO};
            case WDM2 -> new TipoVagon[]{TipoVagon.INDIO};
            case DD51, D51, DF200 -> new TipoVagon[]{TipoVagon.TREN_AZUL};
            case HST, DELTIC -> new TipoVagon[]{TipoVagon.MK3};
            case P42 -> new TipoVagon[]{TipoVagon.DOS_PISOS};
            default -> null;
        };
    }

    private static TipoVagon[] armarTren(TipoLocomotora tipo, RandomSource azar) {
        TipoVagon[] coches = cochesDe(tipo);
        if (coches != null && azar.nextFloat() < 0.75F) {
            TipoVagon[] tren = new TipoVagon[2 + azar.nextInt(3)];
            for (int i = 0; i < tren.length; i++) {
                tren[i] = coches[0];
            }
            tren[tren.length - 1] = coches[coches.length - 1];
            return tren;
        }
        List<TipoVagon> carga = new ArrayList<>();
        for (TipoVagon v : TipoVagon.values()) {
            if (!v.esCoche()) {
                carga.add(v);
            }
        }
        TipoVagon[] tren = new TipoVagon[azar.nextInt(5)];
        for (int i = 0; i < tren.length; i++) {
            tren[i] = carga.get(azar.nextInt(carga.size()));
        }
        return tren;
    }

    /** ¿Las celdas de a hasta b van en línea recta, planas y seguidas? */
    private static boolean recto(List<int[]> c, int a, int b) {
        int[] p = c.get(a);
        boolean eo = c.get(b)[2] == p[2];
        for (int i = a; i <= b; i++) {
            int[] q = c.get(i);
            if (q[3] == Red.CURVA || q[1] != p[1] || (eo ? q[2] != p[2] : q[0] != p[0])) {
                return false;
            }
            if (i > a) {
                int[] r = c.get(i - 1);
                if (Math.abs(q[0] - r[0]) + Math.abs(q[2] - r[2]) != 1) {
                    return false;
                }
            }
        }
        return true;
    }

    /** ¿Están puestos los rieles? (de a una celda donde va a aparecer el tren; de a tres en el camino hasta el jugador) */
    private static boolean hayVia(ServerLevel nivel, List<int[]> c, int a, int b, boolean todas) {
        for (int i = a; i <= b; i += todas ? 1 : 3) {
            int[] q = c.get(i);
            BlockPos p = new BlockPos(q[0], q[1], q[2]);
            if (todas ? !nivel.isPositionEntityTicking(p) : !nivel.isLoaded(p)) {
                return false;
            }
            if (!(nivel.getBlockState(p).getBlock() instanceof ViaBlock)) {
                return false;
            }
        }
        return true;
    }

    /** ¿Hay alguna vagoneta, locomotora o vagón sobre la vía entre las celdas a y b? (no se choca con trenes de nadie) */
    private static boolean hayVehiculos(ServerLevel nivel, List<int[]> c, int a, int b) {
        for (int i = a; i <= b; i += 16) {
            int j = Math.min(b, i + 16);
            int[] p = c.get(i);
            int[] q = c.get(j);
            AABB caja = new AABB(Math.min(p[0], q[0]) - 1, Math.min(p[1], q[1]) - 1, Math.min(p[2], q[2]) - 1,
                    Math.max(p[0], q[0]) + 2, Math.max(p[1], q[1]) + 3, Math.max(p[2], q[2]) + 2);
            if (!nivel.getEntitiesOfClass(AbstractMinecart.class, caja, e -> true).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    private static void poner(ServerLevel nivel, List<int[]> c, int is, int dir, TipoLocomotora tipo, TipoVagon[] vagones,
                              long ahora) {
        int[] celda = c.get(is);
        int[] sig = c.get(is + dir);
        double fx = sig[0] - celda[0];
        double fz = sig[2] - celda[2];
        float rumbo = (float) Math.toDegrees(Math.atan2(fz, fx));
        double x = celda[0] + 0.5;
        double y = celda[1] + 0.0625;
        double z = celda[2] + 0.5;
        LocomotoraEntity loco = ModEntidades.porTipo(tipo).get().create(nivel);
        if (loco == null) {
            return;
        }
        loco.moveTo(x, y, z, 0.0F, 0.0F);
        loco.setRumbo(rumbo);
        loco.ponerCombustible(LocomotoraEntity.COMBUSTIBLE_MAXIMO);
        loco.ponerMarcha(LocomotoraEntity.MARCHA_MAXIMA);
        loco.getPersistentData().putLong(MARCA, ahora);
        nivel.addFreshEntity(loco);
        AbstractMinecart lider = loco;
        double largoLider = tipo.largoAtras();
        double d = 0.0;
        for (TipoVagon tv : vagones) {
            d += largoLider + tv.largoFrente() + Enganches.HUECO;
            VagonEntity w = ModEntidades.porTipo(tv).get().create(nivel);
            if (w == null) {
                break;
            }
            w.moveTo(x - fx * d, y, z - fz * d, 0.0F, 0.0F);
            w.setRumbo(rumbo);
            w.getPersistentData().putLong(MARCA, ahora);
            w.getPersistentData().putUUID(TREN, loco.getUUID());
            nivel.addFreshEntity(w);
            w.engancharA(new Enganches.Propuesta(lider, false, true, 0.0));
            lider = w;
            largoLider = tv.largoAtras();
        }
        ACTIVOS.add(loco.getUUID());
    }
}
