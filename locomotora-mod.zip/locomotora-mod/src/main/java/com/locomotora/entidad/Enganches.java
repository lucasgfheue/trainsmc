package com.locomotora.entidad;

import java.util.List;

import org.jetbrains.annotations.Nullable;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Enganches entre locomotoras y vagones.
 * <p>
 * Cada vagón enganchado guarda quién es su líder (la locomotora o el vagón al que está enganchado) y en qué punta.
 * En cada tick avanza lo mismo que va a avanzar su líder en ese tick, más una pequeña corrección para quedar a la
 * distancia justa medida siguiendo la vía. Así el tren entero sigue a la locomotora, tirando o empujando, sin
 * estirarse ni encogerse en las curvas, y sin importar en qué orden mueva el juego a cada uno.
 */
public final class Enganches {
    /** Espacio entre los enganches de dos vehículos enganchados (bloques). */
    public static final double HUECO = 0.06;
    /** Hasta cuántos bloques de hueco entre las puntas se puede enganchar algo. */
    public static final double ALCANCE = 1.6;
    /** Cuánto se pueden encimar las puntas al enganchar (por ejemplo, dos vagones que se chocaron). */
    public static final double ENCIMADO = 0.75;
    /** Si un vagón queda más lejos que esto de donde debería (el líder se descarriló o quedó en un chunk sin cargar), se suelta. */
    public static final double CORTE = 6.0;
    /** Corrección máxima por tick para llegar a la distancia justa (bloques). */
    static final double CORRECCION = 0.25;
    /** Tope de vagones seguidos que se recorren buscando al líder (protege de círculos). */
    static final int PROFUNDIDAD_MAXIMA = 64;
    /** El medio largo más grande de todos los vehículos (el ténder de la Big Boy) y de los vagones. */
    private static final double LARGO_MAXIMO;
    private static final double LARGO_MAXIMO_VAGON;

    static {
        double vagon = 0.0;
        for (TipoVagon tipo : TipoVagon.values()) {
            vagon = Math.max(vagon, Math.max(tipo.largoFrente(), tipo.largoAtras()));
        }
        double maximo = vagon;
        for (TipoLocomotora tipo : TipoLocomotora.values()) {
            maximo = Math.max(maximo, Math.max(tipo.largoFrente(), tipo.largoAtras()));
        }
        LARGO_MAXIMO = maximo;
        LARGO_MAXIMO_VAGON = vagon;
    }

    /** Un vehículo encontrado sobre la vía, a la distancia {@code s} (con signo: positiva hacia el frente). */
    record EnLaVia(AbstractMinecart vehiculo, double s) {
    }

    /** Un enganche posible: a qué líder, en qué punta de él, con qué punta propia y cuánto hueco queda. */
    public record Propuesta(AbstractMinecart lider, boolean alFrenteDelLider, boolean liderPorMiFrente, double hueco) {
    }

    private Enganches() {
    }

    // ================================================================= medidas

    static double largo(VehiculoDeVia v, boolean frente) {
        return frente ? v.largoFrente() : v.largoAtras();
    }

    /** Medio largo de {@code v} (con el enganche) del lado que mira al punto (x, z), en línea recta. */
    static double largoHacia(AbstractMinecart v, double x, double z) {
        if (v instanceof VehiculoDeVia vv) {
            return largo(vv, (x - v.getX()) * vv.frenteX() + (z - v.getZ()) * vv.frenteZ() >= 0.0);
        }
        return 0.5; // una vagoneta común
    }

    /** ¿{@code a} y {@code b} están enganchados uno con el otro (en cualquier sentido)? */
    public static boolean enganchados(Entity a, Entity b) {
        return (a instanceof VagonEntity va && va.siguiendoA(b)) || (b instanceof VagonEntity vb && vb.siguiendoA(a));
    }

    /** Rumbo (en grados) para mirar hacia (dx, dz), alineado con el riel si es recto. */
    public static float rumboSegunDireccion(double dx, double dz, @Nullable RailShape forma) {
        if (forma == RailShape.NORTH_SOUTH || forma == RailShape.ASCENDING_NORTH || forma == RailShape.ASCENDING_SOUTH) {
            return dz >= 0.0 ? 90.0F : -90.0F;
        }
        if (forma == RailShape.EAST_WEST || forma == RailShape.ASCENDING_EAST || forma == RailShape.ASCENDING_WEST) {
            return dx >= 0.0 ? 0.0F : 180.0F;
        }
        if (Math.abs(dx) >= Math.abs(dz)) {
            return dx >= 0.0 ? 0.0F : 180.0F;
        }
        return dz >= 0.0 ? 90.0F : -90.0F;
    }

    // ================================================================= movimiento del tren

    /**
     * Cuánto se va a mover {@code v} en esta vuelta del servidor: nada si ya se movió (o si su chunk está dormido y no
     * se mueve); si es un vagón enganchado, lo que planea avanzar; si no, lo que le da su velocidad.
     */
    static Vec3 movimientoPrevisto(AbstractMinecart v, int profundidad) {
        if (v instanceof VehiculoDeVia vv) {
            long ahora = v.level().getGameTime();
            long ultimo = vv.ultimoTick();
            if (ultimo == ahora || ultimo < ahora - 1L) {
                return Vec3.ZERO;
            }
        }
        Vec3 m = v instanceof VagonEntity w && w.estaEnganchado() && profundidad < PROFUNDIDAD_MAXIMA
                ? w.planDeLaVuelta(profundidad + 1)
                : v.getDeltaMovement();
        // Con pasajero el juego la mueve un 25% menos, y nunca más rápido que el tope del riel
        double f = v.isVehicle() ? 0.75 : 1.0;
        double tope = v.getMaxSpeedWithRail();
        return new Vec3(Mth.clamp(m.x * f, -tope, tope), 0.0, Mth.clamp(m.z * f, -tope, tope));
    }

    // ================================================================= buscar sobre la vía

    /**
     * El vehículo (locomotora o vagón) más cercano sobre la vía a cada lado de {@code v}, hasta {@code largo} bloques:
     * [0] = hacia su frente, [1] = hacia atrás.
     */
    static EnLaVia[] vecinosEnLaVia(AbstractMinecart v, VehiculoDeVia vv, double largo) {
        Via via = Via.alrededor(v.level(), v.getX(), v.getY(), v.getZ(), vv.frenteX(), vv.frenteZ(), largo, largo);
        EnLaVia[] cercanos = new EnLaVia[2];
        double[] lejos = new double[1];
        AABB zona = v.getBoundingBox().inflate(largo, 2.0, largo);
        for (AbstractMinecart otro : v.level().getEntitiesOfClass(AbstractMinecart.class, zona,
                o -> o != v && o instanceof VehiculoDeVia && o.isAlive())) {
            double s = via.proyectar(otro.getX(), otro.getY(), otro.getZ(), lejos);
            if (lejos[0] > 0.6 || Math.abs(s) > largo) {
                continue; // en otra vía
            }
            int lado = s >= 0.0 ? 0 : 1;
            if (cercanos[lado] == null || Math.abs(s) < Math.abs(cercanos[lado].s())) {
                cercanos[lado] = new EnLaVia(otro, s);
            }
        }
        return cercanos;
    }

    /** ¿{@code e} queda del lado del frente de {@code c}, siguiendo la vía? */
    static boolean alFrenteDe(AbstractMinecart c, VehiculoDeVia cv, Entity e) {
        double dx = e.getX() - c.getX();
        double dz = e.getZ() - c.getZ();
        boolean enRecta = dx * cv.frenteX() + dz * cv.frenteZ() >= 0.0;
        double largo = Math.sqrt(dx * dx + dz * dz) * 1.6 + 2.0;
        Via via = Via.alrededor(c.level(), c.getX(), c.getY(), c.getZ(), cv.frenteX(), cv.frenteZ(), largo, largo);
        double[] lejos = new double[1];
        double s = via.proyectar(e.getX(), e.getY(), e.getZ(), lejos);
        return lejos[0] > 1.0 ? enRecta : s >= 0.0;
    }

    /** Los vagones enganchados a {@code v} (detrás o delante). */
    static List<VagonEntity> seguidores(AbstractMinecart v) {
        double propio = v instanceof VehiculoDeVia vv ? Math.max(vv.largoFrente(), vv.largoAtras()) : 0.5;
        double r = propio + LARGO_MAXIMO_VAGON + CORTE + 2.0;
        return v.level().getEntitiesOfClass(VagonEntity.class, v.getBoundingBox().inflate(r, 4.0, r),
                w -> w.siguiendoA(v));
    }

    /** Suelta a todos los vagones enganchados a {@code v} (por ejemplo, porque lo rompieron). */
    public static void soltarSeguidores(AbstractMinecart v) {
        for (VagonEntity w : seguidores(v)) {
            w.soltar();
        }
    }

    /** ¿Está libre la punta (frente o cola) de {@code c} para enganchar algo, sin contar a {@code ignorar}? */
    static boolean puntaLibre(AbstractMinecart c, boolean frente, @Nullable Entity ignorar) {
        if (c instanceof VagonEntity w && w.estaEnganchado() && w.liderPorMiFrente() == frente) {
            return false;
        }
        for (VagonEntity s : seguidores(c)) {
            if (s != ignorar && s.alFrenteDelLider() == frente) {
                return false;
            }
        }
        return true;
    }

    /** ¿Si {@code w} siguiera a {@code lider} se cerraría un círculo (el líder, o el líder de su líder…, es {@code w})? */
    static boolean haceCirculo(VagonEntity w, AbstractMinecart lider) {
        AbstractMinecart e = lider;
        for (int i = 0; i < PROFUNDIDAD_MAXIMA && e != null; i++) {
            if (e == w) {
                return true;
            }
            e = e instanceof VagonEntity v ? v.getLider() : null;
        }
        return false;
    }

    // ================================================================= enganchar

    /** El mejor líder para {@code w}: la locomotora o el vagón más cercano sobre la vía que tenga esa punta libre. */
    @Nullable
    public static Propuesta buscarLiderPara(VagonEntity w) {
        double largo = Math.max(w.largoFrente(), w.largoAtras()) + LARGO_MAXIMO + ALCANCE + 1.0;
        EnLaVia[] cercanos = vecinosEnLaVia(w, w, largo);
        Propuesta mejor = null;
        double mejorPuntaje = Double.MAX_VALUE;
        for (int lado = 0; lado < 2; lado++) {
            EnLaVia e = cercanos[lado];
            if (e == null || !(e.vehiculo() instanceof VehiculoDeVia cv)) {
                continue;
            }
            AbstractMinecart c = e.vehiculo();
            boolean porMiFrente = lado == 0;
            if (!puntaLibre(w, porMiFrente, null) || haceCirculo(w, c)) {
                continue;
            }
            boolean alFrente = alFrenteDe(c, cv, w);
            double hueco = Math.abs(e.s()) - (largo(w, porMiFrente) + largo(cv, alFrente) + HUECO);
            if (hueco < -ENCIMADO || hueco > ALCANCE || !puntaLibre(c, alFrente, w)) {
                continue;
            }
            // Entre dos posibles gana el más cercano; si están casi igual, mejor una locomotora
            double puntaje = Math.abs(hueco) - (c instanceof LocomotoraEntity ? 0.25 : 0.0);
            if (puntaje < mejorPuntaje) {
                mejorPuntaje = puntaje;
                mejor = new Propuesta(c, alFrente, porMiFrente, hueco);
            }
        }
        return mejor;
    }

    /**
     * Engancha a {@code v} los vagones sueltos que estén pegados a sus puntas libres (por ejemplo, al poner una
     * locomotora delante de unos vagones). Devuelve cuántos enganchó.
     */
    public static int engancharVecinos(AbstractMinecart v) {
        if (!(v instanceof VehiculoDeVia vv)) {
            return 0;
        }
        double largo = Math.max(vv.largoFrente(), vv.largoAtras()) + LARGO_MAXIMO_VAGON + ALCANCE + 1.0;
        EnLaVia[] cercanos = vecinosEnLaVia(v, vv, largo);
        int enganchados = 0;
        for (int lado = 0; lado < 2; lado++) {
            EnLaVia e = cercanos[lado];
            if (e == null || !(e.vehiculo() instanceof VagonEntity c) || c.estaEnganchado()) {
                continue;
            }
            boolean frenteDeV = lado == 0;
            boolean suFrente = alFrenteDe(c, c, v);
            double hueco = Math.abs(e.s()) - (largo(vv, frenteDeV) + largo(c, suFrente) + HUECO);
            if (hueco < -ENCIMADO || hueco > ALCANCE || !puntaLibre(v, frenteDeV, null)
                    || !puntaLibre(c, suFrente, null) || haceCirculo(c, v)) {
                continue;
            }
            c.engancharA(new Propuesta(v, frenteDeV, suFrente, hueco));
            enganchados++;
        }
        return enganchados;
    }

    /**
     * Engancha un vagón recién puesto en la vía: a la locomotora o al vagón que tenga al lado y, del otro lado, a los
     * vagones sueltos que estén esperando. Devuelve el aviso para el jugador (o null si no enganchó nada).
     */
    @Nullable
    public static Component engancharAlColocar(VagonEntity w) {
        Propuesta p = buscarLiderPara(w);
        if (p != null) {
            w.engancharA(p);
        }
        int otros = engancharVecinos(w);
        if (p != null) {
            return Component.translatable("mensaje.locomotora.enganchado", p.lider().getDisplayName())
                    .withStyle(ChatFormatting.GREEN);
        }
        if (otros > 0) {
            return Component.translatable("mensaje.locomotora.vagones_enganchados", otros).withStyle(ChatFormatting.GREEN);
        }
        return null;
    }

    // ================================================================= topes

    /**
     * La caja de choque de una vagoneta es chica pero los modelos son largos: las vagonetas sueltas que quedan
     * delante o detrás de {@code yo} se empujan para que no se metan dentro del modelo (las enganchadas ya van a la
     * distancia justa).
     */
    static void empujarVecinos(AbstractMinecart yo, VehiculoDeVia v) {
        double fx = v.frenteX();
        double fz = v.frenteZ();
        double alcance = Math.max(v.largoFrente(), v.largoAtras()) + 3.5;
        AABB zona = yo.getBoundingBox().inflate(alcance, 0.5, alcance);
        Vec3 miVelocidad = yo.getDeltaMovement();
        double miAvance = miVelocidad.x * fx + miVelocidad.z * fz;

        for (AbstractMinecart otra : yo.level().getEntitiesOfClass(AbstractMinecart.class, zona,
                o -> o != yo && !yo.hasPassenger(o))) {
            if (enganchados(yo, otra)) {
                continue;
            }
            double dx = otra.getX() - yo.getX();
            double dz = otra.getZ() - yo.getZ();
            double adelante = dx * fx + dz * fz;
            double lateral = Math.abs(-dx * fz + dz * fx);
            if (lateral > 0.8) {
                continue;
            }
            boolean estaDelante = adelante >= 0.0;
            double separacionMinima = largo(v, estaDelante) + largoHacia(otra, yo.getX(), yo.getZ());
            double separacion = Math.abs(adelante);
            if (separacion >= separacionMinima) {
                continue;
            }
            double signo = estaDelante ? 1.0 : -1.0;
            Vec3 suVelocidad = otra.getDeltaMovement();
            double suAvance = suVelocidad.x * fx + suVelocidad.z * fz;
            // La otra vagoneta tiene que alejarse al menos tan rápido como nos acercamos
            double objetivo = miAvance + signo * Math.min(0.05, (separacionMinima - separacion) * 0.25);
            if (signo * (objetivo - suAvance) > 0.0) {
                double cambio = objetivo - suAvance;
                otra.setDeltaMovement(suVelocidad.x + fx * cambio, suVelocidad.y, suVelocidad.z + fz * cambio);
            }
            // Si la otra no se puede mover (está trabada), no la atravesamos
            if (separacion < separacionMinima - 0.3 && signo * (miAvance - suAvance) > 0.0) {
                double correccion = suAvance - miAvance;
                yo.setDeltaMovement(miVelocidad.x + fx * correccion, miVelocidad.y, miVelocidad.z + fz * correccion);
                miVelocidad = yo.getDeltaMovement();
                miAvance = suAvance;
            }
        }
    }
}
