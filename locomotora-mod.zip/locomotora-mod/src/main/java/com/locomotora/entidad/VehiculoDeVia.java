package com.locomotora.entidad;

/**
 * Lo que tienen en común las locomotoras y los vagones: van por la vía mirando siempre hacia un mismo frente (que
 * sigue las curvas pero nunca se da vuelta solo) y se pueden enganchar entre sí.
 */
public interface VehiculoDeVia {

    /** Hacia dónde mira el frente, en grados: el frente es (cos, sin) en (x, z). */
    float getRumbo();

    double frenteX();

    double frenteZ();

    /** Medio largo del modelo hacia el frente, en bloques, contando el enganche. */
    double largoFrente();

    /** Medio largo del modelo hacia atrás, en bloques, contando el enganche (con el ténder si tiene). */
    double largoAtras();

    /** Distancia recorrida (en bloques, interpolada) para girar las ruedas y mover las bielas. */
    double getRecorrido(float tickParcial);

    /** Tiempo de juego del último tick del servidor en que se movió (para saber si ya se movió en esta vuelta). */
    long ultimoTick();

    /** La marcha puesta, para la palanca de la cabina (los vagones no tienen). */
    default int marchaCabina() {
        return 0;
    }

    /** Qué tan rápido va, de 0 a 1 (a toda máquina), para la aguja del velocímetro de la cabina. */
    default float velocidadCabina(float tickParcial) {
        return 0.0F;
    }

    /** Cuánto está girada la torreta (tren artillero), en radianes: positivo hacia la derecha del frente. */
    default float giroTorreta(float tickParcial) {
        return 0.0F;
    }

    /** Cuánto está levantado el cañón de la torreta, en radianes. */
    default float alzaTorreta(float tickParcial) {
        return 0.0F;
    }
}
