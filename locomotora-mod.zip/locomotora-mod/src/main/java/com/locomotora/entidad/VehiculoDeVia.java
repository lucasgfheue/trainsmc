package com.locomotora.entidad;

/**
 * Lo que tienen en común las locomotoras y los vagones: van por la vía mirando siempre hacia un mismo frente (que
 * sigue las curvas pero nunca se da vuelta solo) y se pueden enganchar entre sí.
 */
public interface VehiculoDeVia {

    /** Hacia dónde mira el frente, en grados: el frente es (cos, sin) en (x, z). */
    float getRumbo();

    double frenteX();

    double frenteZ();

    /** Medio largo del modelo hacia el frente, en bloques, contando el enganche. */
    double largoFrente();

    /** Medio largo del modelo hacia atrás, en bloques, contando el enganche (con el ténder si tiene). */
    double largoAtras();

    /** Distancia recorrida (en bloques, interpolada) para girar las ruedas y mover las bielas. */
    double getRecorrido(float tickParcial);

    /** Tiempo de juego del último tick del servidor en que se movió (para saber si ya se movió en esta vuelta). */
    long ultimoTick();
}
