package com.locomotora.entidad;

import java.util.HashMap;
import java.util.Map;

/**
 * Asientos de las cabinas de las locomotoras (generado por el estudio de diseño junto con los modelos): para cada
 * una, {x, z del modelo, altura de la cadera sobre el riel} en 1/16 de bloque. El frente del modelo está hacia -x y
 * la z va hacia la derecha del maquinista. El primer asiento es el del maquinista (el que maneja).
 */
public final class AsientosCabina {
    private static final Map<String, float[][]> A = new HashMap<>();

    static {
        A.put("adler", new float[][]{{19.5F, -3.5F, 13.0F}, {19.5F, 3.5F, 13.0F}});
        A.put("artillero", new float[][]{{-8.0F, 0.0F, 27.2F}, {28.0F, -5.0F, 34.0F}, {28.0F, 5.0F, 34.0F}});
        A.put("best_friend", new float[][]{{-11.5F, 4.0F, 14.5F}, {-11.5F, -4.0F, 14.5F}, {17.2F, 0.0F, 15.0F}});
        A.put("bigboy", new float[][]{{100.0F, 5.5F, 21.0F}, {92.0F, 5.5F, 21.0F}, {100.0F, -5.5F, 21.0F}, {92.0F, -5.5F, 21.0F}});
        A.put("br01", new float[][]{{56.0F, -4.5F, 21.337F}, {56.0F, 4.5F, 21.337F}});
        A.put("br9f", new float[][]{{52.0F, -4.5F, 20.295F}, {52.0F, 4.5F, 20.295F}});
        A.put("cc72000", new float[][]{{-73.0F, -6.5F, 13.4F}, {-73.0F, 6.5F, 13.4F}, {-66.0F, 0.0F, 13.4F}});
        A.put("chme3", new float[][]{{46.0F, -6.5F, 16.58F}, {46.0F, 6.5F, 16.58F}, {53.0F, 0.0F, 16.58F}});
        A.put("class08", new float[][]{{22.0F, -6.5F, 13.4F}, {22.0F, 6.5F, 13.4F}, {29.0F, 0.0F, 13.4F}});
        A.put("coppernob", new float[][]{{19.5F, 3.5F, 14.5F}, {19.5F, -3.5F, 14.5F}});
        A.put("d51", new float[][]{{46.0F, -4.5F, 20.295F}, {46.0F, 4.5F, 20.295F}});
        A.put("dd51", new float[][]{{-2.0F, -6.5F, 13.4F}, {-2.0F, 6.5F, 13.4F}, {5.0F, 0.0F, 13.4F}});
        A.put("deltic", new float[][]{{-73.0F, -6.5F, 12.4F}, {-73.0F, 6.5F, 12.4F}, {-66.0F, 0.0F, 12.4F}});
        A.put("deutz", new float[][]{{11.5F, -2.8F, 5.9F}, {11.5F, 2.8F, 5.9F}});
        A.put("df200", new float[][]{{-70.0F, -6.5F, 14.821F}, {-70.0F, 6.5F, 14.821F}, {-63.0F, 0.0F, 14.821F}});
        A.put("df4", new float[][]{{-75.0F, 6.5F, 15.256F}, {-75.0F, -6.5F, 15.256F}, {-68.0F, 0.0F, 15.256F}});
        A.put("es44", new float[][]{{-72.0F, 6.5F, 20.4F}, {-72.0F, -6.5F, 20.4F}, {-65.0F, 0.0F, 20.4F}});
        A.put("f7", new float[][]{{-38.0F, -8.0F, 17.0F}, {-38.0F, 8.0F, 17.0F}});
        A.put("garratt", new float[][]{{44.0F, 4.5F, 16.0F}, {44.0F, -4.5F, 16.0F}});
        A.put("ge44", new float[][]{{3.0F, 6.5F, 11.58F}, {3.0F, -6.5F, 11.58F}});
        A.put("gs4", new float[][]{{62.0F, 4.5F, 22.377F}, {62.0F, -4.5F, 22.377F}});
        A.put("hamburger", new float[][]{{-101.0F, -6.0F, 11.049F}, {-101.0F, 6.0F, 11.049F}, {-94.0F, 0.0F, 11.049F}});
        A.put("hiawatha", new float[][]{{37.0F, 4.5F, 15.0F}, {37.0F, -4.5F, 15.0F}});
        A.put("hst", new float[][]{{-49.0F, -6.5F, 15.0F}, {-49.0F, 6.5F, 15.0F}, {-42.0F, 0.0F, 15.0F}});
        A.put("john_bull", new float[][]{{17.5F, 3.5F, 13.0F}, {17.5F, -3.5F, 13.0F}});
        A.put("jupiter", new float[][]{{30.0F, 4.5F, 15.0F}, {30.0F, -4.5F, 15.0F}});
        A.put("locomotion", new float[][]{{16.5F, 3.5F, 12.0F}, {16.5F, -3.5F, 12.0F}});
        A.put("mallard", new float[][]{{56.0F, 4.5F, 17.295F}, {56.0F, -4.5F, 17.295F}});
        A.put("merchant", new float[][]{{49.0F, -4.5F, 18.377F}, {55.0F, 0.0F, 18.377F}, {49.0F, 4.5F, 18.377F}});
        A.put("nwj", new float[][]{{47.0F, 4.5F, 24.377F}, {53.0F, 0.0F, 24.377F}, {47.0F, -4.5F, 24.377F}});
        A.put("p36", new float[][]{{51.0F, -4.5F, 23.0F}, {57.0F, 0.0F, 23.0F}, {51.0F, 4.5F, 23.0F}});
        A.put("p42", new float[][]{{-71.0F, 6.0F, 15.27F}, {-71.0F, -6.0F, 15.27F}, {-64.0F, 0.0F, 15.27F}});
        A.put("pannier", new float[][]{{26.0F, 4.5F, 13.413F}, {26.0F, -4.5F, 13.413F}});
        A.put("plymouth", new float[][]{{9.0F, 6.0F, 12.9F}, {9.0F, -6.0F, 12.9F}});
        A.put("portena", new float[][]{{16.0F, 3.5F, 9.887F}, {16.0F, -3.5F, 9.887F}});
        A.put("rocket", new float[][]{{17.5F, 3.5F, 8.0F}, {17.5F, -3.5F, 8.0F}});
        A.put("scotsman", new float[][]{{51.0F, 4.5F, 16.0F}, {57.0F, 0.0F, 16.0F}, {51.0F, -4.5F, 16.0F}});
        A.put("sd40", new float[][]{{-60.0F, 6.5F, 18.4F}, {-60.0F, -6.5F, 18.4F}, {-53.0F, 0.0F, 18.4F}});
        A.put("shay", new float[][]{{12.0F, 3.5F, 12.0F}, {12.0F, -3.5F, 12.0F}});
        A.put("simplex", new float[][]{{10.0F, 4.0F, 13.0F}, {10.0F, -3.0F, 13.0F}});
        A.put("t1", new float[][]{{62.0F, 4.5F, 18.0F}, {68.0F, 0.0F, 18.0F}, {62.0F, -4.5F, 18.0F}});
        A.put("tgm23", new float[][]{{18.0F, -6.5F, 17.26F}, {18.0F, 6.5F, 17.26F}});
        A.put("tunel", new float[][]{{-15.0F, 5.0F, 1.4F}, {-15.0F, -5.0F, 1.4F}});
        A.put("v160", new float[][]{{-49.0F, -6.5F, 13.907F}, {-49.0F, 6.5F, 13.907F}, {-42.0F, 0.0F, 13.907F}});
        A.put("v200", new float[][]{{-59.0F, -6.5F, 13.257F}, {-59.0F, 6.5F, 13.257F}, {-52.0F, 0.0F, 13.257F}});
        A.put("wdm2", new float[][]{{-46.0F, -6.5F, 16.4F}, {-46.0F, 6.5F, 16.4F}});
        A.put("zephyr", new float[][]{{-71.0F, 4.0F, 13.4F}, {-71.0F, -4.0F, 13.4F}, {-64.0F, 0.0F, 13.4F}});
    }

    private AsientosCabina() {
    }

    /** Los asientos de una locomotora, o null si no tiene cabina armada. */
    public static float[][] de(String id) {
        return A.get(id);
    }
}
