package com.locomotora.entidad;

/**
 * Los modelos de locomotora. Las medidas están en bloques y salen del estudio de diseño
 * (adelante = hacia el frente, desde el centro de la locomotora; un valor negativo es hacia atrás).
 */
public enum TipoLocomotora {
    // ---------------------------------------------------------------------------------- trenes reales (estilo Traincraft)
    //         id             diésel  tono   vel.   acel.   asiento        chimenea/escape  cilindros            silbato/bocina  largo
    //                                sonido máx.           atrás  alto    adel.  alto      adel. lado  alto     adel.  alto     frente atrás
    SCOTSMAN( "scotsman",     false,  1.1F,  0.40,  0.011,  3.25,  1.15F,  2.81,  2.40,     1.87, 0.53, 0.60,    -2.31, 2.35,    4.13,  8.75),
    F7(       "f7",           true,   1.0F,  0.40,  0.012, -2.60,  1.30F, -2.38,  2.75,     0.0,  0.0,  0.0,      2.13, 2.75,    4.50,  4.50),
    V200(     "v200",         true,   1.2F,  0.40,  0.014, -3.60,  1.15F,  0.0,   2.50,     0.0,  0.0,  0.0,      4.00, 2.30,    5.25,  5.25),
    // ---------------------------------------------------------------------------------- vapor
    MALLARD(  "mallard",      false,  0.95F,  0.40,   0.012,   3.12,   0.85F,   2.31,   2.27,      1.86,  0.53,  0.59,    -1.94,   2.35,     4.00,   9.12),
    BIG_BOY(  "bigboy",       false,  0.80F,  0.34,   0.010,   5.75,   1.30F,   6.38,   2.96,      5.81,  0.53,  0.47,    -2.62,   2.87,     8.12,   16.12),
    GS4(      "gs4",          false,  0.90F,  0.40,   0.011,   3.62,   1.17F,   3.00,   2.70,      2.59,  0.53,  0.59,    -2.50,   2.54,     5.50,   12.88),
    BR01(     "br01",         false,  1.20F,  0.40,   0.011,   3.25,   1.10F,   2.88,   2.64,      1.93,  0.53,  0.56,    -2.12,   2.42,     4.12,   9.38),
    PANNIER(  "pannier",      false,  1.30F,  0.30,   0.016,   1.38,   0.64F,   2.12,   2.20,      2.00,  0.35,  0.50,    -0.62,   1.98,     3.00,   3.06),
    // ---------------------------------------------------------------------------------- diésel
    HST(      "hst",          true,   1.10F,  0.40,   0.015,  -3.75,   0.82F,  -1.25,   2.39,      0.00,  0.00,  0.00,     4.69,   1.54,     5.06,   5.38),
    DELTIC(   "deltic",       true,   1.05F,  0.40,   0.014,  -4.75,   0.73F,   0.00,   2.33,      0.00,  0.00,  0.00,     5.75,   1.54,     6.10,   6.10),
    SD40(     "sd40",         true,   0.95F,  0.34,   0.012,  -3.88,   1.14F,  -0.19,   2.52,      0.00,  0.00,  0.00,     2.38,   2.55,     6.12,   6.12),
    ES44(     "es44",         true,   0.90F,  0.36,   0.013,  -4.50,   1.23F,   1.00,   2.70,      0.00,  0.00,  0.00,     4.00,   2.86,     6.50,   6.50),
    DD51(     "dd51",         true,   1.25F,  0.36,   0.013,   0.00,   0.87F,   2.50,   2.14,      0.00,  0.00,  0.00,     0.62,   2.23,     5.38,   5.38),
    CLASS08(  "class08",      true,   1.15F,  0.25,   0.018,   1.50,   0.79F,   1.50,   1.96,      0.00,  0.00,  0.00,    -0.75,   2.29,     2.62,   2.62),
    // ---------------------------------------------------------------------------------- vapor (segunda tanda)
    ROCKET(   "rocket",       false,  1.35F,  0.30,   0.014,   1.00,   0.71F,   0.81,   2.58,     -0.55,  0.47,  1.13,     0.06,   1.48,     1.19,   3.25),
    JUPITER(  "jupiter",      false,  1.15F,  0.32,   0.013,   1.62,   0.92F,   2.12,   2.77,      1.90,  0.53,  0.44,    -0.38,   2.23,     3.50,   6.00),
    HIAWATHA( "hiawatha",     false,  1.00F,  0.40,   0.012,   2.00,   0.70F,   2.44,   2.45,      2.80,  0.53,  0.59,     1.25,   2.47,     4.50,   9.06),
    T1(       "t1",           false,  0.95F,  0.40,   0.011,   3.75,   1.11F,   4.56,   2.70,      4.81,  0.53,  0.56,    -2.50,   2.66,     7.12,   13.00),
    NWJ(      "nwj",          false,  0.85F,  0.40,   0.011,   2.88,   1.34F,   3.88,   2.77,      4.06,  0.53,  0.50,    -1.88,   2.66,     6.38,   12.50),
    MERCHANT( "merchant",     false,  1.10F,  0.40,   0.012,   3.00,   0.98F,   2.81,   2.45,      2.56,  0.53,  0.53,    -1.88,   2.40,     4.00,   8.50),
    BR9F(     "br9f",         false,  1.10F,  0.36,   0.012,   3.00,   1.09F,   3.31,   2.70,      3.43,  0.53,  0.44,    -1.62,   2.54,     4.81,   8.00),
    D51(      "d51",          false,  1.25F,  0.36,   0.012,   2.62,   1.09F,   2.94,   2.58,      2.90,  0.53,  0.41,    -0.38,   2.60,     4.38,   8.38),
    P36(      "p36",          false,  0.90F,  0.40,   0.011,   3.12,   1.34F,   4.38,   2.89,      3.81,  0.53,  0.53,    -1.88,   2.79,     5.88,   11.25),
    GARRATT(  "garratt",      false,  0.85F,  0.30,   0.010,   2.62,   1.09F,   2.62,   2.58,      7.62,  0.53,  0.41,    -0.88,   2.48,     9.12,   9.12),
    // ---------------------------------------------------------------------------------- diésel (segunda tanda)
    ZEPHYR(   "zephyr",       true,   1.10F,  0.40,   0.014,  -5.00,   0.55F,   3.75,   2.19,      0.00,  0.00,  0.00,     5.25,   2.19,     6.62,   13.00),
    HAMBURGER("hamburger",    true,   1.25F,  0.40,   0.014,  -6.50,   0.55F,   3.75,   2.12,      0.00,  0.00,  0.00,     6.88,   2.00,     7.62,   7.62),
    V160(     "v160",         true,   1.20F,  0.40,   0.014,  -3.25,   0.80F,   0.00,   2.44,      0.00,  0.00,  0.00,     3.12,   2.38,     4.81,   4.81),
    CC72000(  "cc72000",      true,   1.15F,  0.40,   0.013,  -4.75,   0.75F,  -2.38,   2.56,      0.00,  0.00,  0.00,     4.62,   2.44,     6.06,   6.06),
    CHME3(    "chme3",        true,   1.30F,  0.25,   0.018,   3.00,   0.90F,   0.50,   2.31,      0.00,  0.00,  0.00,    -3.00,   2.50,     5.31,   5.31),
    DF4(      "df4",          true,   1.00F,  0.36,   0.012,  -4.75,   0.80F,   0.00,   2.69,      0.00,  0.00,  0.00,     4.38,   2.56,     6.00,   6.00),
    WDM2(     "wdm2",         true,   1.05F,  0.36,   0.013,  -2.94,   0.90F,   0.25,   2.25,      0.00,  0.00,  0.00,     3.25,   2.41,     5.44,   5.44),
    P42(      "p42",          true,   0.95F,  0.40,   0.015,  -4.75,   0.80F,  -1.25,   2.38,      0.00,  0.00,  0.00,     3.62,   2.41,     6.47,   6.31),
    DF200(    "df200",        true,   1.10F,  0.36,   0.012,  -4.62,   0.80F,   0.00,   2.62,      0.00,  0.00,  0.00,     4.38,   2.50,     5.88,   5.88),
    // ---------------------------------------------------------------------------------- diésel abandonadas
    GP9_ABANDONADA("gp9_abandonada", true,  0.95F,  0.36,   0.012,  -3.25,   1.14F,   0.62,   2.19,      0.00,  0.00,  0.00,     3.25,   2.38,     5.31,   5.31),
    E8_ABANDONADA("e8_abandonada", true,  1.00F,  0.40,   0.012,  -3.56,   1.01F,   0.00,   2.50,      0.00,  0.00,  0.00,     3.44,   2.44,     5.62,   5.81),
    RS3_ABANDONADA("rs3_abandonada", true,  1.10F,  0.30,   0.013,  -3.19,   1.14F,   1.25,   2.12,      0.00,  0.00,  0.00,     3.12,   2.38,     5.19,   5.19),
    RDC_ABANDONADO("rdc_abandonado", true,  1.20F,  0.36,   0.015,  -5.38,   0.82F,   3.75,   2.31,      0.00,  0.00,  0.00,     5.00,   2.31,     6.31,   6.31),
    CLASS37_ABANDONADA("class37_abandonada", true,  1.05F,  0.36,   0.012,  -3.75,   0.95F,   0.00,   2.44,      0.00,  0.00,  0.00,     3.75,   2.38,     5.50,   5.50),
    CLASS20_ABANDONADA("class20_abandonada", true,  1.15F,  0.32,   0.014,   2.81,   1.01F,   1.88,   2.06,      0.00,  0.00,  0.00,    -2.81,   2.25,     5.38,   4.12),
    M62_ABANDONADA("m62_abandonada", true,  0.90F,  0.36,   0.012,  -4.38,   0.95F,   0.00,   2.62,      0.00,  0.00,  0.00,     4.38,   2.50,     5.38,   5.38),
    TEP60_ABANDONADA("tep60_abandonada", true,  1.10F,  0.40,   0.013,  -4.00,   0.95F,   0.00,   2.50,      0.00,  0.00,  0.00,     4.00,   2.50,     5.62,   5.62),
    T478_ABANDONADA("t478_abandonada", true,  1.20F,  0.32,   0.014,  -3.56,   0.95F,   0.00,   2.56,      0.00,  0.00,  0.00,     3.56,   2.44,     4.62,   4.62),
    KIHA40_ABANDONADO("kiha40_abandonado", true,  1.30F,  0.30,   0.015,  -5.38,   0.82F,   0.62,   2.50,      0.00,  0.00,  0.00,     5.25,   2.38,     6.19,   6.19),
    SHARKNOSE_ABANDONADA("sharknose_abandonada", true,  0.95F,  0.36,   0.012,  -2.56,   0.95F,   0.00,   2.38,      0.00,  0.00,  0.00,     2.50,   2.31,     5.00,   5.69),
    // ---------------------------------------------------------------------------------- vapor pequeñas antiguas
    LOCOMOTION("locomotion", false,  1.30F,  0.20,   0.010,   1.06,   0.94F,   0.78,   2.58,      0.50,  0.10,  1.59,     0.00,   1.62,     1.25,   3.06),
    BEST_FRIEND("best_friend", false,  1.45F,  0.25,   0.012,  -0.84,   1.09F,  -0.56,   2.77,      0.00,  0.05,  1.25,    -0.50,   2.00,     1.25,   2.88),
    JOHN_BULL("john_bull", false,  1.25F,  0.25,   0.012,   1.09,   1.00F,   0.97,   2.83,      0.88,  0.30,  0.60,    -0.78,   1.75,     2.28,   3.06),
    ADLER("adler", false,  1.40F,  0.30,   0.013,   1.19,   1.00F,   1.25,   2.71,      1.12,  0.30,  0.60,    -0.84,   1.56,     1.73,   3.12),
    COPPERNOB("coppernob", false,  1.30F,  0.25,   0.013,   1.16,   1.09F,   1.09,   2.64,      1.00,  0.30,  0.70,    -0.84,   1.75,     1.56,   3.19),
    PORTENA("portena", false,  1.35F,  0.25,   0.014,   1.00,   1.06F,   1.56,   2.71,      1.62,  0.53,  0.34,    -0.62,   1.69,     2.31,   1.75),
    SHAY("shay", false,  0.95F,  0.20,   0.018,   0.56,   0.94F,   1.69,   2.60,      0.25,  0.38,  1.06,    -0.22,   2.19,     2.31,   2.31),
    // ---------------------------------------------------------------------------------- diésel industriales y de minería
    SIMPLEX("simplex", true,  1.35F,  0.20,   0.016,   0.62,   0.75F,   0.50,   1.38,      0.00,  0.00,  0.00,     0.75,   1.00,     1.25,   1.25),
    DEUTZ("deutz", true,  1.40F,  0.20,   0.016,   0.78,   0.30F,   0.09,   1.56,      0.00,  0.00,  0.00,     0.25,   1.40,     1.25,   1.25),
    GE44("ge44", true,  1.20F,  0.30,   0.014,   0.00,   0.80F,   0.88,   1.94,      0.00,  0.00,  0.00,     0.12,   2.19,     2.94,   2.94),
    PLYMOUTH("plymouth", true,  1.30F,  0.22,   0.016,   0.44,   0.80F,   0.75,   1.94,      0.00,  0.00,  0.00,     0.19,   2.12,     1.81,   1.81),
    TGM23("tgm23", true,  1.10F,  0.28,   0.015,   0.94,   1.00F,   0.88,   2.12,      0.00,  0.00,  0.00,    -0.88,   2.56,     2.56,   2.31),
    TUNEL("tunel", true,  1.25F,  0.22,   0.018,  -1.19,   0.20F,  -0.56,   1.06,      0.00,  0.00,  0.00,     0.94,   1.47,     2.00,   2.00),
    // ---------------------------------------------------------------------------------- tren artillero (blindado, con torreta)
    ARTILLERO("artillero", true,  0.80F,  0.30,   0.012,  -0.50,   1.70F,  -2.31,   2.13,      0.00,  0.00,  0.00,     3.00,   1.50,     3.44,   3.44);

    private final String id;
    private final boolean diesel;
    private final float tonoSonido;
    private final double velocidadMaxima;
    private final double aceleracion;
    private final double asientoAtras;
    private final float alturaAsiento;
    private final double chimeneaAdelante;
    private final double chimeneaAlto;
    private final double cilindroAdelante;
    private final double cilindroLado;
    private final double cilindroAlto;
    private final double silbatoAdelante;
    private final double silbatoAlto;
    private final double largoFrente;
    private final double largoAtras;
    /**
     * Asientos de la cabina: {adelante, al costado, alto de la cadera sobre el riel} en bloques (salen de
     * {@link AsientosCabina}; se arman la primera vez que se piden). El primero es el del maquinista.
     */
    private double[][] asientos;

    /** Los trenes van al doble de la velocidad de la tabla (y aceleran el doble, así tardan lo mismo en llegar). */
    private static final double DOBLE = 2.0;

    TipoLocomotora(String id, boolean diesel, float tonoSonido, double velocidadMaxima, double aceleracion,
                   double asientoAtras, float alturaAsiento, double chimeneaAdelante, double chimeneaAlto,
                   double cilindroAdelante, double cilindroLado, double cilindroAlto,
                   double silbatoAdelante, double silbatoAlto, double largoFrente, double largoAtras) {
        this.id = id;
        this.diesel = diesel;
        this.tonoSonido = tonoSonido;
        this.velocidadMaxima = velocidadMaxima * DOBLE;
        this.aceleracion = aceleracion * DOBLE;
        this.asientoAtras = asientoAtras;
        this.alturaAsiento = alturaAsiento;
        this.chimeneaAdelante = chimeneaAdelante;
        this.chimeneaAlto = chimeneaAlto;
        this.cilindroAdelante = cilindroAdelante;
        this.cilindroLado = cilindroLado;
        this.cilindroAlto = cilindroAlto;
        this.silbatoAdelante = silbatoAdelante;
        this.silbatoAlto = silbatoAlto;
        this.largoFrente = largoFrente;
        this.largoAtras = largoAtras;
    }

    public String id() { return id; }
    /** ¿Es la locomotora blindada del tren artillero (con torreta; ver {@link com.locomotora.artillero.ArtilleroEntity})? */
    public boolean artillero() { return this == ARTILLERO; }
    /** Las diésel usan bidones de diésel, bocina, motor y humo de escape; las de vapor, carbón y silbato. */
    public boolean diesel() { return diesel; }
    /** Tono del silbato o la bocina (1 = normal). */
    public float tonoSilbato() { return tonoSonido; }
    /**
     * Bloques por tick a toda máquina (hasta 0.8: los trenes pueden ir al doble del tope de las vagonetas, menos en las
     * esquinas de los rieles, ver {@link Enganches#topeDeTren}).
     */
    public double velocidadMaxima() { return velocidadMaxima; }
    public double aceleracion() { return aceleracion; }
    public double asientoAtras() { return asientoAtras; }
    public float alturaAsiento() { return alturaAsiento; }
    public double chimeneaAdelante() { return chimeneaAdelante; }
    public double chimeneaAlto() { return chimeneaAlto; }
    public double cilindroAdelante() { return cilindroAdelante; }
    public double cilindroLado() { return cilindroLado; }
    public double cilindroAlto() { return cilindroAlto; }
    public double silbatoAdelante() { return silbatoAdelante; }
    public double silbatoAlto() { return silbatoAlto; }
    public double largoFrente() { return largoFrente; }
    public double largoAtras() { return largoAtras; }

    private double[][] asientos() {
        double[][] a = this.asientos;
        if (a == null) {
            float[][] crudos = AsientosCabina.de(this.id);
            if (crudos == null || crudos.length == 0) {
                // sin cabina armada (las abandonadas): un solo asiento, el de siempre
                crudos = new float[][]{{(float) (this.asientoAtras * 16.0), 0.0F, this.alturaAsiento * 16.0F}};
            }
            a = new double[crudos.length][];
            for (int i = 0; i < crudos.length; i++) {
                // el frente del modelo está hacia -x; la z del modelo va hacia (-frenteZ, frenteX) en el mundo
                a[i] = new double[]{-crudos[i][0] / 16.0, crudos[i][1] / 16.0, crudos[i][2] / 16.0};
            }
            this.asientos = a;
        }
        return a;
    }

    /** Cuántos pueden ir en la cabina (el primero maneja). */
    public int cantidadAsientos() { return asientos().length; }
    /** Cuánto hacia adelante del centro queda el asiento (bloques; negativo = hacia atrás). */
    public double asientoAdelante(int i) { return asientos()[i][0]; }
    /** Cuánto hacia el costado (-frenteZ, frenteX) queda el asiento (bloques; positivo = a la derecha). */
    public double asientoCostado(int i) { return asientos()[i][1]; }
    /** Altura de la cadera del que va sentado, sobre el riel (bloques). */
    public double asientoAlto(int i) { return asientos()[i][2]; }
}
