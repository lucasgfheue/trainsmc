package com.locomotora.entidad;

/**
 * Los vagones de carga de las locomotoras industriales y de minería. Las medidas están en bloques y salen del estudio
 * de diseño (medio largo del modelo hacia cada punta, contando los topes o el enganche).
 */
public enum TipoVagon {
    //         id            largo frente / atrás
    SKIP(      "skip",       0.875, 0.875),
    LADRILLOS( "ladrillos",  0.875, 0.875),
    CARBON(    "carbon",     0.8125, 0.8125),
    TOLVA(     "tolva",      1.6875, 1.6875),
    VOLTEO(    "volteo",     1.375, 1.375),
    CISTERNA(  "cisterna",   1.875, 1.875),
    DOVELAS(   "dovelas",    1.625, 1.625);

    private final String id;
    private final double largoFrente;
    private final double largoAtras;

    TipoVagon(String id, double largoFrente, double largoAtras) {
        this.id = id;
        this.largoFrente = largoFrente;
        this.largoAtras = largoAtras;
    }

    public String id() { return id; }
    public double largoFrente() { return largoFrente; }
    public double largoAtras() { return largoAtras; }
}
