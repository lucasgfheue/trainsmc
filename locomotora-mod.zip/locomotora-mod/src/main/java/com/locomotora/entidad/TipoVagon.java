package com.locomotora.entidad;

/**
 * Los vagones: los de carga de las locomotoras industriales y de minería (con cofre) y los coches de pasajeros (con
 * asientos para varios jugadores). Las medidas están en bloques y salen del estudio de diseño (medio largo del modelo
 * hacia cada punta, contando los topes o el enganche).
 */
public enum TipoVagon {
    // ---------------------------------------------------------------------------------------------- vagones de carga
    //         id            largo frente / atrás
    SKIP(      "skip",       0.875, 0.875),
    LADRILLOS( "ladrillos",  0.875, 0.875),
    CARBON(    "carbon",     0.8125, 0.8125),
    TOLVA(     "tolva",      1.6875, 1.6875),
    VOLTEO(    "volteo",     1.375, 1.375),
    CISTERNA(  "cisterna",   1.875, 1.875),
    DOVELAS(   "dovelas",    1.625, 1.625),

    // ---------------------------------------------------------------------------------------------- vagones de la línea
    // id, largo frente / atrás y los dos bogies o ejes de las puntas (x del modelo, en 1/16 de bloque)
    G10(          "g10",          2.1875, 2.1875, -16, 16),
    REFRIGERADO(  "refrigerado",  2.8125, 2.8125, -30, 30),
    TRONCOS(      "troncos",      2.0625, 2.0625, -18, 18),
    CONTENEDORES( "contenedores", 4.25,   4.25,   -48, 48),
    PETROLERO(    "petrolero",    2.6875, 2.6875, -28, 28),
    TAKI(         "taki",         3.125,  3.125,  -32, 32),
    GLP(          "glp",          4.25,   4.25,   -50, 50),

    // ---------------------------------------------------------------------------------------------- coches de pasajeros
    // id, largo frente / atrás, los dos bogies (x del modelo, en 1/16 de bloque) y los asientos: {x, z del modelo,
    // altura de la cadera sobre el riel en bloques}. Cada asiento queda frente a una ventana: sentado, el jugador
    // tiene los ojos a la altura de las ventanas y ve el paisaje.
    DILIGENCIA("diligencia", 1.6875, 1.6875, -12, 12, new float[][]{
            {-19.0F, 3.5F, 0.50F}, {-11.0F, -3.5F, 0.50F}, {-4.0F, 3.5F, 0.50F}, {4.0F, -3.5F, 0.50F},
            {11.0F, 3.5F, 0.50F}, {19.0F, -3.5F, 0.50F}}),
    OESTE(     "oeste",      4.0, 4.0, -38, 38, filas(0.47F, 7.5F, -38.5F, -20.5F, 15.5F, 33.5F)),
    TECA(      "teca",       4.625, 4.625, -48, 48, new float[][]{
            {-42.5F, 6.0F, 0.48F}, {-32.5F, -6.0F, 0.48F}, {-27.5F, 6.0F, 0.48F}, {-17.5F, -6.0F, 0.48F},
            {17.5F, 6.0F, 0.48F}, {27.5F, -6.0F, 0.48F}, {32.5F, 6.0F, 0.48F}, {42.5F, -6.0F, 0.48F}}),
    CAMA(      "cama",       5.125, 5.125, -56, 56, filas(0.44F, 7.0F, -42.0F, -18.0F, 18.0F, 42.0F)),
    DAYLIGHT(  "daylight",   5.3125, 5.3125, -58, 58, filas(0.45F, 8.0F, -41.0F, -17.0F, 19.0F, 43.0F)),
    MIRADOR(   "mirador",    5.3125, 5.1875, -58, 52, new float[][]{
            {-51.0F, 8.0F, 0.56F}, {-51.0F, -8.0F, 0.56F}, {-16.0F, 8.0F, 0.56F}, {-16.0F, -8.0F, 0.56F},
            {5.0F, 8.0F, 0.56F}, {5.0F, -8.0F, 0.56F}, {58.5F, 6.0F, 0.56F}, {58.5F, -6.0F, 0.56F}}),
    DOMO(      "domo",       5.4375, 5.4375, -60, 60, new float[][]{
            {-41.0F, 8.0F, 0.51F}, {-41.0F, -8.0F, 0.51F}, {43.0F, 8.0F, 0.51F}, {43.0F, -8.0F, 0.51F},
            // los del domo: la cabeza adentro del domo, mirando por sus vidrios
            {-12.0F, 5.0F, 1.42F}, {-12.0F, -5.0F, 1.42F}, {12.0F, 5.0F, 1.42F}, {12.0F, -5.0F, 1.42F}}),
    INDIO(     "indio",      4.875, 4.875, -52, 52, filas(0.48F, 8.0F, -45.0F, -20.0F, 17.5F, 42.5F)),
    TREN_AZUL( "tren_azul",  4.8125, 4.8125, -50, 50, filas(0.46F, 7.0F, -45.0F, -15.0F, 15.0F, 45.0F)),
    MK3(       "mk3",        5.1875, 5.1875, -54, 54, filas(0.60F, 8.0F, -43.5F, -16.5F, 10.5F, 37.5F)),
    DOS_PISOS( "dos_pisos",  5.3125, 5.3125, -62, 62, filas(0.95F, 8.0F, -45.0F, -12.5F, 13.5F, 46.0F));

    private final String id;
    private final double largoFrente;
    private final double largoAtras;
    private final double bogieDelantero;
    private final double bogieTrasero;
    /** {adelante, al costado, alto} de cada asiento, en bloques (null: vagón de carga). */
    private final double[][] asientos;

    TipoVagon(String id, double largoFrente, double largoAtras) {
        this(id, largoFrente, largoAtras, 0, 0, null);
    }

    /** Vagón de carga largo, que se apoya en la vía por sus dos bogies (o sus dos ejes de las puntas). */
    TipoVagon(String id, double largoFrente, double largoAtras, int bogieDelantero, int bogieTrasero) {
        this(id, largoFrente, largoAtras, bogieDelantero, bogieTrasero, null);
    }

    TipoVagon(String id, double largoFrente, double largoAtras, int bogieDelantero, int bogieTrasero,
              float[][] asientos) {
        this.id = id;
        this.largoFrente = largoFrente;
        this.largoAtras = largoAtras;
        this.bogieDelantero = bogieDelantero / 16.0;
        this.bogieTrasero = bogieTrasero / 16.0;
        if (asientos == null) {
            this.asientos = null;
        } else {
            this.asientos = new double[asientos.length][];
            for (int i = 0; i < asientos.length; i++) {
                // el frente del modelo está hacia -x; la z del modelo va hacia (-frenteZ, frenteX) en el mundo
                this.asientos[i] = new double[]{-asientos[i][0] / 16.0, asientos[i][1] / 16.0, asientos[i][2]};
            }
        }
    }

    /** Asientos de a dos (uno a cada lado) en cada x. */
    private static float[][] filas(float alto, float z, float... xs) {
        float[][] r = new float[xs.length * 2][];
        for (int i = 0; i < xs.length; i++) {
            r[2 * i] = new float[]{xs[i], z, alto};
            r[2 * i + 1] = new float[]{xs[i], -z, alto};
        }
        return r;
    }

    public String id() { return id; }
    public double largoFrente() { return largoFrente; }
    public double largoAtras() { return largoAtras; }

    /** ¿Coche de pasajeros (asientos) o vagón de carga (cofre)? */
    public boolean esCoche() { return asientos != null; }

    /** ¿Es largo (más de 3 bloques)? Entonces su caja tiene tramos para poder hacerle clic en cualquier parte. */
    public boolean esLargo() { return largoFrente + largoAtras > 3.0; }

    /** ¿Se apoya en la vía por dos bogies propios (los coches y los vagones de la línea)? */
    public boolean tieneBogies() { return bogieTrasero > bogieDelantero; }

    /** Nombre del ítem y de la entidad: "vagon_..." o "coche_...". */
    public String nombreRegistro() { return (esCoche() ? "coche_" : "vagon_") + id; }

    /** Distancia del centro del coche al bogie de adelante (bloques; negativo = hacia adelante, como en el modelo). */
    public double bogieDelantero() { return bogieDelantero; }
    public double bogieTrasero() { return bogieTrasero; }

    public int cantidadAsientos() { return asientos == null ? 0 : asientos.length; }
    /** Cuánto hacia adelante del centro queda el asiento (bloques). */
    public double asientoAdelante(int i) { return asientos[i][0]; }
    /** Cuánto hacia el costado (-frenteZ, frenteX) queda el asiento (bloques; el signo dice de qué lado). */
    public double asientoCostado(int i) { return asientos[i][1]; }
    /** Altura de la cadera del pasajero sobre el riel (bloques). */
    public double asientoAlto(int i) { return asientos[i][2]; }
}
