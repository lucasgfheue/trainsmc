package com.locomotora.entidad;

import java.util.Arrays;
import java.util.Locale;

import com.locomotora.registro.ModItems;
import com.locomotora.registro.ModSonidos;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.vehicle.DismountHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import org.jetbrains.annotations.Nullable;

/**
 * Locomotora: una vagoneta con motor propio. Hay modelos de vapor (carbón) y diésel (bidón de diésel),
 * ver {@link TipoLocomotora}.
 *
 * <ul>
 *   <li>Clic derecho con carbón / carbón vegetal / bloque de carbón: carga la caldera.</li>
 *   <li>Clic derecho con la mano vacía: subirse a la cabina. El primero va al puesto del maquinista y maneja; los
 *       demás (2 a 4 según el tamaño de la locomotora) se sientan en los otros asientos de la cabina.</li>
 *   <li>Shift + clic derecho: arrancar (alejándose del jugador) o frenar.</li>
 *   <li>Montado: W sube la marcha, S la baja (hasta marcha atrás), A o D hacen sonar el silbato.</li>
 * </ul>
 *
 * Empuja a las vagonetas que tenga delante (o detrás, yendo en marcha atrás) manteniéndolas fuera del modelo, y
 * arrastra (o empuja) a los vagones que tenga enganchados, ver {@link Enganches}.
 */
public class LocomotoraEntity extends AbstractMinecart implements VehiculoDeVia {

    // ---------------------------------------------------------------- ajustes
    /** Ticks de combustible que da una pieza de carbón (a marcha 1 dura 4 minutos). */
    public static final int CARBON_POR_PIEZA = 4800;
    /** Un bidón de diésel rinde como 6 piezas de carbón. */
    public static final int POR_BIDON = CARBON_POR_PIEZA * 6;
    /** Capacidad de la caldera o del tanque: 40 piezas de carbón (casi 7 bidones). */
    public static final int COMBUSTIBLE_MAXIMO = CARBON_POR_PIEZA * 40;

    public static final int MARCHA_MINIMA = -1;
    public static final int MARCHA_MAXIMA = 3;

    /** Fracción de la velocidad máxima en cada marcha hacia adelante. */
    private static final double[] FRACCION_MARCHA = {0.0, 0.3, 0.62, 1.0};
    private static final double VELOCIDAD_MARCHA_ATRAS = 0.2;
    private static final double FRENADO = 0.012;

    /** Etiqueta vanilla #minecraft:coals (carbón y carbón vegetal, y los de otros mods que la usen). */
    private static final TagKey<Item> CARBONES =
            TagKey.create(Registries.ITEM, ResourceLocation.withDefaultNamespace("coals"));

    // ------------------------------------------------- datos sincronizados con el cliente
    private static final EntityDataAccessor<Boolean> DATA_CON_FUEGO =
            SynchedEntityData.defineId(LocomotoraEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_MARCHA =
            SynchedEntityData.defineId(LocomotoraEntity.class, EntityDataSerializers.INT);
    /** Hacia dónde mira el frente de la locomotora, en grados: el frente es (cos, sin) en (x, z). */
    private static final EntityDataAccessor<Float> DATA_RUMBO =
            SynchedEntityData.defineId(LocomotoraEntity.class, EntityDataSerializers.FLOAT);
    /** Quién va en cada asiento de la cabina (id de la entidad; 0 = libre). El asiento 0 es el del maquinista. */
    private static final EntityDataAccessor<CompoundTag> DATA_ASIENTOS =
            SynchedEntityData.defineId(LocomotoraEntity.class, EntityDataSerializers.COMPOUND_TAG);
    /** El que va sentado: sus pies quedan este tanto debajo de la cadera. */
    private static final double PIERNAS = 0.6;

    private final TipoLocomotora tipo;

    // ------------------------------------------------- estado del servidor
    private int combustible;
    private int esperaSilbato;
    private int ultimaEntrada;
    private int esperaRepeticion;
    private int ticksTrabada;
    private int esperaResoplido;
    private int pausaEstado;
    private long ultimoTick = Long.MIN_VALUE;
    /** ¿La última vez que se movió iba hacia su cola? (en los giros de 90° de las esquinas no se nota) */
    private boolean haciaAtras;
    /** El asiento que pidió el próximo que sube, -1 si ninguno. */
    private int asientoPedido = -1;

    // ------------------------------------------------- estado del cliente (animación de ruedas y de la cabina)
    private double recorrido;
    private double recorridoAnterior;
    /** La aguja del velocímetro (0 a 1), suavizada. */
    private float aguja;
    private float agujaAnterior;

    public LocomotoraEntity(EntityType<? extends LocomotoraEntity> tipoEntidad, Level level, TipoLocomotora tipo) {
        super(tipoEntidad, level);
        this.tipo = tipo;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_CON_FUEGO, false);
        builder.define(DATA_MARCHA, 0);
        builder.define(DATA_RUMBO, 0.0F);
        builder.define(DATA_ASIENTOS, new CompoundTag());
    }

    // ================================================================= identidad

    public TipoLocomotora getTipo() {
        return this.tipo;
    }

    /** "FURNACE" hace que el juego la trate como vagoneta con motor (empuja a las demás). */
    @Override
    public AbstractMinecart.Type getMinecartType() {
        return AbstractMinecart.Type.FURNACE;
    }

    @Override
    protected Item getDropItem() {
        return ModItems.porTipo(this.tipo).get();
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(ModItems.porTipo(this.tipo).get());
    }

    /** El modelo es mucho más grande que la caja de colisión: así no desaparece al mirarlo de cerca. */
    @Override
    public AABB getBoundingBoxForCulling() {
        double alcance = Math.max(3.4, Math.max(this.tipo.largoFrente(), this.tipo.largoAtras()) + 1.0);
        return super.getBoundingBoxForCulling().inflate(alcance, 0.0, alcance).expandTowards(0.0, 2.0, 0.0);
    }

    /** Más fácil de apuntar con el clic. */
    @Override
    public float getPickRadius() {
        return 0.5F;
    }

    // ================================================================= getters / setters

    public boolean tieneFuego() {
        return this.entityData.get(DATA_CON_FUEGO);
    }

    private void setFuego(boolean fuego) {
        this.entityData.set(DATA_CON_FUEGO, fuego);
    }

    public int getMarcha() {
        return this.entityData.get(DATA_MARCHA);
    }

    private void setMarcha(int marcha) {
        this.entityData.set(DATA_MARCHA, Mth.clamp(marcha, MARCHA_MINIMA, MARCHA_MAXIMA));
    }

    @Override
    public float getRumbo() {
        return this.entityData.get(DATA_RUMBO);
    }

    public void setRumbo(float grados) {
        this.entityData.set(DATA_RUMBO, Mth.wrapDegrees(grados));
    }

    @Override
    public double frenteX() {
        return Math.cos(Math.toRadians(getRumbo()));
    }

    @Override
    public double frenteZ() {
        return Math.sin(Math.toRadians(getRumbo()));
    }

    @Override
    public double largoFrente() {
        return this.tipo.largoFrente();
    }

    @Override
    public double largoAtras() {
        return this.tipo.largoAtras();
    }

    @Override
    public long ultimoTick() {
        return this.ultimoTick;
    }

    public int getCombustible() {
        return this.combustible;
    }

    /** Carga combustible directo (los trenes que andan solos y los de la generación del mundo). */
    public void ponerCombustible(int ticks) {
        this.combustible = Mth.clamp(ticks, 0, COMBUSTIBLE_MAXIMO);
        setFuego(this.combustible > 0);
    }

    /** Pone una marcha sin maquinista (para los trenes que andan solos). */
    public void ponerMarcha(int marcha) {
        setMarcha(marcha);
    }

    /** Distancia recorrida (en bloques, interpolada) para girar ruedas y bielas. */
    @Override
    public double getRecorrido(float tickParcial) {
        return Mth.lerp(tickParcial, this.recorridoAnterior, this.recorrido);
    }

    /** La palanca de la cabina sigue a la marcha. */
    @Override
    public int marchaCabina() {
        return getMarcha();
    }

    /** La aguja del velocímetro de la cabina (0 parada, 1 a toda máquina). */
    @Override
    public float velocidadCabina(float tickParcial) {
        return Mth.lerp(tickParcial, this.agujaAnterior, this.aguja);
    }

    // ================================================================= tick

    @Override
    public void tick() {
        super.tick();
        if (this.isRemoved()) {
            return;
        }
        if (this.level().isClientSide()) {
            tickCliente();
        } else {
            // ya se movió en esta vuelta: los vagones enganchados se guían por eso
            this.ultimoTick = this.level().getGameTime();
            tickServidor();
        }
    }

    private void tickServidor() {
        if (this.esperaSilbato > 0) {
            this.esperaSilbato--;
        }
        if (this.pausaEstado > 0) {
            this.pausaEstado--;
        }

        leerControlesDelMaquinista();
        empujarVagonetasCercanas();
        Atropello.revisar(this, this);

        int marcha = getMarcha();
        boolean motorEncendido = this.combustible > 0 && marcha != 0;

        // Consumo de carbón: más marcha, más consumo
        if (motorEncendido) {
            this.combustible = Math.max(0, this.combustible - Math.abs(marcha));
            if (this.combustible == 0) {
                avisarMaquinista(Component.translatable(clave("mensaje.locomotora.sin_carbon")).withStyle(ChatFormatting.RED));
            }
        }
        setFuego(this.combustible > 0);

        double dx = this.getX() - this.xo;
        double dz = this.getZ() - this.zo;
        double avance = Math.sqrt(dx * dx + dz * dz);

        // Si quedó trabada contra algo, se detiene sola para no gastar carbón
        if (motorEncendido && avance < 0.003) {
            if (++this.ticksTrabada > 60) {
                this.ticksTrabada = 0;
                cambiarMarcha(0, null);
                avisarMaquinista(Component.translatable("mensaje.locomotora.trabada").withStyle(ChatFormatting.YELLOW));
            }
        } else {
            this.ticksTrabada = 0;
        }

        if (this.tipo.diesel()) {
            // Motor diésel: se oye siempre que tenga combustible y acelera con la marcha
            if (this.combustible > 0) {
                if (--this.esperaResoplido <= 0) {
                    float tono = (0.72F + 0.12F * Math.abs(marcha) + (float) Math.min(avance, 0.4) * 0.4F)
                            * (0.85F + this.tipo.tonoSilbato() * 0.15F);
                    this.level().playSound(null, this.getX(), this.getY() + 1.0, this.getZ(), ModSonidos.MOTOR.get(),
                            SoundSource.NEUTRAL, motorEncendido ? 0.9F : 0.5F, tono);
                    this.esperaResoplido = motorEncendido ? 12 : 22;
                }
            } else {
                this.esperaResoplido = 0;
            }
        } else if (motorEncendido && avance > 0.02) {
            // "Chuf, chuf": el ritmo acompaña a la velocidad
            if (--this.esperaResoplido <= 0) {
                this.level().playSound(null, this.getX(), this.getY() + 1.0, this.getZ(), ModSonidos.RESOPLIDO.get(),
                        SoundSource.NEUTRAL, 0.8F, (0.9F + this.random.nextFloat() * 0.2F) * (0.5F + this.tipo.tonoSilbato() * 0.5F));
                this.esperaResoplido = Mth.clamp((int) (1.4 / avance), 3, 20);
            }
        } else {
            this.esperaResoplido = 0;
        }

        if (this.tickCount % 20 == 0 && this.pausaEstado == 0 && getMaquinista() instanceof Player maquinista) {
            mostrarEstado(maquinista);
        }
    }

    /** Lee las teclas del jugador montado (el servidor recibe W/S/A/D de quien va sentado). */
    private void leerControlesDelMaquinista() {
        if (!(getMaquinista() instanceof Player maquinista)) {
            this.ultimaEntrada = 0;
            return;
        }

        int entrada = maquinista.zza > 0.1F ? 1 : (maquinista.zza < -0.1F ? -1 : 0);
        if (entrada != 0) {
            // Un toque cambia una marcha; si se mantiene apretada, sigue cambiando cada medio segundo
            if (entrada != this.ultimaEntrada || --this.esperaRepeticion <= 0) {
                cambiarMarcha(getMarcha() + entrada, maquinista);
                this.esperaRepeticion = 10;
            }
        }
        this.ultimaEntrada = entrada;

        if (Math.abs(maquinista.xxa) > 0.1F) {
            silbar();
        }
    }

    private void cambiarMarcha(int nueva, @Nullable Player quien) {
        nueva = Mth.clamp(nueva, MARCHA_MINIMA, MARCHA_MAXIMA);
        int anterior = getMarcha();
        if (nueva == anterior) {
            return;
        }
        setMarcha(nueva);
        this.level().playSound(null, this.getX(), this.getY() + 1.0, this.getZ(), SoundEvents.LEVER_CLICK,
                SoundSource.NEUTRAL, 0.5F, nueva == 0 ? 0.6F : 0.9F);
        if (anterior == 0 && this.combustible > 0) {
            silbar(); // ¡Partimos!
        }
        if (quien != null) {
            mostrarEstado(quien);
        }
    }

    public void silbar() {
        if (this.esperaSilbato > 0) {
            return;
        }
        this.esperaSilbato = 50;
        double x = this.getX() + frenteX() * this.tipo.silbatoAdelante();
        double y = this.getY() + this.tipo.silbatoAlto();
        double z = this.getZ() + frenteZ() * this.tipo.silbatoAdelante();
        this.level().playSound(null, x, y, z, this.tipo.diesel() ? ModSonidos.BOCINA.get() : ModSonidos.SILBATO.get(),
                SoundSource.NEUTRAL, 4.0F, this.tipo.tonoSilbato());
        if (!this.tipo.diesel() && this.level() instanceof ServerLevel servidor) {
            servidor.sendParticles(ParticleTypes.CLOUD, x, y + 0.1, z, 10, 0.05, 0.2, 0.05, 0.03);
        }
    }

    // ================================================================= física

    @Override
    protected void moveAlongTrack(BlockPos pos, BlockState estado) {
        super.moveAlongTrack(pos, estado);
        actualizarRumboSegunMovimiento();
    }

    /**
     * El frente sigue la vía (el trazo dibujado, redondo en las curvas), pero nunca se da vuelta solo: si va para
     * atrás, sigue mirando hacia el mismo lado.
     */
    private void actualizarRumboSegunMovimiento() {
        Vec3 m = this.getDeltaMovement();
        double largo = Math.sqrt(m.x * m.x + m.z * m.z);
        if (largo < 1.0E-3) {
            return;
        }
        double ux = m.x / largo;
        double uz = m.z / largo;
        // Al salir de una esquina el juego gira el movimiento 90° de golpe: ahí el coseno da 0 (más el ruido del
        // redondeo, que a veces es negativo) y no dice para qué lado va. Se sigue como venía; si no, los trenes que
        // iban hacia el oeste se daban vuelta en las curvas.
        double coseno = ux * frenteX() + uz * frenteZ();
        if (coseno < -1.0E-4) {
            this.haciaAtras = true;
        } else if (coseno > 1.0E-4) {
            this.haciaAtras = false;
        }
        if (this.haciaAtras) {
            ux = -ux;
            uz = -uz;
        }
        float nuevo = Via.rumboSobreLaVia(this.level(), this.getX(), this.getY(), this.getZ(), ux, uz, this);
        if (Math.abs(Mth.wrapDegrees(nuevo - getRumbo())) > 0.5F) {
            setRumbo(nuevo);
        }
    }

    /** Los trenes andan hasta el doble de rápido que una vagoneta (menos en las esquinas de los rieles). */
    @Override
    public double getMaxSpeedWithRail() {
        return Enganches.topeDeTren(this, super.getMaxSpeedWithRail());
    }

    /** Se llama en cada tick sobre los rieles: acá está el "motor" y el freno. */
    @Override
    protected void applyNaturalSlowdown() {
        Vec3 m = this.getDeltaMovement();
        double mx = m.x;
        double mz = m.z;
        int marcha = getMarcha();

        if (this.combustible > 0 && marcha != 0) {
            double signo = marcha > 0 ? 1.0 : -1.0;
            double dirX = frenteX() * signo;
            double dirZ = frenteZ() * signo;
            double velocidad = marcha > 0 ? this.tipo.velocidadMaxima() * FRACCION_MARCHA[marcha] : VELOCIDAD_MARCHA_ATRAS;
            // Llevando pasajero el juego mueve la vagoneta un 25% menos, así que se compensa
            double objetivo = velocidad / (this.isVehicle() ? 0.75 : 1.0);
            if (this.isInWater()) {
                objetivo *= 0.5;
            }
            double actual = mx * dirX + mz * dirZ;
            if (actual < objetivo) {
                double empuje = Math.min(this.tipo.aceleracion(), objetivo - actual);
                mx += dirX * empuje;
                mz += dirZ * empuje;
            } else {
                double exceso = Math.min(FRENADO, actual - objetivo);
                mx -= dirX * exceso;
                mz -= dirZ * exceso;
            }
        } else if (marcha == 0) {
            // Freno puesto
            double v = Math.sqrt(mx * mx + mz * mz);
            if (v < 0.02) {
                mx = 0.0;
                mz = 0.0;
            } else {
                double factor = Math.max(0.0, v - Math.max(FRENADO, v * 0.06)) / v;
                mx *= factor;
                mz *= factor;
            }
        } else {
            // Sin carbón: sigue por inercia y se va frenando de a poco
            mx *= 0.985;
            mz *= 0.985;
        }

        if (this.isInWater()) {
            mx *= 0.95;
            mz *= 0.95;
        }
        this.setDeltaMovement(mx, 0.0, mz);
    }

    /**
     * La caja de colisión es la de una vagoneta, pero el modelo mide más de 5 bloques: las vagonetas sueltas que
     * quedan delante (o detrás) se empujan para que no se metan dentro del modelo.
     */
    private void empujarVagonetasCercanas() {
        Enganches.empujarVecinos(this, this);
    }

    /** Los vagones enganchados no se chocan con la locomotora: ya van a la distancia justa. */
    @Override
    public void push(Entity otra) {
        if (Enganches.enganchados(this, otra)) {
            return;
        }
        super.push(otra);
    }

    // ================================================================= cabina: asientos

    /**
     * Un punto de la locomotora: tanto hacia adelante, tanto hacia el costado (-frenteZ, frenteX) y tanto de alto,
     * siguiendo la vía (en las curvas y en las vías del mod la cabina va donde se dibuja, no en línea recta).
     */
    protected Vec3 puntoDeLaLoco(double adelante, double costado, double alto) {
        double fx = frenteX();
        double fz = frenteZ();
        double alcance = Math.abs(adelante) + 1.5;
        Via via = Via.alrededor(this.level(), this.getX(), this.getY(), this.getZ(), fx, fz, alcance, alcance, this);
        if (via.enVia()) {
            Vec3 a = via.punto(adelante);
            Vec3 d = via.punto(adelante + 0.25).subtract(via.punto(adelante - 0.25));
            double h = Math.sqrt(d.x * d.x + d.z * d.z);
            double lx = h < 1.0E-6 ? -fz : -d.z / h;
            double lz = h < 1.0E-6 ? fx : d.x / h;
            return new Vec3(a.x + lx * costado, a.y + alto, a.z + lz * costado);
        }
        return new Vec3(this.getX() + fx * adelante - fz * costado, this.getY() + alto,
                this.getZ() + fz * adelante + fx * costado);
    }

    private Vec3 puntoAsiento(int i) {
        return puntoDeLaLoco(this.tipo.asientoAdelante(i), this.tipo.asientoCostado(i), this.tipo.asientoAlto(i));
    }

    /** Quién va en cada asiento (números de entidad; 0 = libre). Es una copia: se cambia y se guarda con guardarAsientos. */
    private int[] asientos() {
        int[] a = this.entityData.get(DATA_ASIENTOS).getIntArray("a");
        return Arrays.copyOf(a, this.tipo.cantidadAsientos());
    }

    private void guardarAsientos(int[] a) {
        CompoundTag tag = new CompoundTag();
        tag.putIntArray("a", a);
        this.entityData.set(DATA_ASIENTOS, tag);
    }

    /** ¿Ese número de entidad va arriba de la locomotora? */
    private boolean vaArriba(int id) {
        if (id == 0) {
            return false;
        }
        for (Entity p : this.getPassengers()) {
            if (p.getId() == id) {
                return true;
            }
        }
        return false;
    }

    /** El asiento de un pasajero (si todavía no llegó el dato, el que le toca por orden de subida). */
    private int asientoDe(Entity pasajero) {
        int[] a = asientos();
        for (int i = 0; i < a.length; i++) {
            if (a[i] == pasajero.getId()) {
                return i;
            }
        }
        int k = this.getPassengers().indexOf(pasajero);
        return Math.max(0, Math.min(a.length - 1, k));
    }

    /** El asiento libre más cercano a un lugar, o -1. */
    private int asientoLibreMasCercano(Vec3 desde) {
        int[] a = asientos();
        int mejor = -1;
        double distancia = Double.MAX_VALUE;
        for (int i = 0; i < a.length; i++) {
            if (vaArriba(a[i])) {
                continue;
            }
            double d = puntoAsiento(i).distanceToSqr(desde);
            if (d < distancia) {
                distancia = d;
                mejor = i;
            }
        }
        return mejor;
    }

    /** El maquinista: el jugador que va en el puesto de manejo (el primer asiento), o null si está libre. */
    @Nullable
    public Player getMaquinista() {
        int id = asientos()[0];
        if (id != 0) {
            for (Entity p : this.getPassengers()) {
                if (p.getId() == id) {
                    return p instanceof Player j ? j : null;
                }
            }
        }
        return null;
    }

    @Override
    protected boolean canAddPassenger(Entity pasajero) {
        return this.getPassengers().size() < this.tipo.cantidadAsientos();
    }

    @Override
    protected void addPassenger(Entity pasajero) {
        super.addPassenger(pasajero);
        if (this.level().isClientSide()) {
            return;
        }
        int[] a = asientos();
        // si alguien quedó anotado en un asiento pero ya no va arriba, se libera
        for (int i = 0; i < a.length; i++) {
            if (a[i] != 0 && !vaArriba(a[i])) {
                a[i] = 0;
            }
        }
        guardarAsientos(a);
        int elegido = this.asientoPedido >= 0 && this.asientoPedido < a.length && a[this.asientoPedido] == 0
                ? this.asientoPedido : -1;
        if (elegido < 0) {
            elegido = a[0] == 0 ? 0 : asientoLibreMasCercano(pasajero.position());
        }
        if (elegido >= 0) {
            a[elegido] = pasajero.getId();
        }
        guardarAsientos(a);
    }

    @Override
    protected void removePassenger(Entity pasajero) {
        super.removePassenger(pasajero);
        if (this.level().isClientSide()) {
            return;
        }
        int[] a = asientos();
        for (int i = 0; i < a.length; i++) {
            if (a[i] == pasajero.getId()) {
                a[i] = 0;
            }
        }
        guardarAsientos(a);
    }

    /** Cada uno en su asiento de la cabina, siguiendo la vía. */
    @Override
    protected void positionRider(Entity pasajero, Entity.MoveFunction mover) {
        Vec3 p = puntoAsiento(asientoDe(pasajero));
        mover.accept(pasajero, p.x, p.y - PIERNAS, p.z);
    }

    /** Al bajarse, sale por el costado de su asiento (si ahí no se puede, por el otro). */
    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity pasajero) {
        int i = asientoDe(pasajero);
        double lado = this.tipo.asientoCostado(i) >= 0.0 ? 1.0 : -1.0;
        for (double s : new double[]{lado, -lado}) {
            Vec3 afuera = puntoDeLaLoco(this.tipo.asientoAdelante(i), s * 1.4, 0.0);
            BlockPos pos = BlockPos.containing(afuera);
            for (BlockPos q : new BlockPos[]{pos, pos.above(), pos.below()}) {
                Vec3 v = DismountHelper.findSafeDismountLocation(pasajero.getType(), this.level(), q, true);
                if (v != null) {
                    return v;
                }
            }
        }
        return super.getDismountLocationForPassenger(pasajero);
    }

    /** Un golpe de alguien que va arriba no le hace nada a la locomotora. */
    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (fuente.getEntity() != null && fuente.getEntity().getVehicle() == this) {
            return false;
        }
        return super.hurt(fuente, cantidad);
    }

    // ================================================================= interacción

    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        InteractionResult resultado = super.interact(jugador, mano);
        if (resultado.consumesAction()) {
            return resultado;
        }

        ItemStack enMano = jugador.getItemInHand(mano);
        int valor = valorComoCombustible(enMano);

        // Cargar carbón (vapor) o diésel
        if (valor > 0) {
            if (!this.level().isClientSide()) {
                if (this.combustible + valor <= COMBUSTIBLE_MAXIMO) {
                    enMano.consume(1, jugador);
                    this.combustible += valor;
                    setFuego(true);
                    this.level().playSound(null, this.getX(), this.getY() + 1.0, this.getZ(),
                            this.tipo.diesel() ? SoundEvents.BUCKET_EMPTY : SoundEvents.FIRECHARGE_USE,
                            SoundSource.NEUTRAL, 0.5F, 1.3F);
                    mostrarEstado(jugador);
                } else {
                    jugador.displayClientMessage(Component.translatable(clave("mensaje.locomotora.caldera_llena"))
                            .withStyle(ChatFormatting.GOLD), true);
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }

        // Shift + clic: arrancar o frenar sin subirse
        if (jugador.isSecondaryUseActive()) {
            if (!this.level().isClientSide()) {
                if (getMarcha() != 0) {
                    cambiarMarcha(0, jugador);
                } else if (this.combustible > 0) {
                    orientarSegunDireccion(this.getX() - jugador.getX(), this.getZ() - jugador.getZ(), formaDelRielActual());
                    cambiarMarcha(2, jugador);
                } else {
                    jugador.displayClientMessage(Component.translatable(clave("mensaje.locomotora.sin_carbon"))
                            .withStyle(ChatFormatting.RED), true);
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }

        // Subirse: al puesto del maquinista si está libre; si no, al asiento libre más cercano
        if (jugador.getVehicle() == this) {
            return InteractionResult.PASS;
        }
        if (this.getPassengers().size() >= this.tipo.cantidadAsientos()) {
            if (!this.level().isClientSide()) {
                jugador.displayClientMessage(Component.translatable("mensaje.locomotora.cabina_llena")
                        .withStyle(ChatFormatting.RED), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }
        if (!this.level().isClientSide()) {
            this.asientoPedido = vaArriba(asientos()[0]) ? asientoLibreMasCercano(jugador.position()) : 0;
            boolean subio = jugador.startRiding(this);
            this.asientoPedido = -1;
            if (subio) {
                if (getMaquinista() == jugador) {
                    mostrarEstado(jugador);
                } else {
                    jugador.displayClientMessage(Component.translatable("mensaje.locomotora.acompanante")
                            .withStyle(ChatFormatting.GRAY), true);
                }
                return InteractionResult.CONSUME;
            }
            return InteractionResult.PASS;
        }
        return InteractionResult.SUCCESS;
    }

    /** Cuánto combustible da un ítem: carbón para las de vapor, bidón de diésel para las diésel. */
    public int valorComoCombustible(ItemStack stack) {
        if (this.tipo.diesel()) {
            return stack.is(ModItems.BIDON_DIESEL.get()) ? POR_BIDON : 0;
        }
        if (stack.is(Items.COAL_BLOCK)) {
            return CARBON_POR_PIEZA * 9;
        }
        if (stack.is(CARBONES) || stack.is(Items.COAL) || stack.is(Items.CHARCOAL)) {
            return CARBON_POR_PIEZA;
        }
        return 0;
    }

    /**
     * Apunta el frente según una dirección (por ejemplo, hacia donde mira el jugador),
     * alineado con el riel si es recto.
     */
    public void orientarSegunDireccion(double dx, double dz, @Nullable RailShape forma) {
        setRumbo(Enganches.rumboSegunDireccion(dx, dz, forma));
    }

    @Nullable
    private RailShape formaDelRielActual() {
        BlockPos pos = this.getCurrentRailPosition();
        BlockState estado = this.level().getBlockState(pos);
        if (estado.getBlock() instanceof BaseRailBlock riel) {
            return riel.getRailDirection(estado, this.level(), pos, this);
        }
        return null;
    }

    // ================================================================= mensajes

    private void avisarMaquinista(Component mensaje) {
        if (getMaquinista() instanceof Player maquinista) {
            maquinista.displayClientMessage(mensaje, true);
            this.pausaEstado = 40;
        }
    }

    private void mostrarEstado(Player jugador) {
        Component marcha = Component.translatable("marcha.locomotora." + nombreMarcha(getMarcha()));
        int unidad = this.tipo.diesel() ? POR_BIDON : CARBON_POR_PIEZA;
        Component carbon = this.combustible > 0
                ? Component.translatable(clave("estado.locomotora.carbon"),
                        String.format(Locale.ROOT, "%.1f", this.combustible / (double) unidad))
                : Component.translatable(clave("estado.locomotora.sin_carbon")).withStyle(ChatFormatting.RED);
        jugador.displayClientMessage(agregarAlEstado(Component.translatable("estado.locomotora", marcha, carbon)), true);
    }

    /** Lo que cada locomotora agrega a la línea de estado del maquinista (el tren artillero, su blindaje). */
    protected Component agregarAlEstado(Component estado) {
        return estado;
    }

    /** Las diésel usan sus propios textos: "carbon" pasa a "diesel" y "caldera_llena" a "tanque_lleno". */
    private String clave(String deVapor) {
        if (!this.tipo.diesel()) {
            return deVapor;
        }
        return deVapor.replace("caldera_llena", "tanque_lleno").replace("carbon", "diesel");
    }

    private static String nombreMarcha(int marcha) {
        return switch (marcha) {
            case -1 -> "atras";
            case 0 -> "freno";
            default -> Integer.toString(marcha);
        };
    }

    // ================================================================= efectos del cliente

    private void tickCliente() {
        this.recorridoAnterior = this.recorrido;
        double dx = this.getX() - this.xo;
        double dz = this.getZ() - this.zo;
        double distancia = Math.sqrt(dx * dx + dz * dz);
        if (distancia > 1.0E-4 && distancia < 2.0) {
            double sentido = dx * frenteX() + dz * frenteZ() >= 0.0 ? 1.0 : -1.0;
            this.recorrido += sentido * distancia;
        }
        // la aguja del velocímetro sigue a la velocidad, sin saltos
        this.agujaAnterior = this.aguja;
        double objetivo = distancia < 2.0 ? distancia / Math.max(0.05, this.tipo.velocidadMaxima()) : 0.0;
        this.aguja += ((float) Mth.clamp(objetivo, 0.0, 1.0) - this.aguja) * 0.2F;
        if (tieneFuego()) {
            echarHumo(distancia);
        }
    }

    private void echarHumo(double velocidad) {
        double fx = frenteX();
        double fz = frenteZ();
        double cx = this.getX() + fx * this.tipo.chimeneaAdelante();
        double cy = this.getY() + this.tipo.chimeneaAlto();
        double cz = this.getZ() + fz * this.tipo.chimeneaAdelante();
        boolean enMarcha = getMarcha() != 0 && velocidad > 0.01;

        if (this.tipo.diesel()) {
            // Escape del motor diésel: humo oscuro, más espeso en marcha
            if (enMarcha || this.random.nextInt(3) == 0) {
                this.level().addParticle(ParticleTypes.LARGE_SMOKE, cx, cy, cz, 0.0, enMarcha ? 0.09 : 0.04, 0.0);
            }
            if (enMarcha && this.random.nextInt(2) == 0) {
                this.level().addParticle(ParticleTypes.SMOKE, cx, cy, cz, 0.0, 0.12, 0.0);
            }
            return;
        }

        if (enMarcha) {
            this.level().addParticle(ParticleTypes.LARGE_SMOKE, cx, cy, cz, 0.0, 0.05, 0.0);
            if (this.random.nextInt(2) == 0) {
                this.level().addAlwaysVisibleParticle(ParticleTypes.CAMPFIRE_COSY_SMOKE, true, cx, cy, cz, 0.0, 0.07, 0.0);
            }
            // Vapor que escapa de los cilindros, a los costados
            if (this.random.nextInt(4) == 0) {
                double lado = this.random.nextBoolean() ? 1.0 : -1.0;
                double ancho = this.tipo.cilindroLado() + 0.15;
                double px = this.getX() + fx * this.tipo.cilindroAdelante() - fz * ancho * lado;
                double pz = this.getZ() + fz * this.tipo.cilindroAdelante() + fx * ancho * lado;
                this.level().addParticle(ParticleTypes.CLOUD, px, this.getY() + this.tipo.cilindroAlto(), pz,
                        -fz * lado * 0.07, 0.01, fx * lado * 0.07);
            }
        } else if (this.random.nextInt(3) == 0) {
            // Caldera encendida pero parada: humo suave
            this.level().addParticle(ParticleTypes.SMOKE, cx, cy, cz, 0.0, 0.04, 0.0);
        }
    }

    // ================================================================= romperla y guardado

    /** Si la rompen, los vagones que tenía enganchados quedan sueltos. */
    @Override
    public void remove(Entity.RemovalReason motivo) {
        if (!this.level().isClientSide() && motivo.shouldDestroy()) {
            Enganches.soltarSeguidores(this);
        }
        super.remove(motivo);
    }

    @Override
    public void destroy(DamageSource fuente) {
        super.destroy(fuente);
        // Devuelve el combustible que quedaba (carbón o bidones de diésel enteros)
        int piezas = this.combustible / (this.tipo.diesel() ? POR_BIDON : CARBON_POR_PIEZA);
        if (piezas > 0 && this.level().getGameRules().getBoolean(GameRules.RULE_DOENTITYDROPS)) {
            this.spawnAtLocation(this.tipo.diesel()
                    ? new ItemStack(ModItems.BIDON_DIESEL.get(), Math.min(piezas, 16))
                    : new ItemStack(Items.COAL, Math.min(piezas, 64)));
        }
        this.combustible = 0;
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Combustible", this.combustible);
        tag.putInt("Marcha", getMarcha());
        tag.putFloat("Rumbo", getRumbo());
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.combustible = Mth.clamp(tag.getInt("Combustible"), 0, COMBUSTIBLE_MAXIMO);
        setMarcha(tag.getInt("Marcha"));
        setRumbo(tag.getFloat("Rumbo"));
        setFuego(this.combustible > 0);
    }
}
