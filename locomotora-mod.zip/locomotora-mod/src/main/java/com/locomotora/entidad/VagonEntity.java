package com.locomotora.entidad;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import com.locomotora.registro.ModItems;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.DismountHelper;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.entity.vehicle.MinecartChest;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.entity.PartEntity;

import org.jetbrains.annotations.Nullable;

/**
 * Vagón de carga (una vagoneta con cofre de 27 espacios) o coche de pasajeros (con asientos para varios), que se
 * engancha a una locomotora o a otro vagón, ver {@link TipoVagon} y {@link Enganches}.
 *
 * <ul>
 *   <li>Al ponerlo en la vía se engancha solo a la locomotora o al vagón que tenga al lado.</li>
 *   <li>Clic derecho: abre la carga; en un coche, te sentás en el asiento libre más cercano (frente a una ventana).
 *       Si traés animales o aldeanos atados con correa, suben ellos; con una correa en la mano, bajan.</li>
 *   <li>Shift + clic derecho: lo desengancha, o lo engancha a lo que tenga al lado.</li>
 * </ul>
 * Un coche mide hasta 11 bloques (y un portacontenedores, 8): para poder hacerle clic en cualquier parte, la caja de
 * los coches y de los vagones largos tiene tramos ({@link ParteCoche}) que siguen la vía como el modelo.
 */
public class VagonEntity extends MinecartChest implements VehiculoDeVia {
    /** Enganchado puede ir apenas más rápido que el tope del riel, para alcanzar a la locomotora si quedó atrás. */
    private static final double RESERVA_DE_VELOCIDAD = 1.15;

    /** Hacia dónde mira el frente del vagón, en grados: el frente es (cos, sin) en (x, z). */
    private static final EntityDataAccessor<Float> DATA_RUMBO =
            SynchedEntityData.defineId(VagonEntity.class, EntityDataSerializers.FLOAT);

    /** En los coches: quién va en cada asiento (id de la entidad; 0 = libre). */
    private static final EntityDataAccessor<CompoundTag> DATA_ASIENTOS =
            SynchedEntityData.defineId(VagonEntity.class, EntityDataSerializers.COMPOUND_TAG);
    /** Largo de cada tramo de la caja de un coche (bloques). */
    private static final double PASO_PARTES = 1.5;
    /** El pasajero va sentado: sus pies quedan este tanto debajo de la cadera. */
    private static final double PIERNAS = 0.6;

    private final TipoVagon tipo;

    // ------------------------------------------------- coche de pasajeros
    @Nullable
    private final ParteCoche[] partes;
    /** El asiento que pidió el próximo pasajero (el más cercano a donde estaba), -1 si ninguno. */
    private int asientoPedido = -1;
    /** Dónde está la caja del coche (sigue la vía por los dos bogies, como el modelo): origen y dirección. */
    private double marcoX = Double.NaN;
    private double marcoY;
    private double marcoZ;
    private float marcoRumbo;
    private Vec3 marcoOrigen = Vec3.ZERO;
    private Vec3 marcoDireccion = new Vec3(1.0, 0.0, 0.0);

    // ------------------------------------------------- enganche (solo en el servidor)
    @Nullable
    private UUID idLider;
    /** ¿Está enganchado en el frente del líder (o en su cola)? */
    private boolean alFrenteDelLider;
    /** ¿El líder está del lado de mi frente (o de mi cola)? */
    private boolean liderPorMiFrente;
    @Nullable
    private AbstractMinecart lider;
    private long ultimoTick = Long.MIN_VALUE;
    private long vueltaDelPlan = Long.MIN_VALUE;
    private Vec3 plan = Vec3.ZERO;
    private boolean cortado;
    /** El líder se le metió encima más de medio bloque: este vagón está trabado (contra un bloque, o descarrilado). */
    private boolean encimado;
    /** ¿La última vez que se movió iba hacia su cola? (en los giros de 90° de las esquinas no se nota) */
    private boolean haciaAtras;

    // ------------------------------------------------- cliente (animación de las ruedas)
    private double recorrido;
    private double recorridoAnterior;

    public VagonEntity(EntityType<? extends VagonEntity> tipoEntidad, Level level, TipoVagon tipo) {
        super(tipoEntidad, level);
        this.tipo = tipo;
        if (tipo.esCoche() || (tipo.tieneBogies() && tipo.esLargo())) {
            // los tramos se crean justo después del coche: sus números de entidad quedan seguidos al del coche
            int n = Math.max(2, (int) Math.ceil((tipo.largoFrente() + tipo.largoAtras()) / PASO_PARTES));
            this.partes = new ParteCoche[n];
            for (int i = 0; i < n; i++) {
                this.partes[i] = new ParteCoche(this, 1.6F, 2.5F);
            }
        } else {
            this.partes = null;
        }
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_RUMBO, 0.0F);
        builder.define(DATA_ASIENTOS, new CompoundTag());
    }

    // ================================================================= identidad

    public TipoVagon getTipo() {
        return this.tipo;
    }

    @Override
    protected Item getDropItem() {
        return ModItems.porTipo(this.tipo).get();
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(ModItems.porTipo(this.tipo).get());
    }

    /** El modelo es más largo que la caja de choque: así no desaparece al mirarlo de cerca. */
    @Override
    public AABB getBoundingBoxForCulling() {
        double alcance = Math.max(this.tipo.largoFrente(), this.tipo.largoAtras()) + 1.0;
        return super.getBoundingBoxForCulling().inflate(alcance, 0.0, alcance).expandTowards(0.0, 1.5, 0.0);
    }

    // ================================================================= VehiculoDeVia

    @Override
    public float getRumbo() {
        return this.entityData.get(DATA_RUMBO);
    }

    public void setRumbo(float grados) {
        this.entityData.set(DATA_RUMBO, Mth.wrapDegrees(grados));
    }

    @Override
    public double frenteX() {
        return Math.cos(Math.toRadians(getRumbo()));
    }

    @Override
    public double frenteZ() {
        return Math.sin(Math.toRadians(getRumbo()));
    }

    @Override
    public double largoFrente() {
        return this.tipo.largoFrente();
    }

    @Override
    public double largoAtras() {
        return this.tipo.largoAtras();
    }

    @Override
    public double getRecorrido(float tickParcial) {
        return Mth.lerp(tickParcial, this.recorridoAnterior, this.recorrido);
    }

    @Override
    public long ultimoTick() {
        return this.ultimoTick;
    }

    /** Apunta el frente según una dirección (por ejemplo, hacia donde mira el jugador), alineado con el riel. */
    public void orientarSegunDireccion(double dx, double dz, @Nullable RailShape forma) {
        setRumbo(Enganches.rumboSegunDireccion(dx, dz, forma));
    }

    // ================================================================= enganche

    public boolean estaEnganchado() {
        return this.idLider != null;
    }

    /** ¿Este vagón va enganchado a {@code e}? */
    public boolean siguiendoA(Entity e) {
        return this.idLider != null && this.idLider.equals(e.getUUID());
    }

    public boolean alFrenteDelLider() {
        return this.alFrenteDelLider;
    }

    public boolean liderPorMiFrente() {
        return this.liderPorMiFrente;
    }

    /** La locomotora o el vagón al que va enganchado, si está cargado en el mundo. */
    @Nullable
    public AbstractMinecart getLider() {
        if (this.idLider == null) {
            return null;
        }
        if (this.lider != null && !this.lider.isRemoved()) {
            return this.lider;
        }
        this.lider = null;
        if (this.level() instanceof ServerLevel servidor
                && servidor.getEntity(this.idLider) instanceof AbstractMinecart v && v instanceof VehiculoDeVia) {
            this.lider = v;
        }
        return this.lider;
    }

    public void engancharA(Enganches.Propuesta p) {
        this.idLider = p.lider().getUUID();
        this.lider = p.lider();
        this.alFrenteDelLider = p.alFrenteDelLider();
        this.liderPorMiFrente = p.liderPorMiFrente();
        this.vueltaDelPlan = Long.MIN_VALUE;
        this.cortado = false;
        this.level().playSound(null, this.getX(), this.getY() + 0.5, this.getZ(), SoundEvents.CHAIN_PLACE,
                SoundSource.NEUTRAL, 1.0F, 0.9F);
    }

    /**
     * Engancha el vagón a un líder que todavía no está en el mundo (al generar el mundo, cada vehículo del tren se pone
     * en su propio chunk): solo se guarda quién es; se lo busca cuando hace falta.
     */
    public void engancharEnGeneracion(UUID lider, boolean alFrenteDelLider, boolean liderPorMiFrente) {
        this.idLider = lider;
        this.lider = null;
        this.alFrenteDelLider = alFrenteDelLider;
        this.liderPorMiFrente = liderPorMiFrente;
        this.vueltaDelPlan = Long.MIN_VALUE;
        this.cortado = false;
    }

    public void soltar() {
        if (this.idLider == null) {
            return;
        }
        this.idLider = null;
        this.lider = null;
        this.cortado = false;
        this.level().playSound(null, this.getX(), this.getY() + 0.5, this.getZ(), SoundEvents.CHAIN_BREAK,
                SoundSource.NEUTRAL, 1.0F, 0.9F);
    }

    /** Lo que este vagón planea avanzar en esta vuelta del servidor (se calcula una sola vez por vuelta). */
    Vec3 planDeLaVuelta(int profundidad) {
        long ahora = this.level().getGameTime();
        if (this.vueltaDelPlan != ahora) {
            // se marca antes de calcular: si por error hubiera un círculo de enganches, no se repite para siempre
            this.vueltaDelPlan = ahora;
            this.plan = calcularPlan(profundidad);
        }
        return this.plan;
    }

    /**
     * Avanzar lo mismo que avanza el líder en esta vuelta (lo que ya avanzó, si el juego lo movió antes, o lo que va a
     * avanzar), más una corrección (con tope) para quedar a la distancia justa de él, medida siguiendo la vía.
     */
    private Vec3 calcularPlan(int profundidad) {
        this.cortado = false;
        this.encimado = false;
        AbstractMinecart l = getLider();
        if (!(l instanceof VehiculoDeVia vl)) {
            return this.getDeltaMovement(); // el líder no está cargado: por ahora va suelto
        }
        double separacion = Enganches.largo(vl, this.alFrenteDelLider) + Enganches.largo(this, this.liderPorMiFrente)
                + Enganches.HUECO;
        double alcance = separacion + Enganches.CORTE + 2.0;
        Via via = Via.alrededor(this.level(), this.getX(), this.getY(), this.getZ(), frenteX(), frenteZ(), alcance, alcance,
                this);
        double[] lejos = new double[1];
        double s = via.proyectar(l.getX(), l.getY(), l.getZ(), lejos);
        if (lejos[0] > 1.0) {
            // El líder no está sobre esta vía (tomó el otro lado de un desvío, o se descarriló): se lo sigue en recta
            double dx = l.getX() - this.getX();
            double dz = l.getZ() - this.getZ();
            double cuerda = Math.sqrt(dx * dx + dz * dz);
            s = dx * frenteX() + dz * frenteZ() >= 0.0 ? cuerda : -cuerda;
        }
        double distancia = Math.abs(s);
        // en una rampa empinada dos coches largos quedan a varios bloques de altura uno del otro
        if (distancia > separacion + Enganches.CORTE || Math.abs(l.getY() - this.getY()) > 3.0 + separacion * 0.8) {
            this.cortado = true;
            return Vec3.ZERO;
        }
        double lado = s >= 0.0 ? 1.0 : -1.0;
        // En marcha normal la distancia nunca se achica tanto: si pasa, es que este vagón no se puede mover
        this.encimado = distancia < separacion - 0.5;
        boolean yaSeMovio = vl.ultimoTick() == this.level().getGameTime();
        Vec3 movimientoLider = yaSeMovio
                ? new Vec3(l.getX() - l.xo, 0.0, l.getZ() - l.zo)
                : Enganches.movimientoPrevisto(l, profundidad);
        // El juego mueve las vagonetas en planta: en una subida, avanzar un bloque en planta es más de un bloque de vía
        Vec3 haciaLider = via.tangente(s);
        double enPlanta = Math.max(1.0E-6, haciaLider.x * haciaLider.x + haciaLider.z * haciaLider.z);
        double avanceLider = (movimientoLider.x * haciaLider.x + movimientoLider.z * haciaLider.z) / enPlanta;
        // Dónde estaba el líder al empezar esta vuelta: desde ahí se mide cuánto falta corregir
        double inicio = yaSeMovio ? s - avanceLider : s;
        double correccion = Mth.clamp(inicio - lado * separacion, -Enganches.CORRECCION, Enganches.CORRECCION);
        double avance = avanceLider + correccion;
        // con pasajeros el juego mueve la vagoneta un 25% menos: se compensa (como en la locomotora)
        if (this.isVehicle()) {
            avance /= 0.75;
        }
        Vec3 aqui = via.tangente(0.0);
        return new Vec3(aqui.x * avance, 0.0, aqui.z * avance);
    }

    private void alternarEnganche(Player jugador) {
        if (this.idLider != null) {
            soltar();
            jugador.displayClientMessage(Component.translatable("mensaje.locomotora.desenganchado")
                    .withStyle(ChatFormatting.YELLOW), true);
            return;
        }
        Enganches.Propuesta p = Enganches.buscarLiderPara(this);
        if (p == null) {
            jugador.displayClientMessage(Component.translatable("mensaje.locomotora.nada_que_enganchar")
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        engancharA(p);
        jugador.displayClientMessage(Component.translatable("mensaje.locomotora.enganchado", p.lider().getDisplayName())
                .withStyle(ChatFormatting.GREEN), true);
    }

    // ================================================================= tick y física

    @Override
    public void tick() {
        boolean servidor = !this.level().isClientSide();
        if (servidor && this.idLider != null) {
            Vec3 p = planDeLaVuelta(0);
            if (this.cortado) {
                soltar();
            } else if (this.lider != null) {
                Vec3 m = this.getDeltaMovement();
                this.setDeltaMovement(p.x, m.y, p.z);
            }
        }
        super.tick();
        if (this.isRemoved()) {
            return;
        }
        if (servidor) {
            this.ultimoTick = this.level().getGameTime();
            frenarAlTrenSiChoca();
            Enganches.empujarVecinos(this, this);
            Atropello.revisar(this, this);
        } else {
            tickCliente();
        }
        moverPartes();
    }

    /**
     * Si este vagón quedó trabado (contra un bloque, o descarrilado al final de la vía) y el tren lo sigue empujando,
     * frena a la cabeza del tren para que no se le meta encima: la locomotora se queda quieta y al rato avisa que está
     * trabada. Hacia el otro lado (para alejarse del vagón) puede andar.
     */
    private void frenarAlTrenSiChoca() {
        if (!this.encimado || this.idLider == null) {
            return;
        }
        // La cabeza del tren y el vagón enganchado a ella por este lado
        VagonEntity ultimo = this;
        AbstractMinecart cabeza = getLider();
        for (int i = 0; i < Enganches.PROFUNDIDAD_MAXIMA && cabeza instanceof VagonEntity w; i++) {
            AbstractMinecart siguiente = w.getLider();
            if (siguiente == null) {
                break;
            }
            ultimo = w;
            cabeza = siguiente;
        }
        if (!(cabeza instanceof VehiculoDeVia cv)) {
            return;
        }
        // Hacia dónde queda el resto del tren mirado desde la cabeza: se le quita la velocidad para ese lado
        double signo = ultimo.alFrenteDelLider() ? 1.0 : -1.0;
        double hx = cv.frenteX() * signo;
        double hz = cv.frenteZ() * signo;
        Vec3 m = cabeza.getDeltaMovement();
        double contra = m.x * hx + m.z * hz;
        if (contra > 0.0) {
            cabeza.setDeltaMovement(m.x - hx * contra, m.y, m.z - hz * contra);
        }
    }

    @Override
    public double getMaxSpeedWithRail() {
        double tope = Enganches.topeDeTren(this, super.getMaxSpeedWithRail());
        return this.idLider != null ? tope * RESERVA_DE_VELOCIDAD : tope;
    }

    @Override
    protected void moveAlongTrack(BlockPos pos, BlockState estado) {
        super.moveAlongTrack(pos, estado);
        actualizarRumboSegunMovimiento();
    }

    /**
     * El frente sigue la vía (el trazo dibujado, redondo en las curvas), pero nunca se da vuelta solo. En los giros
     * de 90° de las esquinas el movimiento no dice para qué lado va: se sigue como venía (ver LocomotoraEntity).
     */
    private void actualizarRumboSegunMovimiento() {
        Vec3 m = this.getDeltaMovement();
        double largo = Math.sqrt(m.x * m.x + m.z * m.z);
        if (largo < 1.0E-3) {
            return;
        }
        double ux = m.x / largo;
        double uz = m.z / largo;
        double coseno = ux * frenteX() + uz * frenteZ();
        if (coseno < -1.0E-4) {
            this.haciaAtras = true;
        } else if (coseno > 1.0E-4) {
            this.haciaAtras = false;
        }
        if (this.haciaAtras) {
            ux = -ux;
            uz = -uz;
        }
        float nuevo = Via.rumboSobreLaVia(this.level(), this.getX(), this.getY(), this.getZ(), ux, uz, this);
        if (Math.abs(Mth.wrapDegrees(nuevo - getRumbo())) > 0.5F) {
            setRumbo(nuevo);
        }
    }

    /** Los vehículos enganchados no se chocan entre sí: ya van a la distancia justa. */
    @Override
    public void push(Entity otra) {
        if (Enganches.enganchados(this, otra)) {
            return;
        }
        super.push(otra);
    }

    // ================================================================= interacción

    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        if (this.tipo.tieneAsientos() && jugador.getVehicle() == this) {
            return InteractionResult.PASS;
        }
        if (jugador.isSecondaryUseActive()) {
            if (!this.level().isClientSide()) {
                alternarEnganche(jugador);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }
        if (this.tipo.tieneAsientos()) {
            return subirAlCoche(jugador, mano);
        }
        return super.interact(jugador, mano);
    }

    /** Clic derecho en un coche: bajan o suben los animales que trae el jugador, o se sienta él. */
    private InteractionResult subirAlCoche(Player jugador, InteractionHand mano) {
        if (this.level().isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        ItemStack enMano = jugador.getItemInHand(mano);
        // con una correa en la mano: bajan los animales y aldeanos que van en el coche
        if (enMano.is(Items.LEAD)) {
            List<Entity> animales = new ArrayList<>();
            for (Entity p : this.getPassengers()) {
                if (!(p instanceof Player)) {
                    animales.add(p);
                }
            }
            if (!animales.isEmpty()) {
                for (Entity e : animales) {
                    e.stopRiding();
                }
                jugador.displayClientMessage(Component.translatable("mensaje.locomotora.bajaron", animales.size())
                        .withStyle(ChatFormatting.YELLOW), true);
                return InteractionResult.CONSUME;
            }
        }
        // los que el jugador trae atados suben primero (la correa le vuelve a la mano)
        List<Mob> atados = this.level().getEntitiesOfClass(Mob.class, jugador.getBoundingBox().inflate(10.0),
                m -> m.getLeashHolder() == jugador && m.getVehicle() == null);
        if (!atados.isEmpty()) {
            int subieron = 0;
            for (Mob m : atados) {
                if (this.getPassengers().size() >= this.tipo.cantidadAsientos()) {
                    break;
                }
                m.dropLeash(true, false);
                if (!jugador.getAbilities().instabuild && !jugador.getInventory().add(new ItemStack(Items.LEAD))) {
                    jugador.drop(new ItemStack(Items.LEAD), false);
                }
                this.asientoPedido = asientoLibreMasCercano(m.position());
                if (m.startRiding(this, true)) {
                    subieron++;
                }
            }
            this.asientoPedido = -1;
            jugador.displayClientMessage(Component.translatable(subieron > 0 ? "mensaje.locomotora.subieron"
                    : "mensaje.locomotora.coche_lleno", subieron).withStyle(subieron > 0 ? ChatFormatting.GREEN
                    : ChatFormatting.RED), true);
            return InteractionResult.CONSUME;
        }
        if (this.getPassengers().size() >= this.tipo.cantidadAsientos()) {
            jugador.displayClientMessage(Component.translatable("mensaje.locomotora.coche_lleno")
                    .withStyle(ChatFormatting.RED), true);
            return InteractionResult.CONSUME;
        }
        this.asientoPedido = asientoParaSubir(jugador);
        boolean subio = jugador.startRiding(this);
        this.asientoPedido = -1;
        return subio ? InteractionResult.CONSUME : InteractionResult.PASS;
    }

    /** Un golpe de alguien que va sentado adentro no le hace nada al coche. */
    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (this.tipo.tieneAsientos() && fuente.getEntity() != null && fuente.getEntity().getVehicle() == this) {
            return false;
        }
        return super.hurt(fuente, cantidad);
    }

    // ================================================================= coche: asientos y tramos de la caja

    @Override
    public boolean isMultipartEntity() {
        return this.partes != null;
    }

    @Override
    public PartEntity<?>[] getParts() {
        return this.partes;
    }

    /** En el cliente los tramos toman los números de entidad que tienen en el servidor (los que siguen al del coche). */
    @Override
    public void recreateFromPacket(ClientboundAddEntityPacket paquete) {
        super.recreateFromPacket(paquete);
        if (this.partes != null) {
            for (int i = 0; i < this.partes.length; i++) {
                this.partes[i].setId(paquete.getId() + 1 + i);
            }
        }
    }

    /** La caja del coche apoyada en la vía por sus dos bogies (igual que el modelo); se recalcula si se movió. */
    private void calcularMarco() {
        double x = this.getX();
        double y = this.getY();
        double z = this.getZ();
        float rumbo = getRumbo();
        if (x == this.marcoX && y == this.marcoY && z == this.marcoZ && rumbo == this.marcoRumbo) {
            return;
        }
        this.marcoX = x;
        this.marcoY = y;
        this.marcoZ = z;
        this.marcoRumbo = rumbo;
        double fx = frenteX();
        double fz = frenteZ();
        double delantero = -this.tipo.bogieDelantero();
        double espacio = this.tipo.bogieTrasero() - this.tipo.bogieDelantero();
        Via via = Via.alrededor(this.level(), x, y, z, fx, fz, espacio * 1.6 - delantero + 2.0, delantero + 2.0, this);
        Vec3 a = via.punto(delantero);
        Vec3 b = via.punto(via.atrasPorCuerda(delantero, espacio));
        Vec3 d = a.subtract(b);
        d = d.lengthSqr() < 1.0E-8 ? new Vec3(fx, 0.0, fz) : d.normalize();
        this.marcoDireccion = d;
        this.marcoOrigen = a.subtract(d.scale(delantero));
    }

    /** Un punto de la caja: tanto hacia adelante, tanto hacia el costado (-frenteZ, frenteX) y tanto de alto. */
    private Vec3 puntoDelCoche(double adelante, double costado, double alto) {
        calcularMarco();
        Vec3 d = this.marcoDireccion;
        double h = Math.sqrt(d.x * d.x + d.z * d.z);
        double lx = h < 1.0E-6 ? -frenteZ() : -d.z / h;
        double lz = h < 1.0E-6 ? frenteX() : d.x / h;
        return this.marcoOrigen.add(d.scale(adelante)).add(lx * costado, alto, lz * costado);
    }

    private Vec3 puntoAsiento(int i) {
        return puntoDelCoche(this.tipo.asientoAdelante(i), this.tipo.asientoCostado(i), this.tipo.asientoAlto(i));
    }

    /** Los tramos de la caja acompañan al coche (también en el cliente, para poder apuntarle). */
    private void moverPartes() {
        if (this.partes == null) {
            return;
        }
        double largo = this.tipo.largoFrente() + this.tipo.largoAtras();
        double paso = largo / this.partes.length;
        for (int i = 0; i < this.partes.length; i++) {
            ParteCoche p = this.partes[i];
            Vec3 c = puntoDelCoche(this.tipo.largoFrente() - (i + 0.5) * paso, 0.0, 0.0);
            p.xo = p.getX();
            p.yo = p.getY();
            p.zo = p.getZ();
            p.xOld = p.xo;
            p.yOld = p.yo;
            p.zOld = p.zo;
            p.setPos(c.x, c.y, c.z);
        }
    }

    /** Quién va en cada asiento (números de entidad; 0 = libre). Es una copia: se cambia y se guarda con guardarAsientos. */
    private int[] asientos() {
        int[] a = this.entityData.get(DATA_ASIENTOS).getIntArray("a");
        return Arrays.copyOf(a, this.tipo.cantidadAsientos());
    }

    private void guardarAsientos(int[] a) {
        CompoundTag tag = new CompoundTag();
        tag.putIntArray("a", a);
        this.entityData.set(DATA_ASIENTOS, tag);
    }

    /** El asiento de un pasajero (si todavía no llegó el dato, el que le toca por orden de subida). */
    private int asientoDe(Entity pasajero) {
        int[] a = asientos();
        for (int i = 0; i < a.length; i++) {
            if (a[i] == pasajero.getId()) {
                return i;
            }
        }
        int k = this.getPassengers().indexOf(pasajero);
        return Math.max(0, Math.min(a.length - 1, k));
    }

    /** El que va sentado en el asiento {@code i}, o null si está libre. */
    @Nullable
    public Entity enAsiento(int i) {
        if (!this.tipo.tieneAsientos() || i < 0 || i >= this.tipo.cantidadAsientos()) {
            return null;
        }
        int id = asientos()[i];
        if (id != 0) {
            for (Entity p : this.getPassengers()) {
                if (p.getId() == id) {
                    return p;
                }
            }
        }
        return null;
    }

    /** El asiento que toma el jugador que sube con clic derecho: el libre más cercano a él. */
    protected int asientoParaSubir(Player jugador) {
        return asientoLibreMasCercano(jugador.position());
    }

    /** El asiento libre más cercano a un lugar, o -1. */
    private int asientoLibreMasCercano(Vec3 desde) {
        int[] a = asientos();
        int mejor = -1;
        double distancia = Double.MAX_VALUE;
        for (int i = 0; i < a.length; i++) {
            if (a[i] != 0) {
                continue;
            }
            double d = puntoAsiento(i).distanceToSqr(desde);
            if (d < distancia) {
                distancia = d;
                mejor = i;
            }
        }
        return mejor;
    }

    @Override
    protected boolean canAddPassenger(Entity pasajero) {
        if (this.tipo.tieneAsientos()) {
            return this.getPassengers().size() < this.tipo.cantidadAsientos();
        }
        return super.canAddPassenger(pasajero);
    }

    @Override
    protected void addPassenger(Entity pasajero) {
        super.addPassenger(pasajero);
        if (!this.tipo.tieneAsientos() || this.level().isClientSide()) {
            return;
        }
        int[] a = asientos();
        // si alguien quedó anotado en un asiento pero ya no va en el coche, se libera
        for (int i = 0; i < a.length; i++) {
            int id = a[i];
            if (id != 0 && this.getPassengers().stream().noneMatch(p -> p.getId() == id)) {
                a[i] = 0;
            }
        }
        int elegido = this.asientoPedido >= 0 && this.asientoPedido < a.length && a[this.asientoPedido] == 0
                ? this.asientoPedido : -1;
        if (elegido < 0) {
            guardarAsientos(a);
            elegido = asientoLibreMasCercano(pasajero.position());
        }
        if (elegido >= 0) {
            a[elegido] = pasajero.getId();
        }
        guardarAsientos(a);
    }

    @Override
    protected void removePassenger(Entity pasajero) {
        super.removePassenger(pasajero);
        if (!this.tipo.tieneAsientos() || this.level().isClientSide()) {
            return;
        }
        int[] a = asientos();
        for (int i = 0; i < a.length; i++) {
            if (a[i] == pasajero.getId()) {
                a[i] = 0;
            }
        }
        guardarAsientos(a);
    }

    /** Cada pasajero en su asiento, siguiendo la caja del coche (también en las curvas y las subidas). */
    @Override
    protected void positionRider(Entity pasajero, Entity.MoveFunction mover) {
        if (!this.tipo.tieneAsientos()) {
            super.positionRider(pasajero, mover);
            return;
        }
        Vec3 p = puntoAsiento(asientoDe(pasajero));
        mover.accept(pasajero, p.x, p.y - PIERNAS, p.z);
    }

    /** Al levantarse, el pasajero baja por el costado de su asiento (si ahí no se puede, por el otro). */
    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity pasajero) {
        if (!this.tipo.tieneAsientos()) {
            return super.getDismountLocationForPassenger(pasajero);
        }
        int i = asientoDe(pasajero);
        double lado = this.tipo.asientoCostado(i) >= 0.0 ? 1.0 : -1.0;
        for (double s : new double[]{lado, -lado}) {
            Vec3 afuera = puntoDelCoche(this.tipo.asientoAdelante(i), s * 1.4, 0.0);
            BlockPos pos = BlockPos.containing(afuera);
            for (BlockPos q : new BlockPos[]{pos, pos.above(), pos.below()}) {
                Vec3 v = DismountHelper.findSafeDismountLocation(pasajero.getType(), this.level(), q, true);
                if (v != null) {
                    return v;
                }
            }
        }
        return super.getDismountLocationForPassenger(pasajero);
    }

    // ================================================================= cliente

    private void tickCliente() {
        this.recorridoAnterior = this.recorrido;
        double dx = this.getX() - this.xo;
        double dz = this.getZ() - this.zo;
        double distancia = Math.sqrt(dx * dx + dz * dz);
        if (distancia > 1.0E-4 && distancia < 2.0) {
            double sentido = dx * frenteX() + dz * frenteZ() >= 0.0 ? 1.0 : -1.0;
            this.recorrido += sentido * distancia;
        }
    }

    // ================================================================= romperlo y guardado

    @Override
    public void remove(Entity.RemovalReason motivo) {
        if (!this.level().isClientSide() && motivo.shouldDestroy()) {
            Enganches.soltarSeguidores(this);
        }
        super.remove(motivo);
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("Rumbo", getRumbo());
        if (this.idLider != null) {
            tag.putUUID("Lider", this.idLider);
            tag.putBoolean("AlFrenteDelLider", this.alFrenteDelLider);
            tag.putBoolean("LiderPorMiFrente", this.liderPorMiFrente);
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setRumbo(tag.getFloat("Rumbo"));
        this.idLider = tag.hasUUID("Lider") ? tag.getUUID("Lider") : null;
        this.alFrenteDelLider = tag.getBoolean("AlFrenteDelLider");
        this.liderPorMiFrente = tag.getBoolean("LiderPorMiFrente");
        this.lider = null;
    }
}
