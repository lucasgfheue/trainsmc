package com.locomotora.entidad;

import java.util.UUID;

import com.locomotora.registro.ModItems;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.entity.vehicle.MinecartChest;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import org.jetbrains.annotations.Nullable;

/**
 * Vagón de carga: una vagoneta con cofre (27 espacios) que se engancha a una locomotora o a otro vagón, ver
 * {@link TipoVagon} y {@link Enganches}.
 *
 * <ul>
 *   <li>Al ponerlo en la vía se engancha solo a la locomotora o al vagón que tenga al lado.</li>
 *   <li>Clic derecho: abre la carga.</li>
 *   <li>Shift + clic derecho: lo desengancha, o lo engancha a lo que tenga al lado.</li>
 * </ul>
 */
public class VagonEntity extends MinecartChest implements VehiculoDeVia {
    /** Enganchado puede ir apenas más rápido que el tope del riel, para alcanzar a la locomotora si quedó atrás. */
    private static final double RESERVA_DE_VELOCIDAD = 1.15;

    /** Hacia dónde mira el frente del vagón, en grados: el frente es (cos, sin) en (x, z). */
    private static final EntityDataAccessor<Float> DATA_RUMBO =
            SynchedEntityData.defineId(VagonEntity.class, EntityDataSerializers.FLOAT);

    private final TipoVagon tipo;

    // ------------------------------------------------- enganche (solo en el servidor)
    @Nullable
    private UUID idLider;
    /** ¿Está enganchado en el frente del líder (o en su cola)? */
    private boolean alFrenteDelLider;
    /** ¿El líder está del lado de mi frente (o de mi cola)? */
    private boolean liderPorMiFrente;
    @Nullable
    private AbstractMinecart lider;
    private long ultimoTick = Long.MIN_VALUE;
    private long vueltaDelPlan = Long.MIN_VALUE;
    private Vec3 plan = Vec3.ZERO;
    private boolean cortado;
    /** El líder se le metió encima más de medio bloque: este vagón está trabado (contra un bloque, o descarrilado). */
    private boolean encimado;

    // ------------------------------------------------- cliente (animación de las ruedas)
    private double recorrido;
    private double recorridoAnterior;

    public VagonEntity(EntityType<? extends VagonEntity> tipoEntidad, Level level, TipoVagon tipo) {
        super(tipoEntidad, level);
        this.tipo = tipo;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_RUMBO, 0.0F);
    }

    // ================================================================= identidad

    public TipoVagon getTipo() {
        return this.tipo;
    }

    @Override
    protected Item getDropItem() {
        return ModItems.porTipo(this.tipo).get();
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(ModItems.porTipo(this.tipo).get());
    }

    /** El modelo es más largo que la caja de choque: así no desaparece al mirarlo de cerca. */
    @Override
    public AABB getBoundingBoxForCulling() {
        double alcance = Math.max(this.tipo.largoFrente(), this.tipo.largoAtras()) + 1.0;
        return super.getBoundingBoxForCulling().inflate(alcance, 0.0, alcance).expandTowards(0.0, 1.5, 0.0);
    }

    // ================================================================= VehiculoDeVia

    @Override
    public float getRumbo() {
        return this.entityData.get(DATA_RUMBO);
    }

    public void setRumbo(float grados) {
        this.entityData.set(DATA_RUMBO, Mth.wrapDegrees(grados));
    }

    @Override
    public double frenteX() {
        return Math.cos(Math.toRadians(getRumbo()));
    }

    @Override
    public double frenteZ() {
        return Math.sin(Math.toRadians(getRumbo()));
    }

    @Override
    public double largoFrente() {
        return this.tipo.largoFrente();
    }

    @Override
    public double largoAtras() {
        return this.tipo.largoAtras();
    }

    @Override
    public double getRecorrido(float tickParcial) {
        return Mth.lerp(tickParcial, this.recorridoAnterior, this.recorrido);
    }

    @Override
    public long ultimoTick() {
        return this.ultimoTick;
    }

    /** Apunta el frente según una dirección (por ejemplo, hacia donde mira el jugador), alineado con el riel. */
    public void orientarSegunDireccion(double dx, double dz, @Nullable RailShape forma) {
        setRumbo(Enganches.rumboSegunDireccion(dx, dz, forma));
    }

    // ================================================================= enganche

    public boolean estaEnganchado() {
        return this.idLider != null;
    }

    /** ¿Este vagón va enganchado a {@code e}? */
    public boolean siguiendoA(Entity e) {
        return this.idLider != null && this.idLider.equals(e.getUUID());
    }

    public boolean alFrenteDelLider() {
        return this.alFrenteDelLider;
    }

    public boolean liderPorMiFrente() {
        return this.liderPorMiFrente;
    }

    /** La locomotora o el vagón al que va enganchado, si está cargado en el mundo. */
    @Nullable
    public AbstractMinecart getLider() {
        if (this.idLider == null) {
            return null;
        }
        if (this.lider != null && !this.lider.isRemoved()) {
            return this.lider;
        }
        this.lider = null;
        if (this.level() instanceof ServerLevel servidor
                && servidor.getEntity(this.idLider) instanceof AbstractMinecart v && v instanceof VehiculoDeVia) {
            this.lider = v;
        }
        return this.lider;
    }

    public void engancharA(Enganches.Propuesta p) {
        this.idLider = p.lider().getUUID();
        this.lider = p.lider();
        this.alFrenteDelLider = p.alFrenteDelLider();
        this.liderPorMiFrente = p.liderPorMiFrente();
        this.vueltaDelPlan = Long.MIN_VALUE;
        this.cortado = false;
        this.level().playSound(null, this.getX(), this.getY() + 0.5, this.getZ(), SoundEvents.CHAIN_PLACE,
                SoundSource.NEUTRAL, 1.0F, 0.9F);
    }

    public void soltar() {
        if (this.idLider == null) {
            return;
        }
        this.idLider = null;
        this.lider = null;
        this.cortado = false;
        this.level().playSound(null, this.getX(), this.getY() + 0.5, this.getZ(), SoundEvents.CHAIN_BREAK,
                SoundSource.NEUTRAL, 1.0F, 0.9F);
    }

    /** Lo que este vagón planea avanzar en esta vuelta del servidor (se calcula una sola vez por vuelta). */
    Vec3 planDeLaVuelta(int profundidad) {
        long ahora = this.level().getGameTime();
        if (this.vueltaDelPlan != ahora) {
            // se marca antes de calcular: si por error hubiera un círculo de enganches, no se repite para siempre
            this.vueltaDelPlan = ahora;
            this.plan = calcularPlan(profundidad);
        }
        return this.plan;
    }

    /**
     * Avanzar lo mismo que avanza el líder en esta vuelta (lo que ya avanzó, si el juego lo movió antes, o lo que va a
     * avanzar), más una corrección (con tope) para quedar a la distancia justa de él, medida siguiendo la vía.
     */
    private Vec3 calcularPlan(int profundidad) {
        this.cortado = false;
        this.encimado = false;
        AbstractMinecart l = getLider();
        if (!(l instanceof VehiculoDeVia vl)) {
            return this.getDeltaMovement(); // el líder no está cargado: por ahora va suelto
        }
        double separacion = Enganches.largo(vl, this.alFrenteDelLider) + Enganches.largo(this, this.liderPorMiFrente)
                + Enganches.HUECO;
        double alcance = separacion + Enganches.CORTE + 2.0;
        Via via = Via.alrededor(this.level(), this.getX(), this.getY(), this.getZ(), frenteX(), frenteZ(), alcance, alcance);
        double[] lejos = new double[1];
        double s = via.proyectar(l.getX(), l.getY(), l.getZ(), lejos);
        if (lejos[0] > 1.0) {
            // El líder no está sobre esta vía (tomó el otro lado de un desvío, o se descarriló): se lo sigue en recta
            double dx = l.getX() - this.getX();
            double dz = l.getZ() - this.getZ();
            double cuerda = Math.sqrt(dx * dx + dz * dz);
            s = dx * frenteX() + dz * frenteZ() >= 0.0 ? cuerda : -cuerda;
        }
        double distancia = Math.abs(s);
        if (distancia > separacion + Enganches.CORTE || Math.abs(l.getY() - this.getY()) > 4.0) {
            this.cortado = true;
            return Vec3.ZERO;
        }
        double lado = s >= 0.0 ? 1.0 : -1.0;
        // En marcha normal la distancia nunca se achica tanto: si pasa, es que este vagón no se puede mover
        this.encimado = distancia < separacion - 0.5;
        boolean yaSeMovio = vl.ultimoTick() == this.level().getGameTime();
        Vec3 movimientoLider = yaSeMovio
                ? new Vec3(l.getX() - l.xo, 0.0, l.getZ() - l.zo)
                : Enganches.movimientoPrevisto(l, profundidad);
        // El juego mueve las vagonetas en planta: en una subida, avanzar un bloque en planta es más de un bloque de vía
        Vec3 haciaLider = via.tangente(s);
        double enPlanta = Math.max(1.0E-6, haciaLider.x * haciaLider.x + haciaLider.z * haciaLider.z);
        double avanceLider = (movimientoLider.x * haciaLider.x + movimientoLider.z * haciaLider.z) / enPlanta;
        // Dónde estaba el líder al empezar esta vuelta: desde ahí se mide cuánto falta corregir
        double inicio = yaSeMovio ? s - avanceLider : s;
        double correccion = Mth.clamp(inicio - lado * separacion, -Enganches.CORRECCION, Enganches.CORRECCION);
        double avance = avanceLider + correccion;
        Vec3 aqui = via.tangente(0.0);
        return new Vec3(aqui.x * avance, 0.0, aqui.z * avance);
    }

    private void alternarEnganche(Player jugador) {
        if (this.idLider != null) {
            soltar();
            jugador.displayClientMessage(Component.translatable("mensaje.locomotora.desenganchado")
                    .withStyle(ChatFormatting.YELLOW), true);
            return;
        }
        Enganches.Propuesta p = Enganches.buscarLiderPara(this);
        if (p == null) {
            jugador.displayClientMessage(Component.translatable("mensaje.locomotora.nada_que_enganchar")
                    .withStyle(ChatFormatting.RED), true);
            return;
        }
        engancharA(p);
        jugador.displayClientMessage(Component.translatable("mensaje.locomotora.enganchado", p.lider().getDisplayName())
                .withStyle(ChatFormatting.GREEN), true);
    }

    // ================================================================= tick y física

    @Override
    public void tick() {
        boolean servidor = !this.level().isClientSide();
        if (servidor && this.idLider != null) {
            Vec3 p = planDeLaVuelta(0);
            if (this.cortado) {
                soltar();
            } else if (this.lider != null) {
                Vec3 m = this.getDeltaMovement();
                this.setDeltaMovement(p.x, m.y, p.z);
            }
        }
        super.tick();
        if (this.isRemoved()) {
            return;
        }
        if (servidor) {
            this.ultimoTick = this.level().getGameTime();
            frenarAlTrenSiChoca();
            Enganches.empujarVecinos(this, this);
        } else {
            tickCliente();
        }
    }

    /**
     * Si este vagón quedó trabado (contra un bloque, o descarrilado al final de la vía) y el tren lo sigue empujando,
     * frena a la cabeza del tren para que no se le meta encima: la locomotora se queda quieta y al rato avisa que está
     * trabada. Hacia el otro lado (para alejarse del vagón) puede andar.
     */
    private void frenarAlTrenSiChoca() {
        if (!this.encimado || this.idLider == null) {
            return;
        }
        // La cabeza del tren y el vagón enganchado a ella por este lado
        VagonEntity ultimo = this;
        AbstractMinecart cabeza = getLider();
        for (int i = 0; i < Enganches.PROFUNDIDAD_MAXIMA && cabeza instanceof VagonEntity w; i++) {
            AbstractMinecart siguiente = w.getLider();
            if (siguiente == null) {
                break;
            }
            ultimo = w;
            cabeza = siguiente;
        }
        if (!(cabeza instanceof VehiculoDeVia cv)) {
            return;
        }
        // Hacia dónde queda el resto del tren mirado desde la cabeza: se le quita la velocidad para ese lado
        double signo = ultimo.alFrenteDelLider() ? 1.0 : -1.0;
        double hx = cv.frenteX() * signo;
        double hz = cv.frenteZ() * signo;
        Vec3 m = cabeza.getDeltaMovement();
        double contra = m.x * hx + m.z * hz;
        if (contra > 0.0) {
            cabeza.setDeltaMovement(m.x - hx * contra, m.y, m.z - hz * contra);
        }
    }

    @Override
    public double getMaxSpeedWithRail() {
        double tope = super.getMaxSpeedWithRail();
        return this.idLider != null ? tope * RESERVA_DE_VELOCIDAD : tope;
    }

    @Override
    protected void moveAlongTrack(BlockPos pos, BlockState estado) {
        super.moveAlongTrack(pos, estado);
        actualizarRumboSegunMovimiento();
    }

    /** El frente sigue la dirección del riel (para tomar bien las curvas), pero nunca se da vuelta solo. */
    private void actualizarRumboSegunMovimiento() {
        Vec3 m = this.getDeltaMovement();
        double largo = Math.sqrt(m.x * m.x + m.z * m.z);
        if (largo < 1.0E-3) {
            return;
        }
        double ux = m.x / largo;
        double uz = m.z / largo;
        if (ux * frenteX() + uz * frenteZ() < 0.0) {
            ux = -ux;
            uz = -uz;
        }
        float nuevo = (float) Math.toDegrees(Math.atan2(uz, ux));
        if (Math.abs(Mth.wrapDegrees(nuevo - getRumbo())) > 0.5F) {
            setRumbo(nuevo);
        }
    }

    /** Los vehículos enganchados no se chocan entre sí: ya van a la distancia justa. */
    @Override
    public void push(Entity otra) {
        if (Enganches.enganchados(this, otra)) {
            return;
        }
        super.push(otra);
    }

    // ================================================================= interacción

    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        if (jugador.isSecondaryUseActive()) {
            if (!this.level().isClientSide()) {
                alternarEnganche(jugador);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }
        return super.interact(jugador, mano);
    }

    // ================================================================= cliente

    private void tickCliente() {
        this.recorridoAnterior = this.recorrido;
        double dx = this.getX() - this.xo;
        double dz = this.getZ() - this.zo;
        double distancia = Math.sqrt(dx * dx + dz * dz);
        if (distancia > 1.0E-4 && distancia < 2.0) {
            double sentido = dx * frenteX() + dz * frenteZ() >= 0.0 ? 1.0 : -1.0;
            this.recorrido += sentido * distancia;
        }
    }

    // ================================================================= romperlo y guardado

    @Override
    public void remove(Entity.RemovalReason motivo) {
        if (!this.level().isClientSide() && motivo.shouldDestroy()) {
            Enganches.soltarSeguidores(this);
        }
        super.remove(motivo);
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("Rumbo", getRumbo());
        if (this.idLider != null) {
            tag.putUUID("Lider", this.idLider);
            tag.putBoolean("AlFrenteDelLider", this.alFrenteDelLider);
            tag.putBoolean("LiderPorMiFrente", this.liderPorMiFrente);
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setRumbo(tag.getFloat("Rumbo"));
        this.idLider = tag.hasUUID("Lider") ? tag.getUUID("Lider") : null;
        this.alFrenteDelLider = tag.getBoolean("AlFrenteDelLider");
        this.liderPorMiFrente = tag.getBoolean("LiderPorMiFrente");
        this.lider = null;
    }
}
