package com.locomotora.entidad;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * Un tramo de la caja de un coche de pasajeros (o de un vagón de carga largo), para poder hacerle clic en cualquier
 * parte (no solo en el medio): el coche mide hasta 11 bloques y su caja de choque, como la de una vagoneta, apenas uno.
 * Lo que le pase a un tramo (clic derecho, golpes) le pasa al coche. No se guarda ni se manda a los clientes: cada lado
 * arma los suyos.
 */
public class ParteCoche extends PartEntity<VagonEntity> {
    private final EntityDimensions medida;

    public ParteCoche(VagonEntity coche, float ancho, float alto) {
        super(coche);
        this.medida = EntityDimensions.scalable(ancho, alto);
        this.refreshDimensions();
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    /** Se le puede apuntar, salvo desde adentro del mismo coche (si no, el pasajero no podría apuntar a nada). */
    @Override
    public boolean isPickable() {
        VagonEntity coche = this.getParent();
        if (coche.isRemoved()) {
            return false;
        }
        return !(this.level().isClientSide() && com.locomotora.cliente.Local.vaEn(coche));
    }

    /** Las flechas y demás proyectiles pasan de largo (no se rompe un coche por un tiro perdido). */
    @Override
    public boolean canBeHitByProjectile() {
        return false;
    }

    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        return !this.isInvulnerableTo(fuente) && this.getParent().hurt(fuente, cantidad);
    }

    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        return this.getParent().interact(jugador, mano);
    }

    @Override
    public ItemStack getPickResult() {
        return this.getParent().getPickResult();
    }

    @Override
    public boolean is(Entity otra) {
        return this == otra || this.getParent() == otra;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket(ServerEntity entidad) {
        throw new UnsupportedOperationException();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return this.medida;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }
}
