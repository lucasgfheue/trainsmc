package com.locomotora.entidad;

import java.util.List;
import java.util.Optional;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Un tren en marcha atropella a quien tenga delante (jugadores, animales, aldeanos, monstruos): pasado el paso de
 * hombre mata (ni la armadura ni las pociones salvan; un tótem sí); más despacio, empuja y lastima un poco. Cada
 * locomotora o vagón mira la punta que va adelante (la de su frente o, yendo para atrás, la de su cola) siguiendo la
 * vía, así también en las curvas. Los que van sentados en un tren no cuentan, y en creativo no pasa nada.
 */
final class Atropello {
    /** Desde esta rapidez (bloques por tick: 2 m/s, unos 7 km/h) el golpe mata. */
    static final double MORTAL = 0.1;
    /** Más despacio no hace nada (el juego solo empuja). */
    static final double MINIMA = 0.03;
    /** Medio ancho de la zona que barre la punta (los trenes miden un bloque y medio de ancho). */
    private static final double MEDIO_ANCHO = 0.8;
    /** Alto de la zona sobre los rieles. */
    private static final double ALTO = 2.6;
    /** El tipo de daño (data/locomotora/damage_type/atropello.json): "fue atropellado por un tren". */
    static final ResourceKey<DamageType> TIPO = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.fromNamespaceAndPath("locomotora", "atropello"));

    private Atropello() {
    }

    /** Se llama en cada vuelta del servidor, después de que el vehículo se movió. */
    static void revisar(AbstractMinecart v, VehiculoDeVia vv) {
        if (!(v.level() instanceof ServerLevel nivel)) {
            return;
        }
        double dx = v.getX() - v.xo;
        double dz = v.getZ() - v.zo;
        double rapidez = Math.sqrt(dx * dx + dz * dz);
        if (rapidez < MINIMA || rapidez > 2.0) {
            return; // quieto, o lo movieron de golpe (no anduvo hasta acá)
        }
        // casi siempre no hay nadie cerca: entonces ni se arma el camino de la vía
        double radio = Math.max(vv.largoFrente(), vv.largoAtras()) + 2.5;
        List<LivingEntity> cerca = nivel.getEntitiesOfClass(LivingEntity.class,
                v.getBoundingBox().inflate(radio, 2.0, radio).expandTowards(0.0, 1.5, 0.0), Atropello::sePuede);
        if (cerca.isEmpty()) {
            return;
        }
        double fx = vv.frenteX();
        double fz = vv.frenteZ();
        boolean haciaElFrente = dx * fx + dz * fz >= 0.0;
        double signo = haciaElFrente ? 1.0 : -1.0;
        double punta = haciaElFrente ? vv.largoFrente() : vv.largoAtras();
        // lo que la punta barre en esta vuelta y en la que viene (con un poco de margen)
        double desde = punta - 0.6;
        double hasta = punta + Math.max(0.6, rapidez * 2.0);
        Via via = Via.alrededor(nivel, v.getX(), v.getY(), v.getZ(), fx, fz, haciaElFrente ? 1.0 : hasta + 1.0,
                haciaElFrente ? hasta + 1.0 : 1.0, v);
        DamageSource fuente = null;
        for (LivingEntity e : cerca) {
            double s = signo * via.proyectar(e.getX(), v.getY(), e.getZ(), null);
            if (s < desde || s > hasta) {
                continue;
            }
            Vec3 q = via.punto(signo * s);
            double lx = e.getX() - q.x;
            double lz = e.getZ() - q.z;
            if (Math.sqrt(lx * lx + lz * lz) > MEDIO_ANCHO + e.getBbWidth() / 2.0) {
                continue;
            }
            double dy = e.getY() - q.y;
            if (dy > ALTO - 0.3 || dy + e.getBbHeight() < 0.0) {
                continue;
            }
            if (fuente == null) {
                fuente = fuente(nivel, v);
            }
            golpear(e, fuente, rapidez, via.tangente(signo * s).scale(signo));
        }
    }

    /** Los que van sentados en un tren, los espectadores, los de creativo y los soportes de armadura, no. */
    private static boolean sePuede(LivingEntity e) {
        if (!e.isAlive() || e.isSpectator() || e.isInvulnerable() || e instanceof ArmorStand) {
            return false;
        }
        if (e instanceof Player p && p.isCreative()) {
            return false;
        }
        return !(e.getRootVehicle() instanceof VehiculoDeVia);
    }

    private static void golpear(LivingEntity e, DamageSource fuente, double rapidez, Vec3 haciaDondeVa) {
        boolean mortal = rapidez >= MORTAL;
        // sale despedido para adelante (y un poco para arriba)
        double fuerza = mortal ? 0.5 + rapidez * 2.0 : 0.3;
        e.push(haciaDondeVa.x * fuerza, mortal ? 0.4 : 0.2, haciaDondeVa.z * fuerza);
        e.hurtMarked = true;
        e.hurt(fuente, mortal ? 1000.0F : 3.0F);
    }

    private static DamageSource fuente(ServerLevel nivel, AbstractMinecart v) {
        Optional<Holder.Reference<DamageType>> tipo = nivel.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolder(TIPO);
        // si faltara el tipo de daño (un paquete de datos que lo borró), un golpe común
        return tipo.<DamageSource>map(t -> new DamageSource(t, v)).orElseGet(() -> nivel.damageSources().generic());
    }
}
