package com.locomotora.mundo;

import java.util.ArrayList;
import java.util.List;

/**
 * Un estado de bloque escrito como en los comandos: {@code minecraft:oak_stairs[facing=east,half=bottom]}.
 * Las estaciones se arman con estos textos (sin clases del juego, así se prueban y se dibujan solas) y el juego los
 * convierte en bloques al generar el mundo.
 */
public final class Bloque {
    public static final String AIRE = "minecraft:air";

    private Bloque() {
    }

    /** El id sin propiedades. */
    public static String id(String estado) {
        int i = estado.indexOf('[');
        return i < 0 ? estado : estado.substring(0, i);
    }

    /** El valor de una propiedad, o null. */
    public static String prop(String estado, String clave) {
        for (String[] kv : props(estado)) {
            if (kv[0].equals(clave)) {
                return kv[1];
            }
        }
        return null;
    }

    public static List<String[]> props(String estado) {
        List<String[]> lista = new ArrayList<>();
        int i = estado.indexOf('[');
        if (i < 0) {
            return lista;
        }
        String cuerpo = estado.substring(i + 1, estado.length() - 1);
        if (cuerpo.isEmpty()) {
            return lista;
        }
        for (String par : cuerpo.split(",")) {
            int e = par.indexOf('=');
            lista.add(new String[]{par.substring(0, e), par.substring(e + 1)});
        }
        return lista;
    }

    public static String armar(String id, List<String[]> props) {
        if (props.isEmpty()) {
            return id;
        }
        StringBuilder sb = new StringBuilder(id).append('[');
        for (int i = 0; i < props.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(props.get(i)[0]).append('=').append(props.get(i)[1]);
        }
        return sb.append(']').toString();
    }

    /** El mismo estado con una propiedad cambiada (o agregada). */
    public static String con(String estado, String clave, String valor) {
        List<String[]> ps = props(estado);
        boolean hecho = false;
        for (String[] kv : ps) {
            if (kv[0].equals(clave)) {
                kv[1] = valor;
                hecho = true;
            }
        }
        if (!hecho) {
            ps.add(new String[]{clave, valor});
        }
        return armar(id(estado), ps);
    }

    /** El estado reflejado en z (el norte pasa a ser el sur): giros, bisagras, formas de escalera y conexiones. */
    public static String espejarZ(String estado) {
        List<String[]> ps = props(estado);
        if (ps.isEmpty()) {
            return estado;
        }
        String id = id(estado);
        String norte = null;
        String sur = null;
        for (String[] kv : ps) {
            if (kv[0].equals("north")) {
                norte = kv[1];
            } else if (kv[0].equals("south")) {
                sur = kv[1];
            }
        }
        for (String[] kv : ps) {
            switch (kv[0]) {
                case "facing" -> kv[1] = switch (kv[1]) {
                    case "north" -> "south";
                    case "south" -> "north";
                    default -> kv[1];
                };
                case "shape" -> kv[1] = switch (kv[1]) {
                    case "inner_left" -> "inner_right";
                    case "inner_right" -> "inner_left";
                    case "outer_left" -> "outer_right";
                    case "outer_right" -> "outer_left";
                    case "north_east" -> "south_east";
                    case "south_east" -> "north_east";
                    case "north_west" -> "south_west";
                    case "south_west" -> "north_west";
                    case "ascending_north" -> "ascending_south";
                    case "ascending_south" -> "ascending_north";
                    default -> kv[1];
                };
                case "hinge" -> kv[1] = kv[1].equals("left") ? "right" : "left";
                case "type" -> {
                    if (id.endsWith("chest")) {
                        kv[1] = switch (kv[1]) {
                            case "left" -> "right";
                            case "right" -> "left";
                            default -> kv[1];
                        };
                    }
                }
                case "rotation" -> kv[1] = Integer.toString(Math.floorMod(8 - Integer.parseInt(kv[1]), 16));
                case "north" -> kv[1] = sur;
                case "south" -> kv[1] = norte;
                default -> {
                }
            }
        }
        return armar(id, ps);
    }

    // ------------------------------------------------------------------ qué clase de bloque es (por el nombre)
    private static String nombre(String estado) {
        String id = id(estado);
        int i = id.indexOf(':');
        return i < 0 ? id : id.substring(i + 1);
    }

    public static boolean esValla(String estado) {
        String n = nombre(estado);
        return n.endsWith("_fence");
    }

    public static boolean esPortillo(String estado) {
        return nombre(estado).endsWith("_fence_gate");
    }

    public static boolean esPanel(String estado) {
        String n = nombre(estado);
        return n.endsWith("glass_pane") || n.equals("iron_bars");
    }

    public static boolean esMuro(String estado) {
        return nombre(estado).endsWith("_wall");
    }

    public static boolean esHoja(String estado) {
        return nombre(estado).endsWith("_leaves");
    }

    /** ¿Es un cubo entero y macizo? (a lo que se pegan vallas, paneles, muros y enredaderas) */
    public static boolean esCubo(String estado) {
        String n = nombre(estado);
        if (n.endsWith("_stairs") || n.endsWith("_slab") || n.endsWith("_fence") || n.endsWith("_fence_gate")
                || n.endsWith("_wall") || n.endsWith("_pane") || n.endsWith("_door") || n.endsWith("_trapdoor")
                || n.endsWith("_carpet") || n.endsWith("_leaves") || n.endsWith("_button") || n.endsWith("_plate")
                || n.endsWith("_sign") || n.endsWith("_torch") || n.endsWith("_bars") || n.endsWith("_rail")
                || n.endsWith("lantern") || n.endsWith("_bed") || n.endsWith("chest") || n.endsWith("_pot")
                || n.startsWith("potted_") || n.startsWith("via_") || n.equals("losa_balasto")) {
            return false;
        }
        return n.endsWith("_planks") || n.endsWith("_log") || n.endsWith("_wood") || n.endsWith("bricks")
                || n.endsWith("_tiles") || n.endsWith("cobblestone") || n.endsWith("cobbled_deepslate")
                || n.endsWith("stone") || n.endsWith("andesite") || n.endsWith("diorite") || n.endsWith("granite")
                || n.endsWith("deepslate") || n.endsWith("terracotta") || n.endsWith("_concrete")
                || n.endsWith("sandstone") || n.endsWith("glass") || n.endsWith("_wool") || n.equals("dirt")
                || n.equals("grass_block") || n.equals("coarse_dirt") || n.equals("podzol") || n.equals("gravel")
                || n.equals("sand") || n.equals("red_sand") || n.equals("moss_block") || n.equals("bookshelf")
                || n.equals("barrel") || n.equals("hay_block") || n.equals("coal_block") || n.endsWith("_block")
                || n.equals("balasto") || n.equals("packed_mud") || n.equals("mud") || n.equals("snow_block")
                || n.equals("clay") || n.equals("crafting_table") || n.equals("smooth_stone")
                || n.equals("chiseled_stone_bricks") || n.equals("lodestone") || n.equals("tuff")
                || n.equals("calcite") || n.equals("blackstone") || n.equals("basalt");
    }
}
