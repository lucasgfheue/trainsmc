package com.locomotora.mundo;

import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;

import com.locomotora.via.Pieza;

/**
 * Pone en un chunk lo que le toca de la red: la línea (con su balasto, terraplenes, cortes, puentes y túneles), las
 * estaciones y el camino de la estación a la aldea. Escribe en su chunk y, para sacar ramas de árboles que se
 * metieron en la vía, también en los 8 vecinos.
 */
public final class Generador {
    public static final String AIRE = Bloque.AIRE;
    public static final String BALASTO = Estacion.BALASTO;
    public static final String PIEDRA = "minecraft:stone_bricks";
    /** Bloques de alto libres sobre el riel (los trenes miden menos de 3). */
    public static final int GALIBO = 3;

    private Generador() {
    }

    public static void generar(Red red, Mundo m, int chunkX, int chunkZ) {
        int x0 = chunkX << 4;
        int z0 = chunkZ << 4;
        int rz = Math.floorDiv(z0, Red.REGION);
        int enFila = z0 - rz * Red.REGION;
        if (enFila > Red.BANDA1 + 52) {
            return;
        }
        int rx = Math.floorDiv(x0, Red.REGION);
        Red.Tramo[] tramos = new Red.Tramo[2];
        for (int k = rx - 1; k <= rx; k++) {
            Red.Tramo t = red.tramo(k, rz);
            if (t.toca(x0 - 24, z0 - 24, x0 + 39, z0 + 39)) {
                linea(m, t, chunkX, chunkZ);
                tramos[k - rx + 1] = t;
            }
        }
        boolean hubo = false;
        for (int k = rx - 1; k <= rx + 1; k++) {
            Red.Nodo n = red.nodo(k, rz);
            if (n.tipo == Red.PASO) {
                continue;
            }
            Estacion e = red.estacion(n);
            if (e.plano().toca(x0 - 16, z0 - 16, x0 + 31, z0 + 31)) {
                estacion(m, e, chunkX, chunkZ);
                hubo = true;
            }
            if (e instanceof EstacionAldea ea) {
                camino(m, ea, chunkX, chunkZ);
            }
        }
        // la estación nivela su terreno encima de las primeras celdas de la línea: se vuelven a poner los rieles
        if (hubo) {
            for (Red.Tramo t : tramos) {
                if (t != null) {
                    rieles(m, t, chunkX, chunkZ);
                }
            }
        }
    }

    private static void rieles(Mundo m, Red.Tramo t, int chunkX, int chunkZ) {
        for (int i : t.celdasCerca(chunkX, chunkZ)) {
            if (enChunk(t.cx[i], t.cz[i], chunkX, chunkZ)) {
                Plano.PiezaPlan pp = t.piezas.get(t.pieza[i]);
                Pieza.Celda c = pp.pieza.celda(t.cx[i], t.cy[i], t.cz[i]);
                if (c != null) {
                    m.ponerVia(pp, c);
                }
            }
        }
    }

    private static boolean enChunk(int x, int z, int chunkX, int chunkZ) {
        return (x >> 4) == chunkX && (z >> 4) == chunkZ;
    }

    private static boolean cerca(int x, int z, int chunkX, int chunkZ) {
        return Math.abs((x >> 4) - chunkX) <= 1 && Math.abs((z >> 4) - chunkZ) <= 1;
    }

    // ================================================================= la línea
    private static void linea(Mundo m, Red.Tramo t, int chunkX, int chunkZ) {
        int x0 = chunkX << 4;
        int z0 = chunkZ << 4;
        int[] dCol = new int[256];
        int[] celCol = new int[256];
        Arrays.fill(dCol, 99);
        int[] cercanas = t.celdasCerca(chunkX, chunkZ);
        for (int i : cercanas) {
            int cx = t.cx[i];
            int cz = t.cz[i];
            byte cl = t.clase[i];
            for (int d = 0; d <= Plano.TALUD + 1; d++) {
                if (cl == Red.EO) {
                    marcar(dCol, celCol, t, i, cx, cz + d, d, x0, z0);
                    marcar(dCol, celCol, t, i, cx, cz - d, d, x0, z0);
                } else if (cl == Red.NS) {
                    marcar(dCol, celCol, t, i, cx + d, cz, d, x0, z0);
                    marcar(dCol, celCol, t, i, cx - d, cz, d, x0, z0);
                } else {
                    for (int a = -d; a <= d; a++) {
                        marcar(dCol, celCol, t, i, cx + a, cz - d, d, x0, z0);
                        marcar(dCol, celCol, t, i, cx + a, cz + d, d, x0, z0);
                        marcar(dCol, celCol, t, i, cx - d, cz + a, d, x0, z0);
                        marcar(dCol, celCol, t, i, cx + d, cz + a, d, x0, z0);
                    }
                }
            }
        }
        for (int idx = 0; idx < 256; idx++) {
            if (dCol[idx] <= Plano.TALUD + 1) {
                columna(m, t, celCol[idx], x0 + (idx >> 4), z0 + (idx & 15), dCol[idx]);
            }
        }
        rieles(m, t, chunkX, chunkZ);
        // ramas y troncos de los árboles de los vecinos metidos en el gálibo
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) {
                    continue;
                }
                for (int i : t.celdasCerca(chunkX + dx, chunkZ + dz)) {
                    int cx = t.cx[i];
                    int cz = t.cz[i];
                    int y = t.cy[i];
                    for (int ax = -1; ax <= 1; ax++) {
                        for (int az = -1; az <= 1; az++) {
                            int x = cx + ax;
                            int z = cz + az;
                            if (enChunk(x, z, chunkX, chunkZ) || !cerca(x, z, chunkX, chunkZ)) {
                                continue;
                            }
                            for (int yy = y; yy <= y + GALIBO + 1; yy++) {
                                if (m.tipo(x, yy, z) == Mundo.ARBOL) {
                                    m.poner(x, yy, z, AIRE);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private static void marcar(int[] dCol, int[] celCol, Red.Tramo t, int i, int x, int z, int d, int x0, int z0) {
        int ix = x - x0;
        int iz = z - z0;
        if (ix < 0 || ix > 15 || iz < 0 || iz > 15) {
            return;
        }
        int idx = (ix << 4) | iz;
        boolean mejor = d < dCol[idx];
        if (!mejor && d == dCol[idx]) {
            // a igual distancia manda la recta (su costado es exacto); entre iguales, la más alta
            boolean curva = t.clase[i] == Red.CURVA;
            boolean otraCurva = t.clase[celCol[idx]] == Red.CURVA;
            mejor = (otraCurva && !curva) || (curva == otraCurva && t.cy[i] > t.cy[celCol[idx]]);
        }
        if (mejor) {
            dCol[idx] = d;
            celCol[idx] = i;
        }
    }

    /** Lo que va en la columna (x, z), a {@code d} bloques de costado de la celda i de la línea. */
    private static void columna(Mundo m, Red.Tramo t, int i, int x, int z, int d) {
        int y = t.cy[i];
        byte modo = t.modo[i];
        byte cl = t.clase[i];
        int largo = cl == Red.EO ? x : (cl == Red.NS ? z : x + z);
        int fase = Math.floorMod(largo, 8);
        boolean pilar = fase <= 1;
        if (d <= 1) {
            int hasta = modo == Red.CORTE ? y + GALIBO + 2 : y + GALIBO;
            for (int yy = d == 0 ? y + 1 : y; yy <= hasta; yy++) {
                limpiar(m, x, yy, z);
            }
            if (modo == Red.TUNEL) {
                revestir(m, x, y + GALIBO + 1, z);
            } else {
                // árboles colgando sobre la vía
                for (int yy = hasta + 1; yy <= hasta + 4; yy++) {
                    if (m.tipo(x, yy, z) == Mundo.ARBOL) {
                        m.poner(x, yy, z, AIRE);
                    }
                }
            }
            m.poner(x, y - 1, z, BALASTO);
            soporte(m, x, z, y, modo, cl, fase, d);
            if (modo == Red.TUNEL && d == 1 && Math.floorMod(largo, 12) == 0) {
                antorcha(m, t, i, x, z, y);
            }
            return;
        }
        if (d == 2) {
            switch (modo) {
                case Red.PUENTE -> bordePuente(m, x, z, y, cl, pilar, fase);
                case Red.TUNEL -> {
                    for (int yy = y; yy <= y + GALIBO; yy++) {
                        revestir(m, x, yy, z);
                    }
                    revestir(m, x, y - 1, z);
                }
                case Red.CORTE -> cortar(m, x, z, y, y + 12);
                case Red.TERRAPLEN -> rellenarHasta(m, x, z, y - 1);
                default -> {
                    for (int yy = y; yy <= y + 2; yy++) {
                        if (m.tipo(x, yy, z) == Mundo.ARBOL) {
                            m.poner(x, yy, z, AIRE);
                        }
                    }
                }
            }
            return;
        }
        // taludes
        if (modo == Red.TERRAPLEN) {
            rellenarHasta(m, x, z, y - 1 - (d - 2));
        } else if (modo == Red.CORTE) {
            cortar(m, x, z, y + (d - 2), y + 12);
        }
    }

    private static void limpiar(Mundo m, int x, int y, int z) {
        if (m.tipo(x, y, z) != Mundo.AIRE) {
            m.poner(x, y, z, AIRE);
        }
    }

    /** En el túnel: la roca (o el agua o la arena) que toca el gálibo pasa a ser ladrillo. */
    private static void revestir(Mundo m, int x, int y, int z) {
        int tp = m.tipo(x, y, z);
        if (tp == Mundo.SOLIDO || tp == Mundo.AGUA || tp == Mundo.LAVA) {
            m.poner(x, y, z, PIEDRA);
        }
    }

    private static void antorcha(Mundo m, Red.Tramo t, int i, int x, int z, int y) {
        int cx = t.cx[i];
        int cz = t.cz[i];
        String hacia;
        if (x > cx) {
            hacia = "west";
        } else if (x < cx) {
            hacia = "east";
        } else if (z > cz) {
            hacia = "north";
        } else {
            hacia = "south";
        }
        // solo de un lado
        if (((x + z) & 1) != 0) {
            return;
        }
        int wx = x + (x - cx);
        int wz = z + (z - cz);
        if (m.tipo(wx, y + 2, wz) == Mundo.SOLIDO || m.id(wx, y + 2, wz).equals(PIEDRA)) {
            m.poner(x, y + 2, z, "minecraft:wall_torch[facing=" + hacia + "]");
        }
    }

    /** Primer bloque firme bajo y0 (inclusive); {altura, 1 si hay agua o lava en el medio}. */
    private static int[] suelo(Mundo m, int x, int z, int y0) {
        int g = y0;
        int limite = Math.max(m.minY(), y0 - 120);
        boolean agua = false;
        while (g > limite) {
            int tp = m.tipo(x, g, z);
            if (tp == Mundo.SOLIDO) {
                break;
            }
            if (tp == Mundo.AGUA || tp == Mundo.LAVA) {
                agua = true;
            }
            g--;
        }
        return new int[]{g, agua ? 1 : 0};
    }

    /** Debajo del lecho: tierra hasta el suelo si el hueco es chico; si no, el tablero del puente y sus pilares. */
    private static void soporte(Mundo m, int x, int z, int y, byte modo, byte cl, int fase, int d) {
        int[] s = suelo(m, x, z, y - 2);
        int g = s[0];
        int hueco = (y - 2) - g;
        if (hueco <= 0) {
            return;
        }
        boolean agua = s[1] == 1;
        if (!agua && hueco <= 4 && modo != Red.PUENTE) {
            String[] mat = relleno(m.id(x, g, z));
            for (int yy = g + 1; yy <= y - 2; yy++) {
                m.poner(x, yy, z, mat[1]);
            }
            return;
        }
        m.poner(x, y - 2, z, PIEDRA);
        if (fase <= 1) {
            for (int yy = g + 1; yy <= y - 3; yy++) {
                m.poner(x, yy, z, PIEDRA);
            }
        } else if (hueco >= 2 && cl != Red.CURVA && (fase == 2 || fase == 7)) {
            String hacia = cl == Red.EO ? (fase == 2 ? "west" : "east") : (fase == 2 ? "north" : "south");
            m.poner(x, y - 3, z, "minecraft:stone_brick_stairs[facing=" + hacia + ",half=top,shape=straight,waterlogged="
                    + (m.tipo(x, y - 3, z) == Mundo.AGUA) + "]");
        }
    }

    private static void bordePuente(Mundo m, int x, int z, int y, byte cl, boolean pilar, int fase) {
        int[] s = suelo(m, x, z, y - 1);
        int g = s[0];
        int hueco = (y - 1) - g;
        if (hueco <= 1 && s[1] == 0) {
            // en la punta del puente, donde ya hay suelo: un hombro de tierra
            rellenarHasta(m, x, z, y - 1);
            return;
        }
        m.poner(x, y - 1, z, PIEDRA);
        m.poner(x, y - 2, z, PIEDRA);
        if (pilar) {
            for (int yy = g + 1; yy <= y - 3; yy++) {
                m.poner(x, yy, z, PIEDRA);
            }
        } else if (cl != Red.CURVA && (fase == 2 || fase == 7)) {
            String hacia = cl == Red.EO ? (fase == 2 ? "west" : "east") : (fase == 2 ? "north" : "south");
            m.poner(x, y - 3, z, "minecraft:stone_brick_stairs[facing=" + hacia + ",half=top,shape=straight,waterlogged="
                    + (m.tipo(x, y - 3, z) == Mundo.AGUA) + "]");
        }
        String baranda;
        if (cl == Red.EO) {
            baranda = "minecraft:stone_brick_wall[east=low,north=none,south=none,up=" + pilar + ",waterlogged=false,west=low]";
        } else if (cl == Red.NS) {
            baranda = "minecraft:stone_brick_wall[east=none,north=low,south=low,up=" + pilar + ",waterlogged=false,west=none]";
        } else {
            baranda = "minecraft:stone_brick_wall[east=none,north=none,south=none,up=true,waterlogged=false,west=none]";
        }
        m.poner(x, y, z, baranda);
        for (int yy = y + 1; yy <= y + GALIBO; yy++) {
            int tp = m.tipo(x, yy, z);
            if (tp == Mundo.ARBOL || tp == Mundo.PLANTA || tp == Mundo.SOLIDO) {
                m.poner(x, yy, z, AIRE);
            }
        }
    }

    /** Rellena la columna desde el suelo hasta {@code tope} (con pasto o lo que haya arriba del lugar). */
    private static void rellenarHasta(Mundo m, int x, int z, int tope) {
        int[] s = suelo(m, x, z, tope);
        int g = s[0];
        if (g >= tope) {
            return;
        }
        String[] mat = relleno(m.id(x, g, z));
        for (int yy = g + 1; yy < tope; yy++) {
            m.poner(x, yy, z, mat[1]);
        }
        m.poner(x, tope, z, mat[0]);
        if (m.tipo(x, tope + 1, z) == Mundo.PLANTA) {
            m.poner(x, tope + 1, z, AIRE);
        }
        if (Bloque.id(mat[0]).equals("minecraft:grass_block") && m.id(x, g, z).equals("minecraft:grass_block")) {
            m.poner(x, g, z, "minecraft:dirt");
        }
    }

    /** Talud de un corte: saca lo que haya desde {@code desde} hasta la cima (si no es una montaña) y deja pasto. */
    private static void cortar(Mundo m, int x, int z, int desde, int maximo) {
        int cima = m.cima(x, z);
        if (cima < desde) {
            return;
        }
        // la cima sin contar árboles
        int tierra = cima;
        while (tierra >= desde && m.tipo(x, tierra, z) != Mundo.SOLIDO) {
            tierra--;
        }
        if (tierra > maximo) {
            return;
        }
        String arriba = tierra >= desde ? m.id(x, tierra, z) : null;
        for (int yy = desde; yy <= cima; yy++) {
            if (m.tipo(x, yy, z) != Mundo.AIRE) {
                m.poner(x, yy, z, AIRE);
            }
        }
        if (arriba != null && m.tipo(x, desde - 1, z) == Mundo.SOLIDO) {
            String id = m.id(x, desde - 1, z);
            if (id.equals("minecraft:dirt") || id.equals("minecraft:coarse_dirt")) {
                m.poner(x, desde - 1, z, relleno(arriba)[0]);
            }
        }
    }

    /** {arriba, relleno} según el suelo del lugar. */
    public static String[] relleno(String suelo) {
        String n = suelo.startsWith("minecraft:") ? suelo.substring(10) : suelo;
        switch (n) {
            case "grass_block", "dirt", "coarse_dirt", "rooted_dirt", "moss_block", "mud", "clay", "farmland",
                 "dirt_path" -> {
                return new String[]{"minecraft:grass_block[snowy=false]", "minecraft:dirt"};
            }
            case "podzol" -> {
                return new String[]{"minecraft:podzol[snowy=false]", "minecraft:dirt"};
            }
            case "mycelium" -> {
                return new String[]{"minecraft:mycelium[snowy=false]", "minecraft:dirt"};
            }
            case "sand", "sandstone", "smooth_sandstone", "cut_sandstone" -> {
                return new String[]{"minecraft:sand", "minecraft:sandstone"};
            }
            case "red_sand", "red_sandstone" -> {
                return new String[]{"minecraft:red_sand", "minecraft:red_sandstone"};
            }
            case "snow_block", "powder_snow", "ice", "packed_ice", "blue_ice" -> {
                return new String[]{"minecraft:snow_block", "minecraft:dirt"};
            }
            case "gravel" -> {
                return new String[]{"minecraft:gravel", "minecraft:cobblestone"};
            }
            case "stone", "andesite", "diorite", "granite", "deepslate", "tuff", "calcite", "cobblestone",
                 "mossy_cobblestone", "dripstone_block", "terracotta", "white_terracotta", "orange_terracotta",
                 "yellow_terracotta", "brown_terracotta", "red_terracotta", "light_gray_terracotta" -> {
                return new String[]{suelo, suelo};
            }
            default -> {
                return new String[]{"minecraft:grass_block[snowy=false]", "minecraft:dirt"};
            }
        }
    }

    // ================================================================= estaciones
    private static void estacion(Mundo m, Estacion e, int chunkX, int chunkZ) {
        Plano p = e.plano();
        int x0 = chunkX << 4;
        int z0 = chunkZ << 4;
        int ax = Math.max(x0, p.minX());
        int bx = Math.min(x0 + 15, p.maxX());
        int az = Math.max(z0, p.minZ());
        int bz = Math.min(z0 + 15, p.maxZ());
        for (int x = ax; x <= bx; x++) {
            for (int z = az; z <= bz; z++) {
                Plano.Pisada pi = p.pisada(x, z);
                if (pi != null) {
                    nivelar(m, x, z, pi);
                } else {
                    Plano.Talud ta = p.talud(x, z);
                    if (ta != null) {
                        talud(m, x, z, ta);
                    }
                }
                TreeMap<Integer, String> col = p.columna(x, z);
                if (col != null) {
                    for (Map.Entry<Integer, String> b : col.entrySet()) {
                        m.poner(x, b.getKey(), z, b.getValue());
                        String tabla = p.botin(x, b.getKey(), z);
                        if (tabla != null) {
                            m.botin(x, b.getKey(), z, tabla);
                        }
                    }
                }
            }
        }
        for (Plano.PiezaPlan pp : p.piezas) {
            for (Pieza.Celda c : pp.pieza.celdas()) {
                if (enChunk(c.x, c.z, chunkX, chunkZ) && !pp.faltan.contains(Pieza.clave(c.x, c.y, c.z))) {
                    m.ponerVia(pp, c);
                }
            }
        }
        for (Plano.EntidadPlan en : p.entidades) {
            if (enChunk((int) Math.floor(en.x), (int) Math.floor(en.z), chunkX, chunkZ)) {
                m.entidad(en);
            }
        }
        // hojas de árboles vecinos metidas en la estación (cerca del piso)
        for (int x = Math.max(x0 - 16, p.minX()); x <= Math.min(x0 + 31, p.maxX()); x++) {
            for (int z = Math.max(z0 - 16, p.minZ()); z <= Math.min(z0 + 31, p.maxZ()); z++) {
                if (enChunk(x, z, chunkX, chunkZ)) {
                    continue;
                }
                Plano.Pisada pi = p.pisada(x, z);
                if (pi == null) {
                    continue;
                }
                for (int yy = pi.piso + 1; yy <= pi.piso + 8; yy++) {
                    if (p.obtener(x, yy, z) == null && m.tipo(x, yy, z) == Mundo.ARBOL) {
                        m.poner(x, yy, z, AIRE);
                    }
                }
            }
        }
    }

    /** La columna nivelada de la estación: se despeja arriba del piso y se rellena abajo. */
    private static void nivelar(Mundo m, int x, int z, Plano.Pisada pi) {
        int cima = m.cima(x, z);
        int g = cima;
        while (g > m.minY() && m.tipo(x, g, z) != Mundo.SOLIDO) {
            g--;
        }
        String natural = m.id(x, g, z);
        String[] mat = relleno(natural);
        int tope = Math.min(Math.max(cima, pi.limpiar), pi.limpiar + 40);
        for (int yy = pi.piso + 1; yy <= tope; yy++) {
            if (m.tipo(x, yy, z) != Mundo.AIRE) {
                m.poner(x, yy, z, AIRE);
            }
        }
        for (int yy = g + 1; yy < pi.piso; yy++) {
            m.poner(x, yy, z, mat[1]);
        }
        m.poner(x, pi.piso, z, pi.superficie != null ? pi.superficie : mat[0]);
    }

    private static void talud(Mundo m, int x, int z, Plano.Talud ta) {
        int cima = m.cima(x, z);
        int g = cima;
        while (g > m.minY() && m.tipo(x, g, z) != Mundo.SOLIDO) {
            g--;
        }
        int abajo = ta.piso - ta.d;
        int arriba = ta.piso + ta.d;
        if (g < abajo) {
            rellenarHasta(m, x, z, abajo);
        } else if (g > arriba) {
            cortar(m, x, z, arriba + 1, ta.limpiar + 16);
        }
    }

    // ================================================================= camino a la aldea
    private static void camino(Mundo m, EstacionAldea e, int chunkX, int chunkZ) {
        int fin = e.finCamino();
        for (int w = 15; w <= fin; w++) {
            for (int u = -1; u <= 1; u++) {
                int x = e.x(u);
                int z = e.z(w);
                if (!enChunk(x, z, chunkX, chunkZ)) {
                    continue;
                }
                int y = m.cima(x, z);
                while (y > m.minY()) {
                    int tp = m.tipo(x, y, z);
                    if (tp == Mundo.PLANTA || tp == Mundo.ARBOL) {
                        m.poner(x, y, z, AIRE);
                    } else if (tp != Mundo.AIRE) {
                        break;
                    }
                    y--;
                }
                int tp = m.tipo(x, y, z);
                String id = m.id(x, y, z);
                if (tp == Mundo.AGUA) {
                    m.poner(x, y, z, "minecraft:oak_planks");
                } else if (id.equals("minecraft:grass_block") || id.equals("minecraft:dirt") || id.equals("minecraft:coarse_dirt")
                        || id.equals("minecraft:podzol") || id.equals("minecraft:mycelium") || id.equals("minecraft:rooted_dirt")
                        || id.equals("minecraft:snow_block")) {
                    m.poner(x, y, z, "minecraft:dirt_path");
                } else if (id.equals("minecraft:sand") || id.equals("minecraft:red_sand")) {
                    m.poner(x, y, z, "minecraft:smooth_sandstone");
                }
            }
        }
    }
}
