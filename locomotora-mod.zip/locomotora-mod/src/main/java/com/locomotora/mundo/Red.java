package com.locomotora.mundo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.locomotora.via.ConfigVia;
import com.locomotora.via.Pieza;
import com.locomotora.via.TipoVia;

/**
 * La red de vías del mundo. El mundo se parte en las mismas regiones que usa el juego para las aldeas (544 bloques).
 * Cada fila de regiones tiene una línea infinita de oeste a este, y cada región un "nodo" por donde pasa la línea:
 * una estación de pueblo al lado de la aldea, una estación abandonada o un simple punto de paso. Entre dos nodos la
 * línea va recta y, si cambia de altura en z, da un rodeo en S con dos curvas. La altura sigue al terreno con
 * rampas (vías en subida), terraplenes, puentes y túneles.
 * <p>
 * Todo sale de la semilla y del terreno que va a tener el mundo, así cada chunk calcula lo mismo sin importar el orden
 * en que se generen.
 */
public final class Red {
    public static final int REGION = 544;
    /** La línea de cada fila va entre estos desvíos en z dentro de la región (las aldeas de las filas vecinas no llegan). */
    public static final int BANDA0 = 96;
    public static final int BANDA1 = 448;
    public static final int PASO_Z = 32;
    /** Distancia de la estación al centro de la aldea. */
    public static final int A_LA_ALDEA = 112;
    /** Ninguna parte del rodeo pasa a menos de esto (en x) del centro de una aldea. */
    public static final int LEJOS_DE_ALDEA = 96;
    public static final int RADIO = 15;
    public static final double PROB_ABANDONADA = 0.4;
    /** La vía nunca va a menos de esta altura sobre el nivel del mar (deja pasar botes bajo los puentes). */
    public static final int SOBRE_MAR = 3;

    public static final int PASO = 0;
    public static final int ALDEA = 1;
    public static final int ABANDONADA = 2;

    // modos de cada celda de la línea
    public static final byte LLANO = 0;
    public static final byte TERRAPLEN = 1;
    public static final byte PUENTE = 2;
    public static final byte CORTE = 3;
    public static final byte TUNEL = 4;

    // clase de celda
    public static final byte EO = 0;
    public static final byte NS = 1;
    public static final byte CURVA = 2;

    private final long semilla;
    private final Terreno terreno;
    private final Aldeas aldeas;
    private final boolean conAldeas;

    private final Memo<Nodo> nodos = new Memo<>(4096);
    private final Memo<Tramo> tramos = new Memo<>(160);
    private final Memo<Estacion> estaciones = new Memo<>(32);

    public Red(long semilla, Terreno terreno, Aldeas aldeas) {
        this.semilla = semilla;
        this.terreno = terreno;
        this.aldeas = aldeas;
        this.conAldeas = aldeas != null && aldeas.region() == REGION;
    }

    public long semilla() {
        return this.semilla;
    }

    public Terreno terreno() {
        return this.terreno;
    }

    private static long clave(int a, int b) {
        return ((long) a << 32) | (b & 0xFFFFFFFFL);
    }

    private int alMar() {
        return this.terreno.nivelMar() + SOBRE_MAR;
    }

    // ================================================================= nodos
    public static final class Nodo {
        public final int rx;
        public final int rz;
        public final int tipo;
        public final int x;
        public final int z;
        public final int y;
        public final int s;
        public final int medio;
        public final Aldeas.Aldea aldea;
        public final boolean arena;
        public final long semilla;

        Nodo(int rx, int rz, int tipo, int x, int z, int y, int s, int medio, Aldeas.Aldea aldea, boolean arena,
             long semilla) {
            this.rx = rx;
            this.rz = rz;
            this.tipo = tipo;
            this.x = x;
            this.z = z;
            this.y = y;
            this.s = s;
            this.medio = medio;
            this.aldea = aldea;
            this.arena = arena;
            this.semilla = semilla;
        }

        @Override
        public String toString() {
            String t = this.tipo == ALDEA ? "aldea" : this.tipo == ABANDONADA ? "abandonada" : "paso";
            return t + "(" + this.x + ", " + this.y + ", " + this.z + ")";
        }
    }

    public Nodo nodo(int rx, int rz) {
        return this.nodos.obtener(clave(rx, rz), () -> calcularNodo(rx, rz));
    }

    /** El nodo si ya está calculado (para no frenar el juego); si no, null. */
    public Nodo nodoSiEsta(int rx, int rz) {
        return this.nodos.mirar(clave(rx, rz));
    }

    /** Altura de la estación y qué tan apto es el lugar: {altura (mediana), dispersión (p90 - p10), % de agua}. */
    private int[] lugar(int x, int z, int s, int u0, int u1, int w0, int w1, int paso) {
        List<Integer> alturas = new ArrayList<>();
        int agua = 0;
        for (int u = u0; u <= u1; u += paso) {
            for (int w = w0; w <= w1; w += paso) {
                int a = this.terreno.altura(x + u, z + s * w);
                alturas.add(a);
                if (a <= this.terreno.nivelMar()) {
                    agua++;
                }
            }
        }
        Collections.sort(alturas);
        int n = alturas.size();
        int mediana = alturas.get(n / 2);
        int disp = alturas.get(Math.min(n - 1, (n * 9) / 10)) - alturas.get(n / 10);
        return new int[]{Math.max(mediana, alMar()), disp, (100 * agua) / n};
    }

    private Nodo calcularNodo(int rx, int rz) {
        long h = Ruido.hash(this.semilla, rx, rz, 0x4E0D0L);
        int x0 = rx * REGION;
        int z0 = rz * REGION;
        Aldeas.Aldea a = this.conAldeas ? this.aldeas.aldea(rx, rz) : null;
        if (a != null) {
            int zv = a.z() - z0;
            int mejor = Integer.MIN_VALUE;
            int[] mejorLugar = null;
            int preferida = zv <= (BANDA0 + BANDA1) / 2 + 64 ? zv + A_LA_ALDEA : zv - A_LA_ALDEA;
            for (int c : new int[]{preferida, 2 * zv - preferida}) {
                int q = Math.round(c / (float) PASO_Z) * PASO_Z;
                if (q < BANDA0 || q > BANDA1 || Math.abs(q - zv) < LEJOS_DE_ALDEA) {
                    continue;
                }
                int s = q < zv ? 1 : -1;
                int[] l = lugar(a.x(), z0 + q, s, -EstacionAldea.MEDIO - 1, EstacionAldea.MEDIO + 1, -2, 14, 6);
                // primero la preferida, salvo que esté en el agua o sea muy despareja
                int puntaje = -l[1] - l[2] / 4 + (c == preferida ? 6 : 0);
                if (mejorLugar == null || puntaje > mejor) {
                    mejor = puntaje;
                    mejorLugar = new int[]{q, s, l[0]};
                }
            }
            if (mejorLugar != null) {
                return new Nodo(rx, rz, ALDEA, a.x(), z0 + mejorLugar[0], mejorLugar[2], mejorLugar[1], EstacionAldea.MEDIO,
                        a, false, h);
            }
        }
        int q = BANDA0 + PASO_Z * (int) Math.floorMod(Ruido.mezclar(h ^ 0x51L), (long) ((BANDA1 - BANDA0) / PASO_Z + 1));
        if (Ruido.valor(h, 1, 2, 3) < PROB_ABANDONADA) {
            int x = x0 + 160 + (int) Math.floorMod(Ruido.mezclar(h ^ 0x52L), 225L);
            int s = q < (BANDA0 + BANDA1) / 2 ? 1 : -1;
            int[] l = lugar(x, z0 + q, s, -EstacionAbandonada.MEDIO - 2, EstacionAbandonada.MEDIO + 2, -14, 31, 7);
            if (l[2] <= 12 && l[1] <= 10) {
                boolean arena = this.terreno instanceof Biomas b && b.desierto(x, z0 + q);
                return new Nodo(rx, rz, ABANDONADA, x, z0 + q, l[0], s, EstacionAbandonada.MEDIO, null, arena, h);
            }
        }
        int x = x0 + 192 + (int) Math.floorMod(Ruido.mezclar(h ^ 0x53L), 161L);
        int y = Math.max(this.terreno.altura(x, z0 + q), alMar());
        return new Nodo(rx, rz, PASO, x, z0 + q, y, 1, 0, null, false, h);
    }

    /** Si el terreno sabe de biomas: para elegir los materiales de la estación abandonada. */
    public interface Biomas {
        boolean desierto(int x, int z);
    }

    // ================================================================= estaciones
    public Estacion estacion(Nodo n) {
        if (n.tipo == PASO) {
            return null;
        }
        return this.estaciones.obtener(clave(n.rx, n.rz), () -> n.tipo == ALDEA
                ? new EstacionAldea(n.x, n.y, n.z, n.s, n.semilla, Paleta.deAldea(n.aldea.estructura()),
                        Math.abs(n.aldea.z() - n.z))
                : new EstacionAbandonada(n.x, n.y, n.z, n.s, n.semilla, n.arena));
    }

    // ================================================================= tramos
    /** El tramo de línea entre el nodo (rx, rz) y el de la región siguiente hacia el este. */
    public static final class Tramo {
        public final int rx;
        public final int rz;
        public final List<Plano.PiezaPlan> piezas;
        public final int n;
        public final int[] cx;
        public final int[] cy;
        public final int[] cz;
        public final byte[] clase;
        public final byte[] modo;
        public final short[] terreno;
        public final int[] pieza;
        public final int minX;
        public final int maxX;
        public final int minZ;
        public final int maxZ;
        /** Por chunk (con 8 bloques de margen): qué celdas hay. */
        private final Map<Long, int[]> porChunk;

        Tramo(int rx, int rz, List<Plano.PiezaPlan> piezas, int[] cx, int[] cy, int[] cz, byte[] clase, byte[] modo,
              short[] terreno, int[] pieza) {
            this.rx = rx;
            this.rz = rz;
            this.piezas = piezas;
            this.n = cx.length;
            this.cx = cx;
            this.cy = cy;
            this.cz = cz;
            this.clase = clase;
            this.modo = modo;
            this.terreno = terreno;
            this.pieza = pieza;
            int a = Integer.MAX_VALUE;
            int b = Integer.MIN_VALUE;
            int c = Integer.MAX_VALUE;
            int d = Integer.MIN_VALUE;
            Map<Long, List<Integer>> mapa = new HashMap<>();
            for (int i = 0; i < this.n; i++) {
                a = Math.min(a, cx[i]);
                b = Math.max(b, cx[i]);
                c = Math.min(c, cz[i]);
                d = Math.max(d, cz[i]);
                for (int qx = (cx[i] - 8) >> 4; qx <= (cx[i] + 8) >> 4; qx++) {
                    for (int qz = (cz[i] - 8) >> 4; qz <= (cz[i] + 8) >> 4; qz++) {
                        mapa.computeIfAbsent(clave(qx, qz), k -> new ArrayList<>()).add(i);
                    }
                }
            }
            this.minX = a;
            this.maxX = b;
            this.minZ = c;
            this.maxZ = d;
            this.porChunk = new HashMap<>();
            for (Map.Entry<Long, List<Integer>> e : mapa.entrySet()) {
                int[] v = new int[e.getValue().size()];
                for (int i = 0; i < v.length; i++) {
                    v[i] = e.getValue().get(i);
                }
                this.porChunk.put(e.getKey(), v);
            }
        }

        /** Las celdas que caen en el chunk (cx, cz) o a menos de 8 bloques de él. */
        public int[] celdasCerca(int chunkX, int chunkZ) {
            int[] v = this.porChunk.get(clave(chunkX, chunkZ));
            return v == null ? new int[0] : v;
        }

        public boolean toca(int x0, int z0, int x1, int z1) {
            return this.maxX >= x0 && this.minX <= x1 && this.maxZ >= z0 && this.minZ <= z1;
        }
    }

    public Tramo tramo(int rx, int rz) {
        return this.tramos.obtener(clave(rx, rz), () -> calcularTramo(rx, rz));
    }

    /** El tramo si ya está calculado (para no frenar el juego); si no, null. */
    public Tramo tramoSiEsta(int rx, int rz) {
        return this.tramos.mirar(clave(rx, rz));
    }

    // ---------------------------------------------------------------- el recorrido
    private static final class Recorrido {
        final List<int[]> celdas = new ArrayList<>(); // {x, z, clase, corrida, forzadaPlana}

        void agregar(int x, int z, int clase, int corrida, boolean plana) {
            this.celdas.add(new int[]{x, z, clase, corrida, plana ? 1 : 0});
        }
    }

    private static Pieza curva(int x, int y, int z, Pieza.Rumbo rumbo, boolean izquierda, int radio) {
        ConfigVia c = new ConfigVia(TipoVia.CURVA);
        c.radio = radio;
        c.izquierda = izquierda;
        c.ajustar();
        return c.pieza(x, y, z, rumbo);
    }

    private Tramo calcularTramo(int rx, int rz) {
        Nodo a = nodo(rx, rz);
        Nodo b = nodo(rx + 1, rz);
        int xa = a.x + (a.medio > 0 ? a.medio + 1 : 0);
        int xb = b.x - b.medio - 1;
        Recorrido r = new Recorrido();
        int radio = 0;
        int xj = 0;
        if (a.z == b.z) {
            for (int x = xa; x <= xb; x++) {
                r.agregar(x, a.z, EO, 0, x == xa && a.medio == 0);
            }
        } else {
            int[] j = rodeo(a, b, xa, xb, rx, rz);
            radio = j[0];
            xj = j[1];
            int dz = Math.abs(b.z - a.z);
            int dir = b.z > a.z ? 1 : -1;
            int largo = dz - 2 * radio - 1;
            if (largo < 0) {
                // no entra el rodeo (no debería pasar: dz es múltiplo de 32): recta con salto
                for (int x = xa; x <= xb; x++) {
                    r.agregar(x, a.z, EO, 0, false);
                }
                radio = 0;
            } else {
                for (int x = xa; x < xj; x++) {
                    r.agregar(x, a.z, EO, 0, x == xa && a.medio == 0);
                }
                Pieza c1 = curva(xj, 0, a.z, Pieza.Rumbo.ESTE, dir < 0, radio);
                for (Pieza.Celda c : c1.celdas()) {
                    r.agregar(c.x, c.z, CURVA, 1, true);
                }
                for (int k = 0; k < largo; k++) {
                    r.agregar(xj + radio, a.z + dir * (radio + 1 + k), NS, 2, false);
                }
                Pieza c2 = curva(xj + radio, 0, a.z + dir * (radio + 1 + largo), dir > 0 ? Pieza.Rumbo.SUR : Pieza.Rumbo.NORTE,
                        dir > 0, radio);
                for (Pieza.Celda c : c2.celdas()) {
                    r.agregar(c.x, c.z, CURVA, 3, true);
                }
                for (int x = xj + 2 * radio + 1; x <= xb; x++) {
                    r.agregar(x, b.z, EO, 4, false);
                }
            }
        }
        return armarTramo(rx, rz, a, b, r, radio, xj);
    }

    /** {radio, x del comienzo} del rodeo en S, lejos de las aldeas y de las estaciones. */
    private int[] rodeo(Nodo a, Nodo b, int xa, int xb, int rx, int rz) {
        long h = Ruido.hash(this.semilla, rx, rz, 0x50DE0L);
        for (int radio : new int[]{RADIO, 10, 6}) {
            int lo = xa + 6;
            int hi = xb - 6 - 2 * radio;
            if (a.tipo == ALDEA) {
                lo = Math.max(lo, a.aldea.x() + LEJOS_DE_ALDEA);
            }
            if (b.tipo == ALDEA) {
                hi = Math.min(hi, b.aldea.x() - LEJOS_DE_ALDEA - 2 * radio);
            }
            if (lo <= hi) {
                return new int[]{radio, lo + (int) Math.floorMod(h, (long) (hi - lo + 1))};
            }
        }
        // no entra lejos de las aldeas: al medio, con el radio que quepa
        for (int radio : new int[]{RADIO, 10, 6, 3}) {
            int lo = xa + 2;
            int hi = xb - 2 - 2 * radio;
            if (lo <= hi) {
                return new int[]{radio, (lo + hi) / 2};
            }
        }
        return new int[]{3, xa};
    }

    // ---------------------------------------------------------------- perfil (programación dinámica)
    private static final int[] PASOS = {2, 3, 4, 1};
    /** Costo por cada bloque que sube una rampa, según el paso (1 cada 2, 3, 4 o 1). */
    private static final float[] COSTO_PASO = {4.0F, 2.0F, 1.2F, 20.0F};
    private static final float COSTO_EMPEZAR = 25.0F;
    /** Movimientos: 0 llano; 1 + 2·i sube con PASOS[i]; 2 + 2·i baja. */
    private static final int MOVS = 1 + 2 * PASOS.length;

    /**
     * Lo que cuesta que la vía quede {@code e} bloques por encima (positivo) o por debajo del terreno: hasta 2 de
     * diferencia no importa (lomitas que se cortan, pozos que se rellenan); muy por debajo es un túnel y lo hondo casi
     * no suma; muy por encima es un puente.
     */
    private static float desvio(int e) {
        if (e >= 0) {
            int d = Math.max(0, e - 2);
            return d <= 8 ? 0.35F * d : 2.8F + 0.25F * (d - 8);
        }
        int d = Math.max(0, -e - 2);
        return d <= 6 ? 0.45F * d : 2.7F + 0.12F * (d - 6);
    }

    private Tramo armarTramo(int rx, int rz, Nodo a, Nodo b, Recorrido r, int radio, int xj) {
        int n = r.celdas.size();
        int[] x = new int[n];
        int[] z = new int[n];
        byte[] clase = new byte[n];
        int[] corrida = new int[n];
        boolean[] plana = new boolean[n];
        for (int i = 0; i < n; i++) {
            int[] c = r.celdas.get(i);
            x[i] = c[0];
            z[i] = c[1];
            clase[i] = (byte) c[2];
            corrida[i] = c[3];
            plana[i] = c[4] == 1;
        }
        // terreno: cada 4 celdas, interpolado
        short[] terr = new short[n];
        if (n > 0) {
            int[] muestras = new int[(n - 1) / 4 + 2];
            int[] dondeM = new int[muestras.length];
            int m = 0;
            for (int i = 0; i < n; i += 4) {
                dondeM[m] = i;
                muestras[m++] = this.terreno.altura(x[i], z[i]);
            }
            if (dondeM[m - 1] != n - 1) {
                dondeM[m] = n - 1;
                muestras[m++] = this.terreno.altura(x[n - 1], z[n - 1]);
            }
            for (int k = 0; k < m - 1; k++) {
                int i0 = dondeM[k];
                int i1 = dondeM[k + 1];
                for (int i = i0; i <= i1; i++) {
                    double t = i1 == i0 ? 0.0 : (i - i0) / (double) (i1 - i0);
                    terr[i] = (short) Math.round(muestras[k] + (muestras[k + 1] - muestras[k]) * t);
                }
            }
            if (m == 1) {
                terr[0] = (short) muestras[0];
            }
        }
        // lo que se quiere seguir: el terreno suavizado (mediana y promedio), nunca bajo el mar
        int[] deseo = suavizar(terr, alMar());
        int[][] perfil = perfil(n, deseo, plana, corrida, a.y, b.y);
        return construir(rx, rz, b.z > a.z ? 1 : -1, x, z, clase, corrida, terr, perfil[0], perfil[1]);
    }

    private static int[] suavizar(short[] t, int minimo) {
        int n = t.length;
        int[] med = new int[n];
        int[] buf = new int[9];
        for (int i = 0; i < n; i++) {
            int k = 0;
            for (int j = i - 4; j <= i + 4; j++) {
                buf[k++] = t[Math.max(0, Math.min(n - 1, j))];
            }
            Arrays.sort(buf, 0, k);
            med[i] = buf[k / 2];
        }
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            int suma = 0;
            int k = 0;
            for (int j = i - 4; j <= i + 4; j++) {
                suma += med[Math.max(0, Math.min(n - 1, j))];
                k++;
            }
            out[i] = Math.max(minimo, Math.round(suma / (float) k));
        }
        return out;
    }

    /**
     * Elige la altura de cada celda: llano o rampas (de a un bloque cada PASOS celdas), plano en las curvas y en las
     * celdas forzadas, empezando en {@code y0} y terminando (después de la última) en {@code y1}.
     * Devuelve {alturas al empezar cada movimiento, movimiento que empieza en cada celda (-1 adentro de una rampa)}.
     */
    private int[][] perfil(int n, int[] deseo, boolean[] plana, int[] corrida, int y0, int y1) {
        int lo = Math.min(y0, y1);
        int hi = Math.max(y0, y1);
        for (int d : deseo) {
            lo = Math.min(lo, d);
            hi = Math.max(hi, d);
        }
        lo = Math.max(alMar(), lo - 20);
        hi = Math.min(this.terreno.maxY() - 24, hi + 20);
        if (hi < lo) {
            hi = lo;
        }
        int alto = hi - lo + 1;
        float inf = Float.POSITIVE_INFINITY;
        float[] costo = new float[(n + 1) * alto * MOVS];
        byte[] previo = new byte[(n + 1) * alto * MOVS];
        Arrays.fill(costo, inf);
        int s0 = y0 - lo;
        if (s0 < 0 || s0 >= alto) {
            s0 = Math.max(0, Math.min(alto - 1, s0));
        }
        costo[(0 * alto + s0) * MOVS] = 0.0F;
        float[] celda = new float[alto];
        for (int t = 0; t < n; t++) {
            for (int h = 0; h < alto; h++) {
                celda[h] = desvio(lo + h - deseo[t]);
            }
            for (int h = 0; h < alto; h++) {
                int base = (t * alto + h) * MOVS;
                float mejor = inf;
                for (int m = 0; m < MOVS; m++) {
                    mejor = Math.min(mejor, costo[base + m]);
                }
                if (mejor == inf) {
                    continue;
                }
                // llano
                {
                    int dest = ((t + 1) * alto + h) * MOVS;
                    for (int m = 0; m < MOVS; m++) {
                        float c = costo[base + m];
                        if (c == inf) {
                            continue;
                        }
                        float nc = c + celda[h];
                        if (nc < costo[dest]) {
                            costo[dest] = nc;
                            previo[dest] = (byte) m;
                        }
                    }
                }
                if (plana[t]) {
                    continue;
                }
                // rampas
                for (int i = 0; i < PASOS.length; i++) {
                    int p = PASOS[i];
                    if (t + p > n) {
                        continue;
                    }
                    boolean ok = true;
                    for (int k = 0; k < p; k++) {
                        if (plana[t + k] || corrida[t + k] != corrida[t]) {
                            ok = false;
                            break;
                        }
                    }
                    if (!ok) {
                        continue;
                    }
                    int medio = (p - 1) / 2;
                    for (int dir = -1; dir <= 1; dir += 2) {
                        int h2 = h + dir;
                        if (h2 < 0 || h2 >= alto) {
                            continue;
                        }
                        float suma = COSTO_PASO[i];
                        for (int k = 0; k < p; k++) {
                            int hh = h + (k > medio ? dir : 0);
                            suma += desvio(lo + hh - deseo[t + k]);
                        }
                        int mov = dir > 0 ? 1 + 2 * i : 2 + 2 * i;
                        int dest = ((t + p) * alto + h2) * MOVS + mov;
                        for (int m = 0; m < MOVS; m++) {
                            float c = costo[base + m];
                            if (c == inf) {
                                continue;
                            }
                            float nc = c + suma + (m != mov ? COSTO_EMPEZAR : 0.0F);
                            if (nc < costo[dest]) {
                                costo[dest] = nc;
                                previo[dest] = (byte) m;
                            }
                        }
                    }
                }
            }
        }
        int hf = Math.max(0, Math.min(alto - 1, y1 - lo));
        int mf = -1;
        float mejor = inf;
        for (int m = 0; m < MOVS; m++) {
            float c = costo[(n * alto + hf) * MOVS + m];
            if (c < mejor) {
                mejor = c;
                mf = m;
            }
        }
        int[] alturas = new int[n];
        int[] movs = new int[n];
        Arrays.fill(movs, -1);
        if (mf < 0) {
            // sin solución (desnivel imposible): todo llano a la altura de salida
            Arrays.fill(alturas, y0);
            Arrays.fill(movs, 0);
            return new int[][]{alturas, movs};
        }
        // de atrás para adelante
        int t = n;
        int h = hf;
        int m = mf;
        while (t > 0) {
            int len;
            int dir;
            if (m == 0) {
                len = 1;
                dir = 0;
            } else {
                int i = (m - 1) / 2;
                len = PASOS[i];
                dir = (m % 2 == 1) ? 1 : -1;
            }
            int t0 = t - len;
            int h0 = h - dir;
            movs[t0] = m;
            for (int k = 0; k < len; k++) {
                alturas[t0 + k] = lo + h0;
            }
            int pm = previo[(t * alto + h) * MOVS + m];
            t = t0;
            h = h0;
            m = pm;
        }
        return new int[][]{alturas, movs};
    }

    // ---------------------------------------------------------------- de movimientos a piezas
    private Tramo construir(int rx, int rz, int dirNS, int[] x, int[] z, byte[] clase, int[] corrida, short[] terr,
                            int[] alturas, int[] movs) {
        int n = x.length;
        List<Plano.PiezaPlan> piezas = new ArrayList<>();
        int[] piezaDe = new int[n];
        int[] cy = new int[n];
        int t = 0;
        while (t < n) {
            if (clase[t] == CURVA) {
                // la curva entera, plana
                int c = corrida[t];
                int t1 = t;
                while (t1 < n && corrida[t1] == c) {
                    t1++;
                }
                Pieza.Rumbo rumbo;
                boolean izq;
                int dz = z[t1 - 1] - z[t];
                if (c == 1) {
                    rumbo = Pieza.Rumbo.ESTE;
                    izq = dz < 0;
                } else {
                    rumbo = dz > 0 ? Pieza.Rumbo.SUR : Pieza.Rumbo.NORTE;
                    izq = dz > 0;
                }
                int radio = Math.abs(dz);
                Plano.PiezaPlan pp = Estacion.pieza(TipoVia.CURVA, x[t], alturas[t], z[t], rumbo, izq, 8, radio, 2, 2, null);
                piezas.add(pp);
                for (int k = t; k < t1; k++) {
                    piezaDe[k] = piezas.size() - 1;
                }
                t = t1;
                continue;
            }
            Pieza.Rumbo rumbo = clase[t] == EO ? Pieza.Rumbo.ESTE : (dirNS > 0 ? Pieza.Rumbo.SUR : Pieza.Rumbo.NORTE);
            int m = movs[t];
            if (m <= 0) {
                // llano: juntar las celdas llanas seguidas de la misma corrida (hasta 30)
                int t1 = t;
                while (t1 < n && t1 - t < ConfigVia.MAX && movs[t1] == 0 && clase[t1] != CURVA && corrida[t1] == corrida[t]
                        && alturas[t1] == alturas[t]) {
                    t1++;
                }
                if (t1 == t) {
                    t1 = t + 1;
                }
                Plano.PiezaPlan pp = Estacion.pieza(TipoVia.RECTA, x[t], alturas[t], z[t], rumbo, false, t1 - t, 6, 2, 2, null);
                piezas.add(pp);
                for (int k = t; k < t1; k++) {
                    piezaDe[k] = piezas.size() - 1;
                }
                t = t1;
                continue;
            }
            // rampa: unidades seguidas iguales, de a lo sumo 30 bloques
            int i = (m - 1) / 2;
            int p = PASOS[i];
            boolean sube = m % 2 == 1;
            int maxUnidades = ConfigVia.MAX / p;
            int unidades = 0;
            int t1 = t;
            while (t1 < n && movs[t1] == m && corrida[t1] == corrida[t] && unidades < maxUnidades) {
                t1 += p;
                unidades++;
            }
            Plano.PiezaPlan pp;
            if (sube) {
                pp = Estacion.pieza(TipoVia.SUBIDA, x[t], alturas[t], z[t], rumbo, false, 8, 6, unidades, p, null);
            } else {
                int ult = t1 - 1;
                int yBajo = alturas[t] - unidades;
                pp = Estacion.pieza(TipoVia.SUBIDA, x[ult], yBajo, z[ult], rumbo.contrario(), false, 8, 6, unidades, p, null);
            }
            piezas.add(pp);
            for (int k = t; k < t1; k++) {
                piezaDe[k] = piezas.size() - 1;
            }
            t = t1;
        }
        // la altura real de cada celda sale de su pieza
        byte[] modo = new byte[n];
        for (int k = 0; k < n; k++) {
            Pieza p = piezas.get(piezaDe[k]).pieza;
            int yy = Integer.MIN_VALUE;
            for (Pieza.Celda c : p.celdas()) {
                if (c.x == x[k] && c.z == z[k]) {
                    yy = c.y;
                    break;
                }
            }
            if (yy == Integer.MIN_VALUE) {
                yy = alturas[k];
            }
            cy[k] = yy;
            int sobre = yy - terr[k];
            boolean agua = terr[k] <= this.terreno.nivelMar();
            if (-sobre >= 6) {
                modo[k] = TUNEL;
            } else if (-sobre >= 1) {
                modo[k] = CORTE;
            } else if (agua || sobre > 4) {
                modo[k] = PUENTE;
            } else if (sobre >= 1) {
                modo[k] = TERRAPLEN;
            } else {
                modo[k] = LLANO;
            }
        }
        return new Tramo(rx, rz, piezas, x, cy, z, clase, modo, terr, piezaDe);
    }
}
