package com.locomotora.mundo;

import com.locomotora.via.Pieza;

/** El pedazo del mundo que se está generando (un chunk y sus vecinos), visto desde la red. */
public interface Mundo {
    int AIRE = 0;
    int AGUA = 1;
    int LAVA = 2;
    /** Pasto, flores, nieve en capa: se reemplaza sin más. */
    int PLANTA = 3;
    /** Troncos y hojas. */
    int ARBOL = 4;
    int SOLIDO = 5;

    int tipo(int x, int y, int z);

    /** El id del bloque (sin propiedades), por ejemplo minecraft:grass_block. */
    String id(int x, int y, int z);

    /** Altura del bloque más alto que no es aire en la columna (árboles incluidos). */
    int cima(int x, int z);

    void poner(int x, int y, int z, String estado);

    /** Un bloque de una pieza de vía, con la pieza guardada en él. */
    void ponerVia(Plano.PiezaPlan pieza, Pieza.Celda celda);

    void botin(int x, int y, int z, String tabla);

    void entidad(Plano.EntidadPlan e);

    int minY();

    int maxY();
}
