package com.locomotora.mundo;

/**
 * Números al azar que dependen solo de la posición y de una semilla: así cada chunk calcula lo mismo para sus bloques,
 * sin importar en qué orden se genere el mundo.
 */
public final class Ruido {
    private Ruido() {
    }

    public static long mezclar(long a) {
        a ^= a >>> 33;
        a *= 0xff51afd7ed558ccdL;
        a ^= a >>> 33;
        a *= 0xc4ceb9fe1a85ec53L;
        a ^= a >>> 33;
        return a;
    }

    public static long hash(long semilla, long a, long b, long c) {
        long h = mezclar(semilla ^ 0x9E3779B97F4A7C15L);
        h = mezclar(h ^ (a * 0x632BE59BD9B4E019L));
        h = mezclar(h ^ (b * 0x85157AF5L));
        h = mezclar(h ^ (c * 0x3C6EF372FE94F82BL));
        return h;
    }

    /** Número entre 0 (incluido) y 1 (excluido). */
    public static double valor(long semilla, long a, long b, long c) {
        return (hash(semilla, a, b, c) >>> 11) * 0x1.0p-53;
    }

    /** Entero entre 0 y n - 1. */
    public static int entero(long semilla, long a, long b, long c, int n) {
        return (int) Math.floorMod(hash(semilla, a, b, c), (long) n);
    }

    /** Ruido suave en 3D (valor interpolado en una grilla de tamaño 'escala'), entre 0 y 1. */
    public static double suave(long semilla, double x, double y, double z, double escala) {
        double fx = x / escala;
        double fy = y / escala;
        double fz = z / escala;
        long ix = (long) Math.floor(fx);
        long iy = (long) Math.floor(fy);
        long iz = (long) Math.floor(fz);
        double tx = curva(fx - ix);
        double ty = curva(fy - iy);
        double tz = curva(fz - iz);
        double c000 = valor(semilla, ix, iy, iz);
        double c100 = valor(semilla, ix + 1, iy, iz);
        double c010 = valor(semilla, ix, iy + 1, iz);
        double c110 = valor(semilla, ix + 1, iy + 1, iz);
        double c001 = valor(semilla, ix, iy, iz + 1);
        double c101 = valor(semilla, ix + 1, iy, iz + 1);
        double c011 = valor(semilla, ix, iy + 1, iz + 1);
        double c111 = valor(semilla, ix + 1, iy + 1, iz + 1);
        double x00 = c000 + (c100 - c000) * tx;
        double x10 = c010 + (c110 - c010) * tx;
        double x01 = c001 + (c101 - c001) * tx;
        double x11 = c011 + (c111 - c011) * tx;
        double y0 = x00 + (x10 - x00) * ty;
        double y1 = x01 + (x11 - x01) * ty;
        return y0 + (y1 - y0) * tz;
    }

    private static double curva(double t) {
        return t * t * (3.0 - 2.0 * t);
    }
}
