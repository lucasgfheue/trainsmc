package com.locomotora.mundo;

import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/**
 * Recuerda lo ya calculado (nodos, tramos, estaciones). Varios hilos generan chunks a la vez: si dos piden lo mismo,
 * lo calcula uno solo y el otro espera el resultado.
 */
final class Memo<T> {
    private final ConcurrentHashMap<Long, FutureTask<T>> mapa = new ConcurrentHashMap<>();
    private final int maximo;

    Memo(int maximo) {
        this.maximo = maximo;
    }

    /** Lo ya calculado, o null si todavía no está (no calcula nada ni espera). */
    T mirar(long clave) {
        FutureTask<T> tarea = this.mapa.get(clave);
        if (tarea == null || !tarea.isDone()) {
            return null;
        }
        try {
            return tarea.get();
        } catch (ExecutionException | InterruptedException e) {
            return null;
        }
    }

    T obtener(long clave, Callable<T> calculo) {
        FutureTask<T> tarea = this.mapa.get(clave);
        if (tarea == null) {
            if (this.mapa.size() >= this.maximo) {
                this.mapa.clear();
            }
            FutureTask<T> nueva = new FutureTask<>(calculo);
            tarea = this.mapa.putIfAbsent(clave, nueva);
            if (tarea == null) {
                tarea = nueva;
                tarea.run();
            }
        }
        try {
            return tarea.get();
        } catch (ExecutionException e) {
            this.mapa.remove(clave, tarea);
            Throwable causa = e.getCause();
            if (causa instanceof RuntimeException r) {
                throw r;
            }
            throw new IllegalStateException(causa);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException(e);
        }
    }
}
