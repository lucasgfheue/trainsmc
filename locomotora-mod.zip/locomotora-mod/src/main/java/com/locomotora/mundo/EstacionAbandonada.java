package com.locomotora.mundo;

import com.locomotora.via.Pieza;
import com.locomotora.via.TipoVia;

/**
 * Estación abandonada, grande: tres vías (la principal sigue en uso), dos andenes en isla y uno lateral bajo un galpón
 * de arcos con el techo de vidrio medio caído, el edificio de dos pisos con su torre del reloj, el tanque de agua, la
 * cabina de señales y la carbonera. En la vía muerta quedó un tren abandonado (locomotora y vagones con carga).
 * Todo con musgo, enredaderas, telarañas, escombros y plantas.
 */
public final class EstacionAbandonada extends Estacion {
    public static final int MEDIO = 50;
    /** u del desvío que lleva a la vía del tren abandonado. */
    public static final int CAMBIO = -40;
    public static final int VIA_TREN = 7;
    public static final int VIA_ROTA = -7;
    /** Última celda de la vía del tren (después va el tope). */
    public static final int FIN_TREN = 38;
    public static final String BOTIN = "locomotora:chests/estacion_abandonada";
    public static final String BOTIN_VAGON = "locomotora:chests/vagon_abandonado";

    public static final String[] LOCOMOTORAS = {"gp9_abandonada", "e8_abandonada", "rs3_abandonada", "rdc_abandonado",
            "class37_abandonada", "class20_abandonada", "m62_abandonada", "tep60_abandonada", "t478_abandonada",
            "kiha40_abandonado", "sharknose_abandonada"};
    /** Medio largo hacia el frente y hacia atrás de cada una (como en TipoLocomotora). */
    private static final double[][] LARGO_LOCO = {{5.31, 5.31}, {5.62, 5.81}, {5.19, 5.19}, {6.31, 6.31}, {5.50, 5.50},
            {5.38, 4.12}, {5.38, 5.38}, {5.62, 5.62}, {4.62, 4.62}, {6.19, 6.19}, {5.00, 5.69}};
    public static final String[] VAGONES = {"skip", "ladrillos", "carbon", "tolva", "volteo", "cisterna", "dovelas"};
    private static final double[] LARGO_VAGON = {0.875, 0.875, 0.8125, 1.6875, 1.375, 1.875, 1.625};
    private static final double HUECO = 0.06;

    /** Arcos del galpón (u) y su forma. */
    private static final int[] ARCOS = {-30, -20, -10, 0, 10, 20, 30};
    private static final int GALPON_U = 31;
    private static final int GALPON_W0 = -9;
    private static final int GALPON_W1 = 12;

    public final boolean arena;
    public final int locomotora;
    public final int[] vagones;

    public EstacionAbandonada(int ox, int oy, int oz, int s, long semilla, boolean arena) {
        super(ox, oy, oz, s, semilla);
        this.arena = arena;
        this.locomotora = entero(1, 0, LOCOMOTORAS.length);
        int n = 2 + entero(2, 0, 3);
        this.vagones = new int[n];
        for (int i = 0; i < n; i++) {
            this.vagones[i] = entero(3, i, VAGONES.length);
        }
        armar();
        corredor();
        this.plano.terminar();
    }

    @Override
    public int medio() {
        return MEDIO;
    }

    // ================================================================= materiales con desgaste
    private String ladrillo(int u, int h, int w) {
        double m = mancha(u, h, w, 4.0, 1);
        double r = azar(u, h, w, 2);
        if (this.arena) {
            return m < 0.35 ? MC + "sandstone" : (r < 0.15 ? MC + "chiseled_sandstone" : MC + "cut_sandstone");
        }
        if (m < 0.33 || r < 0.06) {
            return MC + "mossy_stone_bricks";
        }
        if (m > 0.72 || r > 0.93) {
            return MC + "cracked_stone_bricks";
        }
        return MC + "stone_bricks";
    }

    private String oscuro() {
        return this.arena ? MC + "cut_red_sandstone" : MC + "polished_deepslate";
    }

    private String columna() {
        return this.arena ? MC + "red_sandstone_wall" : MC + "polished_deepslate_wall";
    }

    private String teja() {
        return this.arena ? MC + "red_sandstone_slab" : MC + "deepslate_tile_slab";
    }

    private String tejaEscalera() {
        return this.arena ? MC + "red_sandstone_stairs" : MC + "deepslate_tile_stairs";
    }

    private String bordeAnden(int u, int w) {
        return azar(u, 0, w, 5) < 0.12 ? MC + "cobblestone" : (this.arena ? MC + "smooth_sandstone" : MC + "polished_andesite");
    }

    private String pisoAnden(int u, int w) {
        if (mancha(u, 0, w, 5.0, 6) > 0.7) {
            return this.arena ? MC + "sand" : MC + "moss_block";
        }
        return this.arena ? MC + "sandstone" : ladrillo(u, 0, w);
    }

    /** ¿Esta parte se cayó? Más arriba, más derrumbe. */
    private boolean caido(int u, int h, int w, double umbral) {
        return mancha(u, h, w, 6.0, 7) + 0.012 * h + 0.18 * azar(u, h, w, 8) > umbral;
    }

    // ================================================================= armado
    private void armar() {
        terreno();
        vias();
        andenes();
        galpon();
        edificio();
        torre();
        tanque();
        cabina();
        carbonera();
        plaza();
        vegetacion();
        tren();
    }

    private void terreno() {
        for (int u = -MEDIO - 2; u <= MEDIO + 2; u++) {
            for (int w = -14; w <= 31; w++) {
                String sup = null;
                double m = mancha(u, -1, w, 6.0, 9);
                if (m > 0.62) {
                    sup = MC + "coarse_dirt";
                } else if (m < 0.25) {
                    sup = MC + "gravel";
                }
                boolean alto = w >= 12 && w <= 31 && u >= -22 && u <= 22;
                this.plano.nivelar(x(u), z(w), y(-1), y(alto ? 27 : 15), sup);
            }
        }
        for (int u = -MEDIO - 2; u <= MEDIO + 2; u++) {
            for (int w = -1; w <= 1; w++) {
                this.plano.nivelar(x(u), z(w), y(-1), y(15), BALASTO);
            }
        }
        for (int u = CAMBIO; u <= FIN_TREN + 2; u++) {
            for (int w = 6; w <= 8; w++) {
                this.plano.nivelar(x(u), z(w), y(-1), y(15), mancha(u, -1, w, 4.0, 10) > 0.66 ? MC + "coarse_dirt" : BALASTO);
            }
        }
        for (int u = -38; u <= 38; u++) {
            for (int w = -8; w <= -6; w++) {
                double m = mancha(u, -1, w, 4.0, 11);
                this.plano.nivelar(x(u), z(w), y(-1), y(15), m > 0.58 ? MC + "coarse_dirt" : (m < 0.2 ? MC + "gravel" : BALASTO));
            }
        }
        // del desvío a la vía muerta, el lecho en diagonal
        for (int u = CAMBIO; u <= CAMBIO + 7; u++) {
            for (int w = 0; w <= 8; w++) {
                this.plano.nivelar(x(u), z(w), y(-1), y(15), BALASTO);
            }
        }
    }

    private void vias() {
        // la principal: recta, el desvío (hacia el lado del edificio) y recta
        rectas(-MEDIO, CAMBIO - 1, 0, 0, 0.0);
        boolean izq = this.s < 0;
        this.plano.piezas.add(pieza(TipoVia.DOS_CAMINOS, x(CAMBIO), y(0), z(0), Pieza.Rumbo.ESTE, izq, 4, 3, 2, 2, null));
        rectas(CAMBIO + 4, MEDIO, 0, 0, 0.0);
        // la curva que sigue al desvío y la vía muerta
        Pieza.Rumbo haciaAdentro = this.s > 0 ? Pieza.Rumbo.SUR : Pieza.Rumbo.NORTE;
        this.plano.piezas.add(pieza(TipoVia.CURVA, x(CAMBIO + 3), y(0), z(4), haciaAdentro, !izq, 8, 3, 2, 2, null));
        rectas(CAMBIO + 7, FIN_TREN, 0, VIA_TREN, 0.0);
        // el tope de la vía muerta
        poner(FIN_TREN + 1, 0, VIA_TREN, MC + "oak_log[axis=z]");
        poner(FIN_TREN + 1, 0, VIA_TREN - 1, MC + "oak_log[axis=x]");
        poner(FIN_TREN + 1, 0, VIA_TREN + 1, MC + "oak_log[axis=x]");
        poner(FIN_TREN + 2, 0, VIA_TREN, ladrillo(FIN_TREN + 2, 0, VIA_TREN));
        poner(FIN_TREN + 2, 1, VIA_TREN, MC + "stone_brick_wall");
        // la vía rota, del otro lado, sin conexión
        rectas(-36, 36, 0, VIA_ROTA, 0.3);
    }

    private void andenes() {
        int[][] andenes = {{2, 5}, {-5, -2}, {9, 12}};
        for (int[] a : andenes) {
            for (int u = -32; u <= 32; u++) {
                for (int w = a[0]; w <= a[1]; w++) {
                    boolean borde = (w == a[0] && a[0] != 9 && a[0] != -5) || w == a[1] && a[1] != 12 && a[1] != 5
                            || (a[0] == 9 && w == 9) || (a[0] == -5 && w == -5) || (a[1] == 5 && w == 5);
                    poner(u, 0, w, borde ? bordeAnden(u, w) : pisoAnden(u, w));
                }
            }
            for (int w = a[0]; w <= a[1]; w++) {
                String escalon = this.arena ? MC + "sandstone_slab" : MC + "stone_brick_slab";
                poner(-33, 0, w, losa(escalon, false));
                poner(33, 0, w, losa(escalon, false));
            }
        }
        // bancos y faroles entre los arcos
        for (int i = 0; i < ARCOS.length - 1; i++) {
            int um = (ARCOS[i] + ARCOS[i + 1]) / 2;
            // isla A (entre la principal y la vía del tren): bancos espalda con espalda
            if (azar(um, 1, 3, 12) < 0.8) {
                for (int du = -1; du <= 0; du++) {
                    poner(um + du, 1, 3, escalera(MC + "dark_oak_stairs", ADENTRO, false));
                    if (azar(um + du, 1, 4, 13) < 0.75) {
                        poner(um + du, 1, 4, escalera(MC + "dark_oak_stairs", AFUERA, false));
                    }
                }
            }
            // isla B
            if (azar(um, 1, -3, 14) < 0.6) {
                poner(um, 1, -4, escalera(MC + "dark_oak_stairs", AFUERA, false));
                poner(um + 1, 1, -4, losa(MC + "dark_oak_slab", false));
            }
            // faroles
            farolAnden(um + 3, 3);
            farolAnden(um + 3, -3);
            farolAnden(um + 3, 11);
        }
    }

    private void farolAnden(int u, int w) {
        double r = azar(u, 1, w, 15);
        int alto = r < 0.25 ? 1 : 3;
        for (int h = 1; h <= alto; h++) {
            poner(u, h, w, MC + "dark_oak_fence");
        }
        if (r > 0.45) {
            poner(u, alto + 1, w, farol(false));
        } else if (r > 0.3) {
            // el farol se cayó y quedó al lado
            ponerSiLibre(u + 1, 1, w, farol(false));
        }
    }

    // ================================================================= el galpón de arcos
    /** Altura del arco del galpón sobre w (media elipse entre GALPON_W0 y GALPON_W1). */
    private static double arco(double w) {
        double c = (GALPON_W0 + GALPON_W1) / 2.0;
        double a = (GALPON_W1 - GALPON_W0) / 2.0;
        double t = (w - c) / a;
        return 6.0 + 6.0 * Math.sqrt(Math.max(0.0, 1.0 - t * t));
    }

    private int alturaArco(int w) {
        return (int) Math.round(arco(w));
    }

    private void galpon() {
        // muro bajo del lado de afuera, con columnas
        for (int u = -GALPON_U; u <= GALPON_U; u++) {
            boolean enArco = false;
            for (int a : ARCOS) {
                enArco |= a == u;
            }
            int hasta = enArco ? 6 : 2;
            for (int h = 1; h <= hasta; h++) {
                if (!enArco && caido(u, h, GALPON_W0, 1.05)) {
                    continue;
                }
                poner(u, h, GALPON_W0, enArco ? oscuro() : ladrillo(u, h, GALPON_W0));
            }
            if (!enArco && !caido(u, 3, GALPON_W0, 1.0)) {
                poner(u, 3, GALPON_W0, losa(this.arena ? MC + "sandstone_slab" : MC + "stone_brick_slab", false));
            }
        }
        for (int a : ARCOS) {
            // columnas finas en los andenes en isla
            for (int w : new int[]{-4, 4}) {
                int tope = alturaArco(w);
                boolean rota = azar(a, 0, w, 16) < 0.15;
                for (int h = 1; h < tope; h++) {
                    if (rota && h > 3) {
                        break;
                    }
                    poner(a, h, w, columna());
                }
                if (rota) {
                    // el pedazo que se cayó, tirado en el andén
                    ponerSiLibre(a + 1, 1, w, columna());
                }
            }
            // la columna contra el edificio
            for (int h = 1; h <= 6; h++) {
                poner(a, h, GALPON_W1, oscuro());
            }
            // el arco (costilla): sin huecos aunque baje rápido
            int previa = -1;
            for (int w = GALPON_W0; w <= GALPON_W1; w++) {
                int h = alturaArco(w);
                boolean falta = caido(a, h, w, 1.2);
                int desde = previa < 0 ? h : Math.min(h, previa + 1);
                int hastaH = previa < 0 ? h : Math.max(h, previa - 1);
                for (int hh = desde; hh <= hastaH; hh++) {
                    if (!falta) {
                        poner(a, hh, w, oscuro());
                    }
                }
                previa = h;
            }
        }
        // el techo entre arcos: correas oscuras y vidrios (la mayoría rotos)
        int[] correas = {-6, 1, 8};
        for (int u = -GALPON_U; u <= GALPON_U; u++) {
            boolean enArco = false;
            for (int a : ARCOS) {
                enArco |= a == u;
            }
            if (enArco) {
                continue;
            }
            int previa = -1;
            for (int w = GALPON_W0; w <= GALPON_W1; w++) {
                int h = alturaArco(w);
                boolean correa = false;
                for (int c : correas) {
                    correa |= c == w;
                }
                String b;
                if (correa) {
                    if (caido(u, h, w, 1.12)) {
                        previa = h;
                        continue;
                    }
                    b = oscuro();
                } else {
                    // los vidrios que quedan, sobre todo junto a los arcos y a las correas (no sueltos en el aire)
                    int dArco = 99;
                    for (int a : ARCOS) {
                        dArco = Math.min(dArco, Math.abs(u - a));
                    }
                    boolean junto = dArco <= 2;
                    for (int c : correas) {
                        junto |= Math.abs(w - c) <= 1;
                    }
                    double m = mancha(u, h, w, 5.0, 17);
                    double r = azar(u, h, w, 18);
                    boolean queda = junto ? (m < 0.55 && r > 0.2) : (m < 0.28 && r > 0.4);
                    if (!queda) {
                        previa = h;
                        continue;
                    }
                    b = this.arena ? MC + "orange_stained_glass" : MC + "light_gray_stained_glass";
                }
                int desde = previa < 0 ? h : Math.min(h, previa + 1);
                int hastaH = previa < 0 ? h : Math.max(h, previa - 1);
                for (int hh = desde; hh <= hastaH; hh++) {
                    poner(u, hh, w, b);
                }
                previa = h;
            }
        }
        // escombros donde se cayó el techo (nunca sobre las vías en uso ni la del tren)
        for (int u = -GALPON_U; u <= GALPON_U; u++) {
            for (int w = GALPON_W0 + 1; w < GALPON_W1; w++) {
                if (Math.abs(w) <= 1 || (w >= 6 && w <= 8)) {
                    continue;
                }
                double m = mancha(u, 0, w, 3.0, 19);
                if (m > 0.7) {
                    boolean andenAca = (w >= 2 && w <= 5) || (w >= -5 && w <= -2) || (w >= 9 && w <= 12);
                    int h = andenAca ? 1 : 0;
                    String esc = azar(u, h, w, 20) < 0.5 ? (this.arena ? MC + "sandstone_slab[type=bottom,waterlogged=false]"
                            : MC + "cobblestone_slab[type=bottom,waterlogged=false]") : MC + "gravel";
                    ponerSiLibre(u, h, w, esc);
                    if (m > 0.8) {
                        ponerSiLibre(u, h + 1, w, MC + "cobblestone_slab[type=bottom,waterlogged=false]");
                    }
                }
            }
        }
        // telarañas arriba, junto a los arcos
        for (int a : ARCOS) {
            for (int w = GALPON_W0 + 1; w < GALPON_W1; w++) {
                int h = alturaArco(w) - 1;
                if (h >= 6 && azar(a, h, w, 21) < 0.18) {
                    ponerSiLibre(a + (azar(a, h, w, 22) < 0.5 ? 1 : -1), h, w, MC + "cobweb");
                }
            }
        }
    }

    // ================================================================= el edificio
    private static final int E_U = 20;
    private static final int E_W0 = 13;
    private static final int E_W1 = 26;
    private static final int PISO2 = 7;
    private static final int TECHO_H = 13;

    private void edificio() {
        // zócalo y piso en damero (con partes rotas)
        for (int u = -E_U; u <= E_U; u++) {
            for (int w = E_W0; w <= E_W1; w++) {
                boolean borde = u == -E_U || u == E_U || w == E_W0 || w == E_W1;
                String b;
                if (borde) {
                    b = this.arena ? MC + "sandstone" : MC + "polished_andesite";
                } else if (mancha(u, 0, w, 4.0, 23) > 0.68) {
                    b = this.arena ? MC + "sand" : (azar(u, 0, w, 24) < 0.5 ? MC + "moss_block" : MC + "coarse_dirt");
                } else {
                    boolean par = ((u + w) & 1) == 0;
                    b = this.arena ? (par ? MC + "smooth_sandstone" : MC + "cut_red_sandstone")
                            : (par ? MC + "polished_diorite" : MC + "polished_andesite");
                }
                poner(u, 0, w, b);
            }
        }
        // paredes: planta baja alta con ventanales en arco, cornisa, y el piso de arriba
        for (int u = -E_U; u <= E_U; u++) {
            pared(u, E_W0, true);
            pared(u, E_W1, false);
        }
        for (int w = E_W0 + 1; w < E_W1; w++) {
            paredLado(-E_U, w);
            paredLado(E_U, w);
        }
        // entrepiso en las alas (con partes caídas); el hall del medio es de doble altura
        for (int u = -E_U + 1; u < E_U; u++) {
            if (Math.abs(u) <= 8) {
                continue;
            }
            for (int w = E_W0 + 1; w < E_W1; w++) {
                if (caido(u, PISO2, w, 1.0)) {
                    continue;
                }
                poner(u, PISO2, w, MC + "dark_oak_planks");
            }
        }
        for (int w = E_W0 + 1; w < E_W1; w++) {
            for (int u : new int[]{-9, 9}) {
                if (!caido(u, PISO2, w, 1.05)) {
                    poner(u, PISO2, w, MC + "dark_oak_log[axis=z]");
                }
            }
        }
        techoEdificio();
        interior();
    }

    /** Pared larga (del andén o de la calle): pilastras cada 5, ventanales en arco y ventanas arriba. */
    private void pared(int u, int w, boolean andenLado) {
        boolean pilastra = Math.floorMod(u, 5) == 0 || Math.abs(u) == E_U;
        for (int h = 1; h <= 12; h++) {
            if (caido(u, h, w, 1.08 + (h < 4 ? 0.3 : 0.0))) {
                continue;
            }
            String b = ladrillo(u, h, w);
            if (pilastra) {
                b = h <= 6 && !this.arena ? MC + "stone_bricks" : b;
            } else if (h >= 2 && h <= 5) {
                // ventanal (o puerta del lado del andén)
                boolean puertaAca = andenLado && (u == -12 || u == -11 || u == 0 || u == 1 || u == 11 || u == 12) && h <= 4;
                if (puertaAca) {
                    continue;
                }
                if (h == 5 && (Math.floorMod(u, 5) == 1 || Math.floorMod(u, 5) == 4)) {
                    // la punta del arco del ventanal
                    String lado = Math.floorMod(u, 5) == 1 ? "west" : "east";
                    b = escalera(this.arena ? MC + "sandstone_stairs" : MC + "stone_brick_stairs",
                            lado.equals("west") ? "east" : "west", true);
                    b = Bloque.con(b, "facing", Math.floorMod(u, 5) == 1 ? "west" : "east");
                } else {
                    double r = azar(u, h, w, 25);
                    b = r < 0.35 ? null : (r < 0.7 ? MC + "glass_pane" : MC + "iron_bars");
                }
            } else if (h == 7) {
                b = escalera(this.arena ? MC + "sandstone_stairs" : MC + "stone_brick_stairs",
                        andenLado ? ADENTRO : AFUERA, true);
            } else if (h >= 9 && h <= 11 && Math.floorMod(u, 5) >= 2 && Math.floorMod(u, 5) <= 3) {
                double r = azar(u, h, w, 26);
                b = r < 0.4 ? null : MC + "glass_pane";
            }
            if (b != null) {
                poner(u, h, w, b);
            }
        }
    }

    private void paredLado(int u, int w) {
        boolean ventana = Math.floorMod(w, 4) == 1 || Math.floorMod(w, 4) == 2;
        for (int h = 1; h <= 12; h++) {
            if (caido(u, h, w, 1.1 + (h < 4 ? 0.3 : 0.0))) {
                continue;
            }
            String b = ladrillo(u, h, w);
            if (ventana && ((h >= 2 && h <= 4) || (h >= 9 && h <= 11))) {
                double r = azar(u, h, w, 27);
                b = r < 0.4 ? null : MC + "glass_pane";
            }
            if (b != null) {
                poner(u, h, w, b);
            }
        }
    }

    private void techoEdificio() {
        // techo de tejas a dos aguas (pendiente suave, de a media losa), con agujeros
        int medioW = (E_W0 + E_W1) / 2;    // 19 y 20 son la cumbrera
        for (int u = -E_U - 1; u <= E_U + 1; u++) {
            for (int w = E_W0 - 1; w <= E_W1 + 1; w++) {
                int paso = w <= medioW ? w - (E_W0 - 1) : (E_W1 + 1) - w;
                int medias = 2 * TECHO_H + paso;
                int h = medias / 2;
                boolean arriba = (medias & 1) == 1;
                if (caido(u, h, w, 0.98)) {
                    continue;
                }
                if (u >= -3 && u <= 3 && w >= 23) {
                    continue; // la torre
                }
                poner(u, h, w, losa(teja(), arriba));
                if (arriba && w >= E_W0 && w <= E_W1 && u >= -E_U && u <= E_U) {
                    // relleno bajo la losa de arriba para que no se vea el hueco
                    ponerSiLibre(u, h, w, losa(teja(), true));
                }
            }
        }
        // los muros de las puntas, en triángulo hasta el techo
        for (int w = E_W0; w <= E_W1; w++) {
            int paso = w <= medioW ? w - (E_W0 - 1) : (E_W1 + 1) - w;
            int tope = (2 * TECHO_H + paso) / 2;
            for (int h = TECHO_H; h < tope; h++) {
                for (int u : new int[]{-E_U, E_U}) {
                    if (!caido(u, h, w, 1.05)) {
                        poner(u, h, w, ladrillo(u, h, w));
                    }
                }
            }
        }
    }

    private void interior() {
        // boleterías: tabique de madera oscura con rejas, del lado oeste del hall
        for (int w = E_W0 + 2; w <= E_W1 - 2; w++) {
            for (int h = 1; h <= 4; h++) {
                boolean ventanilla = h == 2 && Math.floorMod(w, 3) == 0;
                if (caido(-8, h, w, 1.2)) {
                    continue;
                }
                poner(-8, h, w, ventanilla ? MC + "iron_bars" : MC + "dark_oak_planks");
            }
            if (Math.floorMod(w, 3) == 0) {
                poner(-7, 1, w, losa(MC + "dark_oak_slab", true));
            }
        }
        // bancos en filas (algunos rotos)
        for (int w : new int[]{16, 17, 21, 22}) {
            for (int u = -5; u <= 5; u++) {
                if (Math.abs(u) <= 1) {
                    continue;
                }
                double r = azar(u, 1, w, 28);
                if (r < 0.15) {
                    continue;
                }
                String facing = (w == 16 || w == 21) ? ADENTRO : AFUERA;
                poner(u, 1, w, r < 0.3 ? losa(MC + "dark_oak_slab", false) : escalera(MC + "dark_oak_stairs", facing, false));
            }
        }
        // la araña del hall, colgando de una cadena (con faroles, uno se cayó)
        for (int h = 8; h <= 12; h++) {
            poner(0, h, 19, MC + "chain[axis=y,waterlogged=false]");
        }
        poner(0, 7, 19, farol(true));
        poner(1, 8, 19, MC + "chain[axis=x,waterlogged=false]");
        poner(-1, 8, 19, MC + "chain[axis=x,waterlogged=false]");
        poner(2, 8, 19, MC + "chain[axis=x,waterlogged=false]");
        poner(2, 7, 19, farol(true));
        poner(-2, 8, 19, MC + "chain[axis=x,waterlogged=false]");
        poner(-2, 1, 20, farol(false));
        // cofres, barriles y cajas
        poner(-17, 1, 24, MC + "chest[facing=north,type=single,waterlogged=false]");
        botin(-17, 1, 24, BOTIN);
        poner(-16, 1, 24, MC + "barrel[facing=up,open=false]");
        poner(-18, 1, 24, MC + "barrel[facing=up,open=false]");
        poner(-15, 1, 15, MC + "cartography_table");
        poner(-18, 1, 15, MC + "bookshelf");
        poner(-18, 2, 15, MC + "bookshelf");
        poner(17, PISO2 + 1, 15, MC + "chest[facing=south,type=single,waterlogged=false]");
        botin(17, PISO2 + 1, 15, BOTIN);
        for (int u = 12; u <= 18; u += 2) {
            poner(u, 1, 24, MC + "barrel[facing=up,open=false]");
            if (azar(u, 2, 24, 29) < 0.5) {
                poner(u, 2, 24, MC + "barrel[facing=up,open=false]");
            }
        }
        poner(14, 1, 15, MC + "chest[facing=south,type=single,waterlogged=false]");
        botin(14, 1, 15, BOTIN);
        // escombros y musgo adentro
        for (int u = -E_U + 1; u < E_U; u++) {
            for (int w = E_W0 + 1; w < E_W1; w++) {
                double m = mancha(u, 1, w, 3.5, 30);
                if (m > 0.74) {
                    ponerSiLibre(u, 1, w, azar(u, 1, w, 31) < 0.5 ? MC + "cobblestone" : MC + "gravel");
                } else if (m < 0.2 && libre(u, 1, w) && !this.arena) {
                    poner(u, 1, w, MC + "moss_carpet");
                }
            }
        }
        // telarañas en los rincones
        int[][] rincones = {{-E_U + 1, E_W0 + 1}, {E_U - 1, E_W0 + 1}, {-E_U + 1, E_W1 - 1}, {E_U - 1, E_W1 - 1},
                {-9, E_W0 + 1}, {9, E_W1 - 1}, {-9, E_W1 - 1}, {9, E_W0 + 1}};
        for (int[] r : rincones) {
            for (int h : new int[]{5, 6, 11, 12}) {
                if (azar(r[0], h, r[1], 32) < 0.6) {
                    ponerSiLibre(r[0], h, r[1], MC + "cobweb");
                }
            }
        }
    }

    // ================================================================= la torre del reloj
    private void torre() {
        int w0 = 23;
        int w1 = 28;
        for (int h = 0; h <= 22; h++) {
            for (int u = -3; u <= 3; u++) {
                for (int w = w0; w <= w1; w++) {
                    boolean borde = Math.abs(u) == 3 || w == w0 || w == w1;
                    if (!borde) {
                        if (h == 0) {
                            poner(u, h, w, MC + "polished_andesite");
                        }
                        continue;
                    }
                    boolean esquina = Math.abs(u) == 3 && (w == w0 || w == w1);
                    String b = esquina ? oscuro() : ladrillo(u, h, w);
                    // la entrada en arco hacia la calle
                    if (w == w1 && Math.abs(u) <= 1 && h >= 1 && h <= 4) {
                        continue;
                    }
                    if (w == w1 && Math.abs(u) == 2 && h == 4) {
                        b = escalera(this.arena ? MC + "sandstone_stairs" : MC + "stone_brick_stairs", u < 0 ? "east" : "west", true);
                        b = Bloque.con(b, "facing", u < 0 ? "west" : "east");
                    }
                    if (w == w0 && Math.abs(u) <= 1 && h >= 1 && h <= 4) {
                        continue; // al hall
                    }
                    // ventanitas
                    if (Math.abs(u) == 3 && w > w0 && w < w1 && h % 5 == 2) {
                        b = MC + "iron_bars";
                    }
                    if (h > 18 && caido(u, h, w, 1.15)) {
                        continue;
                    }
                    poner(u, h, w, b);
                }
            }
        }
        // el reloj, mirando a la calle
        for (int du = -2; du <= 2; du++) {
            for (int dh = -2; dh <= 2; dh++) {
                int d2 = du * du + dh * dh;
                if (d2 > 6) {
                    continue;
                }
                String b = d2 >= 4 ? oscuro() : MC + "calcite";
                poner(du, 17 + dh, w1, b);
            }
        }
        poner(0, 17, w1, MC + "coal_block");
        poner(0, 18, w1, MC + "black_concrete");
        poner(1, 17, w1, MC + "black_concrete");
        // techo en punta y el pararrayos
        for (int capa = 0; capa <= 3; capa++) {
            int r = 3 - capa;
            int h = 23 + capa;
            for (int u = -r - 1; u <= r + 1; u++) {
                for (int w = w0 + capa - 1; w <= w1 - capa + 1; w++) {
                    boolean bordeU = Math.abs(u) == r + 1;
                    boolean bordeW = w == w0 + capa - 1 || w == w1 - capa + 1;
                    if (!bordeU && !bordeW) {
                        continue;
                    }
                    String facing = bordeW ? (w == w0 + capa - 1 ? ADENTRO : AFUERA) : (u < 0 ? "east" : "west");
                    if (caido(u, h, w, 1.2)) {
                        continue;
                    }
                    poner(u, h, w, escalera(tejaEscalera(), facing, false));
                }
            }
        }
        caja(-1, 1, 26, 26, w0 + 3, w1 - 3, teja() + "[type=double,waterlogged=false]");
        poner(0, 27, (w0 + w1) / 2, MC + "lightning_rod[facing=up,powered=false,waterlogged=false]");
    }

    // ================================================================= tanque de agua
    private void tanque() {
        int cu = 42;
        int cw = -12;
        for (int du : new int[]{-2, 2}) {
            for (int dw : new int[]{-2, 2}) {
                for (int h = 0; h <= 7; h++) {
                    poner(cu + du, h, cw + dw, MC + "spruce_log[axis=y]");
                }
            }
        }
        for (int d = -1; d <= 1; d++) {
            poner(cu + d, 3, cw - 2, MC + "spruce_fence");
            poner(cu + d, 3, cw + 2, MC + "spruce_fence");
            poner(cu - 2, 3, cw + d, MC + "spruce_fence");
            poner(cu + 2, 3, cw + d, MC + "spruce_fence");
        }
        caja(cu - 3, cu + 3, 8, 8, cw - 3, cw + 3, MC + "spruce_planks");
        for (int h = 9; h <= 13; h++) {
            for (int du = -3; du <= 3; du++) {
                for (int dw = -3; dw <= 3; dw++) {
                    int a = Math.abs(du);
                    int b = Math.abs(dw);
                    boolean anillo = (a == 3 && b <= 1) || (b == 3 && a <= 1) || (a == 2 && b == 2);
                    if (!anillo) {
                        if (a + b <= 3 && h <= 12) {
                            poner(cu + du, h, cw + dw, MC + "water[level=0]");
                        }
                        continue;
                    }
                    boolean aro = h == 10 || h == 12;
                    poner(cu + du, h, cw + dw, aro ? MC + "dark_oak_planks" : MC + "spruce_planks");
                }
            }
        }
        for (int du = -2; du <= 2; du++) {
            for (int dw = -2; dw <= 2; dw++) {
                poner(cu + du, 14, cw + dw, losa(MC + "spruce_slab", false));
            }
        }
        poner(cu, 14, cw, MC + "spruce_planks");
        poner(cu, 15, cw, losa(MC + "spruce_slab", false));
        // el caño hacia la vía
        poner(cu, 11, cw + 4, MC + "spruce_trapdoor[facing=south,half=top,open=false,powered=false,waterlogged=false]");
        poner(cu, 10, cw + 4, MC + "chain[axis=y,waterlogged=false]");
        for (int h = 1; h <= 7; h++) {
            poner(cu - 2, h, cw + 3, MC + "ladder[facing=south,waterlogged=false]");
        }
    }

    // ================================================================= cabina de señales
    private void cabina() {
        int u0 = -47;
        int u1 = -41;
        int w0 = 10;
        int w1 = 15;
        for (int h = 0; h <= 3; h++) {
            for (int u = u0; u <= u1; u++) {
                for (int w = w0; w <= w1; w++) {
                    boolean borde = u == u0 || u == u1 || w == w0 || w == w1;
                    if (borde || h == 0) {
                        poner(u, h, w, h == 0 ? MC + "stone_bricks" : MC + "bricks");
                    }
                }
            }
        }
        poner((u0 + u1) / 2, 1, w1, puerta(MC + "spruce_door", ADENTRO, false, "left"));
        poner((u0 + u1) / 2, 2, w1, puerta(MC + "spruce_door", ADENTRO, true, "left"));
        caja(u0, u1, 4, 4, w0, w1, MC + "dark_oak_planks");
        for (int h = 5; h <= 7; h++) {
            for (int u = u0; u <= u1; u++) {
                for (int w = w0; w <= w1; w++) {
                    boolean esquina = (u == u0 || u == u1) && (w == w0 || w == w1);
                    boolean borde = u == u0 || u == u1 || w == w0 || w == w1;
                    if (!borde) {
                        continue;
                    }
                    String b = esquina || h == 7 ? MC + "dark_oak_log[axis=y]" : (azar(u, h, w, 33) < 0.3 ? null : MC + "glass_pane");
                    if (h == 7 && !esquina) {
                        b = MC + "dark_oak_planks";
                    }
                    if (b != null) {
                        poner(u, h, w, b);
                    }
                }
            }
        }
        for (int u = u0 + 1; u <= u1 - 1; u++) {
            poner(u, 5, w0 + 1, MC + "lever[face=floor,facing=" + ADENTRO + ",powered=" + (azar(u, 5, w0 + 1, 34) < 0.3) + "]");
        }
        poner(u1 - 1, 5, w1 - 1, MC + "chest[facing=west,type=single,waterlogged=false]");
        botin(u1 - 1, 5, w1 - 1, BOTIN);
        // techo a dos aguas
        int mw = (w0 + w1) / 2;
        for (int u = u0 - 1; u <= u1 + 1; u++) {
            for (int w = w0 - 1; w <= w1 + 1; w++) {
                int h = 8 + Math.min(w - (w0 - 1), (w1 + 1) - w);
                if (caido(u, h, w, 1.15)) {
                    continue;
                }
                if (w == mw || w == mw + 1) {
                    poner(u, h, w, losa(MC + "dark_oak_slab", false));
                } else {
                    poner(u, h, w, escalera(MC + "dark_oak_stairs", w < mw ? ADENTRO : AFUERA, false));
                }
            }
        }
        // escalera de mano para subir
        for (int h = 1; h <= 4; h++) {
            poner(u1 + 1, h, w0 + 2, MC + "ladder[facing=east,waterlogged=false]");
        }
        poner(u1 + 1, 4, w0 + 2, MC + "ladder[facing=east,waterlogged=false]");
    }

    // ================================================================= carbonera
    private void carbonera() {
        int u0 = 40;
        int u1 = 47;
        int w0 = 10;
        int w1 = 14;
        for (int u = u0; u <= u1; u++) {
            for (int w = w0; w <= w1; w++) {
                boolean borde = u == u0 || u == u1 || w == w1;
                if (borde) {
                    poner(u, 0, w, MC + "cobblestone");
                    if (!caido(u, 1, w, 1.0)) {
                        poner(u, 1, w, MC + "cobblestone_wall");
                    }
                } else {
                    double r = azar(u, 0, w, 35);
                    poner(u, 0, w, r < 0.7 ? MC + "coal_block" : MC + "gravel");
                    if (mancha(u, 1, w, 3.0, 36) > 0.45) {
                        poner(u, 1, w, MC + "coal_block");
                    }
                }
            }
        }
    }

    // ================================================================= la plaza de la calle
    private void plaza() {
        for (int u = -16; u <= 16; u++) {
            for (int w = 27; w <= 31; w++) {
                if (u >= -3 && u <= 3 && w <= 28) {
                    continue;
                }
                double m = mancha(u, -1, w, 4.0, 37);
                String b = m > 0.62 ? MC + "grass_block[snowy=false]" : (m < 0.3 ? MC + "cobblestone" : MC + "stone_bricks");
                if (this.arena) {
                    b = m > 0.62 ? MC + "sand" : MC + "smooth_sandstone";
                }
                poner(u, -1, w, b);
            }
        }
        for (int u = -2; u <= 2; u++) {
            poner(u, 0, 29, escalera(this.arena ? MC + "sandstone_stairs" : MC + "stone_brick_stairs", AFUERA, false));
        }
        for (int u : new int[]{-10, 10}) {
            poner(u, 0, 30, MC + "dark_oak_fence");
            poner(u, 1, 30, MC + "dark_oak_fence");
            poner(u, 2, 30, MC + "dark_oak_fence");
            if (azar(u, 3, 30, 38) < 0.6) {
                poner(u, 3, 30, farol(false));
            }
        }
    }

    // ================================================================= plantas, enredaderas
    private void vegetacion() {
        String[] yuyos = this.arena ? new String[]{MC + "dead_bush"}
                : new String[]{MC + "short_grass", MC + "short_grass", MC + "fern", MC + "short_grass", MC + "dandelion",
                MC + "poppy", MC + "short_grass"};
        String suelo = this.arena ? MC + "coarse_dirt" : MC + "moss_block";
        for (int u = -MEDIO - 2; u <= MEDIO + 2; u++) {
            for (int w = -14; w <= 31; w++) {
                if (Math.abs(w) <= 1) {
                    continue;
                }
                if (!libre(u, 0, w) || !libre(u, -1, w)) {
                    // sobre los andenes: alfombras de musgo y yuyos sobre el musgo
                    String abajo = en(u, 0, w);
                    if (abajo != null && Bloque.id(abajo).equals(MC + "moss_block") && libre(u, 1, w)) {
                        double r = azar(u, 1, w, 39);
                        if (r < 0.35) {
                            poner(u, 1, w, MC + "moss_carpet");
                        } else if (r < 0.55) {
                            poner(u, 1, w, yuyos[(int) (azar(u, 1, w, 40) * yuyos.length)]);
                        }
                    }
                    continue;
                }
                boolean enVia = esVia(u, 0, w);
                if (enVia) {
                    continue;
                }
                double m = mancha(u, 0, w, 5.0, 41);
                double r = azar(u, 0, w, 42);
                boolean lechoDeVia = (w >= 6 && w <= 8) || (w >= -8 && w <= -6);
                if (r < 0.25 + 0.35 * m) {
                    poner(u, -1, w, lechoDeVia ? suelo : (this.arena ? MC + "coarse_dirt" : MC + "grass_block[snowy=false]"));
                    poner(u, 0, w, yuyos[(int) (azar(u, 0, w, 43) * yuyos.length)]);
                } else if (!lechoDeVia && r > 0.985 && !this.arena) {
                    poner(u, -1, w, MC + "grass_block[snowy=false]");
                    poner(u, 0, w, hojas(MC + "oak_leaves"));
                }
            }
        }
        // árboles que crecieron en el patio y en la isla B
        int[][] arboles = {{14, -4}, {-46, -11}, {46, 24}, {-30, 27}, {28, -12}, {-12, -12}};
        for (int[] a : arboles) {
            if (this.arena) {
                break;
            }
            arbol(a[0], a[1], azar(a[0], 0, a[1], 44) < 0.5);
        }
        // enredaderas colgando de las paredes de afuera del edificio y de las columnas del galpón
        for (int u = -E_U - 1; u <= E_U + 1; u++) {
            for (int w : new int[]{E_W0 - 1, E_W1 + 1}) {
                enredadera(u, w, 12);
            }
        }
        for (int w = E_W0; w <= E_W1; w++) {
            enredadera(-E_U - 1, w, 12);
            enredadera(E_U + 1, w, 12);
        }
        for (int a : ARCOS) {
            enredadera(a + 1, -4, 9);
            enredadera(a - 1, 4, 9);
            enredadera(a, GALPON_W0 - 1, 6);
        }
    }

    private void enredadera(int u, int w, int desde) {
        if (this.arena || mancha(u, desde, w, 4.0, 45) < 0.55) {
            return;
        }
        int largo = 2 + (int) (azar(u, desde, w, 46) * 8);
        for (int h = desde; h > desde - largo && h >= 1; h--) {
            if (!libre(u, h, w)) {
                break;
            }
            poner(u, h, w, MC + "vine[east=false,north=false,south=false,up=false,west=false]");
        }
    }

    private void arbol(int u, int w, boolean abedul) {
        String tronco = abedul ? MC + "birch_log[axis=y]" : MC + "oak_log[axis=y]";
        String hoja = hojas(abedul ? MC + "birch_leaves" : MC + "oak_leaves");
        int alto = 4 + (int) (azar(u, 0, w, 47) * 2);
        boolean enAnden = !libre(u, 0, w);
        int base = enAnden ? 1 : 0;
        if (enAnden) {
            poner(u, 0, w, MC + "dirt");
        } else {
            poner(u, -1, w, MC + "dirt");
        }
        for (int h = base; h < base + alto; h++) {
            poner(u, h, w, tronco);
        }
        for (int h = base + alto - 2; h <= base + alto + 1; h++) {
            int r = h >= base + alto ? 1 : 2;
            for (int du = -r; du <= r; du++) {
                for (int dw = -r; dw <= r; dw++) {
                    if (Math.abs(du) == r && Math.abs(dw) == r && azar(u + du, h, w + dw, 48) < 0.6) {
                        continue;
                    }
                    if (Math.abs(w + dw) <= 1 && h <= 4) {
                        continue; // nunca sobre la vía principal
                    }
                    ponerSiLibre(u + du, h, w + dw, hoja);
                }
            }
        }
    }

    // ================================================================= el tren abandonado
    private void tren() {
        // de atrás (contra el tope) hacia adelante: vagones y, al final, la locomotora mirando al desvío (oeste)
        double fin = x(FIN_TREN) + 1.0 - 0.15;
        double yy = y(0) + 0.0625;
        double zz = z(VIA_TREN) + 0.5;
        long[] ids = new long[2 * (this.vagones.length + 1)];
        for (int i = 0; i <= this.vagones.length; i++) {
            ids[2 * i] = Ruido.hash(this.semilla, 101, i, 0) | 1L;
            ids[2 * i + 1] = Ruido.hash(this.semilla, 102, i, 0) | 1L;
        }
        double[] centro = new double[this.vagones.length];
        double x = fin;
        for (int i = this.vagones.length - 1; i >= 0; i--) {
            double l = LARGO_VAGON[this.vagones[i]];
            centro[i] = x - l;
            x = centro[i] - l - HUECO;
        }
        double[] largoLoco = LARGO_LOCO[this.locomotora];
        double xLoco = x - largoLoco[1];
        // la locomotora: índice 0; vagón i: índice i + 1, enganchado al de adelante (más al oeste)
        this.plano.entidades.add(new Plano.EntidadPlan("locomotora_" + LOCOMOTORAS[this.locomotora], xLoco, yy, zz,
                180.0F, ids[0], ids[1], 0L, 0L, false, false, null));
        for (int i = 0; i < this.vagones.length; i++) {
            long la = ids[2 * i];
            long lb = ids[2 * i + 1];
            this.plano.entidades.add(new Plano.EntidadPlan("vagon_" + VAGONES[this.vagones[i]], centro[i], yy, zz,
                    180.0F, ids[2 * (i + 1)], ids[2 * (i + 1) + 1], la, lb, false, true, BOTIN_VAGON));
        }
    }
}
