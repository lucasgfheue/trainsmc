package com.locomotora.mundo;

/** Los materiales de una estación de pueblo, según la clase de aldea (llanura, desierto, sabana, nieve, taiga). */
public final class Paleta {
    public final String nombre;
    /** Tronco para esquinas y vigas (se le pone el eje); en el desierto es un bloque sin eje. */
    public final String tronco;
    public final String pared;
    public final String tablas;
    public final String losa;
    public final String escalera;
    public final String valla;
    public final String puerta;
    public final String trampilla;
    public final String base;
    public final String piso;
    public final String techo;
    public final String techoLosa;
    public final String techoMacizo;
    public final boolean techoPlano;
    public final String borde;
    public final String anden;
    public final String acento;
    public final String maceta;

    private Paleta(String nombre, String tronco, String pared, String tablas, String losa, String escalera, String valla,
                   String puerta, String trampilla, String base, String piso, String techo, String techoLosa,
                   String techoMacizo, boolean techoPlano, String borde, String anden, String acento, String maceta) {
        this.nombre = nombre;
        this.tronco = tronco;
        this.pared = pared;
        this.tablas = tablas;
        this.losa = losa;
        this.escalera = escalera;
        this.valla = valla;
        this.puerta = puerta;
        this.trampilla = trampilla;
        this.base = base;
        this.piso = piso;
        this.techo = techo;
        this.techoLosa = techoLosa;
        this.techoMacizo = techoMacizo;
        this.techoPlano = techoPlano;
        this.borde = borde;
        this.anden = anden;
        this.acento = acento;
        this.maceta = maceta;
    }

    private static String mc(String n) {
        return "minecraft:" + n;
    }

    public static final Paleta LLANURA = new Paleta("llanura", mc("oak_log"), mc("bricks"), mc("oak_planks"),
            mc("oak_slab"), mc("oak_stairs"), mc("oak_fence"), mc("oak_door"), mc("oak_trapdoor"), mc("cobblestone"),
            mc("spruce_planks"), mc("dark_oak_stairs"), mc("dark_oak_slab"), mc("dark_oak_planks"), false,
            mc("smooth_stone"), mc("stone_bricks"), mc("white_terracotta"), mc("potted_red_tulip"));
    public static final Paleta DESIERTO = new Paleta("desierto", mc("cut_sandstone"), mc("smooth_sandstone"),
            mc("birch_planks"), mc("smooth_sandstone_slab"), mc("smooth_sandstone_stairs"), mc("sandstone_wall"),
            mc("birch_door"), mc("birch_trapdoor"), mc("sandstone"), mc("smooth_sandstone"),
            mc("smooth_sandstone_stairs"), mc("smooth_sandstone_slab"), mc("cut_sandstone"), true,
            mc("cut_sandstone"), mc("smooth_sandstone"), mc("orange_terracotta"), mc("potted_cactus"));
    public static final Paleta SABANA = new Paleta("sabana", mc("acacia_log"), mc("acacia_planks"), mc("acacia_planks"),
            mc("acacia_slab"), mc("acacia_stairs"), mc("acacia_fence"), mc("acacia_door"), mc("acacia_trapdoor"),
            mc("cobblestone"), mc("acacia_planks"), mc("acacia_stairs"), mc("acacia_slab"), mc("acacia_planks"), false,
            mc("smooth_stone"), mc("terracotta"), mc("yellow_terracotta"), mc("potted_dead_bush"));
    public static final Paleta NIEVE = new Paleta("nieve", mc("stripped_spruce_log"), mc("spruce_planks"),
            mc("spruce_planks"), mc("spruce_slab"), mc("spruce_stairs"), mc("spruce_fence"), mc("spruce_door"),
            mc("spruce_trapdoor"), mc("stone_bricks"), mc("dark_oak_planks"), mc("stone_brick_stairs"),
            mc("stone_brick_slab"), mc("stone_bricks"), false, mc("stone_bricks"), mc("spruce_planks"),
            mc("light_blue_terracotta"), mc("potted_spruce_sapling"));
    public static final Paleta TAIGA = new Paleta("taiga", mc("spruce_log"), mc("spruce_planks"), mc("spruce_planks"),
            mc("spruce_slab"), mc("spruce_stairs"), mc("spruce_fence"), mc("spruce_door"), mc("spruce_trapdoor"),
            mc("mossy_cobblestone"), mc("oak_planks"), mc("spruce_stairs"), mc("spruce_slab"), mc("spruce_planks"),
            false, mc("cobblestone"), mc("spruce_planks"), mc("brown_terracotta"), mc("potted_fern"));

    /** La paleta según el id de la estructura de la aldea (minecraft:village_plains, ...). */
    public static Paleta deAldea(String estructura) {
        if (estructura == null) {
            return LLANURA;
        }
        if (estructura.contains("desert")) {
            return DESIERTO;
        }
        if (estructura.contains("savanna")) {
            return SABANA;
        }
        if (estructura.contains("snowy")) {
            return NIEVE;
        }
        if (estructura.contains("taiga")) {
            return TAIGA;
        }
        return LLANURA;
    }

    public static Paleta porNombre(String n) {
        return switch (n) {
            case "desierto" -> DESIERTO;
            case "sabana" -> SABANA;
            case "nieve" -> NIEVE;
            case "taiga" -> TAIGA;
            default -> LLANURA;
        };
    }

    /** Tronco con su eje (x, y o z); si el material no tiene eje, tal cual. */
    public String tronco(char eje) {
        String n = Bloque.id(this.tronco);
        if (n.endsWith("_log") || n.endsWith("_wood")) {
            return this.tronco + "[axis=" + eje + "]";
        }
        return this.tronco;
    }
}
