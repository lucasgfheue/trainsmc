package com.locomotora.mundo;

/**
 * Estación de pueblo, al lado de una aldea: andén con techito, faroles y bancos, y la casa de la estación (boletería,
 * sala de espera y un cofre) con los materiales de la aldea. Desde la puerta de atrás sale un camino hasta la aldea.
 */
public final class EstacionAldea extends Estacion {
    public static final int MEDIO = 16;
    public static final String BOTIN = "locomotora:chests/estacion_pueblo";

    public final Paleta p;
    /** Cuántos bloques hay (hacia +w) desde la vía hasta el centro de la aldea. */
    public final int haciaAldea;

    public EstacionAldea(int ox, int oy, int oz, int s, long semilla, Paleta paleta, int haciaAldea) {
        super(ox, oy, oz, s, semilla);
        this.p = paleta;
        this.haciaAldea = haciaAldea;
        armar();
        corredor();
        this.plano.terminar();
    }

    @Override
    public int medio() {
        return MEDIO;
    }

    /** El camino a la aldea: desde w = 13 hasta acá (en w), con u de -1 a 1. */
    public int finCamino() {
        return Math.max(15, this.haciaAldea - 6);
    }

    private static String losaDe(String bloque) {
        String n = Bloque.id(bloque);
        return switch (n) {
            case "minecraft:smooth_stone" -> MC + "smooth_stone_slab";
            case "minecraft:cut_sandstone" -> MC + "cut_sandstone_slab";
            case "minecraft:stone_bricks" -> MC + "stone_brick_slab";
            case "minecraft:cobblestone" -> MC + "cobblestone_slab";
            case "minecraft:smooth_sandstone" -> MC + "smooth_sandstone_slab";
            default -> n.endsWith("_planks") ? n.replace("_planks", "_slab") : MC + "stone_slab";
        };
    }

    private void armar() {
        // ---- el terreno: nivelado de punta a punta, con balasto bajo la vía y el camino de tierra atrás
        nivelar(-MEDIO - 1, MEDIO + 1, -2, 14, 11, null);
        nivelar(-MEDIO - 1, MEDIO + 1, -1, 1, 11, BALASTO);
        nivelar(-1, 1, 13, 14, 11, MC + "dirt_path");
        rectas(-MEDIO, MEDIO, 0, 0, 0.0);

        anden();
        casa();
        patio();
    }

    private void anden() {
        String borde = this.p.borde;
        for (int u = -13; u <= 13; u++) {
            poner(u, 0, 2, borde);
            for (int w = 3; w <= 5; w++) {
                poner(u, 0, w, this.p.anden);
            }
        }
        // escalones en las puntas
        String escalon = losa(losaDe(borde), false);
        for (int w = 2; w <= 5; w++) {
            poner(-14, 0, w, escalon);
            poner(14, 0, w, escalon);
        }
        // techito sobre el andén, con postes en el borde
        for (int u = -10; u <= 10; u++) {
            for (int w = 2; w <= 5; w++) {
                poner(u, 4, w, losa(this.p.techoLosa, false));
            }
        }
        for (int u : new int[]{-9, -3, 3, 9}) {
            for (int h = 1; h <= 3; h++) {
                poner(u, h, 2, this.p.valla);
            }
        }
        poner(-6, 3, 3, farol(true));
        poner(6, 3, 3, farol(true));
        poner(0, 3, 3, MC + "bell[attachment=ceiling,facing=east,powered=false]");
        // bancos contra la pared de la casa, bajo las ventanas
        for (int u : new int[]{-5, -4, 4, 5}) {
            poner(u, 1, 5, escalera(this.p.escalera, ADENTRO, false));
        }
        // faroles en las puntas
        for (int u : new int[]{-12, 12}) {
            poner(u, 1, 4, this.p.valla);
            poner(u, 2, 4, this.p.valla);
            poner(u, 3, 4, farol(false));
        }
    }

    private void casa() {
        // base y piso
        for (int u = -7; u <= 7; u++) {
            for (int w = 6; w <= 12; w++) {
                boolean borde = u == -7 || u == 7 || w == 6 || w == 12;
                poner(u, 0, w, borde ? this.p.base : this.p.piso);
            }
        }
        // paredes con esquinas y postes de tronco
        for (int h = 1; h <= 4; h++) {
            for (int u = -7; u <= 7; u++) {
                boolean poste = u == -7 || u == -3 || u == 3 || u == 7;
                poner(u, h, 6, poste ? this.p.tronco('y') : this.p.pared);
                poner(u, h, 12, poste ? this.p.tronco('y') : this.p.pared);
            }
            for (int w = 7; w <= 11; w++) {
                poner(-7, h, w, this.p.pared);
                poner(7, h, w, this.p.pared);
            }
        }
        // viga de arriba
        for (int u = -7; u <= 7; u++) {
            poner(u, 5, 6, this.p.tronco('x'));
            poner(u, 5, 12, this.p.tronco('x'));
        }
        for (int w = 7; w <= 11; w++) {
            poner(-7, 5, w, this.p.tronco('z'));
            poner(7, 5, w, this.p.tronco('z'));
        }
        // cielorraso
        caja(-6, 6, 5, 5, 7, 11, this.p.tablas);
        // puertas (adelante, al andén; atrás, al camino) con vidrio arriba
        String vidrio = MC + "glass_pane";
        poner(0, 1, 6, puerta(this.p.puerta, AFUERA, false, "left"));
        poner(0, 2, 6, puerta(this.p.puerta, AFUERA, true, "left"));
        poner(0, 3, 6, vidrio);
        poner(0, 1, 12, puerta(this.p.puerta, ADENTRO, false, "left"));
        poner(0, 2, 12, puerta(this.p.puerta, ADENTRO, true, "left"));
        poner(0, 3, 12, vidrio);
        poner(0, 0, 13, escalera(this.p.escalera, AFUERA, false));
        // ventanas
        for (int u : new int[]{-5, -4, 4, 5}) {
            for (int h = 2; h <= 3; h++) {
                poner(u, h, 6, vidrio);
                poner(u, h, 12, vidrio);
            }
        }
        for (int w = 8; w <= 10; w++) {
            for (int h = 2; h <= 3; h++) {
                poner(-7, h, w, vidrio);
                poner(7, h, w, vidrio);
            }
        }
        // detalles en el color de la aldea bajo las ventanas
        for (int u : new int[]{-5, -4, 4, 5}) {
            poner(u, 1, 12, this.p.acento);
        }
        techo();
        // adentro: boletería con cofre, bancos, macetas, faroles y una alfombra
        for (int u = -6; u <= -4; u++) {
            poner(u, 1, 9, losa(this.p.losa, true));
        }
        poner(-3, 1, 9, this.p.trampilla + "[facing=east,half=top,open=true,powered=false,waterlogged=false]");
        poner(-6, 1, 11, MC + "chest[facing=north,type=single,waterlogged=false]");
        botin(-6, 1, 11, BOTIN);
        poner(-5, 1, 11, MC + "barrel[facing=up,open=false]");
        poner(-4, 1, 11, MC + "cartography_table");
        for (int w = 8; w <= 10; w++) {
            poner(6, 1, w, escalera(this.p.escalera, "east", false));
        }
        for (int u = 2; u <= 4; u++) {
            poner(u, 1, 8, escalera(this.p.escalera, ADENTRO, false));
        }
        poner(-6, 1, 7, this.p.maceta);
        poner(6, 1, 7, this.p.maceta);
        poner(6, 1, 11, this.p.maceta);
        poner(-3, 4, 9, farol(true));
        poner(3, 4, 9, farol(true));
        for (int w = 7; w <= 11; w++) {
            poner(0, 1, w, MC + "red_carpet");
        }
    }

    private void techo() {
        if (this.p.techoPlano) {
            caja(-7, 7, 6, 6, 6, 12, this.p.techoMacizo);
            for (int u = -7; u <= 7; u++) {
                poner(u, 7, 6, losa(this.p.techoLosa, false));
                poner(u, 7, 12, losa(this.p.techoLosa, false));
            }
            for (int w = 7; w <= 11; w++) {
                poner(-7, 7, w, losa(this.p.techoLosa, false));
                poner(7, 7, w, losa(this.p.techoLosa, false));
            }
            for (int u : new int[]{-7, 7}) {
                for (int w : new int[]{6, 12}) {
                    poner(u, 7, w, this.p.acento);
                }
            }
            // una cúpula chica sobre la entrada
            caja(-2, 2, 7, 7, 8, 10, this.p.techoMacizo);
            caja(-1, 1, 8, 8, 8, 10, this.p.acento);
            poner(0, 9, 9, losa(this.p.techoLosa, false));
            return;
        }
        // a dos aguas: la cumbrera va a lo largo de la vía, en w = 9
        for (int u = -8; u <= 8; u++) {
            for (int w = 5; w <= 13; w++) {
                int h = 5 + (w <= 9 ? w - 5 : 13 - w);
                if (w == 9) {
                    poner(u, h, w, losa(this.p.techoLosa, false));
                    poner(u, h - 1, w, this.p.techoMacizo);
                } else {
                    poner(u, h, w, escalera(this.p.techo, w < 9 ? ADENTRO : AFUERA, false));
                }
            }
        }
        // los triángulos de las puntas
        for (int w = 6; w <= 12; w++) {
            int arriba = 5 + (w <= 9 ? w - 5 : 13 - w);
            for (int h = 6; h < arriba; h++) {
                poner(-7, h, w, this.p.tablas);
                poner(7, h, w, this.p.tablas);
            }
        }
        // chimenea
        for (int h = 6; h <= 10; h++) {
            poner(5, h, 10, MC + "bricks");
        }
        poner(5, 11, 10, MC + "campfire[facing=north,lit=true,signal_fire=false,waterlogged=false]");
    }

    private void patio() {
        // un rincón de carga al este de la casa
        poner(9, 0, 8, MC + "barrel[facing=up,open=false]");
        poner(10, 0, 8, MC + "barrel[facing=up,open=false]");
        poner(9, 0, 9, MC + "hay_block[axis=y]");
        poner(9, 1, 9, MC + "hay_block[axis=x]");
        poner(10, 0, 9, MC + "hay_block[axis=z]");
        // flores sueltas en el patio y al costado
        boolean seco = this.p == Paleta.DESIERTO;
        String[] flores = seco ? new String[]{MC + "dead_bush"}
                : this.p == Paleta.SABANA ? new String[]{MC + "short_grass", MC + "short_grass", MC + "dandelion"}
                : new String[]{MC + "poppy", MC + "dandelion", MC + "short_grass", MC + "cornflower"};
        String tierra = seco ? MC + "sand" : MC + "grass_block[snowy=false]";
        for (int u = -16; u <= 16; u++) {
            for (int w = 6; w <= 14; w++) {
                if (Math.abs(u) <= 8 && w <= 13 || Math.abs(u) <= 1) {
                    continue;
                }
                if (u >= 8 && u <= 11 && w >= 7 && w <= 10) {
                    continue;
                }
                if (azar(u, 0, w, 3) < 0.18) {
                    poner(u, -1, w, tierra);
                    poner(u, 0, w, flores[(int) (azar(u, 0, w, 4) * flores.length)]);
                }
            }
        }
    }
}
