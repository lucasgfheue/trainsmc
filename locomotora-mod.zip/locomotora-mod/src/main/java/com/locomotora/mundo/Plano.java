package com.locomotora.mundo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.locomotora.via.ConfigVia;
import com.locomotora.via.Pieza;

/**
 * El plano de una estación ya ubicada en el mundo (coordenadas del mundo): los bloques que lleva, el terreno que
 * nivela (la "pisada", con taludes alrededor), sus vías, sus cofres y las entidades (el tren abandonado).
 * Cada chunk pone solo la parte que le toca.
 */
public final class Plano {
    /** Hasta cuántos bloques afuera de la pisada se hace el talud (terraplén o corte). */
    public static final int TALUD = 6;

    /** Una columna nivelada: el piso arriba en {@code piso}, despejado hasta {@code limpiar}. */
    public static final class Pisada {
        public final int piso;
        public final int limpiar;
        /** Lo que va arriba del piso donde el plano no pone nada (null: lo que haya en el lugar). */
        public final String superficie;

        Pisada(int piso, int limpiar, String superficie) {
            this.piso = piso;
            this.limpiar = limpiar;
            this.superficie = superficie;
        }
    }

    /** Columna del talud: a {@code d} bloques de una pisada con piso {@code piso}. */
    public static final class Talud {
        public final int piso;
        public final int d;
        public final int limpiar;

        Talud(int piso, int d, int limpiar) {
            this.piso = piso;
            this.d = d;
            this.limpiar = limpiar;
        }
    }

    /** Una pieza de vía de la estación; {@code faltan}: celdas que no se ponen (vía rota). */
    public static final class PiezaPlan {
        public final Pieza pieza;
        public final ConfigVia config;
        public final java.util.Set<Long> faltan;

        public PiezaPlan(Pieza pieza, ConfigVia config, java.util.Set<Long> faltan) {
            this.pieza = pieza;
            this.config = config;
            this.faltan = faltan;
        }
    }

    /** Una entidad a poner: locomotora o vagón (con su enganche y su carga). */
    public static final class EntidadPlan {
        public final String tipo;
        public final double x;
        public final double y;
        public final double z;
        public final float rumbo;
        public final long uuidAlto;
        public final long uuidBajo;
        /** Vagón: a quién va enganchado (0, 0 = a nadie). */
        public final long liderAlto;
        public final long liderBajo;
        public final boolean alFrenteDelLider;
        public final boolean liderPorMiFrente;
        /** Vagón: tabla de botín de la carga (o null). */
        public final String botin;

        public EntidadPlan(String tipo, double x, double y, double z, float rumbo, long uuidAlto, long uuidBajo,
                           long liderAlto, long liderBajo, boolean alFrenteDelLider, boolean liderPorMiFrente,
                           String botin) {
            this.tipo = tipo;
            this.x = x;
            this.y = y;
            this.z = z;
            this.rumbo = rumbo;
            this.uuidAlto = uuidAlto;
            this.uuidBajo = uuidBajo;
            this.liderAlto = liderAlto;
            this.liderBajo = liderBajo;
            this.alFrenteDelLider = alFrenteDelLider;
            this.liderPorMiFrente = liderPorMiFrente;
            this.botin = botin;
        }

        public boolean enganchado() {
            return this.liderAlto != 0L || this.liderBajo != 0L;
        }
    }

    private final Map<Long, TreeMap<Integer, String>> columnas = new HashMap<>();
    private final Map<Long, Pisada> pisada = new HashMap<>();
    private final Map<Long, Talud> taludes = new HashMap<>();
    private final Map<Long, String> botines = new HashMap<>();
    /** Columnas donde no va talud (el corredor de la vía, que arregla la línea). */
    private final java.util.Set<Long> sinTalud = new java.util.HashSet<>();
    public final List<PiezaPlan> piezas = new ArrayList<>();
    public final List<EntidadPlan> entidades = new ArrayList<>();
    /** Caja que ocupa todo (con taludes): minX, minZ, maxX, maxZ. */
    private int minX = Integer.MAX_VALUE;
    private int minZ = Integer.MAX_VALUE;
    private int maxX = Integer.MIN_VALUE;
    private int maxZ = Integer.MIN_VALUE;
    private boolean terminado;

    public static long col(int x, int z) {
        return ((long) x << 32) | (z & 0xFFFFFFFFL);
    }

    private void abarcar(int x, int z) {
        this.minX = Math.min(this.minX, x);
        this.maxX = Math.max(this.maxX, x);
        this.minZ = Math.min(this.minZ, z);
        this.maxZ = Math.max(this.maxZ, z);
    }

    // ------------------------------------------------------------------ armar
    public void poner(int x, int y, int z, String estado) {
        this.columnas.computeIfAbsent(col(x, z), k -> new TreeMap<>()).put(y, estado);
        abarcar(x, z);
    }

    public void quitar(int x, int y, int z) {
        TreeMap<Integer, String> c = this.columnas.get(col(x, z));
        if (c != null) {
            c.remove(y);
        }
    }

    public String obtener(int x, int y, int z) {
        TreeMap<Integer, String> c = this.columnas.get(col(x, z));
        return c == null ? null : c.get(y);
    }

    public void nivelar(int x, int z, int piso, int limpiar, String superficie) {
        this.pisada.put(col(x, z), new Pisada(piso, limpiar, superficie));
        abarcar(x, z);
    }

    /** La columna no se nivela ni lleva talud (por ella sigue la línea, con sus propias rampas). */
    public void sinNivelar(int x, int z) {
        this.pisada.remove(col(x, z));
        this.sinTalud.add(col(x, z));
    }

    public void botin(int x, int y, int z, String tabla) {
        this.botines.put(Pieza.clave(x, y, z), tabla);
    }

    // ------------------------------------------------------------------ terminar
    /** Calcula los taludes y las conexiones de vallas, paneles, muros y enredaderas. */
    public Plano terminar() {
        if (this.terminado) {
            return this;
        }
        this.terminado = true;
        calcularTaludes();
        conectar();
        return this;
    }

    private void calcularTaludes() {
        if (this.pisada.isEmpty()) {
            return;
        }
        int x0 = this.minX - TALUD;
        int z0 = this.minZ - TALUD;
        int ancho = this.maxX - this.minX + 1 + 2 * TALUD;
        int fondo = this.maxZ - this.minZ + 1 + 2 * TALUD;
        int[] dist = new int[ancho * fondo];
        int[] piso = new int[ancho * fondo];
        int[] limpiar = new int[ancho * fondo];
        java.util.Arrays.fill(dist, Integer.MAX_VALUE);
        java.util.ArrayDeque<Integer> cola = new java.util.ArrayDeque<>();
        for (Map.Entry<Long, Pisada> e : this.pisada.entrySet()) {
            int x = (int) (e.getKey() >> 32);
            int z = (int) (long) e.getKey();
            int i = (x - x0) * fondo + (z - z0);
            dist[i] = 0;
            piso[i] = e.getValue().piso;
            limpiar[i] = e.getValue().limpiar;
            cola.add(i);
        }
        // distancia de tablero (8 vecinos) hacia afuera, hasta TALUD
        while (!cola.isEmpty()) {
            int i = cola.poll();
            int x = i / fondo;
            int z = i % fondo;
            if (dist[i] >= TALUD) {
                continue;
            }
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    int nx = x + dx;
                    int nz = z + dz;
                    if ((dx == 0 && dz == 0) || nx < 0 || nz < 0 || nx >= ancho || nz >= fondo) {
                        continue;
                    }
                    int j = nx * fondo + nz;
                    if (dist[j] > dist[i] + 1) {
                        dist[j] = dist[i] + 1;
                        piso[j] = piso[i];
                        limpiar[j] = limpiar[i];
                        cola.add(j);
                    }
                }
            }
        }
        for (int i = 0; i < dist.length; i++) {
            if (dist[i] > 0 && dist[i] <= TALUD) {
                int x = x0 + i / fondo;
                int z = z0 + i % fondo;
                if (!this.sinTalud.contains(col(x, z))) {
                    this.taludes.put(col(x, z), new Talud(piso[i], dist[i], limpiar[i]));
                }
            }
        }
        this.minX -= TALUD;
        this.minZ -= TALUD;
        this.maxX += TALUD;
        this.maxZ += TALUD;
    }

    private static final int[][] LADOS = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};
    private static final String[] NOMBRES = {"north", "east", "south", "west"};

    private void conectar() {
        List<Object[]> cambios = new ArrayList<>();
        for (Map.Entry<Long, TreeMap<Integer, String>> e : this.columnas.entrySet()) {
            int x = (int) (e.getKey() >> 32);
            int z = (int) (long) e.getKey();
            for (Map.Entry<Integer, String> b : e.getValue().entrySet()) {
                int y = b.getKey();
                String s = b.getValue();
                String nuevo = null;
                if (Bloque.esValla(s) || Bloque.esPanel(s) || Bloque.esMuro(s)) {
                    nuevo = conexiones(x, y, z, s);
                } else if (Bloque.id(s).equals("minecraft:vine")) {
                    nuevo = enredadera(x, y, z, s);
                }
                if (nuevo != null && !nuevo.equals(s)) {
                    cambios.add(new Object[]{x, y, z, nuevo});
                }
            }
        }
        for (Object[] c : cambios) {
            String s = (String) c[3];
            if (s.isEmpty()) {
                quitar((Integer) c[0], (Integer) c[1], (Integer) c[2]);
            } else {
                poner((Integer) c[0], (Integer) c[1], (Integer) c[2], s);
            }
        }
    }

    private boolean seUne(String yo, String otro) {
        if (otro == null) {
            return false;
        }
        if (Bloque.esValla(yo)) {
            boolean madera = !Bloque.id(yo).equals("minecraft:nether_brick_fence");
            if (Bloque.esValla(otro)) {
                return madera == !Bloque.id(otro).equals("minecraft:nether_brick_fence");
            }
            return Bloque.esPortillo(otro) || Bloque.esCubo(otro);
        }
        if (Bloque.esPanel(yo)) {
            return Bloque.esPanel(otro) || Bloque.esMuro(otro) || Bloque.esCubo(otro);
        }
        return Bloque.esMuro(otro) || Bloque.esPanel(otro) || Bloque.esPortillo(otro) || Bloque.esCubo(otro);
    }

    private String conexiones(int x, int y, int z, String s) {
        boolean muro = Bloque.esMuro(s);
        boolean[] une = new boolean[4];
        for (int i = 0; i < 4; i++) {
            une[i] = seUne(s, obtener(x + LADOS[i][0], y, z + LADOS[i][1]));
        }
        String r = s;
        for (int i = 0; i < 4; i++) {
            r = Bloque.con(r, NOMBRES[i], muro ? (une[i] ? "low" : "none") : Boolean.toString(une[i]));
        }
        if (muro) {
            boolean recto = (une[0] && une[2] && !une[1] && !une[3]) || (une[1] && une[3] && !une[0] && !une[2]);
            String arriba = obtener(x, y + 1, z);
            r = Bloque.con(r, "up", Boolean.toString(!recto || (arriba != null && Bloque.esMuro(arriba))));
        }
        return Bloque.con(r, "waterlogged", "false");
    }

    /** Las enredaderas se pegan a los cubos que tengan al lado (o arriba); si no hay ninguno, no van. */
    private String enredadera(int x, int y, int z, String s) {
        String r = s;
        boolean alguna = false;
        for (int i = 0; i < 4; i++) {
            String otro = obtener(x + LADOS[i][0], y, z + LADOS[i][1]);
            boolean pega = otro != null && Bloque.esCubo(otro);
            alguna |= pega;
            r = Bloque.con(r, NOMBRES[i], Boolean.toString(pega));
        }
        String arriba = obtener(x, y + 1, z);
        boolean techo = arriba != null && Bloque.esCubo(arriba);
        r = Bloque.con(r, "up", Boolean.toString(techo));
        return alguna || techo ? r : "";
    }

    // ------------------------------------------------------------------ consultas (para poner por chunk)
    public int minX() {
        return this.minX;
    }

    public int maxX() {
        return this.maxX;
    }

    public int minZ() {
        return this.minZ;
    }

    public int maxZ() {
        return this.maxZ;
    }

    public boolean toca(int x0, int z0, int x1, int z1) {
        return this.maxX >= x0 && this.minX <= x1 && this.maxZ >= z0 && this.minZ <= z1;
    }

    public Pisada pisada(int x, int z) {
        return this.pisada.get(col(x, z));
    }

    public Talud talud(int x, int z) {
        return this.taludes.get(col(x, z));
    }

    /** Los bloques de la columna (x, z), de abajo hacia arriba (null si no hay). */
    public TreeMap<Integer, String> columna(int x, int z) {
        return this.columnas.get(col(x, z));
    }

    public String botin(int x, int y, int z) {
        return this.botines.get(Pieza.clave(x, y, z));
    }

    public int cantidadBloques() {
        int n = 0;
        for (TreeMap<Integer, String> c : this.columnas.values()) {
            n += c.size();
        }
        return n;
    }
}
