package com.locomotora.mundo;

import java.util.HashSet;
import java.util.Set;

import com.locomotora.via.ConfigVia;
import com.locomotora.via.Pieza;
import com.locomotora.via.TipoVia;

/**
 * Lo común a las dos estaciones: se arman en coordenadas propias y quedan en un {@link Plano} del mundo.
 * <ul>
 *   <li>u: a lo largo de la vía (hacia el este), w: de través (+w hacia el edificio), h: altura sobre la vía.</li>
 *   <li>La vía principal va en w = 0 y su bloque (el riel) en h = 0; el piso del lugar (lecho, suelo) en h = -1.</li>
 *   <li>Se dibuja como si el edificio quedara al sur (s = +1); si queda al norte (s = -1) se refleja en z.</li>
 * </ul>
 */
public abstract class Estacion {
    public static final String MC = "minecraft:";
    public static final String BALASTO = "locomotora:balasto";

    protected final Plano plano = new Plano();
    /** Bloque del riel de la vía principal en u = 0. */
    public final int ox;
    public final int oy;
    public final int oz;
    /** +1: el edificio queda hacia +z (sur); -1: hacia -z (norte). */
    public final int s;
    protected final long semilla;

    protected Estacion(int ox, int oy, int oz, int s, long semilla) {
        this.ox = ox;
        this.oy = oy;
        this.oz = oz;
        this.s = s >= 0 ? 1 : -1;
        this.semilla = semilla;
    }

    /** Medio largo de la parte plana de la vía principal (la estación pone sus propias vías de -medio a +medio). */
    public abstract int medio();

    public Plano plano() {
        return this.plano;
    }

    // ------------------------------------------------------------------ de propio a mundo
    public int x(int u) {
        return this.ox + u;
    }

    public int z(int w) {
        return this.oz + this.s * w;
    }

    public int y(int h) {
        return this.oy + h;
    }

    protected void poner(int u, int h, int w, String estado) {
        this.plano.poner(x(u), y(h), z(w), this.s < 0 ? Bloque.espejarZ(estado) : estado);
    }

    protected void quitar(int u, int h, int w) {
        this.plano.quitar(x(u), y(h), z(w));
    }

    protected String en(int u, int h, int w) {
        return this.plano.obtener(x(u), y(h), z(w));
    }

    protected boolean libre(int u, int h, int w) {
        return en(u, h, w) == null;
    }

    /** Pone el bloque solo si el lugar está libre. */
    protected void ponerSiLibre(int u, int h, int w, String estado) {
        if (libre(u, h, w)) {
            poner(u, h, w, estado);
        }
    }

    protected void caja(int u0, int u1, int h0, int h1, int w0, int w1, String estado) {
        for (int u = Math.min(u0, u1); u <= Math.max(u0, u1); u++) {
            for (int h = Math.min(h0, h1); h <= Math.max(h0, h1); h++) {
                for (int w = Math.min(w0, w1); w <= Math.max(w0, w1); w++) {
                    poner(u, h, w, estado);
                }
            }
        }
    }

    protected void nivelar(int u0, int u1, int w0, int w1, int limpiarH, String superficie) {
        for (int u = Math.min(u0, u1); u <= Math.max(u0, u1); u++) {
            for (int w = Math.min(w0, w1); w <= Math.max(w0, w1); w++) {
                this.plano.nivelar(x(u), z(w), y(-1), y(limpiarH), superficie);
            }
        }
    }

    /** Más allá de la parte plana, por el corredor de la vía (w de -2 a 2) no se nivela: ahí manda la línea. */
    protected void corredor() {
        for (int k = medio() + 1; k <= medio() + Plano.TALUD + 2; k++) {
            for (int w = -2; w <= 2; w++) {
                this.plano.sinNivelar(x(k), z(w));
                this.plano.sinNivelar(x(-k), z(w));
            }
        }
    }

    protected void botin(int u, int h, int w, String tabla) {
        this.plano.botin(x(u), y(h), z(w), tabla);
    }

    // ------------------------------------------------------------------ al azar (fijo para cada lugar)
    protected double azar(int u, int h, int w, int sal) {
        return Ruido.valor(this.semilla + sal * 0x9E3779B97F4A7C15L, x(u), y(h), z(w));
    }

    /** Ruido suave (manchas de musgo, partes derrumbadas), entre 0 y 1. */
    protected double mancha(int u, int h, int w, double escala, int sal) {
        return Ruido.suave(this.semilla + sal * 0x632BE59BD9B4E019L, x(u), y(h), z(w), escala);
    }

    protected int entero(int a, int b, int n) {
        return Ruido.entero(this.semilla, a, b, 77, n);
    }

    // ------------------------------------------------------------------ direcciones (en el dibujo con s = +1)
    /** Hacia el edificio (+w). */
    protected static final String ADENTRO = "south";
    /** Hacia la vía (-w). */
    protected static final String AFUERA = "north";

    protected static String escalera(String material, String facing, boolean arriba) {
        return material + "[facing=" + facing + ",half=" + (arriba ? "top" : "bottom") + ",shape=straight,waterlogged=false]";
    }

    protected static String losa(String material, boolean arriba) {
        return material + "[type=" + (arriba ? "top" : "bottom") + ",waterlogged=false]";
    }

    protected static String eje(String tronco, char eje) {
        return tronco + "[axis=" + eje + "]";
    }

    protected static String farol(boolean colgado) {
        return MC + "lantern[hanging=" + colgado + ",waterlogged=false]";
    }

    protected static String puerta(String material, String facing, boolean arriba, String bisagra) {
        return material + "[facing=" + facing + ",half=" + (arriba ? "upper" : "lower") + ",hinge=" + bisagra
                + ",open=false,powered=false]";
    }

    protected static String hojas(String material) {
        return material + "[distance=1,persistent=true,waterlogged=false]";
    }

    // ------------------------------------------------------------------ vías
    /** Una pieza armada como la arma el ítem (así cada bloque la reconoce como la misma). */
    public static Plano.PiezaPlan pieza(TipoVia tipo, int x, int y, int z, Pieza.Rumbo rumbo, boolean izquierda,
                                        int largo, int radio, int alto, int paso, Set<Long> faltan) {
        ConfigVia c = new ConfigVia(tipo);
        c.largo = largo;
        c.radio = radio;
        c.izquierda = izquierda;
        c.alto = alto;
        c.paso = paso;
        c.ajustar();
        return new Plano.PiezaPlan(c.pieza(x, y, z, rumbo), c, faltan == null ? Set.of() : faltan);
    }

    /** Rectas hacia el este en w desde u0 hasta u1 (en tramos de hasta 30), a la altura h. */
    protected void rectas(int u0, int u1, int h, int w, double rota) {
        int u = u0;
        int n = u1 - u0 + 1;
        int tramos = (n + ConfigVia.MAX - 1) / ConfigVia.MAX;
        for (int t = 0; t < tramos; t++) {
            int largo = n / tramos + (t < n % tramos ? 1 : 0);
            Set<Long> faltan = new HashSet<>();
            if (rota > 0.0) {
                for (int i = 0; i < largo; i++) {
                    if (mancha(u + i, h, w, 5.0, 31) < rota) {
                        faltan.add(Pieza.clave(x(u + i), y(h), z(w)));
                    }
                }
            }
            this.plano.piezas.add(pieza(TipoVia.RECTA, x(u), y(h), z(w), Pieza.Rumbo.ESTE, false, largo, 6, 2, 2, faltan));
            u += largo;
        }
    }

    /** ¿El bloque (u, h, w) es parte de alguna vía de la estación? */
    protected boolean esVia(int u, int h, int w) {
        int x = x(u);
        int yy = y(h);
        int z = z(w);
        for (Plano.PiezaPlan pp : this.plano.piezas) {
            if (pp.pieza.celda(x, yy, z) != null) {
                return true;
            }
        }
        return false;
    }
}
