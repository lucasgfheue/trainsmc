package com.locomotora.mundo;

/** Dónde caen las aldeas (las mismas regiones que usa el juego para ubicarlas). */
public interface Aldeas {
    /** Una aldea: su centro aproximado y la estructura (minecraft:village_plains, ...). */
    record Aldea(int x, int z, String estructura) {
    }

    /** Tamaño de la región de las aldeas en bloques (34 chunks en el juego normal); 0 si no se sabe. */
    int region();

    /** La aldea de la región (rx, rz), o null si ahí no hay. */
    Aldea aldea(int rx, int rz);
}
