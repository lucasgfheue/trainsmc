package com.locomotora.mundo;

/** Lo que la red necesita saber del terreno antes de que exista (sale del generador del mundo, igual en cada chunk). */
public interface Terreno {
    /** Primera altura libre en (x, z): el agua cuenta como ocupada (como el mapa de alturas WORLD_SURFACE_WG). */
    int altura(int x, int z);

    int nivelMar();

    int minY();

    int maxY();
}
