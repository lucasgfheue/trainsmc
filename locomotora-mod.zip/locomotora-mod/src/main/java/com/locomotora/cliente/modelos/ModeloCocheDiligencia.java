package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Coche diligencia" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloCocheDiligencia {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("coche_diligencia"), "main"),
            LocomotoraMod.id("textures/entity/coche_diligencia.png"),
            List.of(
                new DatosModelo.Animada("ri0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -12.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -12.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -12.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("ri1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 12.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 12.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 12.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -12.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -12.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -12.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 12.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 12.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 12.0F, -4.5F, 1.0471975511965976F, "cuerpo")),
            ModeloCocheDiligencia::crearCapa,
            16.0F,
            ModeloCocheDiligencia::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -12.0F, 12.0F)));

    private ModeloCocheDiligencia() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 64);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("costadoi", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -30.0F, -0.5F, 90.0F, 30.0F, 1.0F), PartPose.offset(-22.5F, -12.0F, -9.0F));
        g.addOrReplaceChild("costadod", CubeListBuilder.create().texOffs(182, 0).addBox(0.0F, -30.0F, -0.5F, 90.0F, 30.0F, 1.0F), PartPose.offset(-22.5F, -12.0F, 9.0F));
        g.addOrReplaceChild("caja", CubeListBuilder.create().texOffs(436, 0).addBox(-22.5F, -27.0F, -8.5F, 1.0F, 9.0F, 17.0F).texOffs(472, 0).addBox(21.5F, -27.0F, -8.5F, 1.0F, 9.0F, 17.0F).texOffs(628, 0).addBox(-21.5F, -13.0F, -8.5F, 43.0F, 1.0F, 17.0F).texOffs(364, 0).addBox(-8.0F, -27.0F, -8.5F, 1.0F, 14.0F, 17.0F).texOffs(400, 0).addBox(7.0F, -27.0F, -8.5F, 1.0F, 14.0F, 17.0F), PartPose.ZERO);
        g.addOrReplaceChild("bancos", CubeListBuilder.create().texOffs(174, 31).addBox(-20.5F, -17.0F, 0.0F, 3.0F, 4.0F, 7.0F).texOffs(830, 0).addBox(-21.5F, -24.0F, 0.0F, 1.0F, 11.0F, 7.0F).texOffs(194, 31).addBox(-12.5F, -17.0F, 0.0F, 3.0F, 4.0F, 7.0F).texOffs(846, 0).addBox(-9.5F, -24.0F, 0.0F, 1.0F, 11.0F, 7.0F).texOffs(214, 31).addBox(-5.5F, -17.0F, 0.0F, 3.0F, 4.0F, 7.0F).texOffs(862, 0).addBox(-6.5F, -24.0F, 0.0F, 1.0F, 11.0F, 7.0F).texOffs(234, 31).addBox(2.5F, -17.0F, 0.0F, 3.0F, 4.0F, 7.0F).texOffs(878, 0).addBox(5.5F, -24.0F, 0.0F, 1.0F, 11.0F, 7.0F).texOffs(254, 31).addBox(9.5F, -17.0F, 0.0F, 3.0F, 4.0F, 7.0F).texOffs(894, 0).addBox(8.5F, -24.0F, 0.0F, 1.0F, 11.0F, 7.0F).texOffs(274, 31).addBox(17.5F, -17.0F, 0.0F, 3.0F, 4.0F, 7.0F).texOffs(910, 0).addBox(20.5F, -24.0F, 0.0F, 1.0F, 11.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("bancos2", CubeListBuilder.create().texOffs(294, 31).addBox(-20.5F, -17.0F, -7.0F, 3.0F, 4.0F, 7.0F).texOffs(926, 0).addBox(-21.5F, -24.0F, -7.0F, 1.0F, 11.0F, 7.0F).texOffs(314, 31).addBox(-12.5F, -17.0F, -7.0F, 3.0F, 4.0F, 7.0F).texOffs(942, 0).addBox(-9.5F, -24.0F, -7.0F, 1.0F, 11.0F, 7.0F).texOffs(334, 31).addBox(-5.5F, -17.0F, -7.0F, 3.0F, 4.0F, 7.0F).texOffs(958, 0).addBox(-6.5F, -24.0F, -7.0F, 1.0F, 11.0F, 7.0F).texOffs(354, 31).addBox(2.5F, -17.0F, -7.0F, 3.0F, 4.0F, 7.0F).texOffs(974, 0).addBox(5.5F, -24.0F, -7.0F, 1.0F, 11.0F, 7.0F).texOffs(374, 31).addBox(9.5F, -17.0F, -7.0F, 3.0F, 4.0F, 7.0F).texOffs(990, 0).addBox(8.5F, -24.0F, -7.0F, 1.0F, 11.0F, 7.0F).texOffs(394, 31).addBox(17.5F, -17.0F, -7.0F, 3.0F, 4.0F, 7.0F).texOffs(1006, 0).addBox(20.5F, -24.0F, -7.0F, 1.0F, 11.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("forro", CubeListBuilder.create().texOffs(464, 31).addBox(-21.5F, -20.0F, 7.5F, 43.0F, 8.0F, 1.0F).texOffs(552, 31).addBox(-21.5F, -20.0F, -8.5F, 43.0F, 8.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("techo_0", CubeListBuilder.create().texOffs(788, 31).addBox(-23.0F, -1.0F, -1.5F, 46.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -27.329510389255503F, -8.778612388152808F, -2.8598506829993546F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_1", CubeListBuilder.create().texOffs(886, 31).addBox(-23.0F, -1.0F, -1.5F, 46.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -27.93719286512225F, -6.311365425929363F, -2.9403483888823385F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_2", CubeListBuilder.create().texOffs(0, 46).addBox(-23.0F, -1.0F, -1.5F, 46.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -28.34451425156048F, -3.803243648138981F, -3.020846094765319F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_3", CubeListBuilder.create().texOffs(98, 46).addBox(-23.0F, -1.0F, -1.5F, 46.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -28.54883657953758F, -1.2704906103624252F, -3.101343800648302F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_4", CubeListBuilder.create().texOffs(196, 46).addBox(-23.0F, -1.0F, -1.5F, 46.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -28.54883657953758F, 1.2704906103624252F, 3.101343800648302F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_5", CubeListBuilder.create().texOffs(294, 46).addBox(-23.0F, -1.0F, -1.5F, 46.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -28.34451425156048F, 3.803243648138981F, 3.020846094765319F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_6", CubeListBuilder.create().texOffs(392, 46).addBox(-23.0F, -1.0F, -1.5F, 46.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -27.93719286512225F, 6.311365425929363F, 2.9403483888823385F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_7", CubeListBuilder.create().texOffs(490, 46).addBox(-23.0F, -1.0F, -1.5F, 46.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -27.329510389255503F, 8.778612388152808F, 2.8598506829993546F, 0.0F, 0.0F));
        g.addOrReplaceChild("baranda", CubeListBuilder.create().texOffs(914, 46).addBox(-21.5F, -31.0F, -9.0F, 38.0F, 1.0F, 1.0F).texOffs(882, 46).addBox(-21.0F, -30.0F, -9.0F, 1.0F, 2.0F, 1.0F).texOffs(886, 46).addBox(-11.0F, -30.0F, -9.0F, 1.0F, 2.0F, 1.0F).texOffs(890, 46).addBox(-1.0F, -30.0F, -9.0F, 1.0F, 2.0F, 1.0F).texOffs(894, 46).addBox(9.0F, -30.0F, -9.0F, 1.0F, 2.0F, 1.0F).texOffs(0, 50).addBox(-21.5F, -31.0F, 8.0F, 38.0F, 1.0F, 1.0F).texOffs(898, 46).addBox(-21.0F, -30.0F, 8.0F, 1.0F, 2.0F, 1.0F).texOffs(902, 46).addBox(-11.0F, -30.0F, 8.0F, 1.0F, 2.0F, 1.0F).texOffs(906, 46).addBox(-1.0F, -30.0F, 8.0F, 1.0F, 2.0F, 1.0F).texOffs(910, 46).addBox(9.0F, -30.0F, 8.0F, 1.0F, 2.0F, 1.0F).texOffs(794, 0).addBox(-21.5F, -31.0F, -8.5F, 1.0F, 1.0F, 17.0F), PartPose.ZERO);
        g.addOrReplaceChild("equipaje", CubeListBuilder.create().texOffs(124, 31).addBox(-20.0F, -32.0F, -6.0F, 7.0F, 4.0F, 7.0F).texOffs(640, 31).addBox(-19.0F, -31.0F, 2.0F, 5.0F, 3.0F, 5.0F).texOffs(748, 0).addBox(-11.0F, -33.0F, -7.0F, 10.0F, 5.0F, 13.0F).texOffs(660, 31).addBox(-11.5F, -34.0F, -0.5F, 11.0F, 6.0F, 1.0F).texOffs(438, 31).addBox(0.0F, -31.0F, -5.0F, 6.0F, 3.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("guarda", CubeListBuilder.create().texOffs(580, 0).addBox(14.0F, -30.0F, -8.5F, 7.0F, 2.0F, 17.0F).texOffs(508, 0).addBox(20.0F, -35.0F, -8.5F, 1.0F, 5.0F, 17.0F).texOffs(544, 0).addBox(13.0F, -30.0F, -8.5F, 1.0F, 4.0F, 17.0F), PartPose.ZERO);
        g.addOrReplaceChild("ri0_0", CubeListBuilder.create().texOffs(152, 31).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(588, 46).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(414, 31).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(748, 31).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-12.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("ri0_1", CubeListBuilder.create().texOffs(610, 46).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(422, 31).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri0_2", CubeListBuilder.create().texOffs(632, 46).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(430, 31).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ri1_0", CubeListBuilder.create().texOffs(152, 31).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(588, 46).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(414, 31).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(758, 31).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(12.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("ri1_1", CubeListBuilder.create().texOffs(610, 46).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(422, 31).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri1_2", CubeListBuilder.create().texOffs(632, 46).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(430, 31).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd0_0", CubeListBuilder.create().texOffs(152, 31).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(588, 46).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(414, 31).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(768, 31).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-12.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rd0_1", CubeListBuilder.create().texOffs(610, 46).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(422, 31).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd0_2", CubeListBuilder.create().texOffs(632, 46).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(430, 31).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd1_0", CubeListBuilder.create().texOffs(152, 31).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(588, 46).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(414, 31).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(778, 31).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(12.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rd1_1", CubeListBuilder.create().texOffs(610, 46).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(422, 31).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd1_2", CubeListBuilder.create().texOffs(632, 46).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(430, 31).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(686, 46).addBox(-24.0F, -12.0F, 7.0F, 48.0F, 2.0F, 1.0F).texOffs(784, 46).addBox(-24.0F, -12.0F, -8.0F, 48.0F, 2.0F, 1.0F).texOffs(0, 31).addBox(-24.0F, -12.0F, -7.0F, 48.0F, 1.0F, 14.0F).texOffs(654, 46).addBox(-13.5F, -6.0F, 2.0F, 3.0F, 3.0F, 1.0F).texOffs(662, 46).addBox(-13.5F, -6.0F, -3.0F, 3.0F, 3.0F, 1.0F).texOffs(724, 31).addBox(-13.0F, -11.0F, 2.0F, 2.0F, 5.0F, 1.0F).texOffs(730, 31).addBox(-13.0F, -11.0F, -3.0F, 2.0F, 5.0F, 1.0F).texOffs(78, 50).addBox(-17.0F, -10.0F, 7.0F, 10.0F, 1.0F, 1.0F).texOffs(100, 50).addBox(-17.0F, -10.0F, -8.0F, 10.0F, 1.0F, 1.0F).texOffs(670, 46).addBox(10.5F, -6.0F, 2.0F, 3.0F, 3.0F, 1.0F).texOffs(678, 46).addBox(10.5F, -6.0F, -3.0F, 3.0F, 3.0F, 1.0F).texOffs(736, 31).addBox(11.0F, -11.0F, 2.0F, 2.0F, 5.0F, 1.0F).texOffs(742, 31).addBox(11.0F, -11.0F, -3.0F, 2.0F, 5.0F, 1.0F).texOffs(122, 50).addBox(7.0F, -10.0F, 7.0F, 10.0F, 1.0F, 1.0F).texOffs(144, 50).addBox(7.0F, -10.0F, -8.0F, 10.0F, 1.0F, 1.0F).texOffs(684, 31).addBox(-26.0F, -12.0F, -7.5F, 2.0F, 3.0F, 3.0F).texOffs(694, 31).addBox(-26.0F, -12.0F, 4.5F, 2.0F, 3.0F, 3.0F).texOffs(166, 50).addBox(-27.0F, -11.0F, -0.5F, 3.0F, 1.0F, 1.0F).texOffs(704, 31).addBox(24.0F, -12.0F, -7.5F, 2.0F, 3.0F, 3.0F).texOffs(714, 31).addBox(24.0F, -12.0F, 4.5F, 2.0F, 3.0F, 3.0F).texOffs(174, 50).addBox(24.0F, -11.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "costadoi", 0.5F, 0.5F, 1.0F);
        escalar(g0, "costadod", 0.5F, 0.5F, 1.0F);
        escalar(g0, "techo_0", 1.0004347826086957F, 1.0F, 0.8543469225840873F);
        escalar(g0, "techo_1", 1.0004347826086957F, 1.0F, 0.8543469225840865F);
        escalar(g0, "techo_2", 1.0004347826086957F, 1.0F, 0.8543469225840873F);
        escalar(g0, "techo_3", 1.0004347826086957F, 1.0F, 0.854346922584087F);
        escalar(g0, "techo_4", 1.0004347826086957F, 1.0F, 0.854346922584087F);
        escalar(g0, "techo_5", 1.0004347826086957F, 1.0F, 0.8543469225840873F);
        escalar(g0, "techo_6", 1.0004347826086957F, 1.0F, 0.8543469225840865F);
        escalar(g0, "techo_7", 1.0004347826086957F, 1.0F, 0.8543469225840873F);
    }
}
