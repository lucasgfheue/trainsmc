package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Coche Mk3" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloCocheMk3 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("coche_mk3"), "main"),
            LocomotoraMod.id("textures/entity/coche_mk3.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -62.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -62.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -62.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -46.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -46.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -46.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -62.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -62.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -62.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -46.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -46.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -46.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 46.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 46.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 46.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 62.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 62.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 62.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 46.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 46.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 46.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 62.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 62.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 62.0F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloCocheMk3::crearCapa,
            16.0F,
            ModeloCocheMk3::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -54.0F, 54.0F)));

    private ModeloCocheMk3() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("caja", CubeListBuilder.create().texOffs(164, 80).addBox(-76.0F, -32.0F, 11.5F, 152.0F, 20.0F, 1.0F).texOffs(470, 80).addBox(-76.0F, -32.0F, -12.5F, 152.0F, 20.0F, 1.0F).texOffs(604, 47).addBox(-75.0F, -13.0F, -11.5F, 150.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_techo_0", CubeListBuilder.create().texOffs(304, 146).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -32.59740145133915F, -11.563418608781763F, -2.5738039219286253F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_1", CubeListBuilder.create().texOffs(614, 146).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.69250813817119F, -9.633679276951163F, -2.677038236776109F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_2", CubeListBuilder.create().texOffs(0, 153).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.582922896524764F, -7.601361855271072F, -2.780272551623593F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_3", CubeListBuilder.create().texOffs(310, 153).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.25916471271237F, -5.48810617968481F, -2.88350686647108F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_4", CubeListBuilder.create().texOffs(620, 153).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.714033057031216F, -3.316413905513608F, -2.986741181318566F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_5", CubeListBuilder.create().texOffs(0, 157).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.942684554011564F, -1.1094089129304692F, -3.0899754961660495F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_6", CubeListBuilder.create().texOffs(310, 157).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.94268455401157F, 1.1094089129304676F, 3.0899754961660526F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_7", CubeListBuilder.create().texOffs(620, 157).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.714033057031216F, 3.316413905513606F, 2.986741181318563F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_8", CubeListBuilder.create().texOffs(0, 161).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.25916471271237F, 5.488106179684809F, 2.88350686647108F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_9", CubeListBuilder.create().texOffs(310, 161).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.582922896524764F, 7.6013618552710716F, 2.7802725516235958F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_10", CubeListBuilder.create().texOffs(620, 161).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.69250813817119F, 9.633679276951161F, 2.677038236776106F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_11", CubeListBuilder.create().texOffs(0, 165).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -32.59740145133915F, 11.563418608781761F, 2.5738039219286257F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_puntaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -24.0F, 0.0F, 1.0F, 24.0F, 23.0F), PartPose.offset(-76.0F, -12.0F, -11.5F));
        g.addOrReplaceChild("caja_puntab", CubeListBuilder.create().texOffs(48, 0).addBox(0.0F, -24.0F, 0.0F, 1.0F, 24.0F, 23.0F), PartPose.offset(75.0F, -12.0F, -11.5F));
        g.addOrReplaceChild("asientos", CubeListBuilder.create().texOffs(832, 102).addBox(-58.5F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(776, 80).addBox(-59.5F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(856, 102).addBox(-58.5F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(796, 80).addBox(-59.5F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(880, 102).addBox(-49.5F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(816, 80).addBox(-46.5F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(904, 102).addBox(-49.5F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(836, 80).addBox(-46.5F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(928, 102).addBox(-45.0F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(856, 80).addBox(-46.0F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(952, 102).addBox(-45.0F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(876, 80).addBox(-46.0F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(976, 102).addBox(-36.0F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(896, 80).addBox(-33.0F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(1000, 102).addBox(-36.0F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(916, 80).addBox(-33.0F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(0, 121).addBox(-31.5F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(936, 80).addBox(-32.5F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(24, 121).addBox(-31.5F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(956, 80).addBox(-32.5F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(48, 121).addBox(-22.5F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(976, 80).addBox(-19.5F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(72, 121).addBox(-22.5F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(996, 80).addBox(-19.5F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(96, 121).addBox(-18.0F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(0, 102).addBox(-19.0F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(120, 121).addBox(-18.0F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(20, 102).addBox(-19.0F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(144, 121).addBox(-9.0F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(40, 102).addBox(-6.0F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(168, 121).addBox(-9.0F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(60, 102).addBox(-6.0F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(192, 121).addBox(-4.5F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(80, 102).addBox(-5.5F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(216, 121).addBox(-4.5F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(100, 102).addBox(-5.5F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(240, 121).addBox(4.5F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(120, 102).addBox(7.5F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(264, 121).addBox(4.5F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(140, 102).addBox(7.5F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(288, 121).addBox(9.0F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(160, 102).addBox(8.0F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(312, 121).addBox(9.0F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(180, 102).addBox(8.0F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(336, 121).addBox(18.0F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(200, 102).addBox(21.0F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(360, 121).addBox(18.0F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(220, 102).addBox(21.0F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(384, 121).addBox(22.5F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(240, 102).addBox(21.5F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(408, 121).addBox(22.5F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(260, 102).addBox(21.5F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(432, 121).addBox(31.5F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(280, 102).addBox(34.5F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(456, 121).addBox(31.5F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(300, 102).addBox(34.5F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(480, 121).addBox(36.0F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(320, 102).addBox(35.0F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(504, 121).addBox(36.0F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(340, 102).addBox(35.0F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(528, 121).addBox(45.0F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(360, 102).addBox(48.0F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(552, 121).addBox(45.0F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(380, 102).addBox(48.0F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(576, 121).addBox(49.5F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(400, 102).addBox(48.5F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(600, 121).addBox(49.5F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(420, 102).addBox(48.5F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(624, 121).addBox(58.5F, -17.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(440, 102).addBox(61.5F, -23.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(648, 121).addBox(58.5F, -17.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(460, 102).addBox(61.5F, -23.0F, 2.0F, 1.0F, 10.0F, 9.0F), PartPose.ZERO);
        g.addOrReplaceChild("mesas", CubeListBuilder.create().texOffs(96, 134).addBox(-54.0F, -20.0F, -11.0F, 3.0F, 1.0F, 8.0F).texOffs(0, 146).addBox(-53.0F, -19.0F, -5.0F, 1.0F, 6.0F, 1.0F).texOffs(118, 134).addBox(-54.0F, -20.0F, 3.0F, 3.0F, 1.0F, 8.0F).texOffs(4, 146).addBox(-53.0F, -19.0F, 4.0F, 1.0F, 6.0F, 1.0F).texOffs(140, 134).addBox(-40.5F, -20.0F, -11.0F, 3.0F, 1.0F, 8.0F).texOffs(8, 146).addBox(-39.5F, -19.0F, -5.0F, 1.0F, 6.0F, 1.0F).texOffs(162, 134).addBox(-40.5F, -20.0F, 3.0F, 3.0F, 1.0F, 8.0F).texOffs(12, 146).addBox(-39.5F, -19.0F, 4.0F, 1.0F, 6.0F, 1.0F).texOffs(184, 134).addBox(-27.0F, -20.0F, -11.0F, 3.0F, 1.0F, 8.0F).texOffs(16, 146).addBox(-26.0F, -19.0F, -5.0F, 1.0F, 6.0F, 1.0F).texOffs(206, 134).addBox(-27.0F, -20.0F, 3.0F, 3.0F, 1.0F, 8.0F).texOffs(20, 146).addBox(-26.0F, -19.0F, 4.0F, 1.0F, 6.0F, 1.0F).texOffs(228, 134).addBox(-13.5F, -20.0F, -11.0F, 3.0F, 1.0F, 8.0F).texOffs(24, 146).addBox(-12.5F, -19.0F, -5.0F, 1.0F, 6.0F, 1.0F).texOffs(250, 134).addBox(-13.5F, -20.0F, 3.0F, 3.0F, 1.0F, 8.0F).texOffs(28, 146).addBox(-12.5F, -19.0F, 4.0F, 1.0F, 6.0F, 1.0F).texOffs(272, 134).addBox(0.0F, -20.0F, -11.0F, 3.0F, 1.0F, 8.0F).texOffs(32, 146).addBox(1.0F, -19.0F, -5.0F, 1.0F, 6.0F, 1.0F).texOffs(294, 134).addBox(0.0F, -20.0F, 3.0F, 3.0F, 1.0F, 8.0F).texOffs(36, 146).addBox(1.0F, -19.0F, 4.0F, 1.0F, 6.0F, 1.0F).texOffs(316, 134).addBox(13.5F, -20.0F, -11.0F, 3.0F, 1.0F, 8.0F).texOffs(40, 146).addBox(14.5F, -19.0F, -5.0F, 1.0F, 6.0F, 1.0F).texOffs(338, 134).addBox(13.5F, -20.0F, 3.0F, 3.0F, 1.0F, 8.0F).texOffs(44, 146).addBox(14.5F, -19.0F, 4.0F, 1.0F, 6.0F, 1.0F).texOffs(360, 134).addBox(27.0F, -20.0F, -11.0F, 3.0F, 1.0F, 8.0F).texOffs(48, 146).addBox(28.0F, -19.0F, -5.0F, 1.0F, 6.0F, 1.0F).texOffs(382, 134).addBox(27.0F, -20.0F, 3.0F, 3.0F, 1.0F, 8.0F).texOffs(52, 146).addBox(28.0F, -19.0F, 4.0F, 1.0F, 6.0F, 1.0F).texOffs(404, 134).addBox(40.5F, -20.0F, -11.0F, 3.0F, 1.0F, 8.0F).texOffs(56, 146).addBox(41.5F, -19.0F, -5.0F, 1.0F, 6.0F, 1.0F).texOffs(426, 134).addBox(40.5F, -20.0F, 3.0F, 3.0F, 1.0F, 8.0F).texOffs(60, 146).addBox(41.5F, -19.0F, 4.0F, 1.0F, 6.0F, 1.0F).texOffs(448, 134).addBox(54.0F, -20.0F, -11.0F, 3.0F, 1.0F, 8.0F).texOffs(64, 146).addBox(55.0F, -19.0F, -5.0F, 1.0F, 6.0F, 1.0F).texOffs(470, 134).addBox(54.0F, -20.0F, 3.0F, 3.0F, 1.0F, 8.0F).texOffs(68, 146).addBox(55.0F, -19.0F, 4.0F, 1.0F, 6.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("vestibulos", CubeListBuilder.create().texOffs(96, 0).addBox(-65.0F, -32.0F, -11.5F, 1.0F, 19.0F, 23.0F).texOffs(144, 0).addBox(64.0F, -32.0F, -11.5F, 1.0F, 19.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(492, 134).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(310, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(144, 146).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-62.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(328, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(518, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(346, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(526, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(492, 134).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(310, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(154, 146).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(328, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(518, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(346, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(526, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(492, 134).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(310, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(164, 146).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-62.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(328, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(518, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(346, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(526, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(492, 134).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(310, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(174, 146).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(328, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(518, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(346, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(526, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(534, 134).addBox(-67.0F, -9.0F, 7.0F, 26.0F, 6.0F, 1.0F).texOffs(588, 134).addBox(-67.0F, -9.0F, -8.0F, 26.0F, 6.0F, 1.0F).texOffs(184, 146).addBox(-64.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(194, 146).addBox(-64.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(204, 146).addBox(-48.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(214, 146).addBox(-48.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(104, 146).addBox(-56.0F, -9.0F, 8.0F, 4.0F, 5.0F, 1.0F).texOffs(114, 146).addBox(-56.0F, -9.0F, -9.0F, 4.0F, 5.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_pivote", CubeListBuilder.create().texOffs(480, 102).addBox(-57.0F, -12.0F, -7.0F, 6.0F, 4.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(492, 134).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(310, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(224, 146).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(46.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(328, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(518, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(346, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(526, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(492, 134).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(310, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(234, 146).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(62.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(328, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(518, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(346, 165).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(526, 134).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(492, 134).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(310, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(244, 146).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(46.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(328, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(518, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(346, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(526, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(492, 134).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(310, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(254, 146).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(62.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(328, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(518, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(346, 165).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(526, 134).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(642, 134).addBox(41.0F, -9.0F, 7.0F, 26.0F, 6.0F, 1.0F).texOffs(696, 134).addBox(41.0F, -9.0F, -8.0F, 26.0F, 6.0F, 1.0F).texOffs(264, 146).addBox(44.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(274, 146).addBox(44.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(284, 146).addBox(60.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(294, 146).addBox(60.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(124, 146).addBox(52.0F, -9.0F, 8.0F, 4.0F, 5.0F, 1.0F).texOffs(134, 146).addBox(52.0F, -9.0F, -9.0F, 4.0F, 5.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_pivote", CubeListBuilder.create().texOffs(520, 102).addBox(51.0F, -12.0F, -7.0F, 6.0F, 4.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bajo_piso", CubeListBuilder.create().texOffs(264, 47).addBox(-74.0F, -12.0F, -11.0F, 148.0F, 3.0F, 22.0F).texOffs(84, 80).addBox(-36.0F, -9.0F, -9.0F, 22.0F, 4.0F, 18.0F).texOffs(0, 80).addBox(10.0F, -9.0F, -9.0F, 24.0F, 4.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuellei", CubeListBuilder.create().texOffs(120, 47).addBox(-78.0F, -31.0F, -5.0F, 2.0F, 18.0F, 10.0F).texOffs(72, 146).addBox(-83.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(168, 47).addBox(-78.0F, -12.0F, -11.0F, 2.0F, 4.0F, 22.0F).texOffs(364, 165).addBox(-80.0F, -12.0F, -0.5F, 2.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topefi_0", CubeListBuilder.create().texOffs(888, 0).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(192, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefi_1", CubeListBuilder.create().texOffs(908, 0).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(250, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefi_2", CubeListBuilder.create().texOffs(928, 0).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(308, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_0", CubeListBuilder.create().texOffs(0, 134).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(672, 121).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefic_1", CubeListBuilder.create().texOffs(6, 134).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(694, 121).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_2", CubeListBuilder.create().texOffs(12, 134).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(716, 121).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_3", CubeListBuilder.create().texOffs(18, 134).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(738, 121).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_0", CubeListBuilder.create().texOffs(948, 0).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(366, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefd_1", CubeListBuilder.create().texOffs(968, 0).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(424, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_2", CubeListBuilder.create().texOffs(988, 0).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(482, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_0", CubeListBuilder.create().texOffs(24, 134).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(760, 121).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefdc_1", CubeListBuilder.create().texOffs(30, 134).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(782, 121).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_2", CubeListBuilder.create().texOffs(36, 134).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(804, 121).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_3", CubeListBuilder.create().texOffs(42, 134).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(826, 121).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fuelled", CubeListBuilder.create().texOffs(144, 47).addBox(76.0F, -31.0F, -5.0F, 2.0F, 18.0F, 10.0F).texOffs(88, 146).addBox(78.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(216, 47).addBox(76.0F, -12.0F, -11.0F, 2.0F, 4.0F, 22.0F).texOffs(370, 165).addBox(78.0F, -12.0F, -0.5F, 2.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topeti_0", CubeListBuilder.create().texOffs(0, 47).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(540, 0).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topeti_1", CubeListBuilder.create().texOffs(20, 47).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(598, 0).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_2", CubeListBuilder.create().texOffs(40, 47).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(656, 0).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_0", CubeListBuilder.create().texOffs(48, 134).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(848, 121).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topetic_1", CubeListBuilder.create().texOffs(54, 134).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(870, 121).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_2", CubeListBuilder.create().texOffs(60, 134).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(892, 121).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_3", CubeListBuilder.create().texOffs(66, 134).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(914, 121).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_0", CubeListBuilder.create().texOffs(60, 47).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(714, 0).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetd_1", CubeListBuilder.create().texOffs(80, 47).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(772, 0).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_2", CubeListBuilder.create().texOffs(100, 47).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(830, 0).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_0", CubeListBuilder.create().texOffs(72, 134).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(936, 121).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetdc_1", CubeListBuilder.create().texOffs(78, 134).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(958, 121).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_2", CubeListBuilder.create().texOffs(84, 134).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(980, 121).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_3", CubeListBuilder.create().texOffs(90, 134).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(1002, 121).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent0_0", CubeListBuilder.create().texOffs(750, 134).addBox(-6.0F, -37.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(560, 102).addBox(-2.5F, -37.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-48.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent0_1", CubeListBuilder.create().texOffs(784, 134).addBox(-6.0F, -37.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(594, 102).addBox(-2.5F, -37.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-48.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent1_0", CubeListBuilder.create().texOffs(818, 134).addBox(-6.0F, -37.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(628, 102).addBox(-2.5F, -37.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-16.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent1_1", CubeListBuilder.create().texOffs(852, 134).addBox(-6.0F, -37.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(662, 102).addBox(-2.5F, -37.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-16.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent2_0", CubeListBuilder.create().texOffs(886, 134).addBox(-6.0F, -37.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(696, 102).addBox(-2.5F, -37.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(16.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent2_1", CubeListBuilder.create().texOffs(920, 134).addBox(-6.0F, -37.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(730, 102).addBox(-2.5F, -37.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(16.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent3_0", CubeListBuilder.create().texOffs(954, 134).addBox(-6.0F, -37.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(764, 102).addBox(-2.5F, -37.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(48.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent3_1", CubeListBuilder.create().texOffs(988, 134).addBox(-6.0F, -37.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(798, 102).addBox(-2.5F, -37.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(48.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "caja_techo_0", 1.0001315789473686F, 1.0F, 0.7472589810980623F);
        escalar(g0, "caja_techo_1", 1.0001315789473686F, 1.0F, 0.7472589810980629F);
        escalar(g0, "caja_techo_2", 1.0001315789473686F, 1.0F, 0.7472589810980635F);
        escalar(g0, "caja_techo_3", 1.0001315789473686F, 1.0F, 0.7472589810980629F);
        escalar(g0, "caja_techo_4", 1.0001315789473686F, 1.0F, 0.7472589810980627F);
        escalar(g0, "caja_techo_5", 1.0001315789473686F, 1.0F, 0.7472589810980632F);
        escalar(g0, "caja_techo_6", 1.0001315789473686F, 1.0F, 0.747258981098062F);
        escalar(g0, "caja_techo_7", 1.0001315789473686F, 1.0F, 0.7472589810980637F);
        escalar(g0, "caja_techo_8", 1.0001315789473686F, 1.0F, 0.7472589810980632F);
        escalar(g0, "caja_techo_9", 1.0001315789473686F, 1.0F, 0.747258981098062F);
        escalar(g0, "caja_techo_10", 1.0001315789473686F, 1.0F, 0.747258981098064F);
        escalar(g0, "caja_techo_11", 1.0001315789473686F, 1.0F, 0.7472589810980628F);
        escalar(g0, "topefi_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topeti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "vent0_0", 0.2155718909193002F, 1.0F, 0.2155718909193002F);
        escalar(g0, "vent0_1", 0.2155718909193002F, 1.0F, 0.2155718909193002F);
        escalar(g0, "vent1_0", 0.2155718909193002F, 1.0F, 0.2155718909193002F);
        escalar(g0, "vent1_1", 0.2155718909193002F, 1.0F, 0.2155718909193002F);
        escalar(g0, "vent2_0", 0.2155718909193002F, 1.0F, 0.2155718909193002F);
        escalar(g0, "vent2_1", 0.2155718909193002F, 1.0F, 0.2155718909193002F);
        escalar(g0, "vent3_0", 0.2155718909193002F, 1.0F, 0.2155718909193002F);
        escalar(g0, "vent3_1", 0.2155718909193002F, 1.0F, 0.2155718909193002F);
    }
}
