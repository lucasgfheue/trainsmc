package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "TGM23" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloTGM23 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("tgm23"), "main"),
            LocomotoraMod.id("textures/entity/tgm23.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -4.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -4.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -4.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 8.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 8.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 8.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("ciegoi_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 18.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ciegoi_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 18.0F, -4.5F, 0.7853981633974483F, "cuerpo"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 1.5707963267948966F, 0.0F, -4.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 1.5707963267948966F, 0.0F, -4.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 1.5707963267948966F, 0.0F, -4.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("ciegod_0", DatosModelo.RUEDA, 4.5F, 0.0F, 1.5707963267948966F, 0.0F, 18.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ciegod_1", DatosModelo.RUEDA, 4.5F, 0.0F, 1.5707963267948966F, 0.0F, 18.0F, -4.5F, 0.7853981633974483F, "cuerpo"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 4.5F, 1.8F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 4.5F, 1.8F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 9.719999999999999F, -29.5F, 0.0F, "cuerpo", 4.8F, -5.5F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.15F, 0.0F, 10.0F, -28.0F, 0.15F, "cuerpo", -0.24F, -2.5F, 0.0F)),
            ModeloTGM23::crearCapa,
            16.0F,
            ModeloTGM23::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -16.0F, 8.0F)));

    private ModeloTGM23() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(974, 50).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(144, 88).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1014, 50).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 73).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(330, 88).addBox(-1.0F, -2.8F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-16.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(166, 88).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 73).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(188, 88).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(8, 73).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(974, 50).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(144, 88).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1014, 50).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(724, 73).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(336, 88).addBox(-1.0F, -2.8F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-4.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(166, 88).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 73).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(188, 88).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(8, 73).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(974, 50).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(144, 88).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1014, 50).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(734, 73).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(342, 88).addBox(-1.0F, -2.8F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(8.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(166, 88).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 73).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(188, 88).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(8, 73).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ciegoi_0", CubeListBuilder.create().texOffs(210, 88).addBox(-2.0F, -1.0F, -6.0F, 4.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, 0.003F)).texOffs(594, 73).addBox(-1.0F, -2.0F, -6.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, 0.006F)).texOffs(476, 92).addBox(-0.5F, -2.3F, -7.0F, 1.0F, 1.0F, 1.0F), PartPose.offset(18.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("ciegoi_1", CubeListBuilder.create().texOffs(222, 88).addBox(-2.0F, -1.0F, -6.0F, 4.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, 0.009000000000000001F)).texOffs(602, 73).addBox(-1.0F, -2.0F, -6.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, 0.012F)), PartPose.offsetAndRotation(18.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(974, 50).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(144, 88).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1014, 50).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(744, 73).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(348, 88).addBox(-1.0F, -2.8F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-16.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(166, 88).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 73).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(188, 88).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(8, 73).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(974, 50).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(144, 88).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1014, 50).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(754, 73).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(354, 88).addBox(-1.0F, -2.8F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-4.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(166, 88).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 73).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(188, 88).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(8, 73).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(974, 50).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(144, 88).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1014, 50).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(764, 73).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(360, 88).addBox(-1.0F, -2.8F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(8.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(166, 88).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 73).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(188, 88).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(8, 73).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ciegod_0", CubeListBuilder.create().texOffs(234, 88).addBox(-2.0F, -1.0F, 4.0F, 4.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, 0.003F)).texOffs(610, 73).addBox(-1.0F, -2.0F, 4.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, 0.006F)).texOffs(480, 92).addBox(-0.5F, -2.3F, 6.0F, 1.0F, 1.0F, 1.0F), PartPose.offset(18.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("ciegod_1", CubeListBuilder.create().texOffs(246, 88).addBox(-2.0F, -1.0F, 4.0F, 4.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, 0.009000000000000001F)).texOffs(618, 73).addBox(-1.0F, -2.0F, 4.0F, 2.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, 0.012F)), PartPose.offsetAndRotation(18.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(304, 92).addBox(-16.0F, -6.8F, -7.5F, 34.0F, 1.0F, 1.0F).texOffs(258, 88).addBox(-17.5F, -7.8F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(266, 88).addBox(-5.5F, -7.8F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(274, 88).addBox(6.5F, -7.8F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(282, 88).addBox(16.5F, -7.8F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(374, 92).addBox(-16.0F, -6.8F, 6.5F, 34.0F, 1.0F, 1.0F).texOffs(290, 88).addBox(-17.5F, -7.8F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(298, 88).addBox(-5.5F, -7.8F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(306, 88).addBox(6.5F, -7.8F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(314, 88).addBox(16.5F, -7.8F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(108, 73).addBox(-34.0F, -12.0F, 2.0F, 64.0F, 8.0F, 1.0F).texOffs(238, 73).addBox(-34.0F, -12.0F, -3.0F, 64.0F, 8.0F, 1.0F).texOffs(782, 0).addBox(-34.0F, -13.0F, -11.0F, 64.0F, 1.0F, 22.0F).texOffs(782, 73).addBox(-34.0F, -12.0F, 10.0F, 64.0F, 3.0F, 1.0F).texOffs(0, 84).addBox(-34.0F, -12.0F, -11.0F, 64.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_ciego", CubeListBuilder.create().texOffs(650, 73).addBox(15.0F, -9.0F, 2.0F, 6.0F, 3.0F, 2.0F).texOffs(666, 73).addBox(15.0F, -9.0F, -4.0F, 6.0F, 3.0F, 2.0F).texOffs(602, 0).addBox(-36.0F, -13.0F, -11.0F, 2.0F, 7.0F, 22.0F).texOffs(562, 73).addBox(-41.0F, -10.5F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(444, 92).addBox(-33.5F, -3.0F, -11.0F, 3.0F, 1.0F, 1.0F).texOffs(530, 73).addBox(-33.5F, -9.0F, -11.0F, 1.0F, 6.0F, 1.0F).texOffs(534, 73).addBox(-31.5F, -9.0F, -11.0F, 1.0F, 6.0F, 1.0F).texOffs(452, 92).addBox(-33.5F, -3.0F, 10.0F, 3.0F, 1.0F, 1.0F).texOffs(538, 73).addBox(-33.5F, -9.0F, 10.0F, 1.0F, 6.0F, 1.0F).texOffs(542, 73).addBox(-31.5F, -9.0F, 10.0F, 1.0F, 6.0F, 1.0F).texOffs(650, 0).addBox(30.0F, -13.0F, -11.0F, 2.0F, 7.0F, 22.0F).texOffs(578, 73).addBox(32.0F, -10.5F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(460, 92).addBox(26.5F, -3.0F, -11.0F, 3.0F, 1.0F, 1.0F).texOffs(546, 73).addBox(26.5F, -9.0F, -11.0F, 1.0F, 6.0F, 1.0F).texOffs(550, 73).addBox(28.5F, -9.0F, -11.0F, 1.0F, 6.0F, 1.0F).texOffs(468, 92).addBox(26.5F, -3.0F, 10.0F, 3.0F, 1.0F, 1.0F).texOffs(554, 73).addBox(26.5F, -9.0F, 10.0F, 1.0F, 6.0F, 1.0F).texOffs(558, 73).addBox(28.5F, -9.0F, 10.0F, 1.0F, 6.0F, 1.0F).texOffs(494, 0).addBox(-32.0F, -29.0F, -8.0F, 38.0F, 16.0F, 16.0F).texOffs(362, 50).addBox(-32.0F, -31.0F, -6.0F, 38.0F, 2.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_cantoi_0", CubeListBuilder.create().texOffs(378, 88).addBox(-19.0F, -1.0F, -0.5F, 38.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -29.309016994374943F, -7.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_1", CubeListBuilder.create().texOffs(456, 88).addBox(-19.0F, -1.0F, -0.5F, 38.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -29.89680224666742F, -7.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_2", CubeListBuilder.create().texOffs(534, 88).addBox(-19.0F, -1.0F, -0.5F, 38.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -30.39680224666742F, -7.39680224666742F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_3", CubeListBuilder.create().texOffs(612, 88).addBox(-19.0F, -1.0F, -0.5F, 38.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -30.7600735106701F, -6.89680224666742F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_4", CubeListBuilder.create().texOffs(690, 88).addBox(-19.0F, -1.0F, -0.5F, 38.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -30.951056516295154F, -6.3090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_0", CubeListBuilder.create().texOffs(768, 88).addBox(-19.0F, -1.0F, -0.5F, 38.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -29.309016994374943F, 7.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_1", CubeListBuilder.create().texOffs(846, 88).addBox(-19.0F, -1.0F, -0.5F, 38.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -29.89680224666742F, 7.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_2", CubeListBuilder.create().texOffs(924, 88).addBox(-19.0F, -1.0F, -0.5F, 38.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -30.39680224666742F, 7.39680224666742F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_3", CubeListBuilder.create().texOffs(0, 92).addBox(-19.0F, -1.0F, -0.5F, 38.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -30.7600735106701F, 6.89680224666742F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_4", CubeListBuilder.create().texOffs(78, 92).addBox(-19.0F, -1.0F, -0.5F, 38.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -30.951056516295154F, 6.3090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_tapaa", CubeListBuilder.create().texOffs(362, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 32.0F), PartPose.offset(-32.0F, -29.0F, -8.0F));
        g.addOrReplaceChild("capo_tapab", CubeListBuilder.create().texOffs(428, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 32.0F), PartPose.offset(5.0F, -29.0F, -8.0F));
        g.addOrReplaceChild("faro_i_0", CubeListBuilder.create().texOffs(778, 84).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(510, 50).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-32.05F, -17.0F, -5.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_1", CubeListBuilder.create().texOffs(802, 84).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(534, 50).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-32.05F, -17.0F, -5.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_2", CubeListBuilder.create().texOffs(826, 84).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(558, 50).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-32.05F, -17.0F, -5.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_3", CubeListBuilder.create().texOffs(850, 84).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(582, 50).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-32.05F, -17.0F, -5.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_vidrio", CubeListBuilder.create().texOffs(894, 50).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-32.669999999999995F, -17.0F, -5.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_0", CubeListBuilder.create().texOffs(874, 84).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(606, 50).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-32.05F, -17.0F, 5.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_1", CubeListBuilder.create().texOffs(898, 84).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(630, 50).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-32.05F, -17.0F, 5.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_2", CubeListBuilder.create().texOffs(922, 84).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(654, 50).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-32.05F, -17.0F, 5.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_3", CubeListBuilder.create().texOffs(946, 84).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(678, 50).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-32.05F, -17.0F, 5.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_vidrio", CubeListBuilder.create().texOffs(934, 50).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-32.669999999999995F, -17.0F, 5.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escape_0", CubeListBuilder.create().texOffs(462, 73).addBox(-6.0F, -34.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(294, 50).addBox(-2.5F, -34.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(-14.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("escape_1", CubeListBuilder.create().texOffs(496, 73).addBox(-6.0F, -34.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(328, 50).addBox(-2.5F, -34.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(-14.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador", CubeListBuilder.create().texOffs(432, 73).addBox(-28.0F, -32.0F, -4.0F, 7.0F, 1.0F, 8.0F), PartPose.ZERO);
        g.addOrReplaceChild("baranda_capo", CubeListBuilder.create().texOffs(156, 92).addBox(-31.0F, -28.0F, 8.5F, 36.0F, 1.0F, 1.0F).texOffs(626, 73).addBox(-31.5F, -27.0F, 8.5F, 1.0F, 5.0F, 1.0F).texOffs(630, 73).addBox(-13.5F, -27.0F, 8.5F, 1.0F, 5.0F, 1.0F).texOffs(634, 73).addBox(4.5F, -27.0F, 8.5F, 1.0F, 5.0F, 1.0F).texOffs(230, 92).addBox(-31.0F, -28.0F, -9.5F, 36.0F, 1.0F, 1.0F).texOffs(638, 73).addBox(-31.5F, -27.0F, -9.5F, 1.0F, 5.0F, 1.0F).texOffs(642, 73).addBox(-13.5F, -27.0F, -9.5F, 1.0F, 5.0F, 1.0F).texOffs(646, 73).addBox(4.5F, -27.0F, -9.5F, 1.0F, 5.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(188, 0).addBox(6.0F, -39.0F, -11.5F, 22.0F, 26.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_arco6", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 46.0F), PartPose.offset(6.0F, -39.0F, -11.5F));
        g.addOrReplaceChild("cabina_arco27", CubeListBuilder.create().texOffs(94, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 46.0F), PartPose.offset(27.0F, -39.0F, -11.5F));
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(130, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -37.094785999913285F, -11.141828989898364F, -2.472675635381741F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(184, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -38.34241651963849F, -9.349524103472586F, -2.5942969114195673F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(238, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -39.36338568288902F, -7.419093921532033F, -2.715918187457399F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(292, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -40.14261019068358F, -5.379057675258977F, -2.837539463495221F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(346, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -40.66857816132419F, -3.2595538622131706F, -2.9591607395330515F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(400, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -40.93351920130506F, -1.0918949949120025F, -3.0807820155708803F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(454, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -40.93351920130506F, 1.091894994912001F, 3.0807820155708803F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(508, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -40.66857816132419F, 3.259553862213168F, 2.9591607395330515F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(562, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -40.14261019068358F, 5.379057675258977F, 2.837539463495221F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(616, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -39.36338568288902F, 7.419093921532031F, 2.7159181874573988F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(670, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -38.34241651963849F, 9.349524103472582F, 2.5942969114195678F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(724, 84).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(17.0F, -37.094785999913285F, 11.141828989898361F, 2.4726756353817416F, 0.0F, 0.0F));
        g.addOrReplaceChild("bocina_0", CubeListBuilder.create().texOffs(258, 50).addBox(12.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(194, 50).addBox(12.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -41.0F, 3.0F));
        g.addOrReplaceChild("bocina_1", CubeListBuilder.create().texOffs(276, 50).addBox(12.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(226, 50).addBox(12.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -41.0F, 3.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("faro_ti_0", CubeListBuilder.create().texOffs(970, 84).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(702, 50).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(28.05F, -16.0F, -6.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_ti_1", CubeListBuilder.create().texOffs(994, 84).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(726, 50).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(28.05F, -16.0F, -6.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_ti_2", CubeListBuilder.create().texOffs(0, 88).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(750, 50).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(28.05F, -16.0F, -6.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_ti_3", CubeListBuilder.create().texOffs(24, 88).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(774, 50).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(28.05F, -16.0F, -6.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_ti_vidrio", CubeListBuilder.create().texOffs(368, 73).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(28.57F, -16.0F, -6.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_td_0", CubeListBuilder.create().texOffs(48, 88).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(798, 50).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(28.05F, -16.0F, 6.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_td_1", CubeListBuilder.create().texOffs(72, 88).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(822, 50).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(28.05F, -16.0F, 6.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_td_2", CubeListBuilder.create().texOffs(96, 88).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(846, 50).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(28.05F, -16.0F, 6.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_td_3", CubeListBuilder.create().texOffs(120, 88).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(870, 50).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(28.05F, -16.0F, 6.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_td_vidrio", CubeListBuilder.create().texOffs(400, 73).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(28.57F, -16.0F, 6.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_forro", CubeListBuilder.create().texOffs(698, 0).addBox(7.0F, -38.0F, 10.0F, 20.0F, 24.0F, 1.0F).texOffs(740, 0).addBox(7.0F, -38.0F, -11.0F, 20.0F, 24.0F, 1.0F).texOffs(278, 0).addBox(26.0F, -38.0F, -10.0F, 1.0F, 24.0F, 20.0F).texOffs(0, 50).addBox(7.0F, -14.0F, -11.0F, 20.0F, 1.0F, 22.0F).texOffs(84, 50).addBox(7.0F, -39.0F, -11.0F, 20.0F, 1.0F, 22.0F).texOffs(320, 0).addBox(7.0F, -38.0F, -10.0F, 1.0F, 24.0F, 20.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_pupitre", CubeListBuilder.create().texOffs(168, 50).addBox(8.0F, -28.0F, -10.0F, 4.0F, 14.0F, 9.0F).texOffs(996, 50).addBox(8.0F, -31.0F, -9.5F, 1.0F, 3.0F, 8.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(462, 50).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(9.6F, -29.5F, -5.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(366, 88).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(9.719999999999999F, -29.5F, -5.5F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro0", CubeListBuilder.create().texOffs(16, 73).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(9.6F, -29.5F, -9.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro0_aguja", CubeListBuilder.create().texOffs(484, 92).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.719999999999999F, -29.5F, -9.1F, 0.4F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro1", CubeListBuilder.create().texOffs(52, 73).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(9.6F, -29.5F, -1.9000000000000004F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro1_aguja", CubeListBuilder.create().texOffs(488, 92).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.719999999999999F, -29.5F, -1.9000000000000004F, 1.1F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_luces", CubeListBuilder.create().texOffs(492, 92).addBox(10.0F, -29.0F, -9.5F, 1.0F, 1.0F, 1.0F).texOffs(496, 92).addBox(10.0F, -29.0F, -8.3F, 1.0F, 1.0F, 1.0F).texOffs(500, 92).addBox(10.0F, -29.0F, -7.1F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(774, 73).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F).texOffs(322, 88).addBox(-1.0F, -6.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -28.0F, -2.5F, 0.0F, 0.0F, 0.15F));
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(778, 73).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -28.5F, -8.5F, 0.0F, 0.0F, -2.4668517113662407F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("cab_freno_perilla", CubeListBuilder.create().texOffs(504, 92).addBox(11.5F, -31.5F, -9.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(682, 73).addBox(16.0F, -17.259999999999998F, -8.5F, 4.0F, 1.0F, 4.0F).texOffs(88, 73).addBox(20.0F, -23.259999999999998F, -8.5F, 1.0F, 6.0F, 4.0F).texOffs(370, 88).addBox(17.5F, -16.259999999999998F, -7.0F, 1.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(698, 73).addBox(16.0F, -17.259999999999998F, 4.5F, 4.0F, 1.0F, 4.0F).texOffs(98, 73).addBox(20.0F, -23.259999999999998F, 4.5F, 1.0F, 6.0F, 4.0F).texOffs(374, 88).addBox(17.5F, -16.259999999999998F, 6.0F, 1.0F, 2.0F, 1.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "capo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_i_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_i_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_i_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_i_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_i_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "faro_d_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "escape_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "escape_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "cabina_arco6", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_arco27", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_techo_0", 1.0008333333333332F, 1.0F, 0.7359446586282741F);
        escalar(g0, "cabina_techo_1", 1.0008333333333332F, 1.0F, 0.7359446586282746F);
        escalar(g0, "cabina_techo_2", 1.0008333333333332F, 1.0F, 0.7359446586282737F);
        escalar(g0, "cabina_techo_3", 1.0008333333333332F, 1.0F, 0.7359446586282751F);
        escalar(g0, "cabina_techo_4", 1.0008333333333332F, 1.0F, 0.7359446586282742F);
        escalar(g0, "cabina_techo_5", 1.0008333333333332F, 1.0F, 0.7359446586282749F);
        escalar(g0, "cabina_techo_6", 1.0008333333333332F, 1.0F, 0.7359446586282737F);
        escalar(g0, "cabina_techo_7", 1.0008333333333332F, 1.0F, 0.7359446586282746F);
        escalar(g0, "cabina_techo_8", 1.0008333333333332F, 1.0F, 0.7359446586282757F);
        escalar(g0, "cabina_techo_9", 1.0008333333333332F, 1.0F, 0.7359446586282726F);
        escalar(g0, "cabina_techo_10", 1.0008333333333332F, 1.0F, 0.7359446586282751F);
        escalar(g0, "cabina_techo_11", 1.0008333333333332F, 1.0F, 0.7359446586282745F);
        escalar(g0, "bocina_0", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
        escalar(g0, "bocina_1", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
        escalar(g0, "faro_ti_0", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_ti_1", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_ti_2", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_ti_3", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_ti_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "faro_td_0", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_td_1", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_td_2", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_td_3", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_td_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "cab_velocimetro", 0.2333333333333333F, 0.6F, 0.2333333333333333F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.574F, 0.6F);
        escalar(g0, "cab_manometro0", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro0_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_manometro1", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro1_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_freno", 0.8F, 0.8003905296791061F, 0.8F);
    }
}
