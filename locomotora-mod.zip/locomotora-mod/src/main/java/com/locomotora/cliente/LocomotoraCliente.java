package com.locomotora.cliente;

import com.locomotora.LocomotoraMod;
import com.locomotora.cliente.modelos.DatosModelo;
import com.locomotora.cliente.modelos.ModeloAdler;
import com.locomotora.cliente.modelos.ModeloBR01;
import com.locomotora.cliente.modelos.ModeloBR9F;
import com.locomotora.cliente.modelos.ModeloBestFriend;
import com.locomotora.cliente.modelos.ModeloBigBoy;
import com.locomotora.cliente.modelos.ModeloCC72000;
import com.locomotora.cliente.modelos.ModeloChME3;
import com.locomotora.cliente.modelos.ModeloClass08;
import com.locomotora.cliente.modelos.ModeloClass20Abandonada;
import com.locomotora.cliente.modelos.ModeloClass37Abandonada;
import com.locomotora.cliente.modelos.ModeloCoppernob;
import com.locomotora.cliente.modelos.ModeloD51;
import com.locomotora.cliente.modelos.ModeloDD51;
import com.locomotora.cliente.modelos.ModeloDF200;
import com.locomotora.cliente.modelos.ModeloDF4;
import com.locomotora.cliente.modelos.ModeloDeltic;
import com.locomotora.cliente.modelos.ModeloDeutz;
import com.locomotora.cliente.modelos.ModeloE8Abandonada;
import com.locomotora.cliente.modelos.ModeloES44;
import com.locomotora.cliente.modelos.ModeloF7;
import com.locomotora.cliente.modelos.ModeloGE44;
import com.locomotora.cliente.modelos.ModeloGP9Abandonada;
import com.locomotora.cliente.modelos.ModeloGS4;
import com.locomotora.cliente.modelos.ModeloGarratt;
import com.locomotora.cliente.modelos.ModeloHST;
import com.locomotora.cliente.modelos.ModeloHamburger;
import com.locomotora.cliente.modelos.ModeloHiawatha;
import com.locomotora.cliente.modelos.ModeloJohnBull;
import com.locomotora.cliente.modelos.ModeloJupiter;
import com.locomotora.cliente.modelos.ModeloKiHa40Abandonado;
import com.locomotora.cliente.modelos.ModeloLocomotion;
import com.locomotora.cliente.modelos.ModeloM62Abandonada;
import com.locomotora.cliente.modelos.ModeloMallard;
import com.locomotora.cliente.modelos.ModeloMerchant;
import com.locomotora.cliente.modelos.ModeloNWJ;
import com.locomotora.cliente.modelos.ModeloP36;
import com.locomotora.cliente.modelos.ModeloP42;
import com.locomotora.cliente.modelos.ModeloPannier;
import com.locomotora.cliente.modelos.ModeloPlymouth;
import com.locomotora.cliente.modelos.ModeloPortena;
import com.locomotora.cliente.modelos.ModeloRDCAbandonado;
import com.locomotora.cliente.modelos.ModeloRS3Abandonada;
import com.locomotora.cliente.modelos.ModeloRocket;
import com.locomotora.cliente.modelos.ModeloSD40;
import com.locomotora.cliente.modelos.ModeloScotsman;
import com.locomotora.cliente.modelos.ModeloSharknoseAbandonada;
import com.locomotora.cliente.modelos.ModeloShay;
import com.locomotora.cliente.modelos.ModeloSimplex;
import com.locomotora.cliente.modelos.ModeloT1;
import com.locomotora.cliente.modelos.ModeloT478Abandonada;
import com.locomotora.cliente.modelos.ModeloTEP60Abandonada;
import com.locomotora.cliente.modelos.ModeloTGM23;
import com.locomotora.cliente.modelos.ModeloTunel;
import com.locomotora.cliente.modelos.ModeloV160;
import com.locomotora.cliente.modelos.ModeloV200;
import com.locomotora.cliente.modelos.ModeloCocheDiligencia;
import com.locomotora.cliente.modelos.ModeloCocheOeste;
import com.locomotora.cliente.modelos.ModeloCocheTeca;
import com.locomotora.cliente.modelos.ModeloCocheCama;
import com.locomotora.cliente.modelos.ModeloCocheDaylight;
import com.locomotora.cliente.modelos.ModeloCocheMirador;
import com.locomotora.cliente.modelos.ModeloCocheDomo;
import com.locomotora.cliente.modelos.ModeloCocheIndio;
import com.locomotora.cliente.modelos.ModeloCocheTrenAzul;
import com.locomotora.cliente.modelos.ModeloCocheMk3;
import com.locomotora.cliente.modelos.ModeloCocheDosPisos;
import com.locomotora.cliente.modelos.ModeloVagonCarbon;
import com.locomotora.cliente.modelos.ModeloVagonCisterna;
import com.locomotora.cliente.modelos.ModeloVagonDovelas;
import com.locomotora.cliente.modelos.ModeloVagonG10;
import com.locomotora.cliente.modelos.ModeloVagonRefrigerado;
import com.locomotora.cliente.modelos.ModeloVagonTroncos;
import com.locomotora.cliente.modelos.ModeloVagonContenedores;
import com.locomotora.cliente.modelos.ModeloVagonPetrolero;
import com.locomotora.cliente.modelos.ModeloVagonTaki;
import com.locomotora.cliente.modelos.ModeloVagonGlp;
import com.locomotora.cliente.modelos.ModeloVagonLadrillos;
import com.locomotora.cliente.modelos.ModeloVagonSkip;
import com.locomotora.cliente.modelos.ModeloVagonTolva;
import com.locomotora.cliente.modelos.ModeloVagonVolteo;
import com.locomotora.cliente.modelos.ModeloWDM2;
import com.locomotora.cliente.modelos.ModeloZephyr;
import com.locomotora.entidad.LocomotoraEntity;
import com.locomotora.entidad.TipoLocomotora;
import com.locomotora.entidad.TipoVagon;
import com.locomotora.entidad.VagonEntity;
import com.locomotora.registro.ModBloques;
import com.locomotora.registro.ModEntidades;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.neoforge.common.NeoForge;

/** Parte del mod que solo se carga en el cliente (gráficos). */
@Mod(value = LocomotoraMod.MODID, dist = Dist.CLIENT)
public class LocomotoraCliente {

    public LocomotoraCliente(IEventBus modEventBus, ModContainer contenedor) {
        modEventBus.addListener(LocomotoraCliente::registrarRenderers);
        modEventBus.addListener(LocomotoraCliente::registrarModelos);
        modEventBus.addListener(LocomotoraCliente::registrarPantallas);
        // Con una vía en la mano se ve dónde va a quedar la pieza
        NeoForge.EVENT_BUS.addListener(VistaPrevia::dibujar);
    }

    private static void registrarPantallas(RegisterMenuScreensEvent event) {
        event.register(ModBloques.VIA_MENU.get(), ViaScreen::new);
    }

    public static DatosModelo datosDe(TipoLocomotora tipo) {
        return switch (tipo) {
            case SCOTSMAN -> ModeloScotsman.DATOS;
            case F7 -> ModeloF7.DATOS;
            case V200 -> ModeloV200.DATOS;
            case MALLARD -> ModeloMallard.DATOS;
            case BIG_BOY -> ModeloBigBoy.DATOS;
            case GS4 -> ModeloGS4.DATOS;
            case BR01 -> ModeloBR01.DATOS;
            case PANNIER -> ModeloPannier.DATOS;
            case HST -> ModeloHST.DATOS;
            case DELTIC -> ModeloDeltic.DATOS;
            case SD40 -> ModeloSD40.DATOS;
            case ES44 -> ModeloES44.DATOS;
            case DD51 -> ModeloDD51.DATOS;
            case CLASS08 -> ModeloClass08.DATOS;
            case ROCKET -> ModeloRocket.DATOS;
            case JUPITER -> ModeloJupiter.DATOS;
            case HIAWATHA -> ModeloHiawatha.DATOS;
            case T1 -> ModeloT1.DATOS;
            case NWJ -> ModeloNWJ.DATOS;
            case MERCHANT -> ModeloMerchant.DATOS;
            case BR9F -> ModeloBR9F.DATOS;
            case D51 -> ModeloD51.DATOS;
            case P36 -> ModeloP36.DATOS;
            case GARRATT -> ModeloGarratt.DATOS;
            case ZEPHYR -> ModeloZephyr.DATOS;
            case HAMBURGER -> ModeloHamburger.DATOS;
            case V160 -> ModeloV160.DATOS;
            case CC72000 -> ModeloCC72000.DATOS;
            case CHME3 -> ModeloChME3.DATOS;
            case DF4 -> ModeloDF4.DATOS;
            case WDM2 -> ModeloWDM2.DATOS;
            case P42 -> ModeloP42.DATOS;
            case DF200 -> ModeloDF200.DATOS;
            case GP9_ABANDONADA -> ModeloGP9Abandonada.DATOS;
            case E8_ABANDONADA -> ModeloE8Abandonada.DATOS;
            case RS3_ABANDONADA -> ModeloRS3Abandonada.DATOS;
            case RDC_ABANDONADO -> ModeloRDCAbandonado.DATOS;
            case CLASS37_ABANDONADA -> ModeloClass37Abandonada.DATOS;
            case CLASS20_ABANDONADA -> ModeloClass20Abandonada.DATOS;
            case M62_ABANDONADA -> ModeloM62Abandonada.DATOS;
            case TEP60_ABANDONADA -> ModeloTEP60Abandonada.DATOS;
            case T478_ABANDONADA -> ModeloT478Abandonada.DATOS;
            case KIHA40_ABANDONADO -> ModeloKiHa40Abandonado.DATOS;
            case SHARKNOSE_ABANDONADA -> ModeloSharknoseAbandonada.DATOS;
            case LOCOMOTION -> ModeloLocomotion.DATOS;
            case BEST_FRIEND -> ModeloBestFriend.DATOS;
            case JOHN_BULL -> ModeloJohnBull.DATOS;
            case ADLER -> ModeloAdler.DATOS;
            case COPPERNOB -> ModeloCoppernob.DATOS;
            case PORTENA -> ModeloPortena.DATOS;
            case SHAY -> ModeloShay.DATOS;
            case SIMPLEX -> ModeloSimplex.DATOS;
            case DEUTZ -> ModeloDeutz.DATOS;
            case GE44 -> ModeloGE44.DATOS;
            case PLYMOUTH -> ModeloPlymouth.DATOS;
            case TGM23 -> ModeloTGM23.DATOS;
            case TUNEL -> ModeloTunel.DATOS;
        };
    }

    public static DatosModelo datosDe(TipoVagon tipo) {
        return switch (tipo) {
            case SKIP -> ModeloVagonSkip.DATOS;
            case LADRILLOS -> ModeloVagonLadrillos.DATOS;
            case CARBON -> ModeloVagonCarbon.DATOS;
            case TOLVA -> ModeloVagonTolva.DATOS;
            case VOLTEO -> ModeloVagonVolteo.DATOS;
            case CISTERNA -> ModeloVagonCisterna.DATOS;
            case DOVELAS -> ModeloVagonDovelas.DATOS;
            case G10 -> ModeloVagonG10.DATOS;
            case REFRIGERADO -> ModeloVagonRefrigerado.DATOS;
            case TRONCOS -> ModeloVagonTroncos.DATOS;
            case CONTENEDORES -> ModeloVagonContenedores.DATOS;
            case PETROLERO -> ModeloVagonPetrolero.DATOS;
            case TAKI -> ModeloVagonTaki.DATOS;
            case GLP -> ModeloVagonGlp.DATOS;
            case DILIGENCIA -> ModeloCocheDiligencia.DATOS;
            case OESTE -> ModeloCocheOeste.DATOS;
            case TECA -> ModeloCocheTeca.DATOS;
            case CAMA -> ModeloCocheCama.DATOS;
            case DAYLIGHT -> ModeloCocheDaylight.DATOS;
            case MIRADOR -> ModeloCocheMirador.DATOS;
            case DOMO -> ModeloCocheDomo.DATOS;
            case INDIO -> ModeloCocheIndio.DATOS;
            case TREN_AZUL -> ModeloCocheTrenAzul.DATOS;
            case MK3 -> ModeloCocheMk3.DATOS;
            case DOS_PISOS -> ModeloCocheDosPisos.DATOS;
        };
    }

    private static void registrarRenderers(EntityRenderersEvent.RegisterRenderers event) {
        for (TipoLocomotora tipo : TipoLocomotora.values()) {
            DatosModelo datos = datosDe(tipo);
            event.registerEntityRenderer(ModEntidades.porTipo(tipo).get(),
                    contexto -> new LocomotoraRenderer<LocomotoraEntity>(contexto, datos, 1.3F));
        }
        for (TipoVagon tipo : TipoVagon.values()) {
            DatosModelo datos = datosDe(tipo);
            event.registerEntityRenderer(ModEntidades.porTipo(tipo).get(),
                    contexto -> new LocomotoraRenderer<VagonEntity>(contexto, datos, 0.8F));
        }
        // Las vías curvas, los desvíos y las subidas se dibujan redondos
        event.registerBlockEntityRenderer(ModBloques.VIA_ENTIDAD.get(), ViaRenderer::new);
    }

    private static void registrarModelos(EntityRenderersEvent.RegisterLayerDefinitions event) {
        for (TipoLocomotora tipo : TipoLocomotora.values()) {
            DatosModelo datos = datosDe(tipo);
            event.registerLayerDefinition(datos.capa(), datos.fabricaCapa());
        }
        for (TipoVagon tipo : TipoVagon.values()) {
            DatosModelo datos = datosDe(tipo);
            event.registerLayerDefinition(datos.capa(), datos.fabricaCapa());
        }
    }
}
