package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "SP GS-4 Daylight" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloGS4 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("gs4"), "main"),
            LocomotoraMod.id("textures/entity/gs4.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, -24.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, -24.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, -24.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, -4.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, -4.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, -4.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 16.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 16.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 16.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi3_0", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 36.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi3_1", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 36.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi3_2", DatosModelo.RUEDA, 9.5F, 0.0F, 0.0F, 0.0F, 36.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 9.5F, 3.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_i", DatosModelo.MOTRIZ, 9.5F, 3.5F, 0.0F, -44.0F, 16.0F, -13.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_i", DatosModelo.CRUCETA, 9.5F, 3.5F, 0.0F, -44.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, -24.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, -24.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, -24.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, -4.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, -4.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, -4.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd3_0", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 36.0F, -9.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd3_1", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 36.0F, -9.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd3_2", DatosModelo.RUEDA, 9.5F, 0.0F, 1.5707963267948966F, 0.0F, 36.0F, -9.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 9.5F, 3.5F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_d", DatosModelo.MOTRIZ, 9.5F, 3.5F, 1.5707963267948966F, -44.0F, 16.0F, -13.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_d", DatosModelo.CRUCETA, 9.5F, 3.5F, 1.5707963267948966F, -44.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -72.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -72.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -72.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -58.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -58.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -58.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -72.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -72.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -72.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -58.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -58.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -58.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 56.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 56.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 56.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 70.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 70.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 70.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 56.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 56.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 56.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 70.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 70.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 70.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 48.72F, -35.6F, 0.0F, "locomotora", 4.8F, 2.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.0F, 0.0F, 53.0F, -23.0F, 0.0F, "locomotora", -0.22F, 8.0F, 0.0F),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 110.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 110.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 110.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 162.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 162.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 162.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 174.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 174.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 174.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 186.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 186.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 186.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 86.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 98.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 110.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 110.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 110.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 162.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 162.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 162.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 174.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 174.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 174.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 186.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 186.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 186.0F, -4.5F, 1.0471975511965976F, "tender")),
            ModeloGS4::crearCapa,
            16.0F,
            ModeloGS4::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -65.0F, 63.0F),
                new DatosModelo.Segmento("tender", 98.0F, 174.0F)));

    private ModeloGS4() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        piezas5(g0);
        piezas6(g1);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
        escalas2(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(290, 170).addBox(-9.5F, -9.5F, -6.0F, 19.0F, 19.0F, 2.0F).texOffs(70, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(356, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(520, 296).addBox(-1.0F, -4.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-24.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(110, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(150, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(290, 170).addBox(-9.5F, -9.5F, -6.0F, 19.0F, 19.0F, 2.0F).texOffs(70, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(356, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(410, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(526, 296).addBox(-1.0F, -4.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-4.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(110, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(150, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(290, 170).addBox(-9.5F, -9.5F, -6.0F, 19.0F, 19.0F, 2.0F).texOffs(70, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(356, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(420, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(532, 296).addBox(-1.0F, -4.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(16.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(110, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(150, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi3_0", CubeListBuilder.create().texOffs(290, 170).addBox(-9.5F, -9.5F, -6.0F, 19.0F, 19.0F, 2.0F).texOffs(70, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(356, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(430, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(538, 296).addBox(-1.0F, -4.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(36.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmi3_1", CubeListBuilder.create().texOffs(110, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi3_2", CubeListBuilder.create().texOffs(150, 229).addBox(-9.0F, -2.5F, -6.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 170).addBox(-2.5F, -9.0F, -6.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(856, 301).addBox(-24.0F, -13.5F, -7.5F, 60.0F, 1.0F, 1.0F).texOffs(224, 286).addBox(-25.5F, -14.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(232, 286).addBox(-5.5F, -14.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(240, 286).addBox(14.5F, -14.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(248, 286).addBox(34.5F, -14.5F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_i", CubeListBuilder.create().texOffs(122, 303).addBox(-44.0F, -0.5F, -0.5F, 44.0F, 1.0F, 1.0F).texOffs(256, 286).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(16.0F, -13.0F, -8.5F));
        g.addOrReplaceChild("cruceta_i", CubeListBuilder.create().texOffs(440, 253).addBox(-29.36057455164034F, -11.0F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(430, 303).addBox(-37.86057455164034F, -10.0F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_i", CubeListBuilder.create().texOffs(302, 303).addBox(-35.36057455164034F, -8.0F, -9.0F, 15.0F, 1.0F, 1.0F).texOffs(334, 303).addBox(-35.36057455164034F, -12.0F, -9.0F, 15.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_i_0", CubeListBuilder.create().texOffs(44, 206).addBox(-47.36057455164034F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(698, 191).addBox(-47.36057455164034F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, -8.5F));
        g.addOrReplaceChild("cil_i_1", CubeListBuilder.create().texOffs(72, 206).addBox(-47.36057455164034F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(742, 191).addBox(-47.36057455164034F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_2", CubeListBuilder.create().texOffs(100, 206).addBox(-47.36057455164034F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(786, 191).addBox(-47.36057455164034F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_3", CubeListBuilder.create().texOffs(128, 206).addBox(-47.36057455164034F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(830, 191).addBox(-47.36057455164034F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_0", CubeListBuilder.create().texOffs(882, 206).addBox(-47.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(484, 206).addBox(-47.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, -8.5F));
        g.addOrReplaceChild("cil_i_a_1", CubeListBuilder.create().texOffs(888, 206).addBox(-47.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(506, 206).addBox(-47.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_2", CubeListBuilder.create().texOffs(894, 206).addBox(-47.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(528, 206).addBox(-47.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_3", CubeListBuilder.create().texOffs(900, 206).addBox(-47.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(550, 206).addBox(-47.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_0", CubeListBuilder.create().texOffs(906, 206).addBox(-35.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(572, 206).addBox(-35.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, -8.5F));
        g.addOrReplaceChild("cil_i_b_1", CubeListBuilder.create().texOffs(912, 206).addBox(-35.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(594, 206).addBox(-35.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_2", CubeListBuilder.create().texOffs(918, 206).addBox(-35.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(616, 206).addBox(-35.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_3", CubeListBuilder.create().texOffs(924, 206).addBox(-35.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(638, 206).addBox(-35.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(290, 170).addBox(-9.5F, -9.5F, 4.0F, 19.0F, 19.0F, 2.0F).texOffs(70, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(356, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(544, 296).addBox(-1.0F, -4.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-24.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(110, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(150, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(290, 170).addBox(-9.5F, -9.5F, 4.0F, 19.0F, 19.0F, 2.0F).texOffs(70, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(356, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(460, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(550, 296).addBox(-1.0F, -4.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-4.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(110, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(150, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(290, 170).addBox(-9.5F, -9.5F, 4.0F, 19.0F, 19.0F, 2.0F).texOffs(70, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(356, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(556, 296).addBox(-1.0F, -4.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(16.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(110, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(150, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd3_0", CubeListBuilder.create().texOffs(290, 170).addBox(-9.5F, -9.5F, 4.0F, 19.0F, 19.0F, 2.0F).texOffs(70, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(356, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(562, 296).addBox(-1.0F, -4.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(36.0F, -9.5F, 0.0F));
        g.addOrReplaceChild("rmd3_1", CubeListBuilder.create().texOffs(110, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -9.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd3_2", CubeListBuilder.create().texOffs(150, 229).addBox(-9.0F, -2.5F, 4.0F, 18.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 170).addBox(-2.5F, -9.0F, 4.0F, 5.0F, 18.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -9.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(0, 303).addBox(-24.0F, -13.5F, 6.5F, 60.0F, 1.0F, 1.0F).texOffs(264, 286).addBox(-25.5F, -14.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(272, 286).addBox(-5.5F, -14.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(280, 286).addBox(14.5F, -14.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(288, 286).addBox(34.5F, -14.5F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_d", CubeListBuilder.create().texOffs(212, 303).addBox(-44.0F, -0.5F, -0.5F, 44.0F, 1.0F, 1.0F).texOffs(296, 286).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(16.0F, -13.0F, 8.5F));
        g.addOrReplaceChild("cruceta_d", CubeListBuilder.create().texOffs(490, 253).addBox(-29.36057455164034F, -11.0F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(452, 303).addBox(-37.86057455164034F, -10.0F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_d", CubeListBuilder.create().texOffs(366, 303).addBox(-35.36057455164034F, -8.0F, 8.0F, 15.0F, 1.0F, 1.0F).texOffs(398, 303).addBox(-35.36057455164034F, -12.0F, 8.0F, 15.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_d_0", CubeListBuilder.create().texOffs(156, 206).addBox(-47.36057455164034F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(874, 191).addBox(-47.36057455164034F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, 8.5F));
        g.addOrReplaceChild("cil_d_1", CubeListBuilder.create().texOffs(184, 206).addBox(-47.36057455164034F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(918, 191).addBox(-47.36057455164034F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_2", CubeListBuilder.create().texOffs(212, 206).addBox(-47.36057455164034F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(962, 191).addBox(-47.36057455164034F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_3", CubeListBuilder.create().texOffs(240, 206).addBox(-47.36057455164034F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(0, 206).addBox(-47.36057455164034F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_0", CubeListBuilder.create().texOffs(930, 206).addBox(-47.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(660, 206).addBox(-47.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, 8.5F));
        g.addOrReplaceChild("cil_d_a_1", CubeListBuilder.create().texOffs(936, 206).addBox(-47.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(682, 206).addBox(-47.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_2", CubeListBuilder.create().texOffs(942, 206).addBox(-47.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(704, 206).addBox(-47.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_3", CubeListBuilder.create().texOffs(948, 206).addBox(-47.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(726, 206).addBox(-47.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_0", CubeListBuilder.create().texOffs(954, 206).addBox(-35.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(748, 206).addBox(-35.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, 8.5F));
        g.addOrReplaceChild("cil_d_b_1", CubeListBuilder.create().texOffs(960, 206).addBox(-35.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(770, 206).addBox(-35.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_2", CubeListBuilder.create().texOffs(966, 206).addBox(-35.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(792, 206).addBox(-35.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_3", CubeListBuilder.create().texOffs(972, 206).addBox(-35.86057455164034F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(814, 206).addBox(-35.86057455164034F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rbi0_0", CubeListBuilder.create().texOffs(978, 206).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(660, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(500, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-72.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi0_1", CubeListBuilder.create().texOffs(682, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(8, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-72.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi0_2", CubeListBuilder.create().texOffs(704, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(16, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-72.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbi1_0", CubeListBuilder.create().texOffs(978, 206).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(660, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-58.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi1_1", CubeListBuilder.create().texOffs(682, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(8, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi1_2", CubeListBuilder.create().texOffs(704, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(16, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd0_0", CubeListBuilder.create().texOffs(978, 206).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(660, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(520, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-72.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd0_1", CubeListBuilder.create().texOffs(682, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(8, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-72.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd0_2", CubeListBuilder.create().texOffs(704, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(16, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-72.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd1_0", CubeListBuilder.create().texOffs(978, 206).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(660, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(530, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-58.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd1_1", CubeListBuilder.create().texOffs(682, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(8, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd1_2", CubeListBuilder.create().texOffs(704, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(16, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(268, 206).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(34, 248).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 206).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(540, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(56.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(58, 248).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 206).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(82, 248).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 206).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti1_0", CubeListBuilder.create().texOffs(268, 206).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(34, 248).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 206).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(550, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(70.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti1_1", CubeListBuilder.create().texOffs(58, 248).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 206).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(70.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti1_2", CubeListBuilder.create().texOffs(82, 248).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 206).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(70.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(268, 206).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(34, 248).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 206).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(560, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(56.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(58, 248).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 206).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(82, 248).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 206).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd1_0", CubeListBuilder.create().texOffs(268, 206).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(34, 248).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 206).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(570, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(70.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd1_1", CubeListBuilder.create().texOffs(58, 248).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 206).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(70.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd1_2", CubeListBuilder.create().texOffs(82, 248).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 206).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(70.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(586, 170).addBox(-76.0F, -18.0F, 2.0F, 154.0F, 14.0F, 1.0F).texOffs(0, 191).addBox(-76.0F, -18.0F, -3.0F, 154.0F, 14.0F, 1.0F).texOffs(250, 138).addBox(-70.0F, -22.0F, -13.0F, 122.0F, 1.0F, 26.0F).texOffs(488, 229).addBox(-70.0F, -22.0F, 12.0F, 122.0F, 5.0F, 1.0F).texOffs(734, 229).addBox(-70.0F, -22.0F, -13.0F, 122.0F, 5.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_humo_0", CubeListBuilder.create().texOffs(152, 69).addBox(-62.0F, -31.0F, -3.5F, 14.0F, 62.0F, 7.0F).texOffs(0, 0).addBox(-62.0F, -3.5F, -31.0F, 14.0F, 7.0F, 62.0F), PartPose.offset(0.0F, -29.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_1", CubeListBuilder.create().texOffs(194, 69).addBox(-62.0F, -31.0F, -3.5F, 14.0F, 62.0F, 7.0F).texOffs(152, 0).addBox(-62.0F, -3.5F, -31.0F, 14.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 0.2243994752564138F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_2", CubeListBuilder.create().texOffs(236, 69).addBox(-62.0F, -31.0F, -3.5F, 14.0F, 62.0F, 7.0F).texOffs(304, 0).addBox(-62.0F, -3.5F, -31.0F, 14.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 0.4487989505128276F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_3", CubeListBuilder.create().texOffs(278, 69).addBox(-62.0F, -31.0F, -3.5F, 14.0F, 62.0F, 7.0F).texOffs(456, 0).addBox(-62.0F, -3.5F, -31.0F, 14.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 0.6731984257692414F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_4", CubeListBuilder.create().texOffs(320, 69).addBox(-62.0F, -31.0F, -3.5F, 14.0F, 62.0F, 7.0F).texOffs(608, 0).addBox(-62.0F, -3.5F, -31.0F, 14.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 0.8975979010256552F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_5", CubeListBuilder.create().texOffs(362, 69).addBox(-62.0F, -31.0F, -3.5F, 14.0F, 62.0F, 7.0F).texOffs(760, 0).addBox(-62.0F, -3.5F, -31.0F, 14.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 1.121997376282069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_6", CubeListBuilder.create().texOffs(404, 69).addBox(-62.0F, -31.0F, -3.5F, 14.0F, 62.0F, 7.0F).texOffs(0, 69).addBox(-62.0F, -3.5F, -31.0F, 14.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 0.0F, 1.3463968515384828F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(700, 253).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -38.15872819274321F, 1.0319408312224079F, 3.0293951539917425F, -0.0007101589678742508F, -0.006302877957252239F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(754, 253).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -38.30684778615685F, 1.0486299012691316F, 3.029395153991743F, -0.0007101589678742413F, -0.006302877957252239F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(808, 253).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -38.454967379570476F, 1.0653189713158553F, 3.0293951539917434F, -0.0007101589678742508F, -0.006302877957252239F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(862, 253).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -38.603086972984116F, 1.0820080413625788F, 3.029395153991744F, -0.0007101589678742413F, -0.006302877957252239F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(916, 253).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -37.69947131764068F, 3.0440766713800835F, 2.8049997115384957F, -0.0020948679237364634F, -0.005986833089233913F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(970, 253).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -37.840163576147F, 3.093307021860624F, 2.804999711538496F, -0.002094867923736473F, -0.005986833089234065F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(0, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -37.98085583465331F, 3.142537372341165F, 2.804999711538496F, -0.0020948679237364634F, -0.005986833089233913F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(54, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -38.12154809315963F, 3.191767722821705F, 2.8049997115384966F, -0.0020948679237364543F, -0.005986833089234065F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(108, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -36.803986624842956F, 4.903569796277552F, 2.5806030270971707F, -0.0033745349311716907F, -0.005370587780477477F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(162, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -36.93019665112074F, 4.982872811850775F, 2.5806030270971707F, -0.0033745349311716907F, -0.005370587780477628F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(216, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -37.05640667739853F, 5.062175827423997F, 2.5806030270971707F, -0.0033745349311716907F, -0.005370587780477477F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(270, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -37.18261670367631F, 5.141478842997219F, 2.580603027097171F, -0.0033745349311716717F, -0.005370587780477628F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(324, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -35.51717745606536F, 6.517177456065364F, 2.356204547907189F, -0.00448499274658389F, -0.004485037855437628F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(378, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -35.62257655238987F, 6.622576552389871F, 2.356204547907189F, -0.004484992746583871F, -0.004485037855437628F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(432, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -35.72797564871438F, 6.727975648714379F, 2.356204547907189F, -0.00448499274658389F, -0.004485037855437628F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(486, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -35.83337474503888F, 6.833374745038887F, 2.3562045479071894F, -0.004484992746583871F, -0.004485037855437628F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(540, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -33.90356979627755F, 7.803986624842955F, 2.131804076663432F, -0.005370557201465989F, -0.0033745835976022546F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(594, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -33.982872811850775F, 7.930196651120739F, 2.1318040766634323F, -0.005370557201465989F, -0.0033745835976022546F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(648, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -34.062175827424F, 8.056406677398524F, 2.1318040766634327F, -0.005370557201466027F, -0.0033745835976021037F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(702, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -34.14147884299722F, 8.182616703676308F, 2.1318040766634327F, -0.005370557201465989F, -0.0033745835976022546F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(756, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -32.04407667138008F, 8.699471317640675F, 1.907401810611465F, -0.005986819952558298F, -0.002094905466493948F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(810, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -32.093307021860625F, 8.840163576146992F, 1.907401810611464F, -0.005986819952558298F, -0.002094905466493948F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(864, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -32.14253737234117F, 8.980855834653312F, 1.9074018106114639F, -0.005986819952558374F, -0.0020949054664937965F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(918, 258).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -32.19176772282171F, 9.121548093159632F, 1.9074018106114636F, -0.005986819952558298F, -0.002094905466493948F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(0, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -30.031940831222407F, 9.158728192743206F, 1.6829983024971493F, -0.00630287636787944F, -0.0007101730740866365F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(54, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -30.04862990126913F, 9.306847786156844F, 1.6829983024971498F, -0.00630287636787944F, -0.0007101730740866365F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(108, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -30.065318971315854F, 9.45496737957048F, 1.6829983024971495F, -0.006302876367879478F, -0.0007101730740866365F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(162, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -30.082008041362577F, 9.60308697298412F, 1.6829983024971495F, -0.00630287636787944F, -0.0007101730740866365F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(216, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -27.968059168777593F, 9.158728192743208F, 1.4585943510926438F, -0.00630287636787944F, 0.0007101730740866365F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(270, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -27.95137009873087F, 9.306847786156844F, 1.4585943510926433F, -0.00630287636787944F, 0.0007101730740866365F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(324, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -27.934681028684146F, 9.454967379570482F, 1.4585943510926436F, -0.006302876367879478F, 0.0007101730740867122F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(378, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -27.917991958637423F, 9.603086972984118F, 1.4585943510926438F, -0.00630287636787944F, 0.0007101730740866365F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(432, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -25.955923328619917F, 8.699471317640675F, 1.2341908429783297F, -0.005986819952558298F, 0.002094905466493948F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(486, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -25.906692978139375F, 8.840163576146994F, 1.23419084297833F, -0.005986819952558298F, 0.0020949054664937965F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(540, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -25.857462627658833F, 8.980855834653312F, 1.2341908429783295F, -0.005986819952558336F, 0.0020949054664940233F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(594, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -25.808232277178295F, 9.121548093159632F, 1.2341908429783293F, -0.005986819952558298F, 0.0020949054664938724F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(648, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -24.096430203722452F, 7.803986624842958F, 1.0097885769263615F, -0.005370557201465989F, 0.003374583597602179F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(702, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -24.01712718814923F, 7.930196651120742F, 1.0097885769263613F, -0.005370557201466008F, 0.0033745835976021037F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(756, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -23.937824172576004F, 8.056406677398527F, 1.0097885769263617F, -0.005370557201465989F, 0.0033745835976022546F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(810, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -23.858521157002784F, 8.182616703676311F, 1.0097885769263615F, -0.005370557201465989F, 0.003374583597602179F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(864, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -22.48282254393464F, 6.517177456065367F, 0.7853881056826046F, -0.004484992746583871F, 0.004485037855437552F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(918, 262).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -22.377423447610134F, 6.622576552389874F, 0.7853881056826048F, -0.00448499274658389F, 0.004485037855437628F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(0, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -22.272024351285623F, 6.727975648714382F, 0.7853881056826044F, -0.00448499274658389F, 0.004485037855437628F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(54, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -22.16662525496112F, 6.833374745038889F, 0.7853881056826043F, -0.004484992746583871F, 0.004485037855437628F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(108, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -21.196013375157044F, 4.903569796277553F, 0.5609896264926215F, -0.0033745349311716717F, 0.005370587780477553F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(162, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -21.06980334887926F, 4.982872811850775F, 0.5609896264926216F, -0.0033745349311716907F, 0.005370587780477553F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(216, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -20.943593322601476F, 5.062175827423997F, 0.5609896264926217F, -0.0033745349311716907F, 0.005370587780477553F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(270, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -20.81738329632369F, 5.141478842997219F, 0.5609896264926223F, -0.0033745349311716907F, 0.005370587780477628F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(324, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -20.300528682359328F, 3.044076671380086F, 0.33659294205129575F, -0.0020948679237364634F, 0.005986833089233989F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(378, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -20.159836423853008F, 3.0933070218606273F, 0.33659294205129625F, -0.0020948679237364825F, 0.005986833089234065F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(432, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -20.019144165346688F, 3.1425373723411676F, 0.33659294205129686F, -0.0020948679237364634F, 0.005986833089233989F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(486, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -19.87845190684037F, 3.1917677228217087F, 0.3365929420512958F, -0.0020948679237364825F, 0.005986833089234065F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(540, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -19.841271807256796F, 1.031940831222411F, 0.11219749959805311F, -0.0007101589678742511F, 0.006302877957252315F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(594, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -19.693152213843156F, 1.0486299012691347F, 0.11219749959805253F, -0.0007101589678742511F, 0.006302877957252315F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(648, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -19.545032620429517F, 1.0653189713158584F, 0.1121974995980512F, -0.0007101589678742512F, 0.006302877957252239F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(702, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -19.396913027015884F, 1.082008041362582F, 0.11219749959805148F, -0.0007101589678742511F, 0.006302877957252315F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(756, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -19.841271807256792F, -1.0319408312224068F, -0.11219749959805159F, 0.0007101589678742407F, 0.006302877957252315F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(810, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -19.693152213843156F, -1.0486299012691305F, -0.1121974995980519F, 0.0007101589678742503F, 0.006302877957252239F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(864, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -19.545032620429517F, -1.065318971315854F, -0.11219749959805057F, 0.0007101589678742407F, 0.006302877957252315F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(918, 266).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -19.39691302701588F, -1.0820080413625774F, -0.11219749959805007F, 0.0007101589678742502F, 0.006302877957252315F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(0, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -20.30052868235932F, -3.0440766713800826F, -0.3365929420512959F, 0.0020948679237364634F, 0.005986833089233913F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(54, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -20.159836423853008F, -3.093307021860623F, -0.33659294205129564F, 0.0020948679237364634F, 0.005986833089234065F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(108, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -20.019144165346688F, -3.1425373723411636F, -0.33659294205129614F, 0.002094867923736473F, 0.005986833089233989F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(162, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -19.87845190684037F, -3.1917677228217043F, -0.33659294205129664F, 0.0020948679237364634F, 0.005986833089234065F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(216, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -21.19601337515704F, -4.90356979627755F, -0.5609896264926217F, 0.003374534931171681F, 0.005370587780477477F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(270, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -21.069803348879258F, -4.982872811850771F, -0.5609896264926216F, 0.0033745349311716717F, 0.005370587780477628F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(324, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -20.943593322601476F, -5.062175827423993F, -0.5609896264926217F, 0.00337453493117171F, 0.005370587780477477F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(378, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -20.81738329632369F, -5.141478842997215F, -0.5609896264926217F, 0.0033745349311716717F, 0.005370587780477628F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(432, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -22.48282254393463F, -6.517177456065362F, -0.7853881056826033F, 0.004484992746583871F, 0.004485037855437628F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(486, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -22.377423447610123F, -6.622576552389869F, -0.7853881056826031F, 0.004484992746583871F, 0.004485037855437628F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(540, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -22.272024351285616F, -6.727975648714377F, -0.7853881056826036F, 0.00448499274658389F, 0.004485037855437552F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(594, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -22.16662525496111F, -6.833374745038885F, -0.7853881056826041F, 0.004484992746583871F, 0.004485037855437628F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(648, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -24.09643020372244F, -7.803986624842954F, -1.0097885769263606F, 0.005370557201465989F, 0.003374583597602179F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(702, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -24.01712718814922F, -7.930196651120738F, -1.0097885769263608F, 0.005370557201465989F, 0.003374583597602179F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(756, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -23.937824172576F, -8.056406677398522F, -1.0097885769263606F, 0.005370557201465989F, 0.0033745835976021037F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(810, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -23.858521157002777F, -8.182616703676306F, -1.00978857692636F, 0.005370557201465989F, 0.0033745835976022546F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(864, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -25.955923328619907F, -8.699471317640672F, -1.234190842978329F, 0.005986819952558336F, 0.0020949054664938724F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(918, 270).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -25.906692978139368F, -8.84016357614699F, -1.2341908429783286F, 0.005986819952558298F, 0.002094905466493948F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(0, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -25.857462627658826F, -8.980855834653308F, -1.2341908429783282F, 0.005986819952558336F, 0.0020949054664938724F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(54, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -25.808232277178284F, -9.121548093159628F, -1.2341908429783284F, 0.005986819952558298F, 0.002094905466493948F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(108, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -27.968059168777586F, -9.158728192743206F, -1.458594351092643F, 0.006302876367879478F, 0.0007101730740866365F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(162, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -27.951370098730862F, -9.306847786156842F, -1.4585943510926431F, 0.00630287636787944F, 0.0007101730740867122F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(216, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -27.93468102868414F, -9.45496737957048F, -1.4585943510926433F, 0.006302876367879478F, 0.0007101730740866365F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(270, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -27.917991958637415F, -9.603086972984118F, -1.4585943510926433F, 0.00630287636787944F, 0.0007101730740867122F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(324, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -30.031940831222407F, -9.158728192743208F, -1.6829983024971495F, 0.00630287636787944F, -0.0007101730740866365F));
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(378, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -30.04862990126913F, -9.306847786156844F, -1.6829983024971498F, 0.00630287636787944F, -0.0007101730740866365F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(432, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -30.065318971315854F, -9.454967379570482F, -1.6829983024971498F, 0.006302876367879478F, -0.0007101730740866365F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(486, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -30.082008041362577F, -9.603086972984118F, -1.6829983024971495F, 0.00630287636787944F, -0.0007101730740865608F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(540, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -32.04407667138008F, -8.699471317640675F, -1.9074018106114627F, 0.005986819952558298F, -0.002094905466493948F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(594, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -32.093307021860625F, -8.840163576146995F, -1.9074018106114625F, 0.005986819952558298F, -0.0020949054664937965F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(648, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -32.14253737234117F, -8.980855834653312F, -1.9074018106114627F, 0.005986819952558336F, -0.002094905466493948F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(702, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -32.19176772282171F, -9.121548093159632F, -1.9074018106114627F, 0.005986819952558298F, -0.0020949054664937965F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(756, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -33.90356979627755F, -7.803986624842958F, -2.1318040766634327F, 0.005370557201465989F, -0.0033745835976022546F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(810, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -33.982872811850775F, -7.930196651120742F, -2.1318040766634327F, 0.005370557201465989F, -0.0033745835976021037F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(864, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -34.062175827424F, -8.056406677398526F, -2.1318040766634323F, 0.005370557201465989F, -0.0033745835976022546F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(918, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -34.141478842997216F, -8.18261670367631F, -2.131804076663432F, 0.005370557201466008F, -0.0033745835976021037F));
        g.addOrReplaceChild("caldera_96", CubeListBuilder.create().texOffs(0, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -35.51717745606536F, -6.517177456065366F, -2.3562045479071885F, 0.004484992746583871F, -0.004485037855437628F));
        g.addOrReplaceChild("caldera_97", CubeListBuilder.create().texOffs(54, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -35.62257655238987F, -6.622576552389874F, -2.3562045479071885F, 0.00448499274658389F, -0.004485037855437628F));
        g.addOrReplaceChild("caldera_98", CubeListBuilder.create().texOffs(108, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -35.72797564871438F, -6.727975648714381F, -2.3562045479071885F, 0.004484992746583871F, -0.004485037855437628F));
        g.addOrReplaceChild("caldera_99", CubeListBuilder.create().texOffs(162, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -35.83337474503888F, -6.833374745038888F, -2.356204547907189F, 0.00448499274658389F, -0.004485037855437628F));
        g.addOrReplaceChild("caldera_100", CubeListBuilder.create().texOffs(216, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -36.80398662484295F, -4.903569796277558F, -2.580603027097172F, 0.0033745349311716907F, -0.005370587780477477F));
        g.addOrReplaceChild("caldera_101", CubeListBuilder.create().texOffs(270, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -36.93019665112074F, -4.98287281185078F, -2.580603027097172F, 0.0033745349311716907F, -0.005370587780477628F));
        g.addOrReplaceChild("caldera_102", CubeListBuilder.create().texOffs(324, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -37.05640667739853F, -5.062175827424001F, -2.5806030270971707F, 0.0033745349311716907F, -0.005370587780477628F));
        g.addOrReplaceChild("caldera_103", CubeListBuilder.create().texOffs(378, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -37.18261670367631F, -5.141478842997223F, -2.5806030270971703F, 0.0033745349311716717F, -0.005370587780477477F));
        g.addOrReplaceChild("caldera_104", CubeListBuilder.create().texOffs(432, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -37.69947131764067F, -3.0440766713800937F, -2.8049997115384957F, 0.0020948679237364825F, -0.005986833089233913F));
        g.addOrReplaceChild("caldera_105", CubeListBuilder.create().texOffs(486, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -37.840163576146985F, -3.093307021860634F, -2.8049997115384957F, 0.0020948679237364634F, -0.005986833089234065F));
        g.addOrReplaceChild("caldera_106", CubeListBuilder.create().texOffs(540, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -37.98085583465331F, -3.1425373723411747F, -2.804999711538496F, 0.0020948679237364825F, -0.005986833089234216F));
        g.addOrReplaceChild("caldera_107", CubeListBuilder.create().texOffs(594, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -38.12154809315963F, -3.191767722821716F, -2.804999711538495F, 0.0020948679237364634F, -0.005986833089233913F));
        g.addOrReplaceChild("caldera_108", CubeListBuilder.create().texOffs(648, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-36.25F, -38.158728192743204F, -1.0319408312224143F, -3.0293951539917394F, 0.0007101589678742515F, -0.006302877957252239F));
        g.addOrReplaceChild("caldera_109", CubeListBuilder.create().texOffs(702, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-12.75F, -38.306847786156844F, -1.048629901269138F, -3.0293951539917403F, 0.0007101589678742515F, -0.006302877957252239F));
        g.addOrReplaceChild("caldera_110", CubeListBuilder.create().texOffs(756, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.75F, -38.454967379570476F, -1.0653189713158617F, -3.029395153991742F, 0.0007101589678742514F, -0.00630287795725239F));
        g.addOrReplaceChild("caldera_111", CubeListBuilder.create().texOffs(810, 278).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.25F, -38.603086972984116F, -1.0820080413625854F, -3.0293951539917443F, 0.0007101589678742515F, -0.006302877957252239F));
        g.addOrReplaceChild("skyline", CubeListBuilder.create().texOffs(466, 191).addBox(-60.0F, -39.0F, -5.0F, 106.0F, 3.0F, 10.0F).texOffs(530, 218).addBox(-60.0F, -42.0F, -2.0F, 106.0F, 3.0F, 4.0F).texOffs(710, 236).addBox(-88.0F, -9.0F, -1.5F, 8.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("skyline_cantoi_0", CubeListBuilder.create().texOffs(594, 296).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.0F, -39.46352549156242F, -4.9265847744427305F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantoi_1", CubeListBuilder.create().texOffs(808, 296).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.0F, -40.34520337000113F, -4.640110266005152F, -2.0420352248333677F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantoi_2", CubeListBuilder.create().texOffs(0, 299).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.0F, -41.09520337000113F, -4.095203370001131F, -2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantoi_3", CubeListBuilder.create().texOffs(214, 299).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.0F, -41.64011026600515F, -3.3452033700011308F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantoi_4", CubeListBuilder.create().texOffs(428, 299).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.0F, -41.92658477444273F, -2.463525491562421F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantod_0", CubeListBuilder.create().texOffs(642, 299).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.0F, -39.46352549156242F, 4.9265847744427305F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantod_1", CubeListBuilder.create().texOffs(0, 301).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.0F, -40.34520337000113F, 4.640110266005152F, 2.0420352248333677F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantod_2", CubeListBuilder.create().texOffs(214, 301).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.0F, -41.09520337000113F, 4.095203370001131F, 2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantod_3", CubeListBuilder.create().texOffs(428, 301).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.0F, -41.64011026600515F, 3.3452033700011308F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_cantod_4", CubeListBuilder.create().texOffs(642, 301).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.0F, -41.92658477444273F, 2.463525491562421F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("skyline_tapaa", CubeListBuilder.create().texOffs(658, 138).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 20.0F), PartPose.offset(-60.0F, -39.0F, -5.0F));
        g.addOrReplaceChild("skyline_tapab", CubeListBuilder.create().texOffs(700, 138).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 20.0F), PartPose.offset(45.0F, -39.0F, -5.0F));
        g.addOrReplaceChild("cono_0", CubeListBuilder.create().texOffs(732, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -38.36601346058839F, 1.0552962717485064F, 0.11143529511475209F, 0.013102186907615039F, 3.025037148454245F));
        g.addOrReplaceChild("cono_1", CubeListBuilder.create().texOffs(750, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -37.912006516577364F, 1.0041419746317188F, 0.10498234052994443F, 0.03966451807608929F, 2.7816537365554765F));
        g.addOrReplaceChild("cono_2", CubeListBuilder.create().texOffs(962, 248).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -37.00461292776205F, 0.9019032713333848F, 0.09055193734208812F, 0.06634129349327818F, 2.51095412836708F));
        g.addOrReplaceChild("cono_3", CubeListBuilder.create().texOffs(458, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -35.63649864154661F, 0.7477538125861491F, 0.06687846674356294F, 0.0901564217047418F, 2.2103949478952343F));
        g.addOrReplaceChild("cono_4", CubeListBuilder.create().texOffs(792, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -33.75788382984147F, 0.536084758811438F, 0.03677642511776892F, 0.10602522309499181F, 1.9053960135042889F));
        g.addOrReplaceChild("cono_5", CubeListBuilder.create().texOffs(474, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -30.840178070852776F, 0.2073382731826969F, 0.007755983378748903F, 0.11193246750962928F, 1.6401229747849346F));
        g.addOrReplaceChild("cono_6", CubeListBuilder.create().texOffs(768, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -37.8963624366082F, 3.112971853646574F, 0.3344558736197399F, 0.038658084586685515F, 3.030832804086511F));
        g.addOrReplaceChild("cono_7", CubeListBuilder.create().texOffs(786, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -37.46512129653779F, 2.96207405235539F, 0.316251515205497F, 0.11724234515495575F, 2.7982855217458664F));
        g.addOrReplaceChild("cono_8", CubeListBuilder.create().texOffs(978, 248).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -36.603228211211324F, 2.660484617955412F, 0.2748509311594899F, 0.19682205302321829F, 2.5352537595681435F));
        g.addOrReplaceChild("cono_9", CubeListBuilder.create().texOffs(476, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -35.303716888054474F, 2.2057659392473754F, 0.20508243932307357F, 0.26881409904766423F, 2.2352045520772097F));
        g.addOrReplaceChild("cono_10", CubeListBuilder.create().texOffs(808, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -33.51930366742054F, 1.5813727481325015F, 0.11377032471363564F, 0.3174799870630683F, 1.921676655994633F));
        g.addOrReplaceChild("cono_11", CubeListBuilder.create().texOffs(492, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -30.74790385846577F, 0.6116180127614795F, 0.02408267400427608F, 0.3357692913479697F, 1.6437701670294653F));
        g.addOrReplaceChild("cono_12", CubeListBuilder.create().texOffs(804, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -36.98061065208208F, 5.014550028164365F, 0.5578977692667624F, 0.062297393936502216F, 3.042154667938987F));
        g.addOrReplaceChild("cono_13", CubeListBuilder.create().texOffs(822, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -36.593759547421584F, 4.7714753685498685F, 0.5312623096725474F, 0.18956141479476918F, 2.8312851083152752F));
        g.addOrReplaceChild("cono_14", CubeListBuilder.create().texOffs(994, 248).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -35.820585883834354F, 4.285658156616868F, 0.46872624729015877F, 0.3204660784994865F, 2.5850820474635676F));
        g.addOrReplaceChild("cono_15", CubeListBuilder.create().texOffs(494, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -34.6548404477659F, 3.5531717512382963F, 0.35747011718259625F, 0.4420845976600599F, 2.288527503031142F));
        g.addOrReplaceChild("cono_16", CubeListBuilder.create().texOffs(824, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -33.05410674814645F, 2.547364104624667F, 0.20237430597044084F, 0.5269119984193069F, 1.958203245476392F));
        g.addOrReplaceChild("cono_17", CubeListBuilder.create().texOffs(510, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -30.567982448004393F, 0.9852286712859932F, 0.043226610225965266F, 0.5595088808548668F, 1.6521087272183872F));
        g.addOrReplaceChild("cono_18", CubeListBuilder.create().texOffs(840, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -35.66467772533261F, 6.664677725332604F, 0.7819512583421305F, 0.08283863493614745F, 3.058468317217216F));
        g.addOrReplaceChild("cono_19", CubeListBuilder.create().texOffs(858, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -35.34161498581925F, 6.341614985819252F, 0.7519162677703787F, 0.2531283703789995F, 2.8799403864305426F));
        g.addOrReplaceChild("cono_20", CubeListBuilder.create().texOffs(0, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -34.69593089995556F, 5.69593089995556F, 0.6783127085654724F, 0.4319784098966062F, 2.6624509099649556F));
        g.addOrReplaceChild("cono_21", CubeListBuilder.create().texOffs(512, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -33.722406694868994F, 4.722406694868997F, 0.5363281393779871F, 0.6048126121027005F, 2.378409349288029F));
        g.addOrReplaceChild("cono_22", CubeListBuilder.create().texOffs(840, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -32.385619988044795F, 3.385619988044793F, 0.31563050038457297F, 0.7319801205993047F, 2.025275435099926F));
        g.addOrReplaceChild("cono_23", CubeListBuilder.create().texOffs(528, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -30.309435850275573F, 1.3094358502755719F, 0.06872921300226094F, 0.783028844416671F, 1.6680709429484084F));
        g.addOrReplaceChild("cono_24", CubeListBuilder.create().texOffs(876, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -34.01455002816437F, 7.980610652082078F, 1.0066874307142182F, 0.09924445392760543F, 3.0789867954950276F));
        g.addOrReplaceChild("cono_25", CubeListBuilder.create().texOffs(894, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -33.77147536854987F, 7.5937595474215875F, 0.9791847557765825F, 0.30456868354745703F, 2.942766538015579F));
        g.addOrReplaceChild("cono_26", CubeListBuilder.create().texOffs(16, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -33.28565815661687F, 6.820585883834351F, 0.9085555839998263F, 0.5251396744997089F, 2.768963601518473F));
        g.addOrReplaceChild("cono_27", CubeListBuilder.create().texOffs(530, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -32.553171751238295F, 5.654840447765898F, 0.7576880915645975F, 0.7489620286212278F, 2.5177678827742573F));
        g.addOrReplaceChild("cono_28", CubeListBuilder.create().texOffs(856, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -31.54736410462467F, 4.054106748146454F, 0.47928046000581165F, 0.9278080370398019F, 2.1467293183231257F));
        g.addOrReplaceChild("cono_29", CubeListBuilder.create().texOffs(546, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -29.985228671285995F, 1.5679824480043951F, 0.10911930315985453F, 1.0060336902425466F, 1.6997703088335272F));
        g.addOrReplaceChild("cono_30", CubeListBuilder.create().texOffs(912, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -32.11297185364658F, 8.896362436608198F, 1.2320421912539097F, 0.11067675774067427F, 3.102696466691936F));
        g.addOrReplaceChild("cono_31", CubeListBuilder.create().texOffs(930, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -31.962074052355394F, 8.465121296537784F, 1.2127553956371857F, 0.34085422153016365F, 3.0171574783097173F));
        g.addOrReplaceChild("cono_32", CubeListBuilder.create().texOffs(32, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -31.660484617955415F, 7.6032282112113245F, 1.161154457184397F, 0.5930110022788123F, 2.9035338029876643F));
        g.addOrReplaceChild("cono_33", CubeListBuilder.create().texOffs(548, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -31.205765939247378F, 6.303716888054476F, 1.038773553245619F, 0.8617878174070345F, 2.7214193772397035F));
        g.addOrReplaceChild("cono_34", CubeListBuilder.create().texOffs(872, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -30.5813727481325F, 4.519303667420536F, 0.750867314950281F, 1.1020614829851352F, 2.3786943600479384F));
        g.addOrReplaceChild("cono_35", CubeListBuilder.create().texOffs(564, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -29.61161801276148F, 1.7479038584657676F, 0.1942461485171452F, 1.2274823505614496F, 1.77675221504269F));
        g.addOrReplaceChild("cono_36", CubeListBuilder.create().texOffs(948, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -30.055296271748507F, 9.366013460588388F, 1.4578269915174975F, 0.11654545534934085F, 3.128400972638498F));
        g.addOrReplaceChild("cono_37", CubeListBuilder.create().texOffs(966, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -30.004141974631718F, 8.91200651657736F, 1.4508919359841412F, 0.35964293477237375F, 3.099215480578423F));
        g.addOrReplaceChild("cono_38", CubeListBuilder.create().texOffs(48, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -29.901903271333385F, 8.004612927762045F, 1.4318823258058115F, 0.6290334231574534F, 3.059515716513441F));
        g.addOrReplaceChild("cono_39", CubeListBuilder.create().texOffs(566, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -29.74775381258615F, 6.636498641546606F, 1.3834767481739576F, 0.925758191671395F, 2.9912767200985124F));
        g.addOrReplaceChild("cono_40", CubeListBuilder.create().texOffs(888, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -29.53608475881144F, 4.757883829841469F, 1.2385438793639492F, 1.2204032477335136F, 2.82819495042983F));
        g.addOrReplaceChild("cono_41", CubeListBuilder.create().texOffs(582, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -29.207338273182696F, 1.840178070852774F, 0.5484327633001619F, 1.4392099818735413F, 2.123099514588194F));
        g.addOrReplaceChild("cono_42", CubeListBuilder.create().texOffs(984, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -27.944703728251493F, 9.366013460588388F, 1.6837656620722958F, 0.11654545534934088F, -3.128400972638498F));
        g.addOrReplaceChild("cono_43", CubeListBuilder.create().texOffs(1002, 236).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -27.995858025368282F, 8.91200651657736F, 1.690700717605652F, 0.35964293477237375F, -3.099215480578423F));
        g.addOrReplaceChild("cono_44", CubeListBuilder.create().texOffs(64, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -28.098096728666615F, 8.004612927762045F, 1.7097103277839816F, 0.6290334231574534F, -3.0595157165134417F));
        g.addOrReplaceChild("cono_45", CubeListBuilder.create().texOffs(584, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -28.25224618741385F, 6.636498641546606F, 1.7581159054158357F, 0.925758191671395F, -2.9912767200985124F));
        g.addOrReplaceChild("cono_46", CubeListBuilder.create().texOffs(904, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -28.46391524118856F, 4.757883829841469F, 1.903048774225844F, 1.2204032477335136F, -2.82819495042983F));
        g.addOrReplaceChild("cono_47", CubeListBuilder.create().texOffs(600, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -28.792661726817304F, 1.840178070852774F, 2.5931598902896313F, 1.4392099818735413F, -2.123099514588194F));
        g.addOrReplaceChild("cono_48", CubeListBuilder.create().texOffs(0, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -25.887028146353426F, 8.8963624366082F, 1.9095504623358832F, 0.1106767577406747F, -3.102696466691936F));
        g.addOrReplaceChild("cono_49", CubeListBuilder.create().texOffs(18, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -26.037925947644613F, 8.465121296537784F, 1.9288372579526072F, 0.3408542215301635F, -3.0171574783097173F));
        g.addOrReplaceChild("cono_50", CubeListBuilder.create().texOffs(80, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -26.33951538204459F, 7.6032282112113245F, 1.9804381964053959F, 0.5930110022788123F, -2.9035338029876647F));
        g.addOrReplaceChild("cono_51", CubeListBuilder.create().texOffs(602, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -26.794234060752625F, 6.303716888054476F, 2.1028191003441745F, 0.8617878174070348F, -2.721419377239703F));
        g.addOrReplaceChild("cono_52", CubeListBuilder.create().texOffs(920, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -27.4186272518675F, 4.519303667420536F, 2.3907253386395113F, 1.1020614829851358F, -2.3786943600479393F));
        g.addOrReplaceChild("cono_53", CubeListBuilder.create().texOffs(618, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -28.38838198723852F, 1.7479038584657678F, 2.947346505072648F, 1.2274823505614496F, -1.7767522150426902F));
        g.addOrReplaceChild("cono_54", CubeListBuilder.create().texOffs(36, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -23.98544997183564F, 7.980610652082078F, 2.1349052228755743F, 0.0992444539276061F, -3.0789867954950276F));
        g.addOrReplaceChild("cono_55", CubeListBuilder.create().texOffs(54, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -24.22852463145013F, 7.593759547421589F, 2.162407897813209F, 0.3045686835474568F, -2.9427665380155803F));
        g.addOrReplaceChild("cono_56", CubeListBuilder.create().texOffs(96, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -24.71434184338313F, 6.820585883834353F, 2.2330370695899653F, 0.5251396744997093F, -2.768963601518474F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("cono_57", CubeListBuilder.create().texOffs(620, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -25.446828248761705F, 5.6548404477659F, 2.3839045620251937F, 0.748962028621229F, -2.5177678827742582F));
        g.addOrReplaceChild("cono_58", CubeListBuilder.create().texOffs(936, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -26.452635895375334F, 4.054106748146454F, 2.6623121935839813F, 0.9278080370398019F, -2.1467293183231257F));
        g.addOrReplaceChild("cono_59", CubeListBuilder.create().texOffs(636, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -28.01477132871401F, 1.5679824480043956F, 3.032473350429939F, 1.0060336902425473F, -1.6997703088335272F));
        g.addOrReplaceChild("cono_60", CubeListBuilder.create().texOffs(72, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -22.335322274667398F, 6.664677725332606F, 2.3596413952476616F, 0.082838634936148F, -3.058468317217215F));
        g.addOrReplaceChild("cono_61", CubeListBuilder.create().texOffs(90, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -22.658385014180748F, 6.341614985819254F, 2.3896763858194143F, 0.2531283703789995F, -2.879940386430543F));
        g.addOrReplaceChild("cono_62", CubeListBuilder.create().texOffs(112, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -23.30406910004444F, 5.695930899955561F, 2.4632799450243223F, 0.43197840989660585F, -2.6624509099649543F));
        g.addOrReplaceChild("cono_63", CubeListBuilder.create().texOffs(638, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -24.277593305131003F, 4.722406694868998F, 2.605264514211807F, 0.6048126121027003F, -2.378409349288029F));
        g.addOrReplaceChild("cono_64", CubeListBuilder.create().texOffs(952, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -25.61438001195521F, 3.3856199880447932F, 2.82596215320522F, 0.7319801205993044F, -2.0252754350999256F));
        g.addOrReplaceChild("cono_65", CubeListBuilder.create().texOffs(654, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -27.69056414972443F, 1.3094358502755723F, 3.072863440587532F, 0.7830288444166714F, -1.6680709429484084F));
        g.addOrReplaceChild("cono_66", CubeListBuilder.create().texOffs(108, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -21.019389347917922F, 5.014550028164366F, 2.5836948843230325F, 0.06229739393650213F, -3.042154667938987F));
        g.addOrReplaceChild("cono_67", CubeListBuilder.create().texOffs(126, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -21.406240452578412F, 4.771475368549869F, 2.610330343917246F, 0.18956141479476926F, -2.8312851083152752F));
        g.addOrReplaceChild("cono_68", CubeListBuilder.create().texOffs(128, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -22.179414116165653F, 4.2856581566168686F, 2.672866406299634F, 0.3204660784994868F, -2.585082047463567F));
        g.addOrReplaceChild("cono_69", CubeListBuilder.create().texOffs(656, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -23.3451595522341F, 3.553171751238297F, 2.7841225364071964F, 0.4420845976600605F, -2.2885275030311427F));
        g.addOrReplaceChild("cono_70", CubeListBuilder.create().texOffs(968, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -24.945893251853548F, 2.5473641046246676F, 2.939218347619353F, 0.5269119984193066F, -1.9582032454763918F));
        g.addOrReplaceChild("cono_71", CubeListBuilder.create().texOffs(672, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -27.432017551995607F, 0.9852286712859935F, 3.098366043363828F, 0.5595088808548672F, -1.6521087272183872F));
        g.addOrReplaceChild("cono_72", CubeListBuilder.create().texOffs(144, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -20.1036375633918F, 3.1129718536465774F, 2.807136779970052F, 0.03865808458668544F, -3.030832804086512F));
        g.addOrReplaceChild("cono_73", CubeListBuilder.create().texOffs(162, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -20.534878703462216F, 2.9620740523553923F, 2.8253411383842955F, 0.11724234515495599F, -2.7982855217458664F));
        g.addOrReplaceChild("cono_74", CubeListBuilder.create().texOffs(144, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -21.396771788788676F, 2.6604846179554147F, 2.866741722430303F, 0.19682205302321862F, -2.5352537595681435F));
        g.addOrReplaceChild("cono_75", CubeListBuilder.create().texOffs(674, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -22.696283111945526F, 2.2057659392473776F, 2.936510214266719F, 0.2688140990476648F, -2.2352045520772097F));
        g.addOrReplaceChild("cono_76", CubeListBuilder.create().texOffs(984, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -24.480696332579466F, 1.5813727481325033F, 3.0278223288761574F, 0.3174799870630682F, -1.9216766559946326F));
        g.addOrReplaceChild("cono_77", CubeListBuilder.create().texOffs(690, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -27.25209614153423F, 0.6116180127614801F, 3.1175099795855172F, 0.3357692913479702F, -1.6437701670294653F));
        g.addOrReplaceChild("cono_78", CubeListBuilder.create().texOffs(180, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -19.633986539411612F, 1.0552962717485095F, 3.030157358475041F, 0.013102186907615039F, -3.025037148454245F));
        g.addOrReplaceChild("cono_79", CubeListBuilder.create().texOffs(198, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -20.08799348342264F, 1.004141974631722F, 3.036610313059849F, 0.03966451807608937F, -2.781653736555477F));
        g.addOrReplaceChild("cono_80", CubeListBuilder.create().texOffs(160, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -20.995387072237953F, 0.9019032713333874F, 3.051040716247705F, 0.06634129349327826F, -2.51095412836708F));
        g.addOrReplaceChild("cono_81", CubeListBuilder.create().texOffs(692, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -22.36350135845339F, 0.7477538125861516F, 3.07471418684623F, 0.09015642170474186F, -2.210394947895234F));
        g.addOrReplaceChild("cono_82", CubeListBuilder.create().texOffs(1000, 282).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -24.242116170158532F, 0.5360847588114396F, 3.104816228472024F, 0.10602522309499207F, -1.9053960135042887F));
        g.addOrReplaceChild("cono_83", CubeListBuilder.create().texOffs(708, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -27.159821929147224F, 0.2073382731826975F, 3.133836670211044F, 0.11193246750962967F, -1.6401229747849346F));
        g.addOrReplaceChild("cono_84", CubeListBuilder.create().texOffs(216, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -19.633986539411612F, -1.0552962717485053F, -3.030157358475041F, -0.013102186907615039F, -3.025037148454245F));
        g.addOrReplaceChild("cono_85", CubeListBuilder.create().texOffs(234, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -20.08799348342264F, -1.0041419746317177F, -3.0366103130598487F, -0.03966451807608929F, -2.7816537365554765F));
        g.addOrReplaceChild("cono_86", CubeListBuilder.create().texOffs(176, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -20.995387072237953F, -0.9019032713333838F, -3.051040716247705F, -0.06634129349327818F, -2.51095412836708F));
        g.addOrReplaceChild("cono_87", CubeListBuilder.create().texOffs(710, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -22.363501358453394F, -0.7477538125861485F, -3.07471418684623F, -0.09015642170474171F, -2.2103949478952343F));
        g.addOrReplaceChild("cono_88", CubeListBuilder.create().texOffs(0, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -24.242116170158532F, -0.5360847588114375F, -3.104816228472024F, -0.10602522309499161F, -1.9053960135042887F));
        g.addOrReplaceChild("cono_89", CubeListBuilder.create().texOffs(726, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -27.159821929147224F, -0.20733827318269668F, -3.133836670211044F, -0.11193246750962924F, -1.6401229747849346F));
        g.addOrReplaceChild("cono_90", CubeListBuilder.create().texOffs(252, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -20.1036375633918F, -3.112971853646573F, -2.8071367799700537F, -0.03865808458668544F, -3.030832804086511F));
        g.addOrReplaceChild("cono_91", CubeListBuilder.create().texOffs(270, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -20.534878703462216F, -2.962074052355389F, -2.825341138384297F, -0.11724234515495552F, -2.7982855217458673F));
        g.addOrReplaceChild("cono_92", CubeListBuilder.create().texOffs(192, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -21.396771788788676F, -2.6604846179554107F, -2.8667417224303042F, -0.19682205302321806F, -2.5352537595681426F));
        g.addOrReplaceChild("cono_93", CubeListBuilder.create().texOffs(728, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -22.696283111945526F, -2.2057659392473745F, -2.9365102142667197F, -0.26881409904766423F, -2.2352045520772097F));
        g.addOrReplaceChild("cono_94", CubeListBuilder.create().texOffs(16, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -24.480696332579466F, -1.581372748132501F, -3.027822328876158F, -0.31747998706306774F, -1.9216766559946326F));
        g.addOrReplaceChild("cono_95", CubeListBuilder.create().texOffs(744, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -27.25209614153423F, -0.6116180127614793F, -3.1175099795855172F, -0.3357692913479698F, -1.6437701670294653F));
        g.addOrReplaceChild("cono_96", CubeListBuilder.create().texOffs(288, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -21.019389347917922F, -5.014550028164363F, -2.5836948843230316F, -0.062297393936502604F, -3.0421546679389855F));
        g.addOrReplaceChild("cono_97", CubeListBuilder.create().texOffs(306, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -21.406240452578412F, -4.771475368549866F, -2.6103303439172447F, -0.18956141479476918F, -2.831285108315277F));
        g.addOrReplaceChild("cono_98", CubeListBuilder.create().texOffs(208, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -22.179414116165646F, -4.285658156616865F, -2.6728664062996343F, -0.3204660784994865F, -2.5850820474635667F));
        g.addOrReplaceChild("cono_99", CubeListBuilder.create().texOffs(746, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -23.3451595522341F, -3.5531717512382945F, -2.7841225364071973F, -0.4420845976600599F, -2.2885275030311427F));
        g.addOrReplaceChild("cono_100", CubeListBuilder.create().texOffs(32, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -24.945893251853548F, -2.5473641046246653F, -2.9392183476193536F, -0.5269119984193058F, -1.9582032454763914F));
        g.addOrReplaceChild("cono_101", CubeListBuilder.create().texOffs(762, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -27.432017551995607F, -0.9852286712859928F, -3.098366043363828F, -0.5595088808548668F, -1.6521087272183872F));
        g.addOrReplaceChild("cono_102", CubeListBuilder.create().texOffs(324, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -22.33532227466739F, -6.664677725332602F, -2.359641395247663F, -0.08283863493614796F, -3.0584683172172147F));
        g.addOrReplaceChild("cono_103", CubeListBuilder.create().texOffs(342, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -22.658385014180748F, -6.341614985819249F, -2.389676385819415F, -0.25312837037899916F, -2.8799403864305435F));
        g.addOrReplaceChild("cono_104", CubeListBuilder.create().texOffs(224, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -23.304069100044437F, -5.695930899955557F, -2.463279945024323F, -0.4319784098966056F, -2.6624509099649543F));
        g.addOrReplaceChild("cono_105", CubeListBuilder.create().texOffs(764, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -24.277593305131003F, -4.722406694868996F, -2.605264514211807F, -0.6048126121027003F, -2.3784093492880287F));
        g.addOrReplaceChild("cono_106", CubeListBuilder.create().texOffs(48, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -25.614380011955205F, -3.385619988044791F, -2.8259621532052206F, -0.7319801205993042F, -2.0252754350999256F));
        g.addOrReplaceChild("cono_107", CubeListBuilder.create().texOffs(780, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -27.690564149724427F, -1.3094358502755712F, -3.0728634405875326F, -0.7830288444166706F, -1.6680709429484084F));
        g.addOrReplaceChild("cono_108", CubeListBuilder.create().texOffs(360, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -23.985449971835628F, -7.980610652082074F, -2.1349052228755756F, -0.09924445392760543F, -3.078986795495028F));
        g.addOrReplaceChild("cono_109", CubeListBuilder.create().texOffs(378, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -24.228524631450124F, -7.593759547421586F, -2.162407897813211F, -0.304568683547457F, -2.94276653801558F));
        g.addOrReplaceChild("cono_110", CubeListBuilder.create().texOffs(240, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -24.714341843383128F, -6.820585883834349F, -2.2330370695899666F, -0.525139674499709F, -2.7689636015184727F));
        g.addOrReplaceChild("cono_111", CubeListBuilder.create().texOffs(782, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -25.4468282487617F, -5.654840447765897F, -2.383904562025196F, -0.7489620286212282F, -2.517767882774257F));
        g.addOrReplaceChild("cono_112", CubeListBuilder.create().texOffs(64, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -26.45263589537533F, -4.054106748146452F, -2.6623121935839817F, -0.9278080370398017F, -2.1467293183231257F));
        g.addOrReplaceChild("cono_113", CubeListBuilder.create().texOffs(798, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -28.014771328714005F, -1.5679824480043947F, -3.032473350429939F, -1.0060336902425462F, -1.699770308833527F));
        g.addOrReplaceChild("cono_114", CubeListBuilder.create().texOffs(396, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -25.887028146353416F, -8.896362436608197F, -1.909550462335884F, -0.11067675774067383F, -3.102696466691936F));
        g.addOrReplaceChild("cono_115", CubeListBuilder.create().texOffs(414, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -26.0379259476446F, -8.465121296537783F, -1.9288372579526083F, -0.34085422153016365F, -3.017157478309717F));
        g.addOrReplaceChild("cono_116", CubeListBuilder.create().texOffs(256, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -26.33951538204458F, -7.603228211211322F, -1.9804381964053974F, -0.593011002278812F, -2.903533802987664F));
        g.addOrReplaceChild("cono_117", CubeListBuilder.create().texOffs(800, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -26.79423406075262F, -6.303716888054473F, -2.1028191003441767F, -0.8617878174070339F, -2.7214193772397017F));
        g.addOrReplaceChild("cono_118", CubeListBuilder.create().texOffs(80, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -27.41862725186749F, -4.519303667420534F, -2.3907253386395135F, -1.1020614829851347F, -2.378694360047937F));
        g.addOrReplaceChild("cono_119", CubeListBuilder.create().texOffs(816, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -28.388381987238517F, -1.747903858465767F, -2.9473465050726486F, -1.2274823505614485F, -1.7767522150426895F));
        g.addOrReplaceChild("cono_120", CubeListBuilder.create().texOffs(432, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -27.94470372825149F, -9.366013460588386F, -1.6837656620722965F, -0.11654545534934041F, -3.128400972638498F));
        g.addOrReplaceChild("cono_121", CubeListBuilder.create().texOffs(450, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -27.995858025368275F, -8.91200651657736F, -1.6907007176056525F, -0.35964293477237375F, -3.0992154805784224F));
        g.addOrReplaceChild("cono_122", CubeListBuilder.create().texOffs(272, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -28.09809672866661F, -8.004612927762043F, -1.7097103277839818F, -0.6290334231574534F, -3.0595157165134412F));
        g.addOrReplaceChild("cono_123", CubeListBuilder.create().texOffs(818, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -28.252246187413846F, -6.636498641546604F, -1.7581159054158364F, -0.925758191671395F, -2.9912767200985115F));
        g.addOrReplaceChild("cono_124", CubeListBuilder.create().texOffs(96, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -28.46391524118856F, -4.757883829841469F, -1.9030487742258462F, -1.2204032477335136F, -2.8281949504298276F));
        g.addOrReplaceChild("cono_125", CubeListBuilder.create().texOffs(834, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -28.7926617268173F, -1.8401780708527737F, -2.5931598902896336F, -1.4392099818735404F, -2.1230995145881923F));
        g.addOrReplaceChild("cono_126", CubeListBuilder.create().texOffs(468, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -30.055296271748507F, -9.366013460588388F, -1.4578269915174973F, -0.11654545534934088F, 3.128400972638498F));
        g.addOrReplaceChild("cono_127", CubeListBuilder.create().texOffs(486, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -30.004141974631718F, -8.91200651657736F, -1.450891935984141F, -0.35964293477237375F, 3.099215480578423F));
        g.addOrReplaceChild("cono_128", CubeListBuilder.create().texOffs(288, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -29.901903271333385F, -8.004612927762045F, -1.4318823258058118F, -0.6290334231574534F, 3.0595157165134417F));
        g.addOrReplaceChild("cono_129", CubeListBuilder.create().texOffs(836, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -29.74775381258615F, -6.636498641546606F, -1.3834767481739576F, -0.925758191671395F, 2.9912767200985124F));
        g.addOrReplaceChild("cono_130", CubeListBuilder.create().texOffs(112, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -29.536084758811437F, -4.757883829841469F, -1.2385438793639472F, -1.2204032477335136F, 2.8281949504298276F));
        g.addOrReplaceChild("cono_131", CubeListBuilder.create().texOffs(852, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -29.207338273182696F, -1.840178070852774F, -0.5484327633001638F, -1.4392099818735413F, 2.123099514588196F));
        g.addOrReplaceChild("cono_132", CubeListBuilder.create().texOffs(504, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -32.11297185364657F, -8.8963624366082F, -1.23204219125391F, -0.11067675774067427F, 3.102696466691936F));
        g.addOrReplaceChild("cono_133", CubeListBuilder.create().texOffs(522, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -31.962074052355387F, -8.465121296537784F, -1.212755395637186F, -0.34085422153016365F, 3.0171574783097173F));
        g.addOrReplaceChild("cono_134", CubeListBuilder.create().texOffs(304, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -31.66048461795541F, -7.603228211211325F, -1.1611544571843986F, -0.5930110022788123F, 2.903533802987666F));
        g.addOrReplaceChild("cono_135", CubeListBuilder.create().texOffs(854, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -31.205765939247378F, -6.303716888054476F, -1.038773553245619F, -0.8617878174070348F, 2.721419377239703F));
        g.addOrReplaceChild("cono_136", CubeListBuilder.create().texOffs(128, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -30.5813727481325F, -4.519303667420536F, -0.7508673149502814F, -1.1020614829851352F, 2.3786943600479384F));
        g.addOrReplaceChild("cono_137", CubeListBuilder.create().texOffs(870, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -29.61161801276148F, -1.7479038584657678F, -0.19424614851714564F, -1.2274823505614498F, 1.7767522150426904F));
        g.addOrReplaceChild("cono_138", CubeListBuilder.create().texOffs(540, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -34.014550028164365F, -7.980610652082078F, -1.0066874307142195F, -0.0992444539276055F, 3.0789867954950276F));
        g.addOrReplaceChild("cono_139", CubeListBuilder.create().texOffs(558, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -33.771475368549865F, -7.593759547421589F, -0.9791847557765841F, -0.3045686835474572F, 2.9427665380155794F));
        g.addOrReplaceChild("cono_140", CubeListBuilder.create().texOffs(320, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -33.28565815661687F, -6.820585883834353F, -0.9085555839998274F, -0.5251396744997089F, 2.768963601518475F));
        g.addOrReplaceChild("cono_141", CubeListBuilder.create().texOffs(872, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -32.553171751238295F, -5.654840447765899F, -0.7576880915645975F, -0.7489620286212283F, 2.517767882774257F));
        g.addOrReplaceChild("cono_142", CubeListBuilder.create().texOffs(144, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -31.547364104624666F, -4.054106748146454F, -0.47928046000581165F, -0.9278080370398021F, 2.1467293183231257F));
        g.addOrReplaceChild("cono_143", CubeListBuilder.create().texOffs(888, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -29.98522867128599F, -1.5679824480043953F, -0.10911930315985442F, -1.006033690242547F, 1.6997703088335272F));
        g.addOrReplaceChild("cono_144", CubeListBuilder.create().texOffs(576, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -35.66467772533261F, -6.664677725332606F, -0.781951258342131F, -0.08283863493614749F, 3.058468317217216F));
        g.addOrReplaceChild("cono_145", CubeListBuilder.create().texOffs(594, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -35.34161498581925F, -6.341614985819254F, -0.7519162677703791F, -0.25312837037899966F, 2.879940386430542F));
        g.addOrReplaceChild("cono_146", CubeListBuilder.create().texOffs(336, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -34.695930899955556F, -5.695930899955561F, -0.678312708565471F, -0.4319784098966061F, 2.662450909964954F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("cono_147", CubeListBuilder.create().texOffs(890, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -33.722406694868994F, -4.722406694868998F, -0.5363281393779865F, -0.6048126121027003F, 2.3784093492880296F));
        g.addOrReplaceChild("cono_148", CubeListBuilder.create().texOffs(160, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -32.385619988044795F, -3.3856199880447937F, -0.31563050038457313F, -0.7319801205993044F, 2.0252754350999256F));
        g.addOrReplaceChild("cono_149", CubeListBuilder.create().texOffs(906, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -30.30943585027557F, -1.309435850275572F, -0.06872921300226122F, -0.7830288444166712F, 1.6680709429484084F));
        g.addOrReplaceChild("cono_150", CubeListBuilder.create().texOffs(612, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -36.98061065208208F, -5.014550028164371F, -0.5578977692667613F, -0.062297393936502216F, 3.042154667938987F));
        g.addOrReplaceChild("cono_151", CubeListBuilder.create().texOffs(630, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -36.593759547421584F, -4.771475368549875F, -0.5312623096725481F, -0.18956141479476926F, 2.831285108315277F));
        g.addOrReplaceChild("cono_152", CubeListBuilder.create().texOffs(352, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -35.82058588383435F, -4.285658156616872F, -0.4687262472901594F, -0.3204660784994874F, 2.585082047463565F));
        g.addOrReplaceChild("cono_153", CubeListBuilder.create().texOffs(908, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -34.65484044776589F, -3.5531717512383008F, -0.3574701171825983F, -0.44208459766006125F, 2.2885275030311445F));
        g.addOrReplaceChild("cono_154", CubeListBuilder.create().texOffs(176, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -33.05410674814645F, -2.54736410462467F, -0.20237430597044012F, -0.5269119984193066F, 1.9582032454763916F));
        g.addOrReplaceChild("cono_155", CubeListBuilder.create().texOffs(924, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -30.567982448004393F, -0.9852286712859945F, -0.04322661022596493F, -0.5595088808548678F, 1.6521087272183872F));
        g.addOrReplaceChild("cono_156", CubeListBuilder.create().texOffs(648, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -37.8963624366082F, -3.112971853646584F, -0.3344558736197416F, -0.038658084586685355F, 3.0308328040865127F));
        g.addOrReplaceChild("cono_157", CubeListBuilder.create().texOffs(666, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -37.46512129653778F, -2.9620740523553994F, -0.31625151520549893F, -0.11724234515495606F, 2.798285521745868F));
        g.addOrReplaceChild("cono_158", CubeListBuilder.create().texOffs(368, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -36.603228211211324F, -2.6604846179554205F, -0.27485093115949116F, -0.19682205302321926F, 2.535253759568142F));
        g.addOrReplaceChild("cono_159", CubeListBuilder.create().texOffs(926, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -35.303716888054474F, -2.2057659392473825F, -0.20508243932307532F, -0.26881409904766573F, 2.235204552077211F));
        g.addOrReplaceChild("cono_160", CubeListBuilder.create().texOffs(192, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -33.51930366742053F, -1.5813727481325066F, -0.11377032471363534F, -0.3174799870630684F, 1.9216766559946319F));
        g.addOrReplaceChild("cono_161", CubeListBuilder.create().texOffs(942, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -30.747903858465765F, -0.6116180127614814F, -0.024082674004276133F, -0.3357692913479712F, 1.6437701670294653F));
        g.addOrReplaceChild("cono_162", CubeListBuilder.create().texOffs(684, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-62.970571419134444F, -38.36601346058839F, -1.055296271748513F, -0.11143529511475332F, -0.01310218690761496F, 3.025037148454247F));
        g.addOrReplaceChild("cono_163", CubeListBuilder.create().texOffs(702, 242).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-64.84557141913444F, -37.91200651657736F, -1.0041419746317248F, -0.10498234052994397F, -0.03966451807608945F, 2.7816537365554765F));
        g.addOrReplaceChild("cono_164", CubeListBuilder.create().texOffs(384, 253).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-66.52665042944955F, -37.00461292776205F, -0.9019032713333903F, -0.09055193734208779F, -0.06634129349327826F, 2.51095412836708F));
        g.addOrReplaceChild("cono_165", CubeListBuilder.create().texOffs(944, 248).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.8992456936412F, -35.63649864154661F, -0.7477538125861537F, -0.06687846674356268F, -0.09015642170474195F, 2.210394947895234F));
        g.addOrReplaceChild("cono_166", CubeListBuilder.create().texOffs(208, 286).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-68.86981711277565F, -33.75788382984147F, -0.5360847588114414F, -0.03677642511776979F, -0.10602522309499234F, 1.9053960135042884F));
        g.addOrReplaceChild("cono_167", CubeListBuilder.create().texOffs(960, 303).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.372221848584F, -30.840178070852772F, -0.20733827318269815F, -0.0077559833787494625F, -0.11193246750963005F, 1.6401229747849346F));
        g.addOrReplaceChild("faro_0", CubeListBuilder.create().texOffs(468, 282).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(292, 206).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-69.0F, -29.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_1", CubeListBuilder.create().texOffs(492, 282).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(316, 206).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-69.0F, -29.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_2", CubeListBuilder.create().texOffs(516, 282).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(340, 206).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-69.0F, -29.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_3", CubeListBuilder.create().texOffs(540, 282).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(364, 206).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-69.0F, -29.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_vidrio", CubeListBuilder.create().texOffs(826, 138).addBox(-10.5F, 0.0F, -10.5F, 21.0F, 1.0F, 21.0F), PartPose.offsetAndRotation(-70.22F, -29.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_0", CubeListBuilder.create().texOffs(564, 282).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(388, 206).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-60.5F, -39.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_1", CubeListBuilder.create().texOffs(588, 282).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(412, 206).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-60.5F, -39.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_2", CubeListBuilder.create().texOffs(612, 282).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(436, 206).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-60.5F, -39.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_3", CubeListBuilder.create().texOffs(636, 282).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(460, 206).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-60.5F, -39.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_vidrio", CubeListBuilder.create().texOffs(310, 191).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(-61.52F, -39.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("campana_0", CubeListBuilder.create().texOffs(52, 218).addBox(-13.0F, -40.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(52, 138).addBox(-3.5F, -40.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offset(-40.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("campana_1", CubeListBuilder.create().texOffs(118, 218).addBox(-13.0F, -40.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(118, 138).addBox(-3.5F, -40.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offsetAndRotation(-40.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("campana_2", CubeListBuilder.create().texOffs(184, 218).addBox(-13.0F, -40.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(184, 138).addBox(-3.5F, -40.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offsetAndRotation(-40.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("faldon_frente_0", CubeListBuilder.create().texOffs(106, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-70.9189082366402F, -16.75F, -12.887485129146384F, -1.692633933610866F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_1", CubeListBuilder.create().texOffs(128, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-70.9189082366402F, -20.25F, -12.887485129146384F, -1.692633933610866F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_2", CubeListBuilder.create().texOffs(150, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.60396946438237F, -16.75F, -12.440436265126316F, -1.9824857470735489F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_3", CubeListBuilder.create().texOffs(172, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.60396946438237F, -20.25F, -12.440436265126316F, -1.9824857470735489F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_4", CubeListBuilder.create().texOffs(194, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-74.04187389123834F, -16.75F, -11.558176475314845F, -2.2548390547012858F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_5", CubeListBuilder.create().texOffs(216, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-74.04187389123834F, -20.25F, -11.558176475314845F, -2.2548390547012858F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_6", CubeListBuilder.create().texOffs(238, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-75.28498405538741F, -16.75F, -10.263503851158196F, -2.4886074128110796F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_7", CubeListBuilder.create().texOffs(260, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-75.28498405538741F, -20.25F, -10.263503851158196F, -2.4886074128110796F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_8", CubeListBuilder.create().texOffs(518, 236).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.3160023699435F, -16.75F, -8.58809909000452F, -2.681889968506446F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_9", CubeListBuilder.create().texOffs(542, 236).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.3160023699435F, -20.25F, -8.58809909000452F, -2.681889968506446F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_10", CubeListBuilder.create().texOffs(566, 236).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-77.11272398480914F, -16.75F, -6.5680450732622795F, -2.842101248969347F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_11", CubeListBuilder.create().texOffs(590, 236).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-77.11272398480914F, -20.25F, -6.5680450732622795F, -2.842101248969347F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_12", CubeListBuilder.create().texOffs(266, 229).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-77.65565308623158F, -16.75F, -4.231450379621364F, -2.9777202071809987F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_13", CubeListBuilder.create().texOffs(292, 229).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-77.65565308623158F, -20.25F, -4.231450379621364F, -2.9777202071809987F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_14", CubeListBuilder.create().texOffs(318, 229).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-77.93076007947471F, -16.75F, -1.4932258845403235F, -3.0952564893708923F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_15", CubeListBuilder.create().texOffs(344, 229).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-77.93076007947471F, -20.25F, -1.4932258845403235F, -3.0952564893708923F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_16", CubeListBuilder.create().texOffs(370, 229).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-77.93076007947471F, -16.75F, 1.4932258845403235F, 3.0952564893708923F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_17", CubeListBuilder.create().texOffs(396, 229).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-77.93076007947471F, -20.25F, 1.4932258845403235F, 3.0952564893708923F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_18", CubeListBuilder.create().texOffs(422, 229).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-77.65565308623158F, -16.75F, 4.231450379621364F, 2.9777202071809987F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_19", CubeListBuilder.create().texOffs(448, 229).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-77.65565308623158F, -20.25F, 4.231450379621364F, 2.9777202071809987F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_20", CubeListBuilder.create().texOffs(614, 236).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-77.11272398480914F, -16.75F, 6.56804507326228F, 2.842101248969347F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_21", CubeListBuilder.create().texOffs(638, 236).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-77.11272398480914F, -20.25F, 6.56804507326228F, 2.842101248969347F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_22", CubeListBuilder.create().texOffs(662, 236).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.3160023699435F, -16.75F, 8.58809909000452F, 2.681889968506446F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_23", CubeListBuilder.create().texOffs(686, 236).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.3160023699435F, -20.25F, 8.58809909000452F, 2.681889968506446F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_24", CubeListBuilder.create().texOffs(282, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-75.28498405538741F, -16.75F, 10.263503851158196F, 2.4886074128110796F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_25", CubeListBuilder.create().texOffs(304, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-75.28498405538741F, -20.25F, 10.263503851158196F, 2.4886074128110796F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_26", CubeListBuilder.create().texOffs(326, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-74.04187389123834F, -16.75F, 11.558176475314845F, 2.2548390547012858F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_27", CubeListBuilder.create().texOffs(348, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-74.04187389123834F, -20.25F, 11.558176475314845F, 2.2548390547012858F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_28", CubeListBuilder.create().texOffs(370, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.60396946438237F, -16.75F, 12.440436265126316F, 1.9824857470735489F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_29", CubeListBuilder.create().texOffs(392, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.60396946438237F, -20.25F, 12.440436265126316F, 1.9824857470735489F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_30", CubeListBuilder.create().texOffs(414, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-70.9189082366402F, -16.75F, 12.887485129146386F, 1.692633933610866F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_frente_31", CubeListBuilder.create().texOffs(436, 248).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-70.9189082366402F, -20.25F, 12.887485129146386F, 1.692633933610866F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faldon_tapa", CubeListBuilder.create().texOffs(546, 138).addBox(0.0F, -1.0F, 0.0F, 8.0F, 1.0F, 26.0F), PartPose.offset(-78.0F, -21.0F, -13.0F));
        g.addOrReplaceChild("piloto_0", CubeListBuilder.create().texOffs(190, 229).addBox(-6.5F, -1.0F, -3.0F, 13.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-75.20645313762238F, -5.625F, -11.14805689442376F, -1.7549957769745355F, 0.0F, -1.3375778263676223F));
        g.addOrReplaceChild("piloto_1", CubeListBuilder.create().texOffs(958, 242).addBox(-6.5F, -1.0F, -2.0F, 13.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.72182261846153F, -11.875F, -11.14805689442376F, -1.851148600791257F, 0.0F, -1.3375778263676223F));
        g.addOrReplaceChild("piloto_2", CubeListBuilder.create().texOffs(366, 236).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-77.60915166708436F, -5.625F, -10.488160338223159F, -1.9631794648316048F, 0.0F, -1.213584762556851F));
        g.addOrReplaceChild("piloto_3", CubeListBuilder.create().texOffs(814, 242).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-75.27650990223107F, -11.875F, -10.488160338223159F, -2.139808847124829F, 0.0F, -1.2135847625568488F));
        g.addOrReplaceChild("piloto_4", CubeListBuilder.create().texOffs(404, 236).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-79.5914068578279F, -5.625F, -9.468259498355339F, -2.209741573716726F, 0.0F, -1.1190895867846307F));
        g.addOrReplaceChild("piloto_5", CubeListBuilder.create().texOffs(850, 242).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.55914561388865F, -11.875F, -9.468259498355339F, -2.425041824575577F, 0.0F, -1.1190895867846298F));
        g.addOrReplaceChild("piloto_6", CubeListBuilder.create().texOffs(126, 236).addBox(-7.5F, -1.0F, -2.5F, 15.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.19322214676447F, -5.625F, -8.099685819291068F, -2.4699248057311953F, 0.0F, -1.0484982904746962F));
        g.addOrReplaceChild("piloto_7", CubeListBuilder.create().texOffs(738, 242).addBox(-7.5F, -1.0F, -2.0F, 15.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.59561433025937F, -11.875F, -8.099685819291068F, -2.6664963040783354F, 0.0F, -1.0484982904746962F));
        g.addOrReplaceChild("piloto_8", CubeListBuilder.create().texOffs(166, 236).addBox(-7.5F, -1.0F, -2.5F, 15.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.410952070039F, -5.625F, -6.3888066825133025F, -2.713006223666929F, 0.0F, -0.9983798041940841F));
        g.addOrReplaceChild("piloto_9", CubeListBuilder.create().texOffs(206, 236).addBox(-7.5F, -1.0F, -2.5F, 15.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-78.38355722178994F, -11.875F, -6.3888066825133025F, -2.8541328732603395F, 0.0F, -0.9983798041940833F));
        g.addOrReplaceChild("piloto_10", CubeListBuilder.create().texOffs(980, 229).addBox(-8.0F, -1.0F, -2.5F, 16.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-83.2323098461188F, -5.625F, -4.3144095100901145F, -2.920297652562017F, 0.0F, -0.9662947804030286F));
        g.addOrReplaceChild("piloto_11", CubeListBuilder.create().texOffs(0, 236).addBox(-8.0F, -1.0F, -2.5F, 16.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-78.91502401807686F, -11.875F, -4.3144095100901145F, -2.997033099915826F, 0.0F, -0.9662947804030286F));
        g.addOrReplaceChild("piloto_12", CubeListBuilder.create().texOffs(274, 218).addBox(-8.0F, -1.0F, -3.5F, 16.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-83.64613212419168F, -5.625F, -1.5904288879314532F, -3.0884954286317226F, 0.0F, -0.9506469631369311F));
        g.addOrReplaceChild("piloto_13", CubeListBuilder.create().texOffs(320, 218).addBox(-8.0F, -1.0F, -3.5F, 16.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-79.18279137447696F, -11.875F, -1.5904288879314532F, -3.1072168484445712F, 0.0F, -0.9506469631369319F));
        g.addOrReplaceChild("piloto_14", CubeListBuilder.create().texOffs(366, 218).addBox(-8.0F, -1.0F, -3.5F, 16.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-83.64613212419168F, -5.625F, 1.5904288879314523F, 3.0884954286317226F, 0.0F, -0.9506469631369311F));
        g.addOrReplaceChild("piloto_15", CubeListBuilder.create().texOffs(412, 218).addBox(-8.0F, -1.0F, -3.5F, 16.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-79.18279137447696F, -11.875F, 1.5904288879314523F, 3.1072168484445712F, 0.0F, -0.9506469631369319F));
        g.addOrReplaceChild("piloto_16", CubeListBuilder.create().texOffs(42, 236).addBox(-8.0F, -1.0F, -2.5F, 16.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-83.2323098461188F, -5.625F, 4.314409510090112F, 2.920297652562017F, 0.0F, -0.9662947804030286F));
        g.addOrReplaceChild("piloto_17", CubeListBuilder.create().texOffs(84, 236).addBox(-8.0F, -1.0F, -2.5F, 16.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-78.91502401807686F, -11.875F, 4.314409510090112F, 2.9970330999158254F, 0.0F, -0.9662947804030286F));
        g.addOrReplaceChild("piloto_18", CubeListBuilder.create().texOffs(246, 236).addBox(-7.5F, -1.0F, -2.5F, 15.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.410952070039F, -5.625F, 6.3888066825133F, 2.713006223666929F, 0.0F, -0.9983798041940841F));
        g.addOrReplaceChild("piloto_19", CubeListBuilder.create().texOffs(286, 236).addBox(-7.5F, -1.0F, -2.5F, 15.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-78.38355722178994F, -11.875F, 6.3888066825133F, 2.8541328732603395F, 0.0F, -0.9983798041940833F));
        g.addOrReplaceChild("piloto_20", CubeListBuilder.create().texOffs(326, 236).addBox(-7.5F, -1.0F, -2.5F, 15.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-81.19322214676448F, -5.625F, 8.099685819291068F, 2.4699248057311958F, 0.0F, -1.0484982904746962F));
        g.addOrReplaceChild("piloto_21", CubeListBuilder.create().texOffs(776, 242).addBox(-7.5F, -1.0F, -2.0F, 15.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.59561433025937F, -11.875F, 8.099685819291068F, 2.666496304078336F, 0.0F, -1.0484982904746962F));
        g.addOrReplaceChild("piloto_22", CubeListBuilder.create().texOffs(442, 236).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-79.5914068578279F, -5.625F, 9.468259498355337F, 2.209741573716727F, 0.0F, -1.1190895867846298F));
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("piloto_23", CubeListBuilder.create().texOffs(886, 242).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.55914561388865F, -11.875F, 9.468259498355337F, 2.4250418245755765F, 0.0F, -1.1190895867846298F));
        g.addOrReplaceChild("piloto_24", CubeListBuilder.create().texOffs(480, 236).addBox(-7.0F, -1.0F, -2.5F, 14.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-77.60915166708438F, -5.625F, 10.488160338223157F, 1.9631794648316037F, 0.0F, -1.2135847625568499F));
        g.addOrReplaceChild("piloto_25", CubeListBuilder.create().texOffs(922, 242).addBox(-7.0F, -1.0F, -2.0F, 14.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-75.27650990223106F, -11.875F, 10.488160338223157F, 2.139808847124829F, 0.0F, -1.2135847625568488F));
        g.addOrReplaceChild("piloto_26", CubeListBuilder.create().texOffs(228, 229).addBox(-6.5F, -1.0F, -3.0F, 13.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-75.20645313762238F, -5.625F, 11.14805689442376F, 1.7549957769745361F, 0.0F, -1.3375778263676223F));
        g.addOrReplaceChild("piloto_27", CubeListBuilder.create().texOffs(0, 248).addBox(-6.5F, -1.0F, -2.0F, 13.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.72182261846153F, -11.875F, 11.14805689442376F, 1.8511486007912579F, 0.0F, -1.3375778263676223F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(506, 170).addBox(47.0F, -39.0F, 11.5F, 19.0F, 17.0F, 1.0F).texOffs(546, 170).addBox(47.0F, -39.0F, -12.5F, 19.0F, 17.0F, 1.0F).texOffs(742, 138).addBox(47.0F, -23.0F, -11.5F, 19.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_frente", CubeListBuilder.create().texOffs(0, 138).addBox(0.0F, -7.0F, 0.0F, 1.0F, 7.0F, 25.0F), PartPose.offset(46.0F, -35.0F, -12.5F));
        g.addOrReplaceChild("cabina_fuego", CubeListBuilder.create().texOffs(332, 170).addBox(47.0F, -34.0F, -5.0F, 2.0F, 11.0F, 10.0F).texOffs(474, 229).addBox(49.0F, -28.0F, -2.0F, 1.0F, 3.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(864, 278).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -39.49927091301129F, -11.51615384404144F, -2.7173867122803745F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(916, 278).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -40.31080529218622F, -9.517149853366792F, -2.7945150652457276F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(968, 278).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -40.965899979783764F, -7.461558465566805F, -2.8716434182110686F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(0, 282).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -41.46065989126571F, -5.361601886657044F, -2.9487717711764225F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(52, 282).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -41.79214326612349F, -3.2297661107331788F, -3.0259001241417716F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(104, 282).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -41.95837915909906F, -1.0787266803175881F, -3.1030284771071184F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(156, 282).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -41.95837915909906F, 1.0787266803175866F, 3.1030284771071184F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(208, 282).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -41.79214326612349F, 3.229766110733176F, 3.0259001241417716F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(260, 282).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -41.46065989126571F, 5.361601886657043F, 2.9487717711764225F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(312, 282).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -40.965899979783764F, 7.461558465566805F, 2.8716434182110686F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(364, 282).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -40.31080529218622F, 9.517149853366792F, 2.7945150652457276F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(416, 282).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(56.5F, -39.49927091301129F, 11.51615384404144F, 2.7173867122803745F, 0.0F, 0.0F));
        g.addOrReplaceChild("numeroi", CubeListBuilder.create().texOffs(458, 218).addBox(0.0F, -7.0F, -0.5F, 17.0F, 7.0F, 1.0F), PartPose.offset(51.75F, -25.75F, -13.0F));
        g.addOrReplaceChild("numerod", CubeListBuilder.create().texOffs(494, 218).addBox(0.0F, -7.0F, -0.5F, 17.0F, 7.0F, 1.0F), PartPose.offset(51.75F, -25.75F, 13.0F));
        g.addOrReplaceChild("cab_fondo_caldera", CubeListBuilder.create().texOffs(956, 69).addBox(46.6F, -35.0F, -11.5F, 1.0F, 12.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_placa", CubeListBuilder.create().texOffs(836, 206).addBox(47.0F, -39.0F, -3.5F, 1.0F, 5.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(362, 191).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(48.6F, -35.6F, 2.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(586, 296).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(48.72F, -35.6F, 2.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_presion", CubeListBuilder.create().texOffs(414, 191).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(48.6F, -35.6F, -2.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_presion_aguja", CubeListBuilder.create().texOffs(590, 296).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(48.72F, -35.6F, -2.0F, 0.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_nivel", CubeListBuilder.create().texOffs(734, 242).addBox(49.0F, -32.0F, -4.5F, 1.0F, 5.0F, 1.0F).texOffs(568, 296).addBox(49.0F, -27.0F, -5.0F, 1.0F, 1.0F, 2.0F).texOffs(574, 296).addBox(49.0F, -33.0F, -5.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_regulador", CubeListBuilder.create().texOffs(484, 229).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(48.5F, -34.5F, 0.0F, 1.9495902196202934F, 0.09966865249116204F, 1.5707963267948966F));
        g.addOrReplaceChild("cab_valvulas", CubeListBuilder.create().texOffs(992, 303).addBox(49.0F, -32.0F, -2.0F, 1.0F, 1.0F, 1.0F).texOffs(996, 303).addBox(49.0F, -32.0F, 3.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_tubo", CubeListBuilder.create().texOffs(270, 218).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 8.0F, 1.0F), PartPose.offset(49.5F, -31.5F, 3.5F));
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(48, 218).addBox(-0.5F, -10.0F, -0.5F, 1.0F, 10.0F, 1.0F).texOffs(304, 286).addBox(-1.0F, -12.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(53.0F, -23.0F, 8.0F));
        g.addOrReplaceChild("cab_palanca_cuadrante", CubeListBuilder.create().texOffs(978, 303).addBox(50.0F, -24.0F, 8.5F, 6.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(580, 296).addBox(56.0F, -34.0F, 10.5F, 2.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_freno_manija", CubeListBuilder.create().texOffs(312, 286).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(57.0F, -34.0F, 11.0F, -0.7297276562269664F, 0.0F, -2.0344439357957027F));
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(250, 218).addBox(64.0F, -29.0F, 2.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(260, 218).addBox(64.0F, -29.0F, -6.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
    }

    private static void piezas6(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(580, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(86.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(590, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(98.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(98.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(98.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri2_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(600, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(110.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri2_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(110.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri2_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(110.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri3_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(610, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(162.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri3_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(162.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri3_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(162.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri4_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(620, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(174.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri4_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(174.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri4_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(174.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri5_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(630, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(186.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri5_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(186.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri5_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(186.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(640, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(86.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(650, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(98.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(98.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(98.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd2_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(110.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd2_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(110.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd2_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(110.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd3_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(670, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(162.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd3_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(162.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd3_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(162.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd4_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(680, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(174.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd4_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(174.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd4_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(174.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd5_0", CubeListBuilder.create().texOffs(1000, 206).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(726, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(690, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(186.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd5_1", CubeListBuilder.create().texOffs(748, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(186.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd5_2", CubeListBuilder.create().texOffs(770, 282).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 218).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(186.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_bogies", CubeListBuilder.create().texOffs(750, 218).addBox(81.0F, -9.0F, 7.0F, 34.0F, 6.0F, 1.0F).texOffs(820, 218).addBox(81.0F, -9.0F, -8.0F, 34.0F, 6.0F, 1.0F).texOffs(890, 218).addBox(157.0F, -9.0F, 7.0F, 34.0F, 6.0F, 1.0F).texOffs(0, 229).addBox(157.0F, -9.0F, -8.0F, 34.0F, 6.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(650, 69).addBox(72.0F, -35.0F, -12.5F, 128.0F, 22.0F, 25.0F).texOffs(0, 170).addBox(72.0F, -39.0F, -8.5F, 128.0F, 4.0F, 17.0F).texOffs(398, 170).addBox(74.0F, -40.0F, -9.0F, 36.0F, 1.0F, 18.0F).texOffs(614, 138).addBox(200.0F, -13.0F, -10.0F, 2.0F, 7.0F, 20.0F).texOffs(720, 242).addBox(202.0F, -11.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender_caja_cantoi_0", CubeListBuilder.create().texOffs(316, 286).addBox(-64.0F, -1.0F, -1.0F, 128.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(136.0F, -35.61803398874989F, -12.402113032590307F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_1", CubeListBuilder.create().texOffs(576, 286).addBox(-64.0F, -1.0F, -1.0F, 128.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(136.0F, -36.79360449333484F, -12.0201470213402F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_2", CubeListBuilder.create().texOffs(0, 290).addBox(-64.0F, -1.0F, -1.0F, 128.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(136.0F, -37.79360449333484F, -11.29360449333484F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_3", CubeListBuilder.create().texOffs(260, 290).addBox(-64.0F, -1.0F, -1.0F, 128.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(136.0F, -38.5201470213402F, -10.29360449333484F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_4", CubeListBuilder.create().texOffs(520, 290).addBox(-64.0F, -1.0F, -1.0F, 128.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(136.0F, -38.90211303259031F, -9.118033988749895F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_0", CubeListBuilder.create().texOffs(0, 293).addBox(-64.0F, -1.0F, -1.0F, 128.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(136.0F, -35.61803398874989F, 12.402113032590307F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_1", CubeListBuilder.create().texOffs(260, 293).addBox(-64.0F, -1.0F, -1.0F, 128.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(136.0F, -36.79360449333484F, 12.0201470213402F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_2", CubeListBuilder.create().texOffs(520, 293).addBox(-64.0F, -1.0F, -1.0F, 128.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(136.0F, -37.79360449333484F, 11.29360449333484F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_3", CubeListBuilder.create().texOffs(0, 296).addBox(-64.0F, -1.0F, -1.0F, 128.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(136.0F, -38.5201470213402F, 10.29360449333484F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_4", CubeListBuilder.create().texOffs(260, 296).addBox(-64.0F, -1.0F, -1.0F, 128.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(136.0F, -38.90211303259031F, 9.118033988749895F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_tapaa", CubeListBuilder.create().texOffs(446, 69).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 50.0F), PartPose.offset(72.0F, -35.0F, -12.5F));
        g.addOrReplaceChild("tender_caja_tapab", CubeListBuilder.create().texOffs(548, 69).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 50.0F), PartPose.offset(199.0F, -35.0F, -12.5F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "cil_i_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "caja_humo_0", 1.0F, 0.30773023274113315F, 0.30773023274113315F);
        escalar(g0, "caja_humo_1", 1.0F, 0.30773023274113315F, 0.30773023274113315F);
        escalar(g0, "caja_humo_2", 1.0F, 0.30773023274113315F, 0.30773023274113315F);
        escalar(g0, "caja_humo_3", 1.0F, 0.30773023274113315F, 0.30773023274113315F);
        escalar(g0, "caja_humo_4", 1.0F, 0.30773023274113315F, 0.30773023274113315F);
        escalar(g0, "caja_humo_5", 1.0F, 0.30773023274113315F, 0.30773023274113315F);
        escalar(g0, "caja_humo_6", 1.0F, 0.30773023274113315F, 0.30773023274113315F);
        escalar(g0, "caldera_0", 0.9791866132720112F, 1.0F, 0.6979119010439523F);
        escalar(g0, "caldera_1", 0.9791866132720112F, 1.0F, 0.709108348654283F);
        escalar(g0, "caldera_2", 0.9791866132720112F, 1.0F, 0.7203047962646137F);
        escalar(g0, "caldera_3", 0.9791866132720112F, 1.0F, 0.7315012438749444F);
        escalar(g0, "caldera_4", 0.9791866132720112F, 1.0F, 0.6979119010439527F);
        escalar(g0, "caldera_5", 0.9791866132720112F, 1.0F, 0.7091083486542834F);
        escalar(g0, "caldera_6", 0.9791866132720112F, 1.0F, 0.7203047962646144F);
        escalar(g0, "caldera_7", 0.9791866132720112F, 1.0F, 0.7315012438749448F);
        escalar(g0, "caldera_8", 0.9791866132720112F, 1.0F, 0.6979119010439522F);
        escalar(g0, "caldera_9", 0.9791866132720112F, 1.0F, 0.7091083486542833F);
        escalar(g0, "caldera_10", 0.9791866132720112F, 1.0F, 0.7203047962646137F);
        escalar(g0, "caldera_11", 0.9791866132720112F, 1.0F, 0.7315012438749452F);
        escalar(g0, "caldera_12", 0.9791866132720112F, 1.0F, 0.6979119010439524F);
        escalar(g0, "caldera_13", 0.9791866132720112F, 1.0F, 0.7091083486542832F);
        escalar(g0, "caldera_14", 0.9791866132720112F, 1.0F, 0.7203047962646135F);
        escalar(g0, "caldera_15", 0.9791866132720112F, 1.0F, 0.7315012438749443F);
        escalar(g0, "caldera_16", 0.9791866132720112F, 1.0F, 0.6979119010439513F);
        escalar(g0, "caldera_17", 0.9791866132720112F, 1.0F, 0.7091083486542812F);
        escalar(g0, "caldera_18", 0.9791866132720112F, 1.0F, 0.7203047962646137F);
        escalar(g0, "caldera_19", 0.9791866132720112F, 1.0F, 0.7315012438749439F);
        escalar(g0, "caldera_20", 0.9791866132720112F, 1.0F, 0.6979119010439526F);
        escalar(g0, "caldera_21", 0.9791866132720112F, 1.0F, 0.7091083486542843F);
        escalar(g0, "caldera_22", 0.9791866132720112F, 1.0F, 0.720304796264614F);
        escalar(g0, "caldera_23", 0.9791866132720112F, 1.0F, 0.7315012438749459F);
        escalar(g0, "caldera_24", 0.9791866132720112F, 1.0F, 0.6979119010439527F);
        escalar(g0, "caldera_25", 0.9791866132720112F, 1.0F, 0.7091083486542834F);
        escalar(g0, "caldera_26", 0.9791866132720112F, 1.0F, 0.7203047962646142F);
        escalar(g0, "caldera_27", 0.9791866132720112F, 1.0F, 0.731501243874945F);
        escalar(g0, "caldera_28", 0.9791866132720112F, 1.0F, 0.6979119010439515F);
        escalar(g0, "caldera_29", 0.9791866132720112F, 1.0F, 0.7091083486542823F);
        escalar(g0, "caldera_30", 0.9791866132720112F, 1.0F, 0.7203047962646142F);
        escalar(g0, "caldera_31", 0.9791866132720112F, 1.0F, 0.731501243874945F);
        escalar(g0, "caldera_32", 0.9791866132720112F, 1.0F, 0.6979119010439535F);
        escalar(g0, "caldera_33", 0.9791866132720112F, 1.0F, 0.7091083486542832F);
        escalar(g0, "caldera_34", 0.9791866132720112F, 1.0F, 0.720304796264614F);
        escalar(g0, "caldera_35", 0.9791866132720112F, 1.0F, 0.7315012438749448F);
        escalar(g0, "caldera_36", 0.9791866132720112F, 1.0F, 0.6979119010439501F);
        escalar(g0, "caldera_37", 0.9791866132720112F, 1.0F, 0.709108348654282F);
        escalar(g0, "caldera_38", 0.9791866132720112F, 1.0F, 0.7203047962646121F);
        escalar(g0, "caldera_39", 0.9791866132720112F, 1.0F, 0.7315012438749431F);
        escalar(g0, "caldera_40", 0.9791866132720112F, 1.0F, 0.6979119010439536F);
        escalar(g0, "caldera_41", 0.9791866132720112F, 1.0F, 0.7091083486542846F);
        escalar(g0, "caldera_42", 0.9791866132720112F, 1.0F, 0.7203047962646152F);
        escalar(g0, "caldera_43", 0.9791866132720112F, 1.0F, 0.7315012438749458F);
        escalar(g0, "caldera_44", 0.9791866132720112F, 1.0F, 0.6979119010439522F);
        escalar(g0, "caldera_45", 0.9791866132720112F, 1.0F, 0.7091083486542827F);
        escalar(g0, "caldera_46", 0.9791866132720112F, 1.0F, 0.7203047962646137F);
        escalar(g0, "caldera_47", 0.9791866132720112F, 1.0F, 0.731501243874945F);
        escalar(g0, "caldera_48", 0.9791866132720112F, 1.0F, 0.6979119010439508F);
        escalar(g0, "caldera_49", 0.9791866132720112F, 1.0F, 0.709108348654282F);
        escalar(g0, "caldera_50", 0.9791866132720112F, 1.0F, 0.7203047962646125F);
        escalar(g0, "caldera_51", 0.9791866132720112F, 1.0F, 0.7315012438749431F);
        escalar(g0, "caldera_52", 0.9791866132720112F, 1.0F, 0.6979119010439536F);
        escalar(g0, "caldera_53", 0.9791866132720112F, 1.0F, 0.7091083486542843F);
        escalar(g0, "caldera_54", 0.9791866132720112F, 1.0F, 0.7203047962646152F);
        escalar(g0, "caldera_55", 0.9791866132720112F, 1.0F, 0.7315012438749462F);
        escalar(g0, "caldera_56", 0.9791866132720112F, 1.0F, 0.6979119010439524F);
        escalar(g0, "caldera_57", 0.9791866132720112F, 1.0F, 0.7091083486542832F);
        escalar(g0, "caldera_58", 0.9791866132720112F, 1.0F, 0.7203047962646137F);
        escalar(g0, "caldera_59", 0.9791866132720112F, 1.0F, 0.7315012438749448F);
        escalar(g0, "caldera_60", 0.9791866132720112F, 1.0F, 0.6979119010439526F);
        escalar(g0, "caldera_61", 0.9791866132720112F, 1.0F, 0.7091083486542827F);
        escalar(g0, "caldera_62", 0.9791866132720112F, 1.0F, 0.7203047962646144F);
        escalar(g0, "caldera_63", 0.9791866132720112F, 1.0F, 0.7315012438749448F);
        escalar(g0, "caldera_64", 0.9791866132720112F, 1.0F, 0.6979119010439505F);
        escalar(g0, "caldera_65", 0.9791866132720112F, 1.0F, 0.709108348654282F);
        escalar(g0, "caldera_66", 0.9791866132720112F, 1.0F, 0.7203047962646121F);
        escalar(g0, "caldera_67", 0.9791866132720112F, 1.0F, 0.7315012438749435F);
        escalar(g0, "caldera_68", 0.9791866132720112F, 1.0F, 0.6979119010439533F);
        escalar(g0, "caldera_69", 0.9791866132720112F, 1.0F, 0.7091083486542841F);
        escalar(g0, "caldera_70", 0.9791866132720112F, 1.0F, 0.7203047962646153F);
        escalar(g0, "caldera_71", 0.9791866132720112F, 1.0F, 0.7315012438749461F);
        escalar(g0, "caldera_72", 0.9791866132720112F, 1.0F, 0.6979119010439501F);
        escalar(g0, "caldera_73", 0.9791866132720112F, 1.0F, 0.7091083486542811F);
        escalar(g0, "caldera_74", 0.9791866132720112F, 1.0F, 0.7203047962646112F);
        escalar(g0, "caldera_75", 0.9791866132720112F, 1.0F, 0.7315012438749413F);
        escalar(g0, "caldera_76", 0.9791866132720112F, 1.0F, 0.6979119010439526F);
        escalar(g0, "caldera_77", 0.9791866132720112F, 1.0F, 0.7091083486542821F);
        escalar(g0, "caldera_78", 0.9791866132720112F, 1.0F, 0.7203047962646131F);
        escalar(g0, "caldera_79", 0.9791866132720112F, 1.0F, 0.7315012438749449F);
        escalar(g0, "caldera_80", 0.9791866132720112F, 1.0F, 0.6979119010439551F);
        escalar(g0, "caldera_81", 0.9791866132720112F, 1.0F, 0.7091083486542872F);
        escalar(g0, "caldera_82", 0.9791866132720112F, 1.0F, 0.7203047962646179F);
        escalar(g0, "caldera_83", 0.9791866132720112F, 1.0F, 0.7315012438749474F);
        escalar(g0, "caldera_84", 0.9791866132720112F, 1.0F, 0.6979119010439515F);
        escalar(g0, "caldera_85", 0.9791866132720112F, 1.0F, 0.7091083486542823F);
        escalar(g0, "caldera_86", 0.9791866132720112F, 1.0F, 0.720304796264613F);
        escalar(g0, "caldera_87", 0.9791866132720112F, 1.0F, 0.731501243874945F);
        escalar(g0, "caldera_88", 0.9791866132720112F, 1.0F, 0.6979119010439533F);
        escalar(g0, "caldera_89", 0.9791866132720112F, 1.0F, 0.7091083486542828F);
        escalar(g0, "caldera_90", 0.9791866132720112F, 1.0F, 0.7203047962646149F);
        escalar(g0, "caldera_91", 0.9791866132720112F, 1.0F, 0.7315012438749445F);
        escalar(g0, "caldera_92", 0.9791866132720112F, 1.0F, 0.6979119010439517F);
        escalar(g0, "caldera_93", 0.9791866132720112F, 1.0F, 0.7091083486542837F);
        escalar(g0, "caldera_94", 0.9791866132720112F, 1.0F, 0.7203047962646139F);
        escalar(g0, "caldera_95", 0.9791866132720112F, 1.0F, 0.7315012438749458F);
        escalar(g0, "caldera_96", 0.9791866132720112F, 1.0F, 0.6979119010439523F);
        escalar(g0, "caldera_97", 0.9791866132720112F, 1.0F, 0.7091083486542827F);
        escalar(g0, "caldera_98", 0.9791866132720112F, 1.0F, 0.7203047962646134F);
        escalar(g0, "caldera_99", 0.9791866132720112F, 1.0F, 0.7315012438749443F);
        escalar(g0, "caldera_100", 0.9791866132720112F, 1.0F, 0.6979119010439486F);
        escalar(g0, "caldera_101", 0.9791866132720112F, 1.0F, 0.7091083486542803F);
        escalar(g0, "caldera_102", 0.9791866132720112F, 1.0F, 0.7203047962646115F);
        escalar(g0, "caldera_103", 0.9791866132720112F, 1.0F, 0.7315012438749416F);
        escalar(g0, "caldera_104", 0.9791866132720112F, 1.0F, 0.6979119010439527F);
        escalar(g0, "caldera_105", 0.9791866132720112F, 1.0F, 0.7091083486542828F);
        escalar(g0, "caldera_106", 0.9791866132720112F, 1.0F, 0.7203047962646142F);
        escalar(g0, "caldera_107", 0.9791866132720112F, 1.0F, 0.7315012438749452F);
        escalar(g0, "caldera_108", 0.9791866132720112F, 1.0F, 0.6979119010439551F);
        escalar(g0, "caldera_109", 0.9791866132720112F, 1.0F, 0.709108348654286F);
        escalar(g0, "caldera_110", 0.9791866132720112F, 1.0F, 0.7203047962646165F);
        escalar(g0, "caldera_111", 0.9791866132720112F, 1.0F, 0.7315012438749474F);
        escalar(g0, "skyline_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "skyline_cantoi_1", 1.0F, 1.0F, 0.9386067902413818F);
        escalar(g0, "skyline_cantoi_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "skyline_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "skyline_cantoi_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "skyline_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "skyline_cantod_1", 1.0F, 1.0F, 0.9386067902413818F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "skyline_cantod_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "skyline_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "skyline_cantod_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "skyline_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "skyline_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cono_0", 0.49368523201181386F, 1.0F, 0.42878949588910853F);
        escalar(g0, "cono_1", 0.48894227219813485F, 1.0F, 0.4081983039494289F);
        escalar(g0, "cono_2", 0.48793918414483345F, 1.0F, 0.45880506667532994F);
        escalar(g0, "cono_3", 0.4066488877343466F, 1.0F, 0.381242641049204F);
        escalar(g0, "cono_4", 0.4654894202320423F, 1.0F, 0.3663179174508557F);
        escalar(g0, "cono_5", 0.4694787644346796F, 1.0F, 0.43730044396852435F);
        escalar(g0, "cono_6", 0.4936852320118138F, 1.0F, 0.42878949588910853F);
        escalar(g0, "cono_7", 0.4889422721981352F, 1.0F, 0.40819830394942896F);
        escalar(g0, "cono_8", 0.48793918414483317F, 1.0F, 0.45880506667533005F);
        escalar(g0, "cono_9", 0.4066488877343466F, 1.0F, 0.38124264104920436F);
        escalar(g0, "cono_10", 0.465489420232042F, 1.0F, 0.3663179174508559F);
        escalar(g0, "cono_11", 0.4694787644346799F, 1.0F, 0.4373004439685247F);
        escalar(g0, "cono_12", 0.4936852320118138F, 1.0F, 0.4287894958891088F);
        escalar(g0, "cono_13", 0.48894227219813513F, 1.0F, 0.4081983039494289F);
        escalar(g0, "cono_14", 0.4879391841448332F, 1.0F, 0.4588050666753296F);
        escalar(g0, "cono_15", 0.40664888773434676F, 1.0F, 0.3812426410492038F);
        escalar(g0, "cono_16", 0.465489420232042F, 1.0F, 0.36631791745085596F);
        escalar(g0, "cono_17", 0.4694787644346799F, 1.0F, 0.43730044396852535F);
        escalar(g0, "cono_18", 0.4936852320118138F, 1.0F, 0.4287894958891084F);
        escalar(g0, "cono_19", 0.488942272198135F, 1.0F, 0.40819830394942896F);
        escalar(g0, "cono_20", 0.4879391841448334F, 1.0F, 0.4588050666753304F);
        escalar(g0, "cono_21", 0.4066488877343467F, 1.0F, 0.3812426410492046F);
        escalar(g0, "cono_22", 0.46548942023204215F, 1.0F, 0.36631791745085573F);
        escalar(g0, "cono_23", 0.4694787644346798F, 1.0F, 0.4373004439685241F);
        escalar(g0, "cono_24", 0.4936852320118138F, 1.0F, 0.4287894958891081F);
        escalar(g0, "cono_25", 0.4889422721981349F, 1.0F, 0.40819830394942835F);
        escalar(g0, "cono_26", 0.4879391841448336F, 1.0F, 0.45880506667532905F);
        escalar(g0, "cono_27", 0.40664888773434643F, 1.0F, 0.38124264104920336F);
        escalar(g0, "cono_28", 0.4654894202320423F, 1.0F, 0.36631791745085546F);
        escalar(g0, "cono_29", 0.46947876443467973F, 1.0F, 0.4373004439685246F);
        escalar(g0, "cono_30", 0.4936852320118138F, 1.0F, 0.4287894958891088F);
        escalar(g0, "cono_31", 0.4889422721981349F, 1.0F, 0.40819830394942913F);
        escalar(g0, "cono_32", 0.48793918414483356F, 1.0F, 0.45880506667533044F);
        escalar(g0, "cono_33", 0.4066488877343466F, 1.0F, 0.3812426410492048F);
        escalar(g0, "cono_34", 0.4654894202320425F, 1.0F, 0.366317917450856F);
        escalar(g0, "cono_35", 0.46947876443467973F, 1.0F, 0.43730044396852524F);
        escalar(g0, "cono_36", 0.49368523201181386F, 1.0F, 0.428789495889109F);
        escalar(g0, "cono_37", 0.4889422721981349F, 1.0F, 0.40819830394942935F);
        escalar(g0, "cono_38", 0.48793918414483356F, 1.0F, 0.45880506667533005F);
        escalar(g0, "cono_39", 0.4066488877343466F, 1.0F, 0.3812426410492039F);
        escalar(g0, "cono_40", 0.4654894202320423F, 1.0F, 0.366317917450856F);
        escalar(g0, "cono_41", 0.46947876443467973F, 1.0F, 0.43730044396852463F);
        escalar(g0, "cono_42", 0.49368523201181386F, 1.0F, 0.42878949588910825F);
        escalar(g0, "cono_43", 0.4889422721981349F, 1.0F, 0.40819830394942863F);
        escalar(g0, "cono_44", 0.4879391841448335F, 1.0F, 0.4588050666753296F);
        escalar(g0, "cono_45", 0.4066488877343466F, 1.0F, 0.3812426410492039F);
        escalar(g0, "cono_46", 0.4654894202320423F, 1.0F, 0.366317917450856F);
        escalar(g0, "cono_47", 0.46947876443467973F, 1.0F, 0.43730044396852463F);
        escalar(g0, "cono_48", 0.4936852320118138F, 1.0F, 0.4287894958891088F);
        escalar(g0, "cono_49", 0.4889422721981349F, 1.0F, 0.4081983039494291F);
        escalar(g0, "cono_50", 0.4879391841448335F, 1.0F, 0.45880506667532994F);
        escalar(g0, "cono_51", 0.4066488877343466F, 1.0F, 0.3812426410492039F);
        escalar(g0, "cono_52", 0.4654894202320423F, 1.0F, 0.36631791745085546F);
        escalar(g0, "cono_53", 0.46947876443467973F, 1.0F, 0.4373004439685252F);
        escalar(g0, "cono_54", 0.4936852320118138F, 1.0F, 0.4287894958891079F);
        escalar(g0, "cono_55", 0.4889422721981348F, 1.0F, 0.40819830394942846F);
        escalar(g0, "cono_56", 0.4879391841448336F, 1.0F, 0.4588050666753296F);
        escalar(g0, "cono_57", 0.4066488877343466F, 1.0F, 0.38124264104920386F);
        escalar(g0, "cono_58", 0.4654894202320425F, 1.0F, 0.36631791745085523F);
        escalar(g0, "cono_59", 0.4694787644346797F, 1.0F, 0.43730044396852286F);
        escalar(g0, "cono_60", 0.4936852320118138F, 1.0F, 0.4287894958891094F);
        escalar(g0, "cono_61", 0.4889422721981349F, 1.0F, 0.4081983039494294F);
        escalar(g0, "cono_62", 0.48793918414483356F, 1.0F, 0.4588050666753304F);
        escalar(g0, "cono_63", 0.4066488877343465F, 1.0F, 0.38124264104920447F);
        escalar(g0, "cono_64", 0.4654894202320425F, 1.0F, 0.36631791745085635F);
        escalar(g0, "cono_65", 0.4694787644346797F, 1.0F, 0.43730044396852563F);
        escalar(g0, "cono_66", 0.4936852320118138F, 1.0F, 0.42878949588910864F);
        escalar(g0, "cono_67", 0.48894227219813513F, 1.0F, 0.4081983039494289F);
        escalar(g0, "cono_68", 0.4879391841448334F, 1.0F, 0.45880506667532983F);
        escalar(g0, "cono_69", 0.4066488877343466F, 1.0F, 0.3812426410492041F);
        escalar(g0, "cono_70", 0.4654894202320423F, 1.0F, 0.36631791745085573F);
        escalar(g0, "cono_71", 0.4694787644346797F, 1.0F, 0.4373004439685244F);
        escalar(g0, "cono_72", 0.4936852320118138F, 1.0F, 0.4287894958891078F);
        escalar(g0, "cono_73", 0.4889422721981352F, 1.0F, 0.4081983039494282F);
        escalar(g0, "cono_74", 0.4879391841448332F, 1.0F, 0.4588050666753292F);
        escalar(g0, "cono_75", 0.4066488877343466F, 1.0F, 0.3812426410492036F);
        escalar(g0, "cono_76", 0.46548942023204265F, 1.0F, 0.36631791745085523F);
        escalar(g0, "cono_77", 0.46947876443467956F, 1.0F, 0.43730044396852397F);
        escalar(g0, "cono_78", 0.49368523201181386F, 1.0F, 0.4287894958891093F);
        escalar(g0, "cono_79", 0.48894227219813485F, 1.0F, 0.4081983039494297F);
        escalar(g0, "cono_80", 0.4879391841448335F, 1.0F, 0.45880506667533083F);
        escalar(g0, "cono_81", 0.4066488877343466F, 1.0F, 0.38124264104920474F);
        escalar(g0, "cono_82", 0.46548942023204265F, 1.0F, 0.3663179174508564F);
        escalar(g0, "cono_83", 0.46947876443467945F, 1.0F, 0.4373004439685253F);
        escalar(g0, "cono_84", 0.49368523201181386F, 1.0F, 0.42878949588910864F);
        escalar(g0, "cono_85", 0.48894227219813485F, 1.0F, 0.40819830394942896F);
        escalar(g0, "cono_86", 0.48793918414483345F, 1.0F, 0.45880506667532994F);
        escalar(g0, "cono_87", 0.4066488877343466F, 1.0F, 0.381242641049204F);
        escalar(g0, "cono_88", 0.46548942023204265F, 1.0F, 0.36631791745085573F);
        escalar(g0, "cono_89", 0.4694787644346794F, 1.0F, 0.4373004439685245F);
        escalar(g0, "cono_90", 0.4936852320118138F, 1.0F, 0.42878949588910864F);
        escalar(g0, "cono_91", 0.488942272198135F, 1.0F, 0.4081983039494288F);
        escalar(g0, "cono_92", 0.4879391841448334F, 1.0F, 0.45880506667532983F);
        escalar(g0, "cono_93", 0.4066488877343466F, 1.0F, 0.3812426410492043F);
        escalar(g0, "cono_94", 0.4654894202320425F, 1.0F, 0.3663179174508559F);
        escalar(g0, "cono_95", 0.4694787644346795F, 1.0F, 0.4373004439685248F);
        escalar(g0, "cono_96", 0.4936852320118139F, 1.0F, 0.4287894958891079F);
        escalar(g0, "cono_97", 0.48894227219813485F, 1.0F, 0.40819830394942835F);
        escalar(g0, "cono_98", 0.48793918414483356F, 1.0F, 0.45880506667532905F);
        escalar(g0, "cono_99", 0.4066488877343466F, 1.0F, 0.38124264104920313F);
        escalar(g0, "cono_100", 0.4654894202320425F, 1.0F, 0.36631791745085485F);
        escalar(g0, "cono_101", 0.4694787644346796F, 1.0F, 0.4373004439685238F);
        escalar(g0, "cono_102", 0.49368523201181386F, 1.0F, 0.4287894958891093F);
        escalar(g0, "cono_103", 0.4889422721981348F, 1.0F, 0.4081983039494294F);
        escalar(g0, "cono_104", 0.4879391841448335F, 1.0F, 0.4588050666753305F);
        escalar(g0, "cono_105", 0.4066488877343466F, 1.0F, 0.3812426410492049F);
        escalar(g0, "cono_106", 0.4654894202320423F, 1.0F, 0.36631791745085646F);
        escalar(g0, "cono_107", 0.4694787644346797F, 1.0F, 0.4373004439685246F);
        escalar(g0, "cono_108", 0.4936852320118138F, 1.0F, 0.42878949588910664F);
        escalar(g0, "cono_109", 0.48894227219813485F, 1.0F, 0.4081983039494272F);
        escalar(g0, "cono_110", 0.4879391841448336F, 1.0F, 0.4588050666753284F);
        escalar(g0, "cono_111", 0.4066488877343466F, 1.0F, 0.3812426410492027F);
        escalar(g0, "cono_112", 0.46548942023204215F, 1.0F, 0.36631791745085424F);
        escalar(g0, "cono_113", 0.4694787644346797F, 1.0F, 0.43730044396852286F);
        escalar(g0, "cono_114", 0.4936852320118138F, 1.0F, 0.42878949588910886F);
        escalar(g0, "cono_115", 0.4889422721981349F, 1.0F, 0.40819830394942924F);
        escalar(g0, "cono_116", 0.48793918414483356F, 1.0F, 0.4588050666753297F);
        escalar(g0, "cono_117", 0.4066488877343466F, 1.0F, 0.3812426410492037F);
        escalar(g0, "cono_118", 0.46548942023204243F, 1.0F, 0.3663179174508557F);
        escalar(g0, "cono_119", 0.4694787644346797F, 1.0F, 0.43730044396852535F);
        escalar(g0, "cono_120", 0.4936852320118138F, 1.0F, 0.4287894958891104F);
        escalar(g0, "cono_121", 0.4889422721981349F, 1.0F, 0.40819830394943074F);
        escalar(g0, "cono_122", 0.4879391841448335F, 1.0F, 0.4588050666753323F);
        escalar(g0, "cono_123", 0.4066488877343466F, 1.0F, 0.38124264104920613F);
        escalar(g0, "cono_124", 0.4654894202320425F, 1.0F, 0.3663179174508578F);
        escalar(g0, "cono_125", 0.4694787644346797F, 1.0F, 0.43730044396852646F);
        escalar(g0, "cono_126", 0.49368523201181386F, 1.0F, 0.42878949588910825F);
        escalar(g0, "cono_127", 0.4889422721981349F, 1.0F, 0.40819830394942863F);
        escalar(g0, "cono_128", 0.4879391841448335F, 1.0F, 0.4588050666753296F);
        escalar(g0, "cono_129", 0.4066488877343466F, 1.0F, 0.3812426410492039F);
        escalar(g0, "cono_130", 0.4654894202320425F, 1.0F, 0.36631791745085546F);
        escalar(g0, "cono_131", 0.4694787644346797F, 1.0F, 0.43730044396852286F);
        escalar(g0, "cono_132", 0.4936852320118138F, 1.0F, 0.428789495889108F);
        escalar(g0, "cono_133", 0.4889422721981349F, 1.0F, 0.40819830394942835F);
        escalar(g0, "cono_134", 0.4879391841448333F, 1.0F, 0.45880506667532983F);
        escalar(g0, "cono_135", 0.40664888773434676F, 1.0F, 0.3812426410492043F);
        escalar(g0, "cono_136", 0.4654894202320423F, 1.0F, 0.36631791745085596F);
        escalar(g0, "cono_137", 0.4694787644346797F, 1.0F, 0.4373004439685268F);
        escalar(g0, "cono_138", 0.4936852320118138F, 1.0F, 0.4287894958891094F);
        escalar(g0, "cono_139", 0.4889422721981349F, 1.0F, 0.4081983039494297F);
        escalar(g0, "cono_140", 0.4879391841448334F, 1.0F, 0.45880506667532994F);
        escalar(g0, "cono_141", 0.4066488877343466F, 1.0F, 0.38124264104920375F);
        escalar(g0, "cono_142", 0.4654894202320425F, 1.0F, 0.3663179174508555F);
        escalar(g0, "cono_143", 0.4694787644346796F, 1.0F, 0.4373004439685232F);
        escalar(g0, "cono_144", 0.4936852320118138F, 1.0F, 0.4287894958891082F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1) {
        escalar(g0, "cono_145", 0.488942272198135F, 1.0F, 0.4081983039494288F);
        escalar(g0, "cono_146", 0.4879391841448338F, 1.0F, 0.45880506667532955F);
        escalar(g0, "cono_147", 0.40664888773434626F, 1.0F, 0.3812426410492038F);
        escalar(g0, "cono_148", 0.4654894202320425F, 1.0F, 0.366317917450856F);
        escalar(g0, "cono_149", 0.4694787644346797F, 1.0F, 0.4373004439685252F);
        escalar(g0, "cono_150", 0.4936852320118138F, 1.0F, 0.42878949588910686F);
        escalar(g0, "cono_151", 0.48894227219813485F, 1.0F, 0.4081983039494273F);
        escalar(g0, "cono_152", 0.48793918414483417F, 1.0F, 0.4588050666753283F);
        escalar(g0, "cono_153", 0.4066488877343459F, 1.0F, 0.3812426410492027F);
        escalar(g0, "cono_154", 0.46548942023204265F, 1.0F, 0.36631791745085424F);
        escalar(g0, "cono_155", 0.4694787644346796F, 1.0F, 0.43730044396852225F);
        escalar(g0, "cono_156", 0.4936852320118137F, 1.0F, 0.42878949588910864F);
        escalar(g0, "cono_157", 0.4889422721981349F, 1.0F, 0.4081983039494291F);
        escalar(g0, "cono_158", 0.4879391841448337F, 1.0F, 0.4588050666753301F);
        escalar(g0, "cono_159", 0.40664888773434615F, 1.0F, 0.3812426410492044F);
        escalar(g0, "cono_160", 0.46548942023204337F, 1.0F, 0.36631791745085573F);
        escalar(g0, "cono_161", 0.46947876443467923F, 1.0F, 0.4373004439685246F);
        escalar(g0, "cono_162", 0.49368523201181375F, 1.0F, 0.4287894958891103F);
        escalar(g0, "cono_163", 0.48894227219813485F, 1.0F, 0.40819830394943046F);
        escalar(g0, "cono_164", 0.4879391841448335F, 1.0F, 0.4588050666753317F);
        escalar(g0, "cono_165", 0.4066488877343466F, 1.0F, 0.38124264104920547F);
        escalar(g0, "cono_166", 0.46548942023204304F, 1.0F, 0.36631791745085723F);
        escalar(g0, "cono_167", 0.46947876443467923F, 1.0F, 0.43730044396852635F);
        escalar(g0, "faro_0", 0.5100083458096798F, 0.8999999999999999F, 0.5100083458096798F);
        escalar(g0, "faro_1", 0.5100083458096798F, 0.8999999999999999F, 0.5100083458096798F);
        escalar(g0, "faro_2", 0.5100083458096798F, 0.8999999999999999F, 0.5100083458096798F);
        escalar(g0, "faro_3", 0.5100083458096798F, 0.8999999999999999F, 0.5100083458096798F);
        escalar(g0, "faro_vidrio", 0.24761904761904763F, 0.15F, 0.24761904761904763F);
        escalar(g0, "faro_alto_0", 0.31385128972903376F, 0.8F, 0.31385128972903376F);
        escalar(g0, "faro_alto_1", 0.31385128972903376F, 0.8F, 0.31385128972903376F);
        escalar(g0, "faro_alto_2", 0.31385128972903376F, 0.8F, 0.31385128972903376F);
        escalar(g0, "faro_alto_3", 0.31385128972903376F, 0.8F, 0.31385128972903376F);
        escalar(g0, "faro_alto_vidrio", 0.24615384615384617F, 0.15F, 0.24615384615384617F);
        escalar(g0, "campana_0", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
        escalar(g0, "campana_1", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
        escalar(g0, "campana_2", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
        escalar(g0, "faldon_frente_0", 0.5028571428571429F, 1.0F, 0.4678854997535547F);
        escalar(g0, "faldon_frente_1", 0.5028571428571429F, 1.0F, 0.4678854997535547F);
        escalar(g0, "faldon_frente_2", 0.5028571428571429F, 1.0F, 0.4230022124218987F);
        escalar(g0, "faldon_frente_3", 0.5028571428571429F, 1.0F, 0.4230022124218987F);
        escalar(g0, "faldon_frente_4", 0.5028571428571429F, 1.0F, 0.43837441656953396F);
        escalar(g0, "faldon_frente_5", 0.5028571428571429F, 1.0F, 0.43837441656953396F);
        escalar(g0, "faldon_frente_6", 0.5028571428571429F, 1.0F, 0.4752074966551901F);
        escalar(g0, "faldon_frente_7", 0.5028571428571429F, 1.0F, 0.4752074966551901F);
        escalar(g0, "faldon_frente_8", 0.5028571428571429F, 1.0F, 0.41840483968072706F);
        escalar(g0, "faldon_frente_9", 0.5028571428571429F, 1.0F, 0.41840483968072706F);
        escalar(g0, "faldon_frente_10", 0.5028571428571429F, 1.0F, 0.4609801430844313F);
        escalar(g0, "faldon_frente_11", 0.5028571428571429F, 1.0F, 0.4609801430844313F);
        escalar(g0, "faldon_frente_12", 0.5028571428571429F, 1.0F, 0.4239681435214217F);
        escalar(g0, "faldon_frente_13", 0.5028571428571429F, 1.0F, 0.4239681435214217F);
        escalar(g0, "faldon_frente_14", 0.5028571428571429F, 1.0F, 0.5016101092605262F);
        escalar(g0, "faldon_frente_15", 0.5028571428571429F, 1.0F, 0.5016101092605262F);
        escalar(g0, "faldon_frente_16", 0.5028571428571429F, 1.0F, 0.5016101092605262F);
        escalar(g0, "faldon_frente_17", 0.5028571428571429F, 1.0F, 0.5016101092605262F);
        escalar(g0, "faldon_frente_18", 0.5028571428571429F, 1.0F, 0.4239681435214217F);
        escalar(g0, "faldon_frente_19", 0.5028571428571429F, 1.0F, 0.4239681435214217F);
        escalar(g0, "faldon_frente_20", 0.5028571428571429F, 1.0F, 0.4609801430844313F);
        escalar(g0, "faldon_frente_21", 0.5028571428571429F, 1.0F, 0.4609801430844313F);
        escalar(g0, "faldon_frente_22", 0.5028571428571429F, 1.0F, 0.41840483968072706F);
        escalar(g0, "faldon_frente_23", 0.5028571428571429F, 1.0F, 0.41840483968072706F);
        escalar(g0, "faldon_frente_24", 0.5028571428571429F, 1.0F, 0.4752074966551901F);
        escalar(g0, "faldon_frente_25", 0.5028571428571429F, 1.0F, 0.4752074966551901F);
        escalar(g0, "faldon_frente_26", 0.5028571428571429F, 1.0F, 0.43837441656953396F);
        escalar(g0, "faldon_frente_27", 0.5028571428571429F, 1.0F, 0.43837441656953396F);
        escalar(g0, "faldon_frente_28", 0.5028571428571429F, 1.0F, 0.4230022124218987F);
        escalar(g0, "faldon_frente_29", 0.5028571428571429F, 1.0F, 0.4230022124218987F);
        escalar(g0, "faldon_frente_30", 0.5028571428571429F, 1.0F, 0.4678854997535547F);
        escalar(g0, "faldon_frente_31", 0.5028571428571429F, 1.0F, 0.4678854997535547F);
        escalar(g0, "piloto_0", 0.49690679423521505F, 1.0F, 0.449345743129902F);
        escalar(g0, "piloto_1", 0.49690679423521517F, 1.0F, 0.44831635127160746F);
        escalar(g0, "piloto_2", 0.4786275829860198F, 1.0F, 0.47108084826189556F);
        escalar(g0, "piloto_3", 0.47862758298602015F, 1.0F, 0.41796373904543715F);
        escalar(g0, "piloto_4", 0.49803952571758F, 1.0F, 0.4362920001046663F);
        escalar(g0, "piloto_5", 0.49803952571758014F, 1.0F, 0.42544889560295757F);
        escalar(g0, "piloto_6", 0.48231370069379104F, 1.0F, 0.42358862858961366F);
        escalar(g0, "piloto_7", 0.48231370069379104F, 1.0F, 0.45593775294682126F);
        escalar(g0, "piloto_8", 0.4971174853870739F, 1.0F, 0.43351522150179644F);
        escalar(g0, "piloto_9", 0.4971174853870741F, 1.0F, 0.4043887745340601F);
        escalar(g0, "piloto_10", 0.476042549743627F, 1.0F, 0.4745393340786174F);
        escalar(g0, "piloto_11", 0.4760425497436269F, 1.0F, 0.4649667365119957F);
        escalar(g0, "piloto_12", 0.48125976822066396F, 1.0F, 0.4582634097101464F);
        escalar(g0, "piloto_13", 0.48125976822066363F, 1.0F, 0.4577010428123676F);
        escalar(g0, "piloto_14", 0.48125976822066396F, 1.0F, 0.45826340971014623F);
        escalar(g0, "piloto_15", 0.48125976822066363F, 1.0F, 0.45770104281236745F);
        escalar(g0, "piloto_16", 0.476042549743627F, 1.0F, 0.4745393340786171F);
        escalar(g0, "piloto_17", 0.4760425497436269F, 1.0F, 0.4649667365119954F);
        escalar(g0, "piloto_18", 0.4971174853870739F, 1.0F, 0.4335152215017968F);
        escalar(g0, "piloto_19", 0.4971174853870741F, 1.0F, 0.4043887745340604F);
        escalar(g0, "piloto_20", 0.48231370069379104F, 1.0F, 0.42358862858961394F);
        escalar(g0, "piloto_21", 0.48231370069379104F, 1.0F, 0.4559377529468217F);
        escalar(g0, "piloto_22", 0.49803952571758014F, 1.0F, 0.43629200010466496F);
        escalar(g0, "piloto_23", 0.49803952571758014F, 1.0F, 0.4254488956029573F);
        escalar(g0, "piloto_24", 0.47862758298601993F, 1.0F, 0.4710808482618969F);
        escalar(g0, "piloto_25", 0.47862758298602015F, 1.0F, 0.41796373904543715F);
        escalar(g0, "piloto_26", 0.49690679423521505F, 1.0F, 0.4493457431299021F);
        escalar(g0, "piloto_27", 0.49690679423521517F, 1.0F, 0.4483163512716076F);
        escalar(g0, "cabina_techo_0", 1.0008695652173913F, 1.0F, 0.7263528776800517F);
        escalar(g0, "cabina_techo_1", 1.0008695652173913F, 1.0F, 0.7263528776800502F);
        escalar(g0, "cabina_techo_2", 1.0008695652173913F, 1.0F, 0.7263528776800522F);
        escalar(g0, "cabina_techo_3", 1.0008695652173913F, 1.0F, 0.7263528776800509F);
        escalar(g0, "cabina_techo_4", 1.0008695652173913F, 1.0F, 0.7263528776800512F);
        escalar(g0, "cabina_techo_5", 1.0008695652173913F, 1.0F, 0.7263528776800515F);
        escalar(g0, "cabina_techo_6", 1.0008695652173913F, 1.0F, 0.7263528776800504F);
        escalar(g0, "cabina_techo_7", 1.0008695652173913F, 1.0F, 0.7263528776800516F);
        escalar(g0, "cabina_techo_8", 1.0008695652173913F, 1.0F, 0.7263528776800515F);
        escalar(g0, "cabina_techo_9", 1.0008695652173913F, 1.0F, 0.7263528776800516F);
        escalar(g0, "cabina_techo_10", 1.0008695652173913F, 1.0F, 0.7263528776800507F);
        escalar(g0, "cabina_techo_11", 1.0008695652173913F, 1.0F, 0.7263528776800517F);
        escalar(g0, "numeroi", 0.5F, 0.5F, 1.0F);
        escalar(g0, "numerod", 0.5F, 0.5F, 1.0F);
        escalar(g0, "cab_velocimetro", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.656F, 0.6F);
        escalar(g0, "cab_presion", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "cab_presion_aguja", 0.3F, 0.656F, 0.6F);
        escalar(g0, "cab_regulador", 0.8F, 0.9013878188659974F, 0.8F);
        escalar(g0, "cab_tubo", 0.6F, 0.9375F, 0.6F);
        escalar(g0, "cab_freno_manija", 0.6F, 1.0F, 0.6F);
        escalar(g1, "tender_caja_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g1, "tender_caja_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g1, "tender_caja_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g1, "tender_caja_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g1, "tender_caja_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g1, "tender_caja_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g1, "tender_caja_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g1, "tender_caja_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g1, "tender_caja_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g1, "tender_caja_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g1, "tender_caja_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tender_caja_tapab", 1.0F, 0.5F, 0.5F);
    }
}
