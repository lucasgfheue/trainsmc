package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "EMD SD40-2" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloSD40 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("sd40"), "main"),
            LocomotoraMod.id("textures/entity/sd40.png"),
            List.of(
                new DatosModelo.Animada("bogiefi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefi2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -79.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -60.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 62.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 81.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, -68.28F, -30.5F, 0.0F, "cuerpo", 4.8F, 8.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.15F, 0.0F, -68.0F, -29.0F, 0.15F, "cuerpo", -0.24F, 11.0F, 0.0F)),
            ModeloSD40::crearCapa,
            16.0F,
            ModeloSD40::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -60.0F, 62.0F)));

    private ModeloSD40() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogiefi0_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(756, 159).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-79.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi0_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-79.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi0_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-79.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefi1_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(766, 159).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-60.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi1_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi1_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefi2_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(776, 159).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-41.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi2_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi2_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd0_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(786, 159).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-79.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd0_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-79.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd0_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-79.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd1_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(796, 159).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-60.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd1_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd1_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd2_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(806, 159).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-41.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd2_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd2_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogief", CubeListBuilder.create().texOffs(172, 159).addBox(-85.0F, -9.0F, 7.0F, 50.0F, 6.0F, 1.0F).texOffs(274, 159).addBox(-85.0F, -9.0F, -8.0F, 50.0F, 6.0F, 1.0F).texOffs(816, 159).addBox(-81.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(826, 159).addBox(-81.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(836, 159).addBox(-62.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(846, 159).addBox(-62.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(856, 159).addBox(-43.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(866, 159).addBox(-43.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(628, 159).addBox(-71.5F, -9.0F, 8.0F, 4.0F, 5.0F, 1.0F).texOffs(638, 159).addBox(-71.5F, -9.0F, -9.0F, 4.0F, 5.0F, 1.0F).texOffs(648, 159).addBox(-52.5F, -9.0F, 8.0F, 4.0F, 5.0F, 1.0F).texOffs(658, 159).addBox(-52.5F, -9.0F, -9.0F, 4.0F, 5.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogieti0_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(876, 159).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(43.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti0_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti0_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogieti1_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(886, 159).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(62.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti1_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti1_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogieti2_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(896, 159).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(81.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti2_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti2_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd0_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(906, 159).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(43.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd0_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd0_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd1_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(916, 159).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(62.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd1_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd1_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(62.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd2_0", CubeListBuilder.create().texOffs(812, 142).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(24, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(926, 159).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(81.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd2_1", CubeListBuilder.create().texOffs(46, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd2_2", CubeListBuilder.create().texOffs(68, 173).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 142).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(81.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiet", CubeListBuilder.create().texOffs(376, 159).addBox(37.0F, -9.0F, 7.0F, 50.0F, 6.0F, 1.0F).texOffs(478, 159).addBox(37.0F, -9.0F, -8.0F, 50.0F, 6.0F, 1.0F).texOffs(936, 159).addBox(41.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(946, 159).addBox(41.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(956, 159).addBox(60.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(966, 159).addBox(60.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(976, 159).addBox(79.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(986, 159).addBox(79.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(668, 159).addBox(50.5F, -9.0F, 8.0F, 4.0F, 5.0F, 1.0F).texOffs(678, 159).addBox(50.5F, -9.0F, -9.0F, 4.0F, 5.0F, 1.0F).texOffs(688, 159).addBox(69.5F, -9.0F, 8.0F, 4.0F, 5.0F, 1.0F).texOffs(698, 159).addBox(69.5F, -9.0F, -9.0F, 4.0F, 5.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tanque", CubeListBuilder.create().texOffs(814, 72).addBox(-36.0F, -10.0F, -11.0F, 74.0F, 7.0F, 22.0F).texOffs(638, 114).addBox(-36.0F, -12.0F, -9.0F, 74.0F, 2.0F, 18.0F).texOffs(262, 183).addBox(-36.0F, -7.0F, 11.0F, 74.0F, 1.0F, 1.0F).texOffs(412, 183).addBox(-36.0F, -7.0F, -12.0F, 74.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tanque_cantoi_0", CubeListBuilder.create().texOffs(562, 183).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.309016994374947F, -10.951056516295154F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_1", CubeListBuilder.create().texOffs(712, 183).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.89680224666742F, -10.7600735106701F, -2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_2", CubeListBuilder.create().texOffs(862, 183).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.39680224666742F, -10.39680224666742F, -2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_3", CubeListBuilder.create().texOffs(0, 185).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.7600735106701F, -9.89680224666742F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_4", CubeListBuilder.create().texOffs(150, 185).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.951056516295154F, -9.309016994374947F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_0", CubeListBuilder.create().texOffs(300, 185).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.309016994374947F, 10.951056516295154F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_1", CubeListBuilder.create().texOffs(450, 185).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -10.89680224666742F, 10.7600735106701F, 2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_2", CubeListBuilder.create().texOffs(600, 185).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.39680224666742F, 10.39680224666742F, 2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_3", CubeListBuilder.create().texOffs(750, 185).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.7600735106701F, 9.89680224666742F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_4", CubeListBuilder.create().texOffs(0, 187).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -11.951056516295154F, 9.309016994374947F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_tapaa", CubeListBuilder.create().texOffs(332, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(-36.0F, -10.0F, -11.0F));
        g.addOrReplaceChild("tanque_tapab", CubeListBuilder.create().texOffs(422, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(37.0F, -10.0F, -11.0F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(316, 72).addBox(-92.0F, -15.0F, -14.5F, 184.0F, 4.0F, 29.0F), PartPose.ZERO);
        g.addOrReplaceChild("barandas", CubeListBuilder.create().texOffs(490, 187).addBox(-86.0F, -26.0F, 13.0F, 12.0F, 1.0F, 1.0F).texOffs(516, 187).addBox(-86.0F, -26.0F, -14.0F, 12.0F, 1.0F, 1.0F).texOffs(548, 181).addBox(-42.0F, -26.0F, 13.0F, 130.0F, 1.0F, 1.0F).texOffs(0, 183).addBox(-42.0F, -26.0F, -14.0F, 130.0F, 1.0F, 1.0F).texOffs(876, 142).addBox(-86.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(880, 142).addBox(-86.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(884, 142).addBox(-75.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(888, 142).addBox(-75.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(892, 142).addBox(-42.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(896, 142).addBox(-42.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(900, 142).addBox(-10.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(904, 142).addBox(-10.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(908, 142).addBox(22.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(912, 142).addBox(22.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(916, 142).addBox(54.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(920, 142).addBox(54.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F).texOffs(924, 142).addBox(87.0F, -25.0F, 13.0F, 1.0F, 10.0F, 1.0F).texOffs(928, 142).addBox(87.0F, -25.0F, -14.0F, 1.0F, 10.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("pilotof", CubeListBuilder.create().texOffs(600, 159).addBox(-98.0F, -11.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("piloto_rayasf", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -20.0F, 0.0F, 4.0F, 20.0F, 52.0F), PartPose.offset(-94.0F, -5.0F, -13.0F));
        g.addOrReplaceChild("pilotot", CubeListBuilder.create().texOffs(614, 159).addBox(94.0F, -11.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("piloto_rayast", CubeListBuilder.create().texOffs(112, 0).addBox(0.0F, -20.0F, 0.0F, 4.0F, 20.0F, 52.0F), PartPose.offset(92.0F, -5.0F, -13.0F));
        g.addOrReplaceChild("capo_corto", CubeListBuilder.create().texOffs(742, 72).addBox(-88.0F, -28.0F, -10.0F, 16.0F, 13.0F, 20.0F).texOffs(910, 114).addBox(-88.0F, -31.0F, -7.0F, 16.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_corto_cantoi_0", CubeListBuilder.create().texOffs(150, 187).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -28.46352549156242F, -9.92658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_1", CubeListBuilder.create().texOffs(184, 187).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -29.34520337000113F, -9.640110266005152F, -2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_2", CubeListBuilder.create().texOffs(218, 187).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.09520337000113F, -9.095203370001132F, -2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_3", CubeListBuilder.create().texOffs(252, 187).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.640110266005152F, -8.345203370001132F, -2.670353755551325F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_4", CubeListBuilder.create().texOffs(286, 187).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.92658477444273F, -7.463525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_0", CubeListBuilder.create().texOffs(320, 187).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -28.46352549156242F, 9.92658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_1", CubeListBuilder.create().texOffs(354, 187).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -29.34520337000113F, 9.640110266005152F, 2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_2", CubeListBuilder.create().texOffs(388, 187).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.09520337000113F, 9.095203370001132F, 2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_3", CubeListBuilder.create().texOffs(422, 187).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.640110266005152F, 8.345203370001132F, 2.670353755551325F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_4", CubeListBuilder.create().texOffs(456, 187).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-80.0F, -30.92658477444273F, 7.463525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_tapaa", CubeListBuilder.create().texOffs(692, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 40.0F), PartPose.offset(-88.0F, -28.0F, -10.0F));
        g.addOrReplaceChild("capo_corto_tapab", CubeListBuilder.create().texOffs(774, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 40.0F), PartPose.offset(-73.0F, -28.0F, -10.0F));
        g.addOrReplaceChild("faro_a_0", CubeListBuilder.create().texOffs(744, 169).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(116, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, -1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_1", CubeListBuilder.create().texOffs(768, 169).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(140, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, -1.6F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_2", CubeListBuilder.create().texOffs(792, 169).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(164, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, -1.6F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_3", CubeListBuilder.create().texOffs(816, 169).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(188, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, -1.6F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_vidrio", CubeListBuilder.create().texOffs(404, 142).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-89.02000000000001F, -28.0F, -1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_0", CubeListBuilder.create().texOffs(840, 169).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(212, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, 1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_1", CubeListBuilder.create().texOffs(864, 169).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(236, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, 1.6F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_2", CubeListBuilder.create().texOffs(888, 169).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(260, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, 1.6F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_3", CubeListBuilder.create().texOffs(912, 169).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(284, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.4F, -28.0F, 1.6F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_vidrio", CubeListBuilder.create().texOffs(444, 142).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-89.02000000000001F, -28.0F, 1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(224, 0).addBox(-72.0F, -38.0F, -14.0F, 26.0F, 23.0F, 28.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(0, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -38.16644998527687F, -12.952375688249639F, -2.5706682836287893F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(62, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -39.39999781853689F, -10.793045647306894F, -2.6744727145307907F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(124, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -40.403159959547146F, -8.517521048120587F, -2.7782771454327917F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(186, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.165136678034074F, -6.1502994777680815F, -2.8820815763347922F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(248, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.67772477064898F, -3.7168657042768674F, -2.985886007236793F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(310, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.93540587409307F, -1.2434173155721182F, -3.0896904381387915F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(372, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.93540587409307F, 1.2434173155721167F, 3.0896904381387915F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(434, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.67772477064898F, 3.7168657042768647F, 2.9858860072367936F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(496, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -41.165136678034074F, 6.1502994777680815F, 2.8820815763347922F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(558, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -40.403159959547146F, 8.517521048120587F, 2.7782771454327917F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(620, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -39.39999781853689F, 10.79304564730689F, 2.6744727145307907F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(682, 169).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.0F, -38.16644998527687F, 12.952375688249639F, 2.5706682836287897F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo", CubeListBuilder.create().texOffs(0, 72).addBox(-46.0F, -35.0F, -11.0F, 136.0F, 20.0F, 22.0F).texOffs(330, 114).addBox(-46.0F, -37.0F, -9.0F, 136.0F, 2.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_largo_cantoi_0", CubeListBuilder.create().texOffs(390, 173).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -35.30901699437494F, -10.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_1", CubeListBuilder.create().texOffs(664, 173).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -35.89680224666742F, -10.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_2", CubeListBuilder.create().texOffs(0, 177).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.39680224666742F, -10.39680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_3", CubeListBuilder.create().texOffs(274, 177).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.7600735106701F, -9.89680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_4", CubeListBuilder.create().texOffs(548, 177).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.951056516295154F, -9.309016994374947F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_0", CubeListBuilder.create().texOffs(0, 179).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -35.30901699437494F, 10.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_1", CubeListBuilder.create().texOffs(274, 179).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -35.89680224666742F, 10.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_2", CubeListBuilder.create().texOffs(548, 179).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.39680224666742F, 10.39680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_3", CubeListBuilder.create().texOffs(0, 181).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.7600735106701F, 9.89680224666742F, 2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_4", CubeListBuilder.create().texOffs(274, 181).addBox(-68.0F, -1.0F, -0.5F, 136.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.0F, -36.951056516295154F, 9.309016994374947F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_tapaa", CubeListBuilder.create().texOffs(512, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(-46.0F, -35.0F, -11.0F));
        g.addOrReplaceChild("capo_largo_tapab", CubeListBuilder.create().texOffs(602, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(89.0F, -35.0F, -11.0F));
        g.addOrReplaceChild("freno_dinamico", CubeListBuilder.create().texOffs(822, 114).addBox(-40.0F, -39.0F, -9.0F, 26.0F, 2.0F, 18.0F).texOffs(932, 142).addBox(56.0F, -35.0F, 11.0F, 34.0F, 9.0F, 1.0F).texOffs(0, 159).addBox(56.0F, -35.0F, -12.0F, 34.0F, 9.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("ventilador60_0", CubeListBuilder.create().texOffs(98, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(524, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(60.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador60_1", CubeListBuilder.create().texOffs(122, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(548, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador60_2", CubeListBuilder.create().texOffs(146, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(572, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador60_3", CubeListBuilder.create().texOffs(170, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(596, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador72_0", CubeListBuilder.create().texOffs(194, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(620, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(72.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador72_1", CubeListBuilder.create().texOffs(218, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(644, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(72.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador72_2", CubeListBuilder.create().texOffs(242, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(668, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(72.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador72_3", CubeListBuilder.create().texOffs(266, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(692, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(72.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador84_0", CubeListBuilder.create().texOffs(290, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(716, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(84.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador84_1", CubeListBuilder.create().texOffs(314, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(740, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(84.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador84_2", CubeListBuilder.create().texOffs(338, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(764, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(84.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador84_3", CubeListBuilder.create().texOffs(362, 173).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(788, 142).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(84.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("escape", CubeListBuilder.create().texOffs(580, 159).addBox(0.0F, -39.0F, -2.0F, 6.0F, 2.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("bocina_0", CubeListBuilder.create().texOffs(32, 142).addBox(-40.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(970, 114).addBox(-40.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -39.5F, 0.0F));
        g.addOrReplaceChild("bocina_1", CubeListBuilder.create().texOffs(50, 142).addBox(-40.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(0, 142).addBox(-40.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -39.5F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("faro_t_0", CubeListBuilder.create().texOffs(936, 169).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(308, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(90.4F, -33.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_1", CubeListBuilder.create().texOffs(960, 169).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(332, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(90.4F, -33.0F, 0.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_2", CubeListBuilder.create().texOffs(984, 169).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(356, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(90.4F, -33.0F, 0.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_3", CubeListBuilder.create().texOffs(0, 173).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(380, 142).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(90.4F, -33.0F, 0.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_vidrio", CubeListBuilder.create().texOffs(484, 142).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(91.02000000000001F, -33.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_forro", CubeListBuilder.create().texOffs(204, 114).addBox(-71.0F, -37.0F, 12.5F, 24.0F, 21.0F, 1.0F).texOffs(254, 114).addBox(-71.0F, -37.0F, -13.5F, 24.0F, 21.0F, 1.0F).texOffs(856, 0).addBox(-48.0F, -37.0F, -12.5F, 1.0F, 21.0F, 25.0F).texOffs(0, 114).addBox(-71.0F, -16.0F, -13.5F, 24.0F, 1.0F, 27.0F).texOffs(102, 114).addBox(-71.0F, -38.0F, -13.5F, 24.0F, 1.0F, 27.0F).texOffs(908, 0).addBox(-71.0F, -37.0F, -12.5F, 1.0F, 21.0F, 25.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_pupitre", CubeListBuilder.create().texOffs(304, 114).addBox(-70.0F, -29.0F, 3.5F, 4.0F, 13.0F, 9.0F).texOffs(834, 142).addBox(-70.0F, -32.0F, 4.0F, 1.0F, 3.0F, 8.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(68, 142).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-68.4F, -30.5F, 8.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(386, 173).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-68.28F, -30.5F, 8.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro0", CubeListBuilder.create().texOffs(70, 159).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-68.4F, -30.5F, 4.4F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro0_aguja", CubeListBuilder.create().texOffs(542, 187).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-68.28F, -30.5F, 4.4F, 0.4F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro1", CubeListBuilder.create().texOffs(106, 159).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-68.4F, -30.5F, 11.6F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro1_aguja", CubeListBuilder.create().texOffs(546, 187).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-68.28F, -30.5F, 11.6F, 1.1F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_luces", CubeListBuilder.create().texOffs(550, 187).addBox(-68.0F, -30.0F, 4.0F, 1.0F, 1.0F, 1.0F).texOffs(554, 187).addBox(-68.0F, -30.0F, 5.2F, 1.0F, 1.0F, 1.0F).texOffs(558, 187).addBox(-68.0F, -30.0F, 6.4F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(996, 159).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F).texOffs(90, 173).addBox(-1.0F, -6.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-68.0F, -29.0F, 11.0F, 0.0F, 0.0F, 0.15F));
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(1000, 159).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(-68.0F, -29.5F, 5.0F, 0.0F, 0.0F, -2.4668517113662407F));
        g.addOrReplaceChild("cab_freno_perilla", CubeListBuilder.create().texOffs(562, 187).addBox(-66.5F, -32.5F, 4.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(708, 159).addBox(-62.0F, -18.400000000000002F, 4.5F, 4.0F, 1.0F, 4.0F).texOffs(142, 159).addBox(-58.0F, -24.400000000000002F, 4.5F, 1.0F, 6.0F, 4.0F).texOffs(566, 187).addBox(-60.5F, -17.400000000000002F, 6.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(724, 159).addBox(-62.0F, -18.400000000000002F, -8.5F, 4.0F, 1.0F, 4.0F).texOffs(152, 159).addBox(-58.0F, -24.400000000000002F, -8.5F, 1.0F, 6.0F, 4.0F).texOffs(570, 187).addBox(-60.5F, -17.400000000000002F, -7.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento2", CubeListBuilder.create().texOffs(740, 159).addBox(-55.0F, -18.400000000000002F, -2.0F, 4.0F, 1.0F, 4.0F).texOffs(162, 159).addBox(-51.0F, -24.400000000000002F, -2.0F, 1.0F, 6.0F, 4.0F).texOffs(574, 187).addBox(-53.5F, -17.400000000000002F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "tanque_cantoi_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_cantoi_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantoi_2", 1.0F, 1.0F, 0.6257378601609229F);
        escalar(g0, "tanque_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_cantod_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_cantod_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantod_2", 1.0F, 1.0F, 0.6257378601609229F);
        escalar(g0, "tanque_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "tanque_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "tanque_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "tanque_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "piloto_rayasf", 0.5F, 0.5F, 0.5F);
        escalar(g0, "piloto_rayast", 0.5F, 0.5F, 0.5F);
        escalar(g0, "capo_corto_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_corto_cantoi_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_corto_cantoi_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "capo_corto_cantoi_3", 1.0F, 1.0F, 0.9386067902413854F);
        escalar(g0, "capo_corto_cantoi_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "capo_corto_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_corto_cantod_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_corto_cantod_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "capo_corto_cantod_3", 1.0F, 1.0F, 0.9386067902413854F);
        escalar(g0, "capo_corto_cantod_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "capo_corto_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_corto_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_a_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_a_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_a_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_a_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_a_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "faro_b_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_b_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_b_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_b_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_b_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "cabina_techo_0", 1.0007142857142857F, 1.0F, 0.8367293207319423F);
        escalar(g0, "cabina_techo_1", 1.0007142857142857F, 1.0F, 0.8367293207319428F);
        escalar(g0, "cabina_techo_2", 1.0007142857142857F, 1.0F, 0.836729320731942F);
        escalar(g0, "cabina_techo_3", 1.0007142857142857F, 1.0F, 0.8367293207319423F);
        escalar(g0, "cabina_techo_4", 1.0007142857142857F, 1.0F, 0.8367293207319416F);
        escalar(g0, "cabina_techo_5", 1.0007142857142857F, 1.0F, 0.8367293207319427F);
        escalar(g0, "cabina_techo_6", 1.0007142857142857F, 1.0F, 0.8367293207319416F);
        escalar(g0, "cabina_techo_7", 1.0007142857142857F, 1.0F, 0.8367293207319424F);
        escalar(g0, "cabina_techo_8", 1.0007142857142857F, 1.0F, 0.8367293207319425F);
        escalar(g0, "cabina_techo_9", 1.0007142857142857F, 1.0F, 0.8367293207319414F);
        escalar(g0, "cabina_techo_10", 1.0007142857142857F, 1.0F, 0.8367293207319428F);
        escalar(g0, "cabina_techo_11", 1.0007142857142857F, 1.0F, 0.8367293207319427F);
        escalar(g0, "capo_largo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_largo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_largo_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_largo_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_largo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_largo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_largo_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_largo_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_largo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_largo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "ventilador60_0", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador60_1", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador60_2", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador60_3", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador72_0", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador72_1", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador72_2", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador72_3", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador84_0", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador84_1", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador84_2", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "ventilador84_3", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "bocina_0", 1.0F, 0.1077859454596501F, 0.1077859454596501F);
        escalar(g0, "bocina_1", 1.0F, 0.1077859454596501F, 0.1077859454596501F);
        escalar(g0, "faro_t_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "cab_velocimetro", 0.2333333333333333F, 0.6F, 0.2333333333333333F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.574F, 0.6F);
        escalar(g0, "cab_manometro0", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro0_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_manometro1", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro1_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_freno", 0.8F, 0.8003905296791061F, 0.8F);
    }
}
