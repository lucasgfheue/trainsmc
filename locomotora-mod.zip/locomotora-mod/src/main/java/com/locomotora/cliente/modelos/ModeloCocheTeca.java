package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Coche de teca" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloCocheTeca {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("coche_teca"), "main"),
            LocomotoraMod.id("textures/entity/coche_teca.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -40.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -40.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -40.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -40.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -40.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -40.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 40.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 40.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 40.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 40.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 40.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 40.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloCocheTeca::crearCapa,
            16.0F,
            ModeloCocheTeca::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -48.0F, 48.0F)));

    private ModeloCocheTeca() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("caja", CubeListBuilder.create().texOffs(72, 106).addBox(-68.0F, -31.0F, 11.5F, 136.0F, 20.0F, 1.0F).texOffs(346, 106).addBox(-68.0F, -31.0F, -12.5F, 136.0F, 20.0F, 1.0F).texOffs(0, 82).addBox(-67.0F, -12.0F, -11.5F, 134.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_techo_0", CubeListBuilder.create().texOffs(568, 157).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -31.87323500715889F, -11.685937651840831F, -2.3211393658016495F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_1", CubeListBuilder.create().texOffs(0, 164).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.48902060796334F, -9.937072917989997F, -2.470312690854038F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_2", CubeListBuilder.create().texOffs(278, 164).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.82694425906593F, -7.967491422114678F, -2.6194860159064284F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_3", CubeListBuilder.create().texOffs(556, 164).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.857288741065695F, -5.820940417948506F, -2.7686593409588185F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_4", CubeListBuilder.create().texOffs(0, 168).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.557168612775506F, -3.545097907964653F, -2.917832666011209F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_5", CubeListBuilder.create().texOffs(278, 168).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.91103852997129F, -1.190513645981658F, -3.0670059910635965F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_6", CubeListBuilder.create().texOffs(556, 168).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.91103852997129F, 1.1905136459816565F, 3.067005991063599F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_7", CubeListBuilder.create().texOffs(0, 172).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.55716861277551F, 3.5450979079646503F, 2.9178326660112064F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_8", CubeListBuilder.create().texOffs(278, 172).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.857288741065695F, 5.820940417948506F, 2.7686593409588185F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_9", CubeListBuilder.create().texOffs(556, 172).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.82694425906593F, 7.967491422114676F, 2.619486015906428F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_10", CubeListBuilder.create().texOffs(0, 176).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.48902060796334F, 9.937072917989997F, 2.4703126908540387F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_11", CubeListBuilder.create().texOffs(278, 176).addBox(-68.0F, -1.0F, -1.5F, 136.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -31.87323500715889F, 11.685937651840831F, 2.3211393658016495F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_puntaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -26.0F, 0.0F, 1.0F, 26.0F, 23.0F), PartPose.offset(-68.0F, -11.0F, -11.5F));
        g.addOrReplaceChild("caja_puntab", CubeListBuilder.create().texOffs(48, 0).addBox(0.0F, -26.0F, 0.0F, 1.0F, 26.0F, 23.0F), PartPose.offset(67.0F, -11.0F, -11.5F));
        g.addOrReplaceChild("tabiques", CubeListBuilder.create().texOffs(96, 0).addBox(-60.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(144, 0).addBox(-45.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(192, 0).addBox(-30.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(240, 0).addBox(-15.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(288, 0).addBox(-0.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(336, 0).addBox(14.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(384, 0).addBox(29.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(432, 0).addBox(44.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(480, 0).addBox(59.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("bancos", CubeListBuilder.create().texOffs(764, 106).addBox(-59.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(314, 82).addBox(-60.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(792, 106).addBox(-59.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(338, 82).addBox(-60.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(820, 106).addBox(-49.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(362, 82).addBox(-46.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(848, 106).addBox(-49.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(386, 82).addBox(-46.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(876, 106).addBox(-44.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(410, 82).addBox(-45.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(904, 106).addBox(-44.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(434, 82).addBox(-45.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(932, 106).addBox(-34.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(458, 82).addBox(-31.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(960, 106).addBox(-34.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(482, 82).addBox(-31.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(988, 106).addBox(-29.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(506, 82).addBox(-30.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(0, 128).addBox(-29.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(530, 82).addBox(-30.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(28, 128).addBox(-19.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(554, 82).addBox(-16.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(56, 128).addBox(-19.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(578, 82).addBox(-16.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(84, 128).addBox(-14.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(602, 82).addBox(-15.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(112, 128).addBox(-14.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(626, 82).addBox(-15.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(140, 128).addBox(-4.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(650, 82).addBox(-1.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(168, 128).addBox(-4.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(674, 82).addBox(-1.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(196, 128).addBox(1.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(698, 82).addBox(0.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(224, 128).addBox(1.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(722, 82).addBox(0.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(252, 128).addBox(11.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(746, 82).addBox(14.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(280, 128).addBox(11.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(770, 82).addBox(14.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(308, 128).addBox(16.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(794, 82).addBox(15.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(336, 128).addBox(16.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(818, 82).addBox(15.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(364, 128).addBox(26.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(842, 82).addBox(29.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(392, 128).addBox(26.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(866, 82).addBox(29.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(420, 128).addBox(31.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(890, 82).addBox(30.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(448, 128).addBox(31.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(914, 82).addBox(30.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(476, 128).addBox(41.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(938, 82).addBox(44.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(504, 128).addBox(41.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(962, 82).addBox(44.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(532, 128).addBox(46.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(986, 82).addBox(45.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(560, 128).addBox(46.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(0, 106).addBox(45.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F).texOffs(588, 128).addBox(56.0F, -16.0F, -11.0F, 3.0F, 4.0F, 11.0F).texOffs(24, 106).addBox(59.0F, -23.0F, -11.0F, 1.0F, 11.0F, 11.0F).texOffs(616, 128).addBox(56.0F, -16.0F, 0.0F, 3.0F, 4.0F, 11.0F).texOffs(48, 106).addBox(59.0F, -23.0F, 0.0F, 1.0F, 11.0F, 11.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(618, 143).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(556, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(636, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 157).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-56.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(574, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(644, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(592, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(652, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(618, 143).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(556, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(636, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(418, 157).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-40.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(574, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(644, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-40.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(592, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(652, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-40.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(618, 143).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(556, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(636, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(428, 157).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-56.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(574, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(644, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(592, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(652, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(618, 143).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(556, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(636, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(438, 157).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-40.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(574, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(644, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-40.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(592, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(652, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-40.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(660, 143).addBox(-61.0F, -9.0F, 7.0F, 26.0F, 6.0F, 1.0F).texOffs(714, 143).addBox(-61.0F, -9.0F, -8.0F, 26.0F, 6.0F, 1.0F).texOffs(448, 157).addBox(-58.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(458, 157).addBox(-58.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(468, 157).addBox(-42.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(478, 157).addBox(-42.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_pivote", CubeListBuilder.create().texOffs(684, 106).addBox(-51.0F, -11.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(618, 143).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(556, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(636, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(488, 157).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(40.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(574, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(644, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(40.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(592, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(652, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(40.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(618, 143).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(556, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(636, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(498, 157).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(56.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(574, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(644, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(592, 176).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(652, 143).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(618, 143).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(556, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(636, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 157).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(40.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(574, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(644, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(40.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(592, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(652, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(40.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(618, 143).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(556, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(636, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(518, 157).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(56.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(574, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(644, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(592, 176).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(652, 143).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(768, 143).addBox(35.0F, -9.0F, 7.0F, 26.0F, 6.0F, 1.0F).texOffs(822, 143).addBox(35.0F, -9.0F, -8.0F, 26.0F, 6.0F, 1.0F).texOffs(528, 157).addBox(38.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(538, 157).addBox(38.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(548, 157).addBox(54.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(558, 157).addBox(54.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_pivote", CubeListBuilder.create().texOffs(724, 106).addBox(45.0F, -11.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bajo_piso", CubeListBuilder.create().texOffs(624, 49).addBox(-68.0F, -11.0F, -11.0F, 136.0F, 2.0F, 22.0F).texOffs(620, 106).addBox(-24.0F, -9.0F, -8.0F, 16.0F, 4.0F, 16.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuellei", CubeListBuilder.create().texOffs(472, 49).addBox(-70.0F, -30.0F, -6.0F, 2.0F, 18.0F, 12.0F).texOffs(528, 49).addBox(-70.0F, -12.0F, -11.0F, 2.0F, 4.0F, 22.0F).texOffs(610, 176).addBox(-72.0F, -11.5F, -0.5F, 2.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topefi_0", CubeListBuilder.create().texOffs(232, 49).addBox(-73.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(528, 0).addBox(-73.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, -8.0F));
        g.addOrReplaceChild("topefi_1", CubeListBuilder.create().texOffs(252, 49).addBox(-73.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(586, 0).addBox(-73.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefi_2", CubeListBuilder.create().texOffs(272, 49).addBox(-73.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(644, 0).addBox(-73.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_0", CubeListBuilder.create().texOffs(522, 143).addBox(-74.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(170, 143).addBox(-74.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, -8.0F));
        g.addOrReplaceChild("topefic_1", CubeListBuilder.create().texOffs(528, 143).addBox(-74.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(192, 143).addBox(-74.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_2", CubeListBuilder.create().texOffs(534, 143).addBox(-74.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(214, 143).addBox(-74.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_3", CubeListBuilder.create().texOffs(540, 143).addBox(-74.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(236, 143).addBox(-74.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_0", CubeListBuilder.create().texOffs(292, 49).addBox(-73.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(702, 0).addBox(-73.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, 8.0F));
        g.addOrReplaceChild("topefd_1", CubeListBuilder.create().texOffs(312, 49).addBox(-73.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(760, 0).addBox(-73.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_2", CubeListBuilder.create().texOffs(332, 49).addBox(-73.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(818, 0).addBox(-73.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_0", CubeListBuilder.create().texOffs(546, 143).addBox(-74.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(258, 143).addBox(-74.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, 8.0F));
        g.addOrReplaceChild("topefdc_1", CubeListBuilder.create().texOffs(552, 143).addBox(-74.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(280, 143).addBox(-74.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_2", CubeListBuilder.create().texOffs(558, 143).addBox(-74.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(302, 143).addBox(-74.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_3", CubeListBuilder.create().texOffs(564, 143).addBox(-74.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(324, 143).addBox(-74.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fuelled", CubeListBuilder.create().texOffs(500, 49).addBox(68.0F, -30.0F, -6.0F, 2.0F, 18.0F, 12.0F).texOffs(576, 49).addBox(68.0F, -12.0F, -11.0F, 2.0F, 4.0F, 22.0F).texOffs(616, 176).addBox(70.0F, -11.5F, -0.5F, 2.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topeti_0", CubeListBuilder.create().texOffs(352, 49).addBox(70.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(876, 0).addBox(70.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, -8.0F));
        g.addOrReplaceChild("topeti_1", CubeListBuilder.create().texOffs(372, 49).addBox(70.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(934, 0).addBox(70.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_2", CubeListBuilder.create().texOffs(392, 49).addBox(70.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(0, 49).addBox(70.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_0", CubeListBuilder.create().texOffs(570, 143).addBox(73.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(346, 143).addBox(73.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, -8.0F));
        g.addOrReplaceChild("topetic_1", CubeListBuilder.create().texOffs(576, 143).addBox(73.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(368, 143).addBox(73.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_2", CubeListBuilder.create().texOffs(582, 143).addBox(73.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(390, 143).addBox(73.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_3", CubeListBuilder.create().texOffs(588, 143).addBox(73.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(412, 143).addBox(73.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_0", CubeListBuilder.create().texOffs(412, 49).addBox(70.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(58, 49).addBox(70.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, 8.0F));
        g.addOrReplaceChild("topetd_1", CubeListBuilder.create().texOffs(432, 49).addBox(70.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(116, 49).addBox(70.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_2", CubeListBuilder.create().texOffs(452, 49).addBox(70.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(174, 49).addBox(70.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_0", CubeListBuilder.create().texOffs(594, 143).addBox(73.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(434, 143).addBox(73.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, 8.0F));
        g.addOrReplaceChild("topetdc_1", CubeListBuilder.create().texOffs(600, 143).addBox(73.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(456, 143).addBox(73.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_2", CubeListBuilder.create().texOffs(606, 143).addBox(73.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(478, 143).addBox(73.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_3", CubeListBuilder.create().texOffs(612, 143).addBox(73.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(500, 143).addBox(73.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent0_0", CubeListBuilder.create().texOffs(876, 143).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(644, 128).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-52.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent0_1", CubeListBuilder.create().texOffs(910, 143).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(678, 128).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-52.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent1_0", CubeListBuilder.create().texOffs(944, 143).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(712, 128).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-37.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent1_1", CubeListBuilder.create().texOffs(978, 143).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(746, 128).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-37.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent2_0", CubeListBuilder.create().texOffs(0, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(780, 128).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-22.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent2_1", CubeListBuilder.create().texOffs(34, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(814, 128).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-22.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent3_0", CubeListBuilder.create().texOffs(68, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(848, 128).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-7.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent3_1", CubeListBuilder.create().texOffs(102, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(882, 128).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-7.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent4_0", CubeListBuilder.create().texOffs(136, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(916, 128).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(7.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent4_1", CubeListBuilder.create().texOffs(170, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(950, 128).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(7.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent5_0", CubeListBuilder.create().texOffs(204, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(984, 128).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(22.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent5_1", CubeListBuilder.create().texOffs(238, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(0, 143).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(22.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent6_0", CubeListBuilder.create().texOffs(272, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(34, 143).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(37.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent6_1", CubeListBuilder.create().texOffs(306, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(68, 143).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(37.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("vent7_0", CubeListBuilder.create().texOffs(340, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(102, 143).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(52.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent7_1", CubeListBuilder.create().texOffs(374, 157).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(136, 143).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(52.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "caja_techo_0", 1.0001470588235295F, 1.0F, 0.8025552363150691F);
        escalar(g0, "caja_techo_1", 1.0001470588235295F, 1.0F, 0.8025552363150689F);
        escalar(g0, "caja_techo_2", 1.0001470588235295F, 1.0F, 0.8025552363150705F);
        escalar(g0, "caja_techo_3", 1.0001470588235295F, 1.0F, 0.8025552363150693F);
        escalar(g0, "caja_techo_4", 1.0001470588235295F, 1.0F, 0.8025552363150693F);
        escalar(g0, "caja_techo_5", 1.0001470588235295F, 1.0F, 0.8025552363150704F);
        escalar(g0, "caja_techo_6", 1.0001470588235295F, 1.0F, 0.8025552363150691F);
        escalar(g0, "caja_techo_7", 1.0001470588235295F, 1.0F, 0.8025552363150702F);
        escalar(g0, "caja_techo_8", 1.0001470588235295F, 1.0F, 0.8025552363150698F);
        escalar(g0, "caja_techo_9", 1.0001470588235295F, 1.0F, 0.8025552363150693F);
        escalar(g0, "caja_techo_10", 1.0001470588235295F, 1.0F, 0.8025552363150698F);
        escalar(g0, "caja_techo_11", 1.0001470588235295F, 1.0F, 0.8025552363150691F);
        escalar(g0, "topefi_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topeti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "vent0_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent0_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent1_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent1_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent2_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent2_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent3_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent3_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent4_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent4_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent5_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent5_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent6_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent6_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent7_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent7_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
    }
}
