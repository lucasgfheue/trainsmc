package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "JNR D51" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloD51 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("d51"), "main"),
            LocomotoraMod.id("textures/entity/d51.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -24.0F, -6.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -24.0F, -6.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -24.0F, -6.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -8.0F, -6.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -8.0F, -6.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -8.0F, -6.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 8.0F, -6.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 8.0F, -6.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 8.0F, -6.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi3_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 24.0F, -6.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi3_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 24.0F, -6.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi3_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 24.0F, -6.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 6.5F, 2.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_i", DatosModelo.MOTRIZ, 6.5F, 2.5F, 0.0F, -42.0F, 8.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_i", DatosModelo.CRUCETA, 6.5F, 2.5F, 0.0F, -42.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -24.0F, -6.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -24.0F, -6.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -24.0F, -6.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -6.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -6.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -6.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -6.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -6.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -6.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd3_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 24.0F, -6.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd3_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 24.0F, -6.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd3_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 24.0F, -6.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 6.5F, 2.5F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_d", DatosModelo.MOTRIZ, 6.5F, 2.5F, 1.5707963267948966F, -42.0F, 8.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_d", DatosModelo.CRUCETA, 6.5F, 2.5F, 1.5707963267948966F, -42.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -58.0F, -4.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -58.0F, -4.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -58.0F, -4.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -58.0F, -4.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -58.0F, -4.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -58.0F, -4.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 32.72F, -33.6F, 0.0F, "locomotora", 4.8F, -2.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.0F, 0.0F, 37.0F, -21.0F, 0.0F, "locomotora", -0.22F, -8.0F, 0.0F),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 66.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 66.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 66.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 66.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 66.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 66.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 1.0471975511965976F, "tender")),
            ModeloD51::crearCapa,
            16.0F,
            ModeloD51::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -58.0F, 44.0F),
                new DatosModelo.Segmento("tender", 72.0F, 110.0F)));

    private ModeloD51() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        piezas5(g1);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
        escalas2(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(0, 148).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(158, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(668, 185).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(184, 215).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-24.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(188, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(218, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(0, 148).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(158, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 185).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(190, 215).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-8.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(188, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(218, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(0, 148).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(158, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(688, 185).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(196, 215).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(8.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(188, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(218, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi3_0", CubeListBuilder.create().texOffs(0, 148).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(158, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(698, 185).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(202, 215).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(24.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmi3_1", CubeListBuilder.create().texOffs(188, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi3_2", CubeListBuilder.create().texOffs(218, 185).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 148).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(600, 220).addBox(-24.0F, -9.5F, -7.5F, 48.0F, 1.0F, 1.0F).texOffs(464, 211).addBox(-25.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(472, 211).addBox(-9.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(480, 211).addBox(6.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(488, 211).addBox(22.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_i", CubeListBuilder.create().texOffs(796, 220).addBox(-42.0F, -0.5F, -0.5F, 42.0F, 1.0F, 1.0F).texOffs(496, 211).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(8.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("cruceta_i", CubeListBuilder.create().texOffs(708, 185).addBox(-35.425529215503055F, -8.0F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(152, 222).addBox(-43.925529215503055F, -7.0F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_i", CubeListBuilder.create().texOffs(968, 220).addBox(-40.425529215503055F, -5.0F, -9.0F, 13.0F, 1.0F, 1.0F).texOffs(996, 220).addBox(-40.425529215503055F, -9.0F, -9.0F, 13.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_i_0", CubeListBuilder.create().texOffs(740, 148).addBox(-52.425529215503055F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(388, 148).addBox(-52.425529215503055F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, -8.5F));
        g.addOrReplaceChild("cil_i_1", CubeListBuilder.create().texOffs(768, 148).addBox(-52.425529215503055F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(432, 148).addBox(-52.425529215503055F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_2", CubeListBuilder.create().texOffs(796, 148).addBox(-52.425529215503055F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(476, 148).addBox(-52.425529215503055F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_3", CubeListBuilder.create().texOffs(824, 148).addBox(-52.425529215503055F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(520, 148).addBox(-52.425529215503055F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_0", CubeListBuilder.create().texOffs(574, 163).addBox(-52.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(176, 163).addBox(-52.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, -8.5F));
        g.addOrReplaceChild("cil_i_a_1", CubeListBuilder.create().texOffs(580, 163).addBox(-52.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(198, 163).addBox(-52.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_2", CubeListBuilder.create().texOffs(586, 163).addBox(-52.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(220, 163).addBox(-52.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_3", CubeListBuilder.create().texOffs(592, 163).addBox(-52.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(242, 163).addBox(-52.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_0", CubeListBuilder.create().texOffs(598, 163).addBox(-40.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(264, 163).addBox(-40.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, -8.5F));
        g.addOrReplaceChild("cil_i_b_1", CubeListBuilder.create().texOffs(604, 163).addBox(-40.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(286, 163).addBox(-40.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_2", CubeListBuilder.create().texOffs(610, 163).addBox(-40.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(308, 163).addBox(-40.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_3", CubeListBuilder.create().texOffs(616, 163).addBox(-40.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(330, 163).addBox(-40.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(0, 148).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(158, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(718, 185).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(208, 215).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-24.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(188, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(218, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(0, 148).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(158, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(728, 185).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(214, 215).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-8.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(188, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(218, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(0, 148).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(158, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(738, 185).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(220, 215).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(8.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(188, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(218, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd3_0", CubeListBuilder.create().texOffs(0, 148).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(158, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(748, 185).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(226, 215).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(24.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmd3_1", CubeListBuilder.create().texOffs(188, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd3_2", CubeListBuilder.create().texOffs(218, 185).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 148).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(698, 220).addBox(-24.0F, -9.5F, 6.5F, 48.0F, 1.0F, 1.0F).texOffs(504, 211).addBox(-25.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(512, 211).addBox(-9.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(520, 211).addBox(6.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(528, 211).addBox(22.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_d", CubeListBuilder.create().texOffs(882, 220).addBox(-42.0F, -0.5F, -0.5F, 42.0F, 1.0F, 1.0F).texOffs(536, 211).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(8.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("cruceta_d", CubeListBuilder.create().texOffs(758, 185).addBox(-35.425529215503055F, -8.0F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(174, 222).addBox(-43.925529215503055F, -7.0F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_d", CubeListBuilder.create().texOffs(0, 222).addBox(-40.425529215503055F, -5.0F, 8.0F, 13.0F, 1.0F, 1.0F).texOffs(28, 222).addBox(-40.425529215503055F, -9.0F, 8.0F, 13.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_d_0", CubeListBuilder.create().texOffs(852, 148).addBox(-52.425529215503055F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(564, 148).addBox(-52.425529215503055F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, 8.5F));
        g.addOrReplaceChild("cil_d_1", CubeListBuilder.create().texOffs(880, 148).addBox(-52.425529215503055F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(608, 148).addBox(-52.425529215503055F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_2", CubeListBuilder.create().texOffs(908, 148).addBox(-52.425529215503055F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(652, 148).addBox(-52.425529215503055F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_3", CubeListBuilder.create().texOffs(936, 148).addBox(-52.425529215503055F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(696, 148).addBox(-52.425529215503055F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_0", CubeListBuilder.create().texOffs(622, 163).addBox(-52.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(352, 163).addBox(-52.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, 8.5F));
        g.addOrReplaceChild("cil_d_a_1", CubeListBuilder.create().texOffs(628, 163).addBox(-52.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(374, 163).addBox(-52.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_2", CubeListBuilder.create().texOffs(634, 163).addBox(-52.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(396, 163).addBox(-52.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_3", CubeListBuilder.create().texOffs(640, 163).addBox(-52.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(418, 163).addBox(-52.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_0", CubeListBuilder.create().texOffs(646, 163).addBox(-40.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(440, 163).addBox(-40.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, 8.5F));
        g.addOrReplaceChild("cil_d_b_1", CubeListBuilder.create().texOffs(652, 163).addBox(-40.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(462, 163).addBox(-40.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_2", CubeListBuilder.create().texOffs(658, 163).addBox(-40.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(484, 163).addBox(-40.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_3", CubeListBuilder.create().texOffs(664, 163).addBox(-40.925529215503055F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(506, 163).addBox(-40.925529215503055F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rbi0_0", CubeListBuilder.create().texOffs(142, 175).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(866, 207).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(182, 175).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(768, 185).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-58.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rbi0_1", CubeListBuilder.create().texOffs(886, 207).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(190, 175).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi0_2", CubeListBuilder.create().texOffs(906, 207).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(198, 175).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd0_0", CubeListBuilder.create().texOffs(142, 175).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(866, 207).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(182, 175).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(778, 185).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-58.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rbd0_1", CubeListBuilder.create().texOffs(886, 207).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(190, 175).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd0_2", CubeListBuilder.create().texOffs(906, 207).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(198, 175).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(56, 163).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(248, 185).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(544, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(788, 185).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(272, 185).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(554, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(296, 185).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(564, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(56, 163).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(248, 185).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(544, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(798, 185).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(272, 185).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(554, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(296, 185).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(564, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(80, 131).addBox(-64.0F, -19.0F, 2.0F, 116.0F, 15.0F, 1.0F).texOffs(314, 131).addBox(-64.0F, -19.0F, -3.0F, 116.0F, 15.0F, 1.0F).texOffs(866, 62).addBox(-66.0F, -14.0F, -11.0F, 3.0F, 6.0F, 22.0F).texOffs(364, 105).addBox(-66.0F, -14.0F, -11.0F, 3.0F, 1.0F, 22.0F).texOffs(126, 185).addBox(-70.0F, -12.0F, -1.5F, 4.0F, 3.0F, 3.0F).texOffs(0, 105).addBox(-63.0F, -20.0F, -12.5F, 93.0F, 1.0F, 25.0F).texOffs(258, 215).addBox(-63.0F, -20.0F, 11.6F, 93.0F, 1.0F, 1.0F).texOffs(446, 215).addBox(-63.0F, -20.0F, -12.6F, 93.0F, 1.0F, 1.0F).texOffs(916, 62).addBox(24.0F, -30.0F, -9.0F, 6.0F, 10.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_humo_0", CubeListBuilder.create().texOffs(312, 62).addBox(-56.0F, -19.0F, -2.5F, 14.0F, 38.0F, 5.0F).texOffs(646, 0).addBox(-56.0F, -2.5F, -19.0F, 14.0F, 5.0F, 38.0F), PartPose.offset(0.0F, -28.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_1", CubeListBuilder.create().texOffs(350, 62).addBox(-56.0F, -19.0F, -2.5F, 14.0F, 38.0F, 5.0F).texOffs(750, 0).addBox(-56.0F, -2.5F, -19.0F, 14.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -28.0F, 0.0F, 0.2617993877991494F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_2", CubeListBuilder.create().texOffs(388, 62).addBox(-56.0F, -19.0F, -2.5F, 14.0F, 38.0F, 5.0F).texOffs(854, 0).addBox(-56.0F, -2.5F, -19.0F, 14.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -28.0F, 0.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_3", CubeListBuilder.create().texOffs(426, 62).addBox(-56.0F, -19.0F, -2.5F, 14.0F, 38.0F, 5.0F).texOffs(0, 62).addBox(-56.0F, -2.5F, -19.0F, 14.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -28.0F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_4", CubeListBuilder.create().texOffs(464, 62).addBox(-56.0F, -19.0F, -2.5F, 14.0F, 38.0F, 5.0F).texOffs(104, 62).addBox(-56.0F, -2.5F, -19.0F, 14.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -28.0F, 0.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_5", CubeListBuilder.create().texOffs(502, 62).addBox(-56.0F, -19.0F, -2.5F, 14.0F, 38.0F, 5.0F).texOffs(208, 62).addBox(-56.0F, -2.5F, -19.0F, 14.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -28.0F, 0.0F, 1.3089969389957472F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta", CubeListBuilder.create().texOffs(0, 0).addBox(-30.5F, 0.0F, -30.5F, 61.0F, 1.0F, 61.0F), PartPose.offsetAndRotation(-56.1F, -28.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("placa_frente", CubeListBuilder.create().texOffs(704, 62).addBox(0.0F, -7.0F, 0.0F, 1.0F, 7.0F, 30.0F), PartPose.offset(-57.0F, -26.0F, -7.5F));
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(520, 191).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -36.30603661607131F, 1.09351046555815F, 3.0106949226825006F, -0.0007189309483729018F, -0.005460850789898393F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(564, 191).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -36.404332907385765F, 1.1064514178132763F, 3.0106949226825006F, -0.0007189309483729142F, -0.005460850789898393F));
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(608, 191).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -36.50262919870022F, 1.1193923700684025F, 3.010694922682499F, -0.0007189309483729018F, -0.005460850789898195F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(652, 191).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -36.600925490014674F, 1.1323333223235283F, 3.0106949226825006F, -0.0007189309483728894F, -0.005460850789898393F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(696, 191).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -35.73999394706057F, 3.2060104655581494F, 2.748898934896245F, -0.002107800268266447F, -0.005088709492432361F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(740, 191).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -35.831591508564244F, 3.2439514178132764F, 2.748898934896244F, -0.002107800268266484F, -0.005088709492432361F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(784, 191).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -35.92318907006792F, 3.281892370068402F, 2.748898934896245F, -0.002107800268266447F, -0.005088709492432163F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(828, 191).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -36.014786631571596F, 3.319833322323528F, 2.748898934896244F, -0.0021078002682664346F, -0.005088709492432558F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(872, 191).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -34.646483481502415F, 5.1000261505131625F, 2.4871015101181375F, -0.003353029812859318F, -0.004369783811017516F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(916, 191).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -34.72514009075097F, 5.16038148957249F, 2.4871015101181375F, -0.0033530298128593675F, -0.004369783811017713F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(960, 191).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -34.803796699999516F, 5.220736828631818F, 2.4871015101181375F, -0.003353029812859318F, -0.004369783811017516F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(0, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -34.88245330924806F, 5.2810921676911455F, 2.487101510118138F, -0.003353029812859318F, -0.004369783811017713F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(44, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -33.100026150513166F, 6.646483481502416F, 2.2253021223477507F, -0.004369759246562085F, -0.003353061825943736F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(88, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -33.160381489572494F, 6.725140090750966F, 2.225302122347751F, -0.004369759246562134F, -0.003353061825944131F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(132, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -33.22073682863182F, 6.803796699999516F, 2.2253021223477516F, -0.00436975924656206F, -0.003353061825943736F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(176, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -33.28109216769114F, 6.882453309248065F, 2.2253021223477507F, -0.00436975924656206F, -0.0033530618259439335F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(220, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -31.20601046555815F, 7.739993947060567F, 1.9635007715563202F, -0.005088698188223827F, -0.0021078275591863817F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(264, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -31.24395141781328F, 7.831591508564243F, 1.9635007715563202F, -0.0050886981882238514F, -0.00210782755918648F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(308, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -31.2818923700684F, 7.923189070067918F, 1.9635007715563197F, -0.005088698188223753F, -0.0021078275591863817F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(352, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -31.319833322323532F, 8.014786631571594F, 1.9635007715563206F, -0.005088698188223753F, -0.0021078275591863817F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(396, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -29.09351046555815F, 8.306036616071314F, 1.701697983715515F, -0.005460849378632041F, -0.000718941668083291F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(440, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -29.106451417813275F, 8.404332907385768F, 1.7016979837155148F, -0.00546084937863209F, -0.0007189416680831924F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(484, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -29.119392370068404F, 8.502629198700221F, 1.701697983715515F, -0.0054608493786319915F, -0.000718941668083291F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(528, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -29.13233332232353F, 8.600925490014674F, 1.701697983715515F, -0.0054608493786319915F, -0.000718941668083291F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(572, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -26.906489534441853F, 8.306036616071314F, 1.439894669874279F, -0.0054608493786319915F, 0.0007189416680831924F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(616, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -26.893548582186725F, 8.404332907385768F, 1.439894669874279F, -0.00546084937863209F, 0.000718941668083291F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(660, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -26.8806076299316F, 8.502629198700223F, 1.439894669874279F, -0.0054608493786319915F, 0.000718941668083291F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(704, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -26.867666677676475F, 8.600925490014674F, 1.4398946698742787F, -0.0054608493786319915F, 0.0007189416680831924F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(748, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -24.79398953444185F, 7.739993947060569F, 1.178091882033473F, -0.005088698188223778F, 0.0021078275591863817F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(792, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -24.756048582186725F, 7.8315915085642445F, 1.1780918820334731F, -0.0050886981882238514F, 0.0021078275591863817F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(836, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -24.718107629931602F, 7.92318907006792F, 1.1780918820334727F, -0.005088698188223753F, 0.00210782755918648F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(880, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -24.680166677676475F, 8.014786631571594F, 1.178091882033473F, -0.005088698188223753F, 0.0021078275591863817F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(924, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -22.89997384948684F, 6.6464834815024165F, 0.9162905312420424F, -0.004369759246562085F, 0.0033530618259439335F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(968, 195).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -22.839618510427506F, 6.725140090750967F, 0.9162905312420428F, -0.004369759246562134F, 0.0033530618259439335F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(0, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -22.779263171368182F, 6.803796699999517F, 0.9162905312420431F, -0.00436975924656206F, 0.003353061825943835F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(44, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -22.718907832308854F, 6.882453309248066F, 0.9162905312420431F, -0.00436975924656206F, 0.0033530618259440324F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(88, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -21.353516518497585F, 5.100026150513165F, 0.6544911434716559F, -0.003353029812859318F, 0.0043697838110176145F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(132, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -21.27485990924903F, 5.160381489572493F, 0.6544911434716552F, -0.0033530298128593675F, 0.004369783811017713F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(176, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -21.196203300000484F, 5.22073682863182F, 0.6544911434716557F, -0.003353029812859318F, 0.0043697838110176145F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(220, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -21.117546690751933F, 5.281092167691147F, 0.6544911434716563F, -0.003353029812859318F, 0.004369783811017713F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(264, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -20.26000605293943F, 3.206010465558153F, 0.39269371869354963F, -0.002107800268266447F, 0.005088709492432361F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(308, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -20.168408491435756F, 3.2439514178132787F, 0.39269371869355035F, -0.002107800268266484F, 0.005088709492432361F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(352, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -20.07681092993208F, 3.2818923700684053F, 0.39269371869354963F, -0.002107800268266447F, 0.005088709492432361F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(396, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -19.985213368428404F, 3.3198333223235315F, 0.3926937186935481F, -0.002107800268266447F, 0.005088709492432262F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(440, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -19.693963383928686F, 1.0935104655581516F, 0.13089773090729243F, -0.0007189309483729022F, 0.005460850789898393F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(484, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -19.59566709261423F, 1.1064514178132778F, 0.13089773090729254F, -0.0007189309483729145F, 0.005460850789898393F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(528, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -19.497370801299777F, 1.119392370068404F, 0.13089773090729342F, -0.0007189309483729022F, 0.005460850789898294F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(572, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -19.399074509985326F, 1.13233332232353F, 0.13089773090729426F, -0.0007189309483729022F, 0.005460850789898195F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(616, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -19.693963383928686F, -1.0935104655581482F, -0.13089773090729265F, 0.0007189309483729015F, 0.005460850789898393F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(660, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -19.59566709261423F, -1.106451417813274F, -0.1308977309072928F, 0.0007189309483729015F, 0.005460850789898393F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(704, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -19.497370801299777F, -1.1193923700684003F, -0.13089773090729284F, 0.0007189309483729015F, 0.005460850789898393F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(748, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -19.399074509985322F, -1.1323333223235261F, -0.13089773090729298F, 0.0007189309483729015F, 0.005460850789898195F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(792, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -20.26000605293943F, -3.2060104655581463F, -0.39269371869354863F, 0.002107800268266447F, 0.005088709492432361F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(836, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -20.168408491435756F, -3.243951417813272F, -0.3926937186935485F, 0.002107800268266472F, 0.005088709492432459F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(880, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -20.07681092993208F, -3.281892370068398F, -0.39269371869354847F, 0.002107800268266447F, 0.005088709492432361F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(924, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -19.985213368428404F, -3.3198333223235243F, -0.3926937186935485F, 0.002107800268266447F, 0.005088709492432262F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(968, 199).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -21.35351651849758F, -5.100026150513161F, -0.654491143471654F, 0.003353029812859318F, 0.0043697838110176145F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(0, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -21.27485990924903F, -5.160381489572488F, -0.6544911434716546F, 0.0033530298128593675F, 0.004369783811017713F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(44, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -21.19620330000048F, -5.220736828631816F, -0.6544911434716552F, 0.003353029812859318F, 0.0043697838110176145F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(88, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -21.117546690751933F, -5.281092167691144F, -0.6544911434716549F, 0.003353029812859318F, 0.0043697838110176145F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(132, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -22.899973849486834F, -6.646483481502415F, -0.9162905312420432F, 0.00436975924656206F, 0.0033530618259439335F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(176, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -22.839618510427506F, -6.725140090750965F, -0.9162905312420428F, 0.004369759246562134F, 0.0033530618259439335F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(220, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -22.77926317136818F, -6.8037966999995145F, -0.9162905312420425F, 0.004369759246562085F, 0.0033530618259439335F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(264, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -22.71890783230885F, -6.882453309248064F, -0.9162905312420422F, 0.00436975924656206F, 0.0033530618259439335F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(308, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -24.793989534441845F, -7.739993947060564F, -1.1780918820334723F, 0.005088698188223753F, 0.00210782755918648F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(352, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -24.756048582186718F, -7.83159150856424F, -1.178091882033472F, 0.0050886981882238514F, 0.00210782755918648F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(396, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -24.718107629931595F, -7.923189070067917F, -1.1780918820334727F, 0.005088698188223778F, 0.0021078275591863817F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(440, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -24.680166677676468F, -8.014786631571592F, -1.178091882033473F, 0.005088698188223753F, 0.00210782755918648F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(484, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -26.906489534441846F, -8.306036616071314F, -1.439894669874278F, 0.0054608493786319915F, 0.000718941668083291F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(528, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -26.89354858218672F, -8.404332907385767F, -1.4398946698742778F, 0.00546084937863209F, 0.000718941668083291F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(572, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -26.880607629931596F, -8.502629198700221F, -1.4398946698742778F, 0.0054608493786319915F, 0.0007189416680831924F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(616, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -26.867666677676468F, -8.600925490014674F, -1.4398946698742776F, 0.0054608493786319915F, 0.000718941668083291F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(660, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -29.093510465558147F, -8.306036616071314F, -1.7016979837155142F, 0.0054608493786319915F, -0.0007189416680831924F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(704, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -29.106451417813275F, -8.404332907385768F, -1.7016979837155144F, 0.00546084937863209F, -0.000718941668083291F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(748, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -29.1193923700684F, -8.502629198700223F, -1.7016979837155144F, 0.0054608493786319915F, -0.0007189416680831924F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(792, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -29.132333322323525F, -8.600925490014674F, -1.7016979837155146F, 0.0054608493786319915F, -0.000718941668083291F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(836, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -31.206010465558144F, -7.73999394706057F, -1.96350077155632F, 0.005088698188223753F, -0.002107827559186283F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(880, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -31.24395141781327F, -7.831591508564245F, -1.9635007715563197F, 0.0050886981882238514F, -0.002107827559186579F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(924, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -31.281892370068398F, -7.923189070067921F, -1.9635007715563195F, 0.005088698188223753F, -0.002107827559186283F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(968, 203).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -31.31983332232352F, -8.014786631571596F, -1.9635007715563197F, 0.005088698188223753F, -0.0021078275591863817F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(0, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -33.10002615051316F, -6.646483481502419F, -2.22530212234775F, 0.00436975924656206F, -0.003353061825943736F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(44, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -33.16038148957249F, -6.725140090750969F, -2.22530212234775F, 0.004369759246562134F, -0.003353061825944131F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(88, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -33.220736828631814F, -6.803796699999519F, -2.2253021223477503F, 0.00436975924656206F, -0.003353061825943736F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(132, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -33.28109216769114F, -6.882453309248068F, -2.2253021223477494F, 0.00436975924656206F, -0.0033530618259439335F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(176, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -34.646483481502415F, -5.100026150513166F, -2.4871015101181393F, 0.003353029812859318F, -0.004369783811017516F));
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(220, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -34.72514009075097F, -5.160381489572494F, -2.487101510118138F, 0.0033530298128593675F, -0.004369783811017911F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(264, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -34.803796699999516F, -5.220736828631821F, -2.487101510118137F, 0.003353029812859318F, -0.004369783811017516F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(308, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -34.88245330924806F, -5.281092167691149F, -2.487101510118137F, 0.003353029812859318F, -0.004369783811017713F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(352, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -35.73999394706057F, -3.2060104655581556F, -2.7488989348962427F, 0.002107800268266447F, -0.005088709492432163F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(396, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -35.831591508564244F, -3.243951417813282F, -2.7488989348962436F, 0.002107800268266484F, -0.0050887094924327555F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(440, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -35.92318907006792F, -3.2818923700684084F, -2.7488989348962445F, 0.002107800268266447F, -0.005088709492432163F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(484, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -36.014786631571596F, -3.319833322323534F, -2.7488989348962454F, 0.002107800268266447F, -0.005088709492432361F));
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(528, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.0F, -36.30603661607131F, -1.0935104655581547F, -3.0106949226824993F, 0.0007189309483729025F, -0.005460850789898195F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(572, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.0F, -36.404332907385765F, -1.1064514178132807F, -3.0106949226824993F, 0.0007189309483729148F, -0.00546085078989859F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(616, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.0F, -36.50262919870022F, -1.119392370068407F, -3.0106949226824993F, 0.0007189309483729025F, -0.005460850789898195F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(660, 207).addBox(-9.5F, -1.0F, -1.5F, 19.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.0F, -36.600925490014674F, -1.132333322323533F, -3.0106949226824993F, 0.0007189309483729025F, -0.005460850789898195F));
        g.addOrReplaceChild("chimenea_0", CubeListBuilder.create().texOffs(828, 175).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(292, 148).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offset(-47.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_1", CubeListBuilder.create().texOffs(852, 175).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(316, 148).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-47.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_2", CubeListBuilder.create().texOffs(876, 175).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(340, 148).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-47.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_3", CubeListBuilder.create().texOffs(900, 175).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(364, 148).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-47.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea_labio_0", CubeListBuilder.create().texOffs(556, 211).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(670, 163).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(-47.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_labio_1", CubeListBuilder.create().texOffs(580, 211).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(694, 163).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-47.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_labio_2", CubeListBuilder.create().texOffs(604, 211).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(718, 163).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-47.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("chimenea_labio_3", CubeListBuilder.create().texOffs(628, 211).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(742, 163).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-47.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("calentador_0", CubeListBuilder.create().texOffs(752, 131).addBox(-5.0F, -1.0F, -6.5F, 10.0F, 2.0F, 13.0F).texOffs(414, 105).addBox(-1.0F, -5.0F, -6.5F, 2.0F, 10.0F, 13.0F), PartPose.offset(-52.5F, -38.0F, 0.0F));
        g.addOrReplaceChild("calentador_1", CubeListBuilder.create().texOffs(798, 131).addBox(-5.0F, -1.0F, -6.5F, 10.0F, 2.0F, 13.0F).texOffs(444, 105).addBox(-1.0F, -5.0F, -6.5F, 2.0F, 10.0F, 13.0F), PartPose.offsetAndRotation(-52.5F, -38.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("calentador_2", CubeListBuilder.create().texOffs(844, 131).addBox(-5.0F, -1.0F, -6.5F, 10.0F, 2.0F, 13.0F).texOffs(474, 105).addBox(-1.0F, -5.0F, -6.5F, 2.0F, 10.0F, 13.0F), PartPose.offsetAndRotation(-52.5F, -38.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("calentador_3", CubeListBuilder.create().texOffs(890, 131).addBox(-5.0F, -1.0F, -6.5F, 10.0F, 2.0F, 13.0F).texOffs(504, 105).addBox(-1.0F, -5.0F, -6.5F, 2.0F, 10.0F, 13.0F), PartPose.offsetAndRotation(-52.5F, -38.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("faro_0", CubeListBuilder.create().texOffs(704, 207).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(80, 163).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-55.2F, -41.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_1", CubeListBuilder.create().texOffs(728, 207).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(104, 163).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-55.2F, -41.5F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_2", CubeListBuilder.create().texOffs(752, 207).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(128, 163).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-55.2F, -41.5F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_3", CubeListBuilder.create().texOffs(776, 207).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(152, 163).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-55.2F, -41.5F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_vidrio", CubeListBuilder.create().texOffs(548, 131).addBox(-7.5F, 0.0F, -7.5F, 15.0F, 1.0F, 15.0F), PartPose.offsetAndRotation(-56.620000000000005F, -41.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_base", CubeListBuilder.create().texOffs(320, 185).addBox(-56.0F, -41.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("domo_0", CubeListBuilder.create().texOffs(924, 175).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.3322741961776985F, -35.84788507991347F, 1.0035693259601124F, 0.12253322271824801F, 0.022647106738135726F, -1.8054017250907821F));
        g.addOrReplaceChild("domo_1", CubeListBuilder.create().texOffs(412, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.140510126495438F, -37.28375802365976F, 0.948269629289048F, 0.08789065014734956F, 0.06963934839336978F, -2.368508509657295F));
        g.addOrReplaceChild("domo_2", CubeListBuilder.create().texOffs(340, 185).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-3.737580101915312F, -38.33051865188429F, 0.8389977175980354F, 0.05294082896689636F, 0.08817504201545635F, -2.70711231415057F));
        g.addOrReplaceChild("domo_3", CubeListBuilder.create().texOffs(926, 207).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.094295212867374F, -39.122898780595506F, 0.6777507030975436F, 0.02989675689867236F, 0.06636502305783136F, -2.9018047572938688F));
        g.addOrReplaceChild("domo_4", CubeListBuilder.create().texOffs(652, 211).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.207594626494535F, -39.659869289590446F, 0.46473800870755F, 0.014539919229737788F, 0.06785792231940581F, -3.0258258203202835F));
        g.addOrReplaceChild("domo_5", CubeListBuilder.create().texOffs(56, 222).addBox(-5.5F, -1.0F, -0.5F, 11.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.478200793054258F, -39.93161621713294F, 0.1725421080384375F, 0.003412133142542134F, 0.06828874848915553F, -3.1144822363895357F));
        g.addOrReplaceChild("domo_6", CubeListBuilder.create().texOffs(240, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.845619499541165F, -35.84788507991347F, 2.3984410336978135F, 0.7647744860810345F, 0.08571121118830176F, -1.7527300392675818F));
        g.addOrReplaceChild("domo_7", CubeListBuilder.create().texOffs(254, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.6255685553708297F, -37.28375802365976F, 2.266279698933986F, 0.601799614634621F, 0.2932441271048017F, -2.233603771597459F));
        g.addOrReplaceChild("domo_8", CubeListBuilder.create().texOffs(128, 215).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.1667438145961215F, -38.33051865188429F, 2.005129591959966F, 0.362956263091607F, 0.15164015324114713F, -2.6947736888068112F));
        g.addOrReplaceChild("domo_9", CubeListBuilder.create().texOffs(948, 211).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.440977929533268F, -39.122898780595506F, 1.6197636325438078F, 0.20918899266762606F, 0.1628048974263348F, -2.893455046891101F));
        g.addOrReplaceChild("domo_10", CubeListBuilder.create().texOffs(732, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.445317191237404F, -39.659869289590446F, 1.1106823227551519F, 0.1024383003307874F, 0.16667093751282072F, -3.021666684964924F));
        g.addOrReplaceChild("domo_11", CubeListBuilder.create().texOffs(268, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.8954533800727855F, -35.84788507991347F, 3.0536630670953713F, 1.181376051481209F, 0.0827068828481217F, -1.6997773918962487F));
        g.addOrReplaceChild("domo_12", CubeListBuilder.create().texOffs(282, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-3.617553422738498F, -37.28375802365976F, 2.8853970221119303F, 1.0374131460576748F, 0.3173800216429449F, -2.0540571221606667F));
        g.addOrReplaceChild("domo_13", CubeListBuilder.create().texOffs(998, 207).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-5.044419334202553F, -38.33051865188429F, 2.552904196384598F, 0.7835615591260823F, 0.5127170466317307F, -2.3715594549006944F));
        g.addOrReplaceChild("domo_14", CubeListBuilder.create().texOffs(964, 211).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-7.149972945881753F, -39.122898780595506F, 2.062261407568318F, 0.41472537846758417F, 0.22108527804648687F, -2.8744762025305994F));
        g.addOrReplaceChild("domo_15", CubeListBuilder.create().texOffs(750, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.931479626149626F, -39.659869289590446F, 1.4141058882085622F, 0.20826509285507236F, 0.22708825303235297F, -3.012162192487791F));
        g.addOrReplaceChild("domo_16", CubeListBuilder.create().texOffs(196, 222).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.746955750638307F, -39.93161621713294F, 0.5250115255681874F, 0.049363929962288215F, 0.22883603199526392F, -3.1112502422132082F));
        g.addOrReplaceChild("domo_17", CubeListBuilder.create().texOffs(942, 175).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-4.548763498392354F, -35.84788507991347F, 3.4945457653139234F, 1.3864037108160736F, 0.07211119301206394F, -1.6713090905120755F));
        g.addOrReplaceChild("domo_18", CubeListBuilder.create().texOffs(428, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.17976116708026F, -37.28375802365976F, 3.3019857539364F, 1.2817112657263958F, 0.2866636208758605F, -1.9502943335479395F));
        g.addOrReplaceChild("domo_19", CubeListBuilder.create().texOffs(444, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.426609263557756F, -38.33051865188429F, 2.9214881775459856F, 1.0663174401361606F, 0.5029499500285053F, -2.208485359434987F));
        g.addOrReplaceChild("domo_20", CubeListBuilder.create().texOffs(0, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.266519721618806F, -39.122898780595506F, 2.3600072144315325F, 0.7718667382146159F, 0.683688762982148F, -2.475181280849842F));
        g.addOrReplaceChild("domo_21", CubeListBuilder.create().texOffs(980, 211).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.69710291921789F, -39.659869289590446F, 1.618272099693433F, 0.31186384016487967F, 0.29314182332207595F, -2.993729669123845F));
        g.addOrReplaceChild("domo_22", CubeListBuilder.create().texOffs(284, 222).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-14.031206779119296F, -39.93161621713294F, 0.6008117998297849F, 0.07490320426557327F, 0.2960226386718122F, -3.1068727542616745F));
        g.addOrReplaceChild("domo_23", CubeListBuilder.create().texOffs(662, 175).addBox(-2.0F, -1.0F, -3.0F, 4.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-7.005846123633196F, -35.84788507991347F, 3.7745014667890224F, 1.495677416111617F, 0.06645048915795337F, -1.646359378188695F));
        g.addOrReplaceChild("domo_24", CubeListBuilder.create().texOffs(742, 175).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-7.50145112899755F, -37.28375802365976F, 3.5665150519011117F, 1.4205669812064887F, 0.26857696763629496F, -1.8658253840773698F));
        g.addOrReplaceChild("domo_25", CubeListBuilder.create().texOffs(960, 175).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-8.480764030150125F, -38.33051865188429F, 3.1555349827743675F, 1.2468492583810897F, 0.4884427693209944F, -2.0842625245062796F));
        g.addOrReplaceChild("domo_26", CubeListBuilder.create().texOffs(460, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.925886377960719F, -39.122898780595506F, 2.5490725521244615F, 0.9725110378367597F, 0.7025030431414123F, -2.3258510076339403F));
        g.addOrReplaceChild("domo_27", CubeListBuilder.create().texOffs(16, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.834941289668176F, -39.659869289590446F, 1.7479154156700254F, 0.5925118433419606F, 0.8680921513971498F, -2.639865850779701F));
        g.addOrReplaceChild("domo_28", CubeListBuilder.create().texOffs(768, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.453649160345009F, -39.93161621713294F, 0.6489441466845283F, 0.09764793494343087F, 0.3969918962982962F, -3.097398764855674F));
        g.addOrReplaceChild("domo_29", CubeListBuilder.create().texOffs(932, 105).addBox(-2.0F, -1.0F, -8.0F, 4.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-12.236614969763922F, -35.84788507991347F, 3.911393547685947F, 1.5617701474755836F, 0.06442720982123024F, -1.5713774718344107F));
        g.addOrReplaceChild("domo_30", CubeListBuilder.create().texOffs(608, 131).addBox(-1.5F, -1.0F, -7.5F, 3.0F, 1.0F, 15.0F), PartPose.offsetAndRotation(-12.443988835470087F, -37.28375802365976F, 3.6958639662678836F, 1.5614504850403703F, 0.26991530322174834F, -1.5732884610986495F));
        g.addOrReplaceChild("domo_31", CubeListBuilder.create().texOffs(164, 148).addBox(-1.5F, -1.0F, -6.5F, 3.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(-12.853758510614163F, -38.33051865188429F, 3.26997863948925F, 1.5603757985825921F, 0.5268426463988336F, -1.576035979267382F));
        g.addOrReplaceChild("domo_32", CubeListBuilder.create().texOffs(964, 148).addBox(-1.5F, -1.0F, -5.5F, 3.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-13.4584348242917F, -39.122898780595506F, 2.6415212765687F, 1.5574055212010518F, 0.8329844109984413F, -1.5807050167745087F));
        g.addOrReplaceChild("domo_33", CubeListBuilder.create().texOffs(390, 175).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-14.257232440540703F, -39.659869289590446F, 1.8113080996014572F, 1.5481019158293692F, 1.1626261611510407F, -1.5916269252470947F));
        g.addOrReplaceChild("domo_34", CubeListBuilder.create().texOffs(32, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.352967084903668F, -39.93161621713294F, 0.6724797885188647F, 0.26142905640319825F, 1.1722360570065407F, -2.898925634706757F));
        g.addOrReplaceChild("domo_35", CubeListBuilder.create().texOffs(972, 105).addBox(-2.0F, -1.0F, -8.0F, 4.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-19.763384914464766F, -35.84788507991347F, 3.911393547685947F, 1.5798225058365367F, 0.06442720978758656F, -1.5702151817735646F));
        g.addOrReplaceChild("domo_36", CubeListBuilder.create().texOffs(644, 131).addBox(-1.5F, -1.0F, -7.5F, 3.0F, 1.0F, 15.0F), PartPose.offsetAndRotation(-19.556011055137944F, -37.28375802365976F, 3.6958639662678836F, 1.5801421682615882F, 0.2699153030872214F, -1.5683041925691128F));
        g.addOrReplaceChild("domo_37", CubeListBuilder.create().texOffs(196, 148).addBox(-1.5F, -1.0F, -6.5F, 3.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(-19.14624139259943F, -38.33051865188429F, 3.2699786394892505F, 1.5812168546852763F, 0.5268426461716131F, -1.5655566744863372F));
        g.addOrReplaceChild("domo_38", CubeListBuilder.create().texOffs(992, 148).addBox(-1.5F, -1.0F, -5.5F, 3.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-18.541565097523275F, -39.122898780595506F, 2.6415212765687F, 1.5841871319729977F, 0.8329844107393276F, -1.5608876371252696F));
        g.addOrReplaceChild("domo_39", CubeListBuilder.create().texOffs(412, 175).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-17.742767505847326F, -39.659869289590446F, 1.8113080996014572F, 1.593490737052469F, 1.162626160965207F, -1.5499657289942204F));
        g.addOrReplaceChild("domo_40", CubeListBuilder.create().texOffs(48, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.64703289519195F, -39.93161621713294F, 0.6724797885188648F, 2.880163592252449F, 1.1722360645519476F, -0.2426670241877795F));
        g.addOrReplaceChild("domo_41", CubeListBuilder.create().texOffs(682, 175).addBox(-2.0F, -1.0F, -3.0F, 4.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-24.9941538763668F, -35.84788507991347F, 3.774501466789023F, 1.645915237478176F, 0.06645048915795342F, -1.4952332754010977F));
        g.addOrReplaceChild("domo_42", CubeListBuilder.create().texOffs(760, 175).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-24.49854887100244F, -37.28375802365976F, 3.566515051901112F, 1.7210256723833042F, 0.2685769676362949F, -1.275767269512424F));
        g.addOrReplaceChild("domo_43", CubeListBuilder.create().texOffs(978, 175).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-23.519235969849873F, -38.33051865188429F, 3.155534982774368F, 1.8947433952087034F, 0.4884427693209944F, -1.057330129083514F));
        g.addOrReplaceChild("domo_44", CubeListBuilder.create().texOffs(476, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-22.074113622039278F, -39.122898780595506F, 2.549072552124462F, 2.1690816157530333F, 0.7025030431414125F, -0.815741645955853F));
        g.addOrReplaceChild("domo_45", CubeListBuilder.create().texOffs(64, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.165058710331817F, -39.659869289590446F, 1.7479154156700254F, 2.5490808102478324F, 0.8680921513971498F, -0.5017268028100927F));
        g.addOrReplaceChild("domo_46", CubeListBuilder.create().texOffs(786, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.54635083965499F, -39.93161621713294F, 0.6489441466845284F, 3.043944718646362F, 0.3969918962982965F, -0.04419388873411943F));
        g.addOrReplaceChild("domo_47", CubeListBuilder.create().texOffs(996, 175).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-27.451236501607642F, -35.84788507991347F, 3.494545765313924F, 1.7551889427737195F, 0.07211119301206398F, -1.4702835630777176F));
        g.addOrReplaceChild("domo_48", CubeListBuilder.create().texOffs(492, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-26.820238832919735F, -37.28375802365976F, 3.3019857539364006F, 1.859881387863397F, 0.2866636208758606F, -1.1912983200418543F));
        g.addOrReplaceChild("domo_49", CubeListBuilder.create().texOffs(508, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.573390736442242F, -38.33051865188429F, 2.921488177545986F, 2.0752752134536325F, 0.502949950028505F, -0.9331072941548063F));
        g.addOrReplaceChild("domo_50", CubeListBuilder.create().texOffs(80, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-23.73348027838119F, -39.122898780595506F, 2.3600072144315325F, 2.369725915375177F, 0.6836887629821481F, -0.6664113727399511F));
        g.addOrReplaceChild("domo_51", CubeListBuilder.create().texOffs(996, 211).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.30289708078211F, -39.659869289590446F, 1.618272099693433F, 2.8297288134249134F, 0.2931418233220762F, -0.14786298446594842F));
        g.addOrReplaceChild("domo_52", CubeListBuilder.create().texOffs(304, 222).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.968793220880702F, -39.93161621713294F, 0.600811799829785F, 3.0666894493242203F, 0.29602263867181244F, -0.034719899328118586F));
        g.addOrReplaceChild("domo_53", CubeListBuilder.create().texOffs(296, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-29.104546619927213F, -35.84788507991347F, 3.0536630670953726F, 1.9602166021085838F, 0.08270688284812176F, -1.441815261693544F));
        g.addOrReplaceChild("domo_54", CubeListBuilder.create().texOffs(310, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.382446577261497F, -37.28375802365976F, 2.885397022111931F, 2.104179507532118F, 0.3173800216429449F, -1.087535531429127F));
        g.addOrReplaceChild("domo_55", CubeListBuilder.create().texOffs(96, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-26.955580665797445F, -38.33051865188429F, 2.552904196384599F, 2.3580310944637097F, 0.5127170466317307F, -0.7700331986890996F));
        g.addOrReplaceChild("domo_56", CubeListBuilder.create().texOffs(0, 215).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.850027054118243F, -39.122898780595506F, 2.062261407568319F, 2.7268672751222085F, 0.22108527804648687F, -0.26711645105919357F));
        g.addOrReplaceChild("domo_57", CubeListBuilder.create().texOffs(804, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.06852037385037F, -39.659869289590446F, 1.4141058882085626F, 2.9333275607347202F, 0.22708825303235314F, -0.12943046110200201F));
        g.addOrReplaceChild("domo_58", CubeListBuilder.create().texOffs(218, 222).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.253044249361693F, -39.93161621713294F, 0.5250115255681875F, 3.0922287236275046F, 0.22883603199526403F, -0.03034241137658505F));
        g.addOrReplaceChild("domo_59", CubeListBuilder.create().texOffs(324, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-30.154380500458835F, -35.84788507991347F, 2.3984410336978144F, 2.376818167508759F, 0.08571121118830204F, -1.3888626143222107F));
        g.addOrReplaceChild("domo_60", CubeListBuilder.create().texOffs(338, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-29.37443144462917F, -37.28375802365976F, 2.266279698933987F, 2.539793038955171F, 0.29324412710480163F, -0.9079888819923356F));
        g.addOrReplaceChild("domo_61", CubeListBuilder.create().texOffs(142, 215).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-27.83325618540388F, -38.33051865188429F, 2.0051295919599674F, 2.7786363904981854F, 0.1516401532411474F, -0.44681896478298244F));
        g.addOrReplaceChild("domo_62", CubeListBuilder.create().texOffs(16, 215).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-25.55902207046673F, -39.122898780595506F, 1.6197636325438085F, 2.9324036609221666F, 0.16280489742633475F, -0.24813760669869217F));
        g.addOrReplaceChild("domo_63", CubeListBuilder.create().texOffs(822, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.554682808762596F, -39.659869289590446F, 1.1106823227551523F, 3.0391543532590055F, 0.16667093751282094F, -0.11992596862486929F));
        g.addOrReplaceChild("domo_64", CubeListBuilder.create().texOffs(0, 185).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-30.6677258038223F, -35.84788507991347F, 1.0035693477901608F, 3.0190594282338776F, 0.02264710722620786F, -1.3361909285342932F));
        g.addOrReplaceChild("domo_65", CubeListBuilder.create().texOffs(524, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.859489873504565F, -37.28375802365976F, 0.9482696499161948F, 3.053702001548085F, 0.06963934989514452F, -0.7730841440105625F));
        g.addOrReplaceChild("domo_66", CubeListBuilder.create().texOffs(358, 185).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-28.26241989808469F, -38.33051865188429F, 0.8389977358482551F, 3.0886518234808436F, 0.08817504391778391F, -0.43448033949888626F));
        g.addOrReplaceChild("domo_67", CubeListBuilder.create().texOffs(944, 207).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.905704787132628F, -39.122898780595506F, 0.6777507178402526F, 3.1116958960488676F, 0.06636502449719534F, -0.23978789629592412F));
        g.addOrReplaceChild("domo_68", CubeListBuilder.create().texOffs(672, 211).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.792405373505467F, -39.659869289590446F, 0.4647380188167203F, 3.1270527340477305F, 0.06785792379095189F, -0.11576683326950991F));
        g.addOrReplaceChild("domo_69", CubeListBuilder.create().texOffs(80, 222).addBox(-5.5F, -1.0F, -0.5F, 11.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.521799206945744F, -39.93161621713294F, 0.17254211179164364F, 3.138180520373959F, 0.06828874996998636F, -0.02711041720025752F));
        g.addOrReplaceChild("domo_70", CubeListBuilder.create().texOffs(18, 185).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-30.667725803822304F, -35.84788507991347F, -1.0035693041300635F, -3.0190594335092134F, -0.022647106250063748F, -1.3361909284637281F));
        g.addOrReplaceChild("domo_71", CubeListBuilder.create().texOffs(540, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.85948987350456F, -37.28375802365976F, -0.9482696086619007F, -3.053702005336803F, -0.06963934689159461F, -0.7730841438544349F));
        g.addOrReplaceChild("domo_72", CubeListBuilder.create().texOffs(376, 185).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-28.26241989808469F, -38.33051865188429F, -0.8389976993478153F, -3.0886518257649502F, -0.08817504011312903F, -0.4344803393795611F));
        g.addOrReplaceChild("domo_73", CubeListBuilder.create().texOffs(962, 207).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.905704787132628F, -39.122898780595506F, -0.6777506883548342F, -3.111695897333374F, -0.06636502161846726F, -0.23978789629592412F));
        g.addOrReplaceChild("domo_74", CubeListBuilder.create().texOffs(692, 211).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.792405373505467F, -39.659869289590446F, -0.4647379985983795F, -3.1270527346723807F, -0.06785792084785976F, -0.11576683326950993F));
        g.addOrReplaceChild("domo_75", CubeListBuilder.create().texOffs(104, 222).addBox(-5.5F, -1.0F, -0.5F, 11.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.521799206945744F, -39.93161621713294F, -0.17254210428523126F, -3.1381805205205437F, -0.06828874700832463F, -0.02711041720025752F));
        g.addOrReplaceChild("domo_76", CubeListBuilder.create().texOffs(352, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-30.154380500458835F, -35.84788507991347F, -2.398441033697812F, -2.376818167508759F, -0.08571121118830148F, -1.3888626143222123F));
        g.addOrReplaceChild("domo_77", CubeListBuilder.create().texOffs(366, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-29.37443144462917F, -37.28375802365976F, -2.2662796989339844F, -2.5397930389551733F, -0.2932441271048019F, -0.9079888819923331F));
        g.addOrReplaceChild("domo_78", CubeListBuilder.create().texOffs(156, 215).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-27.83325618540388F, -38.33051865188429F, -2.0051295919599648F, -2.778636390498186F, -0.15164015324114724F, -0.4468189647829827F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("domo_79", CubeListBuilder.create().texOffs(32, 215).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-25.55902207046673F, -39.122898780595506F, -1.619763632543807F, -2.9324036609221675F, -0.1628048974263345F, -0.24813760669869203F));
        g.addOrReplaceChild("domo_80", CubeListBuilder.create().texOffs(840, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.554682808762593F, -39.659869289590446F, -1.1106823227551512F, -3.0391543532590055F, -0.16667093751282075F, -0.11992596862486929F));
        g.addOrReplaceChild("domo_81", CubeListBuilder.create().texOffs(380, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-29.10454661992722F, -35.84788507991347F, -3.0536630670953713F, -1.9602166021085852F, -0.08270688284812151F, -1.4418152616935451F));
        g.addOrReplaceChild("domo_82", CubeListBuilder.create().texOffs(394, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.382446577261504F, -37.28375802365976F, -2.8853970221119294F, -2.1041795075321197F, -0.3173800216429453F, -1.087535531429125F));
        g.addOrReplaceChild("domo_83", CubeListBuilder.create().texOffs(112, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-26.955580665797445F, -38.33051865188429F, -2.5529041963845978F, -2.3580310944637106F, -0.5127170466317305F, -0.7700331986890996F));
        g.addOrReplaceChild("domo_84", CubeListBuilder.create().texOffs(48, 215).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.850027054118247F, -39.122898780595506F, -2.0622614075683177F, -2.7268672751222103F, -0.22108527804648664F, -0.2671164510591934F));
        g.addOrReplaceChild("domo_85", CubeListBuilder.create().texOffs(858, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.068520373850376F, -39.659869289590446F, -1.414105888208562F, -2.9333275607347216F, -0.22708825303235292F, -0.129430461102002F));
        g.addOrReplaceChild("domo_86", CubeListBuilder.create().texOffs(240, 222).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.253044249361693F, -39.93161621713294F, -0.5250115255681873F, -3.092228723627505F, -0.22883603199526395F, -0.03034241137658505F));
        g.addOrReplaceChild("domo_87", CubeListBuilder.create().texOffs(36, 185).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-27.451236501607646F, -35.84788507991347F, -3.4945457653139234F, -1.7551889427737197F, -0.07211119301206385F, -1.4702835630777176F));
        g.addOrReplaceChild("domo_88", CubeListBuilder.create().texOffs(556, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-26.820238832919742F, -37.28375802365976F, -3.3019857539363997F, -1.8598813878633977F, -0.28666362087586067F, -1.1912983200418537F));
        g.addOrReplaceChild("domo_89", CubeListBuilder.create().texOffs(572, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.573390736442246F, -38.33051865188429F, -2.9214881775459856F, -2.0752752134536325F, -0.5029499500285051F, -0.9331072941548066F));
        g.addOrReplaceChild("domo_90", CubeListBuilder.create().texOffs(128, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-23.733480278381197F, -39.122898780595506F, -2.360007214431532F, -2.3697259153751777F, -0.6836887629821478F, -0.6664113727399505F));
        g.addOrReplaceChild("domo_91", CubeListBuilder.create().texOffs(64, 215).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.302897080782113F, -39.659869289590446F, -1.6182720996934328F, -2.8297288134249134F, -0.2931418233220757F, -0.1478629844659482F));
        g.addOrReplaceChild("domo_92", CubeListBuilder.create().texOffs(324, 222).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.968793220880702F, -39.93161621713294F, -0.6008117998297848F, -3.06668944932422F, -0.2960226386718124F, -0.034719899328118586F));
        g.addOrReplaceChild("domo_93", CubeListBuilder.create().texOffs(702, 175).addBox(-2.0F, -1.0F, -3.0F, 4.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-24.99415387636681F, -35.84788507991347F, -3.774501466789022F, -1.6459152374781763F, -0.0664504891579533F, -1.4952332754010977F));
        g.addOrReplaceChild("domo_94", CubeListBuilder.create().texOffs(778, 175).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-24.498548871002455F, -37.28375802365976F, -3.5665150519011117F, -1.7210256723833046F, -0.2685769676362951F, -1.2757672695124234F));
        g.addOrReplaceChild("domo_95", CubeListBuilder.create().texOffs(54, 185).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-23.51923596984988F, -38.33051865188429F, -3.155534982774367F, -1.8947433952087036F, -0.48844276932099434F, -1.057330129083514F));
        g.addOrReplaceChild("domo_96", CubeListBuilder.create().texOffs(588, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-22.074113622039285F, -39.122898780595506F, -2.5490725521244615F, -2.169081615753034F, -0.7025030431414121F, -0.8157416459558522F));
        g.addOrReplaceChild("domo_97", CubeListBuilder.create().texOffs(144, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.165058710331824F, -39.659869289590446F, -1.7479154156700254F, -2.5490808102478333F, -0.8680921513971496F, -0.5017268028100923F));
        g.addOrReplaceChild("domo_98", CubeListBuilder.create().texOffs(876, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.54635083965499F, -39.93161621713294F, -0.6489441466845282F, -3.043944718646362F, -0.39699189629829595F, -0.04419388873411938F));
        g.addOrReplaceChild("domo_99", CubeListBuilder.create().texOffs(0, 131).addBox(-2.0F, -1.0F, -8.0F, 4.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-19.763385072611324F, -35.84788507991347F, -3.9113935476859467F, -1.579822506215845F, -0.06442720983354466F, -1.5702151817487278F));
        g.addOrReplaceChild("domo_100", CubeListBuilder.create().texOffs(680, 131).addBox(-1.5F, -1.0F, -7.5F, 3.0F, 1.0F, 15.0F), PartPose.offsetAndRotation(-19.556011204570154F, -37.28375802365976F, -3.695863966267883F, -1.5801421686547779F, -0.26991530327098867F, -1.568304192462605F));
        g.addOrReplaceChild("domo_101", CubeListBuilder.create().texOffs(228, 148).addBox(-1.5F, -1.0F, -6.5F, 3.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(-19.146241524812122F, -38.33051865188429F, -3.2699786394892496F, -1.581216855125034F, -0.5268426464820022F, -1.5655566742624103F));
        g.addOrReplaceChild("domo_102", CubeListBuilder.create().texOffs(0, 163).addBox(-1.5F, -1.0F, -5.5F, 3.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-18.541565204326005F, -39.122898780595506F, -2.6415212765687F, -1.584187132540914F, -0.8329844110932834F, -1.5608876367018218F));
        g.addOrReplaceChild("domo_103", CubeListBuilder.create().texOffs(434, 175).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-17.742767579082646F, -39.659869289590446F, -1.8113080996014572F, -1.5934907380195535F, -1.162626161219061F, -1.5499657281042245F));
        g.addOrReplaceChild("domo_104", CubeListBuilder.create().texOffs(160, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.64703292238184F, -39.93161621713294F, -0.6724797885188647F, -2.8801635989926178F, -1.1722360542447299F, -0.24266701694136544F));
        g.addOrReplaceChild("domo_105", CubeListBuilder.create().texOffs(40, 131).addBox(-2.0F, -1.0F, -8.0F, 4.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-12.23661512791048F, -35.84788507991347F, -3.911393547685947F, -1.5617701478548918F, -0.06442720977527214F, -1.5713774718095737F));
        g.addOrReplaceChild("domo_106", CubeListBuilder.create().texOffs(716, 131).addBox(-1.5F, -1.0F, -7.5F, 3.0F, 1.0F, 15.0F), PartPose.offsetAndRotation(-12.443988984902292F, -37.28375802365976F, -3.6958639662678836F, -1.56145048543356F, -0.26991530303798117F, -1.5732884609921418F));
        g.addOrReplaceChild("domo_107", CubeListBuilder.create().texOffs(260, 148).addBox(-1.5F, -1.0F, -6.5F, 3.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(-12.853758642826854F, -38.33051865188429F, -3.2699786394892505F, -1.5603757990223497F, -0.5268426460884446F, -1.576035979043455F));
        g.addOrReplaceChild("domo_108", CubeListBuilder.create().texOffs(28, 163).addBox(-1.5F, -1.0F, -5.5F, 3.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-13.458434931094427F, -39.122898780595506F, -2.6415212765687F, -1.5574055217689682F, -0.8329844106444856F, -1.5807050163510614F));
        g.addOrReplaceChild("domo_109", CubeListBuilder.create().texOffs(456, 175).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-14.257232513776016F, -39.659869289590446F, -1.8113080996014572F, -1.5481019167964538F, -1.162626160897187F, -1.591626924357099F));
        g.addOrReplaceChild("domo_110", CubeListBuilder.create().texOffs(176, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.352967112093559F, -39.93161621713294F, -0.6724797885188648F, -0.26142906314336667F, -1.172236067313758F, -2.8989256274603434F));
        g.addOrReplaceChild("domo_111", CubeListBuilder.create().texOffs(722, 175).addBox(-2.0F, -1.0F, -3.0F, 4.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-7.005846123633205F, -35.84788507991347F, -3.7745014667890233F, -1.4956774161116173F, -0.06645048915795335F, -1.646359378188695F));
        g.addOrReplaceChild("domo_112", CubeListBuilder.create().texOffs(796, 175).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-7.501451128997558F, -37.28375802365976F, -3.5665150519011126F, -1.420566981206489F, -0.26857696763629485F, -1.8658253840773695F));
        g.addOrReplaceChild("domo_113", CubeListBuilder.create().texOffs(72, 185).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-8.480764030150132F, -38.33051865188429F, -3.155534982774368F, -1.2468492583810904F, -0.48844276932099434F, -2.0842625245062787F));
        g.addOrReplaceChild("domo_114", CubeListBuilder.create().texOffs(604, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.925886377960724F, -39.122898780595506F, -2.549072552124462F, -0.9725110378367599F, -0.7025030431414123F, -2.3258510076339403F));
        g.addOrReplaceChild("domo_115", CubeListBuilder.create().texOffs(192, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.834941289668183F, -39.659869289590446F, -1.7479154156700256F, -0.5925118433419608F, -0.8680921513971498F, -2.6398658507797004F));
        g.addOrReplaceChild("domo_116", CubeListBuilder.create().texOffs(894, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.45364916034501F, -39.93161621713294F, -0.6489441466845284F, -0.09764793494343088F, -0.3969918962982966F, -3.097398764855674F));
        g.addOrReplaceChild("domo_117", CubeListBuilder.create().texOffs(90, 185).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-4.5487634983923595F, -35.84788507991347F, -3.4945457653139242F, -1.3864037108160736F, -0.07211119301206398F, -1.6713090905120755F));
        g.addOrReplaceChild("domo_118", CubeListBuilder.create().texOffs(620, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.179761167080265F, -37.28375802365976F, -3.3019857539364006F, -1.2817112657263963F, -0.2866636208758605F, -1.9502943335479388F));
        g.addOrReplaceChild("domo_119", CubeListBuilder.create().texOffs(636, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.4266092635577605F, -38.33051865188429F, -2.921488177545986F, -1.0663174401361608F, -0.5029499500285051F, -2.2084853594349867F));
        g.addOrReplaceChild("domo_120", CubeListBuilder.create().texOffs(208, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.26651972161881F, -39.122898780595506F, -2.3600072144315325F, -0.7718667382146159F, -0.6836887629821481F, -2.475181280849842F));
        g.addOrReplaceChild("domo_121", CubeListBuilder.create().texOffs(80, 215).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.697102919217894F, -39.659869289590446F, -1.618272099693433F, -0.3118638401648799F, -0.29314182332207617F, -2.993729669123845F));
        g.addOrReplaceChild("domo_122", CubeListBuilder.create().texOffs(344, 222).addBox(-4.5F, -1.0F, -0.5F, 9.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-14.031206779119298F, -39.93161621713294F, -0.600811799829785F, -0.07490320426557331F, -0.2960226386718125F, -3.1068727542616745F));
        g.addOrReplaceChild("domo_123", CubeListBuilder.create().texOffs(408, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.895453380072789F, -35.84788507991347F, -3.0536630670953726F, -1.1813760514812095F, -0.08270688284812164F, -1.6997773918962487F));
        g.addOrReplaceChild("domo_124", CubeListBuilder.create().texOffs(422, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-3.617553422738501F, -37.28375802365976F, -2.885397022111931F, -1.0374131460576754F, -0.3173800216429449F, -2.0540571221606663F));
        g.addOrReplaceChild("domo_125", CubeListBuilder.create().texOffs(224, 211).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-5.044419334202556F, -38.33051865188429F, -2.552904196384599F, -0.783561559126083F, -0.5127170466317307F, -2.371559454900694F));
        g.addOrReplaceChild("domo_126", CubeListBuilder.create().texOffs(96, 215).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-7.149972945881755F, -39.122898780595506F, -2.062261407568319F, -0.41472537846758456F, -0.22108527804648692F, -2.8744762025305994F));
        g.addOrReplaceChild("domo_127", CubeListBuilder.create().texOffs(912, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.931479626149628F, -39.659869289590446F, -1.4141058882085626F, -0.2082650928550726F, -0.22708825303235308F, -3.012162192487791F));
        g.addOrReplaceChild("domo_128", CubeListBuilder.create().texOffs(262, 222).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.746955750638307F, -39.93161621713294F, -0.5250115255681875F, -0.049363929962288305F, -0.22883603199526403F, -3.1112502422132082F));
        g.addOrReplaceChild("domo_129", CubeListBuilder.create().texOffs(436, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.8456194995411677F, -35.84788507991347F, -2.398441033697816F, -0.7647744860810368F, -0.08571121118830188F, -1.7527300392675815F));
        g.addOrReplaceChild("domo_130", CubeListBuilder.create().texOffs(450, 211).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.6255685553708323F, -37.28375802365976F, -2.266279698933988F, -0.6017996146346231F, -0.2932441271048021F, -2.233603771597458F));
        g.addOrReplaceChild("domo_131", CubeListBuilder.create().texOffs(170, 215).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.166743814596124F, -38.33051865188429F, -2.005129591959968F, -0.362956263091608F, -0.15164015324114746F, -2.6947736888068112F));
        g.addOrReplaceChild("domo_132", CubeListBuilder.create().texOffs(112, 215).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.440977929533268F, -39.122898780595506F, -1.6197636325438094F, -0.2091889926676265F, -0.1628048974263349F, -2.893455046891101F));
        g.addOrReplaceChild("domo_133", CubeListBuilder.create().texOffs(930, 211).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.445317191237406F, -39.659869289590446F, -1.1106823227551528F, -0.10243830033078778F, -0.16667093751282094F, -3.021666684964924F));
        g.addOrReplaceChild("domo_134", CubeListBuilder.create().texOffs(108, 185).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.3322741961776994F, -35.84788507991347F, -1.0035693568324637F, -0.12253322644847325F, -0.022647107428373937F, -1.8054017250408851F));
        g.addOrReplaceChild("domo_135", CubeListBuilder.create().texOffs(652, 185).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.140510126495439F, -37.28375802365976F, -0.9482696584602397F, -0.0878906528263778F, -0.06963935051720045F, -2.3685085095468965F));
        g.addOrReplaceChild("domo_136", CubeListBuilder.create().texOffs(394, 185).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-3.737580101915313F, -38.33051865188429F, -0.8389977434077445F, -0.05294083058200396F, -0.0881750447057541F, -2.7071123140661943F));
        g.addOrReplaceChild("domo_137", CubeListBuilder.create().texOffs(980, 207).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.094295212867375F, -39.122898780595506F, -0.6777507239468833F, -0.029896757806955755F, -0.0663650250933995F, -2.9018047572938688F));
        g.addOrReplaceChild("domo_138", CubeListBuilder.create().texOffs(712, 211).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.207594626494537F, -39.659869289590446F, -0.4647380230040762F, -0.014539919671432262F, -0.06785792440048628F, -3.0258258203202835F));
        g.addOrReplaceChild("domo_139", CubeListBuilder.create().texOffs(128, 222).addBox(-5.5F, -1.0F, -0.5F, 11.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.478200793054258F, -39.93161621713294F, -0.17254211334627267F, -0.0034121332461934718F, -0.06828875058336667F, -3.1144822363895357F));
        g.addOrReplaceChild("silbato_0", CubeListBuilder.create().texOffs(322, 175).addBox(-6.0F, -41.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(936, 131).addBox(-2.5F, -41.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(6.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("silbato_1", CubeListBuilder.create().texOffs(356, 175).addBox(-6.0F, -41.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(970, 131).addBox(-2.5F, -41.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(6.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("deflectori", CubeListBuilder.create().texOffs(540, 62).addBox(0.0F, -36.0F, -0.5F, 40.0F, 36.0F, 1.0F), PartPose.offset(-62.0F, -20.0F, -12.5F));
        g.addOrReplaceChild("deflectord", CubeListBuilder.create().texOffs(622, 62).addBox(0.0F, -36.0F, -0.5F, 40.0F, 36.0F, 1.0F), PartPose.offset(-62.0F, -20.0F, 12.5F));
        g.addOrReplaceChild("pasamanos", CubeListBuilder.create().texOffs(634, 215).addBox(-48.0F, -32.0F, 9.0F, 74.0F, 1.0F, 1.0F).texOffs(784, 215).addBox(-48.0F, -32.0F, -10.0F, 74.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(852, 105).addBox(31.0F, -38.0F, 11.5F, 19.0F, 18.0F, 1.0F).texOffs(892, 105).addBox(31.0F, -38.0F, -12.5F, 19.0F, 18.0F, 1.0F).texOffs(280, 105).addBox(31.0F, -21.0F, -11.5F, 19.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_frente", CubeListBuilder.create().texOffs(814, 62).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 25.0F), PartPose.offset(30.0F, -32.0F, -12.5F));
        g.addOrReplaceChild("cabina_fuego", CubeListBuilder.create().texOffs(720, 105).addBox(31.0F, -32.0F, -5.0F, 2.0F, 11.0F, 10.0F).texOffs(814, 175).addBox(33.0F, -26.0F, -2.0F, 1.0F, 3.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(888, 185).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -37.280047391071406F, -11.526459469667696F, -2.6818551972416236F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(940, 185).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -38.16112455113704F, -9.542532937373895F, -2.7654438256685654F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(0, 191).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -38.873484783820615F, -7.491970978685589F, -2.8490324540955045F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(52, 191).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -39.41215368367204F, -5.389092650331454F, -2.932621082522443F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(104, 191).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -39.77336973034208F, -3.2485823338048823F, -3.016209710949384F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(156, 191).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -39.95461055524703F, -1.085387194452817F, -3.0997983393763233F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(208, 191).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -39.95461055524703F, 1.0853871944528155F, 3.0997983393763233F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(260, 191).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -39.77336973034208F, 3.2485823338048796F, 3.016209710949384F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(312, 191).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -39.41215368367204F, 5.3890926503314525F, 2.932621082522443F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(364, 191).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -38.873484783820615F, 7.491970978685588F, 2.849032454095504F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(416, 191).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -38.16112455113704F, 9.542532937373895F, 2.765443825668566F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(468, 191).addBox(-11.5F, -1.0F, -1.5F, 23.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.5F, -37.280047391071406F, 11.526459469667696F, 2.6818551972416236F, 0.0F, 0.0F));
        g.addOrReplaceChild("numeroi", CubeListBuilder.create().texOffs(210, 175).addBox(0.0F, -7.0F, -0.5F, 27.0F, 7.0F, 1.0F), PartPose.offset(36.25F, -23.75F, -13.0F));
        g.addOrReplaceChild("numerod", CubeListBuilder.create().texOffs(266, 175).addBox(0.0F, -7.0F, -0.5F, 27.0F, 7.0F, 1.0F), PartPose.offset(36.25F, -23.75F, 13.0F));
        g.addOrReplaceChild("cab_fondo_caldera", CubeListBuilder.create().texOffs(766, 62).addBox(30.6F, -32.0F, -11.5F, 1.0F, 11.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_placa", CubeListBuilder.create().texOffs(528, 163).addBox(31.0F, -37.0F, -3.5F, 1.0F, 5.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(60, 148).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(32.6F, -33.6F, -2.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(250, 215).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(32.72F, -33.6F, -2.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_presion", CubeListBuilder.create().texOffs(112, 148).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(32.6F, -33.6F, 2.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_presion_aguja", CubeListBuilder.create().texOffs(254, 215).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(32.72F, -33.6F, 2.0F, 0.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_nivel", CubeListBuilder.create().texOffs(154, 185).addBox(33.0F, -30.0F, 3.5F, 1.0F, 5.0F, 1.0F).texOffs(232, 215).addBox(33.0F, -25.0F, 3.0F, 1.0F, 1.0F, 2.0F).texOffs(238, 215).addBox(33.0F, -31.0F, 3.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("cab_regulador", CubeListBuilder.create().texOffs(824, 175).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(32.5F, -32.5F, 0.0F, -1.1920024339695F, 0.09966865249116204F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_valvulas", CubeListBuilder.create().texOffs(378, 222).addBox(33.0F, -30.0F, 1.0F, 1.0F, 1.0F, 1.0F).texOffs(382, 222).addBox(33.0F, -30.0F, -4.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_tubo", CubeListBuilder.create().texOffs(206, 175).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 8.0F, 1.0F), PartPose.offset(33.5F, -29.5F, -3.5F));
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(812, 163).addBox(-0.5F, -10.0F, -0.5F, 1.0F, 10.0F, 1.0F).texOffs(544, 211).addBox(-1.0F, -12.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(37.0F, -21.0F, -8.0F));
        g.addOrReplaceChild("cab_palanca_cuadrante", CubeListBuilder.create().texOffs(364, 222).addBox(34.0F, -22.0F, -9.5F, 6.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(244, 215).addBox(40.0F, -32.0F, -11.5F, 2.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_freno_manija", CubeListBuilder.create().texOffs(552, 211).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(41.0F, -32.0F, -11.0F, 0.7297276562269664F, 0.0F, -2.0344439357957027F));
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(162, 175).addBox(48.0F, -27.0F, -6.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(172, 175).addBox(48.0F, -27.0F, 2.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(766, 163).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(800, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(788, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(808, 185).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(66.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(822, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(796, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(66.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(844, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(804, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(66.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(766, 163).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(800, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(788, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(818, 185).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(78.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(822, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(796, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(78.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(844, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(804, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(78.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri2_0", CubeListBuilder.create().texOffs(766, 163).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(800, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(788, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(828, 185).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(104.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri2_1", CubeListBuilder.create().texOffs(822, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(796, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(104.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri2_2", CubeListBuilder.create().texOffs(844, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(804, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(104.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri3_0", CubeListBuilder.create().texOffs(766, 163).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(800, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(788, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(838, 185).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(116.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri3_1", CubeListBuilder.create().texOffs(822, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(796, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri3_2", CubeListBuilder.create().texOffs(844, 207).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(804, 163).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(766, 163).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(800, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(788, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(848, 185).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(66.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(822, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(796, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(66.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(844, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(804, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(66.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(766, 163).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(800, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(788, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(858, 185).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(78.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(822, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(796, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(78.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(844, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(804, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(78.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd2_0", CubeListBuilder.create().texOffs(766, 163).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(800, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(788, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 185).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(104.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd2_1", CubeListBuilder.create().texOffs(822, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(796, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(104.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd2_2", CubeListBuilder.create().texOffs(844, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(804, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(104.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd3_0", CubeListBuilder.create().texOffs(766, 163).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(800, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(788, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 185).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(116.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd3_1", CubeListBuilder.create().texOffs(822, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(796, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd3_2", CubeListBuilder.create().texOffs(844, 207).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(804, 163).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(816, 163).addBox(56.0F, -13.0F, 2.0F, 70.0F, 9.0F, 1.0F).texOffs(0, 175).addBox(56.0F, -13.0F, -3.0F, 70.0F, 9.0F, 1.0F).texOffs(478, 175).addBox(61.0F, -9.0F, 7.0F, 22.0F, 6.0F, 1.0F).texOffs(524, 175).addBox(61.0F, -9.0F, -8.0F, 22.0F, 6.0F, 1.0F).texOffs(570, 175).addBox(99.0F, -9.0F, 7.0F, 22.0F, 6.0F, 1.0F).texOffs(616, 175).addBox(99.0F, -9.0F, -8.0F, 22.0F, 6.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(448, 0).addBox(54.0F, -31.0F, -12.5F, 74.0F, 18.0F, 25.0F).texOffs(534, 105).addBox(54.0F, -34.0F, -9.5F, 74.0F, 3.0F, 19.0F).texOffs(744, 105).addBox(56.0F, -36.0F, -9.0F, 36.0F, 2.0F, 18.0F).texOffs(236, 105).addBox(128.0F, -13.0F, -10.0F, 2.0F, 5.0F, 20.0F).texOffs(140, 185).addBox(130.0F, -12.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender_caja_cantoi_0", CubeListBuilder.create().texOffs(0, 218).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -31.46352549156242F, -12.42658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_1", CubeListBuilder.create().texOffs(150, 218).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -32.34520337000113F, -12.140110266005152F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_2", CubeListBuilder.create().texOffs(300, 218).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -33.09520337000113F, -11.59520337000113F, -2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_3", CubeListBuilder.create().texOffs(450, 218).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -33.64011026600515F, -10.845203370001132F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_4", CubeListBuilder.create().texOffs(600, 218).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -33.92658477444273F, -9.963525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_0", CubeListBuilder.create().texOffs(750, 218).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -31.46352549156242F, 12.42658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_1", CubeListBuilder.create().texOffs(0, 220).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -32.34520337000113F, 12.140110266005152F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_2", CubeListBuilder.create().texOffs(150, 220).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -33.09520337000113F, 11.59520337000113F, 2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_3", CubeListBuilder.create().texOffs(300, 220).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -33.64011026600515F, 10.845203370001132F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_4", CubeListBuilder.create().texOffs(450, 220).addBox(-37.0F, -1.0F, -0.5F, 74.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(91.0F, -33.92658477444273F, 9.963525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_tapaa", CubeListBuilder.create().texOffs(244, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 50.0F), PartPose.offset(54.0F, -31.0F, -12.5F));
        g.addOrReplaceChild("tender_caja_tapab", CubeListBuilder.create().texOffs(346, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 50.0F), PartPose.offset(127.0F, -31.0F, -12.5F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "cil_i_0", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "cil_i_1", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "cil_i_2", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "cil_i_3", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "cil_i_a_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_i_a_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_i_a_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_i_a_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_i_b_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_i_b_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_i_b_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_i_b_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_d_0", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "cil_d_1", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "cil_d_2", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "cil_d_3", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "cil_d_a_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_d_a_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_d_a_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_d_a_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_d_b_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_d_b_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_d_b_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "cil_d_b_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "caja_humo_0", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "caja_humo_1", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "caja_humo_2", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "caja_humo_3", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "caja_humo_4", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "caja_humo_5", 1.0F, 0.46963177644022597F, 0.46963177644022597F);
        escalar(g0, "puerta", 0.24918032786885244F, 0.6F, 0.24918032786885244F);
        escalar(g0, "placa_frente", 1.0F, 0.5F, 0.5F);
        escalar(g0, "caldera_0", 0.9473830408228664F, 1.0F, 0.7396484225802923F);
        escalar(g0, "caldera_1", 0.9473830408228664F, 1.0F, 0.7483501687282957F);
        escalar(g0, "caldera_2", 0.9473830408228664F, 1.0F, 0.7570519148762996F);
        escalar(g0, "caldera_3", 0.9473830408228664F, 1.0F, 0.7657536610243022F);
        escalar(g0, "caldera_4", 0.9473830408228664F, 1.0F, 0.7396484225802921F);
        escalar(g0, "caldera_5", 0.9473830408228664F, 1.0F, 0.7483501687282957F);
        escalar(g0, "caldera_6", 0.9473830408228664F, 1.0F, 0.7570519148762985F);
        escalar(g0, "caldera_7", 0.9473830408228664F, 1.0F, 0.7657536610243031F);
        escalar(g0, "caldera_8", 0.9473830408228664F, 1.0F, 0.7396484225802933F);
        escalar(g0, "caldera_9", 0.9473830408228664F, 1.0F, 0.748350168728296F);
        escalar(g0, "caldera_10", 0.9473830408228664F, 1.0F, 0.7570519148763001F);
        escalar(g0, "caldera_11", 0.9473830408228664F, 1.0F, 0.7657536610243026F);
        escalar(g0, "caldera_12", 0.9473830408228664F, 1.0F, 0.7396484225802921F);
        escalar(g0, "caldera_13", 0.9473830408228664F, 1.0F, 0.7483501687282955F);
        escalar(g0, "caldera_14", 0.9473830408228664F, 1.0F, 0.7570519148762985F);
        escalar(g0, "caldera_15", 0.9473830408228664F, 1.0F, 0.7657536610243035F);
        escalar(g0, "caldera_16", 0.9473830408228664F, 1.0F, 0.7396484225802915F);
        escalar(g0, "caldera_17", 0.9473830408228664F, 1.0F, 0.7483501687282968F);
        escalar(g0, "caldera_18", 0.9473830408228664F, 1.0F, 0.757051914876299F);
        escalar(g0, "caldera_19", 0.9473830408228664F, 1.0F, 0.7657536610243012F);
        escalar(g0, "caldera_20", 0.9473830408228664F, 1.0F, 0.7396484225802934F);
        escalar(g0, "caldera_21", 0.9473830408228664F, 1.0F, 0.7483501687282961F);
        escalar(g0, "caldera_22", 0.9473830408228664F, 1.0F, 0.7570519148762999F);
        escalar(g0, "caldera_23", 0.9473830408228664F, 1.0F, 0.7657536610243039F);
        escalar(g0, "caldera_24", 0.9473830408228664F, 1.0F, 0.739648422580291F);
        escalar(g0, "caldera_25", 0.9473830408228664F, 1.0F, 0.7483501687282947F);
        escalar(g0, "caldera_26", 0.9473830408228664F, 1.0F, 0.7570519148762987F);
        escalar(g0, "caldera_27", 0.9473830408228664F, 1.0F, 0.7657536610243015F);
        escalar(g0, "caldera_28", 0.9473830408228664F, 1.0F, 0.7396484225802937F);
        escalar(g0, "caldera_29", 0.9473830408228664F, 1.0F, 0.748350168728296F);
        escalar(g0, "caldera_30", 0.9473830408228664F, 1.0F, 0.7570519148762992F);
        escalar(g0, "caldera_31", 0.9473830408228664F, 1.0F, 0.7657536610243034F);
        escalar(g0, "caldera_32", 0.9473830408228664F, 1.0F, 0.7396484225802921F);
        escalar(g0, "caldera_33", 0.9473830408228664F, 1.0F, 0.7483501687282973F);
        escalar(g0, "caldera_34", 0.9473830408228664F, 1.0F, 0.7570519148762996F);
        escalar(g0, "caldera_35", 0.9473830408228664F, 1.0F, 0.7657536610243035F);
        escalar(g0, "caldera_36", 0.9473830408228664F, 1.0F, 0.7396484225802918F);
        escalar(g0, "caldera_37", 0.9473830408228664F, 1.0F, 0.7483501687282944F);
        escalar(g0, "caldera_38", 0.9473830408228664F, 1.0F, 0.7570519148762993F);
        escalar(g0, "caldera_39", 0.9473830408228664F, 1.0F, 0.765753661024302F);
        escalar(g0, "caldera_40", 0.9473830408228664F, 1.0F, 0.7396484225802928F);
        escalar(g0, "caldera_41", 0.9473830408228664F, 1.0F, 0.7483501687282966F);
        escalar(g0, "caldera_42", 0.9473830408228664F, 1.0F, 0.7570519148762993F);
        escalar(g0, "caldera_43", 0.9473830408228664F, 1.0F, 0.7657536610243024F);
        escalar(g0, "caldera_44", 0.9473830408228664F, 1.0F, 0.7396484225802927F);
        escalar(g0, "caldera_45", 0.9473830408228664F, 1.0F, 0.7483501687282962F);
        escalar(g0, "caldera_46", 0.9473830408228664F, 1.0F, 0.7570519148762999F);
        escalar(g0, "caldera_47", 0.9473830408228664F, 1.0F, 0.7657536610243033F);
        escalar(g0, "caldera_48", 0.9473830408228664F, 1.0F, 0.7396484225802915F);
        escalar(g0, "caldera_49", 0.9473830408228664F, 1.0F, 0.7483501687282949F);
        escalar(g0, "caldera_50", 0.9473830408228664F, 1.0F, 0.7570519148762984F);
        escalar(g0, "caldera_51", 0.9473830408228664F, 1.0F, 0.7657536610243018F);
        escalar(g0, "caldera_52", 0.9473830408228664F, 1.0F, 0.7396484225802916F);
        escalar(g0, "caldera_53", 0.9473830408228664F, 1.0F, 0.7483501687282951F);
        escalar(g0, "caldera_54", 0.9473830408228664F, 1.0F, 0.7570519148762985F);
        escalar(g0, "caldera_55", 0.9473830408228664F, 1.0F, 0.7657536610243018F);
        escalar(g0, "caldera_56", 0.9473830408228664F, 1.0F, 0.7396484225802937F);
        escalar(g0, "caldera_57", 0.9473830408228664F, 1.0F, 0.7483501687282978F);
        escalar(g0, "caldera_58", 0.9473830408228664F, 1.0F, 0.7570519148763012F);
        escalar(g0, "caldera_59", 0.9473830408228664F, 1.0F, 0.7657536610243046F);
        escalar(g0, "caldera_60", 0.9473830408228664F, 1.0F, 0.7396484225802915F);
        escalar(g0, "caldera_61", 0.9473830408228664F, 1.0F, 0.7483501687282949F);
        escalar(g0, "caldera_62", 0.9473830408228664F, 1.0F, 0.7570519148762981F);
        escalar(g0, "caldera_63", 0.9473830408228664F, 1.0F, 0.7657536610243013F);
        escalar(g0, "caldera_64", 0.9473830408228664F, 1.0F, 0.7396484225802915F);
        escalar(g0, "caldera_65", 0.9473830408228664F, 1.0F, 0.7483501687282947F);
        escalar(g0, "caldera_66", 0.9473830408228664F, 1.0F, 0.757051914876299F);
        escalar(g0, "caldera_67", 0.9473830408228664F, 1.0F, 0.7657536610243022F);
        escalar(g0, "caldera_68", 0.9473830408228664F, 1.0F, 0.7396484225802946F);
        escalar(g0, "caldera_69", 0.9473830408228664F, 1.0F, 0.7483501687282984F);
        escalar(g0, "caldera_70", 0.9473830408228664F, 1.0F, 0.7570519148763012F);
        escalar(g0, "caldera_71", 0.9473830408228664F, 1.0F, 0.7657536610243051F);
        escalar(g0, "caldera_72", 0.9473830408228664F, 1.0F, 0.739648422580291F);
        escalar(g0, "caldera_73", 0.9473830408228664F, 1.0F, 0.7483501687282947F);
        escalar(g0, "caldera_74", 0.9473830408228664F, 1.0F, 0.7570519148762975F);
        escalar(g0, "caldera_75", 0.9473830408228664F, 1.0F, 0.7657536610243015F);
        escalar(g0, "caldera_76", 0.9473830408228664F, 1.0F, 0.7396484225802912F);
        escalar(g0, "caldera_77", 0.9473830408228664F, 1.0F, 0.7483501687282956F);
        escalar(g0, "caldera_78", 0.9473830408228664F, 1.0F, 0.7570519148762987F);
        escalar(g0, "caldera_79", 0.9473830408228664F, 1.0F, 0.7657536610243009F);
        escalar(g0, "caldera_80", 0.9473830408228664F, 1.0F, 0.7396484225802943F);
        escalar(g0, "caldera_81", 0.9473830408228664F, 1.0F, 0.7483501687282975F);
        escalar(g0, "caldera_82", 0.9473830408228664F, 1.0F, 0.7570519148763007F);
        escalar(g0, "caldera_83", 0.9473830408228664F, 1.0F, 0.7657536610243058F);
        escalar(g0, "caldera_84", 0.9473830408228664F, 1.0F, 0.7396484225802912F);
        escalar(g0, "caldera_85", 0.9473830408228664F, 1.0F, 0.7483501687282952F);
        escalar(g0, "caldera_86", 0.9473830408228664F, 1.0F, 0.7570519148762993F);
        escalar(g0, "caldera_87", 0.9473830408228664F, 1.0F, 0.765753661024302F);
        escalar(g0, "caldera_88", 0.9473830408228664F, 1.0F, 0.7396484225802912F);
        escalar(g0, "caldera_89", 0.9473830408228664F, 1.0F, 0.7483501687282951F);
        escalar(g0, "caldera_90", 0.9473830408228664F, 1.0F, 0.7570519148762976F);
        escalar(g0, "caldera_91", 0.9473830408228664F, 1.0F, 0.7657536610243012F);
        escalar(g0, "caldera_92", 0.9473830408228664F, 1.0F, 0.7396484225802942F);
        escalar(g0, "caldera_93", 0.9473830408228664F, 1.0F, 0.7483501687282974F);
        escalar(g0, "caldera_94", 0.9473830408228664F, 1.0F, 0.7570519148763012F);
        escalar(g0, "caldera_95", 0.9473830408228664F, 1.0F, 0.7657536610243043F);
        escalar(g0, "chimenea_0", 0.5296240514177445F, 1.0F, 0.5296240514177445F);
        escalar(g0, "chimenea_1", 0.5296240514177445F, 1.0F, 0.5296240514177445F);
        escalar(g0, "chimenea_2", 0.5296240514177445F, 1.0F, 0.5296240514177445F);
        escalar(g0, "chimenea_3", 0.5296240514177445F, 1.0F, 0.5296240514177445F);
        escalar(g0, "chimenea_labio_0", 0.6473182850661321F, 1.0F, 0.6473182850661321F);
        escalar(g0, "chimenea_labio_1", 0.6473182850661321F, 1.0F, 0.6473182850661321F);
        escalar(g0, "chimenea_labio_2", 0.6473182850661321F, 1.0F, 0.6473182850661321F);
        escalar(g0, "chimenea_labio_3", 0.6473182850661321F, 1.0F, 0.6473182850661321F);
        escalar(g0, "calentador_0", 0.4315455233774214F, 0.4315455233774214F, 1.0F);
        escalar(g0, "calentador_1", 0.4315455233774214F, 0.4315455233774214F, 1.0F);
        escalar(g0, "calentador_2", 0.4315455233774214F, 0.4315455233774214F, 1.0F);
        escalar(g0, "calentador_3", 0.4315455233774214F, 0.4315455233774214F, 1.0F);
        escalar(g0, "faro_0", 0.353082700945163F, 1.0F, 0.353082700945163F);
        escalar(g0, "faro_1", 0.353082700945163F, 1.0F, 0.353082700945163F);
        escalar(g0, "faro_2", 0.353082700945163F, 1.0F, 0.353082700945163F);
        escalar(g0, "faro_3", 0.353082700945163F, 1.0F, 0.353082700945163F);
        escalar(g0, "faro_vidrio", 0.24000000000000002F, 0.15F, 0.24000000000000002F);
        escalar(g0, "domo_0", 0.44108095925274177F, 1.0F, 0.40863546268393225F);
        escalar(g0, "domo_1", 0.4277942025474232F, 1.0F, 0.48292353536389554F);
        escalar(g0, "domo_2", 0.4429545776489109F, 1.0F, 0.42785099403354204F);
        escalar(g0, "domo_3", 0.4736379025166407F, 1.0F, 0.4621109863201999F);
        escalar(g0, "domo_4", 0.4446890605664355F, 1.0F, 0.47845164134595874F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "domo_5", 0.4626498707155174F, 1.0F, 0.36784171811848065F);
        escalar(g0, "domo_6", 0.44048661394414845F, 1.0F, 0.3732032128747913F);
        escalar(g0, "domo_7", 0.4223192362982683F, 1.0F, 0.3530059436878545F);
        escalar(g0, "domo_8", 0.4338106458710288F, 1.0F, 0.46964436795237313F);
        escalar(g0, "domo_9", 0.4624000520169456F, 1.0F, 0.38130529323298895F);
        escalar(g0, "domo_10", 0.4955825204175489F, 1.0F, 0.264606423587637F);
        escalar(g0, "domo_11", 0.439113082076937F, 1.0F, 0.4827776273857338F);
        escalar(g0, "domo_12", 0.4094121010713005F, 1.0F, 0.4565424774778344F);
        escalar(g0, "domo_13", 0.41193505164748007F, 1.0F, 0.4047019583337839F);
        escalar(g0, "domo_14", 0.4353534737025834F, 1.0F, 0.49230530273195117F);
        escalar(g0, "domo_15", 0.4651098489740658F, 1.0F, 0.3407198427922246F);
        escalar(g0, "domo_16", 0.4650961814577954F, 1.0F, 0.26557104336787635F);
        escalar(g0, "domo_17", 0.4370472493156405F, 1.0F, 0.40615806323887843F);
        escalar(g0, "domo_18", 0.389263818730878F, 1.0F, 0.47999742628429265F);
        escalar(g0, "domo_19", 0.47090646312428F, 1.0F, 0.4252620691503627F);
        escalar(g0, "domo_20", 0.4694767975978107F, 1.0F, 0.45932250728457974F);
        escalar(g0, "domo_21", 0.4843337981633414F, 1.0F, 0.47558352437813955F);
        escalar(g0, "domo_22", 0.46024065356775673F, 1.0F, 0.3657120410167321F);
        escalar(g0, "domo_23", 0.43442126984823015F, 1.0F, 0.49366463741591843F);
        escalar(g0, "domo_24", 0.48288504282365957F, 1.0F, 0.4666459036994875F);
        escalar(g0, "domo_25", 0.40825774019851346F, 1.0F, 0.49590843245263716F);
        escalar(g0, "domo_26", 0.48984724621582654F, 1.0F, 0.5017106568967353F);
        escalar(g0, "domo_27", 0.47744241115046504F, 1.0F, 0.4607969155128215F);
        escalar(g0, "domo_28", 0.4835297321483054F, 1.0F, 0.2629056876943882F);
        escalar(g0, "domo_29", 0.4314057455907431F, 1.0F, 0.4716921986530581F);
        escalar(g0, "domo_30", 0.43797188986297514F, 1.0F, 0.4754873756077219F);
        escalar(g0, "domo_31", 0.4281975700377763F, 1.0F, 0.48559523550646755F);
        escalar(g0, "domo_32", 0.4571200134986675F, 1.0F, 0.4639396736227424F);
        escalar(g0, "domo_33", 0.3905584174218071F, 1.0F, 0.5008109163585032F);
        escalar(g0, "domo_34", 0.4318081580819384F, 1.0F, 0.43803942955008046F);
        escalar(g0, "domo_35", 0.4314057455907431F, 1.0F, 0.4716922131238845F);
        escalar(g0, "domo_36", 0.437971889862975F, 1.0F, 0.4754873901927247F);
        escalar(g0, "domo_37", 0.4281975700377763F, 1.0F, 0.48559525039607887F);
        escalar(g0, "domo_38", 0.45712001349866727F, 1.0F, 0.4639396878376235F);
        escalar(g0, "domo_39", 0.3905584174218069F, 1.0F, 0.5008109316755871F);
        escalar(g0, "domo_40", 0.43180815808193806F, 1.0F, 0.43803944281912904F);
        escalar(g0, "domo_41", 0.43442126984823026F, 1.0F, 0.4936646374159191F);
        escalar(g0, "domo_42", 0.48288504282365924F, 1.0F, 0.4666459036994881F);
        escalar(g0, "domo_43", 0.40825774019851346F, 1.0F, 0.4959084324526379F);
        escalar(g0, "domo_44", 0.4898472462158264F, 1.0F, 0.501710656896736F);
        escalar(g0, "domo_45", 0.4774424111504646F, 1.0F, 0.46079691551282237F);
        escalar(g0, "domo_46", 0.4835297321483051F, 1.0F, 0.2629056876943895F);
        escalar(g0, "domo_47", 0.43704724931564054F, 1.0F, 0.40615806323887893F);
        escalar(g0, "domo_48", 0.3892638187308779F, 1.0F, 0.4799974262842933F);
        escalar(g0, "domo_49", 0.47090646312428F, 1.0F, 0.42526206915036313F);
        escalar(g0, "domo_50", 0.4694767975978108F, 1.0F, 0.45932250728458035F);
        escalar(g0, "domo_51", 0.48433379816334116F, 1.0F, 0.47558352437813955F);
        escalar(g0, "domo_52", 0.4602406535677565F, 1.0F, 0.3657120410167304F);
        escalar(g0, "domo_53", 0.4391130820769371F, 1.0F, 0.48277762738573377F);
        escalar(g0, "domo_54", 0.4094121010713003F, 1.0F, 0.45654247747783394F);
        escalar(g0, "domo_55", 0.41193505164747996F, 1.0F, 0.4047019583337841F);
        escalar(g0, "domo_56", 0.43535347370258354F, 1.0F, 0.4923053027319515F);
        escalar(g0, "domo_57", 0.46510984897406576F, 1.0F, 0.34071984279222495F);
        escalar(g0, "domo_58", 0.46509618145779524F, 1.0F, 0.2655710433678779F);
        escalar(g0, "domo_59", 0.4404866139441485F, 1.0F, 0.37320321287479147F);
        escalar(g0, "domo_60", 0.42231923629826795F, 1.0F, 0.353005943687855F);
        escalar(g0, "domo_61", 0.43381064587102863F, 1.0F, 0.46964436795237385F);
        escalar(g0, "domo_62", 0.46240005201694595F, 1.0F, 0.3813052932329897F);
        escalar(g0, "domo_63", 0.4955825204175487F, 1.0F, 0.26460642358763775F);
        escalar(g0, "domo_64", 0.4410809592527418F, 1.0F, 0.4086354540211361F);
        escalar(g0, "domo_65", 0.42779420254742284F, 1.0F, 0.48292352513208303F);
        escalar(g0, "domo_66", 0.4429545776489106F, 1.0F, 0.4278509849807715F);
        escalar(g0, "domo_67", 0.473637902516641F, 1.0F, 0.46211097656964234F);
        escalar(g0, "domo_68", 0.44468906056643537F, 1.0F, 0.4784516313169288F);
        escalar(g0, "domo_69", 0.46264987071551755F, 1.0F, 0.3678417106715753F);
        escalar(g0, "domo_70", 0.4410809592527418F, 1.0F, 0.40863547134672834F);
        escalar(g0, "domo_71", 0.4277942025474232F, 1.0F, 0.4829235455957079F);
        escalar(g0, "domo_72", 0.4429545776489106F, 1.0F, 0.4278510030863124F);
        escalar(g0, "domo_73", 0.473637902516641F, 1.0F, 0.46211099607075723F);
        escalar(g0, "domo_74", 0.44468906056643537F, 1.0F, 0.47845165137498835F);
        escalar(g0, "domo_75", 0.46264987071551755F, 1.0F, 0.3678417255653856F);
        escalar(g0, "domo_76", 0.44048661394414834F, 1.0F, 0.37320321287479147F);
        escalar(g0, "domo_77", 0.42231923629826884F, 1.0F, 0.35300594368785454F);
        escalar(g0, "domo_78", 0.4338106458710283F, 1.0F, 0.46964436795237324F);
        escalar(g0, "domo_79", 0.4624000520169462F, 1.0F, 0.38130529323298906F);
        escalar(g0, "domo_80", 0.4955825204175487F, 1.0F, 0.2646064235876377F);
        escalar(g0, "domo_81", 0.4391130820769369F, 1.0F, 0.48277762738573404F);
        escalar(g0, "domo_82", 0.4094121010713012F, 1.0F, 0.45654247747783483F);
        escalar(g0, "domo_83", 0.41193505164747934F, 1.0F, 0.40470195833378425F);
        escalar(g0, "domo_84", 0.43535347370258376F, 1.0F, 0.4923053027319509F);
        escalar(g0, "domo_85", 0.465109848974066F, 1.0F, 0.3407198427922243F);
        escalar(g0, "domo_86", 0.46509618145779524F, 1.0F, 0.26557104336787807F);
        escalar(g0, "domo_87", 0.4370472493156405F, 1.0F, 0.40615806323887826F);
        escalar(g0, "domo_88", 0.38926381873087823F, 1.0F, 0.479997426284292F);
        escalar(g0, "domo_89", 0.47090646312427964F, 1.0F, 0.4252620691503618F);
        escalar(g0, "domo_90", 0.469476797597811F, 1.0F, 0.45932250728457974F);
        escalar(g0, "domo_91", 0.4843337981633417F, 1.0F, 0.47558352437813955F);
        escalar(g0, "domo_92", 0.4602406535677565F, 1.0F, 0.3657120410167303F);
        escalar(g0, "domo_93", 0.4344212698482302F, 1.0F, 0.49366463741591726F);
        escalar(g0, "domo_94", 0.48288504282365957F, 1.0F, 0.4666459036994866F);
        escalar(g0, "domo_95", 0.40825774019851346F, 1.0F, 0.4959084324526365F);
        escalar(g0, "domo_96", 0.48984724621582715F, 1.0F, 0.5017106568967342F);
        escalar(g0, "domo_97", 0.47744241115046526F, 1.0F, 0.46079691551282F);
        escalar(g0, "domo_98", 0.48352973214830547F, 1.0F, 0.2629056876943877F);
        escalar(g0, "domo_99", 0.4314057455907431F, 1.0F, 0.4716921933563684F);
        escalar(g0, "domo_100", 0.43797188986297525F, 1.0F, 0.4754873702692406F);
        escalar(g0, "domo_101", 0.4281975700377763F, 1.0F, 0.48559523005649186F);
        escalar(g0, "domo_102", 0.45712001349866777F, 1.0F, 0.4639396684197354F);
        escalar(g0, "domo_103", 0.3905584174218074F, 1.0F, 0.500810910752062F);
        escalar(g0, "domo_104", 0.43180815808193884F, 1.0F, 0.43803942469327234F);
        escalar(g0, "domo_105", 0.431405745590743F, 1.0F, 0.4716922184205747F);
        escalar(g0, "domo_106", 0.43797188986297514F, 1.0F, 0.4754873955312065F);
        escalar(g0, "domo_107", 0.42819757003777603F, 1.0F, 0.48559525584605506F);
        escalar(g0, "domo_108", 0.4571200134986673F, 1.0F, 0.46393969304063115F);
        escalar(g0, "domo_109", 0.39055841742180697F, 1.0F, 0.5008109372820289F);
        escalar(g0, "domo_110", 0.43180815808193823F, 1.0F, 0.4380394476759377F);
        escalar(g0, "domo_111", 0.43442126984823015F, 1.0F, 0.4936646374159188F);
        escalar(g0, "domo_112", 0.48288504282365935F, 1.0F, 0.46664590369948766F);
        escalar(g0, "domo_113", 0.40825774019851313F, 1.0F, 0.49590843245263755F);
        escalar(g0, "domo_114", 0.4898472462158264F, 1.0F, 0.5017106568967356F);
        escalar(g0, "domo_115", 0.4774424111504648F, 1.0F, 0.4607969155128215F);
        escalar(g0, "domo_116", 0.48352973214830497F, 1.0F, 0.2629056876943882F);
        escalar(g0, "domo_117", 0.43704724931564054F, 1.0F, 0.4061580632388793F);
        escalar(g0, "domo_118", 0.3892638187308778F, 1.0F, 0.479997426284294F);
        escalar(g0, "domo_119", 0.47090646312427986F, 1.0F, 0.4252620691503638F);
        escalar(g0, "domo_120", 0.4694767975978108F, 1.0F, 0.45932250728458096F);
        escalar(g0, "domo_121", 0.4843337981633413F, 1.0F, 0.4755835243781409F);
        escalar(g0, "domo_122", 0.4602406535677564F, 1.0F, 0.365712041016733F);
        escalar(g0, "domo_123", 0.439113082076937F, 1.0F, 0.48277762738573377F);
        escalar(g0, "domo_124", 0.4094121010713003F, 1.0F, 0.45654247747783394F);
        escalar(g0, "domo_125", 0.41193505164747996F, 1.0F, 0.4047019583337835F);
        escalar(g0, "domo_126", 0.4353534737025834F, 1.0F, 0.4923053027319511F);
        escalar(g0, "domo_127", 0.4651098489740659F, 1.0F, 0.3407198427922245F);
        escalar(g0, "domo_128", 0.46509618145779524F, 1.0F, 0.26557104336787624F);
        escalar(g0, "domo_129", 0.44048661394414845F, 1.0F, 0.3732032128747913F);
        escalar(g0, "domo_130", 0.4223192362982683F, 1.0F, 0.35300594368785454F);
        escalar(g0, "domo_131", 0.43381064587102874F, 1.0F, 0.46964436795237297F);
        escalar(g0, "domo_132", 0.4624000520169456F, 1.0F, 0.38130529323298856F);
        escalar(g0, "domo_133", 0.4955825204175488F, 1.0F, 0.2646064235876371F);
        escalar(g0, "domo_134", 0.44108095925274177F, 1.0F, 0.4086354504328888F);
        escalar(g0, "domo_135", 0.4277942025474232F, 1.0F, 0.482923520893928F);
        escalar(g0, "domo_136", 0.4429545776489109F, 1.0F, 0.4278509812309916F);
        escalar(g0, "domo_137", 0.4736379025166407F, 1.0F, 0.46211097253082967F);
        escalar(g0, "domo_138", 0.44468906056643537F, 1.0F, 0.4784516271627692F);
        escalar(g0, "domo_139", 0.4626498707155175F, 1.0F, 0.3678417075869666F);
        escalar(g0, "silbato_0", 0.1077859454596501F, 1.0F, 0.1077859454596501F);
        escalar(g0, "silbato_1", 0.1077859454596501F, 1.0F, 0.1077859454596501F);
        escalar(g0, "deflectori", 0.5F, 0.5F, 1.0F);
        escalar(g0, "deflectord", 0.5F, 0.5F, 1.0F);
        escalar(g0, "cabina_techo_0", 1.0008695652173913F, 1.0F, 0.7308905619357534F);
        escalar(g0, "cabina_techo_1", 1.0008695652173913F, 1.0F, 0.7308905619357519F);
        escalar(g0, "cabina_techo_2", 1.0008695652173913F, 1.0F, 0.7308905619357532F);
        escalar(g0, "cabina_techo_3", 1.0008695652173913F, 1.0F, 0.7308905619357526F);
        escalar(g0, "cabina_techo_4", 1.0008695652173913F, 1.0F, 0.7308905619357526F);
        escalar(g0, "cabina_techo_5", 1.0008695652173913F, 1.0F, 0.7308905619357532F);
        escalar(g0, "cabina_techo_6", 1.0008695652173913F, 1.0F, 0.7308905619357522F);
        escalar(g0, "cabina_techo_7", 1.0008695652173913F, 1.0F, 0.7308905619357531F);
        escalar(g0, "cabina_techo_8", 1.0008695652173913F, 1.0F, 0.7308905619357532F);
        escalar(g0, "cabina_techo_9", 1.0008695652173913F, 1.0F, 0.7308905619357526F);
        escalar(g0, "cabina_techo_10", 1.0008695652173913F, 1.0F, 0.7308905619357525F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1) {
        escalar(g0, "cabina_techo_11", 1.0008695652173913F, 1.0F, 0.7308905619357534F);
        escalar(g0, "numeroi", 0.5F, 0.5F, 1.0F);
        escalar(g0, "numerod", 0.5F, 0.5F, 1.0F);
        escalar(g0, "cab_velocimetro", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.656F, 0.6F);
        escalar(g0, "cab_presion", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "cab_presion_aguja", 0.3F, 0.656F, 0.6F);
        escalar(g0, "cab_regulador", 0.8F, 0.9013878188659974F, 0.8F);
        escalar(g0, "cab_tubo", 0.6F, 0.9375F, 0.6F);
        escalar(g0, "cab_freno_manija", 0.6F, 1.0F, 0.6F);
        escalar(g1, "tender_caja_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantoi_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g1, "tender_caja_cantoi_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g1, "tender_caja_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g1, "tender_caja_cantoi_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_cantod_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g1, "tender_caja_cantod_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g1, "tender_caja_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g1, "tender_caja_cantod_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g1, "tender_caja_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tender_caja_tapab", 1.0F, 0.5F, 0.5F);
    }
}
