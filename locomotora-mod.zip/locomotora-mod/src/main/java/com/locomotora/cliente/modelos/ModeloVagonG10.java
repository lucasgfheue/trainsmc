package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Vagón cerrado G10" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonG10 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_g10"), "main"),
            LocomotoraMod.id("textures/entity/vagon_g10.png"),
            List.of(
                new DatosModelo.Animada("ri0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("ri1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloVagonG10::crearCapa,
            16.0F,
            ModeloVagonG10::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -16.0F, 16.0F)));

    private ModeloVagonG10() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("costadoi", CubeListBuilder.create().texOffs(92, 0).addBox(0.0F, -42.0F, 0.0F, 100.0F, 42.0F, 2.0F), PartPose.offset(-29.0F, -12.0F, -12.0F));
        g.addOrReplaceChild("costadod", CubeListBuilder.create().texOffs(296, 0).addBox(0.0F, -42.0F, 0.0F, 100.0F, 42.0F, 2.0F), PartPose.offset(-29.0F, -12.0F, 11.0F));
        g.addOrReplaceChild("techo_0", CubeListBuilder.create().texOffs(820, 80).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -33.52609684408834F, -11.994762109287546F, -2.659435645508107F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_1", CubeListBuilder.create().texOffs(0, 100).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -34.48825900468931F, -9.942085367845145F, -2.7471005560684154F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_2", CubeListBuilder.create().texOffs(108, 100).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -35.26700903430607F, -7.813051263016664F, -2.834765466628719F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_3", CubeListBuilder.create().texOffs(216, 100).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -35.85636596447996F, -5.6240112366564965F, -2.922430377189028F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_4", CubeListBuilder.create().texOffs(324, 100).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -36.251803406670106F, -3.3917775890593127F, -3.0100952877493325F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_5", CubeListBuilder.create().texOffs(432, 100).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -36.450284315895246F, -1.1334943568618812F, -3.0977601983096403F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_6", CubeListBuilder.create().texOffs(540, 100).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -36.450284315895246F, 1.13349435686188F, 3.0977601983096403F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_7", CubeListBuilder.create().texOffs(648, 100).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -36.251803406670106F, 3.391777589059311F, 3.0100952877493325F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_8", CubeListBuilder.create().texOffs(756, 100).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -35.85636596447996F, 5.624011236656496F, 2.922430377189028F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_9", CubeListBuilder.create().texOffs(864, 100).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -35.26700903430607F, 7.813051263016662F, 2.8347654666287188F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_10", CubeListBuilder.create().texOffs(0, 104).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -34.48825900468931F, 9.942085367845143F, 2.7471005560684163F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_11", CubeListBuilder.create().texOffs(108, 104).addBox(-25.5F, -1.0F, -1.5F, 51.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.5F, -33.52609684408834F, 11.994762109287546F, 2.659435645508107F, 0.0F, 0.0F));
        g.addOrReplaceChild("punta_a", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -25.0F, 0.0F, 1.0F, 25.0F, 22.0F), PartPose.offset(-29.0F, -12.0F, -11.0F));
        g.addOrReplaceChild("punta_b", CubeListBuilder.create().texOffs(46, 0).addBox(0.0F, -25.0F, 0.0F, 1.0F, 25.0F, 22.0F), PartPose.offset(20.0F, -12.0F, -11.0F));
        g.addOrReplaceChild("piso", CubeListBuilder.create().texOffs(678, 47).addBox(-28.0F, -12.0F, -11.0F, 49.0F, 1.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("armazon", CubeListBuilder.create().texOffs(106, 80).addBox(-29.0F, -32.0F, -13.0F, 1.0F, 19.0F, 1.0F).texOffs(110, 80).addBox(-21.0F, -32.0F, -13.0F, 1.0F, 19.0F, 1.0F).texOffs(114, 80).addBox(-13.0F, -32.0F, -13.0F, 1.0F, 19.0F, 1.0F).texOffs(118, 80).addBox(4.0F, -32.0F, -13.0F, 1.0F, 19.0F, 1.0F).texOffs(122, 80).addBox(12.0F, -32.0F, -13.0F, 1.0F, 19.0F, 1.0F).texOffs(126, 80).addBox(20.0F, -32.0F, -13.0F, 1.0F, 19.0F, 1.0F).texOffs(758, 104).addBox(-29.0F, -13.0F, -13.0F, 50.0F, 1.0F, 1.0F).texOffs(860, 104).addBox(-29.0F, -33.0F, -13.0F, 50.0F, 1.0F, 1.0F).texOffs(130, 80).addBox(-29.0F, -32.0F, 12.0F, 1.0F, 19.0F, 1.0F).texOffs(134, 80).addBox(-21.0F, -32.0F, 12.0F, 1.0F, 19.0F, 1.0F).texOffs(138, 80).addBox(-13.0F, -32.0F, 12.0F, 1.0F, 19.0F, 1.0F).texOffs(142, 80).addBox(4.0F, -32.0F, 12.0F, 1.0F, 19.0F, 1.0F).texOffs(146, 80).addBox(12.0F, -32.0F, 12.0F, 1.0F, 19.0F, 1.0F).texOffs(150, 80).addBox(20.0F, -32.0F, 12.0F, 1.0F, 19.0F, 1.0F).texOffs(0, 108).addBox(-29.0F, -13.0F, 12.0F, 50.0F, 1.0F, 1.0F).texOffs(102, 108).addBox(-29.0F, -33.0F, 12.0F, 50.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("riostrai0", CubeListBuilder.create().texOffs(876, 47).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 20.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -31.5F, -12.5F, 0.0F, 0.0F, -0.37089128881266237F));
        g.addOrReplaceChild("riostrai1", CubeListBuilder.create().texOffs(880, 47).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 20.0F, 1.0F), PartPose.offsetAndRotation(5.0F, -13.5F, -12.5F, 0.0F, 0.0F, -2.770701364777131F));
        g.addOrReplaceChild("riostrad0", CubeListBuilder.create().texOffs(884, 47).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 20.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -31.5F, 12.5F, 0.0F, 0.0F, -0.37089128881266237F));
        g.addOrReplaceChild("riostrad1", CubeListBuilder.create().texOffs(888, 47).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 20.0F, 1.0F), PartPose.offsetAndRotation(5.0F, -13.5F, 12.5F, 0.0F, 0.0F, -2.770701364777131F));
        g.addOrReplaceChild("puertas", CubeListBuilder.create().texOffs(38, 80).addBox(-12.0F, -32.0F, -14.0F, 16.0F, 19.0F, 1.0F).texOffs(204, 108).addBox(-13.0F, -33.0F, -14.0F, 34.0F, 1.0F, 1.0F).texOffs(274, 108).addBox(-13.0F, -13.0F, -14.0F, 34.0F, 1.0F, 1.0F).texOffs(72, 80).addBox(-12.0F, -32.0F, 13.0F, 16.0F, 19.0F, 1.0F).texOffs(344, 108).addBox(-13.0F, -33.0F, 13.0F, 34.0F, 1.0F, 1.0F).texOffs(414, 108).addBox(-13.0F, -13.0F, 13.0F, 34.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("puerta_riostrai", CubeListBuilder.create().texOffs(670, 47).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 23.0F, 1.0F), PartPose.offsetAndRotation(-11.0F, -13.5F, -14.5F, 0.0F, 0.0F, -2.4805494847391065F));
        g.addOrReplaceChild("puerta_riostrad", CubeListBuilder.create().texOffs(674, 47).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 23.0F, 1.0F), PartPose.offsetAndRotation(-11.0F, -13.5F, 14.5F, 0.0F, 0.0F, -2.4805494847391065F));
        g.addOrReplaceChild("ventilas", CubeListBuilder.create().texOffs(462, 104).addBox(-27.5F, -30.0F, -13.0F, 3.0F, 3.0F, 1.0F).texOffs(470, 104).addBox(-27.5F, -30.0F, 12.0F, 3.0F, 3.0F, 1.0F).texOffs(478, 104).addBox(14.0F, -30.0F, -13.0F, 3.0F, 3.0F, 1.0F).texOffs(486, 104).addBox(14.0F, -30.0F, 12.0F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("casilla", CubeListBuilder.create().texOffs(634, 47).addBox(21.0F, -35.0F, 9.0F, 8.0F, 23.0F, 1.0F).texOffs(652, 47).addBox(21.0F, -35.0F, -10.0F, 8.0F, 23.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("casilla_techo_0", CubeListBuilder.create().texOffs(216, 104).addBox(-4.5F, -1.0F, -1.5F, 9.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.0F, -35.54123417329881F, -9.251486569393718F, -2.732542087069215F, 0.0F, 0.0F));
        g.addOrReplaceChild("casilla_techo_1", CubeListBuilder.create().texOffs(240, 104).addBox(-4.5F, -1.0F, -1.5F, 9.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.0F, -36.47442657438334F, -6.69986571250908F, -2.8494136775036663F, 0.0F, 0.0F));
        g.addOrReplaceChild("casilla_techo_2", CubeListBuilder.create().texOffs(264, 104).addBox(-4.5F, -1.0F, -1.5F, 9.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.0F, -37.10371943040853F, -4.056835717203268F, -2.966285267938116F, 0.0F, 0.0F));
        g.addOrReplaceChild("casilla_techo_3", CubeListBuilder.create().texOffs(288, 104).addBox(-4.5F, -1.0F, -1.5F, 9.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.0F, -37.420527029324006F, -1.3584565740879049F, -3.0831568583725697F, 0.0F, 0.0F));
        g.addOrReplaceChild("casilla_techo_4", CubeListBuilder.create().texOffs(312, 104).addBox(-4.5F, -1.0F, -1.5F, 9.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.0F, -37.420527029324006F, 1.3584565740879049F, 3.0831568583725697F, 0.0F, 0.0F));
        g.addOrReplaceChild("casilla_techo_5", CubeListBuilder.create().texOffs(336, 104).addBox(-4.5F, -1.0F, -1.5F, 9.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.0F, -37.10371943040853F, 4.056835717203268F, 2.966285267938116F, 0.0F, 0.0F));
        g.addOrReplaceChild("casilla_techo_6", CubeListBuilder.create().texOffs(360, 104).addBox(-4.5F, -1.0F, -1.5F, 9.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.0F, -36.47442657438334F, 6.69986571250908F, 2.8494136775036663F, 0.0F, 0.0F));
        g.addOrReplaceChild("casilla_techo_7", CubeListBuilder.create().texOffs(384, 104).addBox(-4.5F, -1.0F, -1.5F, 9.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(25.0F, -35.54123417329881F, 9.251486569393718F, 2.732542087069215F, 0.0F, 0.0F));
        g.addOrReplaceChild("casilla_frente", CubeListBuilder.create().texOffs(500, 0).addBox(0.0F, -26.0F, 0.0F, 1.0F, 26.0F, 18.0F), PartPose.offset(21.0F, -12.0F, -9.0F));
        g.addOrReplaceChild("casilla_fondo", CubeListBuilder.create().texOffs(538, 0).addBox(0.0F, -26.0F, 0.0F, 1.0F, 26.0F, 18.0F), PartPose.offset(28.0F, -12.0F, -9.0F));
        g.addOrReplaceChild("casilla_piso", CubeListBuilder.create().texOffs(820, 47).addBox(21.0F, -12.0F, -10.0F, 8.0F, 1.0F, 20.0F).texOffs(214, 80).addBox(26.0F, -26.0F, -0.5F, 1.0F, 14.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("volante", CubeListBuilder.create().texOffs(154, 80).addBox(-7.5F, 0.0F, -7.5F, 15.0F, 1.0F, 15.0F), PartPose.offsetAndRotation(26.5F, -26.3F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(522, 104).addBox(-29.0F, -11.0F, 9.0F, 58.0F, 2.0F, 1.0F).texOffs(640, 104).addBox(-29.0F, -11.0F, -10.0F, 58.0F, 2.0F, 1.0F).texOffs(892, 47).addBox(-22.5F, -11.0F, -9.0F, 1.0F, 2.0F, 18.0F).texOffs(930, 47).addBox(-6.5F, -11.0F, -9.0F, 1.0F, 2.0F, 18.0F).texOffs(968, 47).addBox(5.5F, -11.0F, -9.0F, 1.0F, 2.0F, 18.0F).texOffs(0, 80).addBox(21.5F, -11.0F, -9.0F, 1.0F, 2.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("ri0_0", CubeListBuilder.create().texOffs(666, 80).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(408, 104).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(684, 80).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(740, 80).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-16.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("ri0_1", CubeListBuilder.create().texOffs(426, 104).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 80).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri0_2", CubeListBuilder.create().texOffs(444, 104).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(700, 80).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ri1_0", CubeListBuilder.create().texOffs(666, 80).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(408, 104).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(684, 80).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(750, 80).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(16.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("ri1_1", CubeListBuilder.create().texOffs(426, 104).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 80).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri1_2", CubeListBuilder.create().texOffs(444, 104).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(700, 80).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd0_0", CubeListBuilder.create().texOffs(666, 80).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(408, 104).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(684, 80).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(760, 80).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-16.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rd0_1", CubeListBuilder.create().texOffs(426, 104).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 80).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd0_2", CubeListBuilder.create().texOffs(444, 104).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(700, 80).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd1_0", CubeListBuilder.create().texOffs(666, 80).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(408, 104).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(684, 80).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(770, 80).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(16.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rd1_1", CubeListBuilder.create().texOffs(426, 104).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 80).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd1_2", CubeListBuilder.create().texOffs(444, 104).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(700, 80).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("r_suspension", CubeListBuilder.create().texOffs(780, 80).addBox(-17.5F, -5.0F, -10.5F, 3.0F, 3.0F, 2.0F).texOffs(708, 80).addBox(-18.5F, -9.0F, -9.8F, 1.0F, 7.0F, 1.0F).texOffs(712, 80).addBox(-14.5F, -9.0F, -9.8F, 1.0F, 7.0F, 1.0F).texOffs(644, 108).addBox(-17.5F, -6.0F, -10.0F, 3.0F, 1.0F, 1.0F).texOffs(580, 108).addBox(-19.5F, -7.0F, -10.0F, 7.0F, 1.0F, 1.0F).texOffs(484, 108).addBox(-21.5F, -8.0F, -10.0F, 11.0F, 1.0F, 1.0F).texOffs(676, 108).addBox(-21.5F, -9.0F, -10.0F, 1.0F, 1.0F, 1.0F).texOffs(680, 108).addBox(-11.5F, -9.0F, -10.0F, 1.0F, 1.0F, 1.0F).texOffs(506, 104).addBox(-12.5F, -5.0F, -5.5F, 1.0F, 3.0F, 1.0F).texOffs(790, 80).addBox(14.5F, -5.0F, -10.5F, 3.0F, 3.0F, 2.0F).texOffs(716, 80).addBox(13.5F, -9.0F, -9.8F, 1.0F, 7.0F, 1.0F).texOffs(720, 80).addBox(17.5F, -9.0F, -9.8F, 1.0F, 7.0F, 1.0F).texOffs(652, 108).addBox(14.5F, -6.0F, -10.0F, 3.0F, 1.0F, 1.0F).texOffs(596, 108).addBox(12.5F, -7.0F, -10.0F, 7.0F, 1.0F, 1.0F).texOffs(508, 108).addBox(10.5F, -8.0F, -10.0F, 11.0F, 1.0F, 1.0F).texOffs(684, 108).addBox(10.5F, -9.0F, -10.0F, 1.0F, 1.0F, 1.0F).texOffs(688, 108).addBox(20.5F, -9.0F, -10.0F, 1.0F, 1.0F, 1.0F).texOffs(510, 104).addBox(11.5F, -5.0F, -5.5F, 1.0F, 3.0F, 1.0F).texOffs(800, 80).addBox(-17.5F, -5.0F, 8.5F, 3.0F, 3.0F, 2.0F).texOffs(724, 80).addBox(-18.5F, -9.0F, 8.8F, 1.0F, 7.0F, 1.0F).texOffs(728, 80).addBox(-14.5F, -9.0F, 8.8F, 1.0F, 7.0F, 1.0F).texOffs(660, 108).addBox(-17.5F, -6.0F, 9.0F, 3.0F, 1.0F, 1.0F).texOffs(612, 108).addBox(-19.5F, -7.0F, 9.0F, 7.0F, 1.0F, 1.0F).texOffs(532, 108).addBox(-21.5F, -8.0F, 9.0F, 11.0F, 1.0F, 1.0F).texOffs(692, 108).addBox(-21.5F, -9.0F, 9.0F, 1.0F, 1.0F, 1.0F).texOffs(696, 108).addBox(-11.5F, -9.0F, 9.0F, 1.0F, 1.0F, 1.0F).texOffs(514, 104).addBox(-12.5F, -5.0F, 4.5F, 1.0F, 3.0F, 1.0F).texOffs(810, 80).addBox(14.5F, -5.0F, 8.5F, 3.0F, 3.0F, 2.0F).texOffs(732, 80).addBox(13.5F, -9.0F, 8.8F, 1.0F, 7.0F, 1.0F).texOffs(736, 80).addBox(17.5F, -9.0F, 8.8F, 1.0F, 7.0F, 1.0F).texOffs(668, 108).addBox(14.5F, -6.0F, 9.0F, 3.0F, 1.0F, 1.0F).texOffs(628, 108).addBox(12.5F, -7.0F, 9.0F, 7.0F, 1.0F, 1.0F).texOffs(556, 108).addBox(10.5F, -8.0F, 9.0F, 11.0F, 1.0F, 1.0F).texOffs(700, 108).addBox(10.5F, -9.0F, 9.0F, 1.0F, 1.0F, 1.0F).texOffs(704, 108).addBox(20.5F, -9.0F, 9.0F, 1.0F, 1.0F, 1.0F).texOffs(518, 104).addBox(11.5F, -5.0F, 4.5F, 1.0F, 3.0F, 1.0F).texOffs(530, 47).addBox(-31.0F, -11.0F, -12.0F, 2.0F, 3.0F, 24.0F).texOffs(494, 104).addBox(-33.0F, -11.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(582, 47).addBox(29.0F, -11.0F, -12.0F, 2.0F, 3.0F, 24.0F).texOffs(500, 104).addBox(31.0F, -11.0F, -0.5F, 2.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topefi_0", CubeListBuilder.create().texOffs(290, 47).addBox(-34.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(576, 0).addBox(-34.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -9.5F, -8.5F));
        g.addOrReplaceChild("topefi_1", CubeListBuilder.create().texOffs(310, 47).addBox(-34.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(634, 0).addBox(-34.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefi_2", CubeListBuilder.create().texOffs(330, 47).addBox(-34.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(692, 0).addBox(-34.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_0", CubeListBuilder.create().texOffs(570, 80).addBox(-35.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(218, 80).addBox(-35.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, -8.5F));
        g.addOrReplaceChild("topefic_1", CubeListBuilder.create().texOffs(576, 80).addBox(-35.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(240, 80).addBox(-35.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_2", CubeListBuilder.create().texOffs(582, 80).addBox(-35.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(262, 80).addBox(-35.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_3", CubeListBuilder.create().texOffs(588, 80).addBox(-35.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(284, 80).addBox(-35.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_0", CubeListBuilder.create().texOffs(350, 47).addBox(-34.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(750, 0).addBox(-34.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -9.5F, 8.5F));
        g.addOrReplaceChild("topefd_1", CubeListBuilder.create().texOffs(370, 47).addBox(-34.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(808, 0).addBox(-34.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_2", CubeListBuilder.create().texOffs(390, 47).addBox(-34.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(866, 0).addBox(-34.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_0", CubeListBuilder.create().texOffs(594, 80).addBox(-35.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(306, 80).addBox(-35.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, 8.5F));
        g.addOrReplaceChild("topefdc_1", CubeListBuilder.create().texOffs(600, 80).addBox(-35.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(328, 80).addBox(-35.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_2", CubeListBuilder.create().texOffs(606, 80).addBox(-35.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(350, 80).addBox(-35.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_3", CubeListBuilder.create().texOffs(612, 80).addBox(-35.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(372, 80).addBox(-35.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_0", CubeListBuilder.create().texOffs(410, 47).addBox(31.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(924, 0).addBox(31.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -9.5F, -8.5F));
        g.addOrReplaceChild("topeti_1", CubeListBuilder.create().texOffs(430, 47).addBox(31.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(0, 47).addBox(31.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_2", CubeListBuilder.create().texOffs(450, 47).addBox(31.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(58, 47).addBox(31.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_0", CubeListBuilder.create().texOffs(618, 80).addBox(34.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(394, 80).addBox(34.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, -8.5F));
        g.addOrReplaceChild("topetic_1", CubeListBuilder.create().texOffs(624, 80).addBox(34.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(416, 80).addBox(34.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_2", CubeListBuilder.create().texOffs(630, 80).addBox(34.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(438, 80).addBox(34.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_3", CubeListBuilder.create().texOffs(636, 80).addBox(34.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(460, 80).addBox(34.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_0", CubeListBuilder.create().texOffs(470, 47).addBox(31.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(116, 47).addBox(31.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -9.5F, 8.5F));
        g.addOrReplaceChild("topetd_1", CubeListBuilder.create().texOffs(490, 47).addBox(31.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(174, 47).addBox(31.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_2", CubeListBuilder.create().texOffs(510, 47).addBox(31.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(232, 47).addBox(31.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_0", CubeListBuilder.create().texOffs(642, 80).addBox(34.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(482, 80).addBox(34.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, 8.5F));
        g.addOrReplaceChild("topetdc_1", CubeListBuilder.create().texOffs(648, 80).addBox(34.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(504, 80).addBox(34.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_2", CubeListBuilder.create().texOffs(654, 80).addBox(34.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(526, 80).addBox(34.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_3", CubeListBuilder.create().texOffs(660, 80).addBox(34.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(548, 80).addBox(34.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "costadoi", 0.5F, 0.5F, 0.5F);
        escalar(g0, "costadod", 0.5F, 0.5F, 0.5F);
        escalar(g0, "techo_0", 1.0003921568627452F, 1.0F, 0.7630560743966424F);
        escalar(g0, "techo_1", 1.0003921568627452F, 1.0F, 0.7630560743966416F);
        escalar(g0, "techo_2", 1.0003921568627452F, 1.0F, 0.7630560743966428F);
        escalar(g0, "techo_3", 1.0003921568627452F, 1.0F, 0.763056074396642F);
        escalar(g0, "techo_4", 1.0003921568627452F, 1.0F, 0.7630560743966422F);
        escalar(g0, "techo_5", 1.0003921568627452F, 1.0F, 0.7630560743966425F);
        escalar(g0, "techo_6", 1.0003921568627452F, 1.0F, 0.7630560743966416F);
        escalar(g0, "techo_7", 1.0003921568627452F, 1.0F, 0.7630560743966428F);
        escalar(g0, "techo_8", 1.0003921568627452F, 1.0F, 0.7630560743966424F);
        escalar(g0, "techo_9", 1.0003921568627452F, 1.0F, 0.7630560743966416F);
        escalar(g0, "techo_10", 1.0003921568627452F, 1.0F, 0.7630560743966428F);
        escalar(g0, "techo_11", 1.0003921568627452F, 1.0F, 0.7630560743966424F);
        escalar(g0, "riostrai0", 1.0F, 0.9656603957913983F, 1.0F);
        escalar(g0, "riostrai1", 1.0F, 0.9656603957913983F, 1.0F);
        escalar(g0, "riostrad0", 1.0F, 0.9656603957913983F, 1.0F);
        escalar(g0, "riostrad1", 1.0F, 0.9656603957913983F, 1.0F);
        escalar(g0, "puerta_riostrai", 1.0F, 0.9914568913905547F, 1.0F);
        escalar(g0, "puerta_riostrad", 1.0F, 0.9914568913905547F, 1.0F);
        escalar(g0, "casilla_techo_0", 1.0022222222222221F, 1.0F, 0.9138528454636751F);
        escalar(g0, "casilla_techo_1", 1.0022222222222221F, 1.0F, 0.9138528454636755F);
        escalar(g0, "casilla_techo_2", 1.0022222222222221F, 1.0F, 0.9138528454636751F);
        escalar(g0, "casilla_techo_3", 1.0022222222222221F, 1.0F, 0.9138528454636751F);
        escalar(g0, "casilla_techo_4", 1.0022222222222221F, 1.0F, 0.9138528454636751F);
        escalar(g0, "casilla_techo_5", 1.0022222222222221F, 1.0F, 0.9138528454636751F);
        escalar(g0, "casilla_techo_6", 1.0022222222222221F, 1.0F, 0.9138528454636755F);
        escalar(g0, "casilla_techo_7", 1.0022222222222221F, 1.0F, 0.9138528454636751F);
        escalar(g0, "volante", 0.24000000000000002F, 0.6F, 0.24000000000000002F);
        escalar(g0, "topefi_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topeti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
    }
}
