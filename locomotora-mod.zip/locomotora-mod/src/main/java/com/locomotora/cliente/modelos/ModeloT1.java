package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "PRR T1" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloT1 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("t1"), "main"),
            LocomotoraMod.id("textures/entity/t1.png"),
            List.of(
                new DatosModelo.Animada("fermi0_0", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -52.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("fermi0_1", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -52.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("fermi0_2", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -52.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("fermi1_0", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -32.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("fermi1_1", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -32.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("fermi1_2", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -32.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("febiela_i", DatosModelo.BIELA, 9.0F, 3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("femotriz_i", DatosModelo.MOTRIZ, 9.0F, 3.0F, 0.0F, -32.0F, -32.0F, -12.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("fecruceta_i", DatosModelo.CRUCETA, 9.0F, 3.0F, 0.0F, -32.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("fermd0_0", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -52.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("fermd0_1", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -52.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("fermd0_2", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -52.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("fermd1_0", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -32.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("fermd1_1", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -32.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("fermd1_2", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -32.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("febiela_d", DatosModelo.BIELA, 9.0F, 3.0F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("femotriz_d", DatosModelo.MOTRIZ, 9.0F, 3.0F, 1.5707963267948966F, -32.0F, -32.0F, -12.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("fecruceta_d", DatosModelo.CRUCETA, 9.0F, 3.0F, 1.5707963267948966F, -32.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermi0_0", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -8.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermi0_1", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -8.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermi0_2", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, -8.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rermi1_0", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, 12.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermi1_1", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, 12.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermi1_2", DatosModelo.RUEDA, 9.0F, 0.0F, 0.0F, 0.0F, 12.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rebiela_i", DatosModelo.BIELA, 9.0F, 3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("remotriz_i", DatosModelo.MOTRIZ, 9.0F, 3.0F, 0.0F, 32.0F, -8.0F, -12.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("recruceta_i", DatosModelo.CRUCETA, 9.0F, 3.0F, 0.0F, 32.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermd0_0", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermd0_1", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermd0_2", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rermd1_0", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, 12.0F, -9.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermd1_1", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, 12.0F, -9.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermd1_2", DatosModelo.RUEDA, 9.0F, 0.0F, 1.5707963267948966F, 0.0F, 12.0F, -9.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rebiela_d", DatosModelo.BIELA, 9.0F, 3.0F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("remotriz_d", DatosModelo.MOTRIZ, 9.0F, 3.0F, 1.5707963267948966F, 32.0F, -8.0F, -12.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("recruceta_d", DatosModelo.CRUCETA, 9.0F, 3.0F, 1.5707963267948966F, 32.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -96.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -96.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -96.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -84.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -84.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -84.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -96.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -96.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -96.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -84.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -84.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -84.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 92.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 92.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 92.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 164.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 164.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 164.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 176.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 176.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 176.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 188.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 188.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 188.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 92.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 92.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 92.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 104.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 116.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 164.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 164.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 164.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 176.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 176.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 176.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 188.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 188.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 188.0F, -4.5F, 1.0471975511965976F, "tender")),
            ModeloT1::crearCapa,
            16.0F,
            ModeloT1::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -90.0F, 58.0F),
                new DatosModelo.Segmento("tender", 104.0F, 176.0F)));

    private ModeloT1() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        piezas5(g0);
        piezas6(g0);
        piezas7(g0);
        piezas8(g1);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
        escalas2(g0, g1);
        escalas3(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("fermi0_0", CubeListBuilder.create().texOffs(284, 62).addBox(-9.0F, -9.0F, -6.0F, 18.0F, 18.0F, 2.0F).texOffs(70, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(364, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(416, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(426, 356).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-52.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("fermi0_1", CubeListBuilder.create().texOffs(108, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(378, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-52.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermi0_2", CubeListBuilder.create().texOffs(146, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-52.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fermi1_0", CubeListBuilder.create().texOffs(284, 62).addBox(-9.0F, -9.0F, -6.0F, 18.0F, 18.0F, 2.0F).texOffs(70, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(364, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(426, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(432, 356).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-32.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("fermi1_1", CubeListBuilder.create().texOffs(108, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(378, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermi1_2", CubeListBuilder.create().texOffs(146, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("febiela_i", CubeListBuilder.create().texOffs(738, 356).addBox(-52.0F, -12.5F, -7.5F, 20.0F, 1.0F, 1.0F).texOffs(912, 337).addBox(-53.5F, -13.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(920, 337).addBox(-33.5F, -13.5F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("femotriz_i", CubeListBuilder.create().texOffs(474, 356).addBox(-32.0F, -0.5F, -0.5F, 32.0F, 1.0F, 1.0F).texOffs(928, 337).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(-32.0F, -12.0F, -8.5F));
        g.addOrReplaceChild("fecruceta_i", CubeListBuilder.create().texOffs(436, 324).addBox(-65.35906464414798F, -10.5F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(150, 359).addBox(-73.85906464414798F, -9.5F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("feguias_i", CubeListBuilder.create().texOffs(906, 356).addBox(-70.85906464414798F, -7.5F, -9.0F, 14.0F, 1.0F, 1.0F).texOffs(936, 356).addBox(-70.85906464414798F, -11.5F, -9.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fecil_i_0", CubeListBuilder.create().texOffs(44, 97).addBox(-82.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(342, 83).addBox(-82.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("fecil_i_1", CubeListBuilder.create().texOffs(72, 97).addBox(-82.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(386, 83).addBox(-82.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_2", CubeListBuilder.create().texOffs(100, 97).addBox(-82.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(430, 83).addBox(-82.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_3", CubeListBuilder.create().texOffs(128, 97).addBox(-82.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(474, 83).addBox(-82.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_a_0", CubeListBuilder.create().texOffs(338, 109).addBox(-83.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(612, 97).addBox(-83.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("fecil_i_a_1", CubeListBuilder.create().texOffs(344, 109).addBox(-83.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(634, 97).addBox(-83.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_a_2", CubeListBuilder.create().texOffs(350, 109).addBox(-83.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(656, 97).addBox(-83.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_a_3", CubeListBuilder.create().texOffs(356, 109).addBox(-83.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(678, 97).addBox(-83.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_b_0", CubeListBuilder.create().texOffs(362, 109).addBox(-71.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(700, 97).addBox(-71.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("fecil_i_b_1", CubeListBuilder.create().texOffs(368, 109).addBox(-71.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(722, 97).addBox(-71.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_b_2", CubeListBuilder.create().texOffs(374, 109).addBox(-71.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(744, 97).addBox(-71.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_b_3", CubeListBuilder.create().texOffs(380, 109).addBox(-71.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(766, 97).addBox(-71.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fermd0_0", CubeListBuilder.create().texOffs(284, 62).addBox(-9.0F, -9.0F, 4.0F, 18.0F, 18.0F, 2.0F).texOffs(70, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(364, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(446, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(438, 356).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-52.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("fermd0_1", CubeListBuilder.create().texOffs(108, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(378, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-52.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermd0_2", CubeListBuilder.create().texOffs(146, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-52.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fermd1_0", CubeListBuilder.create().texOffs(284, 62).addBox(-9.0F, -9.0F, 4.0F, 18.0F, 18.0F, 2.0F).texOffs(70, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(364, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(456, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(444, 356).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-32.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("fermd1_1", CubeListBuilder.create().texOffs(108, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(378, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermd1_2", CubeListBuilder.create().texOffs(146, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("febiela_d", CubeListBuilder.create().texOffs(780, 356).addBox(-52.0F, -12.5F, 6.5F, 20.0F, 1.0F, 1.0F).texOffs(936, 337).addBox(-53.5F, -13.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(944, 337).addBox(-33.5F, -13.5F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("femotriz_d", CubeListBuilder.create().texOffs(540, 356).addBox(-32.0F, -0.5F, -0.5F, 32.0F, 1.0F, 1.0F).texOffs(952, 337).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(-32.0F, -12.0F, 8.5F));
        g.addOrReplaceChild("fecruceta_d", CubeListBuilder.create().texOffs(466, 324).addBox(-65.35906464414798F, -10.5F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(172, 359).addBox(-73.85906464414798F, -9.5F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("feguias_d", CubeListBuilder.create().texOffs(966, 356).addBox(-70.85906464414798F, -7.5F, 8.0F, 14.0F, 1.0F, 1.0F).texOffs(0, 359).addBox(-70.85906464414798F, -11.5F, 8.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fecil_d_0", CubeListBuilder.create().texOffs(156, 97).addBox(-82.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(518, 83).addBox(-82.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("fecil_d_1", CubeListBuilder.create().texOffs(184, 97).addBox(-82.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(562, 83).addBox(-82.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_2", CubeListBuilder.create().texOffs(212, 97).addBox(-82.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(606, 83).addBox(-82.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_3", CubeListBuilder.create().texOffs(240, 97).addBox(-82.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(650, 83).addBox(-82.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_a_0", CubeListBuilder.create().texOffs(386, 109).addBox(-83.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(788, 97).addBox(-83.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("fecil_d_a_1", CubeListBuilder.create().texOffs(392, 109).addBox(-83.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(810, 97).addBox(-83.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_a_2", CubeListBuilder.create().texOffs(398, 109).addBox(-83.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(832, 97).addBox(-83.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_a_3", CubeListBuilder.create().texOffs(404, 109).addBox(-83.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(854, 97).addBox(-83.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_b_0", CubeListBuilder.create().texOffs(410, 109).addBox(-71.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(876, 97).addBox(-71.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("fecil_d_b_1", CubeListBuilder.create().texOffs(416, 109).addBox(-71.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(898, 97).addBox(-71.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_b_2", CubeListBuilder.create().texOffs(422, 109).addBox(-71.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(920, 97).addBox(-71.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_b_3", CubeListBuilder.create().texOffs(428, 109).addBox(-71.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(942, 97).addBox(-71.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rermi0_0", CubeListBuilder.create().texOffs(324, 62).addBox(-9.0F, -9.0F, -6.0F, 18.0F, 18.0F, 2.0F).texOffs(184, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(406, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(476, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(450, 356).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-8.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("rermi0_1", CubeListBuilder.create().texOffs(222, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(420, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermi0_2", CubeListBuilder.create().texOffs(260, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rermi1_0", CubeListBuilder.create().texOffs(324, 62).addBox(-9.0F, -9.0F, -6.0F, 18.0F, 18.0F, 2.0F).texOffs(184, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(406, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(486, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(456, 356).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(12.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("rermi1_1", CubeListBuilder.create().texOffs(222, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(420, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermi1_2", CubeListBuilder.create().texOffs(260, 132).addBox(-8.5F, -2.5F, -6.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 62).addBox(-2.5F, -8.5F, -6.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rebiela_i", CubeListBuilder.create().texOffs(822, 356).addBox(-8.0F, -12.5F, -7.5F, 20.0F, 1.0F, 1.0F).texOffs(960, 337).addBox(-9.5F, -13.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(968, 337).addBox(10.5F, -13.5F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("remotriz_i", CubeListBuilder.create().texOffs(606, 356).addBox(0.0F, -0.5F, -0.5F, 32.0F, 1.0F, 1.0F).texOffs(976, 337).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(-8.0F, -12.0F, -8.5F));
        g.addOrReplaceChild("recruceta_i", CubeListBuilder.create().texOffs(496, 324).addBox(22.35906464414798F, -10.5F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(194, 359).addBox(23.85906464414798F, -9.5F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("reguias_i", CubeListBuilder.create().texOffs(30, 359).addBox(16.85906464414798F, -7.5F, -9.0F, 14.0F, 1.0F, 1.0F).texOffs(60, 359).addBox(16.85906464414798F, -11.5F, -9.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("recil_i_0", CubeListBuilder.create().texOffs(268, 97).addBox(30.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(694, 83).addBox(30.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("recil_i_1", CubeListBuilder.create().texOffs(296, 97).addBox(30.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(738, 83).addBox(30.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_2", CubeListBuilder.create().texOffs(324, 97).addBox(30.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(782, 83).addBox(30.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_3", CubeListBuilder.create().texOffs(352, 97).addBox(30.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(826, 83).addBox(30.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_a_0", CubeListBuilder.create().texOffs(434, 109).addBox(30.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(964, 97).addBox(30.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("recil_i_a_1", CubeListBuilder.create().texOffs(440, 109).addBox(30.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(986, 97).addBox(30.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_a_2", CubeListBuilder.create().texOffs(446, 109).addBox(30.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(0, 109).addBox(30.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_a_3", CubeListBuilder.create().texOffs(452, 109).addBox(30.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(22, 109).addBox(30.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_b_0", CubeListBuilder.create().texOffs(458, 109).addBox(42.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(44, 109).addBox(42.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("recil_i_b_1", CubeListBuilder.create().texOffs(464, 109).addBox(42.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(66, 109).addBox(42.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_b_2", CubeListBuilder.create().texOffs(470, 109).addBox(42.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(88, 109).addBox(42.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_b_3", CubeListBuilder.create().texOffs(476, 109).addBox(42.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(110, 109).addBox(42.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rermd0_0", CubeListBuilder.create().texOffs(324, 62).addBox(-9.0F, -9.0F, 4.0F, 18.0F, 18.0F, 2.0F).texOffs(184, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(406, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(462, 356).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-8.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("rermd0_1", CubeListBuilder.create().texOffs(222, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(420, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermd0_2", CubeListBuilder.create().texOffs(260, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rermd1_0", CubeListBuilder.create().texOffs(324, 62).addBox(-9.0F, -9.0F, 4.0F, 18.0F, 18.0F, 2.0F).texOffs(184, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(406, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(516, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(468, 356).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(12.0F, -9.0F, 0.0F));
        g.addOrReplaceChild("rermd1_1", CubeListBuilder.create().texOffs(222, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(420, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -9.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermd1_2", CubeListBuilder.create().texOffs(260, 132).addBox(-8.5F, -2.5F, 4.0F, 17.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 62).addBox(-2.5F, -8.5F, 4.0F, 5.0F, 17.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -9.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rebiela_d", CubeListBuilder.create().texOffs(864, 356).addBox(-8.0F, -12.5F, 6.5F, 20.0F, 1.0F, 1.0F).texOffs(984, 337).addBox(-9.5F, -13.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(992, 337).addBox(10.5F, -13.5F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("remotriz_d", CubeListBuilder.create().texOffs(672, 356).addBox(0.0F, -0.5F, -0.5F, 32.0F, 1.0F, 1.0F).texOffs(1000, 337).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(-8.0F, -12.0F, 8.5F));
        g.addOrReplaceChild("recruceta_d", CubeListBuilder.create().texOffs(526, 324).addBox(22.35906464414798F, -10.5F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(216, 359).addBox(23.85906464414798F, -9.5F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("reguias_d", CubeListBuilder.create().texOffs(90, 359).addBox(16.85906464414798F, -7.5F, 8.0F, 14.0F, 1.0F, 1.0F).texOffs(120, 359).addBox(16.85906464414798F, -11.5F, 8.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("recil_d_0", CubeListBuilder.create().texOffs(380, 97).addBox(30.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(870, 83).addBox(30.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("recil_d_1", CubeListBuilder.create().texOffs(408, 97).addBox(30.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(914, 83).addBox(30.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_2", CubeListBuilder.create().texOffs(436, 97).addBox(30.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(958, 83).addBox(30.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_3", CubeListBuilder.create().texOffs(464, 97).addBox(30.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(0, 97).addBox(30.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_a_0", CubeListBuilder.create().texOffs(482, 109).addBox(30.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(132, 109).addBox(30.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("recil_d_a_1", CubeListBuilder.create().texOffs(488, 109).addBox(30.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(154, 109).addBox(30.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_a_2", CubeListBuilder.create().texOffs(494, 109).addBox(30.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(176, 109).addBox(30.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_a_3", CubeListBuilder.create().texOffs(500, 109).addBox(30.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(198, 109).addBox(30.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_b_0", CubeListBuilder.create().texOffs(506, 109).addBox(42.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(220, 109).addBox(42.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("recil_d_b_1", CubeListBuilder.create().texOffs(512, 109).addBox(42.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(242, 109).addBox(42.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_b_2", CubeListBuilder.create().texOffs(518, 109).addBox(42.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(264, 109).addBox(42.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_b_3", CubeListBuilder.create().texOffs(524, 109).addBox(42.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(286, 109).addBox(42.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rbi0_0", CubeListBuilder.create().texOffs(254, 121).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(832, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(298, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(536, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-96.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi0_1", CubeListBuilder.create().texOffs(854, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(306, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-96.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("rbi0_2", CubeListBuilder.create().texOffs(876, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(314, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-96.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbi1_0", CubeListBuilder.create().texOffs(254, 121).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(832, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(298, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(546, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-84.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi1_1", CubeListBuilder.create().texOffs(854, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(306, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-84.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi1_2", CubeListBuilder.create().texOffs(876, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(314, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-84.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd0_0", CubeListBuilder.create().texOffs(254, 121).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(832, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(298, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(556, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-96.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd0_1", CubeListBuilder.create().texOffs(854, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(306, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-96.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd0_2", CubeListBuilder.create().texOffs(876, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(314, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-96.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd1_0", CubeListBuilder.create().texOffs(254, 121).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(832, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(298, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(566, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-84.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd1_1", CubeListBuilder.create().texOffs(854, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(306, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-84.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd1_2", CubeListBuilder.create().texOffs(876, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(314, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-84.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(492, 97).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(636, 314).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(308, 109).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(576, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(52.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(660, 314).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 109).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(684, 314).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(328, 109).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti1_0", CubeListBuilder.create().texOffs(492, 97).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(636, 314).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(308, 109).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(586, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(64.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti1_1", CubeListBuilder.create().texOffs(660, 314).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 109).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti1_2", CubeListBuilder.create().texOffs(684, 314).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(328, 109).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(492, 97).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(636, 314).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(308, 109).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(596, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(52.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(660, 314).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 109).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(684, 314).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(328, 109).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd1_0", CubeListBuilder.create().texOffs(492, 97).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(636, 314).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(308, 109).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(606, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(64.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd1_1", CubeListBuilder.create().texOffs(660, 314).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 109).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd1_2", CubeListBuilder.create().texOffs(684, 314).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(328, 109).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(624, 62).addBox(-100.0F, -17.0F, 2.0F, 170.0F, 13.0F, 1.0F).texOffs(0, 83).addBox(-100.0F, -17.0F, -3.0F, 170.0F, 13.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("carcasa_0", CubeListBuilder.create().texOffs(0, 139).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -16.978692255792744F, -13.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_1", CubeListBuilder.create().texOffs(0, 144).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -18.936076767378232F, -13.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_2", CubeListBuilder.create().texOffs(0, 149).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -20.89346127896372F, -13.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_3", CubeListBuilder.create().texOffs(0, 154).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -22.850845790549208F, -13.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_4", CubeListBuilder.create().texOffs(0, 159).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -24.808230302134696F, -13.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_5", CubeListBuilder.create().texOffs(0, 164).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -26.765614813720184F, -13.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_6", CubeListBuilder.create().texOffs(0, 169).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -28.722999325305665F, -13.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_7", CubeListBuilder.create().texOffs(0, 174).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -30.680139190356872F, -12.987304298759959F, -1.5837709497693349F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_8", CubeListBuilder.create().texOffs(0, 179).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -32.636552481735734F, -12.936903741818394F, -1.6093316159515703F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_9", CubeListBuilder.create().texOffs(0, 184).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -34.5814967932371F, -12.769728509544969F, -1.7038963958933846F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_10", CubeListBuilder.create().texOffs(0, 189).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -36.474311488346245F, -12.338609277737003F, -1.8857628233489263F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_11", CubeListBuilder.create().texOffs(0, 194).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -38.22180646224115F, -11.515221013004174F, -2.1365422163522227F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_12", CubeListBuilder.create().texOffs(0, 199).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -39.67256511140873F, -10.250184517284122F, -2.439213386584958F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_13", CubeListBuilder.create().texOffs(0, 204).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -40.71637592981677F, -8.623869953181046F, -2.70251669826563F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_14", CubeListBuilder.create().texOffs(0, 209).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -41.37882082953478F, -6.796294588840584F, -2.8850949267678176F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_15", CubeListBuilder.create().texOffs(0, 214).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -41.75926621852029F, -4.8825075428836895F, -3.00551400318039F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_16", CubeListBuilder.create().texOffs(0, 219).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -41.918983338896226F, -2.9349587875406056F, -3.1139956416294416F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_17", CubeListBuilder.create().texOffs(0, 224).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -41.97299444629874F, -0.9783195958468689F, -3.1139956416294416F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_18", CubeListBuilder.create().texOffs(0, 229).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -41.97299444629874F, 0.9783195958468677F, 3.1139956416294416F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_19", CubeListBuilder.create().texOffs(0, 234).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -41.918983338896226F, 2.934958787540603F, 3.1139956416294416F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_20", CubeListBuilder.create().texOffs(0, 239).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -41.75926621852029F, 4.882507542883685F, 3.00551400318039F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_21", CubeListBuilder.create().texOffs(0, 244).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -41.37882082953478F, 6.796294588840576F, 2.885094926767817F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_22", CubeListBuilder.create().texOffs(0, 249).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -40.71637592981677F, 8.623869953181043F, 2.7025166982656312F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_23", CubeListBuilder.create().texOffs(0, 254).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -39.67256511140873F, 10.25018451728412F, 2.439213386584958F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_24", CubeListBuilder.create().texOffs(0, 259).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -38.221806462241155F, 11.515221013004172F, 2.1365422163522236F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_25", CubeListBuilder.create().texOffs(0, 264).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -36.47431148834626F, 12.338609277737F, 1.885762823348928F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_26", CubeListBuilder.create().texOffs(0, 269).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -34.58149679323711F, 12.76972850954497F, 1.703896395893385F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_27", CubeListBuilder.create().texOffs(0, 274).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -32.636552481735734F, 12.936903741818396F, 1.6093316159515696F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_28", CubeListBuilder.create().texOffs(0, 279).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -30.68013919035688F, 12.987304298759959F, 1.5837709497693349F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_29", CubeListBuilder.create().texOffs(0, 284).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -28.722999325305672F, 13.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_30", CubeListBuilder.create().texOffs(0, 289).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -26.765614813720184F, 13.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_31", CubeListBuilder.create().texOffs(0, 294).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -24.808230302134696F, 13.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_32", CubeListBuilder.create().texOffs(0, 299).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -22.850845790549208F, 13.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_33", CubeListBuilder.create().texOffs(0, 304).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -20.89346127896372F, 13.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_34", CubeListBuilder.create().texOffs(0, 309).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -18.936076767378232F, 13.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_35", CubeListBuilder.create().texOffs(0, 314).addBox(-130.0F, -1.0F, -2.0F, 260.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0F, -16.978692255792744F, 13.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("nariz_0", CubeListBuilder.create().texOffs(952, 319).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.72962050988033F, -16.81624677635772F, -12.558101471741423F, -2.116417965796251F, -0.036489970372645564F, -1.5987713010183742F));
        g.addOrReplaceChild("nariz_1", CubeListBuilder.create().texOffs(968, 319).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.66842617817873F, -18.65307927356094F, -12.559907987588165F, -2.1541665431330266F, -0.037886960781840145F, -1.596657147262417F));
        g.addOrReplaceChild("nariz_2", CubeListBuilder.create().texOffs(984, 319).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.60821345007818F, -20.489896309656466F, -12.561942018113445F, -2.196151865678924F, -0.03918359701208832F, -1.5941212662776045F));
        g.addOrReplaceChild("nariz_3", CubeListBuilder.create().texOffs(16, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.54903347104602F, -22.326690512943237F, -12.564225125229697F, -2.242937106739031F, -0.04029490134603263F, -1.5911040682723734F));
        g.addOrReplaceChild("nariz_4", CubeListBuilder.create().texOffs(30, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.49094284098557F, -24.163453513462567F, -12.566781020436023F, -2.2951317981266652F, -0.04110916208520637F, -1.5875577002834957F));
        g.addOrReplaceChild("nariz_5", CubeListBuilder.create().texOffs(44, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.43401642541413F, -26.00017412377889F, -12.569624177222323F, -2.3533695482434376F, -0.04147924853398915F, -1.5834515275897476F));
        g.addOrReplaceChild("nariz_6", CubeListBuilder.create().texOffs(58, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.3783491664017F, -27.836837968395713F, -12.572750764761878F, -2.418266768212164F, -0.041219598957022936F, -1.5787885403467783F));
        g.addOrReplaceChild("nariz_7", CubeListBuilder.create().texOffs(72, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.32405437276859F, -29.673427593500797F, -12.576125882592233F, -2.4903552188776583F, -0.04010988501846361F, -1.573627837335725F));
        g.addOrReplaceChild("nariz_8", CubeListBuilder.create().texOffs(86, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.27138134484046F, -31.509905472993776F, -12.574842610176836F, -2.5696350105192645F, -0.041298043006518695F, -1.5670669829875785F));
        g.addOrReplaceChild("nariz_9", CubeListBuilder.create().texOffs(42, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.22073247511393F, -33.346210827756465F, -12.521915319917895F, -2.6548382173986305F, -0.06875594568895207F, -1.5515002195305385F));
        g.addOrReplaceChild("nariz_10", CubeListBuilder.create().texOffs(54, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.17202073620692F, -35.18235219539F, -12.3110224237451F, -2.7394891823639824F, -0.17354165615963937F, -1.5447175401867035F));
        g.addOrReplaceChild("nariz_11", CubeListBuilder.create().texOffs(66, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.12468164541204F, -37.01840799172673F, -11.788928771229696F, -2.8138131734080316F, -0.3746502747530653F, -1.5453204779862808F));
        g.addOrReplaceChild("nariz_12", CubeListBuilder.create().texOffs(884, 350).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.07826219257913F, -38.85444286107168F, -10.68242829091002F, -2.8675828130451264F, -0.6818398506634662F, -1.5457180540628088F));
        g.addOrReplaceChild("nariz_13", CubeListBuilder.create().texOffs(152, 350).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.03245143781639F, -40.69050253309297F, -7.916719917278382F, -2.858216077384043F, -1.1441685587356367F, -1.5459837873159714F));
        g.addOrReplaceChild("nariz_14", CubeListBuilder.create().texOffs(1000, 319).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.19227570558459F, -16.620659078221937F, -11.6797086346338F, -2.113505406402086F, -0.04921729335524347F, -1.5568874056838085F));
        g.addOrReplaceChild("nariz_15", CubeListBuilder.create().texOffs(0, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.00875906161573F, -18.47243045849096F, -11.684802799310825F, -2.1511890995318583F, -0.05078101103295458F, -1.5544442756710635F));
        g.addOrReplaceChild("nariz_16", CubeListBuilder.create().texOffs(16, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-85.82818782924721F, -20.32415724089524F, -11.69053375552128F, -2.1931273542292846F, -0.052176977798450784F, -1.5514847271507128F));
        g.addOrReplaceChild("nariz_17", CubeListBuilder.create().texOffs(100, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.65068865455933F, -22.175821172699486F, -11.696975084078092F, -2.2398906544061847F, -0.05329411657178901F, -1.5479453139415216F));
        g.addOrReplaceChild("nariz_18", CubeListBuilder.create().texOffs(114, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.47642193646966F, -24.027398797557737F, -11.704197067984818F, -2.292096604510886F, -0.053988438908741894F, -1.543779263492026F));
        g.addOrReplaceChild("nariz_19", CubeListBuilder.create().texOffs(128, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.30560090672799F, -25.878858600661264F, -11.712244703917456F, -2.3503879098793297F, -0.05407471421402081F, -1.5389651737036933F));
        g.addOrReplaceChild("nariz_20", CubeListBuilder.create().texOffs(142, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.1384707700386F, -27.730163564793283F, -11.721143422405573F, -2.4153888075897054F, -0.05330793839407321F, -1.5335138150563932F));
        g.addOrReplaceChild("nariz_21", CubeListBuilder.create().texOffs(156, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.97535597249527F, -29.581264294065072F, -11.730812606232949F, -2.487642064452679F, -0.051452579030642334F, -1.5275484739207597F));
        g.addOrReplaceChild("nariz_22", CubeListBuilder.create().texOffs(170, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.81704010004638F, -31.43204467215942F, -11.736643795688416F, -2.5672384001580117F, -0.051197755677183744F, -1.5205788393874538F));
        g.addOrReplaceChild("nariz_23", CubeListBuilder.create().texOffs(78, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.66469050521695F, -33.282330050496014F, -11.694565609218882F, -2.6531974138840373F, -0.07491909729507713F, -1.505657618798937F));
        g.addOrReplaceChild("nariz_24", CubeListBuilder.create().texOffs(90, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.51803216992307F, -35.13214801052018F, -11.504296936194386F, -2.740120146190265F, -0.1575437674196992F, -1.4929700223188702F));
        g.addOrReplaceChild("nariz_25", CubeListBuilder.create().texOffs(102, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.37544718670313F, -36.981720978053914F, -11.021531624190866F, -2.817501477767483F, -0.34701166895051866F, -1.4947456505687897F));
        g.addOrReplaceChild("nariz_26", CubeListBuilder.create().texOffs(898, 350).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.23563072432408F, -38.831233299934645F, -9.990333167851446F, -2.876347781928962F, -0.6436932245572453F, -1.495941292500626F));
        g.addOrReplaceChild("nariz_27", CubeListBuilder.create().texOffs(174, 350).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.09768704033813F, -40.68081543084101F, -7.405244062920865F, -2.8766373427068666F, -1.1144944566335762F, -1.4967650034256328F));
        g.addOrReplaceChild("nariz_28", CubeListBuilder.create().texOffs(32, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.66161373945593F, -16.427443545100896F, -10.811958578868682F, -2.1120911924111905F, -0.0619990452987657F, -1.516263868218111F));
        g.addOrReplaceChild("nariz_29", CubeListBuilder.create().texOffs(48, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.35593869795284F, -18.293848125572964F, -10.81969586450979F, -2.1497240930058554F, -0.06375389331569747F, -1.5134592446546875F));
        g.addOrReplaceChild("nariz_30", CubeListBuilder.create().texOffs(64, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.05511098554543F, -20.16019057518377F, -10.828429712024766F, -2.1916238743156056F, -0.06528263909414765F, -1.5100477738882991F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("nariz_31", CubeListBuilder.create().texOffs(184, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.75934193516636F, -22.02644120398319F, -10.838268903293985F, -2.238364900064224F, -0.06644591217469387F, -1.5059546999690145F));
        g.addOrReplaceChild("nariz_32", CubeListBuilder.create().texOffs(198, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.4688844503236F, -23.89256370073027F, -10.849324244158087F, -2.2905693929450592F, -0.06706461392253744F, -1.5011283771333626F));
        g.addOrReplaceChild("nariz_33", CubeListBuilder.create().texOffs(212, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.18406851253319F, -25.758510052255488F, -10.861673562205091F, -2.348884800951198F, -0.066913460945572F, -1.4955537183205658F));
        g.addOrReplaceChild("nariz_34", CubeListBuilder.create().texOffs(226, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.90526824353068F, -27.624224604903134F, -10.875376254836297F, -2.4139435651060808F, -0.06568738793292794F, -1.4892485213990856F));
        g.addOrReplaceChild("nariz_35", CubeListBuilder.create().texOffs(240, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.63298903151235F, -29.48963155818572F, -10.890328974798175F, -2.4862853191547822F, -0.0631226015994646F, -1.4823919673308392F));
        g.addOrReplaceChild("nariz_36", CubeListBuilder.create().texOffs(254, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.36848259755979F, -31.354548125206932F, -10.90218881470432F, -2.56605382283152F, -0.06150384268194343F, -1.474849015527808F));
        g.addOrReplaceChild("nariz_37", CubeListBuilder.create().texOffs(114, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.11360655009412F, -33.21870031073952F, -10.869839942651652F, -2.652534220734665F, -0.08145228705983854F, -1.4603860961558393F));
        g.addOrReplaceChild("nariz_38", CubeListBuilder.create().texOffs(126, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.86795413435111F, -35.082127065321764F, -10.69920812144116F, -2.7413488896523504F, -0.14187636984741805F, -1.4417870641331836F));
        g.addOrReplaceChild("nariz_39", CubeListBuilder.create().texOffs(138, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.62899779636192F, -36.94517075302463F, -10.25500962943578F, -2.821398906156661F, -0.31891622788783275F, -1.4446767229546458F));
        g.addOrReplaceChild("nariz_40", CubeListBuilder.create().texOffs(912, 350).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.3946798196522F, -38.80811799783993F, -9.298598658653765F, -2.8849931113003255F, -0.6030340598666212F, -1.4466740547484729F));
        g.addOrReplaceChild("nariz_41", CubeListBuilder.create().texOffs(240, 350).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.16358723191328F, -40.67117175146638F, -6.893850972161791F, -2.8949254165692886F, -1.0804673804415221F, -1.4480999826834597F));
        g.addOrReplaceChild("nariz_42", CubeListBuilder.create().texOffs(80, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-89.13729113901884F, -16.23653618278565F, -9.954565457869565F, -2.1120554267490985F, -0.07479696135065134F, -1.4770436294609504F));
        g.addOrReplaceChild("nariz_43", CubeListBuilder.create().texOffs(96, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-88.70960166634808F, -18.11728585831913F, -9.964363043794616F, -2.1496574234817123F, -0.07677334953480279F, -1.4738637351896549F));
        g.addOrReplaceChild("nariz_44", CubeListBuilder.create().texOffs(112, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-88.28866070710734F, -19.99795904349623F, -9.975434346927251F, -2.1915321142025426F, -0.0784657501382891F, -1.4699747882254273F));
        g.addOrReplaceChild("nariz_45", CubeListBuilder.create().texOffs(268, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.87469764276F, -21.878523656285513F, -9.98795314047953F, -2.238256209519894F, -0.07969624547158276F, -1.4652801339362054F));
        g.addOrReplaceChild("nariz_46", CubeListBuilder.create().texOffs(282, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.46803236636515F, -23.758934524329483F, -10.00207755967456F, -2.2904535690206944F, -0.08027287633408826F, -1.4597530841537167F));
        g.addOrReplaceChild("nariz_47", CubeListBuilder.create().texOffs(296, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.0691239922445F, -25.639126382371046F, -10.017897992110381F, -2.348772412380796F, -0.07992254721537667F, -1.453370997136555F));
        g.addOrReplaceChild("nariz_48", CubeListBuilder.create().texOffs(310, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.67850632468289F, -27.51902162423433F, -10.035452233965483F, -2.413845292430276F, -0.07830764540287866F, -1.446178032320679F));
        g.addOrReplaceChild("nariz_49", CubeListBuilder.create().texOffs(324, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.29682335286634F, -29.3985248499405F, -10.05463140421989F, -2.486206998221323F, -0.07506965306574616F, -1.4383479596823265F));
        g.addOrReplaceChild("nariz_50", CubeListBuilder.create().texOffs(338, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.92562741503372F, -31.27741196584212F, -10.071455764025615F, -2.566035611110165F, -0.07212520117772712F, -1.430055675205234F));
        g.addOrReplaceChild("nariz_51", CubeListBuilder.create().texOffs(150, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.5674044870145F, -33.15532193521174F, -10.04778779816546F, -2.6546187624252386F, -0.03195382550542954F, -1.385915849339596F));
        g.addOrReplaceChild("nariz_52", CubeListBuilder.create().texOffs(162, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.22172581793728F, -35.03229040872009F, -9.89583057026617F, -2.7431416629959617F, -0.12665925195927627F, -1.3914251159221764F));
        g.addOrReplaceChild("nariz_53", CubeListBuilder.create().texOffs(174, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.88529262731087F, -36.90875745958664F, -9.489427704104742F, -2.8254381027681066F, -0.2906225693583295F, -1.3953574953627204F));
        g.addOrReplaceChild("nariz_54", CubeListBuilder.create().texOffs(926, 350).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.55538783724255F, -38.785096109652955F, -8.607260083119609F, -2.893373658425051F, -0.5600990986649295F, -1.3981462769190196F));
        g.addOrReplaceChild("nariz_55", CubeListBuilder.create().texOffs(260, 350).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.23014495781449F, -40.66157067907554F, -6.382542954126658F, -2.9128374780767867F, -1.0414703904756273F, -1.4002036287558637F));
        g.addOrReplaceChild("nariz_56", CubeListBuilder.create().texOffs(128, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.61906715723191F, -16.047865116316704F, -9.107207868332301F, -2.113275080500134F, -0.0875732193287295F, -1.4393289291021747F));
        g.addOrReplaceChild("nariz_57", CubeListBuilder.create().texOffs(144, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.06945409950492F, -17.942692347217818F, -9.118557159693182F, -2.1508620763534343F, -0.08979601739569204F, -1.4357621640537104F));
        g.addOrReplaceChild("nariz_58", CubeListBuilder.create().texOffs(160, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-89.52850737032455F, -19.83742927712959F, -9.13137381412431F, -2.1927258775791993F, -0.09167432962961411F, -1.431370378009418F));
        g.addOrReplaceChild("nariz_59", CubeListBuilder.create().texOffs(352, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.99645885244702F, -21.732043674458303F, -9.145884567171999F, -2.239444502948278F, -0.09300952059799535F, -1.4260576976650807F));
        g.addOrReplaceChild("nariz_60", CubeListBuilder.create().texOffs(366, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.47365326837827F, -23.626487370616562F, -9.162305420399683F, -2.291634988964285F, -0.09356803930690621F, -1.4197849043206123F));
        g.addOrReplaceChild("nariz_61", CubeListBuilder.create().texOffs(380, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.96061873121594F, -25.520686337662035F, -9.180767915906161F, -2.3499435268443842F, -0.0930480722275301F, -1.4125483015129348F));
        g.addOrReplaceChild("nariz_62", CubeListBuilder.create().texOffs(394, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.45803843950497F, -27.414543385378288F, -9.20128562433936F, -2.4149945552604217F, -0.09107606682161161F, -1.404413452009983F));
        g.addOrReplaceChild("nariz_63", CubeListBuilder.create().texOffs(408, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.96669767204261F, -29.307944188896478F, -9.2237220269766F, -2.4873239236300284F, -0.08721322895114081F, -1.3955565766832239F));
        g.addOrReplaceChild("nariz_64", CubeListBuilder.create().texOffs(422, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.48835831842258F, -31.200637388988245F, -9.24447182529699F, -2.5671152353627686F, -0.08299528057656885F, -1.3863705661562222F));
        g.addOrReplaceChild("nariz_65", CubeListBuilder.create().texOffs(186, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.02602219167326F, -33.09219338769486F, -9.228429182846648F, -2.656236099531141F, -0.02583319973917223F, -1.3354006134510827F));
        g.addOrReplaceChild("nariz_66", CubeListBuilder.create().texOffs(198, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.5793138630516F, -34.98263529203196F, -9.094174881130623F, -2.7454597150057F, -0.1120059211365106F, -1.3421148436802082F));
        g.addOrReplaceChild("nariz_67", CubeListBuilder.create().texOffs(940, 350).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.14431034065672F, -36.8724785601912F, -8.72479407133196F, -2.82956357931421F, -0.2623824416517236F, -1.3470029345923649F));
        g.addOrReplaceChild("nariz_68", CubeListBuilder.create().texOffs(954, 350).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.71773954339753F, -38.76216597355907F, -7.916330659786417F, -2.901370439338883F, -0.5151943578450937F, -1.350561060655126F));
        g.addOrReplaceChild("nariz_69", CubeListBuilder.create().texOffs(280, 350).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.29735252476627F, -40.65201155176362F, -5.871337943691364F, -2.9301483811590505F, -0.9968224339217244F, -1.3532694242876453F));
        g.addOrReplaceChild("nariz_70", CubeListBuilder.create().texOffs(160, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-92.10670530446166F, -15.861362799634337F, -8.269581769704018F, -2.115614927472589F, -0.1003158871623347F, -1.403226379510707F));
        g.addOrReplaceChild("nariz_71", CubeListBuilder.create().texOffs(178, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-91.43532153108023F, -17.770004786649494F, -8.281974684845924F, -2.1532094846580234F, -0.10278640176558804F, -1.399228568635177F));
        g.addOrReplaceChild("nariz_72", CubeListBuilder.create().texOffs(196, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.77445225717115F, -19.67855397250942F, -8.296000983766826F, -2.1950801978833168F, -0.10485732935344848F, -1.3942975872501395F));
        g.addOrReplaceChild("nariz_73", CubeListBuilder.create().texOffs(522, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.12437743764116F, -21.58697228565084F, -8.311898723691929F, -2.241799490094748F, -0.10632271339099572F, -1.388350757240482F));
        g.addOrReplaceChild("nariz_74", CubeListBuilder.create().texOffs(538, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.48549557100473F, -23.495205129459027F, -8.329899920678209F, -2.293987407160358F, -0.10689697259764641F, -1.3813137230714019F));
        g.addOrReplaceChild("nariz_75", CubeListBuilder.create().texOffs(554, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.85836251719257F, -25.40317548710563F, -8.350180989233637F, -2.352278620486322F, -0.10623943890244252F, -1.3731890949788965F));
        g.addOrReplaceChild("nariz_76", CubeListBuilder.create().texOffs(570, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.24371942135497F, -27.31077927891505F, -8.372793337268552F, -2.4172862559494908F, -0.1039208092959399F, -1.3640509200918725F));
        g.addOrReplaceChild("nariz_77", CubeListBuilder.create().texOffs(436, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.6424709290376F, -29.217887046144675F, -8.39758043928991F, -2.489530525252026F, -0.09946970407893832F, -1.354123178884616F));
        g.addOrReplaceChild("nariz_78", CubeListBuilder.create().texOffs(450, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.05657384648617F, -31.124223540913967F, -8.421239852491976F, -2.5692071104823326F, -0.09405464988406666F, -1.3439397055439093F));
        g.addOrReplaceChild("nariz_79", CubeListBuilder.create().texOffs(210, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.4894203087564F, -33.029310127812124F, -8.411742331511096F, -2.6586947313199776F, -0.020416967348731635F, -1.2863307107340647F));
        g.addOrReplaceChild("nariz_80", CubeListBuilder.create().texOffs(222, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.9407050175299F, -34.93315636575866F, -8.294207674946518F, -2.7482611029547823F, -0.09801193625330963F, -1.2940539569916099F));
        g.addOrReplaceChild("nariz_81", CubeListBuilder.create().texOffs(968, 350).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.40604441836676F, -36.8363296117639F, -7.961074290587567F, -2.833730939919828F, -0.23444240987635806F, -1.299800073224087F));
        g.addOrReplaceChild("nariz_82", CubeListBuilder.create().texOffs(982, 350).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.88172899927774F, -38.73932473078706F, -7.225786147417867F, -2.908890320628303F, -0.46869790054104904F, -1.3040937559610433F));
        g.addOrReplaceChild("nariz_83", CubeListBuilder.create().texOffs(360, 350).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.36520549675562F, -40.64249329105614F, -5.360231609232778F, -2.946647891173034F, -0.9457946042817452F, -1.3074641846951907F));
        g.addOrReplaceChild("nariz_84", CubeListBuilder.create().texOffs(214, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.59989993889951F, -15.676975212305054F, -7.441445486718921F, -2.118942467910197F, -0.11298748009624271F, -1.3687665017134634F));
        g.addOrReplaceChild("nariz_85", CubeListBuilder.create().texOffs(232, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-92.80690461453774F, -17.599180202435743F, -7.454407731799131F, -2.1565645913195706F, -0.1157117025346507F, -1.3643107791022537F));
        g.addOrReplaceChild("nariz_86", CubeListBuilder.create().texOffs(250, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-92.0262694693819F, -19.521292238276843F, -7.469100175693182F, -2.1984601258350303F, -0.11798914097997698F, -1.358821146174568F));
        g.addOrReplaceChild("nariz_87", CubeListBuilder.create().texOffs(586, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.25827890405725F, -21.443273185625504F, -7.485787998988076F, -2.2451961925087733F, -0.11958577016959362F, -1.3522000383816315F));
        g.addOrReplaceChild("nariz_88", CubeListBuilder.create().texOffs(602, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.50337095658918F, -23.365064052351364F, -7.50471228522755F, -2.2973834697125355F, -0.12019670564552701F, -1.3443804858037058F));
        g.addOrReplaceChild("nariz_89", CubeListBuilder.create().texOffs(618, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.7621497570836F, -25.286582500123124F, -7.526059158722267F, -2.3556506903825434F, -0.1194265552228321F, -1.335344858445832F));
        g.addOrReplaceChild("nariz_90", CubeListBuilder.create().texOffs(634, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.0353844418905F, -27.207721899575088F, -7.549915090258556F, -2.4205986680432123F, -0.11679364893292203F, -1.3251763804992067F));
        g.addOrReplaceChild("nariz_91", CubeListBuilder.create().texOffs(650, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.32403443827333F, -29.128346857663786F, -7.576147852772343F, -2.4927237648730984F, -0.11176841269119457F, -1.314127432437639F));
        g.addOrReplaceChild("nariz_92", CubeListBuilder.create().texOffs(666, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.63018351917025F, -31.048168269530557F, -7.601751592893631F, -2.575703747722253F, 0.011707649910892457F, -1.2283008193972107F));
        g.addOrReplaceChild("nariz_93", CubeListBuilder.create().texOffs(996, 350).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.95752907185883F, -32.96667193147606F, -7.59776148818765F, -2.661925097801975F, -0.015694507518749932F, -1.2388722789979305F));
        g.addOrReplaceChild("nariz_94", CubeListBuilder.create().texOffs(1010, 350).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.30585321804112F, -34.88385297753342F, -7.4959690388002915F, -2.7515024118652374F, -0.08475899082952335F, -1.2474129970894152F));
        g.addOrReplaceChild("nariz_95", CubeListBuilder.create().texOffs(0, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.6704649630035F, -36.800309582598324F, -7.198304344911219F, -2.8379049699449697F, -0.20703239843705865F, -1.2539101359978253F));
        g.addOrReplaceChild("nariz_96", CubeListBuilder.create().texOffs(14, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.04733740481505F, -38.71657143672849F, -6.5356545825464885F, -2.9158672007300557F, -0.42106773829663313F, -1.2588994666894233F));
        g.addOrReplaceChild("nariz_97", CubeListBuilder.create().texOffs(378, 350).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.43369675577279F, -40.63301525130214F, -4.849233743177922F, -2.9621440143622486F, -0.8876562016536489F, -1.2629311393506302F));
        g.addOrReplaceChild("nariz_98", CubeListBuilder.create().texOffs(268, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-95.0984315309205F, -15.494641705402307F, -6.622527431630079F, -2.123131445388771F, -0.12555298256312944F, -1.3359474220391563F));
        g.addOrReplaceChild("nariz_99", CubeListBuilder.create().texOffs(286, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-94.18396151659857F, -17.430171823559803F, -6.635630649560554F, -2.1608003679389576F, -0.12853192776122596F, -1.3310102384144138F));
        g.addOrReplaceChild("nariz_100", CubeListBuilder.create().texOffs(304, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.28370017417802F, -19.365610313114253F, -6.650494949829076F, -2.2027352684317614F, -0.1310237521093418F, -1.3249465202800665F));
        g.addOrReplaceChild("nariz_101", CubeListBuilder.create().texOffs(682, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.39793822365253F, -21.300918789740564F, -6.667393438709274F, -2.2495000506811644F, -0.13276431551417953F, -1.3176372316608314F));
        g.addOrReplaceChild("nariz_102", CubeListBuilder.create().texOffs(698, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.52710487298481F, -23.236040152431357F, -6.686591217030591F, -2.3016959105445514F, -0.1334168927827088F, -1.3090077126876871F));
        g.addOrReplaceChild("nariz_103", CubeListBuilder.create().texOffs(714, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.67181219237166F, -25.170892147690854F, -6.708296485053941F, -2.359938213074309F, -0.13254665927879503F, -1.2990396055760767F));
        g.addOrReplaceChild("nariz_104", CubeListBuilder.create().texOffs(730, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.83286416183522F, -27.10536505302771F, -6.73260327117921F, -2.4248086688391868F, -0.12962678379615336F, -1.2878272862453746F));
        g.addOrReplaceChild("nariz_105", CubeListBuilder.create().texOffs(746, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.01126019064694F, -29.039319947944477F, -6.759389367397534F, -2.4967844510657686F, -0.1240602734667279F, -1.2756365976793587F));
        g.addOrReplaceChild("nariz_106", CubeListBuilder.create().texOffs(762, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.2091088136076F, -30.972467990962112F, -6.785981821557165F, -2.5802759649582163F, 0.01207708249708207F, -1.1820259642917332F));
        g.addOrReplaceChild("nariz_107", CubeListBuilder.create().texOffs(28, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.43029182932435F, -32.90427693718089F, -6.7864973957464425F, -2.6658545107348726F, -0.011645483448118945F, -1.1931512238371274F));
        g.addOrReplaceChild("nariz_108", CubeListBuilder.create().texOffs(42, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.67472128242117F, -34.83472340341001F, -6.699480441484864F, -2.7551375250963863F, -0.07230365375941777F, -1.202324660503249F));
        g.addOrReplaceChild("nariz_109", CubeListBuilder.create().texOffs(56, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.93754843769428F, -36.76441669572368F, -6.43650160594825F, -2.8420621777369814F, -0.1803633583716877F, -1.2094644270053834F));
        g.addOrReplaceChild("nariz_110", CubeListBuilder.create().texOffs(70, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.21455131407312F, -38.69390450992843F, -5.845943199570315F, -2.9222586187605666F, -0.37280273068740355F, -1.2151024809142343F));
        g.addOrReplaceChild("nariz_111", CubeListBuilder.create().texOffs(396, 350).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.50282109239589F, -40.6235765723851F, -4.338341878105518F, -2.9764521493894294F, -0.8217328411837119F, -1.219784515967338F));
        g.addOrReplaceChild("nariz_112", CubeListBuilder.create().texOffs(322, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.6020801629447F, -15.314305763953271F, -5.812574006322006F, -2.1280594306604845F, -0.13798512380929517F, -1.3047515948578152F));
        g.addOrReplaceChild("nariz_113", CubeListBuilder.create().texOffs(340, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-95.56630077286297F, -17.262929882641597F, -5.825402588382987F, -2.1657926917086345F, -0.14121671484982146F, -1.2993127602292238F));
        g.addOrReplaceChild("nariz_114", CubeListBuilder.create().texOffs(358, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-94.54655628685171F, -19.211468087822176F, -5.839975450761823F, -2.2077834665678027F, -0.14391874848478223F, -1.2926523619321337F));
        g.addOrReplaceChild("nariz_115", CubeListBuilder.create().texOffs(778, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.54314506608122F, -21.159881674601433F, -5.856558739002743F, -2.2545880936467495F, -0.1458089636607381F, -1.2846452084862308F));
        g.addOrReplaceChild("nariz_116", CubeListBuilder.create().texOffs(794, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.55649078805625F, -23.10811507619149F, -5.875420930301447F, -2.306798624818441F, -0.14651200255776478F, -1.2751964789348862F));
        g.addOrReplaceChild("nariz_117", CubeListBuilder.create().texOffs(810, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.58718264141747F, -25.05609006634824F, -5.896791605510255F, -2.3650153278079054F, -0.14555430145131748F, -1.26428642407875F));
        g.addOrReplaceChild("nariz_118", CubeListBuilder.create().texOffs(826, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.63601908631546F, -27.003699222294088F, -5.920783442312333F, -2.4297987936678784F, -0.14236059202657583F, -1.2520166022126187F));
        g.addOrReplaceChild("nariz_119", CubeListBuilder.create().texOffs(842, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.70401914809727F, -28.950803104597643F, -5.947277197678357F, -2.5084231485517416F, 0.012847439193560743F, -1.1284382079530673F));
        g.addOrReplaceChild("nariz_120", CubeListBuilder.create().texOffs(858, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.79325845671511F, -30.897120991553116F, -5.9739219419377285F, -2.585615562896664F, 0.011947658245836181F, -1.1378323501418197F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("nariz_121", CubeListBuilder.create().texOffs(84, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.90766555358647F, -32.842121592517586F, -5.977935419815314F, -2.6704021853089954F, -0.008253244171677328F, -1.1492604862936644F));
        g.addOrReplaceChild("nariz_122", CubeListBuilder.create().texOffs(98, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.04728860843532F, -34.78576381924809F, -5.9047277612385765F, -2.7591222257773262F, -0.06068074856822582F, -1.1588851613931412F));
        g.addOrReplaceChild("nariz_123", CubeListBuilder.create().texOffs(112, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.20728333083318F, -36.72864766515129F, -5.675649264389992F, -2.8461849390238076F, -0.15461682127187593F, -1.1665622824641537F));
        g.addOrReplaceChild("nariz_124", CubeListBuilder.create().texOffs(126, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.3833639040349F, -38.67132156255968F, -5.15663504078984F, -2.9280526842076187F, -0.3244097351339936F, -1.172794960428362F));
        g.addOrReplaceChild("nariz_125", CubeListBuilder.create().texOffs(468, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.57257439881613F, -40.614176293012726F, -3.8275511007960623F, -2.989417386794996F, -0.7475058538847916F, -1.1781100812481238F));
        g.addOrReplaceChild("nariz_126", CubeListBuilder.create().texOffs(376, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-98.11063273684853F, -15.135913849569164F, -5.011345281740531F, -2.1336140779685615F, -0.15025421396586197F, -1.2751333247005256F));
        g.addOrReplaceChild("nariz_127", CubeListBuilder.create().texOffs(394, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.95370569909807F, -17.097410938008757F, -5.0235137020249345F, -2.171427194711479F, -0.15373318424985954F, -1.269177225312123F));
        g.addOrReplaceChild("nariz_128", CubeListBuilder.create().texOffs(412, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-95.81463330481172F, -19.058830075332F, -5.037355422738949F, -2.2134873729731566F, -0.1566418656889204F, -1.2619080575724546F));
        g.addOrReplaceChild("nariz_129", CubeListBuilder.create().texOffs(874, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.69371371775549F, -21.02013324635058F, -5.0531201901783F, -2.260342122339681F, -0.1586811337360421F, -1.253195002189943F));
        g.addOrReplaceChild("nariz_130", CubeListBuilder.create().texOffs(890, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.59135163719021F, -22.981268107757707F, -5.071071035671261F, -2.3125736302058355F, -0.15943781119028538F, -1.242922667635493F));
        g.addOrReplaceChild("nariz_131", CubeListBuilder.create().texOffs(906, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.50809356571597F, -24.94216292027324F, -5.091451307996474F, -2.370764437490015F, -0.1584016734481202F, -1.2310702264009892F));
        g.addOrReplaceChild("nariz_132", CubeListBuilder.create().texOffs(922, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.44470629088522F, -26.90271594553562F, -5.114388539385828F, -2.4354514103635467F, -0.15494909951067035F, -1.2177439908367318F));
        g.addOrReplaceChild("nariz_133", CubeListBuilder.create().texOffs(938, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.40219614112182F, -28.8627915970916F, -5.139769221528298F, -2.5150656712216093F, 0.011979223234736915F, -1.086192390637549F));
        g.addOrReplaceChild("nariz_134", CubeListBuilder.create().texOffs(954, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.38254450337449F, -30.822125275346107F, -5.165560857358163F, -2.5916091179302665F, 0.011371605769438098F, -1.0957465174763843F));
        g.addOrReplaceChild("nariz_135", CubeListBuilder.create().texOffs(140, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.3895953603501F, -32.78020409176328F, -5.172082290471676F, -2.6754866058604483F, -0.005487287276928417F, -1.1072554450187622F));
        g.addOrReplaceChild("nariz_136", CubeListBuilder.create().texOffs(154, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.42352505568546F, -34.73697186184479F, -5.111717872061682F, -2.7634112014169303F, -0.049914078931328015F, -1.1171626859086803F));
        g.addOrReplaceChild("nariz_137", CubeListBuilder.create().texOffs(168, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.47965160991865F, -36.69300025077526F, -4.915752031154108F, -2.8502641996100655F, -0.12993331189503615F, -1.125272602086683F));
        g.addOrReplaceChild("nariz_138", CubeListBuilder.create().texOffs(182, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.55376317729802F, -38.648821028034426F, -4.4677349073585395F, -2.9332581377608915F, -0.27639356358693723F, -1.1320443238268454F));
        g.addOrReplaceChild("nariz_139", CubeListBuilder.create().texOffs(484, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.64295141267647F, -40.604813661553706F, -3.316863481768093F, -3.000905310305177F, -0.6647652980431554F, -1.1379688639704004F));
        g.addOrReplaceChild("nariz_140", CubeListBuilder.create().texOffs(430, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-99.62388115712764F, -14.959415306695279F, -4.2186140231840765F, -2.13969214820522F, -0.1623357754523171F, -1.247035985467008F));
        g.addOrReplaceChild("nariz_141", CubeListBuilder.create().texOffs(448, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-98.34598666716437F, -16.933571198522216F, -4.229752146740162F, -2.177598394479812F, -0.1660547946527043F, -1.2405514636403911F));
        g.addOrReplaceChild("nariz_142", CubeListBuilder.create().texOffs(466, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-97.08776233217066F, -18.907658900425186F, -4.242438673274712F, -2.2197395806204896F, -0.16916436463962767F, -1.2326663080164413F));
        g.addOrReplaceChild("nariz_143", CubeListBuilder.create().texOffs(970, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.84947541470085F, -20.881644770389677F, -4.256913729947686F, -2.2666535765208913F, -0.17134242239299224F, -1.223237014557337F));
        g.addOrReplaceChild("nariz_144", CubeListBuilder.create().texOffs(986, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.63150318935824F, -22.855480744541843F, -4.2734254279419845F, -2.318910375632551F, -0.17215303128481607F, -1.2121451224594575F));
        g.addOrReplaceChild("nariz_145", CubeListBuilder.create().texOffs(1002, 329).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.43437510645961F, -24.829098515165008F, -4.292189775498882F, -2.3770745675608063F, -0.17105180538203354F, -1.199364875713448F));
        g.addOrReplaceChild("nariz_146", CubeListBuilder.create().texOffs(0, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.25879545038872F, -26.802405789806443F, -4.31334350771037F, -2.441657781843624F, -0.16735399544823432F, -1.1849919660603083F));
        g.addOrReplaceChild("nariz_147", CubeListBuilder.create().texOffs(16, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.10568037161693F, -28.775280496572663F, -4.3368222869752655F, -2.5222899556938656F, 0.010786235240402346F, -1.0461626111203255F));
        g.addOrReplaceChild("nariz_148", CubeListBuilder.create().texOffs(32, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.97687466672595F, -30.74747952331969F, -4.360893532635374F, -2.5981454273754836F, 0.01039738482703767F, -1.0557641430808733F));
        g.addOrReplaceChild("nariz_149", CubeListBuilder.create().texOffs(196, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.87602784718305F, -32.71852254387013F, -4.368941070440775F, -2.68102685564949F, -0.003317407913733113F, -1.0671627211220556F));
        g.addOrReplaceChild("nariz_150", CubeListBuilder.create().texOffs(210, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.80340494796322F, -34.688344729057015F, -4.32044887991527F, -2.767960568159525F, -0.04001017296836404F, -1.0771954588019403F));
        g.addOrReplaceChild("nariz_151", CubeListBuilder.create().texOffs(224, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.75463873562272F, -36.65747188479946F, -4.156805655897549F, -2.8542953620019653F, -0.10642000641610959F, -1.085637429289212F));
        g.addOrReplaceChild("nariz_152", CubeListBuilder.create().texOffs(238, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.72573899527558F, -38.6264011847105F, -3.7792421265331293F, -2.937902566414159F, -0.22922144697797608F, -1.0928915535609574F));
        g.addOrReplaceChild("nariz_153", CubeListBuilder.create().texOffs(500, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.71394687078136F, -40.59548796819729F, -2.8062840546949235F, -3.010812673358365F, -0.5737806506842467F, -1.0993978241093272F));
        g.addOrReplaceChild("nariz_154", CubeListBuilder.create().texOffs(484, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-101.1416597312824F, -14.784757912786741F, -3.4341462520393025F, -2.146200932070102F, -0.17420486931755957F, -1.2203864289538062F));
        g.addOrReplaceChild("nariz_155", CubeListBuilder.create().texOffs(502, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-99.74295939527988F, -16.77136903394689F, -3.443916922135494F, -2.184210970572133F, -0.17815411797207903F, -1.2133669663759932F));
        g.addOrReplaceChild("nariz_156", CubeListBuilder.create().texOffs(520, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-98.36574453081751F, -18.757922973054214F, -3.455059877755245F, -2.226442033886564F, -0.1814563813031024F, -1.2048641243397697F));
        g.addOrReplaceChild("nariz_157", CubeListBuilder.create().texOffs(48, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-97.01023636312604F, -20.74439219868208F, -3.4678015330622394F, -2.2734237472301158F, -0.18376542652106964F, -1.1947192649095821F));
        g.addOrReplaceChild("nariz_158", CubeListBuilder.create().texOffs(64, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.67678630868329F, -22.73073271439988F, -3.482355569619818F, -2.325709064215719F, -0.18463208249972746F, -1.182820753401539F));
        g.addOrReplaceChild("nariz_159", CubeListBuilder.create().texOffs(80, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.36588805490236F, -24.716881842903714F, -3.4989022801041685F, -2.3838426593258304F, -0.18346655306887316F, -1.1691242755544276F));
        g.addOrReplaceChild("nariz_160", CubeListBuilder.create().texOffs(96, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.07814673355087F, -26.70276105646007F, -3.5175882293395513F, -2.4615673243260034F, 0.008382755682665666F, -0.9996506635244627F));
        g.addOrReplaceChild("nariz_161", CubeListBuilder.create().texOffs(112, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.8143553140467F, -28.688265861553216F, -3.538400476707354F, -2.529985764759435F, 0.009304767759803325F, -1.008301590870545F));
        g.addOrReplaceChild("nariz_162", CubeListBuilder.create().texOffs(128, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.5761679126344F, -30.6731811571317F, -3.5599007290596596F, -2.605119664530652F, 0.009074429693852248F, -1.0178514404370196F));
        g.addOrReplaceChild("nariz_163", CubeListBuilder.create().texOffs(252, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-89.3669089114001F, -32.65707527468758F, -3.568517181609213F, -2.6869423755193886F, -0.0016977031094156886F, -1.0289759929223663F));
        g.addOrReplaceChild("nariz_164", CubeListBuilder.create().texOffs(266, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.18689368965472F, -34.63988089086429F, -3.5309383821054814F, -2.772727302065096F, -0.030958590702960934F, -1.0389957586757317F));
        g.addOrReplaceChild("nariz_165", CubeListBuilder.create().texOffs(280, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.03222341590562F, -36.622060990954935F, -3.3988248608777005F, -2.8582775681933796F, -0.08415447821723787F, -1.0476767952402621F));
        g.addOrReplaceChild("nariz_166", CubeListBuilder.create().texOffs(294, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.89927940864396F, -38.6040606370087F, -3.0911626064856743F, -2.9420284592202033F, -0.1833142529199191F, -1.0553569157858746F));
        g.addOrReplaceChild("nariz_167", CubeListBuilder.create().texOffs(516, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.78555616058362F, -40.58619846098997F, -2.295810537175693F, -3.019078046775793F, -0.4754749533281886F, -1.0624128117896003F));
        g.addOrReplaceChild("nariz_168", CubeListBuilder.create().texOffs(708, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-102.66379343641003F, -14.611893637264254F, -2.6577268357823245F, -2.1530589629034633F, -0.18583968192062753F, -1.195105714971915F));
        g.addOrReplaceChild("nariz_169", CubeListBuilder.create().texOffs(728, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-101.14442608887323F, -16.610766927771735F, -2.6658269807063557F, -2.1911811045506417F, -0.19000730884845785F, -1.1875491158216254F));
        g.addOrReplaceChild("nariz_170", CubeListBuilder.create().texOffs(538, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-99.64836179238384F, -18.60959496634878F, -2.675076211506091F, -2.233508714445744F, -0.19349160693281325F, -1.1784312769327954F));
        g.addOrReplaceChild("nariz_171", CubeListBuilder.create().texOffs(144, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-98.17580865577074F, -20.608352379360547F, -2.6856499816382473F, -2.280560822394505F, -0.19593505008184312F, -1.1675915237767562F));
        g.addOrReplaceChild("nariz_172", CubeListBuilder.create().texOffs(160, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.72706619477091F, -22.607002134503514F, -2.6977230259568388F, -2.332875025862627F, -0.19685151902163908F, -1.1548956590024921F));
        g.addOrReplaceChild("nariz_173", CubeListBuilder.create().texOffs(176, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.30250294978606F, -24.605497616560513F, -2.7114822319849643F, -2.390978915774949F, -0.19561341523095607F, -1.140292350594719F));
        g.addOrReplaceChild("nariz_174", CubeListBuilder.create().texOffs(192, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.90261764600922F, -26.603774902090585F, -2.727069886404363F, -2.470188415495319F, 0.006793277663660118F, -0.9638777087010569F));
        g.addOrReplaceChild("nariz_175", CubeListBuilder.create().texOffs(208, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.52809750070014F, -28.60174487401885F, -2.744477838174474F, -2.538044952310186F, 0.007565093399839553F, -0.9725445062822966F));
        g.addOrReplaceChild("nariz_176", CubeListBuilder.create().texOffs(224, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.18034516104987F, -30.599227499032434F, -2.7625605743266117F, -2.612435741414999F, 0.007442702377967843F, -0.9819574468913342F));
        g.addOrReplaceChild("nariz_177", CubeListBuilder.create().texOffs(308, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-89.86218954650786F, -32.5958600850609F, -2.770807654366014F, -2.69316021724415F, -0.0005793738227261715F, -0.9926661518208348F));
        g.addOrReplaceChild("nariz_178", CubeListBuilder.create().texOffs(322, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.57395942272237F, -34.591578580506194F, -2.743198609921661F, -2.7776713955403336F, -0.02273728011343589F, -1.0025537222650223F));
        g.addOrReplaceChild("nariz_179", CubeListBuilder.create().texOffs(336, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.312386330146F, -36.58676584498175F, -2.641819594676421F, -2.862211057747517F, -0.06318349270145579F, -1.0113896500820965F));
        g.addOrReplaceChild("nariz_180", CubeListBuilder.create().texOffs(350, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.07437405534463F, -38.58179786773978F, -2.403496703108526F, -2.945685135483241F, -0.13902518145067042F, -1.0194407808574664F));
        g.addOrReplaceChild("nariz_181", CubeListBuilder.create().texOffs(532, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.85777553117147F, -40.57694431769044F, -1.7854349228984592F, -3.0256852254573037F, -0.37151569500623305F, -1.027010978321844F));
        g.addOrReplaceChild("nariz_182", CubeListBuilder.create().texOffs(748, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-104.19008619529345F, -14.440779760729521F, -1.8891637174764568F, -2.1601921296242486F, -0.1972295533694123F, -1.1711249648002922F));
        g.addOrReplaceChild("nariz_183", CubeListBuilder.create().texOffs(768, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-102.55024994629986F, -16.451722853184897F, -1.895278459363059F, -2.198432596612868F, -0.2016040389028782F, -1.1630323693334874F));
        g.addOrReplaceChild("nariz_184", CubeListBuilder.create().texOffs(788, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-100.93553689879997F, -18.462633316333005F, -1.9022687613226827F, -2.2408614634213393F, -0.20526022572667227F, -1.1533055127209577F));
        g.addOrReplaceChild("nariz_185", CubeListBuilder.create().texOffs(964, 324).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-99.34610964099397F, -20.47349158133538F, -1.9102667918989482F, -2.2879845443054507F, -0.20782272068952903F, -1.1417754168288685F));
        g.addOrReplaceChild("nariz_186", CubeListBuilder.create().texOffs(982, 324).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-97.78218091865854F, -22.48427158508809F, -1.9194198765656618F, -2.3403294120970615F, -0.20877578290896975F, -1.1282933620426825F));
        g.addOrReplaceChild("nariz_187", CubeListBuilder.create().texOffs(1000, 324).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.24402102615441F, -24.494939546968766F, -1.92988603871432F, -2.4179236802378417F, 0.004421512123877237F, -0.9218296114240898F));
        g.addOrReplaceChild("nariz_188", CubeListBuilder.create().texOffs(0, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.73206013292742F, -26.505441526371786F, -1.9417409309867713F, -2.479093947049832F, 0.005005374442188982F, -0.9301896860034184F));
        g.addOrReplaceChild("nariz_189", CubeListBuilder.create().texOffs(240, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.24682788976875F, -28.515709651763295F, -1.9549815918048061F, -2.5463773958955698F, 0.005591325720864311F, -0.938812325357003F));
        g.addOrReplaceChild("nariz_190", CubeListBuilder.create().texOffs(256, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.78934579660034F, -30.525613875384497F, -1.9688316652489515F, -2.6200018591250767F, 0.005565465170356248F, -0.9479989354743686F));
        g.addOrReplaceChild("nariz_191", CubeListBuilder.create().texOffs(364, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-90.36181471581705F, -32.53487562914498F, -1.9758185532190382F, -2.699609926739303F, 8.288812471024365e-05F, -0.9581888950534635F));
        g.addOrReplaceChild("nariz_192", CubeListBuilder.create().texOffs(378, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.96456787872798F, -34.54343640822834F, -1.9572463415836636F, -2.782754401042951F, -0.01531652072902067F, -0.9678421753463063F));
        g.addOrReplaceChild("nariz_193", CubeListBuilder.create().texOffs(392, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.59510648063895F, -36.551585011069434F, -1.8858047890983198F, -2.8660978105232005F, -0.043525542677346124F, -0.9767573508222186F));
        g.addOrReplaceChild("nariz_194", CubeListBuilder.create().texOffs(406, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.25101079382122F, -38.55961165902686F, -1.716253129081591F, -2.948928730672038F, -0.09663010081255885F, -0.9851268916647956F));
        g.addOrReplaceChild("nariz_195", CubeListBuilder.create().texOffs(420, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.9306000788597F, -40.56772490530015F, -1.2751594638462027F, -3.030678733462138F, -0.2642576281716221F, -0.9931745463174201F));
        g.addOrReplaceChild("nariz_196", CubeListBuilder.create().texOffs(808, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-105.72041620280848F, -14.27136798341379F, -1.1282405801258018F, -2.1675360748701555F, -0.20835849679705087F, -1.148360916337589F));
        g.addOrReplaceChild("nariz_197", CubeListBuilder.create().texOffs(828, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-103.96027417493403F, -16.294199373829894F, -1.1320907357458185F, -2.205898374544482F, -0.21292682667064539F, -1.1397371957714948F));
        g.addOrReplaceChild("nariz_198", CubeListBuilder.create().texOffs(848, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-102.22708118481F, -18.3170111147684F, -1.1364969412311532F, -2.248430371558847F, -0.21674307308586066F, -1.129411257455507F));
        g.addOrReplaceChild("nariz_199", CubeListBuilder.create().texOffs(18, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-100.52092286941885F, -20.33979295087699F, -1.1415561742355589F, -2.295629243492414F, -0.2194085970668807F, -1.1171986321385285F));
        g.addOrReplaceChild("nariz_200", CubeListBuilder.create().texOffs(36, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-98.84192776811284F, -22.362529329184923F, -1.14737157531582F, -2.3480027296241737F, -0.2203947762326871F, -1.1029567775108604F));
        g.addOrReplaceChild("nariz_201", CubeListBuilder.create().texOffs(54, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-97.19031985574023F, -24.385193084433354F, -1.1540092762873833F, -2.4274455647660154F, 0.0027110563872572574F, -0.8901308990058118F));
        g.addOrReplaceChild("nariz_202", CubeListBuilder.create().texOffs(72, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.56638975125334F, -26.40774822517009F, -1.161502031475602F, -2.4881910762444903F, 0.0030674812482101403F, -0.8984640477126384F));
        g.addOrReplaceChild("nariz_203", CubeListBuilder.create().texOffs(90, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.970436822437F, -28.43015630953578F, -1.1698785954550732F, -2.5548917424857143F, 0.003436539785988651F, -0.9069962456145642F));
        g.addOrReplaceChild("nariz_204", CubeListBuilder.create().texOffs(108, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.40307469186897F, -30.45233988006669F, -1.178714517662445F, -2.6277475033355704F, 0.003470633560800716F, -0.9159026779090044F));
        g.addOrReplaceChild("nariz_205", CubeListBuilder.create().texOffs(548, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-90.86573616529705F, -32.47411984042839F, -1.1835430924714172F, -2.70623145994786F, 0.0003196137844880418F, -0.9254926750567509F));
        g.addOrReplaceChild("nariz_206", CubeListBuilder.create().texOffs(564, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-89.35870224464203F, -34.495450980794956F, -1.1730634451619752F, -2.7879421062740346F, -0.008664277391362786F, -0.9348198371192207F));
        g.addOrReplaceChild("nariz_207", CubeListBuilder.create().texOffs(434, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.8803765737952F, -36.516515482239214F, -1.1307606916702608F, -2.869939126839563F, -0.02517219263031418F, -0.9437446248482667F));
        g.addOrReplaceChild("nariz_208", CubeListBuilder.create().texOffs(448, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.42918315669779F, -38.53750017018489F, -1.029421943274369F, -2.951813887446634F, -0.056319581051741736F, -0.9523830194496703F));
        g.addOrReplaceChild("nariz_209", CubeListBuilder.create().texOffs(580, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.00402545059575F, -40.55853955800983F, -0.7649880140109194F, -3.03415826874868F, -0.15648740239097933F, -0.9608724530656015F));
        g.addOrReplaceChild("nariz_210", CubeListBuilder.create().texOffs(868, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-107.2545025570119F, -14.103629909420171F, -0.3748303059817832F, -2.175036910736228F, -0.21921508254405F, -1.126736916183503F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("nariz_211", CubeListBuilder.create().texOffs(888, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-105.37421545600475F, -16.138175150821553F, -0.37616093413018103F, -2.213522998392423F, -0.22396358102198144F, -1.1175897106891985F));
        g.addOrReplaceChild("nariz_212", CubeListBuilder.create().texOffs(908, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-103.52271091303575F, -18.17271382059114F, -0.37768489886817297F, -2.256158620425906F, -0.2279273005354952F, -1.106677378047253F));
        g.addOrReplaceChild("nariz_213", CubeListBuilder.create().texOffs(126, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-101.70001837978143F, -20.207242421494445F, -0.37943631740967654F, -2.303429332302376F, -0.2306925614379277F, -1.093808640919914F));
        g.addOrReplaceChild("nariz_214", CubeListBuilder.create().texOffs(144, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-99.90618226741233F, -22.24175562484497F, -0.38145168251251427F, -2.3822255351080495F, 0.0007978990863762157F, -0.8521880467827593F));
        g.addOrReplaceChild("nariz_215", CubeListBuilder.create().texOffs(162, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-98.14130005979997F, -24.27624179692355F, -0.38373790620694825F, -2.4370869112836093F, 0.0009001507182636278F, -0.8603199563670572F));
        g.addOrReplaceChild("nariz_216", CubeListBuilder.create().texOffs(180, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.40545902139695F, -26.31069009113272F, -0.3863166375677949F, -2.497409216836092F, 0.001028781832701731F, -0.8685757538881403F));
        g.addOrReplaceChild("nariz_217", CubeListBuilder.create().texOffs(198, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.69874287741378F, -28.345089591611725F, -0.3892155482417792F, -2.5635206690860883F, 0.0011549734420892867F, -0.8769838915882202F));
        g.addOrReplaceChild("nariz_218", CubeListBuilder.create().texOffs(216, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.02137673974335F, -30.379412244380084F, -0.39228460793697584F, -2.635596840037891F, 0.0011730506679717546F, -0.8855953344457108F));
        g.addOrReplaceChild("nariz_219", CubeListBuilder.create().texOffs(596, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-91.37386309848618F, -32.413595758961605F, -0.39403996299102584F, -2.7129642268921774F, 0.0001644043202529029F, -0.8945161884873793F));
        g.addOrReplaceChild("nariz_220", CubeListBuilder.create().texOffs(612, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-89.75630990511578F, -34.44762329053701F, -0.3907022640165677F, -2.7932008337749803F, -0.0027434281783918647F, -0.9034369656475536F));
        g.addOrReplaceChild("nariz_221", CubeListBuilder.create().texOffs(628, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.16816339005831F, -36.481557481070546F, -0.37673569291346853F, -2.873737211509928F, -0.008099513332879628F, -0.9123085881313474F));
        g.addOrReplaceChild("nariz_222", CubeListBuilder.create().texOffs(644, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.60886925971809F, -38.5154635085924F, -0.3430520454540794F, -2.954397301308431F, -0.018218553624332594F, -0.9211696614905768F));
        g.addOrReplaceChild("nariz_223", CubeListBuilder.create().texOffs(660, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.07804137930133F, -40.54938836619093F, -0.25496444738595037F, -3.036282810775541F, -0.05105074553584793F, -0.9300663461955264F));
        g.addOrReplaceChild("nariz_224", CubeListBuilder.create().texOffs(928, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-107.25450255701192F, -14.103629909420167F, 0.37483030598177974F, 2.175036910736228F, 0.21921508254404837F, -1.1267369161835012F));
        g.addOrReplaceChild("nariz_225", CubeListBuilder.create().texOffs(948, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-105.37421545600475F, -16.138175150821553F, 0.3761609341301836F, 2.213522998392424F, 0.2239635810219806F, -1.117589710689197F));
        g.addOrReplaceChild("nariz_226", CubeListBuilder.create().texOffs(968, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-103.52271091303575F, -18.17271382059114F, 0.377684898868174F, 2.2561586204259045F, 0.22792730053549656F, -1.106677378047254F));
        g.addOrReplaceChild("nariz_227", CubeListBuilder.create().texOffs(234, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-101.70001837978143F, -20.207242421494445F, 0.3794363174096752F, 2.3034293323023736F, 0.2306925614379267F, -1.093808640919915F));
        g.addOrReplaceChild("nariz_228", CubeListBuilder.create().texOffs(252, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-99.90618226741233F, -22.241755624844963F, 0.38145168251251343F, 2.382225535108048F, -0.0007978990863755998F, -0.8521880467827587F));
        g.addOrReplaceChild("nariz_229", CubeListBuilder.create().texOffs(270, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-98.14130005979996F, -24.276241796923554F, 0.38373790620694903F, 2.4370869112836084F, -0.0009001507182654268F, -0.8603199563670576F));
        g.addOrReplaceChild("nariz_230", CubeListBuilder.create().texOffs(288, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.40545902139696F, -26.31069009113272F, 0.38631663756779167F, 2.497409216836093F, -0.0010287818326969423F, -0.8685757538881419F));
        g.addOrReplaceChild("nariz_231", CubeListBuilder.create().texOffs(306, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.69874287741378F, -28.345089591611725F, 0.38921554824176574F, 2.563520669086086F, -0.001154973442086393F, -0.8769838915882227F));
        g.addOrReplaceChild("nariz_232", CubeListBuilder.create().texOffs(324, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.02137673974335F, -30.37941224438008F, 0.39228460793696474F, 2.635596840037894F, -0.0011730506679764649F, -0.8855953344457081F));
        g.addOrReplaceChild("nariz_233", CubeListBuilder.create().texOffs(676, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-91.3738630984862F, -32.413595758961605F, 0.3940399629910196F, 2.712964226892177F, -0.00016440432025188092F, -0.8945161884873777F));
        g.addOrReplaceChild("nariz_234", CubeListBuilder.create().texOffs(692, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-89.75630990511578F, -34.44762329053701F, 0.39070226401656794F, 2.7932008337749794F, 0.0027434281783858625F, -0.9034369656475536F));
        g.addOrReplaceChild("nariz_235", CubeListBuilder.create().texOffs(708, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.16816339005831F, -36.481557481070546F, 0.37673569291347386F, 2.8737372115099293F, 0.00809951333288173F, -0.9123085881313465F));
        g.addOrReplaceChild("nariz_236", CubeListBuilder.create().texOffs(724, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.6088692597181F, -38.51546350859239F, 0.34305204545408396F, 2.954397301308435F, 0.018218553624331127F, -0.9211696614905789F));
        g.addOrReplaceChild("nariz_237", CubeListBuilder.create().texOffs(740, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.07804137930134F, -40.549388366190925F, 0.25496444738595175F, 3.0362828107755484F, 0.05105074553585175F, -0.9300663461955251F));
        g.addOrReplaceChild("nariz_238", CubeListBuilder.create().texOffs(988, 314).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-105.72041620280848F, -14.27136798341379F, 1.1282405801257975F, 2.167536074870155F, 0.20835849679704752F, -1.148360916337586F));
        g.addOrReplaceChild("nariz_239", CubeListBuilder.create().texOffs(0, 319).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-103.96027417493403F, -16.294199373829894F, 1.132090735745823F, 2.2058983745444816F, 0.2129268266706451F, -1.1397371957714952F));
        g.addOrReplaceChild("nariz_240", CubeListBuilder.create().texOffs(20, 319).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-102.22708118480999F, -18.3170111147684F, 1.1364969412311539F, 2.2484303715588507F, 0.21674307308586335F, -1.129411257455508F));
        g.addOrReplaceChild("nariz_241", CubeListBuilder.create().texOffs(342, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-100.52092286941887F, -20.33979295087699F, 1.1415561742355553F, 2.2956292434924195F, 0.21940859706688146F, -1.117198632138527F));
        g.addOrReplaceChild("nariz_242", CubeListBuilder.create().texOffs(360, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-98.84192776811285F, -22.36252932918492F, 1.1473715753158165F, 2.3480027296241794F, 0.22039477623268813F, -1.102956777510858F));
        g.addOrReplaceChild("nariz_243", CubeListBuilder.create().texOffs(378, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-97.19031985574024F, -24.38519308443335F, 1.1540092762873826F, 2.4274455647660167F, -0.002711056387259446F, -0.8901308990058105F));
        g.addOrReplaceChild("nariz_244", CubeListBuilder.create().texOffs(396, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.56638975125335F, -26.40774822517009F, 1.161502031475593F, 2.488191076244489F, -0.003067481248201436F, -0.8984640477126419F));
        g.addOrReplaceChild("nariz_245", CubeListBuilder.create().texOffs(414, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.97043682243701F, -28.430156309535775F, 1.169878595455046F, 2.5548917424857134F, -0.003436539785983124F, -0.9069962456145694F));
        g.addOrReplaceChild("nariz_246", CubeListBuilder.create().texOffs(432, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.403074691869F, -30.452339880066685F, 1.178714517662422F, 2.6277475033355704F, -0.003470633560809655F, -0.9159026779089995F));
        g.addOrReplaceChild("nariz_247", CubeListBuilder.create().texOffs(756, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-90.86573616529708F, -32.474119840428386F, 1.1835430924714039F, 2.706231459947867F, -0.00031961378448672477F, -0.925492675056749F));
        g.addOrReplaceChild("nariz_248", CubeListBuilder.create().texOffs(772, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-89.35870224464205F, -34.495450980794956F, 1.1730634451619724F, 2.787942106274032F, 0.008664277391353167F, -0.9348198371192162F));
        g.addOrReplaceChild("nariz_249", CubeListBuilder.create().texOffs(462, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.8803765737952F, -36.516515482239214F, 1.1307606916702666F, 2.8699391268395553F, 0.025172192630316895F, -0.9437446248482682F));
        g.addOrReplaceChild("nariz_250", CubeListBuilder.create().texOffs(476, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.42918315669777F, -38.537500170184884F, 1.0294219432743752F, 2.9518138874466224F, 0.056319581051738773F, -0.9523830194496703F));
        g.addOrReplaceChild("nariz_251", CubeListBuilder.create().texOffs(788, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.00402545059575F, -40.55853955800982F, 0.7649880140109215F, 3.0341582687486612F, 0.15648740239098535F, -0.9608724530656023F));
        g.addOrReplaceChild("nariz_252", CubeListBuilder.create().texOffs(40, 319).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-104.19008619529343F, -14.440779760729521F, 1.8891637174764546F, 2.1601921296242477F, 0.19722955336940928F, -1.1711249648002886F));
        g.addOrReplaceChild("nariz_253", CubeListBuilder.create().texOffs(60, 319).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-102.55024994629986F, -16.451722853184897F, 1.8952784593630623F, 2.198432596612864F, 0.20160403890287723F, -1.163032369333489F));
        g.addOrReplaceChild("nariz_254", CubeListBuilder.create().texOffs(80, 319).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-100.93553689879997F, -18.462633316333005F, 1.9022687613226823F, 2.2408614634213326F, 0.20526022572667138F, -1.1533055127209622F));
        g.addOrReplaceChild("nariz_255", CubeListBuilder.create().texOffs(450, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-99.34610964099399F, -20.47349158133538F, 1.9102667918989447F, 2.287984544305446F, 0.20782272068952856F, -1.1417754168288698F));
        g.addOrReplaceChild("nariz_256", CubeListBuilder.create().texOffs(468, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-97.78218091865853F, -22.484271585088088F, 1.9194198765656578F, 2.3403294120970566F, 0.2087757829089695F, -1.1282933620426843F));
        g.addOrReplaceChild("nariz_257", CubeListBuilder.create().texOffs(486, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.24402102615443F, -24.494939546968766F, 1.9298860387143173F, 2.4179236802378385F, -0.004421512123878195F, -0.9218296114240879F));
        g.addOrReplaceChild("nariz_258", CubeListBuilder.create().texOffs(504, 329).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.73206013292743F, -26.505441526371783F, 1.9417409309867597F, 2.4790939470498334F, -0.0050053744421811215F, -0.9301896860034227F));
        g.addOrReplaceChild("nariz_259", CubeListBuilder.create().texOffs(272, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.24682788976878F, -28.515709651763295F, 1.9549815918047786F, 2.5463773958955658F, -0.00559132572085946F, -0.9388123253570057F));
        g.addOrReplaceChild("nariz_260", CubeListBuilder.create().texOffs(288, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.78934579660036F, -30.525613875384497F, 1.9688316652489266F, 2.6200018591250682F, -0.005565465170363152F, -0.9479989354743659F));
        g.addOrReplaceChild("nariz_261", CubeListBuilder.create().texOffs(490, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-90.36181471581708F, -32.534875629144985F, 1.9758185532190229F, 2.6996099267392966F, -8.288812471096684e-05F, -0.9581888950534625F));
        g.addOrReplaceChild("nariz_262", CubeListBuilder.create().texOffs(504, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.96456787872799F, -34.54343640822834F, 1.957246341583659F, 2.782754401042955F, 0.015316520729012397F, -0.9678421753463007F));
        g.addOrReplaceChild("nariz_263", CubeListBuilder.create().texOffs(518, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.59510648063895F, -36.551585011069434F, 1.8858047890983234F, 2.866097810523209F, 0.0435255426773477F, -0.9767573508222209F));
        g.addOrReplaceChild("nariz_264", CubeListBuilder.create().texOffs(532, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.25101079382122F, -38.55961165902686F, 1.716253129081594F, 2.9489287306720464F, 0.09663010081255757F, -0.9851268916647932F));
        g.addOrReplaceChild("nariz_265", CubeListBuilder.create().texOffs(546, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.9306000788597F, -40.56772490530015F, 1.2751594638462038F, 3.030678733462149F, 0.2642576281716251F, -0.9931745463174225F));
        g.addOrReplaceChild("nariz_266", CubeListBuilder.create().texOffs(100, 319).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-102.66379343641005F, -14.611893637264252F, 2.6577268357823205F, 2.153058962903468F, 0.1858396819206271F, -1.1951057149719095F));
        g.addOrReplaceChild("nariz_267", CubeListBuilder.create().texOffs(120, 319).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-101.14442608887322F, -16.61076692777174F, 2.6658269807063606F, 2.191181104550645F, 0.19000730884845773F, -1.187549115821623F));
        g.addOrReplaceChild("nariz_268", CubeListBuilder.create().texOffs(556, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-99.64836179238384F, -18.60959496634878F, 2.6750762115060933F, 2.233508714445745F, 0.19349160693281517F, -1.1784312769328003F));
        g.addOrReplaceChild("nariz_269", CubeListBuilder.create().texOffs(304, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-98.17580865577074F, -20.608352379360543F, 2.685649981638244F, 2.2805608223945084F, 0.1959350500818435F, -1.167591523776754F));
        g.addOrReplaceChild("nariz_270", CubeListBuilder.create().texOffs(320, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-96.7270661947709F, -22.60700213450351F, 2.6977230259568343F, 2.332875025862628F, 0.19685151902163986F, -1.1548956590024924F));
        g.addOrReplaceChild("nariz_271", CubeListBuilder.create().texOffs(336, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.30250294978605F, -24.605497616560513F, 2.7114822319849594F, 2.3909789157749506F, 0.19561341523095513F, -1.1402923505947171F));
        g.addOrReplaceChild("nariz_272", CubeListBuilder.create().texOffs(352, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.90261764600923F, -26.60377490209058F, 2.72706988640435F, 2.470188415495318F, -0.006793277663651928F, -0.9638777087010613F));
        g.addOrReplaceChild("nariz_273", CubeListBuilder.create().texOffs(368, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.52809750070017F, -28.60174487401885F, 2.744477838174447F, 2.538044952310185F, -0.007565093399835696F, -0.9725445062822966F));
        g.addOrReplaceChild("nariz_274", CubeListBuilder.create().texOffs(384, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.18034516104989F, -30.59922749903243F, 2.762560574326588F, 2.6124357414150006F, -0.007442702377974962F, -0.9819574468913342F));
        g.addOrReplaceChild("nariz_275", CubeListBuilder.create().texOffs(560, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-89.86218954650786F, -32.5958600850609F, 2.770807654365998F, 2.6931602172441518F, 0.0005793738227269137F, -0.9926661518208311F));
        g.addOrReplaceChild("nariz_276", CubeListBuilder.create().texOffs(574, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.57395942272238F, -34.591578580506194F, 2.743198609921656F, 2.777671395540329F, 0.02273728011342608F, -1.0025537222650212F));
        g.addOrReplaceChild("nariz_277", CubeListBuilder.create().texOffs(588, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.312386330146F, -36.58676584498175F, 2.641819594676426F, 2.8622110577475164F, 0.0631834927014572F, -1.0113896500820965F));
        g.addOrReplaceChild("nariz_278", CubeListBuilder.create().texOffs(602, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.07437405534463F, -38.58179786773978F, 2.4034967031085293F, 2.945685135483241F, 0.1390251814506708F, -1.0194407808574664F));
        g.addOrReplaceChild("nariz_279", CubeListBuilder.create().texOffs(804, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.85777553117147F, -40.57694431769045F, 1.7854349228984605F, 3.0256852254573037F, 0.37151569500623394F, -1.027010978321844F));
        g.addOrReplaceChild("nariz_280", CubeListBuilder.create().texOffs(574, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-101.1416597312824F, -14.78475791278674F, 3.434146252039299F, 2.1462009320700997F, 0.1742048693175576F, -1.2203864289538051F));
        g.addOrReplaceChild("nariz_281", CubeListBuilder.create().texOffs(592, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-99.74295939527988F, -16.77136903394689F, 3.4439169221355006F, 2.184210970572135F, 0.17815411797207703F, -1.213366966375988F));
        g.addOrReplaceChild("nariz_282", CubeListBuilder.create().texOffs(610, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-98.3657445308175F, -18.757922973054214F, 3.4550598777552493F, 2.2264420338865625F, 0.18145638130310415F, -1.204864124339778F));
        g.addOrReplaceChild("nariz_283", CubeListBuilder.create().texOffs(400, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-97.01023636312604F, -20.74439219868208F, 3.4678015330622376F, 2.2734237472301175F, 0.18376542652107075F, -1.1947192649095775F));
        g.addOrReplaceChild("nariz_284", CubeListBuilder.create().texOffs(416, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.6767863086833F, -22.730732714399878F, 3.4823555696198145F, 2.3257090642157157F, 0.18463208249972926F, -1.182820753401543F));
        g.addOrReplaceChild("nariz_285", CubeListBuilder.create().texOffs(432, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.36588805490236F, -24.716881842903714F, 3.498902280104166F, 2.3838426593258286F, 0.18346655306887172F, -1.1691242755544267F));
        g.addOrReplaceChild("nariz_286", CubeListBuilder.create().texOffs(448, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.07814673355087F, -26.702761056460066F, 3.5175882293395393F, 2.4615673243260074F, -0.008382755682653505F, -0.9996506635244716F));
        g.addOrReplaceChild("nariz_287", CubeListBuilder.create().texOffs(464, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.81435531404671F, -28.688265861553212F, 3.5384004767073263F, 2.5299857647594455F, -0.009304767759802378F, -1.008301590870545F));
        g.addOrReplaceChild("nariz_288", CubeListBuilder.create().texOffs(480, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.57616791263442F, -30.6731811571317F, 3.559900729059639F, 2.6051196645306574F, -0.009074429693859363F, -1.0178514404370178F));
        g.addOrReplaceChild("nariz_289", CubeListBuilder.create().texOffs(616, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-89.3669089114001F, -32.65707527468758F, 3.5685171816091987F, 2.6869423755193926F, 0.001697703109417791F, -1.0289759929223619F));
        g.addOrReplaceChild("nariz_290", CubeListBuilder.create().texOffs(630, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.18689368965472F, -34.6398808908643F, 3.530938382105477F, 2.7727273020650993F, 0.030958590702950844F, -1.038995758675731F));
        g.addOrReplaceChild("nariz_291", CubeListBuilder.create().texOffs(644, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.03222341590562F, -36.622060990954935F, 3.3988248608777063F, 2.858277568193381F, 0.08415447821723891F, -1.0476767952402624F));
        g.addOrReplaceChild("nariz_292", CubeListBuilder.create().texOffs(658, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.89927940864396F, -38.6040606370087F, 3.0911626064856774F, 2.9420284592202033F, 0.18331425291992032F, -1.0553569157858746F));
        g.addOrReplaceChild("nariz_293", CubeListBuilder.create().texOffs(820, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.78555616058362F, -40.58619846098997F, 2.295810537175694F, 3.0190780467757925F, 0.4754749533281891F, -1.0624128117896003F));
        g.addOrReplaceChild("nariz_294", CubeListBuilder.create().texOffs(628, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-99.62388115712764F, -14.959415306695277F, 4.218614023184073F, 2.1396921482052242F, 0.16233577545231712F, -1.247035985467006F));
        g.addOrReplaceChild("nariz_295", CubeListBuilder.create().texOffs(646, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-98.34598666716437F, -16.933571198522216F, 4.229752146740166F, 2.1775983944798156F, 0.1660547946527022F, -1.2405514636403856F));
        g.addOrReplaceChild("nariz_296", CubeListBuilder.create().texOffs(664, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-97.08776233217066F, -18.90765890042519F, 4.242438673274717F, 2.2197395806204887F, 0.16916436463963025F, -1.2326663080164482F));
        g.addOrReplaceChild("nariz_297", CubeListBuilder.create().texOffs(496, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-95.84947541470086F, -20.88164477038968F, 4.256913729947686F, 2.2666535765208957F, 0.17134242239299202F, -1.223237014557331F));
        g.addOrReplaceChild("nariz_298", CubeListBuilder.create().texOffs(512, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.63150318935824F, -22.855480744541843F, 4.273425427941983F, 2.3189103756325573F, 0.17215303128481832F, -1.2121451224594577F));
        g.addOrReplaceChild("nariz_299", CubeListBuilder.create().texOffs(528, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.43437510645961F, -24.829098515165008F, 4.292189775498883F, 2.3770745675608134F, 0.1710518053820302F, -1.1993648757134434F));
        g.addOrReplaceChild("nariz_300", CubeListBuilder.create().texOffs(544, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.25879545038873F, -26.802405789806443F, 4.31334350771036F, 2.44165778184363F, 0.1673539954482416F, -1.1849919660603139F));
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("nariz_301", CubeListBuilder.create().texOffs(560, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.10568037161696F, -28.775280496572655F, 4.33682228697524F, 2.5222899556938683F, -0.010786235240404545F, -1.0461626111203206F));
        g.addOrReplaceChild("nariz_302", CubeListBuilder.create().texOffs(576, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.97687466672596F, -30.74747952331969F, 4.360893532635355F, 2.5981454273754787F, -0.010397384827041957F, -1.055764143080871F));
        g.addOrReplaceChild("nariz_303", CubeListBuilder.create().texOffs(672, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.87602784718307F, -32.71852254387013F, 4.368941070440762F, 2.6810268556494905F, 0.0033174079137318156F, -1.067162721122051F));
        g.addOrReplaceChild("nariz_304", CubeListBuilder.create().texOffs(686, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.80340494796322F, -34.68834472905702F, 4.3204488799152685F, 2.767960568159526F, 0.04001017296835492F, -1.0771954588019403F));
        g.addOrReplaceChild("nariz_305", CubeListBuilder.create().texOffs(700, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.7546387356227F, -36.65747188479946F, 4.156805655897557F, 2.8542953620019684F, 0.10642000641611084F, -1.0856374292892113F));
        g.addOrReplaceChild("nariz_306", CubeListBuilder.create().texOffs(714, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.72573899527559F, -38.6264011847105F, 3.779242126533134F, 2.93790256641416F, 0.2292214469779778F, -1.0928915535609574F));
        g.addOrReplaceChild("nariz_307", CubeListBuilder.create().texOffs(836, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.71394687078136F, -40.59548796819729F, 2.806284054694925F, 3.010812673358366F, 0.5737806506842477F, -1.099397824109327F));
        g.addOrReplaceChild("nariz_308", CubeListBuilder.create().texOffs(682, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-98.11063273684854F, -15.135913849569162F, 5.011345281740525F, 2.133614077968563F, 0.1502542139658614F, -1.2751333247005197F));
        g.addOrReplaceChild("nariz_309", CubeListBuilder.create().texOffs(700, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.95370569909807F, -17.09741093800876F, 5.023513702024939F, 2.1714271947114763F, 0.15373318424985657F, -1.269177225312118F));
        g.addOrReplaceChild("nariz_310", CubeListBuilder.create().texOffs(718, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-95.81463330481172F, -19.058830075332004F, 5.037355422738953F, 2.2134873729731526F, 0.15664186568892108F, -1.2619080575724626F));
        g.addOrReplaceChild("nariz_311", CubeListBuilder.create().texOffs(592, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-94.69371371775549F, -21.02013324635058F, 5.053120190178301F, 2.2603421223396807F, 0.15868113373604198F, -1.2531950021899378F));
        g.addOrReplaceChild("nariz_312", CubeListBuilder.create().texOffs(608, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.59135163719023F, -22.981268107757707F, 5.07107103567126F, 2.3125736302058297F, 0.1594378111902867F, -1.2429226676354992F));
        g.addOrReplaceChild("nariz_313", CubeListBuilder.create().texOffs(624, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.50809356571597F, -24.94216292027324F, 5.091451307996475F, 2.3707644374900125F, 0.1584016734481167F, -1.2310702264009854F));
        g.addOrReplaceChild("nariz_314", CubeListBuilder.create().texOffs(640, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.44470629088525F, -26.90271594553562F, 5.114388539385818F, 2.4354514103635365F, 0.15494909951067823F, -1.2177439908367425F));
        g.addOrReplaceChild("nariz_315", CubeListBuilder.create().texOffs(656, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.40219614112185F, -28.862791597091597F, 5.139769221528273F, 2.515065671221606F, -0.011979223234741062F, -1.086192390637541F));
        g.addOrReplaceChild("nariz_316", CubeListBuilder.create().texOffs(672, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.3825445033745F, -30.822125275346103F, 5.165560857358145F, 2.5916091179302656F, -0.011371605769439701F, -1.0957465174763847F));
        g.addOrReplaceChild("nariz_317", CubeListBuilder.create().texOffs(728, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-88.3895953603501F, -32.78020409176328F, 5.172082290471661F, 2.6754866058604527F, 0.005487287276925974F, -1.1072554450187593F));
        g.addOrReplaceChild("nariz_318", CubeListBuilder.create().texOffs(742, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.42352505568546F, -34.73697186184479F, 5.111717872061679F, 2.763411201416932F, 0.04991407893131974F, -1.117162685908678F));
        g.addOrReplaceChild("nariz_319", CubeListBuilder.create().texOffs(756, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.47965160991866F, -36.69300025077526F, 4.915752031154113F, 2.8502641996100606F, 0.12993331189503735F, -1.1252726020866823F));
        g.addOrReplaceChild("nariz_320", CubeListBuilder.create().texOffs(770, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.55376317729802F, -38.648821028034426F, 4.467734907358543F, 2.9332581377608915F, 0.27639356358693756F, -1.132044323826846F));
        g.addOrReplaceChild("nariz_321", CubeListBuilder.create().texOffs(852, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.64295141267647F, -40.604813661553706F, 3.3168634817680953F, 3.0009053103051806F, 0.6647652980431564F, -1.1379688639703998F));
        g.addOrReplaceChild("nariz_322", CubeListBuilder.create().texOffs(736, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-96.60208016294473F, -15.31430576395327F, 5.812574006321997F, 2.1280594306604836F, 0.1379851238092926F, -1.3047515948578101F));
        g.addOrReplaceChild("nariz_323", CubeListBuilder.create().texOffs(754, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-95.56630077286297F, -17.2629298826416F, 5.825402588382991F, 2.165792691708639F, 0.14121671484982068F, -1.2993127602292167F));
        g.addOrReplaceChild("nariz_324", CubeListBuilder.create().texOffs(772, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-94.54655628685168F, -19.211468087822176F, 5.839975450761829F, 2.2077834665677996F, 0.14391874848478223F, -1.2926523619321404F));
        g.addOrReplaceChild("nariz_325", CubeListBuilder.create().texOffs(688, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-93.54314506608121F, -21.159881674601433F, 5.856558739002745F, 2.254588093646751F, 0.14580896366073862F, -1.284645208486227F));
        g.addOrReplaceChild("nariz_326", CubeListBuilder.create().texOffs(704, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.55649078805625F, -23.10811507619149F, 5.875420930301446F, 2.3067986248184416F, 0.14651200255776695F, -1.2751964789348893F));
        g.addOrReplaceChild("nariz_327", CubeListBuilder.create().texOffs(720, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.58718264141747F, -25.05609006634824F, 5.896791605510256F, 2.3650153278079045F, 0.14555430145131365F, -1.2642864240787475F));
        g.addOrReplaceChild("nariz_328", CubeListBuilder.create().texOffs(736, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.63601908631547F, -27.003699222294085F, 5.920783442312321F, 2.4297987936678798F, 0.14236059202658569F, -1.2520166022126251F));
        g.addOrReplaceChild("nariz_329", CubeListBuilder.create().texOffs(752, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.70401914809729F, -28.95080310459764F, 5.947277197678332F, 2.508423148551742F, -0.012847439193566675F, -1.1284382079530617F));
        g.addOrReplaceChild("nariz_330", CubeListBuilder.create().texOffs(768, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.79325845671512F, -30.897120991553113F, 5.973921941937711F, 2.5856155628966606F, -0.011947658245837194F, -1.137832350141817F));
        g.addOrReplaceChild("nariz_331", CubeListBuilder.create().texOffs(784, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.9076655535865F, -32.842121592517586F, 5.977935419815298F, 2.6704021853089888F, 0.00825324417167631F, -1.1492604862936666F));
        g.addOrReplaceChild("nariz_332", CubeListBuilder.create().texOffs(798, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.04728860843534F, -34.78576381924809F, 5.904727761238572F, 2.7591222257773262F, 0.060680748568217015F, -1.1588851613931357F));
        g.addOrReplaceChild("nariz_333", CubeListBuilder.create().texOffs(812, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.20728333083318F, -36.72864766515129F, 5.675649264389994F, 2.8461849390238085F, 0.1546168212718774F, -1.1665622824641537F));
        g.addOrReplaceChild("nariz_334", CubeListBuilder.create().texOffs(826, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.3833639040349F, -38.67132156255968F, 5.1566350407898405F, 2.928052684207617F, 0.32440973513399335F, -1.1727949604283627F));
        g.addOrReplaceChild("nariz_335", CubeListBuilder.create().texOffs(868, 350).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.57257439881613F, -40.614176293012726F, 3.827551100796068F, 2.98941738679499F, 0.7475058538847906F, -1.1781100812481224F));
        g.addOrReplaceChild("nariz_336", CubeListBuilder.create().texOffs(790, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-95.09843153092052F, -15.494641705402305F, 6.62252743163007F, 2.1231314453887706F, 0.12555298256312472F, -1.3359474220391545F));
        g.addOrReplaceChild("nariz_337", CubeListBuilder.create().texOffs(808, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-94.18396151659857F, -17.430171823559803F, 6.635630649560556F, 2.160800367938958F, 0.1285319277612254F, -1.3310102384144056F));
        g.addOrReplaceChild("nariz_338", CubeListBuilder.create().texOffs(826, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.28370017417802F, -19.365610313114257F, 6.650494949829081F, 2.202735268431758F, 0.13102375210934267F, -1.3249465202800728F));
        g.addOrReplaceChild("nariz_339", CubeListBuilder.create().texOffs(784, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-92.39793822365253F, -21.300918789740564F, 6.667393438709276F, 2.249500050681164F, 0.13276431551417792F, -1.3176372316608318F));
        g.addOrReplaceChild("nariz_340", CubeListBuilder.create().texOffs(800, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.52710487298481F, -23.236040152431357F, 6.686591217030592F, 2.3016959105445545F, 0.13341689278271157F, -1.3090077126876856F));
        g.addOrReplaceChild("nariz_341", CubeListBuilder.create().texOffs(816, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.67181219237166F, -25.170892147690857F, 6.7082964850539435F, 2.359938213074311F, 0.13254665927879153F, -1.299039605576078F));
        g.addOrReplaceChild("nariz_342", CubeListBuilder.create().texOffs(832, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.83286416183523F, -27.105365053027704F, 6.732603271179197F, 2.4248086688391925F, 0.12962678379616355F, -1.2878272862453797F));
        g.addOrReplaceChild("nariz_343", CubeListBuilder.create().texOffs(848, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.01126019064695F, -29.039319947944477F, 6.75938936739751F, 2.4967844510657757F, 0.12406027346672434F, -1.2756365976793518F));
        g.addOrReplaceChild("nariz_344", CubeListBuilder.create().texOffs(864, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.2091088136076F, -30.972467990962112F, 6.785981821557149F, 2.580275964958224F, -0.012077082497083542F, -1.1820259642917301F));
        g.addOrReplaceChild("nariz_345", CubeListBuilder.create().texOffs(840, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-87.43029182932435F, -32.90427693718088F, 6.786497395746429F, 2.6658545107348726F, 0.011645483448119194F, -1.193151223837126F));
        g.addOrReplaceChild("nariz_346", CubeListBuilder.create().texOffs(854, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.67472128242116F, -34.83472340341001F, 6.699480441484861F, 2.755137525096373F, 0.07230365375940734F, -1.2023246605032438F));
        g.addOrReplaceChild("nariz_347", CubeListBuilder.create().texOffs(868, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.93754843769428F, -36.76441669572368F, 6.436501605948253F, 2.842062177736974F, 0.1803633583716902F, -1.2094644270053865F));
        g.addOrReplaceChild("nariz_348", CubeListBuilder.create().texOffs(882, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.21455131407313F, -38.69390450992843F, 5.845943199570318F, 2.9222586187605675F, 0.3728027306874024F, -1.2151024809142343F));
        g.addOrReplaceChild("nariz_349", CubeListBuilder.create().texOffs(414, 350).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.50282109239589F, -40.62357657238509F, 4.338341878105526F, 2.9764521493894325F, 0.8217328411837117F, -1.2197845159673373F));
        g.addOrReplaceChild("nariz_350", CubeListBuilder.create().texOffs(844, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.59989993889954F, -15.676975212305052F, 7.441445486718912F, 2.118942467910198F, 0.11298748009623927F, -1.3687665017134607F));
        g.addOrReplaceChild("nariz_351", CubeListBuilder.create().texOffs(862, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-92.80690461453774F, -17.599180202435743F, 7.454407731799135F, 2.1565645913195737F, 0.11571170253465018F, -1.3643107791022446F));
        g.addOrReplaceChild("nariz_352", CubeListBuilder.create().texOffs(880, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-92.02626946938189F, -19.521292238276843F, 7.469100175693188F, 2.198460125835031F, 0.11798914097997829F, -1.358821146174571F));
        g.addOrReplaceChild("nariz_353", CubeListBuilder.create().texOffs(880, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-91.25827890405725F, -21.443273185625504F, 7.485787998988079F, 2.245196192508768F, 0.11958577016959214F, -1.3522000383816326F));
        g.addOrReplaceChild("nariz_354", CubeListBuilder.create().texOffs(896, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.50337095658918F, -23.365064052351364F, 7.5047122852275505F, 2.29738346971253F, 0.12019670564552827F, -1.3443804858037083F));
        g.addOrReplaceChild("nariz_355", CubeListBuilder.create().texOffs(912, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.7621497570836F, -25.286582500123124F, 7.52605915872227F, 2.3556506903825367F, 0.11942655522282775F, -1.3353448584458318F));
        g.addOrReplaceChild("nariz_356", CubeListBuilder.create().texOffs(928, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.03538444189053F, -27.207721899575088F, 7.549915090258548F, 2.4205986680431995F, 0.11679364893292962F, -1.3251763804992156F));
        g.addOrReplaceChild("nariz_357", CubeListBuilder.create().texOffs(944, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.32403443827334F, -29.128346857663782F, 7.576147852772323F, 2.4927237648730913F, 0.11176841269119085F, -1.3141274324376366F));
        g.addOrReplaceChild("nariz_358", CubeListBuilder.create().texOffs(960, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.63018351917026F, -31.048168269530557F, 7.601751592893619F, 2.575703747722248F, -0.01170764991089374F, -1.2283008193972078F));
        g.addOrReplaceChild("nariz_359", CubeListBuilder.create().texOffs(896, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.95752907185883F, -32.96667193147606F, 7.597761488187638F, 2.6619250978019724F, 0.015694507518750598F, -1.2388722789979267F));
        g.addOrReplaceChild("nariz_360", CubeListBuilder.create().texOffs(910, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.30585321804114F, -34.88385297753342F, 7.495969038800288F, 2.751502411865246F, 0.0847589908295135F, -1.2474129970894123F));
        g.addOrReplaceChild("nariz_361", CubeListBuilder.create().texOffs(924, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.6704649630035F, -36.800309582598324F, 7.198304344911222F, 2.837904969944976F, 0.20703239843706142F, -1.2539101359978286F));
        g.addOrReplaceChild("nariz_362", CubeListBuilder.create().texOffs(938, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.04733740481505F, -38.71657143672849F, 6.535654582546493F, 2.9158672007300557F, 0.42106773829663063F, -1.258899466689423F));
        g.addOrReplaceChild("nariz_363", CubeListBuilder.create().texOffs(432, 350).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.43369675577277F, -40.63301525130214F, 4.849233743177927F, 2.9621440143622477F, 0.8876562016536498F, -1.2629311393506302F));
        g.addOrReplaceChild("nariz_364", CubeListBuilder.create().texOffs(898, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-92.10670530446166F, -15.861362799634335F, 8.269581769704008F, 2.1156149274725866F, 0.10031588716233387F, -1.4032263795107018F));
        g.addOrReplaceChild("nariz_365", CubeListBuilder.create().texOffs(916, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-91.43532153108023F, -17.7700047866495F, 8.281974684845924F, 2.1532094846580194F, 0.10278640176558465F, -1.3992285686351729F));
        g.addOrReplaceChild("nariz_366", CubeListBuilder.create().texOffs(934, 319).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.77445225717113F, -19.67855397250942F, 8.296000983766827F, 2.1950801978833154F, 0.10485732935345053F, -1.3942975872501413F));
        g.addOrReplaceChild("nariz_367", CubeListBuilder.create().texOffs(976, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-90.12437743764116F, -21.58697228565084F, 8.311898723691929F, 2.24179949009475F, 0.10632271339099544F, -1.3883507572404825F));
        g.addOrReplaceChild("nariz_368", CubeListBuilder.create().texOffs(992, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-89.48549557100473F, -23.495205129459027F, 8.329899920678209F, 2.2939874071603605F, 0.10689697259764729F, -1.3813137230714034F));
        g.addOrReplaceChild("nariz_369", CubeListBuilder.create().texOffs(1008, 333).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.85836251719257F, -25.40317548710563F, 8.350180989233642F, 2.3522786204863246F, 0.10623943890243973F, -1.3731890949788925F));
        g.addOrReplaceChild("nariz_370", CubeListBuilder.create().texOffs(0, 337).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.243719421355F, -27.31077927891505F, 8.372793337268543F, 2.4172862559494925F, 0.10392080929594906F, -1.3640509200918802F));
        g.addOrReplaceChild("nariz_371", CubeListBuilder.create().texOffs(464, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.64247092903761F, -29.21788704614467F, 8.397580439289895F, 2.4895305252520274F, 0.09946970407893442F, -1.3541231788846133F));
        g.addOrReplaceChild("nariz_372", CubeListBuilder.create().texOffs(478, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.05657384648617F, -31.124223540913967F, 8.421239852491968F, 2.56920711048233F, 0.09405464988406713F, -1.3439397055439057F));
        g.addOrReplaceChild("nariz_373", CubeListBuilder.create().texOffs(234, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.48942030875641F, -33.02931012781212F, 8.411742331511084F, 2.658694731319982F, 0.0204169673487336F, -1.2863307107340691F));
        g.addOrReplaceChild("nariz_374", CubeListBuilder.create().texOffs(246, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.9407050175299F, -34.93315636575867F, 8.294207674946513F, 2.7482611029547894F, 0.09801193625330036F, -1.2940539569916059F));
        g.addOrReplaceChild("nariz_375", CubeListBuilder.create().texOffs(952, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.40604441836676F, -36.8363296117639F, 7.961074290587569F, 2.833730939919828F, 0.23444240987635995F, -1.299800073224087F));
        g.addOrReplaceChild("nariz_376", CubeListBuilder.create().texOffs(966, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.88172899927774F, -38.73932473078706F, 7.2257861474178675F, 2.908890320628303F, 0.46869790054104765F, -1.3040937559610437F));
        g.addOrReplaceChild("nariz_377", CubeListBuilder.create().texOffs(450, 350).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.36520549675562F, -40.64249329105614F, 5.360231609232784F, 2.94664789117304F, 0.9457946042817444F, -1.3074641846951902F));
        g.addOrReplaceChild("nariz_378", CubeListBuilder.create().texOffs(176, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.61906715723191F, -16.0478651163167F, 9.107207868332292F, 2.1132750805001335F, 0.08757321932873091F, -1.4393289291021725F));
        g.addOrReplaceChild("nariz_379", CubeListBuilder.create().texOffs(192, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-90.06945409950494F, -17.94269234721782F, 9.118557159693179F, 2.150862076353438F, 0.08979601739568845F, -1.4357621640537075F));
        g.addOrReplaceChild("nariz_380", CubeListBuilder.create().texOffs(208, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-89.52850737032455F, -19.837429277129594F, 9.13137381412431F, 2.1927258775792033F, 0.09167432962961682F, -1.4313703780094187F));
        g.addOrReplaceChild("nariz_381", CubeListBuilder.create().texOffs(492, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.99645885244702F, -21.732043674458307F, 9.145884567171997F, 2.2394445029482783F, 0.093009520597995F, -1.4260576976650807F));
        g.addOrReplaceChild("nariz_382", CubeListBuilder.create().texOffs(506, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-88.47365326837827F, -23.62648737061656F, 9.162305420399681F, 2.2916349889642826F, 0.09356803930690653F, -1.4197849043206128F));
        g.addOrReplaceChild("nariz_383", CubeListBuilder.create().texOffs(520, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.96061873121593F, -25.52068633766204F, 9.180767915906166F, 2.349943526844384F, 0.09304807222752573F, -1.4125483015129325F));
        g.addOrReplaceChild("nariz_384", CubeListBuilder.create().texOffs(534, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.45803843950497F, -27.414543385378284F, 9.201285624339352F, 2.4149945552604213F, 0.09107606682162271F, -1.404413452009992F));
        g.addOrReplaceChild("nariz_385", CubeListBuilder.create().texOffs(548, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.96669767204264F, -29.307944188896474F, 9.223722026976585F, 2.48732392363003F, 0.0872132289511359F, -1.3955565766832212F));
        g.addOrReplaceChild("nariz_386", CubeListBuilder.create().texOffs(562, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.4883583184226F, -31.200637388988245F, 9.244471825296984F, 2.5671152353627775F, 0.08299528057657146F, -1.3863705661562187F));
        g.addOrReplaceChild("nariz_387", CubeListBuilder.create().texOffs(258, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-86.02602219167326F, -33.09219338769486F, 9.228429182846636F, 2.656236099531136F, 0.02583319973917809F, -1.3354006134510872F));
        g.addOrReplaceChild("nariz_388", CubeListBuilder.create().texOffs(270, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.57931386305161F, -34.98263529203196F, 9.094174881130616F, 2.7454597150056914F, 0.11200592113650076F, -1.3421148436802042F));
        g.addOrReplaceChild("nariz_389", CubeListBuilder.create().texOffs(980, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.14431034065672F, -36.8724785601912F, 8.72479407133196F, 2.829563579314208F, 0.2623824416517253F, -1.3470029345923644F));
        g.addOrReplaceChild("nariz_390", CubeListBuilder.create().texOffs(994, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.71773954339753F, -38.762165973559064F, 7.916330659786418F, 2.901370439338881F, 0.5151943578450909F, -1.3505610606551266F));
    }

    private static void piezas6(PartDefinition g) {
        g.addOrReplaceChild("nariz_391", CubeListBuilder.create().texOffs(300, 350).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.29735252476627F, -40.65201155176362F, 5.871337943691371F, 2.930148381159045F, 0.996822433921724F, -1.353269424287645F));
        g.addOrReplaceChild("nariz_392", CubeListBuilder.create().texOffs(224, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-89.13729113901886F, -16.23653618278565F, 9.954565457869556F, 2.112055426749101F, 0.07479696135065456F, -1.4770436294609517F));
        g.addOrReplaceChild("nariz_393", CubeListBuilder.create().texOffs(240, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-88.70960166634808F, -18.11728585831913F, 9.964363043794613F, 2.1496574234817114F, 0.07677334953479749F, -1.47386373518965F));
        g.addOrReplaceChild("nariz_394", CubeListBuilder.create().texOffs(256, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-88.28866070710734F, -19.99795904349623F, 9.975434346927251F, 2.1915321142025417F, 0.07846575013829174F, -1.4699747882254308F));
        g.addOrReplaceChild("nariz_395", CubeListBuilder.create().texOffs(576, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.87469764276F, -21.87852365628551F, 9.987953140479528F, 2.2382562095198963F, 0.07969624547158252F, -1.4652801339362007F));
        g.addOrReplaceChild("nariz_396", CubeListBuilder.create().texOffs(590, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.46803236636514F, -23.758934524329483F, 10.002077559674557F, 2.2904535690206944F, 0.08027287633408972F, -1.4597530841537183F));
        g.addOrReplaceChild("nariz_397", CubeListBuilder.create().texOffs(604, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-87.06912399224447F, -25.639126382371046F, 10.017897992110385F, 2.3487724123807965F, 0.07992254721536997F, -1.4533709971365516F));
        g.addOrReplaceChild("nariz_398", CubeListBuilder.create().texOffs(618, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.6785063246829F, -27.51902162423433F, 10.035452233965477F, 2.4138452924302776F, 0.07830764540288854F, -1.446178032320687F));
        g.addOrReplaceChild("nariz_399", CubeListBuilder.create().texOffs(632, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.29682335286637F, -29.398524849940497F, 10.054631404219876F, 2.486206998221323F, 0.07506965306574151F, -1.4383479596823239F));
        g.addOrReplaceChild("nariz_400", CubeListBuilder.create().texOffs(646, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.92562741503373F, -31.27741196584212F, 10.071455764025613F, 2.566035611110162F, 0.07212520117772729F, -1.4300556752052318F));
        g.addOrReplaceChild("nariz_401", CubeListBuilder.create().texOffs(282, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.5674044870145F, -33.15532193521174F, 10.047787798165452F, 2.654618762425241F, 0.031953825505437426F, -1.385915849339596F));
        g.addOrReplaceChild("nariz_402", CubeListBuilder.create().texOffs(294, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.22172581793728F, -35.03229040872009F, 9.895830570266163F, 2.743141662995963F, 0.12665925195926708F, -1.3914251159221764F));
        g.addOrReplaceChild("nariz_403", CubeListBuilder.create().texOffs(306, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.88529262731089F, -36.90875745958664F, 9.48942770410474F, 2.825438102768115F, 0.2906225693583328F, -1.3953574953627237F));
        g.addOrReplaceChild("nariz_404", CubeListBuilder.create().texOffs(1008, 353).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.55538783724255F, -38.78509610965295F, 8.60726008311961F, 2.893373658425053F, 0.5600990986649238F, -1.3981462769190125F));
        g.addOrReplaceChild("nariz_405", CubeListBuilder.create().texOffs(320, 350).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.23014495781449F, -40.66157067907554F, 6.382542954126661F, 2.9128374780767627F, 1.0414703904756286F, -1.4002036287558672F));
        g.addOrReplaceChild("nariz_406", CubeListBuilder.create().texOffs(272, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.66161373945596F, -16.427443545100896F, 10.811958578868676F, 2.112091192411189F, 0.06199904529876704F, -1.5162638682181129F));
        g.addOrReplaceChild("nariz_407", CubeListBuilder.create().texOffs(288, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.35593869795284F, -18.293848125572964F, 10.819695864509788F, 2.149724093005857F, 0.06375389331569417F, -1.5134592446546797F));
        g.addOrReplaceChild("nariz_408", CubeListBuilder.create().texOffs(304, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-87.05511098554544F, -20.16019057518377F, 10.828429712024768F, 2.1916238743156033F, 0.06528263909414941F, -1.5100477738883051F));
        g.addOrReplaceChild("nariz_409", CubeListBuilder.create().texOffs(660, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.75934193516635F, -22.02644120398319F, 10.838268903293983F, 2.2383649000642243F, 0.06644591217469266F, -1.50595469996901F));
        g.addOrReplaceChild("nariz_410", CubeListBuilder.create().texOffs(674, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.4688844503236F, -23.89256370073027F, 10.849324244158087F, 2.2905693929450623F, 0.06706461392253862F, -1.5011283771333646F));
        g.addOrReplaceChild("nariz_411", CubeListBuilder.create().texOffs(688, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-86.18406851253317F, -25.758510052255488F, 10.861673562205095F, 2.3488848009511973F, 0.06691346094556909F, -1.4955537183205627F));
        g.addOrReplaceChild("nariz_412", CubeListBuilder.create().texOffs(702, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.90526824353067F, -27.624224604903134F, 10.87537625483629F, 2.4139435651060763F, 0.06568738793293656F, -1.489248521399096F));
        g.addOrReplaceChild("nariz_413", CubeListBuilder.create().texOffs(716, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.63298903151237F, -29.48963155818572F, 10.890328974798162F, 2.486285319154784F, 0.06312260159945887F, -1.4823919673308352F));
        g.addOrReplaceChild("nariz_414", CubeListBuilder.create().texOffs(730, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.36848259755979F, -31.354548125206936F, 10.90218881470432F, 2.5660538228315253F, 0.061503842681942485F, -1.4748490155278042F));
        g.addOrReplaceChild("nariz_415", CubeListBuilder.create().texOffs(318, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-85.11360655009412F, -33.21870031073952F, 10.869839942651645F, 2.6525342207346645F, 0.0814522870598439F, -1.4603860961558375F));
        g.addOrReplaceChild("nariz_416", CubeListBuilder.create().texOffs(330, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.86795413435111F, -35.082127065321764F, 10.699208121441153F, 2.741348889652349F, 0.14187636984740837F, -1.4417870641331834F));
        g.addOrReplaceChild("nariz_417", CubeListBuilder.create().texOffs(342, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.62899779636192F, -36.94517075302463F, 10.25500962943578F, 2.8213989061566536F, 0.31891622788783464F, -1.4446767229546496F));
        g.addOrReplaceChild("nariz_418", CubeListBuilder.create().texOffs(0, 356).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.39467981965221F, -38.80811799783993F, 9.29859865865377F, 2.8849931113003286F, 0.6030340598666175F, -1.4466740547484656F));
        g.addOrReplaceChild("nariz_419", CubeListBuilder.create().texOffs(340, 350).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.16358723191328F, -40.671171751466375F, 6.893850972161796F, 2.8949254165693135F, 1.0804673804415232F, -1.4480999826834635F));
        g.addOrReplaceChild("nariz_420", CubeListBuilder.create().texOffs(320, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.19227570558459F, -16.620659078221934F, 11.679708634633796F, 2.113505406402088F, 0.0492172933552419F, -1.5568874056838087F));
        g.addOrReplaceChild("nariz_421", CubeListBuilder.create().texOffs(336, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-86.00875906161575F, -18.47243045849096F, 11.684802799310829F, 2.1511890995318597F, 0.05078101103295376F, -1.5544442756710566F));
        g.addOrReplaceChild("nariz_422", CubeListBuilder.create().texOffs(352, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-85.82818782924721F, -20.32415724089524F, 11.69053375552128F, 2.193127354229284F, 0.05217697779845213F, -1.5514847271507168F));
        g.addOrReplaceChild("nariz_423", CubeListBuilder.create().texOffs(744, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.65068865455933F, -22.175821172699482F, 11.696975084078092F, 2.2398906544061856F, 0.05329411657178747F, -1.547945313941522F));
        g.addOrReplaceChild("nariz_424", CubeListBuilder.create().texOffs(758, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.47642193646966F, -24.02739879755774F, 11.704197067984817F, 2.292096604510886F, 0.05398843890874343F, -1.5437792634920255F));
        g.addOrReplaceChild("nariz_425", CubeListBuilder.create().texOffs(772, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.30560090672799F, -25.878858600661268F, 11.712244703917458F, 2.3503879098793274F, 0.05407471421401896F, -1.5389651737036885F));
        g.addOrReplaceChild("nariz_426", CubeListBuilder.create().texOffs(786, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-85.1384707700386F, -27.73016356479328F, 11.721143422405566F, 2.4153888075897036F, 0.053307938394078436F, -1.5335138150564018F));
        g.addOrReplaceChild("nariz_427", CubeListBuilder.create().texOffs(800, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.97535597249528F, -29.581264294065072F, 11.73081260623294F, 2.4876420644526758F, 0.051452579030638323F, -1.527548473920759F));
        g.addOrReplaceChild("nariz_428", CubeListBuilder.create().texOffs(814, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.81704010004638F, -31.43204467215942F, 11.736643795688416F, 2.567238400158009F, 0.05119775567718083F, -1.5205788393874502F));
        g.addOrReplaceChild("nariz_429", CubeListBuilder.create().texOffs(354, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.66469050521697F, -33.282330050496014F, 11.694565609218875F, 2.653197413884039F, 0.07491909729508399F, -1.505657618798935F));
        g.addOrReplaceChild("nariz_430", CubeListBuilder.create().texOffs(366, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.51803216992306F, -35.13214801052018F, 11.504296936194377F, 2.740120146190266F, 0.15754376741968878F, -1.49297002231887F));
        g.addOrReplaceChild("nariz_431", CubeListBuilder.create().texOffs(378, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.37544718670313F, -36.981720978053914F, 11.021531624190867F, 2.817501477767482F, 0.34701166895051944F, -1.4947456505687897F));
        g.addOrReplaceChild("nariz_432", CubeListBuilder.create().texOffs(14, 356).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.23563072432408F, -38.831233299934645F, 9.99033316785145F, 2.8763477819289505F, 0.6436932245572431F, -1.4959412925006221F));
        g.addOrReplaceChild("nariz_433", CubeListBuilder.create().texOffs(196, 350).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.09768704033813F, -40.680815430841015F, 7.405244062920869F, 2.8766373427068412F, 1.1144944566335768F, -1.4967650034256363F));
        g.addOrReplaceChild("nariz_434", CubeListBuilder.create().texOffs(368, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.72962050988033F, -16.81624677635772F, 12.558101471741422F, 2.1164179657962503F, 0.03648997037264387F, -1.5987713010183724F));
        g.addOrReplaceChild("nariz_435", CubeListBuilder.create().texOffs(384, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.66842617817873F, -18.65307927356094F, 12.559907987588167F, 2.154166543133027F, 0.03788696078184055F, -1.5966571472624143F));
        g.addOrReplaceChild("nariz_436", CubeListBuilder.create().texOffs(400, 324).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.60821345007818F, -20.48989630965647F, 12.561942018113445F, 2.1961518656789254F, 0.03918359701208891F, -1.5941212662776065F));
        g.addOrReplaceChild("nariz_437", CubeListBuilder.create().texOffs(828, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.54903347104602F, -22.326690512943237F, 12.564225125229697F, 2.24293710673903F, 0.04029490134603149F, -1.5911040682723738F));
        g.addOrReplaceChild("nariz_438", CubeListBuilder.create().texOffs(842, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.49094284098557F, -24.163453513462567F, 12.566781020436022F, 2.2951317981266652F, 0.04110916208520782F, -1.5875577002834953F));
        g.addOrReplaceChild("nariz_439", CubeListBuilder.create().texOffs(856, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.43401642541413F, -26.000174123778887F, 12.569624177222321F, 2.353369548243442F, 0.041479248533988995F, -1.5834515275897452F));
        g.addOrReplaceChild("nariz_440", CubeListBuilder.create().texOffs(870, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.3783491664017F, -27.836837968395713F, 12.572750764761876F, 2.4182667682121672F, 0.04121959895702474F, -1.5787885403467827F));
        g.addOrReplaceChild("nariz_441", CubeListBuilder.create().texOffs(884, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.32405437276859F, -29.673427593500794F, 12.57612588259223F, 2.4903552188776574F, 0.04010988501846125F, -1.5736278373357229F));
        g.addOrReplaceChild("nariz_442", CubeListBuilder.create().texOffs(898, 337).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-84.27138134484046F, -31.509905472993776F, 12.574842610176837F, 2.5696350105192627F, 0.041298043006519014F, -1.56706698298758F));
        g.addOrReplaceChild("nariz_443", CubeListBuilder.create().texOffs(390, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.22073247511393F, -33.346210827756465F, 12.521915319917893F, 2.654838217398633F, 0.0687559456889557F, -1.551500219530537F));
        g.addOrReplaceChild("nariz_444", CubeListBuilder.create().texOffs(402, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.17202073620692F, -35.18235219539F, 12.311022423745097F, 2.7394891823639855F, 0.17354165615963404F, -1.5447175401867035F));
        g.addOrReplaceChild("nariz_445", CubeListBuilder.create().texOffs(414, 356).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.12468164541204F, -37.01840799172673F, 11.788928771229697F, 2.813813173408031F, 0.3746502747530665F, -1.5453204779862808F));
        g.addOrReplaceChild("nariz_446", CubeListBuilder.create().texOffs(28, 356).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.07826219257912F, -38.85444286107169F, 10.682428290910018F, 2.867582813045138F, 0.6818398506634649F, -1.5457180540628048F));
        g.addOrReplaceChild("nariz_447", CubeListBuilder.create().texOffs(218, 350).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-84.03245143781638F, -40.69050253309297F, 7.916719917278383F, 2.858216077384066F, 1.1441685587356376F, -1.5459837873159752F));
        g.addOrReplaceChild("faro_0", CubeListBuilder.create().texOffs(736, 324).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(516, 97).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.17056986523859F, -36.31689205046923F, 0.0F, 0.0F, 0.0F, 2.2444850808544285F));
        g.addOrReplaceChild("faro_1", CubeListBuilder.create().texOffs(760, 324).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(540, 97).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.17056986523859F, -36.31689205046923F, 0.0F, 0.0F, 0.39269908169872414F, 2.2444850808544285F));
        g.addOrReplaceChild("faro_2", CubeListBuilder.create().texOffs(784, 324).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(564, 97).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.17056986523859F, -36.31689205046923F, 0.0F, 0.0F, 0.7853981633974482F, 2.2444850808544285F));
        g.addOrReplaceChild("faro_3", CubeListBuilder.create().texOffs(808, 324).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(588, 97).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-88.17056986523859F, -36.31689205046923F, 0.0F, 0.0F, 1.1780972450961724F, 2.2444850808544285F));
        g.addOrReplaceChild("faro_vidrio", CubeListBuilder.create().texOffs(448, 62).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-88.96772605252177F, -36.95324259307616F, 0.0F, 0.0F, 0.0F, 2.2444850808544285F));
        g.addOrReplaceChild("visera", CubeListBuilder.create().texOffs(486, 132).addBox(-90.826875F, -40.0F, -3.0F, 5.0F, 1.0F, 6.0F).texOffs(140, 319).addBox(-76.0F, -42.5F, -2.0F, 6.0F, 1.0F, 4.0F).texOffs(624, 132).addBox(-114.0F, -9.0F, -1.5F, 6.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("piloto_0", CubeListBuilder.create().texOffs(568, 132).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-93.39920654669541F, -3.625F, -10.681201164955219F, -1.826523908398375F, 0.0F, -1.5361549198186468F));
        g.addOrReplaceChild("piloto_1", CubeListBuilder.create().texOffs(584, 314).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.25192164704326F, -7.875F, -10.681201164955219F, -1.8550920135403686F, 0.0F, -1.5361549198186468F));
        g.addOrReplaceChild("piloto_2", CubeListBuilder.create().texOffs(482, 121).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-95.86275566905577F, -3.625F, -9.882242496094985F, -1.925349151417814F, -0.015539988596836142F, -1.5173660146817924F));
        g.addOrReplaceChild("piloto_3", CubeListBuilder.create().texOffs(426, 132).addBox(-4.5F, -1.0F, -3.0F, 9.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-95.45614980915516F, -7.875F, -9.882242496094985F, -1.9631092007939888F, -0.016862628720502107F, -1.5161446955249924F));
        g.addOrReplaceChild("piloto_4", CubeListBuilder.create().texOffs(346, 121).addBox(-4.5F, -1.0F, -4.0F, 9.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-98.93451241409372F, -3.625F, -8.600920873330772F, -2.0062316751096834F, -0.03261750461421384F, -1.4706889303691382F));
        g.addOrReplaceChild("piloto_5", CubeListBuilder.create().texOffs(514, 121).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-98.20456373892597F, -7.875F, -8.600920873330772F, -2.050325556202613F, -0.03491440520937822F, -1.4677305224303627F));
        g.addOrReplaceChild("piloto_6", CubeListBuilder.create().texOffs(380, 121).addBox(-4.5F, -1.0F, -4.0F, 9.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-102.18904307265288F, -3.625F, -6.956375116909255F, -2.084924977535961F, -0.05326902306532466F, -1.4175913725135985F));
        g.addOrReplaceChild("piloto_7", CubeListBuilder.create().texOffs(546, 121).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-101.11651222289993F, -7.875F, -6.956375116909255F, -2.1340157146645047F, -0.05618302299255516F, -1.4122929574611836F));
        g.addOrReplaceChild("piloto_8", CubeListBuilder.create().texOffs(578, 121).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-105.27192471088196F, -3.625F, -5.106469208384355F, -2.1703253549864234F, -0.07486240128941915F, -1.3622074522854999F));
        g.addOrReplaceChild("piloto_9", CubeListBuilder.create().texOffs(610, 121).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-103.87488000447333F, -7.875F, -5.106469208384355F, -2.2234046371086715F, -0.07760666335572883F, -1.3542948882851011F));
        g.addOrReplaceChild("piloto_10", CubeListBuilder.create().texOffs(298, 132).addBox(-5.0F, -1.0F, -3.0F, 10.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-107.87803391277698F, -3.625F, -3.240154394415037F, -2.2717145859567536F, -0.0941396737169071F, -1.3070467452652772F));
        g.addOrReplaceChild("piloto_11", CubeListBuilder.create().texOffs(330, 132).addBox(-5.0F, -1.0F, -3.0F, 10.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-106.20666192195836F, -7.875F, -3.240154394415037F, -2.3274180031752225F, -0.09551137535000927F, -1.2967878273173508F));
        g.addOrReplaceChild("piloto_12", CubeListBuilder.create().texOffs(508, 132).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-109.76115777475515F, -3.625F, -1.5758041207123F, -2.412593512837893F, 0.0F, -1.1563691831181557F));
        g.addOrReplaceChild("piloto_13", CubeListBuilder.create().texOffs(528, 314).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-107.89156221951777F, -7.875F, -1.5758041207123F, -2.467398028732733F, 0.0F, -1.1563691831181557F));
        g.addOrReplaceChild("piloto_14", CubeListBuilder.create().texOffs(56, 350).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-110.74765823480394F, -3.625F, -0.4116858004042236F, -2.634202196896555F, 0.0F, -1.1360828648630192F));
        g.addOrReplaceChild("piloto_15", CubeListBuilder.create().texOffs(80, 350).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-108.77422052587721F, -7.875F, -0.4116858004042236F, -2.6800128389740325F, 0.0F, -1.1360828648630192F));
        g.addOrReplaceChild("piloto_16", CubeListBuilder.create().texOffs(104, 350).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-110.74765823480394F, -3.625F, 0.4116858004042236F, 2.634202196896555F, 0.0F, -1.1360828648630192F));
        g.addOrReplaceChild("piloto_17", CubeListBuilder.create().texOffs(128, 350).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-108.77422052587721F, -7.875F, 0.4116858004042236F, 2.6800128389740325F, 0.0F, -1.1360828648630192F));
        g.addOrReplaceChild("piloto_18", CubeListBuilder.create().texOffs(538, 132).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-109.76115777475515F, -3.625F, 1.5758041207123F, 2.412593512837893F, 0.0F, -1.1563691831181557F));
        g.addOrReplaceChild("piloto_19", CubeListBuilder.create().texOffs(556, 314).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-107.89156221951777F, -7.875F, 1.5758041207123F, 2.467398028732733F, 0.0F, -1.1563691831181557F));
        g.addOrReplaceChild("piloto_20", CubeListBuilder.create().texOffs(362, 132).addBox(-5.0F, -1.0F, -3.0F, 10.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-107.87803391277698F, -3.625F, 3.240154394415037F, 2.2717145859567536F, 0.0941396737169071F, -1.3070467452652772F));
        g.addOrReplaceChild("piloto_21", CubeListBuilder.create().texOffs(394, 132).addBox(-5.0F, -1.0F, -3.0F, 10.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-106.20666192195836F, -7.875F, 3.240154394415037F, 2.3274180031752225F, 0.09551137535000927F, -1.2967878273173508F));
        g.addOrReplaceChild("piloto_22", CubeListBuilder.create().texOffs(642, 121).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-105.27192471088196F, -3.625F, 5.106469208384355F, 2.1703253549864234F, 0.07486240128941915F, -1.3622074522854999F));
        g.addOrReplaceChild("piloto_23", CubeListBuilder.create().texOffs(674, 121).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-103.87488000447331F, -7.875F, 5.106469208384355F, 2.2234046371086715F, 0.07760666335572883F, -1.3542948882851011F));
        g.addOrReplaceChild("piloto_24", CubeListBuilder.create().texOffs(414, 121).addBox(-4.5F, -1.0F, -4.0F, 9.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-102.18904307265288F, -3.625F, 6.956375116909254F, 2.084924977535961F, 0.05326902306532466F, -1.4175913725135985F));
        g.addOrReplaceChild("piloto_25", CubeListBuilder.create().texOffs(706, 121).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-101.11651222289993F, -7.875F, 6.956375116909254F, 2.1340157146645047F, 0.05618302299255516F, -1.4122929574611836F));
        g.addOrReplaceChild("piloto_26", CubeListBuilder.create().texOffs(448, 121).addBox(-4.5F, -1.0F, -4.0F, 9.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-98.93451241409372F, -3.625F, 8.600920873330772F, 2.0062316751096834F, 0.03261750461421384F, -1.4706889303691382F));
    }

    private static void piezas7(PartDefinition g) {
        g.addOrReplaceChild("piloto_27", CubeListBuilder.create().texOffs(738, 121).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-98.20456373892597F, -7.875F, 8.600920873330772F, 2.050325556202613F, 0.03491440520937822F, -1.4677305224303627F));
        g.addOrReplaceChild("piloto_28", CubeListBuilder.create().texOffs(770, 121).addBox(-4.5F, -1.0F, -3.5F, 9.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-95.86275566905577F, -3.625F, 9.882242496094985F, 1.925349151417814F, 0.015539988596836142F, -1.5173660146817924F));
        g.addOrReplaceChild("piloto_29", CubeListBuilder.create().texOffs(456, 132).addBox(-4.5F, -1.0F, -3.0F, 9.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-95.45614980915516F, -7.875F, 9.882242496094985F, 1.9631092007939888F, 0.016862628720502107F, -1.5161446955249924F));
        g.addOrReplaceChild("piloto_30", CubeListBuilder.create().texOffs(596, 132).addBox(-4.5F, -1.0F, -2.5F, 9.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-93.39920654669541F, -3.625F, 10.681201164955219F, 1.826523908398375F, 0.0F, -1.5361549198186468F));
        g.addOrReplaceChild("piloto_31", CubeListBuilder.create().texOffs(610, 314).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-93.25192164704326F, -7.875F, 10.681201164955219F, 1.8550920135403686F, 0.0F, -1.5361549198186468F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(424, 0).addBox(46.0F, -38.0F, -13.0F, 26.0F, 22.0F, 26.0F).texOffs(880, 0).addBox(46.0F, -42.0F, -9.0F, 26.0F, 4.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_cantoi_0", CubeListBuilder.create().texOffs(512, 347).addBox(-13.0F, -1.0F, -1.0F, 26.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -38.61803398874989F, -12.902113032590307F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantoi_1", CubeListBuilder.create().texOffs(568, 347).addBox(-13.0F, -1.0F, -1.0F, 26.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -39.79360449333484F, -12.5201470213402F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantoi_2", CubeListBuilder.create().texOffs(624, 347).addBox(-13.0F, -1.0F, -1.0F, 26.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -40.79360449333484F, -11.79360449333484F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantoi_3", CubeListBuilder.create().texOffs(680, 347).addBox(-13.0F, -1.0F, -1.0F, 26.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -41.5201470213402F, -10.79360449333484F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantoi_4", CubeListBuilder.create().texOffs(736, 347).addBox(-13.0F, -1.0F, -1.0F, 26.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -41.90211303259031F, -9.618033988749895F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantod_0", CubeListBuilder.create().texOffs(792, 347).addBox(-13.0F, -1.0F, -1.0F, 26.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -38.61803398874989F, 12.902113032590307F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantod_1", CubeListBuilder.create().texOffs(848, 347).addBox(-13.0F, -1.0F, -1.0F, 26.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -39.79360449333484F, 12.5201470213402F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantod_2", CubeListBuilder.create().texOffs(904, 347).addBox(-13.0F, -1.0F, -1.0F, 26.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -40.79360449333484F, 11.79360449333484F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantod_3", CubeListBuilder.create().texOffs(960, 347).addBox(-13.0F, -1.0F, -1.0F, 26.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -41.5201470213402F, 10.79360449333484F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_cantod_4", CubeListBuilder.create().texOffs(0, 350).addBox(-13.0F, -1.0F, -1.0F, 26.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -41.90211303259031F, 9.618033988749895F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_tapaa", CubeListBuilder.create().texOffs(212, 0).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 52.0F), PartPose.offset(46.0F, -38.0F, -13.0F));
        g.addOrReplaceChild("cabina_tapab", CubeListBuilder.create().texOffs(318, 0).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 52.0F), PartPose.offset(71.0F, -38.0F, -13.0F));
    }

    private static void piezas8(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(616, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(92.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(92.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(92.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(626, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(104.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(104.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(104.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri2_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(636, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(116.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri2_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri2_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri3_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(646, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(164.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri3_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(164.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri3_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(164.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri4_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(656, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(176.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri4_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(176.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri4_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(176.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri5_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 324).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(188.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri5_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(188.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri5_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(188.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(676, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(92.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(92.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(92.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(686, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(104.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(104.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(104.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd2_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(116.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd2_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd2_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd3_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(706, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(164.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd3_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(164.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd3_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(164.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd4_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(716, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(176.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd4_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(176.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd4_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(176.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd5_0", CubeListBuilder.create().texOffs(276, 121).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(898, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(322, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 324).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(188.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd5_1", CubeListBuilder.create().texOffs(920, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(188.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd5_2", CubeListBuilder.create().texOffs(942, 324).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 121).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(188.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(530, 109).addBox(76.0F, -14.0F, 2.0F, 126.0F, 10.0F, 1.0F).texOffs(0, 121).addBox(76.0F, -14.0F, -3.0F, 126.0F, 10.0F, 1.0F).texOffs(802, 121).addBox(87.0F, -9.0F, 7.0F, 34.0F, 6.0F, 1.0F).texOffs(872, 121).addBox(87.0F, -9.0F, -8.0F, 34.0F, 6.0F, 1.0F).texOffs(942, 121).addBox(159.0F, -9.0F, 7.0F, 34.0F, 6.0F, 1.0F).texOffs(0, 132).addBox(159.0F, -9.0F, -8.0F, 34.0F, 6.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(528, 0).addBox(76.0F, -33.0F, -13.0F, 126.0F, 19.0F, 26.0F).texOffs(0, 62).addBox(76.0F, -38.0F, -8.0F, 126.0F, 5.0F, 16.0F).texOffs(512, 62).addBox(78.0F, -39.0F, -7.0F, 42.0F, 1.0F, 14.0F).texOffs(832, 0).addBox(202.0F, -14.0F, -11.0F, 2.0F, 8.0F, 22.0F).texOffs(642, 132).addBox(204.0F, -11.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender_caja_cantoi_0", CubeListBuilder.create().texOffs(0, 341).addBox(-63.0F, -1.0F, -1.0F, 126.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(139.0F, -33.772542485937365F, -12.877641290737884F, -1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_1", CubeListBuilder.create().texOffs(256, 341).addBox(-63.0F, -1.0F, -1.0F, 126.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(139.0F, -35.24200561666855F, -12.400183776675252F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_2", CubeListBuilder.create().texOffs(512, 341).addBox(-63.0F, -1.0F, -1.0F, 126.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(139.0F, -36.49200561666855F, -11.49200561666855F, -2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_3", CubeListBuilder.create().texOffs(768, 341).addBox(-63.0F, -1.0F, -1.0F, 126.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(139.0F, -37.40018377667525F, -10.24200561666855F, -2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_4", CubeListBuilder.create().texOffs(0, 344).addBox(-63.0F, -1.0F, -1.0F, 126.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(139.0F, -37.877641290737884F, -8.772542485937368F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_0", CubeListBuilder.create().texOffs(256, 344).addBox(-63.0F, -1.0F, -1.0F, 126.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(139.0F, -33.772542485937365F, 12.877641290737884F, 1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_1", CubeListBuilder.create().texOffs(512, 344).addBox(-63.0F, -1.0F, -1.0F, 126.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(139.0F, -35.24200561666855F, 12.400183776675252F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_2", CubeListBuilder.create().texOffs(768, 344).addBox(-63.0F, -1.0F, -1.0F, 126.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(139.0F, -36.49200561666855F, 11.49200561666855F, 2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_3", CubeListBuilder.create().texOffs(0, 347).addBox(-63.0F, -1.0F, -1.0F, 126.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(139.0F, -37.40018377667525F, 10.24200561666855F, 2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_4", CubeListBuilder.create().texOffs(256, 347).addBox(-63.0F, -1.0F, -1.0F, 126.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(139.0F, -37.877641290737884F, 8.772542485937368F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 52.0F), PartPose.offset(76.0F, -33.0F, -13.0F));
        g.addOrReplaceChild("tender_caja_tapab", CubeListBuilder.create().texOffs(106, 0).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 52.0F), PartPose.offset(201.0F, -33.0F, -13.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "fecil_i_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "fecil_i_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "fecil_i_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "fecil_i_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "fecil_i_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_i_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_i_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_i_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_i_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_i_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_i_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_i_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "fecil_d_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "fecil_d_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "fecil_d_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "fecil_d_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_i_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "recil_i_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "recil_i_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "recil_i_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "recil_i_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_i_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_i_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_i_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_i_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_i_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_i_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_i_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_d_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "recil_d_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "recil_d_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "recil_d_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "recil_d_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_d_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_d_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_d_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_d_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_d_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_d_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "recil_d_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "carcasa_0", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "carcasa_1", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "carcasa_2", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "carcasa_3", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "carcasa_4", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "carcasa_5", 0.5F, 1.0F, 0.4893461278963711F);
        escalar(g0, "carcasa_6", 0.5F, 1.0F, 0.4893461278963711F);
        escalar(g0, "carcasa_7", 0.5F, 1.0F, 0.48926498569118426F);
        escalar(g0, "carcasa_8", 0.5F, 1.0F, 0.48934612789637183F);
        escalar(g0, "carcasa_9", 0.5F, 1.0F, 0.4878038150960807F);
        escalar(g0, "carcasa_10", 0.5F, 1.0F, 0.48686868159398616F);
        escalar(g0, "carcasa_11", 0.5F, 1.0F, 0.48665577485317046F);
        escalar(g0, "carcasa_12", 0.5F, 1.0F, 0.4868924528361932F);
        escalar(g0, "carcasa_13", 0.5F, 1.0F, 0.48777688136211517F);
        escalar(g0, "carcasa_14", 0.5F, 1.0F, 0.48825240593155184F);
        escalar(g0, "carcasa_15", 0.5F, 1.0F, 0.4891363622618415F);
        escalar(g0, "carcasa_16", 0.5F, 1.0F, 0.4893461278963721F);
        escalar(g0, "carcasa_17", 0.5F, 1.0F, 0.48934612789637266F);
        escalar(g0, "carcasa_18", 0.5F, 1.0F, 0.48934612789637205F);
        escalar(g0, "carcasa_19", 0.5F, 1.0F, 0.48934612789637205F);
        escalar(g0, "carcasa_20", 0.5F, 1.0F, 0.4891363622618406F);
        escalar(g0, "carcasa_21", 0.5F, 1.0F, 0.48825240593155117F);
        escalar(g0, "carcasa_22", 0.5F, 1.0F, 0.4877768813621168F);
        escalar(g0, "carcasa_23", 0.5F, 1.0F, 0.4868924528361932F);
        escalar(g0, "carcasa_24", 0.5F, 1.0F, 0.48665577485316874F);
        escalar(g0, "carcasa_25", 0.5F, 1.0F, 0.4868686815939864F);
        escalar(g0, "carcasa_26", 0.5F, 1.0F, 0.4878038150960825F);
        escalar(g0, "carcasa_27", 0.5F, 1.0F, 0.48934612789637005F);
        escalar(g0, "carcasa_28", 0.5F, 1.0F, 0.48926498569118426F);
        escalar(g0, "carcasa_29", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "carcasa_30", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "carcasa_31", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "carcasa_32", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "carcasa_33", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "carcasa_34", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "carcasa_35", 0.5F, 1.0F, 0.489346127896372F);
        escalar(g0, "nariz_0", 0.45972492712967356F, 1.0F, 0.4293994066380017F);
        escalar(g0, "nariz_1", 0.4597063315750115F, 1.0F, 0.4027970052088432F);
        escalar(g0, "nariz_2", 0.459685219594543F, 1.0F, 0.3771724706768941F);
        escalar(g0, "nariz_3", 0.45966187983314016F, 1.0F, 0.4701702320154412F);
        escalar(g0, "nariz_4", 0.45963545312851045F, 1.0F, 0.4390393003089607F);
        escalar(g0, "nariz_5", 0.4596049253845842F, 1.0F, 0.40969219636408366F);
        escalar(g0, "nariz_6", 0.4595692301792602F, 1.0F, 0.3823545683098391F);
        escalar(g0, "nariz_7", 0.45952748994257775F, 1.0F, 0.3572924077942978F);
        escalar(g0, "nariz_8", 0.459468811723699F, 1.0F, 0.3346927831482114F);
        escalar(g0, "nariz_9", 0.4600643159184269F, 1.0F, 0.47098576025925065F);
        escalar(g0, "nariz_10", 0.4663460528706249F, 1.0F, 0.440031661221262F);
        escalar(g0, "nariz_11", 0.49356341093550077F, 1.0F, 0.4044878516352257F);
        escalar(g0, "nariz_12", 0.4732709947677499F, 1.0F, 0.3554818203286997F);
        escalar(g0, "nariz_13", 0.49323466776911246F, 1.0F, 0.25829895954300064F);
        escalar(g0, "nariz_14", 0.46549900185472426F, 1.0F, 0.4294018640410927F);
        escalar(g0, "nariz_15", 0.4654116174641661F, 1.0F, 0.40280586111116967F);
        escalar(g0, "nariz_16", 0.465318536961249F, 1.0F, 0.3771973271036033F);
        escalar(g0, "nariz_17", 0.4652184707559078F, 1.0F, 0.4702221522133687F);
        escalar(g0, "nariz_18", 0.46510856311781407F, 1.0F, 0.43910698004711274F);
        escalar(g0, "nariz_19", 0.4649854341020825F, 1.0F, 0.40977208852607133F);
        escalar(g0, "nariz_20", 0.46484902739344686F, 1.0F, 0.3824149009496072F);
        escalar(g0, "nariz_21", 0.4646896739368404F, 1.0F, 0.35729300637815226F);
        escalar(g0, "nariz_22", 0.46445559672784154F, 1.0F, 0.33467958247330926F);
        escalar(g0, "nariz_23", 0.4646601576603423F, 1.0F, 0.4710145878924733F);
        escalar(g0, "nariz_24", 0.469797286392055F, 1.0F, 0.44007916168081507F);
        escalar(g0, "nariz_25", 0.49329511412886573F, 1.0F, 0.40452948730026694F);
        escalar(g0, "nariz_26", 0.46392683175978594F, 1.0F, 0.3555029543272986F);
        escalar(g0, "nariz_27", 0.4677795986431177F, 1.0F, 0.258297038039233F);
        escalar(g0, "nariz_28", 0.47315700104832803F, 1.0F, 0.42941019599748537F);
        escalar(g0, "nariz_29", 0.4729479463008619F, 1.0F, 0.4028353660019828F);
        escalar(g0, "nariz_30", 0.47272673567601864F, 1.0F, 0.37721883287556485F);
        escalar(g0, "nariz_31", 0.4724923950345571F, 1.0F, 0.4702334895547963F);
        escalar(g0, "nariz_32", 0.4722406311364325F, 1.0F, 0.43909905964085677F);
        escalar(g0, "nariz_33", 0.471965104740652F, 1.0F, 0.4097427082497996F);
        escalar(g0, "nariz_34", 0.47166627722842364F, 1.0F, 0.38239321596322373F);
        escalar(g0, "nariz_35", 0.471325389563219F, 1.0F, 0.35731249664746184F);
        escalar(g0, "nariz_36", 0.4708437672557336F, 1.0F, 0.3347118300295257F);
        escalar(g0, "nariz_37", 0.47060175698742324F, 1.0F, 0.47103945047685F);
        escalar(g0, "nariz_38", 0.4746228371634646F, 1.0F, 0.4400923569280649F);
        escalar(g0, "nariz_39", 0.4945787198762096F, 1.0F, 0.40454277895830226F);
        escalar(g0, "nariz_40", 0.45608373575383554F, 1.0F, 0.35552235763360784F);
        escalar(g0, "nariz_41", 0.49841494872004255F, 1.0F, 0.2583190812209124F);
        escalar(g0, "nariz_42", 0.4826091640405627F, 1.0F, 0.42938759049944686F);
        escalar(g0, "nariz_43", 0.48222202174054807F, 1.0F, 0.4028004155284849F);
        escalar(g0, "nariz_44", 0.4818199755837913F, 1.0F, 0.377214874585203F);
        escalar(g0, "nariz_45", 0.4814054895489691F, 1.0F, 0.47025159682995726F);
        escalar(g0, "nariz_46", 0.48096065975207786F, 1.0F, 0.4391086508501741F);
        escalar(g0, "nariz_47", 0.48047999759017623F, 1.0F, 0.4097377991700885F);
        escalar(g0, "nariz_48", 0.4799577550797544F, 1.0F, 0.38239194498815765F);
        escalar(g0, "nariz_49", 0.4793830541690076F, 1.0F, 0.35732149338211167F);
        escalar(g0, "nariz_50", 0.47860244208216385F, 1.0F, 0.33471187854568024F);
        escalar(g0, "nariz_51", 0.4778709988733567F, 1.0F, 0.471021562583273F);
        escalar(g0, "nariz_52", 0.48081324453770424F, 1.0F, 0.4400676922540988F);
        escalar(g0, "nariz_53", 0.497431127167997F, 1.0F, 0.4045206705879014F);
        escalar(g0, "nariz_54", 0.4498396232150858F, 1.0F, 0.35550854015717304F);
        escalar(g0, "nariz_55", 0.4715271877797097F, 1.0F, 0.25831492008635F);
        escalar(g0, "nariz_56", 0.49375292370119733F, 1.0F, 0.4294197703747755F);
        escalar(g0, "nariz_57", 0.4931352999235341F, 1.0F, 0.4028174812289621F);
        escalar(g0, "nariz_58", 0.4925049403959137F, 1.0F, 0.37719430155108996F);
        escalar(g0, "nariz_59", 0.49185894401053887F, 1.0F, 0.4702195710750156F);
        escalar(g0, "nariz_60", 0.4911798878676621F, 1.0F, 0.43911123571770183F);
        escalar(g0, "nariz_61", 0.4904510791178142F, 1.0F, 0.4097549196098396F);
        escalar(g0, "nariz_62", 0.48966044435037387F, 1.0F, 0.3823900440507062F);
        escalar(g0, "nariz_63", 0.4888028170923191F, 1.0F, 0.3573105877692104F);
        escalar(g0, "nariz_64", 0.4876856221527923F, 1.0F, 0.3347160071948931F);
        escalar(g0, "nariz_65", 0.486438349769831F, 1.0F, 0.471031559565246F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "nariz_66", 0.48834845550159334F, 1.0F, 0.440078138812232F);
        escalar(g0, "nariz_67", 0.40148233539995826F, 1.0F, 0.40453009444308513F);
        escalar(g0, "nariz_68", 0.4452762487265554F, 1.0F, 0.35551591270584204F);
        escalar(g0, "nariz_69", 0.4457644689094561F, 1.0F, 0.2583190738178234F);
        escalar(g0, "nariz_70", 0.4051691750776724F, 1.0F, 0.4294141550886784F);
        escalar(g0, "nariz_71", 0.40446153355208103F, 1.0F, 0.4028319887801007F);
        escalar(g0, "nariz_72", 0.4037452477872755F, 1.0F, 0.37721970310843267F);
        escalar(g0, "nariz_73", 0.403007924313013F, 1.0F, 0.4702245943670766F);
        escalar(g0, "nariz_74", 0.40224207410676954F, 1.0F, 0.4390885534489753F);
        escalar(g0, "nariz_75", 0.40142971759564255F, 1.0F, 0.4097510784070811F);
        escalar(g0, "nariz_76", 0.40055934898779205F, 1.0F, 0.38240541459863825F);
        escalar(g0, "nariz_77", 0.4995209485396427F, 1.0F, 0.35730765777156487F);
        escalar(g0, "nariz_78", 0.4980352594110874F, 1.0F, 0.33470585537692416F);
        escalar(g0, "nariz_79", 0.49626451336309885F, 1.0F, 0.47104570104201593F);
        escalar(g0, "nariz_80", 0.4971989335482307F, 1.0F, 0.44009881630385816F);
        escalar(g0, "nariz_81", 0.40626467530609894F, 1.0F, 0.40454918240961774F);
        escalar(g0, "nariz_82", 0.442459971316899F, 1.0F, 0.35552863942707014F);
        escalar(g0, "nariz_83", 0.48152628162702193F, 1.0F, 0.25831954315970057F);
        escalar(g0, "nariz_84", 0.4164938534189746F, 1.0F, 0.42941356901239347F);
        escalar(g0, "nariz_85", 0.41554366970643253F, 1.0F, 0.402816028706541F);
        escalar(g0, "nariz_86", 0.4145846869567412F, 1.0F, 0.37720484795916276F);
        escalar(g0, "nariz_87", 0.4136048248294317F, 1.0F, 0.4702322113817485F);
        escalar(g0, "nariz_88", 0.41258818956485827F, 1.0F, 0.4391053956012973F);
        escalar(g0, "nariz_89", 0.411520868582568F, 1.0F, 0.40974762891403227F);
        escalar(g0, "nariz_90", 0.41038817723580384F, 1.0F, 0.38239761735001343F);
        escalar(g0, "nariz_91", 0.409172340016479F, 1.0F, 0.3573166952341527F);
        escalar(g0, "nariz_92", 0.4076741712508506F, 1.0F, 0.33470901387054397F);
        escalar(g0, "nariz_93", 0.40584328244049406F, 1.0F, 0.47102298576400103F);
        escalar(g0, "nariz_94", 0.4058605802934908F, 1.0F, 0.44007354015934486F);
        escalar(g0, "nariz_95", 0.4122702951815242F, 1.0F, 0.40452525338979173F);
        escalar(g0, "nariz_96", 0.44144155532185747F, 1.0F, 0.35550853707083935F);
        escalar(g0, "nariz_97", 0.45541957321916876F, 1.0F, 0.25831393642902506F);
        escalar(g0, "nariz_98", 0.4288824619741921F, 1.0F, 0.42941666139167345F);
        escalar(g0, "nariz_99", 0.42766460924615546F, 1.0F, 0.4028233974871427F);
        escalar(g0, "nariz_100", 0.4264361576181822F, 1.0F, 0.37720802182341706F);
        escalar(g0, "nariz_101", 0.4251883827143458F, 1.0F, 0.47022638006127426F);
        escalar(g0, "nariz_102", 0.42390295507043696F, 1.0F, 0.4391017857826564F);
        escalar(g0, "nariz_103", 0.42256276530567655F, 1.0F, 0.409751426499803F);
        escalar(g0, "nariz_104", 0.4211486174776541F, 1.0F, 0.3823965917066022F);
        escalar(g0, "nariz_105", 0.41964357202903085F, 1.0F, 0.3573114475688865F);
        escalar(g0, "nariz_106", 0.417835395838002F, 1.0F, 0.33471074363920045F);
        escalar(g0, "nariz_107", 0.4156050843973114F, 1.0F, 0.47103061341897956F);
        escalar(g0, "nariz_108", 0.41494688663130114F, 1.0F, 0.44007880190925586F);
        escalar(g0, "nariz_109", 0.41946830007578245F, 1.0F, 0.40453051233192444F);
        escalar(g0, "nariz_110", 0.44225035039928196F, 1.0F, 0.35551522095295784F);
        escalar(g0, "nariz_111", 0.43145987863176255F, 1.0F, 0.2583170522862646F);
        escalar(g0, "nariz_112", 0.4422389857675064F, 1.0F, 0.42941683861420615F);
        escalar(g0, "nariz_113", 0.4407321815662077F, 1.0F, 0.4028227391621208F);
        escalar(g0, "nariz_114", 0.4392163213311779F, 1.0F, 0.37720691434325593F);
        escalar(g0, "nariz_115", 0.4376790721602612F, 1.0F, 0.47022644705758415F);
        escalar(g0, "nariz_116", 0.4361068750406136F, 1.0F, 0.4391028703245748F);
        escalar(g0, "nariz_117", 0.4344793123442587F, 1.0F, 0.40975137567181336F);
        escalar(g0, "nariz_118", 0.4327740110945532F, 1.0F, 0.38239703499968014F);
        escalar(g0, "nariz_119", 0.4309692304837336F, 1.0F, 0.35731244002947377F);
        escalar(g0, "nariz_120", 0.42885513320709007F, 1.0F, 0.33471075248013166F);
        escalar(g0, "nariz_121", 0.4262523813088485F, 1.0F, 0.47102947249267785F);
        escalar(g0, "nariz_122", 0.4249783005976801F, 1.0F, 0.4400771109489766F);
        escalar(g0, "nariz_123", 0.4278200949522736F, 1.0F, 0.4045288877350566F);
        escalar(g0, "nariz_124", 0.4448918734029023F, 1.0F, 0.3555141107675022F);
        escalar(g0, "nariz_125", 0.4783646482557295F, 1.0F, 0.2583166387927668F);
        escalar(g0, "nariz_126", 0.4564746956120442F, 1.0F, 0.42941727935253315F);
        escalar(g0, "nariz_127", 0.45466082922544776F, 1.0F, 0.40282356563192095F);
        escalar(g0, "nariz_128", 0.4528405679822238F, 1.0F, 0.3772076635561372F);
        escalar(g0, "nariz_129", 0.45099747667562406F, 1.0F, 0.47022598160429685F);
        escalar(g0, "nariz_130", 0.4491249841675219F, 1.0F, 0.43910203262464037F);
        escalar(g0, "nariz_131", 0.4471992530072143F, 1.0F, 0.4097521692891431F);
        escalar(g0, "nariz_132", 0.44519600393568515F, 1.0F, 0.3823970282694247F);
        escalar(g0, "nariz_133", 0.44308812982604995F, 1.0F, 0.3573109075478403F);
        escalar(g0, "nariz_134", 0.44067786747238336F, 1.0F, 0.33471098622131906F);
        escalar(g0, "nariz_135", 0.4377388507660914F, 1.0F, 0.4710333755054813F);
        escalar(g0, "nariz_136", 0.4359118184068338F, 1.0F, 0.4400824739089877F);
        escalar(g0, "nariz_137", 0.4372804814792065F, 1.0F, 0.40453376364259175F);
        escalar(g0, "nariz_138", 0.4493502708028331F, 1.0F, 0.3555173048453033F);
        escalar(g0, "nariz_139", 0.4567968252102896F, 1.0F, 0.2583178449370106F);
        escalar(g0, "nariz_140", 0.47150355689539813F, 1.0F, 0.4294111001474987F);
        escalar(g0, "nariz_141", 0.4693673784767848F, 1.0F, 0.40282585029049484F);
        escalar(g0, "nariz_142", 0.4672285972795255F, 1.0F, 0.3772192990309772F);
        escalar(g0, "nariz_143", 0.4650722926284002F, 1.0F, 0.4702376473715149F);
        escalar(g0, "nariz_144", 0.46288801902155186F, 1.0F, 0.43909335937893995F);
        escalar(g0, "nariz_145", 0.4606511717177434F, 1.0F, 0.40974221687120654F);
        escalar(g0, "nariz_146", 0.45834716530775027F, 1.0F, 0.38240622348023007F);
        escalar(g0, "nariz_147", 0.4559434158096652F, 1.0F, 0.3573165402500644F);
        escalar(g0, "nariz_148", 0.4532478832234165F, 1.0F, 0.3347035348577469F);
        escalar(g0, "nariz_149", 0.4500163954999389F, 1.0F, 0.4710316482825181F);
        escalar(g0, "nariz_150", 0.4477029037377086F, 1.0F, 0.4400903896231483F);
        escalar(g0, "nariz_151", 0.4477999823786621F, 1.0F, 0.40454122524719416F);
        escalar(g0, "nariz_152", 0.4555883989797729F, 1.0F, 0.3555184012124909F);
        escalar(g0, "nariz_153", 0.43917678119828046F, 1.0F, 0.2583125565119941F);
        escalar(g0, "nariz_154", 0.48725043925759126F, 1.0F, 0.4294229220145817F);
        escalar(g0, "nariz_155", 0.4847790365262526F, 1.0F, 0.40282665495889075F);
        escalar(g0, "nariz_156", 0.48230962643149516F, 1.0F, 0.37720935906424946F);
        escalar(g0, "nariz_157", 0.47983160619083176F, 1.0F, 0.4702219775924228F);
        escalar(g0, "nariz_158", 0.47732356343379934F, 1.0F, 0.4390984559857262F);
        escalar(g0, "nariz_159", 0.4747729152328482F, 1.0F, 0.409754586571309F);
        escalar(g0, "nariz_160", 0.4721673417088965F, 1.0F, 0.3824014979936579F);
        escalar(g0, "nariz_161", 0.46947522507167305F, 1.0F, 0.35731200421063375F);
        escalar(g0, "nariz_162", 0.4665115292327167F, 1.0F, 0.3347074728579114F);
        escalar(g0, "nariz_163", 0.46303879050019103F, 1.0F, 0.4710318109691626F);
        escalar(g0, "nariz_164", 0.4603065149301095F, 1.0F, 0.44008352038863485F);
        escalar(g0, "nariz_165", 0.4593257801769113F, 1.0F, 0.4045348377811231F);
        escalar(g0, "nariz_166", 0.46355071641694734F, 1.0F, 0.3555168924460947F);
        escalar(g0, "nariz_167", 0.42599871471554435F, 1.0F, 0.2583162295553449F);
        escalar(g0, "nariz_168", 0.4197061407921872F, 1.0F, 0.42941708856235694F);
        escalar(g0, "nariz_169", 0.41735809017026204F, 1.0F, 0.40281566404690816F);
        escalar(g0, "nariz_170", 0.49801952921785597F, 1.0F, 0.3771938418526925F);
        escalar(g0, "nariz_171", 0.49520048390945187F, 1.0F, 0.4702172740411618F);
        escalar(g0, "nariz_172", 0.4923663717857096F, 1.0F, 0.43911015396864617F);
        escalar(g0, "nariz_173", 0.4895076936653762F, 1.0F, 0.4097597635620889F);
        escalar(g0, "nariz_174", 0.4866020229580917F, 1.0F, 0.38239945090464933F);
        escalar(g0, "nariz_175", 0.4836253687640384F, 1.0F, 0.35730513887134513F);
        escalar(g0, "nariz_176", 0.4804156376299325F, 1.0F, 0.334704983262137F);
        escalar(g0, "nariz_177", 0.4767611232594155F, 1.0F, 0.471035435865102F);
        escalar(g0, "nariz_178", 0.47367805852834605F, 1.0F, 0.44008490159284136F);
        escalar(g0, "nariz_179", 0.47180356957367897F, 1.0F, 0.4045360472856734F);
        escalar(g0, "nariz_180", 0.4731661887126535F, 1.0F, 0.35551899817091914F);
        escalar(g0, "nariz_181", 0.4176869977333335F, 1.0F, 0.25831919273309994F);
        escalar(g0, "nariz_182", 0.4338510014053811F, 1.0F, 0.4294122176122295F);
        escalar(g0, "nariz_183", 0.4312067855421404F, 1.0F, 0.4028333020154763F);
        escalar(g0, "nariz_184", 0.4285741374736077F, 1.0F, 0.3772349661421921F);
        escalar(g0, "nariz_185", 0.425941165228003F, 1.0F, 0.47026303092661403F);
        escalar(g0, "nariz_186", 0.4233096154995563F, 1.0F, 0.43910641537301204F);
        escalar(g0, "nariz_187", 0.42066625368149396F, 1.0F, 0.4097224716195392F);
        escalar(g0, "nariz_188", 0.417989522263517F, 1.0F, 0.3823765811162894F);
        escalar(g0, "nariz_189", 0.49833755144984737F, 1.0F, 0.3573299033689996F);
        escalar(g0, "nariz_190", 0.49491683132611647F, 1.0F, 0.3347308660528762F);
        escalar(g0, "nariz_191", 0.4911393900095028F, 1.0F, 0.4710293149760728F);
        escalar(g0, "nariz_192", 0.48777377850563647F, 1.0F, 0.4400660030598558F);
        escalar(g0, "nariz_193", 0.4851786417083785F, 1.0F, 0.4045179805145539F);
        escalar(g0, "nariz_194", 0.4843514483419469F, 1.0F, 0.35550987268966916F);
        escalar(g0, "nariz_195", 0.4974460778923494F, 1.0F, 0.2583207554565552F);
        escalar(g0, "nariz_196", 0.44843200423241125F, 1.0F, 0.4294263422934128F);
        escalar(g0, "nariz_197", 0.4454849696613417F, 1.0F, 0.40282261944888675F);
        escalar(g0, "nariz_198", 0.44255552100540196F, 1.0F, 0.37720023292593785F);
        escalar(g0, "nariz_199", 0.4396400053370908F, 1.0F, 0.4702068237440657F);
        escalar(g0, "nariz_200", 0.436733182677911F, 1.0F, 0.4390717424199115F);
        escalar(g0, "nariz_201", 0.4338189841640722F, 1.0F, 0.4097413055303631F);
        escalar(g0, "nariz_202", 0.43089989698826264F, 1.0F, 0.3824094664133399F);
        escalar(g0, "nariz_203", 0.4279739349001965F, 1.0F, 0.35731761723074834F);
        escalar(g0, "nariz_204", 0.42497153809814914F, 1.0F, 0.33471311093700257F);
        escalar(g0, "nariz_205", 0.42177364716727633F, 1.0F, 0.47104043265217477F);
        escalar(g0, "nariz_206", 0.4187927720389158F, 1.0F, 0.4400941609703115F);
        escalar(g0, "nariz_207", 0.4993981939470096F, 1.0F, 0.4045447367856433F);
        escalar(g0, "nariz_208", 0.4970161170114781F, 1.0F, 0.3555238170319273F);
        escalar(g0, "nariz_209", 0.4166755593061962F, 1.0F, 0.2583200707420533F);
        escalar(g0, "nariz_210", 0.4634051699649251F, 1.0F, 0.42934786939577546F);
        escalar(g0, "nariz_211", 0.460149541486683F, 1.0F, 0.40276409714756634F);
        escalar(g0, "nariz_212", 0.45691814421726534F, 1.0F, 0.37716258365121746F);
        escalar(g0, "nariz_213", 0.4537100767035624F, 1.0F, 0.4701860211021218F);
        escalar(g0, "nariz_214", 0.45052387283195F, 1.0F, 0.4390822783945489F);
        escalar(g0, "nariz_215", 0.44734946064808495F, 1.0F, 0.40973178052466447F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1) {
        escalar(g0, "nariz_216", 0.444200985951049F, 1.0F, 0.3823603794981942F);
        escalar(g0, "nariz_217", 0.4410669034256885F, 1.0F, 0.35726384203108924F);
        escalar(g0, "nariz_218", 0.43792655788608553F, 1.0F, 0.3346586231243253F);
        escalar(g0, "nariz_219", 0.43473674060284323F, 1.0F, 0.470962717811026F);
        escalar(g0, "nariz_220", 0.4316407247347997F, 1.0F, 0.44002243391453555F);
        escalar(g0, "nariz_221", 0.42867467068802717F, 1.0F, 0.4044789833166509F);
        escalar(g0, "nariz_222", 0.42588689365671106F, 1.0F, 0.35546551147718874F);
        escalar(g0, "nariz_223", 0.42402575881955373F, 1.0F, 0.25827742004946574F);
        escalar(g0, "nariz_224", 0.4634051699649269F, 1.0F, 0.4293478693957715F);
        escalar(g0, "nariz_225", 0.46014954148668386F, 1.0F, 0.40276409714756856F);
        escalar(g0, "nariz_226", 0.4569181442172645F, 1.0F, 0.37716258365121924F);
        escalar(g0, "nariz_227", 0.4537100767035624F, 1.0F, 0.4701860211021214F);
        escalar(g0, "nariz_228", 0.45052387283194983F, 1.0F, 0.43908227839454844F);
        escalar(g0, "nariz_229", 0.4473494606480852F, 1.0F, 0.40973178052466475F);
        escalar(g0, "nariz_230", 0.444200985951048F, 1.0F, 0.3823603794981909F);
        escalar(g0, "nariz_231", 0.441066903425688F, 1.0F, 0.35726384203107786F);
        escalar(g0, "nariz_232", 0.43792655788608603F, 1.0F, 0.3346586231243151F);
        escalar(g0, "nariz_233", 0.4347367406028441F, 1.0F, 0.4709627178110186F);
        escalar(g0, "nariz_234", 0.4316407247347997F, 1.0F, 0.44002243391453594F);
        escalar(g0, "nariz_235", 0.42867467068802667F, 1.0F, 0.40447898331665566F);
        escalar(g0, "nariz_236", 0.42588689365671034F, 1.0F, 0.3554655114771923F);
        escalar(g0, "nariz_237", 0.42402575881955507F, 1.0F, 0.25827742004946636F);
        escalar(g0, "nariz_238", 0.448432004232415F, 1.0F, 0.4294263422934167F);
        escalar(g0, "nariz_239", 0.4454849696613415F, 1.0F, 0.40282261944888664F);
        escalar(g0, "nariz_240", 0.4425555210054004F, 1.0F, 0.3772002329259345F);
        escalar(g0, "nariz_241", 0.4396400053370908F, 1.0F, 0.4702068237440613F);
        escalar(g0, "nariz_242", 0.43673318267791056F, 1.0F, 0.43907174241990693F);
        escalar(g0, "nariz_243", 0.4338189841640734F, 1.0F, 0.4097413055303603F);
        escalar(g0, "nariz_244", 0.4308998969882607F, 1.0F, 0.3824094664133388F);
        escalar(g0, "nariz_245", 0.4279739349001955F, 1.0F, 0.3573176172307481F);
        escalar(g0, "nariz_246", 0.4249715380981504F, 1.0F, 0.33471311093700223F);
        escalar(g0, "nariz_247", 0.4217736471672772F, 1.0F, 0.47104043265217244F);
        escalar(g0, "nariz_248", 0.4187927720389171F, 1.0F, 0.4400941609703082F);
        escalar(g0, "nariz_249", 0.4993981939470082F, 1.0F, 0.4045447367856404F);
        escalar(g0, "nariz_250", 0.497016117011478F, 1.0F, 0.35552381703192615F);
        escalar(g0, "nariz_251", 0.4166755593061972F, 1.0F, 0.2583200707420541F);
        escalar(g0, "nariz_252", 0.43385100140538485F, 1.0F, 0.42941221761222914F);
        escalar(g0, "nariz_253", 0.4312067855421395F, 1.0F, 0.40283330201547773F);
        escalar(g0, "nariz_254", 0.42857413747360623F, 1.0F, 0.3772349661421952F);
        escalar(g0, "nariz_255", 0.425941165228003F, 1.0F, 0.4702630309266184F);
        escalar(g0, "nariz_256", 0.4233096154995561F, 1.0F, 0.43910641537301637F);
        escalar(g0, "nariz_257", 0.42066625368149496F, 1.0F, 0.40972247161954095F);
        escalar(g0, "nariz_258", 0.41798952226351527F, 1.0F, 0.3823765811162894F);
        escalar(g0, "nariz_259", 0.49833755144984676F, 1.0F, 0.3573299033690012F);
        escalar(g0, "nariz_260", 0.494916831326117F, 1.0F, 0.33473086605287694F);
        escalar(g0, "nariz_261", 0.4911393900095045F, 1.0F, 0.4710293149760733F);
        escalar(g0, "nariz_262", 0.4877737785056374F, 1.0F, 0.44006600305985766F);
        escalar(g0, "nariz_263", 0.48517864170837777F, 1.0F, 0.4045179805145547F);
        escalar(g0, "nariz_264", 0.48435144834194777F, 1.0F, 0.355509872689668F);
        escalar(g0, "nariz_265", 0.49744607789234896F, 1.0F, 0.2583207554565543F);
        escalar(g0, "nariz_266", 0.41970614079219054F, 1.0F, 0.4294170885623536F);
        escalar(g0, "nariz_267", 0.41735809017026365F, 1.0F, 0.4028156640469086F);
        escalar(g0, "nariz_268", 0.4980195292178523F, 1.0F, 0.3771938418526931F);
        escalar(g0, "nariz_269", 0.4952004839094526F, 1.0F, 0.47021727404115965F);
        escalar(g0, "nariz_270", 0.4923663717857084F, 1.0F, 0.43911015396864367F);
        escalar(g0, "nariz_271", 0.4895076936653773F, 1.0F, 0.4097597635620864F);
        escalar(g0, "nariz_272", 0.48660202295808974F, 1.0F, 0.3823994509046489F);
        escalar(g0, "nariz_273", 0.4836253687640384F, 1.0F, 0.35730513887134513F);
        escalar(g0, "nariz_274", 0.4804156376299325F, 1.0F, 0.33470498326213854F);
        escalar(g0, "nariz_275", 0.4767611232594179F, 1.0F, 0.471035435865103F);
        escalar(g0, "nariz_276", 0.4736780585283453F, 1.0F, 0.4400849015928396F);
        escalar(g0, "nariz_277", 0.47180356957367897F, 1.0F, 0.4045360472856725F);
        escalar(g0, "nariz_278", 0.4731661887126535F, 1.0F, 0.35551899817091936F);
        escalar(g0, "nariz_279", 0.41768699773333356F, 1.0F, 0.2583191927331003F);
        escalar(g0, "nariz_280", 0.4872504392575932F, 1.0F, 0.4294229220145852F);
        escalar(g0, "nariz_281", 0.4847790365262565F, 1.0F, 0.4028266549588909F);
        escalar(g0, "nariz_282", 0.48230962643148967F, 1.0F, 0.3772093590642497F);
        escalar(g0, "nariz_283", 0.4798316061908344F, 1.0F, 0.47022197759242546F);
        escalar(g0, "nariz_284", 0.4773235634337972F, 1.0F, 0.439098455985731F);
        escalar(g0, "nariz_285", 0.4747729152328505F, 1.0F, 0.4097545865713145F);
        escalar(g0, "nariz_286", 0.47216734170889263F, 1.0F, 0.38240149799365897F);
        escalar(g0, "nariz_287", 0.46947522507167305F, 1.0F, 0.35731200421063075F);
        escalar(g0, "nariz_288", 0.46651152923271805F, 1.0F, 0.3347074728579103F);
        escalar(g0, "nariz_289", 0.46303879050019303F, 1.0F, 0.4710318109691631F);
        escalar(g0, "nariz_290", 0.4603065149301087F, 1.0F, 0.44008352038863685F);
        escalar(g0, "nariz_291", 0.4593257801769114F, 1.0F, 0.40453483778112465F);
        escalar(g0, "nariz_292", 0.4635507164169474F, 1.0F, 0.3555168924460945F);
        escalar(g0, "nariz_293", 0.4259987147155444F, 1.0F, 0.2583162295553441F);
        escalar(g0, "nariz_294", 0.4715035568953991F, 1.0F, 0.42941110014749356F);
        escalar(g0, "nariz_295", 0.4693673784767884F, 1.0F, 0.4028258502904913F);
        escalar(g0, "nariz_296", 0.46722859727952104F, 1.0F, 0.3772192990309753F);
        escalar(g0, "nariz_297", 0.46507229262840283F, 1.0F, 0.4702376473715129F);
        escalar(g0, "nariz_298", 0.4628880190215501F, 1.0F, 0.4390933593789361F);
        escalar(g0, "nariz_299", 0.4606511717177453F, 1.0F, 0.40974221687120255F);
        escalar(g0, "nariz_300", 0.45834716530774494F, 1.0F, 0.38240622348022635F);
        escalar(g0, "nariz_301", 0.4559434158096668F, 1.0F, 0.3573165402500646F);
        escalar(g0, "nariz_302", 0.4532478832234176F, 1.0F, 0.3347035348577485F);
        escalar(g0, "nariz_303", 0.4500163954999408F, 1.0F, 0.47103164828251887F);
        escalar(g0, "nariz_304", 0.44770290373770844F, 1.0F, 0.44009038962314984F);
        escalar(g0, "nariz_305", 0.44779998237866153F, 1.0F, 0.40454122524719505F);
        escalar(g0, "nariz_306", 0.45558839897977305F, 1.0F, 0.3555184012124929F);
        escalar(g0, "nariz_307", 0.4391767811982807F, 1.0F, 0.2583125565119956F);
        escalar(g0, "nariz_308", 0.45647469561204745F, 1.0F, 0.42941727935253304F);
        escalar(g0, "nariz_309", 0.4546608292254512F, 1.0F, 0.40282356563192434F);
        escalar(g0, "nariz_310", 0.4528405679822196F, 1.0F, 0.3772076635561391F);
        escalar(g0, "nariz_311", 0.45099747667562606F, 1.0F, 0.4702259816042991F);
        escalar(g0, "nariz_312", 0.4491249841675198F, 1.0F, 0.43910203262464204F);
        escalar(g0, "nariz_313", 0.4471992530072163F, 1.0F, 0.40975216928914526F);
        escalar(g0, "nariz_314", 0.44519600393568054F, 1.0F, 0.3823970282694284F);
        escalar(g0, "nariz_315", 0.4430881298260522F, 1.0F, 0.35731090754784217F);
        escalar(g0, "nariz_316", 0.4406778674723836F, 1.0F, 0.33471098622131895F);
        escalar(g0, "nariz_317", 0.4377388507660921F, 1.0F, 0.4710333755054774F);
        escalar(g0, "nariz_318", 0.4359118184068348F, 1.0F, 0.4400824739089828F);
        escalar(g0, "nariz_319", 0.437280481479206F, 1.0F, 0.4045337636425881F);
        escalar(g0, "nariz_320", 0.44935027080283374F, 1.0F, 0.35551730484529986F);
        escalar(g0, "nariz_321", 0.4567968252102892F, 1.0F, 0.25831784493700977F);
        escalar(g0, "nariz_322", 0.4422389857675097F, 1.0F, 0.4294168386142058F);
        escalar(g0, "nariz_323", 0.44073218156621063F, 1.0F, 0.4028227391621173F);
        escalar(g0, "nariz_324", 0.4392163213311749F, 1.0F, 0.37720691434325565F);
        escalar(g0, "nariz_325", 0.43767907216026264F, 1.0F, 0.47022644705758426F);
        escalar(g0, "nariz_326", 0.43610687504061224F, 1.0F, 0.4391028703245749F);
        escalar(g0, "nariz_327", 0.43447931234426F, 1.0F, 0.4097513756718129F);
        escalar(g0, "nariz_328", 0.4327740110945493F, 1.0F, 0.3823970349996775F);
        escalar(g0, "nariz_329", 0.4309692304837352F, 1.0F, 0.35731244002947343F);
        escalar(g0, "nariz_330", 0.42885513320709095F, 1.0F, 0.3347107524801336F);
        escalar(g0, "nariz_331", 0.4262523813088473F, 1.0F, 0.471029472492681F);
        escalar(g0, "nariz_332", 0.4249783005976816F, 1.0F, 0.4400771109489775F);
        escalar(g0, "nariz_333", 0.4278200949522736F, 1.0F, 0.4045288877350576F);
        escalar(g0, "nariz_334", 0.44489187340290304F, 1.0F, 0.35551411076750317F);
        escalar(g0, "nariz_335", 0.4783646482557276F, 1.0F, 0.25831663879277056F);
        escalar(g0, "nariz_336", 0.42888246197419394F, 1.0F, 0.4294166613916735F);
        escalar(g0, "nariz_337", 0.4276646092461586F, 1.0F, 0.40282339748714446F);
        escalar(g0, "nariz_338", 0.4264361576181802F, 1.0F, 0.3772080218234187F);
        escalar(g0, "nariz_339", 0.4251883827143458F, 1.0F, 0.47022638006127443F);
        escalar(g0, "nariz_340", 0.42390295507043696F, 1.0F, 0.43910178578265713F);
        escalar(g0, "nariz_341", 0.4225627653056769F, 1.0F, 0.40975142649980417F);
        escalar(g0, "nariz_342", 0.4211486174776498F, 1.0F, 0.3823965917066013F);
        escalar(g0, "nariz_343", 0.4196435720290335F, 1.0F, 0.3573114475688854F);
        escalar(g0, "nariz_344", 0.41783539583800255F, 1.0F, 0.33471074363919967F);
        escalar(g0, "nariz_345", 0.4156050843973101F, 1.0F, 0.47103061341897906F);
        escalar(g0, "nariz_346", 0.4149468866313031F, 1.0F, 0.4400788019092591F);
        escalar(g0, "nariz_347", 0.4194683000757822F, 1.0F, 0.4045305123319264F);
        escalar(g0, "nariz_348", 0.4422503503992818F, 1.0F, 0.3555152209529591F);
        escalar(g0, "nariz_349", 0.4314598786317617F, 1.0F, 0.2583170522862628F);
        escalar(g0, "nariz_350", 0.4164938534189764F, 1.0F, 0.42941356901239364F);
        escalar(g0, "nariz_351", 0.4155436697064359F, 1.0F, 0.4028160287065393F);
        escalar(g0, "nariz_352", 0.41458468695673945F, 1.0F, 0.3772048479591631F);
        escalar(g0, "nariz_353", 0.4136048248294317F, 1.0F, 0.4702322113817526F);
        escalar(g0, "nariz_354", 0.4125881895648578F, 1.0F, 0.4391053956012987F);
        escalar(g0, "nariz_355", 0.41152086858256876F, 1.0F, 0.4097476289140333F);
        escalar(g0, "nariz_356", 0.41038817723579957F, 1.0F, 0.38239761735001926F);
        escalar(g0, "nariz_357", 0.4091723400164812F, 1.0F, 0.35731669523415716F);
        escalar(g0, "nariz_358", 0.4076741712508515F, 1.0F, 0.33470901387054575F);
        escalar(g0, "nariz_359", 0.4058432824404939F, 1.0F, 0.4710229857640044F);
        escalar(g0, "nariz_360", 0.4058605802934915F, 1.0F, 0.4400735401593436F);
        escalar(g0, "nariz_361", 0.4122702951815239F, 1.0F, 0.4045252533897891F);
        escalar(g0, "nariz_362", 0.44144155532185697F, 1.0F, 0.3555085370708389F);
        escalar(g0, "nariz_363", 0.4554195732191692F, 1.0F, 0.2583139364290246F);
        escalar(g0, "nariz_364", 0.40516917507767447F, 1.0F, 0.4294141550886797F);
        escalar(g0, "nariz_365", 0.4044615335520832F, 1.0F, 0.4028319887801017F);
    }

    private static void escalas3(ModelPart g0, ModelPart g1) {
        escalar(g0, "nariz_366", 0.40374524778727433F, 1.0F, 0.3772197031084302F);
        escalar(g0, "nariz_367", 0.403007924313013F, 1.0F, 0.47022459436707126F);
        escalar(g0, "nariz_368", 0.4022420741067691F, 1.0F, 0.43908855344897324F);
        escalar(g0, "nariz_369", 0.40142971759564344F, 1.0F, 0.40975107840708175F);
        escalar(g0, "nariz_370", 0.4005593489877885F, 1.0F, 0.3824054145986359F);
        escalar(g0, "nariz_371", 0.499520948539645F, 1.0F, 0.35730765777156526F);
        escalar(g0, "nariz_372", 0.4980352594110875F, 1.0F, 0.33470585537692693F);
        escalar(g0, "nariz_373", 0.49626451336310007F, 1.0F, 0.47104570104201293F);
        escalar(g0, "nariz_374", 0.4971989335482298F, 1.0F, 0.44009881630385506F);
        escalar(g0, "nariz_375", 0.40626467530609905F, 1.0F, 0.40454918240961757F);
        escalar(g0, "nariz_376", 0.44245997131689946F, 1.0F, 0.3555286394270676F);
        escalar(g0, "nariz_377", 0.48152628162702055F, 1.0F, 0.2583195431597023F);
        escalar(g0, "nariz_378", 0.4937529237011986F, 1.0F, 0.4294197703747773F);
        escalar(g0, "nariz_379", 0.493135299923536F, 1.0F, 0.4028174812289588F);
        escalar(g0, "nariz_380", 0.4925049403959123F, 1.0F, 0.3771943015510888F);
        escalar(g0, "nariz_381", 0.49185894401053887F, 1.0F, 0.47021957107501583F);
        escalar(g0, "nariz_382", 0.4911798878676621F, 1.0F, 0.4391112357177008F);
        escalar(g0, "nariz_383", 0.4904510791178156F, 1.0F, 0.40975491960983956F);
        escalar(g0, "nariz_384", 0.4896604443503697F, 1.0F, 0.3823900440507096F);
        escalar(g0, "nariz_385", 0.4888028170923214F, 1.0F, 0.35731058776921126F);
        escalar(g0, "nariz_386", 0.4876856221527919F, 1.0F, 0.33471600719489253F);
        escalar(g0, "nariz_387", 0.48643834976983236F, 1.0F, 0.4710315595652495F);
        escalar(g0, "nariz_388", 0.4883484555015924F, 1.0F, 0.4400781388122327F);
        escalar(g0, "nariz_389", 0.4014823353999576F, 1.0F, 0.40453009444308385F);
        escalar(g0, "nariz_390", 0.4452762487265563F, 1.0F, 0.3555159127058443F);
        escalar(g0, "nariz_391", 0.445764468909455F, 1.0F, 0.25831907381782154F);
        escalar(g0, "nariz_392", 0.48260916404056264F, 1.0F, 0.4293875904994454F);
        escalar(g0, "nariz_393", 0.48222202174055007F, 1.0F, 0.4028004155284868F);
        escalar(g0, "nariz_394", 0.48181997558378975F, 1.0F, 0.3772148745852029F);
        escalar(g0, "nariz_395", 0.4814054895489698F, 1.0F, 0.47025159682995765F);
        escalar(g0, "nariz_396", 0.4809606597520775F, 1.0F, 0.43910865085017736F);
        escalar(g0, "nariz_397", 0.4804799975901774F, 1.0F, 0.4097377991700886F);
        escalar(g0, "nariz_398", 0.47995775507975125F, 1.0F, 0.3823919449881552F);
        escalar(g0, "nariz_399", 0.47938305416900956F, 1.0F, 0.35732149338211167F);
        escalar(g0, "nariz_400", 0.47860244208216385F, 1.0F, 0.3347118785456827F);
        escalar(g0, "nariz_401", 0.4778709988733568F, 1.0F, 0.4710215625832742F);
        escalar(g0, "nariz_402", 0.4808132445377037F, 1.0F, 0.4400676922541005F);
        escalar(g0, "nariz_403", 0.49743112716799626F, 1.0F, 0.4045206705879005F);
        escalar(g0, "nariz_404", 0.44983962321508564F, 1.0F, 0.3555085401571717F);
        escalar(g0, "nariz_405", 0.47152718777971037F, 1.0F, 0.2583149200863504F);
        escalar(g0, "nariz_406", 0.47315700104832825F, 1.0F, 0.42941019599748714F);
        escalar(g0, "nariz_407", 0.4729479463008639F, 1.0F, 0.4028353660019829F);
        escalar(g0, "nariz_408", 0.47272673567601686F, 1.0F, 0.37721883287556657F);
        escalar(g0, "nariz_409", 0.47249239503455776F, 1.0F, 0.4702334895547963F);
        escalar(g0, "nariz_410", 0.47224063113643217F, 1.0F, 0.43909905964085477F);
        escalar(g0, "nariz_411", 0.471965104740653F, 1.0F, 0.4097427082497993F);
        escalar(g0, "nariz_412", 0.4716662772284209F, 1.0F, 0.3823932159632258F);
        escalar(g0, "nariz_413", 0.47132538956322095F, 1.0F, 0.35731249664746256F);
        escalar(g0, "nariz_414", 0.4708437672557334F, 1.0F, 0.33471183002952376F);
        escalar(g0, "nariz_415", 0.47060175698742335F, 1.0F, 0.4710394504768492F);
        escalar(g0, "nariz_416", 0.47462283716346393F, 1.0F, 0.4400923569280637F);
        escalar(g0, "nariz_417", 0.4945787198762096F, 1.0F, 0.40454277895830487F);
        escalar(g0, "nariz_418", 0.45608373575383493F, 1.0F, 0.35552235763361073F);
        escalar(g0, "nariz_419", 0.49841494872004316F, 1.0F, 0.2583190812209124F);
        escalar(g0, "nariz_420", 0.4654990018547246F, 1.0F, 0.4294018640410932F);
        escalar(g0, "nariz_421", 0.46541161746416754F, 1.0F, 0.4028058611111719F);
        escalar(g0, "nariz_422", 0.46531853696124775F, 1.0F, 0.3771973271036033F);
        escalar(g0, "nariz_423", 0.4652184707559078F, 1.0F, 0.47022215221336916F);
        escalar(g0, "nariz_424", 0.46510856311781407F, 1.0F, 0.43910698004711274F);
        escalar(g0, "nariz_425", 0.46498543410208326F, 1.0F, 0.4097720885260703F);
        escalar(g0, "nariz_426", 0.4648490273934453F, 1.0F, 0.3824149009496069F);
        escalar(g0, "nariz_427", 0.46468967393684096F, 1.0F, 0.3572930063781547F);
        escalar(g0, "nariz_428", 0.46445559672784087F, 1.0F, 0.33467958247331225F);
        escalar(g0, "nariz_429", 0.4646601576603444F, 1.0F, 0.4710145878924748F);
        escalar(g0, "nariz_430", 0.4697972863920533F, 1.0F, 0.4400791616808156F);
        escalar(g0, "nariz_431", 0.4932951141288659F, 1.0F, 0.40452948730026606F);
        escalar(g0, "nariz_432", 0.4639268317597861F, 1.0F, 0.3555029543272958F);
        escalar(g0, "nariz_433", 0.4677795986431177F, 1.0F, 0.2582970380392319F);
        escalar(g0, "nariz_434", 0.4597249271296739F, 1.0F, 0.42939940663800347F);
        escalar(g0, "nariz_435", 0.45970633157501206F, 1.0F, 0.40279700520884115F);
        escalar(g0, "nariz_436", 0.45968521959454245F, 1.0F, 0.3771724706768924F);
        escalar(g0, "nariz_437", 0.45966187983314016F, 1.0F, 0.47017023201544106F);
        escalar(g0, "nariz_438", 0.45963545312851045F, 1.0F, 0.43903930030896077F);
        escalar(g0, "nariz_439", 0.4596049253845843F, 1.0F, 0.40969219636408205F);
        escalar(g0, "nariz_440", 0.45956923017926F, 1.0F, 0.38235456830984066F);
        escalar(g0, "nariz_441", 0.45952748994257786F, 1.0F, 0.3572924077943013F);
        escalar(g0, "nariz_442", 0.45946881172369813F, 1.0F, 0.3346927831482105F);
        escalar(g0, "nariz_443", 0.4600643159184288F, 1.0F, 0.47098576025925315F);
        escalar(g0, "nariz_444", 0.4663460528706236F, 1.0F, 0.44003166122126514F);
        escalar(g0, "nariz_445", 0.493563410935501F, 1.0F, 0.4044878516352253F);
        escalar(g0, "nariz_446", 0.4732709947677504F, 1.0F, 0.35548182032869946F);
        escalar(g0, "nariz_447", 0.4932346677691122F, 1.0F, 0.2582989595429991F);
        escalar(g0, "faro_0", 0.3923141121612922F, 0.8F, 0.3923141121612922F);
        escalar(g0, "faro_1", 0.3923141121612922F, 0.8F, 0.3923141121612922F);
        escalar(g0, "faro_2", 0.3923141121612922F, 0.8F, 0.3923141121612922F);
        escalar(g0, "faro_3", 0.3923141121612922F, 0.8F, 0.3923141121612922F);
        escalar(g0, "faro_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "piloto_0", 0.47487849621513156F, 1.0F, 0.4259752553040784F);
        escalar(g0, "piloto_1", 0.47487849621513156F, 1.0F, 0.48070872440471923F);
        escalar(g0, "piloto_2", 0.4768980724034306F, 1.0F, 0.4423525444056694F);
        escalar(g0, "piloto_3", 0.4768980724034306F, 1.0F, 0.4689316332337927F);
        escalar(g0, "piloto_4", 0.4817265936099227F, 1.0F, 0.45078202612157836F);
        escalar(g0, "piloto_5", 0.4817265936099227F, 1.0F, 0.47115310272287897F);
        escalar(g0, "piloto_6", 0.4895981272784502F, 1.0F, 0.46662996214186875F);
        escalar(g0, "piloto_7", 0.4895981272784502F, 1.0F, 0.49107208920031825F);
        escalar(g0, "piloto_8", 0.49956663456790107F, 1.0F, 0.5006818473608553F);
        escalar(g0, "piloto_9", 0.49956663456790107F, 1.0F, 0.4646831730909246F);
        escalar(g0, "piloto_10", 0.45882221580495186F, 1.0F, 0.4924515552547009F);
        escalar(g0, "piloto_11", 0.45882221580495186F, 1.0F, 0.4615950505104763F);
        escalar(g0, "piloto_12", 0.46635860728055895F, 1.0F, 0.4246488440894415F);
        escalar(g0, "piloto_13", 0.46635860728055895F, 1.0F, 0.5046229416778718F);
        escalar(g0, "piloto_14", 0.47058869818698773F, 1.0F, 0.49300083672679973F);
        escalar(g0, "piloto_15", 0.47058869818698773F, 1.0F, 0.47967775918195515F);
        escalar(g0, "piloto_16", 0.47058869818698773F, 1.0F, 0.49300083672679973F);
        escalar(g0, "piloto_17", 0.47058869818698773F, 1.0F, 0.47967775918195515F);
        escalar(g0, "piloto_18", 0.46635860728055895F, 1.0F, 0.4246488440894415F);
        escalar(g0, "piloto_19", 0.46635860728055895F, 1.0F, 0.5046229416778718F);
        escalar(g0, "piloto_20", 0.45882221580495186F, 1.0F, 0.4924515552547009F);
        escalar(g0, "piloto_21", 0.45882221580495186F, 1.0F, 0.4615950505104763F);
        escalar(g0, "piloto_22", 0.49956663456790107F, 1.0F, 0.5006818473608553F);
        escalar(g0, "piloto_23", 0.49956663456790107F, 1.0F, 0.4646831730909246F);
        escalar(g0, "piloto_24", 0.4895981272784502F, 1.0F, 0.46662996214186875F);
        escalar(g0, "piloto_25", 0.4895981272784502F, 1.0F, 0.49107208920031825F);
        escalar(g0, "piloto_26", 0.4817265936099227F, 1.0F, 0.45078202612157836F);
        escalar(g0, "piloto_27", 0.4817265936099227F, 1.0F, 0.47115310272287897F);
        escalar(g0, "piloto_28", 0.4768980724034306F, 1.0F, 0.4423525444056694F);
        escalar(g0, "piloto_29", 0.4768980724034306F, 1.0F, 0.4689316332337927F);
        escalar(g0, "piloto_30", 0.47487849621513156F, 1.0F, 0.4259752553040784F);
        escalar(g0, "piloto_31", 0.47487849621513156F, 1.0F, 0.48070872440471923F);
        escalar(g0, "cabina_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "cabina_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "cabina_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "cabina_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "cabina_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "cabina_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "cabina_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "cabina_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "cabina_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "cabina_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "cabina_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tender_caja_cantoi_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g1, "tender_caja_cantoi_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g1, "tender_caja_cantoi_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g1, "tender_caja_cantoi_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g1, "tender_caja_cantoi_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g1, "tender_caja_cantod_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g1, "tender_caja_cantod_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g1, "tender_caja_cantod_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g1, "tender_caja_cantod_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g1, "tender_caja_cantod_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g1, "tender_caja_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tender_caja_tapab", 1.0F, 0.5F, 0.5F);
    }
}
