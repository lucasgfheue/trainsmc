package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Furgón refrigerado" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonRefrigerado {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_refrigerado"), "main"),
            LocomotoraMod.id("textures/entity/vagon_refrigerado.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -35.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -35.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -35.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -35.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -35.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -35.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 24.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 24.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 24.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 35.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 35.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 35.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 24.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 24.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 24.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 35.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 35.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 35.5F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloVagonRefrigerado::crearCapa,
            16.0F,
            ModeloVagonRefrigerado::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -30.0F, 30.0F)));

    private ModeloVagonRefrigerado() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("costadoi", CubeListBuilder.create().texOffs(96, 0).addBox(0.0F, -44.0F, 0.0F, 160.0F, 44.0F, 2.0F), PartPose.offset(-40.0F, -12.0F, -12.5F));
        g.addOrReplaceChild("costadod", CubeListBuilder.create().texOffs(420, 0).addBox(0.0F, -44.0F, 0.0F, 160.0F, 44.0F, 2.0F), PartPose.offset(-40.0F, -12.0F, 11.5F));
        g.addOrReplaceChild("techo_0", CubeListBuilder.create().texOffs(0, 72).addBox(-41.0F, -1.0F, -1.5F, 82.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.44676873729054F, -12.193954274491375F, -2.8119931825173223F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_1", CubeListBuilder.create().texOffs(170, 72).addBox(-41.0F, -1.0F, -1.5F, 82.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.24353341947321F, -9.552670525146327F, -2.885237509422316F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_2", CubeListBuilder.create().texOffs(340, 72).addBox(-41.0F, -1.0F, -1.5F, 82.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.844875721882204F, -6.860162170718927F, -2.958481836327309F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_3", CubeListBuilder.create().texOffs(510, 72).addBox(-41.0F, -1.0F, -1.5F, 82.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.247571046549936F, -4.130867338932034F, -3.031726163232303F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_4", CubeListBuilder.create().texOffs(680, 72).addBox(-41.0F, -1.0F, -1.5F, 82.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.44946000685041F, -1.3794214188680602F, -3.104970490137295F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_5", CubeListBuilder.create().texOffs(850, 72).addBox(-41.0F, -1.0F, -1.5F, 82.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.44946000685041F, 1.379421418868062F, 3.104970490137295F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_6", CubeListBuilder.create().texOffs(0, 76).addBox(-41.0F, -1.0F, -1.5F, 82.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.247571046549936F, 4.1308673389320365F, 3.031726163232303F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_7", CubeListBuilder.create().texOffs(170, 76).addBox(-41.0F, -1.0F, -1.5F, 82.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.844875721882204F, 6.860162170718929F, 2.958481836327309F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_8", CubeListBuilder.create().texOffs(340, 76).addBox(-41.0F, -1.0F, -1.5F, 82.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.24353341947321F, 9.552670525146329F, 2.8852375094223155F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_9", CubeListBuilder.create().texOffs(510, 76).addBox(-41.0F, -1.0F, -1.5F, 82.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.44676873729054F, 12.193954274491375F, 2.8119931825173223F, 0.0F, 0.0F));
        g.addOrReplaceChild("punta_a", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -25.0F, 0.0F, 1.0F, 25.0F, 23.0F), PartPose.offset(-40.0F, -12.0F, -11.5F));
        g.addOrReplaceChild("punta_b", CubeListBuilder.create().texOffs(48, 0).addBox(0.0F, -25.0F, 0.0F, 1.0F, 25.0F, 23.0F), PartPose.offset(39.0F, -12.0F, -11.5F));
        g.addOrReplaceChild("puertas", CubeListBuilder.create().texOffs(130, 48).addBox(-5.0F, -32.0F, -13.5F, 10.0F, 19.0F, 1.0F).texOffs(174, 48).addBox(-4.5F, -32.0F, -14.5F, 1.0F, 19.0F, 1.0F).texOffs(178, 48).addBox(3.5F, -32.0F, -14.5F, 1.0F, 19.0F, 1.0F).texOffs(540, 80).addBox(-3.5F, -23.0F, -15.5F, 7.0F, 1.0F, 1.0F).texOffs(152, 48).addBox(-5.0F, -32.0F, 12.5F, 10.0F, 19.0F, 1.0F).texOffs(182, 48).addBox(-4.5F, -32.0F, 13.5F, 1.0F, 19.0F, 1.0F).texOffs(186, 48).addBox(3.5F, -32.0F, 13.5F, 1.0F, 19.0F, 1.0F).texOffs(556, 80).addBox(-3.5F, -23.0F, 14.5F, 7.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("escotillas", CubeListBuilder.create().texOffs(680, 48).addBox(-36.0F, -37.0F, -9.5F, 4.0F, 2.0F, 5.0F).texOffs(904, 76).addBox(-35.0F, -38.0F, -8.5F, 2.0F, 1.0F, 3.0F).texOffs(698, 48).addBox(-36.0F, -37.0F, 4.5F, 4.0F, 2.0F, 5.0F).texOffs(914, 76).addBox(-35.0F, -38.0F, 5.5F, 2.0F, 1.0F, 3.0F).texOffs(716, 48).addBox(32.0F, -37.0F, -9.5F, 4.0F, 2.0F, 5.0F).texOffs(924, 76).addBox(33.0F, -38.0F, -8.5F, 2.0F, 1.0F, 3.0F).texOffs(734, 48).addBox(32.0F, -37.0F, 4.5F, 4.0F, 2.0F, 5.0F).texOffs(934, 76).addBox(33.0F, -38.0F, 5.5F, 2.0F, 1.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("pasarela", CubeListBuilder.create().texOffs(680, 76).addBox(-41.0F, -37.0F, -1.5F, 82.0F, 1.0F, 3.0F).texOffs(350, 48).addBox(-41.0F, -37.0F, 1.5F, 4.0F, 1.0F, 12.0F).texOffs(382, 48).addBox(-41.0F, -37.0F, -13.5F, 4.0F, 1.0F, 12.0F).texOffs(414, 48).addBox(37.0F, -37.0F, 1.5F, 4.0F, 1.0F, 12.0F).texOffs(446, 48).addBox(37.0F, -37.0F, -13.5F, 4.0F, 1.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("escalerai_0", CubeListBuilder.create().texOffs(1008, 76).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -13.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_0p0", CubeListBuilder.create().texOffs(628, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -13.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_0p1", CubeListBuilder.create().texOffs(632, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -13.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_1", CubeListBuilder.create().texOffs(1012, 76).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -16.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_1p0", CubeListBuilder.create().texOffs(636, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -16.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_1p1", CubeListBuilder.create().texOffs(640, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -16.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_2", CubeListBuilder.create().texOffs(1016, 76).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -19.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_2p0", CubeListBuilder.create().texOffs(644, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -19.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_2p1", CubeListBuilder.create().texOffs(648, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -19.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_3", CubeListBuilder.create().texOffs(1020, 76).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -22.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_3p0", CubeListBuilder.create().texOffs(652, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -22.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_3p1", CubeListBuilder.create().texOffs(656, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -22.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_4", CubeListBuilder.create().texOffs(0, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -25.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_4p0", CubeListBuilder.create().texOffs(660, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -25.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_4p1", CubeListBuilder.create().texOffs(664, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -25.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_5", CubeListBuilder.create().texOffs(4, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -28.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_5p0", CubeListBuilder.create().texOffs(668, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -28.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_5p1", CubeListBuilder.create().texOffs(672, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -28.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_6", CubeListBuilder.create().texOffs(8, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -31.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_6p0", CubeListBuilder.create().texOffs(676, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -31.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_6p1", CubeListBuilder.create().texOffs(680, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -31.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_0", CubeListBuilder.create().texOffs(12, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -13.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_0p0", CubeListBuilder.create().texOffs(684, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -13.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_0p1", CubeListBuilder.create().texOffs(688, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -13.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_1", CubeListBuilder.create().texOffs(16, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -16.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_1p0", CubeListBuilder.create().texOffs(692, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -16.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_1p1", CubeListBuilder.create().texOffs(696, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -16.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_2", CubeListBuilder.create().texOffs(20, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -19.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_2p0", CubeListBuilder.create().texOffs(700, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -19.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_2p1", CubeListBuilder.create().texOffs(704, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -19.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_3", CubeListBuilder.create().texOffs(24, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -22.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_3p0", CubeListBuilder.create().texOffs(708, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -22.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_3p1", CubeListBuilder.create().texOffs(712, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -22.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_4", CubeListBuilder.create().texOffs(28, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -25.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_4p0", CubeListBuilder.create().texOffs(716, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -25.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_4p1", CubeListBuilder.create().texOffs(720, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -25.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_5", CubeListBuilder.create().texOffs(32, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -28.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_5p0", CubeListBuilder.create().texOffs(724, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -28.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_5p1", CubeListBuilder.create().texOffs(728, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -28.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_6", CubeListBuilder.create().texOffs(36, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -31.5F, -13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_6p0", CubeListBuilder.create().texOffs(732, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -31.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fi_6p1", CubeListBuilder.create().texOffs(736, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -31.5F, -12.3F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_0", CubeListBuilder.create().texOffs(40, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -13.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_0p0", CubeListBuilder.create().texOffs(740, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -13.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_0p1", CubeListBuilder.create().texOffs(744, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -13.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_1", CubeListBuilder.create().texOffs(44, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -16.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_1p0", CubeListBuilder.create().texOffs(748, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -16.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_1p1", CubeListBuilder.create().texOffs(752, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -16.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_2", CubeListBuilder.create().texOffs(48, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -19.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_2p0", CubeListBuilder.create().texOffs(756, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -19.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_2p1", CubeListBuilder.create().texOffs(760, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -19.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_3", CubeListBuilder.create().texOffs(52, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -22.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_3p0", CubeListBuilder.create().texOffs(764, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -22.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_3p1", CubeListBuilder.create().texOffs(768, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -22.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_4", CubeListBuilder.create().texOffs(56, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -25.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_4p0", CubeListBuilder.create().texOffs(772, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -25.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_4p1", CubeListBuilder.create().texOffs(776, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -25.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_5", CubeListBuilder.create().texOffs(60, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -28.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_5p0", CubeListBuilder.create().texOffs(780, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -28.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_5p1", CubeListBuilder.create().texOffs(784, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -28.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_6", CubeListBuilder.create().texOffs(64, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(35.5F, -31.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_6p0", CubeListBuilder.create().texOffs(788, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.8F, -31.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalerad_6p1", CubeListBuilder.create().texOffs(792, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.2F, -31.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_0", CubeListBuilder.create().texOffs(68, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -13.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_0p0", CubeListBuilder.create().texOffs(796, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -13.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_0p1", CubeListBuilder.create().texOffs(800, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -13.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_1", CubeListBuilder.create().texOffs(72, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -16.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_1p0", CubeListBuilder.create().texOffs(804, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -16.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_1p1", CubeListBuilder.create().texOffs(808, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -16.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_2", CubeListBuilder.create().texOffs(76, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -19.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_2p0", CubeListBuilder.create().texOffs(812, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -19.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_2p1", CubeListBuilder.create().texOffs(816, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -19.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_3", CubeListBuilder.create().texOffs(80, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -22.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("escalera_fd_3p0", CubeListBuilder.create().texOffs(820, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -22.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_3p1", CubeListBuilder.create().texOffs(824, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -22.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_4", CubeListBuilder.create().texOffs(84, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -25.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_4p0", CubeListBuilder.create().texOffs(828, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -25.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_4p1", CubeListBuilder.create().texOffs(832, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -25.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_5", CubeListBuilder.create().texOffs(88, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -28.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_5p0", CubeListBuilder.create().texOffs(836, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -28.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_5p1", CubeListBuilder.create().texOffs(840, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -28.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_6", CubeListBuilder.create().texOffs(92, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-38.5F, -31.5F, 13.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_6p0", CubeListBuilder.create().texOffs(844, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-38.2F, -31.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escalera_fd_6p1", CubeListBuilder.create().texOffs(848, 80).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.8F, -31.5F, 12.3F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("freno", CubeListBuilder.create().texOffs(346, 48).addBox(40.0F, -31.0F, -0.5F, 1.0F, 15.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("volante", CubeListBuilder.create().texOffs(46, 48).addBox(-10.5F, 0.0F, -10.5F, 21.0F, 1.0F, 21.0F), PartPose.offsetAndRotation(41.2F, -31.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(520, 48).addBox(-38.0F, -11.0F, -2.0F, 76.0F, 3.0F, 4.0F).texOffs(96, 80).addBox(-40.0F, -11.0F, 10.5F, 80.0F, 2.0F, 1.0F).texOffs(258, 80).addBox(-40.0F, -11.0F, -11.5F, 80.0F, 2.0F, 1.0F).texOffs(946, 0).addBox(-40.0F, -11.0F, -10.5F, 2.0F, 3.0F, 21.0F).texOffs(0, 48).addBox(38.0F, -11.0F, -10.5F, 2.0F, 3.0F, 21.0F).texOffs(744, 0).addBox(-39.0F, -12.0F, -11.5F, 78.0F, 1.0F, 23.0F).texOffs(190, 48).addBox(-31.5F, -8.0F, -9.0F, 3.0F, 1.0F, 18.0F).texOffs(232, 48).addBox(28.5F, -8.0F, -9.0F, 3.0F, 1.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("puntai", CubeListBuilder.create().texOffs(752, 48).addBox(-45.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("puntad", CubeListBuilder.create().texOffs(768, 48).addBox(40.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(478, 48).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(850, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(840, 48).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-35.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(868, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-35.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(886, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-35.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(478, 48).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(850, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(850, 48).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-24.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(868, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(886, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(478, 48).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(850, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 48).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-35.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(868, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-35.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(886, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-35.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(478, 48).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(850, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 48).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-24.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(868, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(886, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(880, 48).addBox(-37.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(890, 48).addBox(-26.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(420, 80).addBox(-37.0F, -7.0F, -8.0F, 14.0F, 2.0F, 1.0F).texOffs(572, 80).addBox(-33.0F, -2.0F, -8.0F, 6.0F, 1.0F, 1.0F).texOffs(784, 48).addBox(-32.5F, -5.0F, -8.5F, 5.0F, 3.0F, 2.0F).texOffs(900, 48).addBox(-37.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(910, 48).addBox(-26.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(450, 80).addBox(-37.0F, -7.0F, 7.0F, 14.0F, 2.0F, 1.0F).texOffs(586, 80).addBox(-33.0F, -2.0F, 7.0F, 6.0F, 1.0F, 1.0F).texOffs(798, 48).addBox(-32.5F, -5.0F, 6.5F, 5.0F, 3.0F, 2.0F).texOffs(274, 48).addBox(-32.0F, -7.0F, -7.0F, 4.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_cordonii", CubeListBuilder.create().texOffs(944, 76).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-34.5F, -2.5F, -7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordonid", CubeListBuilder.create().texOffs(952, 76).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-25.5F, -2.5F, -7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordondi", CubeListBuilder.create().texOffs(960, 76).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-34.5F, -2.5F, 7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordondd", CubeListBuilder.create().texOffs(968, 76).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-25.5F, -2.5F, 7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(478, 48).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(850, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(920, 48).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(24.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(868, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(886, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(478, 48).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(850, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(930, 48).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(35.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(868, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(35.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(886, 76).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 48).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(35.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(478, 48).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(850, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(940, 48).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(24.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(868, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(886, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(478, 48).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(850, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(950, 48).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(35.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(868, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(35.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(886, 76).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 48).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(35.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(960, 48).addBox(23.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(970, 48).addBox(34.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(480, 80).addBox(23.0F, -7.0F, -8.0F, 14.0F, 2.0F, 1.0F).texOffs(600, 80).addBox(27.0F, -2.0F, -8.0F, 6.0F, 1.0F, 1.0F).texOffs(812, 48).addBox(27.5F, -5.0F, -8.5F, 5.0F, 3.0F, 2.0F).texOffs(980, 48).addBox(23.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(990, 48).addBox(34.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(510, 80).addBox(23.0F, -7.0F, 7.0F, 14.0F, 2.0F, 1.0F).texOffs(614, 80).addBox(27.0F, -2.0F, 7.0F, 6.0F, 1.0F, 1.0F).texOffs(826, 48).addBox(27.5F, -5.0F, 6.5F, 5.0F, 3.0F, 2.0F).texOffs(310, 48).addBox(28.0F, -7.0F, -7.0F, 4.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_cordonii", CubeListBuilder.create().texOffs(976, 76).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(25.5F, -2.5F, -7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordonid", CubeListBuilder.create().texOffs(984, 76).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(34.5F, -2.5F, -7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordondi", CubeListBuilder.create().texOffs(992, 76).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(25.5F, -2.5F, 7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordondd", CubeListBuilder.create().texOffs(1000, 76).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(34.5F, -2.5F, 7.5F, 0.0F, 0.0F, 0.982793723247329F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "costadoi", 0.5F, 0.5F, 0.5F);
        escalar(g0, "costadod", 0.5F, 0.5F, 0.5F);
        escalar(g0, "techo_0", 1.0002439024390244F, 1.0F, 0.9268979761727865F);
        escalar(g0, "techo_1", 1.0002439024390244F, 1.0F, 0.9268979761727865F);
        escalar(g0, "techo_2", 1.0002439024390244F, 1.0F, 0.9268979761727868F);
        escalar(g0, "techo_3", 1.0002439024390244F, 1.0F, 0.9268979761727866F);
        escalar(g0, "techo_4", 1.0002439024390244F, 1.0F, 0.9268979761727865F);
        escalar(g0, "techo_5", 1.0002439024390244F, 1.0F, 0.9268979761727877F);
        escalar(g0, "techo_6", 1.0002439024390244F, 1.0F, 0.9268979761727864F);
        escalar(g0, "techo_7", 1.0002439024390244F, 1.0F, 0.9268979761727865F);
        escalar(g0, "techo_8", 1.0002439024390244F, 1.0F, 0.9268979761727859F);
        escalar(g0, "techo_9", 1.0002439024390244F, 1.0F, 0.9268979761727865F);
        escalar(g0, "escalerai_0", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_0p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_0p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_1", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_1p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_1p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_2", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_2p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_2p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_3", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_3p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_3p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_4", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_4p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_4p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_5", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_5p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_5p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_6", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_6p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerai_6p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_0", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fi_0p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_0p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_1", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fi_1p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_1p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_2", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fi_2p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_2p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_3", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fi_3p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_3p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_4", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fi_4p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_4p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_5", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fi_5p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_5p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_6", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fi_6p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fi_6p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_0", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_0p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_0p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_1", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_1p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_1p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_2", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_2p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_2p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_3", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_3p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_3p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_4", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_4p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_4p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_5", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_5p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_5p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_6", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_6p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalerad_6p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_0", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fd_0p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_0p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_1", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fd_1p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_1p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_2", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fd_2p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_2p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_3", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fd_3p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_3p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_4", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fd_4p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_4p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_5", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fd_5p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_5p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_6", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalera_fd_6p0", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "escalera_fd_6p1", 0.48F, 0.7999999999999989F, 0.48F);
        escalar(g0, "volante", 0.24761904761904763F, 0.6F, 0.24761904761904763F);
        escalar(g0, "bogie0_cordonii", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordonid", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordondi", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordondd", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordonii", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordonid", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordondi", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordondd", 0.75F, 0.9013878188659973F, 0.75F);
    }
}
