package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "ChME3" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloChME3 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("chme3"), "main"),
            LocomotoraMod.id("textures/entity/chme3.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -59.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -59.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -59.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -33.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -33.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -33.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -59.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -59.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -59.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -33.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -33.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -33.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 35.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 35.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 35.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 48.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 48.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 48.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 61.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 61.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 61.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 35.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 35.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 35.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 48.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 48.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 48.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 61.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 61.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 61.0F, -5.0F, 1.0471975511965976F, "cuerpo")),
            ModeloChME3::crearCapa,
            16.0F,
            ModeloChME3::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -46.0F, 48.0F)));

    private ModeloChME3() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(460, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-59.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-59.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-59.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i2_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-33.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i2_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i2_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-59.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-59.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-59.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(500, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d2_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-33.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d2_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d2_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(76, 90).addBox(-65.5F, -9.0F, 7.0F, 39.0F, 6.0F, 1.0F).texOffs(156, 90).addBox(-65.5F, -9.0F, -8.0F, 39.0F, 6.0F, 1.0F).texOffs(520, 100).addBox(-61.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(530, 100).addBox(-61.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(540, 100).addBox(-48.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(550, 100).addBox(-48.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(560, 100).addBox(-35.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(570, 100).addBox(-35.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(580, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(35.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(35.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(35.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(590, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(48.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(48.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(48.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i2_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(600, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(61.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i2_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(61.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i2_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(61.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(610, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(35.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(35.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(35.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(620, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(48.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(48.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(48.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d2_0", CubeListBuilder.create().texOffs(176, 78).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(84, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(630, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(61.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d2_1", CubeListBuilder.create().texOffs(108, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(61.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d2_2", CubeListBuilder.create().texOffs(132, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 78).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(61.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(236, 90).addBox(28.5F, -9.0F, 7.0F, 39.0F, 6.0F, 1.0F).texOffs(316, 90).addBox(28.5F, -9.0F, -8.0F, 39.0F, 6.0F, 1.0F).texOffs(640, 100).addBox(33.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(650, 100).addBox(33.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(660, 100).addBox(46.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(670, 100).addBox(46.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(680, 100).addBox(59.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(690, 100).addBox(59.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(0, 48).addBox(-80.0F, -15.0F, -13.0F, 160.0F, 4.0F, 26.0F).texOffs(476, 48).addBox(-26.0F, -11.0F, -10.0F, 52.0F, 7.0F, 20.0F).texOffs(396, 90).addBox(-85.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(372, 48).addBox(-80.0F, -11.0F, -12.0F, 2.0F, 5.0F, 24.0F).texOffs(412, 90).addBox(80.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(424, 48).addBox(78.0F, -11.0F, -12.0F, 2.0F, 5.0F, 24.0F).texOffs(428, 117).addBox(-72.0F, -25.0F, 12.2F, 104.0F, 1.0F, 1.0F).texOffs(638, 117).addBox(-72.0F, -25.0F, -13.2F, 104.0F, 1.0F, 1.0F).texOffs(36, 90).addBox(-72.0F, -24.0F, 12.2F, 1.0F, 9.0F, 1.0F).texOffs(40, 90).addBox(-72.0F, -24.0F, -13.2F, 1.0F, 9.0F, 1.0F).texOffs(44, 90).addBox(-46.0F, -24.0F, 12.2F, 1.0F, 9.0F, 1.0F).texOffs(48, 90).addBox(-46.0F, -24.0F, -13.2F, 1.0F, 9.0F, 1.0F).texOffs(52, 90).addBox(-20.0F, -24.0F, 12.2F, 1.0F, 9.0F, 1.0F).texOffs(56, 90).addBox(-20.0F, -24.0F, -13.2F, 1.0F, 9.0F, 1.0F).texOffs(60, 90).addBox(6.0F, -24.0F, 12.2F, 1.0F, 9.0F, 1.0F).texOffs(64, 90).addBox(6.0F, -24.0F, -13.2F, 1.0F, 9.0F, 1.0F).texOffs(68, 90).addBox(31.0F, -24.0F, 12.2F, 1.0F, 9.0F, 1.0F).texOffs(72, 90).addBox(31.0F, -24.0F, -13.2F, 1.0F, 9.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo", CubeListBuilder.create().texOffs(238, 0).addBox(-72.0F, -30.0F, -9.0F, 106.0F, 15.0F, 18.0F).texOffs(676, 48).addBox(-72.0F, -33.0F, -6.0F, 106.0F, 3.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_cantoi_0", CubeListBuilder.create().texOffs(0, 113).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -30.46352549156242F, -8.92658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_1", CubeListBuilder.create().texOffs(214, 113).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -31.34520337000113F, -8.640110266005152F, -2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_2", CubeListBuilder.create().texOffs(428, 113).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -32.09520337000113F, -8.095203370001132F, -2.3561944901923457F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_3", CubeListBuilder.create().texOffs(642, 113).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -32.64011026600515F, -7.345203370001131F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_4", CubeListBuilder.create().texOffs(0, 115).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -32.92658477444273F, -6.463525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_0", CubeListBuilder.create().texOffs(214, 115).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -30.46352549156242F, 8.92658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_1", CubeListBuilder.create().texOffs(428, 115).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -31.34520337000113F, 8.640110266005152F, 2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_2", CubeListBuilder.create().texOffs(642, 115).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -32.09520337000113F, 8.095203370001132F, 2.3561944901923457F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_3", CubeListBuilder.create().texOffs(0, 117).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -32.64011026600515F, 7.345203370001131F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_4", CubeListBuilder.create().texOffs(214, 117).addBox(-53.0F, -1.0F, -0.5F, 106.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -32.92658477444273F, 6.463525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_frente_0", CubeListBuilder.create().texOffs(594, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.51213222837023F, -17.33333313627921F, -8.986366023380004F, -1.5974124349256502F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_1", CubeListBuilder.create().texOffs(620, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.51213222837023F, -21.999999408837635F, -8.986366023380004F, -1.5974124349256502F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_2", CubeListBuilder.create().texOffs(646, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.51213220217431F, -26.666666602202355F, -8.98636602324875F, -1.5974124365425497F, 0.0F, -1.5707963155680773F));
        g.addOrReplaceChild("capo_frente_3", CubeListBuilder.create().texOffs(832, 109).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.40723394814746F, -30.24999989214738F, -8.98700254538373F, -1.6027719512580112F, 0.0005074344542708387F, -1.487073859247592F));
        g.addOrReplaceChild("capo_frente_4", CubeListBuilder.create().texOffs(568, 119).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.11847365478214F, -31.5F, -8.889125063007686F, -3.141592653589793F, -0.7282080187453532F, 0.0F));
        g.addOrReplaceChild("capo_frente_5", CubeListBuilder.create().texOffs(104, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.15446754246179F, -17.33333313627921F, -8.932074301159512F, -1.8734490168422429F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_6", CubeListBuilder.create().texOffs(126, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.15446754246179F, -21.999999408837635F, -8.932074301159512F, -1.8734490168422429F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_7", CubeListBuilder.create().texOffs(148, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.15446747999434F, -26.666666602202355F, -8.932074302279387F, -1.8734490291846546F, 0.0F, -1.5707963000231406F));
        g.addOrReplaceChild("capo_frente_8", CubeListBuilder.create().texOffs(500, 119).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.91188395962027F, -30.24999989214738F, -8.939785916633445F, -1.9133536868528005F, 0.0060562282761940115F, -1.3791121393550223F));
        g.addOrReplaceChild("capo_frente_9", CubeListBuilder.create().texOffs(170, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.37153179229469F, -17.33333313627921F, -8.825169340764068F, -2.222406709633411F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_10", CubeListBuilder.create().texOffs(192, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.37153179229469F, -21.999999408837635F, -8.825169340764068F, -2.222406709633411F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_11", CubeListBuilder.create().texOffs(214, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.37153171479817F, -26.666666602202355F, -8.82516934495333F, -2.2224067248530677F, 0.0F, -1.570796293582113F));
        g.addOrReplaceChild("capo_frente_12", CubeListBuilder.create().texOffs(572, 119).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.7348313737967F, -31.500279015831058F, -8.732181348540653F, -3.1376447695955507F, -0.47393260799227516F, -0.002944366832120402F));
        g.addOrReplaceChild("capo_frente_13", CubeListBuilder.create().texOffs(556, 119).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.32093419169836F, -31.615656740230477F, -8.559126791192364F, -2.3410687746089707F, -0.34846454368983176F, -0.3443479735494793F));
        g.addOrReplaceChild("capo_frente_14", CubeListBuilder.create().texOffs(236, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.54221247981668F, -17.33333313627921F, -8.630976836569946F, -2.5615834140237936F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_15", CubeListBuilder.create().texOffs(258, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.54221247981668F, -21.999999408837635F, -8.630976836569946F, -2.5615834140237936F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_16", CubeListBuilder.create().texOffs(280, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.54221239424814F, -26.666666602202355F, -8.630976842614027F, -2.561583430478472F, 0.0F, -1.5707962901226762F));
        g.addOrReplaceChild("capo_frente_17", CubeListBuilder.create().texOffs(514, 119).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.2192429574948F, -30.24999989214738F, -8.662212991033432F, -2.638478291590579F, 0.02418967199918352F, -1.317950375835063F));
        g.addOrReplaceChild("capo_frente_18", CubeListBuilder.create().texOffs(576, 119).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.8107630122986F, -31.589490078988987F, -8.514038604209016F, -2.460607841840315F, -0.32339214305197644F, -0.3756953722375874F));
        g.addOrReplaceChild("capo_frente_19", CubeListBuilder.create().texOffs(936, 109).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.3492670624056F, -31.938993751554044F, -8.209754501062193F, -2.3718779883636776F, -0.2117025296880067F, -0.3825610451400543F));
        g.addOrReplaceChild("capo_frente_20", CubeListBuilder.create().texOffs(688, 109).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-73.71506702284705F, -17.33333313627921F, -8.20704189429545F, -2.84942237192588F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_21", CubeListBuilder.create().texOffs(712, 109).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-73.71506702284705F, -21.999999408837635F, -8.20704189429545F, -2.84942237192588F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_22", CubeListBuilder.create().texOffs(736, 109).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-73.71506693172526F, -26.666666602202355F, -8.20704189331106F, -2.8494223861738255F, 0.0F, -1.5707962877427095F));
        g.addOrReplaceChild("capo_frente_23", CubeListBuilder.create().texOffs(848, 109).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-73.36944961135507F, -30.24999989214738F, -8.20256127269296F, -2.9183126604122376F, -0.003454855541164629F, -1.3010417307859556F));
        g.addOrReplaceChild("capo_frente_24", CubeListBuilder.create().texOffs(944, 109).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.88889411912166F, -31.840036180901073F, -7.979449768643678F, -2.810487197104586F, -0.12498250365445254F, -0.9317248576489807F));
        g.addOrReplaceChild("capo_frente_25", CubeListBuilder.create().texOffs(896, 109).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.38095243050222F, -32.357583432619975F, -7.601555957144029F, -2.6530267985532707F, -0.18270228486971052F, -0.4756453070403738F));
        g.addOrReplaceChild("capo_frente_26", CubeListBuilder.create().texOffs(672, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.8696263462028F, -17.33333313627921F, -7.335076150689352F, -3.0283039362052557F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_27", CubeListBuilder.create().texOffs(698, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.8696263462028F, -21.999999408837635F, -7.335076150689352F, -3.0283039362052557F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_28", CubeListBuilder.create().texOffs(724, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.86962624935487F, -26.666666602202355F, -7.335076131213346F, -3.0283039440501933F, 0.0F, -1.5707962852886521F));
        g.addOrReplaceChild("capo_frente_29", CubeListBuilder.create().texOffs(576, 109).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.50015741541083F, -30.24999989214738F, -7.25055152781582F, -3.0607800910032226F, -0.06475570657808392F, -1.2834039358462963F));
        g.addOrReplaceChild("capo_frente_30", CubeListBuilder.create().texOffs(672, 109).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.12174367750532F, -31.62740956456412F, -7.122480151574423F, -3.082534326080064F, 0.03460128412156699F, -1.4785113870398057F));
        g.addOrReplaceChild("capo_frente_31", CubeListBuilder.create().texOffs(612, 109).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.96256501413382F, -32.08737058039583F, -7.003507262430335F, -3.037442749655484F, -0.04366939718303403F, -1.1294548830308706F));
        g.addOrReplaceChild("capo_frente_32", CubeListBuilder.create().texOffs(906, 109).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.40616567578586F, -32.664753362546264F, -6.772963106874837F, -2.9345465206518506F, -0.11692754580097109F, -0.49869951887269864F));
        g.addOrReplaceChild("capo_frente_33", CubeListBuilder.create().texOffs(428, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.96115124894641F, -17.33333313627921F, -5.988233245731898F, -3.1078866081544723F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_34", CubeListBuilder.create().texOffs(456, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.96115124894641F, -21.999999408837635F, -5.988233245731898F, -3.1078866081544723F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_35", CubeListBuilder.create().texOffs(484, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.96115114674194F, -26.666666602202355F, -5.98823321241538F, -3.1078866109410224F, 0.0F, -1.5707962829929958F));
        g.addOrReplaceChild("capo_frente_36", CubeListBuilder.create().texOffs(156, 100).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.57159769508475F, -30.24999989214738F, -5.856558802742465F, -3.117941059514547F, -0.0538254737049532F, -1.2675895852069456F));
        g.addOrReplaceChild("capo_frente_37", CubeListBuilder.create().texOffs(700, 100).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.16927533898681F, -31.65479129535545F, -5.717658058871259F, -3.1258605073768706F, 0.0011542729489903078F, -1.4877412047577685F));
        g.addOrReplaceChild("capo_frente_38", CubeListBuilder.create().texOffs(622, 109).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.99657565325641F, -32.180046781939325F, -5.705151692666504F, -3.125797016080734F, -0.004790082960229754F, -1.1631296096843133F));
        g.addOrReplaceChild("capo_frente_39", CubeListBuilder.create().texOffs(632, 109).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.41832248708562F, -32.772935696706035F, -5.625499104055135F, -3.1296222116733157F, -0.07782761086490526F, -0.48774866602539385F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("capo_frente_40", CubeListBuilder.create().texOffs(512, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99297841410504F, -17.33333313627921F, -4.366777293782899F, -3.1347334575709938F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_41", CubeListBuilder.create().texOffs(540, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99297841410504F, -21.999999408837635F, -4.366777293782899F, -3.1347334575709938F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_42", CubeListBuilder.create().texOffs(568, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99297830928643F, -26.666666602202355F, -4.366777262206338F, -3.134733458182392F, 0.0F, -1.5707962818726473F));
        g.addOrReplaceChild("capo_frente_43", CubeListBuilder.create().texOffs(176, 100).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.59497141688472F, -30.24999989214738F, -4.24819650822579F, -3.136802633955278F, -0.04583696840479487F, -1.262327278246441F));
        g.addOrReplaceChild("capo_frente_44", CubeListBuilder.create().texOffs(710, 100).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.18374035622041F, -31.656672295636795F, -4.133453631082199F, -3.13851416150536F, -0.00025961088078447586F, -1.486665119190914F));
        g.addOrReplaceChild("capo_frente_45", CubeListBuilder.create().texOffs(316, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.00839711447207F, -32.18700263857329F, -4.147590952507715F, -3.139140254648519F, -0.0010638385311693063F, -1.1615006376429693F));
        g.addOrReplaceChild("capo_frente_46", CubeListBuilder.create().texOffs(328, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.42313907290247F, -32.78032990543994F, -4.107028553040202F, -3.141061202234074F, -0.05365119358308697F, -0.4788171066626281F));
        g.addOrReplaceChild("capo_frente_47", CubeListBuilder.create().texOffs(596, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.9993964061508F, -17.33333313627921F, -2.648838958407028F, -3.1409198647856162F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_48", CubeListBuilder.create().texOffs(624, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.9993964061508F, -21.999999408837635F, -2.648838958407028F, -3.1409198647856162F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_49", CubeListBuilder.create().texOffs(652, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99939630072478F, -26.666666602202355F, -2.648838936914367F, -3.1409198648479086F, 0.0F, -1.5707962816123344F));
        g.addOrReplaceChild("capo_frente_50", CubeListBuilder.create().texOffs(196, 100).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.59957165410577F, -30.24999989214738F, -2.5677432073957203F, -3.1411264305100115F, -0.030931580665136776F, -1.2612061613341912F));
        g.addOrReplaceChild("capo_frente_51", CubeListBuilder.create().texOffs(720, 100).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.18651150229715F, -31.656672295636795F, -2.4877385559203837F, -3.1412995275895432F, -2.476242282079463e-05F, -1.4865193660368576F));
        g.addOrReplaceChild("capo_frente_52", CubeListBuilder.create().texOffs(340, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.01080991122839F, -32.18700263857329F, -2.4936537619233246F, -3.1413604172678804F, -0.00010097549074815422F, -1.1606574888211463F));
        g.addOrReplaceChild("capo_frente_53", CubeListBuilder.create().texOffs(352, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.42417196538764F, -32.78032990543994F, -2.4726373361662524F, -3.1415422137138815F, -0.027070422074494702F, -0.47784756205669265F));
        g.addOrReplaceChild("capo_frente_54", CubeListBuilder.create().texOffs(680, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99998997453417F, -17.33333313627921F, -0.890823859040322F, -3.1415813974433373F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_55", CubeListBuilder.create().texOffs(708, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99998997453417F, -21.999999408837635F, -0.890823859040322F, -3.1415813974433373F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_56", CubeListBuilder.create().texOffs(736, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99998986904917F, -26.666666602202355F, -0.8908417207098195F, -3.1415813972185886F, 7.654998838579186e-06F, -1.5707962815870533F));
        g.addOrReplaceChild("capo_frente_57", CubeListBuilder.create().texOffs(216, 100).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.5999930535251F, -30.24999989214738F, -0.8603774224891482F, -3.141584924876433F, -0.011611942481797864F, -1.2610955018508707F));
        g.addOrReplaceChild("capo_frente_58", CubeListBuilder.create().texOffs(730, 100).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.1867588349696F, -31.656672295636795F, -0.8300222327244686F, -3.1415879764426906F, -3.951778824915354e-07F, -1.486505300596516F));
        g.addOrReplaceChild("capo_frente_59", CubeListBuilder.create().texOffs(364, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.01102344923332F, -32.18700263857329F, -0.8317645848466857F, -3.141588954712131F, -1.6085861282245686e-06F, -1.1605829411406F));
        g.addOrReplaceChild("capo_frente_60", CubeListBuilder.create().texOffs(376, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.42426278600672F, -32.78032990543994F, -0.8286546571706567F, -3.141591861764452F, -0.0049458871098518415F, -0.47776150052815614F));
        g.addOrReplaceChild("capo_frente_61", CubeListBuilder.create().texOffs(764, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99998997453417F, -17.33333313627921F, 0.8906659017115651F, 3.141581399439232F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_62", CubeListBuilder.create().texOffs(792, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99998997453417F, -21.999999408837635F, 0.8906659017115651F, 3.141581399439232F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_63", CubeListBuilder.create().texOffs(820, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99998986904916F, -26.666666602202355F, 0.8906480243465316F, 3.1415813996660695F, 7.661725494841698e-06F, -1.5707962815870533F));
        g.addOrReplaceChild("capo_frente_64", CubeListBuilder.create().texOffs(236, 100).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.5999930535251F, -30.24999989214738F, 0.8603390488459479F, 3.141584925227647F, 0.011539192596854075F, -1.2610955024176003F));
        g.addOrReplaceChild("capo_frente_65", CubeListBuilder.create().texOffs(740, 100).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.1867588349696F, -31.656672295636795F, 0.8301815918079971F, 3.1415879755447076F, 3.9525375324395333e-07F, -1.4865053007957207F));
        g.addOrReplaceChild("capo_frente_66", CubeListBuilder.create().texOffs(388, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.01102344923332F, -32.18700263857329F, 0.8319109521978991F, 3.1415889540612323F, 1.608869195132512e-06F, -1.160582940964656F));
        g.addOrReplaceChild("capo_frente_67", CubeListBuilder.create().texOffs(400, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.42426278600672F, -32.78032990543994F, 0.8286699157527244F, 3.1415918617494096F, 0.0050625095798764634F, -0.4777615004357226F));
        g.addOrReplaceChild("capo_frente_68", CubeListBuilder.create().texOffs(848, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.9993964061508F, -17.33333313627921F, 2.648838958404033F, 3.1409198647856247F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_69", CubeListBuilder.create().texOffs(876, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.9993964061508F, -21.999999408837635F, 2.648838958404033F, 3.1409198647856247F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_70", CubeListBuilder.create().texOffs(904, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99939630072478F, -26.666666602202355F, 2.6488389369082905F, 3.140919864847921F, 0.0F, -1.570796281612336F));
        g.addOrReplaceChild("capo_frente_71", CubeListBuilder.create().texOffs(256, 100).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.59957165410579F, -30.24999989214738F, 2.567743207391973F, 3.1411264305100195F, 0.030931580663081406F, -1.2612061613341872F));
        g.addOrReplaceChild("capo_frente_72", CubeListBuilder.create().texOffs(750, 100).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.18651150229714F, -31.656672295636795F, 2.4877385559223F, 3.1412995275895432F, 2.4762422820767152e-05F, -1.486519366036858F));
        g.addOrReplaceChild("capo_frente_73", CubeListBuilder.create().texOffs(412, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.01080991122839F, -32.18700263857329F, 2.4936537619252843F, 3.1413604172678804F, 0.00010097549074809983F, -1.1606574888211463F));
        g.addOrReplaceChild("capo_frente_74", CubeListBuilder.create().texOffs(424, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.42417196538764F, -32.78032990543994F, 2.472637336166926F, 3.1415422137138815F, 0.027070422075618515F, -0.47784756205669265F));
        g.addOrReplaceChild("capo_frente_75", CubeListBuilder.create().texOffs(932, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99297841410504F, -17.33333313627921F, 4.366777293781516F, 3.134733457570997F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_76", CubeListBuilder.create().texOffs(960, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99297841410504F, -21.999999408837635F, 4.366777293781516F, 3.134733457570997F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_77", CubeListBuilder.create().texOffs(988, 90).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.99297830928644F, -26.666666602202355F, 4.366777262203092F, 3.1347334581824073F, 0.0F, -1.570796281872652F));
        g.addOrReplaceChild("capo_frente_78", CubeListBuilder.create().texOffs(276, 100).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.59497141688473F, -30.24999989214738F, 4.248196508223604F, 3.1368026339552872F, 0.04583696840368773F, -1.262327278246439F));
        g.addOrReplaceChild("capo_frente_79", CubeListBuilder.create().texOffs(760, 100).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.18374035622041F, -31.656672295636795F, 4.133453631083994F, 3.138514161505356F, 0.00025961088078487637F, -1.4866651191908897F));
        g.addOrReplaceChild("capo_frente_80", CubeListBuilder.create().texOffs(436, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.00839711447207F, -32.18700263857329F, 4.147590952509906F, 3.139140254648514F, 0.0010638385311712807F, -1.1615006376429735F));
        g.addOrReplaceChild("capo_frente_81", CubeListBuilder.create().texOffs(448, 100).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.42313907290247F, -32.78032990543994F, 4.107028553040664F, 3.141061202234074F, 0.05365119358419233F, -0.47881710666262756F));
        g.addOrReplaceChild("capo_frente_82", CubeListBuilder.create().texOffs(0, 100).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.9611512489464F, -17.33333313627921F, 5.988233245732108F, 3.1078866081544607F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_83", CubeListBuilder.create().texOffs(28, 100).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.9611512489464F, -21.999999408837635F, 5.988233245732108F, 3.1078866081544607F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_84", CubeListBuilder.create().texOffs(56, 100).addBox(-5.0F, -1.0F, -2.0F, 10.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.96115114674195F, -26.666666602202355F, 5.988233212414738F, 3.107886610941038F, 0.0F, -1.5707962829930109F));
        g.addOrReplaceChild("capo_frente_85", CubeListBuilder.create().texOffs(296, 100).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.57159769508478F, -30.24999989214738F, 5.85655880274184F, 3.1179410595145685F, 0.053825473704621984F, -1.2675895852069285F));
        g.addOrReplaceChild("capo_frente_86", CubeListBuilder.create().texOffs(770, 100).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.16927533898681F, -31.65479129535546F, 5.717658058871855F, 3.1258605073768635F, -0.0011542729489860625F, -1.4877412047578749F));
        g.addOrReplaceChild("capo_frente_87", CubeListBuilder.create().texOffs(642, 109).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.99657565325641F, -32.180046781939325F, 5.705151692667311F, 3.125797016080726F, 0.004790082960406785F, -1.1631296096843016F));
        g.addOrReplaceChild("capo_frente_88", CubeListBuilder.create().texOffs(652, 109).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.41832248708562F, -32.77293569670604F, 5.625499104055244F, 3.129622211673321F, 0.07782761086547899F, -0.48774866602539063F));
        g.addOrReplaceChild("capo_frente_89", CubeListBuilder.create().texOffs(750, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.8696263462028F, -17.33333313627921F, 7.335076150689409F, 3.0283039362052673F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_90", CubeListBuilder.create().texOffs(776, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.8696263462028F, -21.999999408837635F, 7.335076150689409F, 3.0283039362052673F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_91", CubeListBuilder.create().texOffs(802, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.8696262493549F, -26.666666602202355F, 7.335076131212983F, 3.0283039440502373F, 0.0F, -1.5707962852886628F));
        g.addOrReplaceChild("capo_frente_92", CubeListBuilder.create().texOffs(594, 109).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.50015741541087F, -30.24999989214738F, 7.250551527815688F, 3.0607800910032164F, 0.06475570657758711F, -1.2834039358462728F));
        g.addOrReplaceChild("capo_frente_93", CubeListBuilder.create().texOffs(680, 109).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.12174367750534F, -31.627409564564132F, 7.122480151574468F, 3.082534326080058F, -0.03460128412157869F, -1.4785113870397042F));
        g.addOrReplaceChild("capo_frente_94", CubeListBuilder.create().texOffs(662, 109).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.96256501413384F, -32.08737058039585F, 7.003507262430064F, 3.037442749655517F, 0.04366939718284041F, -1.1294548830308713F));
        g.addOrReplaceChild("capo_frente_95", CubeListBuilder.create().texOffs(916, 109).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.40616567578586F, -32.6647533625463F, 6.772963106874643F, 2.9345465206519052F, 0.11692754580105086F, -0.4986995188727224F));
        g.addOrReplaceChild("capo_frente_96", CubeListBuilder.create().texOffs(760, 109).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-73.71506702284708F, -17.33333313627921F, 8.207041894295312F, 2.849422371925904F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_97", CubeListBuilder.create().texOffs(784, 109).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-73.71506702284708F, -21.999999408837635F, 8.207041894295312F, 2.849422371925904F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_98", CubeListBuilder.create().texOffs(808, 109).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-73.71506693172527F, -26.666666602202355F, 8.20704189331093F, 2.849422386173855F, 0.0F, -1.5707962877427095F));
        g.addOrReplaceChild("capo_frente_99", CubeListBuilder.create().texOffs(864, 109).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-73.3694496113551F, -30.24999989214738F, 8.202561272692783F, 2.918312660412293F, 0.0034548555412086293F, -1.3010417307859559F));
        g.addOrReplaceChild("capo_frente_100", CubeListBuilder.create().texOffs(952, 109).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.88889411912167F, -31.840036180901116F, 7.979449768643552F, 2.810487197104651F, 0.12498250365437288F, -0.9317248576490534F));
        g.addOrReplaceChild("capo_frente_101", CubeListBuilder.create().texOffs(926, 109).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.38095243050222F, -32.35758343262006F, 7.601555957143867F, 2.653026798553328F, 0.18270228486976853F, -0.47564530704041036F));
        g.addOrReplaceChild("capo_frente_102", CubeListBuilder.create().texOffs(302, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.54221247981668F, -17.33333313627921F, 8.630976836569934F, 2.561583414023809F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_103", CubeListBuilder.create().texOffs(324, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.54221247981668F, -21.999999408837635F, 8.630976836569934F, 2.561583414023809F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_104", CubeListBuilder.create().texOffs(346, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.54221239424815F, -26.666666602202355F, 8.630976842614013F, 2.561583430478492F, 0.0F, -1.5707962901226777F));
        g.addOrReplaceChild("capo_frente_105", CubeListBuilder.create().texOffs(528, 119).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.2192429574948F, -30.24999989214738F, 8.662212991033414F, 2.6384782915905873F, -0.02418967199918421F, -1.317950375835063F));
        g.addOrReplaceChild("capo_frente_106", CubeListBuilder.create().texOffs(580, 119).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.81076301229861F, -31.58949007898901F, 8.514038604208974F, 2.460607841840346F, 0.3233921430519485F, -0.3756953722376523F));
        g.addOrReplaceChild("capo_frente_107", CubeListBuilder.create().texOffs(960, 109).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.3492670624056F, -31.93899375155415F, 8.20975450106207F, 2.371877988363733F, 0.21170252968804934F, -0.3825610451401299F));
        g.addOrReplaceChild("capo_frente_108", CubeListBuilder.create().texOffs(368, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.37153179229469F, -17.33333313627921F, 8.825169340764063F, 2.2224067096334306F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_109", CubeListBuilder.create().texOffs(390, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.37153179229469F, -21.999999408837635F, 8.825169340764063F, 2.2224067096334306F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_110", CubeListBuilder.create().texOffs(412, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.37153171479817F, -26.666666602202355F, 8.825169344953329F, 2.222406724853077F, 0.0F, -1.570796293582113F));
        g.addOrReplaceChild("capo_frente_111", CubeListBuilder.create().texOffs(584, 119).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.7348313737967F, -31.500279015831058F, 8.732181348540655F, 3.1376447695955507F, 0.47393260799228093F, -0.0029443668321203933F));
        g.addOrReplaceChild("capo_frente_112", CubeListBuilder.create().texOffs(562, 119).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.32093419169836F, -31.615656740230527F, 8.559126791192318F, 2.341068774608878F, 0.34846454368993246F, -0.34434797354962404F));
        g.addOrReplaceChild("capo_frente_113", CubeListBuilder.create().texOffs(434, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.15446754246179F, -17.33333313627921F, 8.93207430115951F, 1.8734490168422615F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_114", CubeListBuilder.create().texOffs(456, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.15446754246179F, -21.999999408837635F, 8.93207430115951F, 1.8734490168422615F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_115", CubeListBuilder.create().texOffs(478, 119).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.15446747999434F, -26.666666602202355F, 8.932074302279387F, 1.873449029184664F, 0.0F, -1.5707963000231406F));
        g.addOrReplaceChild("capo_frente_116", CubeListBuilder.create().texOffs(542, 119).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.91188395962027F, -30.24999989214738F, 8.939785916633445F, 1.9133536868528005F, -0.0060562282761940115F, -1.3791121393550223F));
        g.addOrReplaceChild("capo_frente_117", CubeListBuilder.create().texOffs(828, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.51213222837023F, -17.33333313627921F, 8.986366023380004F, 1.5974124349256487F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_118", CubeListBuilder.create().texOffs(854, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.51213222837023F, -21.999999408837635F, 8.986366023380004F, 1.5974124349256487F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_119", CubeListBuilder.create().texOffs(880, 105).addBox(-5.0F, -1.0F, -1.5F, 10.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.51213220217431F, -26.666666602202355F, 8.98636602324875F, 1.5974124365425488F, 0.0F, -1.5707963155680773F));
        g.addOrReplaceChild("capo_frente_120", CubeListBuilder.create().texOffs(880, 109).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.40723394814746F, -30.24999989214738F, 8.98700254538373F, 1.6027719512580112F, -0.0005074344542708387F, -1.487073859247592F));
        g.addOrReplaceChild("capo_frente_121", CubeListBuilder.create().texOffs(588, 119).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.11847365478214F, -31.5F, 8.889125063007688F, 3.141592653589793F, 0.7282080187453555F, 0.0F));
        g.addOrReplaceChild("faro_f5_0", CubeListBuilder.create().texOffs(906, 105).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(200, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.2F, -17.5F, -5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_f5_1", CubeListBuilder.create().texOffs(930, 105).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(224, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.2F, -17.5F, -5.5F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_f5_2", CubeListBuilder.create().texOffs(954, 105).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(248, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.2F, -17.5F, -5.5F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_f5_3", CubeListBuilder.create().texOffs(978, 105).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(272, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.2F, -17.5F, -5.5F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_f5_vidrio", CubeListBuilder.create().texOffs(902, 78).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-74.72F, -17.5F, -5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_f15_0", CubeListBuilder.create().texOffs(0, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(296, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.2F, -17.5F, 5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_f15_1", CubeListBuilder.create().texOffs(24, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(320, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.2F, -17.5F, 5.5F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_f15_2", CubeListBuilder.create().texOffs(48, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(344, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.2F, -17.5F, 5.5F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("faro_f15_3", CubeListBuilder.create().texOffs(72, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(368, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.2F, -17.5F, 5.5F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_f15_vidrio", CubeListBuilder.create().texOffs(938, 78).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-74.72F, -17.5F, 5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_0", CubeListBuilder.create().texOffs(96, 109).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(392, 78).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-73.7F, -32.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_1", CubeListBuilder.create().texOffs(120, 109).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(416, 78).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-73.7F, -32.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_2", CubeListBuilder.create().texOffs(144, 109).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(440, 78).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-73.7F, -32.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_3", CubeListBuilder.create().texOffs(168, 109).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(464, 78).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-73.7F, -32.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_alto_vidrio", CubeListBuilder.create().texOffs(132, 78).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-74.32000000000001F, -32.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("ventilador60_0", CubeListBuilder.create().texOffs(192, 109).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(488, 78).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offset(-60.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador60_1", CubeListBuilder.create().texOffs(216, 109).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(512, 78).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-60.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador60_2", CubeListBuilder.create().texOffs(240, 109).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(536, 78).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-60.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador60_3", CubeListBuilder.create().texOffs(264, 109).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(560, 78).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-60.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador48_0", CubeListBuilder.create().texOffs(288, 109).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(584, 78).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offset(-48.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador48_1", CubeListBuilder.create().texOffs(312, 109).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(608, 78).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-48.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador48_2", CubeListBuilder.create().texOffs(336, 109).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(632, 78).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-48.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador48_3", CubeListBuilder.create().texOffs(360, 109).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(656, 78).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-48.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("escape_0", CubeListBuilder.create().texOffs(956, 48).addBox(-13.0F, -37.0F, -3.5F, 26.0F, 5.0F, 7.0F).texOffs(486, 0).addBox(-3.5F, -37.0F, -13.0F, 7.0F, 5.0F, 26.0F), PartPose.offset(-8.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("escape_1", CubeListBuilder.create().texOffs(0, 78).addBox(-13.0F, -37.0F, -3.5F, 26.0F, 5.0F, 7.0F).texOffs(552, 0).addBox(-3.5F, -37.0F, -13.0F, 7.0F, 5.0F, 26.0F), PartPose.offsetAndRotation(-8.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("escape_2", CubeListBuilder.create().texOffs(66, 78).addBox(-13.0F, -37.0F, -3.5F, 26.0F, 5.0F, 7.0F).texOffs(618, 0).addBox(-3.5F, -37.0F, -13.0F, 7.0F, 5.0F, 26.0F), PartPose.offsetAndRotation(-8.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(0, 0).addBox(34.0F, -38.0F, -12.5F, 28.0F, 23.0F, 25.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(780, 100).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -37.68411409847263F, -11.508079849637468F, -2.7476318415606427F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(846, 100).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -38.43673464039303F, -9.497273199963972F, -2.8192610801113998F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(912, 100).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -39.04351583958841F, -7.437759267310266F, -2.8908903186621515F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(0, 105).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -39.50134578562364F, -5.340100381074208F, -2.962519557212905F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(66, 105).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -39.807876472679695F, -3.21505449912609F, -3.0341487957636644F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(132, 105).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -39.961535841429416F, -1.073520035035644F, -3.105778034314415F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(198, 105).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -39.961535841429416F, 1.0735200350356424F, 3.105778034314415F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(264, 105).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -39.807876472679695F, 3.2150544991260874F, 3.0341487957636644F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(330, 105).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -39.50134578562364F, 5.340100381074208F, 2.962519557212905F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(396, 105).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -39.04351583958841F, 7.437759267310264F, 2.890890318662151F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(462, 105).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -38.43673464039303F, 9.49727319996397F, 2.8192610801113998F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(528, 105).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.0F, -37.68411409847263F, 11.508079849637468F, 2.747631841560643F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_chico", CubeListBuilder.create().texOffs(620, 48).addBox(62.0F, -24.0F, -8.0F, 12.0F, 9.0F, 16.0F).texOffs(912, 48).addBox(62.0F, -27.0F, -5.0F, 12.0F, 3.0F, 10.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_chico_cantoi_0", CubeListBuilder.create().texOffs(848, 117).addBox(-6.0F, -1.0F, -0.5F, 12.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(68.0F, -24.46352549156242F, -7.9265847744427305F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_chico_cantoi_1", CubeListBuilder.create().texOffs(874, 117).addBox(-6.0F, -1.0F, -0.5F, 12.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(68.0F, -25.34520337000113F, -7.640110266005152F, -2.042035224833366F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_chico_cantoi_2", CubeListBuilder.create().texOffs(900, 117).addBox(-6.0F, -1.0F, -0.5F, 12.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(68.0F, -26.09520337000113F, -7.095203370001131F, -2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_chico_cantoi_3", CubeListBuilder.create().texOffs(926, 117).addBox(-6.0F, -1.0F, -0.5F, 12.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(68.0F, -26.640110266005152F, -6.345203370001131F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_chico_cantoi_4", CubeListBuilder.create().texOffs(952, 117).addBox(-6.0F, -1.0F, -0.5F, 12.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(68.0F, -26.92658477444273F, -5.463525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_chico_cantod_0", CubeListBuilder.create().texOffs(978, 117).addBox(-6.0F, -1.0F, -0.5F, 12.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(68.0F, -24.46352549156242F, 7.9265847744427305F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_chico_cantod_1", CubeListBuilder.create().texOffs(0, 119).addBox(-6.0F, -1.0F, -0.5F, 12.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(68.0F, -25.34520337000113F, 7.640110266005152F, 2.042035224833366F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_chico_cantod_2", CubeListBuilder.create().texOffs(26, 119).addBox(-6.0F, -1.0F, -0.5F, 12.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(68.0F, -26.09520337000113F, 7.095203370001131F, 2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_chico_cantod_3", CubeListBuilder.create().texOffs(52, 119).addBox(-6.0F, -1.0F, -0.5F, 12.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(68.0F, -26.640110266005152F, 6.345203370001131F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_chico_cantod_4", CubeListBuilder.create().texOffs(78, 119).addBox(-6.0F, -1.0F, -0.5F, 12.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(68.0F, -26.92658477444273F, 5.463525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_chico_tapaa", CubeListBuilder.create().texOffs(106, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 32.0F), PartPose.offset(62.0F, -24.0F, -8.0F));
        g.addOrReplaceChild("capo_chico_tapab", CubeListBuilder.create().texOffs(172, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 32.0F), PartPose.offset(73.0F, -24.0F, -8.0F));
        g.addOrReplaceChild("faro_t5_0", CubeListBuilder.create().texOffs(384, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(680, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.2F, -17.5F, -5.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t5_1", CubeListBuilder.create().texOffs(408, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(704, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.2F, -17.5F, -5.5F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t5_2", CubeListBuilder.create().texOffs(432, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(728, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.2F, -17.5F, -5.5F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t5_3", CubeListBuilder.create().texOffs(456, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(752, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.2F, -17.5F, -5.5F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t5_vidrio", CubeListBuilder.create().texOffs(974, 78).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(74.72F, -17.5F, -5.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t15_0", CubeListBuilder.create().texOffs(480, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(776, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.2F, -17.5F, 5.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t15_1", CubeListBuilder.create().texOffs(504, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(800, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.2F, -17.5F, 5.5F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t15_2", CubeListBuilder.create().texOffs(528, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(824, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.2F, -17.5F, 5.5F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t15_3", CubeListBuilder.create().texOffs(552, 109).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(848, 78).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.2F, -17.5F, 5.5F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t15_vidrio", CubeListBuilder.create().texOffs(0, 90).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(74.72F, -17.5F, 5.5F, 0.0F, 0.0F, -1.5707963267948966F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "capo_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_cantoi_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_cantoi_2", 1.0F, 1.0F, 0.9386067902413863F);
        escalar(g0, "capo_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_cantoi_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "capo_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_cantod_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_cantod_2", 1.0F, 1.0F, 0.9386067902413863F);
        escalar(g0, "capo_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_cantod_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "capo_frente_0", 0.4716666272558423F, 1.0F, 0.35820386520196923F);
        escalar(g0, "capo_frente_1", 0.4716666272558423F, 1.0F, 0.35820386520196923F);
        escalar(g0, "capo_frente_2", 0.47166681141710204F, 1.0F, 0.3582038477468114F);
        escalar(g0, "capo_frente_3", 0.42791373432563135F, 1.0F, 0.4324446607335044F);
        escalar(g0, "capo_frente_4", 0.344951221737904F, 1.0F, 0.48676122871962774F);
        escalar(g0, "capo_frente_5", 0.4716666272558423F, 1.0F, 0.32282191002022964F);
        escalar(g0, "capo_frente_6", 0.4716666272558423F, 1.0F, 0.32282191002022964F);
        escalar(g0, "capo_frente_7", 0.4716668114171022F, 1.0F, 0.32282188996006483F);
        escalar(g0, "capo_frente_8", 0.4329221998070311F, 1.0F, 0.2567621180257549F);
        escalar(g0, "capo_frente_9", 0.4716666272558423F, 1.0F, 0.2684690908285435F);
        escalar(g0, "capo_frente_10", 0.4716666272558423F, 1.0F, 0.2684690908285435F);
        escalar(g0, "capo_frente_11", 0.4716668114171022F, 1.0F, 0.2684690809058989F);
        escalar(g0, "capo_frente_12", 0.26319177680637645F, 1.0F, 0.26345072838982947F);
        escalar(g0, "capo_frente_13", 0.40185885342233385F, 1.0F, 0.4120083076486489F);
        escalar(g0, "capo_frente_14", 0.4716666272558423F, 1.0F, 0.35592176216245464F);
        escalar(g0, "capo_frente_15", 0.4716666272558423F, 1.0F, 0.35592176216245464F);
        escalar(g0, "capo_frente_16", 0.4716668114171024F, 1.0F, 0.35592175846312474F);
        escalar(g0, "capo_frente_17", 0.4388267278655357F, 1.0F, 0.34188344194808207F);
        escalar(g0, "capo_frente_18", 0.39329693867003984F, 1.0F, 0.3719172353851592F);
        escalar(g0, "capo_frente_19", 0.5242045295685721F, 1.0F, 0.3372644289668459F);
        escalar(g0, "capo_frente_20", 0.4716666272558423F, 1.0F, 0.3340885078226418F);
        escalar(g0, "capo_frente_21", 0.4716666272558423F, 1.0F, 0.3340885078226418F);
        escalar(g0, "capo_frente_22", 0.4716668114171024F, 1.0F, 0.3340885140128065F);
        escalar(g0, "capo_frente_23", 0.4408246681522748F, 1.0F, 0.3675907453704549F);
        escalar(g0, "capo_frente_24", 0.3134200197421294F, 1.0F, 0.47517439036307696F);
        escalar(g0, "capo_frente_25", 0.3802913419887611F, 1.0F, 0.4586129332816089F);
        escalar(g0, "capo_frente_26", 0.4716666272558423F, 1.0F, 0.40312806309379706F);
        escalar(g0, "capo_frente_27", 0.4716666272558423F, 1.0F, 0.40312806309379706F);
        escalar(g0, "capo_frente_28", 0.4716668114171024F, 1.0F, 0.40312807032765763F);
        escalar(g0, "capo_frente_29", 0.4439859951196233F, 1.0F, 0.43099197983356685F);
        escalar(g0, "capo_frente_30", 0.3267582905634407F, 1.0F, 0.44389708467647543F);
        escalar(g0, "capo_frente_31", 0.40200102909677404F, 1.0F, 0.3988791413948702F);
        escalar(g0, "capo_frente_32", 0.3521557035137714F, 1.0F, 0.4844220091483923F);
        escalar(g0, "capo_frente_33", 0.4716666272558423F, 1.0F, 0.3981524557689957F);
        escalar(g0, "capo_frente_34", 0.4716666272558423F, 1.0F, 0.3981524557689957F);
        escalar(g0, "capo_frente_35", 0.4716668114171026F, 1.0F, 0.39815245700607443F);
        escalar(g0, "capo_frente_36", 0.44697328097534567F, 1.0F, 0.40010199289094023F);
        escalar(g0, "capo_frente_37", 0.3620668013948117F, 1.0F, 0.3955609136305364F);
        escalar(g0, "capo_frente_38", 0.4290158296818402F, 1.0F, 0.5058049151242991F);
        escalar(g0, "capo_frente_39", 0.5048320345732651F, 1.0F, 0.482971344784364F);
        escalar(g0, "capo_frente_40", 0.4716666272558423F, 1.0F, 0.4378045738079442F);
        escalar(g0, "capo_frente_41", 0.4716666272558423F, 1.0F, 0.4378045738079442F);
        escalar(g0, "capo_frente_42", 0.4716668114171026F, 1.0F, 0.43780457166354014F);
        escalar(g0, "capo_frente_43", 0.4474315314847792F, 1.0F, 0.42921927064679904F);
        escalar(g0, "capo_frente_44", 0.364577578344872F, 1.0F, 0.4215921242497738F);
        escalar(g0, "capo_frente_45", 0.43245961475379674F, 1.0F, 0.4244809870959743F);
        escalar(g0, "capo_frente_46", 0.5045475716252884F, 1.0F, 0.42203976448519137F);
        escalar(g0, "capo_frente_47", 0.4716666272558423F, 1.0F, 0.44617469697706513F);
        escalar(g0, "capo_frente_48", 0.4716666272558423F, 1.0F, 0.44617469697706513F);
        escalar(g0, "capo_frente_49", 0.4716668114171026F, 1.0F, 0.44617469407766625F);
        escalar(g0, "capo_frente_50", 0.4466819827444309F, 1.0F, 0.4360134262020781F);
        escalar(g0, "capo_frente_51", 0.3644744428373246F, 1.0F, 0.42626738359843525F);
        escalar(g0, "capo_frente_52", 0.4324809842255797F, 1.0F, 0.4274891260509999F);
        escalar(g0, "capo_frente_53", 0.5036532152982344F, 1.0F, 0.4201563864264191F);
        escalar(g0, "capo_frente_54", 0.4716666272558423F, 1.0F, 0.4578329508847891F);
        escalar(g0, "capo_frente_55", 0.4716666272558423F, 1.0F, 0.4578329508847891F);
        escalar(g0, "capo_frente_56", 0.47166681144447276F, 1.0F, 0.4578240122030907F);
        escalar(g0, "capo_frente_57", 0.4460473025694042F, 1.0F, 0.44266952444052154F);
        escalar(g0, "capo_frente_58", 0.36446302172622397F, 1.0F, 0.4275907959083238F);
        escalar(g0, "capo_frente_59", 0.4324682788376224F, 1.0F, 0.4284554761020302F);
        escalar(g0, "capo_frente_60", 0.5028070558555959F, 1.0F, 0.426834957877369F);
        escalar(g0, "capo_frente_61", 0.4716666272558423F, 1.0F, 0.4579119295475736F);
        escalar(g0, "capo_frente_62", 0.4716666272558423F, 1.0F, 0.4579119295475736F);
        escalar(g0, "capo_frente_63", 0.47166681144447276F, 1.0F, 0.45792086038150387F);
        escalar(g0, "capo_frente_64", 0.4460473025693634F, 1.0F, 0.4426887112599037F);
        escalar(g0, "capo_frente_65", 0.3644630217262242F, 1.0F, 0.42751111636705613F);
        escalar(g0, "capo_frente_66", 0.43246827883762395F, 1.0F, 0.4283822924271851F);
        escalar(g0, "capo_frente_67", 0.5028070558556066F, 1.0F, 0.42682732858676514F);
        escalar(g0, "capo_frente_68", 0.4716666272558423F, 1.0F, 0.4461746969771565F);
        escalar(g0, "capo_frente_69", 0.4716666272558423F, 1.0F, 0.4461746969771565F);
        escalar(g0, "capo_frente_70", 0.4716668114171026F, 1.0F, 0.4461746940778522F);
        escalar(g0, "capo_frente_71", 0.4466819827443198F, 1.0F, 0.4360134262024192F);
        escalar(g0, "capo_frente_72", 0.3644744428373294F, 1.0F, 0.42626738359889776F);
        escalar(g0, "capo_frente_73", 0.4324809842255748F, 1.0F, 0.42748912605121886F);
        escalar(g0, "capo_frente_74", 0.5036532152982929F, 1.0F, 0.42015638642632636F);
        escalar(g0, "capo_frente_75", 0.4716666272558423F, 1.0F, 0.43780457380865906F);
        escalar(g0, "capo_frente_76", 0.4716666272558423F, 1.0F, 0.43780457380865906F);
        escalar(g0, "capo_frente_77", 0.4716668114171026F, 1.0F, 0.4378045716647693F);
        escalar(g0, "capo_frente_78", 0.44743153148470377F, 1.0F, 0.42921927064723836F);
        escalar(g0, "capo_frente_79", 0.3645775783449415F, 1.0F, 0.4215921242492507F);
        escalar(g0, "capo_frente_80", 0.43245961475378003F, 1.0F, 0.42448098709587073F);
        escalar(g0, "capo_frente_81", 0.504547571625401F, 1.0F, 0.42203976448517827F);
        escalar(g0, "capo_frente_82", 0.4716666272558423F, 1.0F, 0.3981524557690772F);
        escalar(g0, "capo_frente_83", 0.4716666272558423F, 1.0F, 0.3981524557690772F);
        escalar(g0, "capo_frente_84", 0.4716668114171026F, 1.0F, 0.39815245700614776F);
        escalar(g0, "capo_frente_85", 0.4469732809753208F, 1.0F, 0.4001019928912812F);
        escalar(g0, "capo_frente_86", 0.3620668013950173F, 1.0F, 0.39556091363045964F);
        escalar(g0, "capo_frente_87", 0.4290158296818253F, 1.0F, 0.5058049151235141F);
        escalar(g0, "capo_frente_88", 0.5048320345733369F, 1.0F, 0.4829713447841455F);
        escalar(g0, "capo_frente_89", 0.4716666272558423F, 1.0F, 0.403128063093585F);
        escalar(g0, "capo_frente_90", 0.4716666272558423F, 1.0F, 0.403128063093585F);
        escalar(g0, "capo_frente_91", 0.4716668114171024F, 1.0F, 0.403128070327744F);
        escalar(g0, "capo_frente_92", 0.4439859951196041F, 1.0F, 0.4309919798334403F);
        escalar(g0, "capo_frente_93", 0.3267582905635491F, 1.0F, 0.4438970846762102F);
        escalar(g0, "capo_frente_94", 0.40200102909675217F, 1.0F, 0.3988791413949356F);
        escalar(g0, "capo_frente_95", 0.3521557035137963F, 1.0F, 0.4844220091484124F);
        escalar(g0, "capo_frente_96", 0.4716666272558423F, 1.0F, 0.3340885078227652F);
        escalar(g0, "capo_frente_97", 0.4716666272558423F, 1.0F, 0.3340885078227652F);
        escalar(g0, "capo_frente_98", 0.4716668114171024F, 1.0F, 0.3340885140129104F);
        escalar(g0, "capo_frente_99", 0.44082466815227556F, 1.0F, 0.3675907453705993F);
        escalar(g0, "capo_frente_100", 0.3134200197421224F, 1.0F, 0.47517439036311515F);
        escalar(g0, "capo_frente_101", 0.38029134198880205F, 1.0F, 0.45861293328160135F);
        escalar(g0, "capo_frente_102", 0.4716666272558423F, 1.0F, 0.3559217621624621F);
        escalar(g0, "capo_frente_103", 0.4716666272558423F, 1.0F, 0.3559217621624621F);
        escalar(g0, "capo_frente_104", 0.4716668114171024F, 1.0F, 0.3559217584631472F);
        escalar(g0, "capo_frente_105", 0.4388267278655357F, 1.0F, 0.3418834419481151F);
        escalar(g0, "capo_frente_106", 0.3932969386700605F, 1.0F, 0.37191723538525906F);
        escalar(g0, "capo_frente_107", 0.5242045295686472F, 1.0F, 0.3372644289668742F);
        escalar(g0, "capo_frente_108", 0.4716666272558423F, 1.0F, 0.2684690908285467F);
        escalar(g0, "capo_frente_109", 0.4716666272558423F, 1.0F, 0.2684690908285467F);
        escalar(g0, "capo_frente_110", 0.4716668114171022F, 1.0F, 0.2684690809059005F);
        escalar(g0, "capo_frente_111", 0.26319177680637706F, 1.0F, 0.263450728389828F);
        escalar(g0, "capo_frente_112", 0.40185885342237776F, 1.0F, 0.41200830764878676F);
        escalar(g0, "capo_frente_113", 0.4716666272558423F, 1.0F, 0.32282191002023125F);
        escalar(g0, "capo_frente_114", 0.4716666272558423F, 1.0F, 0.32282191002023125F);
        escalar(g0, "capo_frente_115", 0.4716668114171022F, 1.0F, 0.32282188996006567F);
        escalar(g0, "capo_frente_116", 0.4329221998070311F, 1.0F, 0.2567621180257549F);
        escalar(g0, "capo_frente_117", 0.4716666272558423F, 1.0F, 0.35820386520196923F);
        escalar(g0, "capo_frente_118", 0.4716666272558423F, 1.0F, 0.35820386520196923F);
        escalar(g0, "capo_frente_119", 0.47166681141710204F, 1.0F, 0.3582038477468114F);
        escalar(g0, "capo_frente_120", 0.42791373432563135F, 1.0F, 0.4324446607335044F);
        escalar(g0, "capo_frente_121", 0.34495122173790455F, 1.0F, 0.4867612287196276F);
        escalar(g0, "faro_f5_0", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_f5_1", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_f5_2", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_f5_3", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_f5_vidrio", 0.24444444444444446F, 0.15F, 0.24444444444444446F);
        escalar(g0, "faro_f15_0", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_f15_1", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_f15_2", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_f15_3", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_f15_vidrio", 0.24444444444444446F, 0.15F, 0.24444444444444446F);
        escalar(g0, "faro_alto_0", 0.2550041729048399F, 0.6F, 0.2550041729048399F);
        escalar(g0, "faro_alto_1", 0.2550041729048399F, 0.6F, 0.2550041729048399F);
        escalar(g0, "faro_alto_2", 0.2550041729048399F, 0.6F, 0.2550041729048399F);
        escalar(g0, "faro_alto_3", 0.2550041729048399F, 0.6F, 0.2550041729048399F);
        escalar(g0, "faro_alto_vidrio", 0.23636363636363636F, 0.15F, 0.23636363636363636F);
        escalar(g0, "ventilador60_0", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador60_1", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador60_2", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "ventilador60_3", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador48_0", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador48_1", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador48_2", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador48_3", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "escape_0", 0.11888317862019303F, 1.0F, 0.11888317862019303F);
        escalar(g0, "escape_1", 0.11888317862019303F, 1.0F, 0.11888317862019303F);
        escalar(g0, "escape_2", 0.11888317862019303F, 1.0F, 0.11888317862019303F);
        escalar(g0, "cabina_techo_0", 1.0006666666666666F, 1.0F, 0.7228059321784555F);
        escalar(g0, "cabina_techo_1", 1.0006666666666666F, 1.0F, 0.7228059321784555F);
        escalar(g0, "cabina_techo_2", 1.0006666666666666F, 1.0F, 0.7228059321784571F);
        escalar(g0, "cabina_techo_3", 1.0006666666666666F, 1.0F, 0.7228059321784562F);
        escalar(g0, "cabina_techo_4", 1.0006666666666666F, 1.0F, 0.7228059321784558F);
        escalar(g0, "cabina_techo_5", 1.0006666666666666F, 1.0F, 0.7228059321784567F);
        escalar(g0, "cabina_techo_6", 1.0006666666666666F, 1.0F, 0.7228059321784556F);
        escalar(g0, "cabina_techo_7", 1.0006666666666666F, 1.0F, 0.7228059321784562F);
        escalar(g0, "cabina_techo_8", 1.0006666666666666F, 1.0F, 0.7228059321784568F);
        escalar(g0, "cabina_techo_9", 1.0006666666666666F, 1.0F, 0.7228059321784559F);
        escalar(g0, "cabina_techo_10", 1.0006666666666666F, 1.0F, 0.722805932178456F);
        escalar(g0, "cabina_techo_11", 1.0006666666666666F, 1.0F, 0.722805932178456F);
        escalar(g0, "capo_chico_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_chico_cantoi_1", 1.0F, 1.0F, 0.938606790241385F);
        escalar(g0, "capo_chico_cantoi_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "capo_chico_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_chico_cantoi_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "capo_chico_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_chico_cantod_1", 1.0F, 1.0F, 0.938606790241385F);
        escalar(g0, "capo_chico_cantod_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "capo_chico_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_chico_cantod_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "capo_chico_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_chico_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_t5_0", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t5_1", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t5_2", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t5_3", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t5_vidrio", 0.24444444444444446F, 0.15F, 0.24444444444444446F);
        escalar(g0, "faro_t15_0", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t15_1", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t15_2", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t15_3", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t15_vidrio", 0.24444444444444446F, 0.15F, 0.24444444444444446F);
    }
}
