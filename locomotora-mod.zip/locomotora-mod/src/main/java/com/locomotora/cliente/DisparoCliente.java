package com.locomotora.cliente;

import com.locomotora.artillero.DisparoPayload;
import com.locomotora.artillero.TrenArtillero;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * En el tren artillero, el que maneja una torreta (el maquinista o el tirador de un vagón) dispara con clic izquierdo:
 * el clic no pega ni rompe bloques, se le avisa al servidor. Es un tiro por clic: con el botón apretado mirando un
 * bloque, el juego repite el clic en cada tick, y esos se ignoran.
 */
public final class DisparoCliente {
    /** El tick (del mundo) del último clic que llegó, apretado o repetido. */
    private static long ultimoClic = Long.MIN_VALUE / 2L;

    private DisparoCliente() {
    }

    public static void alClic(InputEvent.InteractionKeyMappingTriggered evento) {
        if (!evento.isAttack()) {
            return;
        }
        LocalPlayer jugador = Minecraft.getInstance().player;
        if (jugador == null || !TrenArtillero.manejaTorreta(jugador)) {
            return;
        }
        evento.setCanceled(true);
        evento.setSwingHand(false);
        long ahora = jugador.level().getGameTime();
        boolean repetido = Math.abs(ahora - ultimoClic) <= 1L;
        ultimoClic = ahora;
        if (!repetido) {
            PacketDistributor.sendToServer(DisparoPayload.FUEGO);
        }
    }
}
