package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Plymouth" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloPlymouth {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("plymouth"), "main"),
            LocomotoraMod.id("textures/entity/plymouth.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -8.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -8.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -8.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 8.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 8.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 8.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 1.5707963267948966F, 0.0F, -8.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 4.0F, 1.6F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 4.0F, 1.6F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 0.72F, -24.5F, 0.0F, "cuerpo", 4.8F, 5.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.15F, 0.0F, 1.0F, -23.0F, 0.15F, "cuerpo", -0.24F, 7.5F, 0.0F)),
            ModeloPlymouth::crearCapa,
            16.0F,
            ModeloPlymouth::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -8.0F, 8.0F)));

    private ModeloPlymouth() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(640, 48).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(958, 65).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(78, 65).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(40, 71).addBox(-1.0F, -2.6F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-8.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(978, 65).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(998, 65).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(640, 48).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(958, 65).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(88, 65).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(46, 71).addBox(-1.0F, -2.6F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(8.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(978, 65).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(998, 65).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(640, 48).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(958, 65).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(98, 65).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(52, 71).addBox(-1.0F, -2.6F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-8.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(978, 65).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(998, 65).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(640, 48).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(958, 65).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(108, 65).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(58, 71).addBox(-1.0F, -2.6F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(8.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(978, 65).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(998, 65).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(448, 71).addBox(-8.0F, -6.1F, -7.5F, 16.0F, 1.0F, 1.0F).texOffs(0, 71).addBox(-9.5F, -7.1F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(8, 71).addBox(6.5F, -7.1F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(482, 71).addBox(-8.0F, -6.1F, 6.5F, 16.0F, 1.0F, 1.0F).texOffs(16, 71).addBox(-9.5F, -7.1F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(24, 71).addBox(6.5F, -7.1F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(720, 48).addBox(-22.0F, -10.0F, 2.0F, 44.0F, 7.0F, 1.0F).texOffs(810, 48).addBox(-22.0F, -10.0F, -3.0F, 44.0F, 7.0F, 1.0F).texOffs(604, 0).addBox(-22.0F, -12.0F, -10.0F, 44.0F, 2.0F, 20.0F).texOffs(118, 65).addBox(-10.0F, -6.0F, 3.0F, 4.0F, 4.0F, 1.0F).texOffs(128, 65).addBox(-10.0F, -6.0F, -4.0F, 4.0F, 4.0F, 1.0F).texOffs(138, 65).addBox(6.0F, -6.0F, 3.0F, 4.0F, 4.0F, 1.0F).texOffs(148, 65).addBox(6.0F, -6.0F, -4.0F, 4.0F, 4.0F, 1.0F).texOffs(516, 0).addBox(-24.0F, -12.0F, -10.0F, 2.0F, 7.0F, 20.0F).texOffs(34, 65).addBox(-29.0F, -10.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(900, 48).addBox(-27.0F, -5.0F, -10.0F, 3.0F, 1.0F, 7.0F).texOffs(920, 48).addBox(-27.0F, -5.0F, 3.0F, 3.0F, 1.0F, 7.0F).texOffs(560, 0).addBox(22.0F, -12.0F, -10.0F, 2.0F, 7.0F, 20.0F).texOffs(50, 65).addBox(24.0F, -10.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(940, 48).addBox(24.0F, -5.0F, -10.0F, 3.0F, 1.0F, 7.0F).texOffs(960, 48).addBox(24.0F, -5.0F, 3.0F, 3.0F, 1.0F, 7.0F).texOffs(450, 0).addBox(-21.0F, -24.0F, -7.5F, 18.0F, 12.0F, 15.0F).texOffs(50, 48).addBox(-21.0F, -26.0F, -5.5F, 18.0F, 2.0F, 11.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_cantoi_0", CubeListBuilder.create().texOffs(68, 71).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -24.309016994374943F, -7.451056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_1", CubeListBuilder.create().texOffs(106, 71).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -24.89680224666742F, -7.2600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_2", CubeListBuilder.create().texOffs(144, 71).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.39680224666742F, -6.89680224666742F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_3", CubeListBuilder.create().texOffs(182, 71).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.7600735106701F, -6.39680224666742F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_4", CubeListBuilder.create().texOffs(220, 71).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.951056516295154F, -5.8090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_0", CubeListBuilder.create().texOffs(258, 71).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -24.309016994374943F, 7.451056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_1", CubeListBuilder.create().texOffs(296, 71).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -24.89680224666742F, 7.2600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_2", CubeListBuilder.create().texOffs(334, 71).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.39680224666742F, 6.89680224666742F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_3", CubeListBuilder.create().texOffs(372, 71).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.7600735106701F, 6.39680224666742F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_4", CubeListBuilder.create().texOffs(410, 71).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.951056516295154F, 5.8090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_tapaa", CubeListBuilder.create().texOffs(326, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 30.0F), PartPose.offset(-21.0F, -24.0F, -7.5F));
        g.addOrReplaceChild("capo_tapab", CubeListBuilder.create().texOffs(388, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 30.0F), PartPose.offset(-4.0F, -24.0F, -7.5F));
        g.addOrReplaceChild("faro_0", CubeListBuilder.create().texOffs(766, 65).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(272, 48).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-21.0F, -27.6F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_1", CubeListBuilder.create().texOffs(790, 65).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(296, 48).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-21.0F, -27.6F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_2", CubeListBuilder.create().texOffs(814, 65).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(320, 48).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-21.0F, -27.6F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_3", CubeListBuilder.create().texOffs(838, 65).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(344, 48).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-21.0F, -27.6F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_vidrio", CubeListBuilder.create().texOffs(108, 48).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-21.82F, -27.6F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_base", CubeListBuilder.create().texOffs(66, 65).addBox(-21.0F, -28.0F, -1.5F, 3.0F, 2.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("escape_0", CubeListBuilder.create().texOffs(572, 48).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 5.0F, 5.0F).texOffs(968, 0).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 5.0F, 12.0F), PartPose.offset(-12.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("escape_1", CubeListBuilder.create().texOffs(606, 48).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 5.0F, 5.0F).texOffs(0, 48).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(-12.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("tapa_radiador_0", CubeListBuilder.create().texOffs(980, 48).addBox(-6.0F, -27.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(204, 48).addBox(-2.5F, -27.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offset(-19.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("tapa_radiador_1", CubeListBuilder.create().texOffs(0, 65).addBox(-6.0F, -27.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(238, 48).addBox(-2.5F, -27.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-19.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(172, 0).addBox(-3.0F, -33.0F, -10.5F, 18.0F, 21.0F, 21.0F).texOffs(34, 48).addBox(-3.0F, -28.0F, 10.5F, 1.0F, 14.0F, 1.0F).texOffs(38, 48).addBox(-3.0F, -28.0F, -11.5F, 1.0F, 14.0F, 1.0F).texOffs(42, 48).addBox(14.0F, -28.0F, 10.5F, 1.0F, 14.0F, 1.0F).texOffs(46, 48).addBox(14.0F, -28.0F, -11.5F, 1.0F, 14.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_arcom3", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 42.0F), PartPose.offset(-3.0F, -33.0F, -10.5F));
        g.addOrReplaceChild("cabina_arco14", CubeListBuilder.create().texOffs(86, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 42.0F), PartPose.offset(14.0F, -33.0F, -10.5F));
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(166, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -32.701928852138636F, -10.648519528596236F, -2.545670939203859F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(216, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -33.761356463982025F, -8.888108196677578F, -2.6540203418194825F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(266, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -34.62420499815417F, -7.023456130108373F, -2.762369744435106F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(316, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -35.280354869800334F, -5.076432178477955F, -2.870719147050732F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(366, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -35.722110679275545F, -3.0698712581272405F, -2.9790685496663585F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(416, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -35.9442914646589F, -1.0273065416763163F, -3.087417952281979F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(466, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -35.9442914646589F, 1.027306541676315F, 3.087417952281979F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(516, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -35.722110679275545F, 3.0698712581272387F, 2.9790685496663585F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(566, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -35.280354869800334F, 5.076432178477955F, 2.870719147050732F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(616, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -34.62420499815417F, 7.0234561301083716F, 2.7623697444351087F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(666, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -33.76135646398203F, 8.888108196677575F, 2.6540203418194825F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(716, 65).addBox(-11.0F, -1.0F, -1.5F, 22.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.0F, -32.70192885213864F, 10.648519528596232F, 2.5456709392038572F, 0.0F, 0.0F));
        g.addOrReplaceChild("faro_t_0", CubeListBuilder.create().texOffs(862, 65).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(368, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(15.05F, -31.5F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_1", CubeListBuilder.create().texOffs(886, 65).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(392, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(15.05F, -31.5F, 0.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_2", CubeListBuilder.create().texOffs(910, 65).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(416, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(15.05F, -31.5F, 0.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_3", CubeListBuilder.create().texOffs(934, 65).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(440, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(15.05F, -31.5F, 0.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_vidrio", CubeListBuilder.create().texOffs(464, 48).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(15.67F, -31.5F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_forro", CubeListBuilder.create().texOffs(876, 0).addBox(-2.0F, -32.0F, 9.0F, 16.0F, 19.0F, 1.0F).texOffs(910, 0).addBox(-2.0F, -32.0F, -10.0F, 16.0F, 19.0F, 1.0F).texOffs(250, 0).addBox(13.0F, -32.0F, -9.0F, 1.0F, 19.0F, 18.0F).texOffs(732, 0).addBox(-2.0F, -13.0F, -10.0F, 16.0F, 1.0F, 20.0F).texOffs(804, 0).addBox(-2.0F, -33.0F, -10.0F, 16.0F, 1.0F, 20.0F).texOffs(288, 0).addBox(-2.0F, -32.0F, -9.0F, 1.0F, 19.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_pupitre", CubeListBuilder.create().texOffs(944, 0).addBox(-1.0F, -23.0F, 1.0F, 4.0F, 10.0F, 8.0F).texOffs(660, 48).addBox(-1.0F, -26.0F, 1.5F, 1.0F, 3.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(156, 48).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(0.6F, -24.5F, 5.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(64, 71).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(0.72F, -24.5F, 5.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro0", CubeListBuilder.create().texOffs(500, 48).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(0.6F, -24.5F, 1.4000000000000004F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro0_aguja", CubeListBuilder.create().texOffs(516, 71).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.72F, -24.5F, 1.4000000000000004F, 0.4F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro1", CubeListBuilder.create().texOffs(536, 48).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(0.6F, -24.5F, 8.6F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro1_aguja", CubeListBuilder.create().texOffs(520, 71).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.72F, -24.5F, 8.6F, 1.1F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_luces", CubeListBuilder.create().texOffs(524, 71).addBox(1.0F, -24.0F, 1.5F, 1.0F, 1.0F, 1.0F).texOffs(528, 71).addBox(1.0F, -24.0F, 2.7F, 1.0F, 1.0F, 1.0F).texOffs(532, 71).addBox(1.0F, -24.0F, 3.9000000000000004F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(158, 65).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F).texOffs(32, 71).addBox(-1.0F, -6.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(1.0F, -23.0F, 7.5F, 0.0F, 0.0F, 0.15F));
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(162, 65).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(1.0F, -23.5F, 2.5F, 0.0F, 0.0F, -2.4668517113662407F));
        g.addOrReplaceChild("cab_freno_perilla", CubeListBuilder.create().texOffs(536, 71).addBox(2.5F, -26.5F, 2.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(676, 48).addBox(11.0F, -19.0F, 4.0F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(686, 48).addBox(11.0F, -19.0F, -8.0F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "capo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_0", 0.2746198785129045F, 0.7F, 0.2746198785129045F);
        escalar(g0, "faro_1", 0.2746198785129045F, 0.7F, 0.2746198785129045F);
        escalar(g0, "faro_2", 0.2746198785129045F, 0.7F, 0.2746198785129045F);
        escalar(g0, "faro_3", 0.2746198785129045F, 0.7F, 0.2746198785129045F);
        escalar(g0, "faro_vidrio", 0.2333333333333333F, 0.15F, 0.2333333333333333F);
        escalar(g0, "escape_0", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "escape_1", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "tapa_radiador_0", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "tapa_radiador_1", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "cabina_arcom3", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_arco14", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_techo_0", 1.000909090909091F, 1.0F, 0.6925439383189964F);
        escalar(g0, "cabina_techo_1", 1.000909090909091F, 1.0F, 0.6925439383189976F);
        escalar(g0, "cabina_techo_2", 1.000909090909091F, 1.0F, 0.6925439383189985F);
        escalar(g0, "cabina_techo_3", 1.000909090909091F, 1.0F, 0.6925439383189974F);
        escalar(g0, "cabina_techo_4", 1.000909090909091F, 1.0F, 0.6925439383189973F);
        escalar(g0, "cabina_techo_5", 1.000909090909091F, 1.0F, 0.6925439383189979F);
        escalar(g0, "cabina_techo_6", 1.000909090909091F, 1.0F, 0.6925439383189972F);
        escalar(g0, "cabina_techo_7", 1.000909090909091F, 1.0F, 0.6925439383189977F);
        escalar(g0, "cabina_techo_8", 1.000909090909091F, 1.0F, 0.6925439383189977F);
        escalar(g0, "cabina_techo_9", 1.000909090909091F, 1.0F, 0.6925439383189969F);
        escalar(g0, "cabina_techo_10", 1.000909090909091F, 1.0F, 0.6925439383189974F);
        escalar(g0, "cabina_techo_11", 1.000909090909091F, 1.0F, 0.6925439383189987F);
        escalar(g0, "faro_t_0", 0.2157727616887107F, 0.6F, 0.2157727616887107F);
        escalar(g0, "faro_t_1", 0.2157727616887107F, 0.6F, 0.2157727616887107F);
        escalar(g0, "faro_t_2", 0.2157727616887107F, 0.6F, 0.2157727616887107F);
        escalar(g0, "faro_t_3", 0.2157727616887107F, 0.6F, 0.2157727616887107F);
        escalar(g0, "faro_t_vidrio", 0.24444444444444446F, 0.15F, 0.24444444444444446F);
        escalar(g0, "cab_velocimetro", 0.2333333333333333F, 0.6F, 0.2333333333333333F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.574F, 0.6F);
        escalar(g0, "cab_manometro0", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro0_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_manometro1", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro1_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_freno", 0.8F, 0.8003905296791061F, 0.8F);
    }
}
