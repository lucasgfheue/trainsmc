package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Vagón cañón" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonCanon {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_canon"), "main"),
            LocomotoraMod.id("textures/entity/vagon_canon.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -41.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -41.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -41.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -30.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -30.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -30.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -41.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -41.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -41.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -30.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -30.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -30.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 30.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 30.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 30.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 41.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 41.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 41.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 30.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 30.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 30.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 41.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 41.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 41.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("torreta", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, -29.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon", DatosModelo.CANON, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, -34.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 1.5707963267948966F)),
            ModeloVagonCanon::crearCapa,
            16.0F,
            ModeloVagonCanon::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -36.0F, 36.0F)));

    private ModeloVagonCanon() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(472, 97).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(784, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(624, 97).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-41.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(802, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(498, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(820, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(472, 97).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(784, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(634, 97).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-30.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(802, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(498, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-30.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(820, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-30.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(472, 97).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(784, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(644, 97).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-41.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(802, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(498, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(820, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(472, 97).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(784, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(654, 97).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-30.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(802, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(498, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-30.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(820, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-30.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(664, 97).addBox(-43.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(674, 97).addBox(-32.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(914, 97).addBox(-43.0F, -7.0F, -8.0F, 14.0F, 2.0F, 1.0F).texOffs(414, 108).addBox(-39.0F, -2.0F, -8.0F, 6.0F, 1.0F, 1.0F).texOffs(568, 97).addBox(-38.5F, -5.0F, -8.5F, 5.0F, 3.0F, 2.0F).texOffs(684, 97).addBox(-43.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(694, 97).addBox(-32.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(944, 97).addBox(-43.0F, -7.0F, 7.0F, 14.0F, 2.0F, 1.0F).texOffs(428, 108).addBox(-39.0F, -2.0F, 7.0F, 6.0F, 1.0F, 1.0F).texOffs(582, 97).addBox(-38.5F, -5.0F, 6.5F, 5.0F, 3.0F, 2.0F).texOffs(272, 73).addBox(-38.0F, -7.0F, -7.0F, 4.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_cordonii", CubeListBuilder.create().texOffs(838, 97).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -2.5F, -7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordonid", CubeListBuilder.create().texOffs(846, 97).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-31.5F, -2.5F, -7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordondi", CubeListBuilder.create().texOffs(854, 97).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -2.5F, 7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordondd", CubeListBuilder.create().texOffs(862, 97).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-31.5F, -2.5F, 7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(472, 97).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(784, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 97).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(30.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(802, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(498, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(820, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(472, 97).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(784, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 97).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(41.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(802, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(498, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(41.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(820, 97).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 97).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(41.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(472, 97).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(784, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(724, 97).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(30.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(802, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(498, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(820, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(472, 97).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(784, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(734, 97).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(41.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(802, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(498, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(41.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(820, 97).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 97).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(41.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(744, 97).addBox(29.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(754, 97).addBox(40.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(974, 97).addBox(29.0F, -7.0F, -8.0F, 14.0F, 2.0F, 1.0F).texOffs(442, 108).addBox(33.0F, -2.0F, -8.0F, 6.0F, 1.0F, 1.0F).texOffs(596, 97).addBox(33.5F, -5.0F, -8.5F, 5.0F, 3.0F, 2.0F).texOffs(764, 97).addBox(29.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(774, 97).addBox(40.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(0, 108).addBox(29.0F, -7.0F, 7.0F, 14.0F, 2.0F, 1.0F).texOffs(456, 108).addBox(33.0F, -2.0F, 7.0F, 6.0F, 1.0F, 1.0F).texOffs(610, 97).addBox(33.5F, -5.0F, 6.5F, 5.0F, 3.0F, 2.0F).texOffs(308, 73).addBox(34.0F, -7.0F, -7.0F, 4.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_cordonii", CubeListBuilder.create().texOffs(870, 97).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(31.5F, -2.5F, -7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordonid", CubeListBuilder.create().texOffs(878, 97).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(40.5F, -2.5F, -7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordondi", CubeListBuilder.create().texOffs(886, 97).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(31.5F, -2.5F, 7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordondd", CubeListBuilder.create().texOffs(894, 97).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(40.5F, -2.5F, 7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(304, 40).addBox(-52.0F, -14.0F, -11.0F, 104.0F, 5.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("faldones", CubeListBuilder.create().texOffs(0, 97).addBox(-48.0F, -14.0F, 12.0F, 96.0F, 10.0F, 1.0F).texOffs(194, 97).addBox(-48.0F, -14.0F, -13.0F, 96.0F, 10.0F, 1.0F).texOffs(42, 108).addBox(-46.0F, -4.0F, 11.0F, 92.0F, 1.0F, 1.0F).texOffs(228, 108).addBox(-46.0F, -4.0F, -12.0F, 92.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("casco", CubeListBuilder.create().texOffs(0, 0).addBox(-42.0F, -28.0F, -13.0F, 84.0F, 14.0F, 26.0F).texOffs(556, 40).addBox(-42.0F, -29.0F, -13.0F, 84.0F, 1.0F, 26.0F), PartPose.ZERO);
        g.addOrReplaceChild("frente_0", CubeListBuilder.create().texOffs(776, 40).addBox(-11.0F, -1.0F, -13.0F, 22.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(-46.5F, -19.5F, 0.0F, 3.141592653589793F, 0.0F, -1.1284221038181517F));
        g.addOrReplaceChild("frente_mejillai", CubeListBuilder.create().texOffs(84, 73).addBox(0.0F, -19.0F, -0.5F, 9.0F, 19.0F, 1.0F), PartPose.offset(-51.0F, -10.0F, -12.4F));
        g.addOrReplaceChild("frente_mejillad", CubeListBuilder.create().texOffs(104, 73).addBox(0.0F, -19.0F, -0.5F, 9.0F, 19.0F, 1.0F), PartPose.offset(-51.0F, -10.0F, 12.4F));
        g.addOrReplaceChild("cola_0", CubeListBuilder.create().texOffs(872, 40).addBox(-11.0F, -1.0F, -13.0F, 22.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(46.5F, -19.5F, 0.0F, 0.0F, 0.0F, -2.0131705497716417F));
        g.addOrReplaceChild("cola_mejillai", CubeListBuilder.create().texOffs(124, 73).addBox(0.0F, -19.0F, -0.5F, 9.0F, 19.0F, 1.0F), PartPose.offset(42.0F, -10.0F, -12.4F));
        g.addOrReplaceChild("cola_mejillad", CubeListBuilder.create().texOffs(144, 73).addBox(0.0F, -19.0F, -0.5F, 9.0F, 19.0F, 1.0F), PartPose.offset(42.0F, -10.0F, 12.4F));
        g.addOrReplaceChild("escotillas", CubeListBuilder.create().texOffs(408, 97).addBox(-34.0F, -30.0F, -4.0F, 8.0F, 1.0F, 8.0F).texOffs(30, 108).addBox(-28.0F, -31.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(440, 97).addBox(26.0F, -30.0F, -4.0F, 8.0F, 1.0F, 8.0F).texOffs(36, 108).addBox(32.0F, -31.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(140, 40).addBox(-54.0F, -14.0F, -12.0F, 2.0F, 7.0F, 24.0F).texOffs(902, 97).addBox(-56.0F, -12.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(192, 40).addBox(52.0F, -14.0F, -12.0F, 2.0F, 7.0F, 24.0F).texOffs(908, 97).addBox(54.0F, -12.0F, -0.5F, 2.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topefi_0", CubeListBuilder.create().texOffs(916, 0).addBox(-57.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(220, 0).addBox(-57.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefi_1", CubeListBuilder.create().texOffs(936, 0).addBox(-57.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(278, 0).addBox(-57.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefi_2", CubeListBuilder.create().texOffs(956, 0).addBox(-57.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(336, 0).addBox(-57.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_0", CubeListBuilder.create().texOffs(780, 73).addBox(-58.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(412, 73).addBox(-58.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefic_1", CubeListBuilder.create().texOffs(786, 73).addBox(-58.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(434, 73).addBox(-58.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_2", CubeListBuilder.create().texOffs(792, 73).addBox(-58.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(456, 73).addBox(-58.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_3", CubeListBuilder.create().texOffs(798, 73).addBox(-58.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(478, 73).addBox(-58.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_0", CubeListBuilder.create().texOffs(976, 0).addBox(-57.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(394, 0).addBox(-57.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefd_1", CubeListBuilder.create().texOffs(996, 0).addBox(-57.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(452, 0).addBox(-57.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_2", CubeListBuilder.create().texOffs(0, 40).addBox(-57.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(510, 0).addBox(-57.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_0", CubeListBuilder.create().texOffs(804, 73).addBox(-58.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(500, 73).addBox(-58.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefdc_1", CubeListBuilder.create().texOffs(810, 73).addBox(-58.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(522, 73).addBox(-58.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_2", CubeListBuilder.create().texOffs(816, 73).addBox(-58.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(544, 73).addBox(-58.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_3", CubeListBuilder.create().texOffs(822, 73).addBox(-58.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(566, 73).addBox(-58.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_0", CubeListBuilder.create().texOffs(20, 40).addBox(54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(568, 0).addBox(54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topeti_1", CubeListBuilder.create().texOffs(40, 40).addBox(54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(626, 0).addBox(54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_2", CubeListBuilder.create().texOffs(60, 40).addBox(54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(684, 0).addBox(54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_0", CubeListBuilder.create().texOffs(828, 73).addBox(57.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(588, 73).addBox(57.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topetic_1", CubeListBuilder.create().texOffs(834, 73).addBox(57.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(610, 73).addBox(57.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_2", CubeListBuilder.create().texOffs(840, 73).addBox(57.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(632, 73).addBox(57.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_3", CubeListBuilder.create().texOffs(846, 73).addBox(57.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(654, 73).addBox(57.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_0", CubeListBuilder.create().texOffs(80, 40).addBox(54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(742, 0).addBox(54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetd_1", CubeListBuilder.create().texOffs(100, 40).addBox(54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(800, 0).addBox(54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_2", CubeListBuilder.create().texOffs(120, 40).addBox(54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(858, 0).addBox(54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_0", CubeListBuilder.create().texOffs(852, 73).addBox(57.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(676, 73).addBox(57.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetdc_1", CubeListBuilder.create().texOffs(858, 73).addBox(57.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(698, 73).addBox(57.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_2", CubeListBuilder.create().texOffs(864, 73).addBox(57.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(720, 73).addBox(57.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_3", CubeListBuilder.create().texOffs(870, 73).addBox(57.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(742, 73).addBox(57.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("torreta", CubeListBuilder.create().texOffs(344, 73).addBox(-10.0F, -1.0F, -7.0F, 20.0F, 1.0F, 14.0F).texOffs(0, 73).addBox(-12.0F, -7.0F, -9.0F, 24.0F, 6.0F, 18.0F).texOffs(198, 73).addBox(-10.0F, -9.0F, -8.0F, 21.0F, 2.0F, 16.0F).texOffs(764, 73).addBox(-14.0F, -8.0F, -3.0F, 2.0F, 6.0F, 6.0F).texOffs(164, 73).addBox(12.0F, -7.0F, -7.0F, 3.0F, 5.0F, 14.0F).texOffs(514, 97).addBox(-1.0F, -11.0F, -3.0F, 6.0F, 2.0F, 6.0F).texOffs(552, 97).addBox(0.0F, -12.0F, -2.0F, 4.0F, 1.0F, 4.0F).texOffs(470, 108).addBox(-9.0F, -10.0F, -6.5F, 1.0F, 1.0F, 1.0F).texOffs(474, 108).addBox(-9.0F, -10.0F, 5.5F, 1.0F, 1.0F, 1.0F), PartPose.offset(0.0F, -29.0F, 0.0F));
        g.addOrReplaceChild("torreta_canon", CubeListBuilder.create().texOffs(388, 97).addBox(-2.5F, -2.5F, -16.0F, 5.0F, 5.0F, 5.0F).texOffs(244, 40).addBox(-1.5F, -1.5F, -43.0F, 3.0F, 3.0F, 27.0F).texOffs(538, 97).addBox(-2.5F, -2.5F, -45.0F, 5.0F, 5.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -34.5F, 0.0F, 0.0F, 1.5707963267948966F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "bogie0_cordonii", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordonid", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordondi", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordondd", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordonii", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordonid", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordondi", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordondd", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "frente_0", 0.9556270928013018F, 1.0F, 1.0F);
        escalar(g0, "cola_0", 0.9556270928013018F, 1.0F, 1.0F);
        escalar(g0, "topefi_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topeti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
    }
}
