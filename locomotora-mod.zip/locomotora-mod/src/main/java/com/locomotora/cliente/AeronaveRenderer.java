package com.locomotora.cliente;

import java.util.List;

import org.jetbrains.annotations.Nullable;

import com.locomotora.aereo.AeronaveEntity;
import com.locomotora.aereo.TipoAeronave;
import com.locomotora.cliente.modelos.DatosModelo;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Dibuja un globo o un zeppelin. El modelo (del estudio de diseño, frente hacia -X) se gira hacia el rumbo:
 * <ul>
 *   <li>Globo: gira despacito sobre sí mismo (el bombardero no: mira hacia donde va) y se mece un poco, con la canasta
 *       colgando de la envoltura. Derribado, se va de costado.</li>
 *   <li>Zeppelin: se inclina un poco en las vueltas y las hélices giran. Derribado, cae de nariz y se va de costado.</li>
 * </ul>
 * Lo que brilla de noche (la llama del quemador, los ojos y faroles del globo bombardero, las ventanas y el reflector
 * del zeppelin bombardero) está en {@code <nombre>_luces.png} y se dibuja encima sin sombra. Cuando le pegan, se pone
 * rojo un momento.
 */
public class AeronaveRenderer extends EntityRenderer<AeronaveEntity> {
    private static final double DOS_PI = Math.PI * 2.0;
    /** Luz de bloque y de cielo al máximo (LightTexture.FULL_BRIGHT). */
    private static final int BRILLO_TOTAL = 0xF000F0;
    /** Lo rojo de cuando le pegan (como a los mobs). */
    private static final int ROJO = OverlayTexture.pack(0, 3);
    /** Vueltas de las hélices (radianes por tick). */
    private static final float HELICE = 0.9F;

    private final DatosModelo datos;
    private final ModelPart raiz;
    private final ModelPart[] helices;
    private final float[] fases;
    private final float[] giros;
    @Nullable
    private final ResourceLocation texturaLuces;

    public AeronaveRenderer(EntityRendererProvider.Context contexto, DatosModelo datos) {
        super(contexto);
        this.datos = datos;
        this.shadowRadius = 0.0F;
        this.raiz = contexto.bakeLayer(datos.capa());
        datos.preparar().accept(this.raiz);
        // las hélices (piezas que giran a lo largo de X)
        List<DatosModelo.Animada> animadas = datos.animadas();
        this.helices = new ModelPart[animadas.size()];
        this.fases = new float[animadas.size()];
        this.giros = new float[animadas.size()];
        for (int i = 0; i < animadas.size(); i++) {
            DatosModelo.Animada a = animadas.get(i);
            this.helices[i] = a.grupo().isEmpty()
                    ? this.raiz.getChild(a.parte())
                    : this.raiz.getChild(a.grupo()).getChild(a.parte());
            this.fases[i] = a.fase();
            this.giros[i] = a.rotX();
        }
        ResourceLocation t = datos.textura();
        ResourceLocation luces = ResourceLocation.fromNamespaceAndPath(t.getNamespace(),
                t.getPath().replace(".png", "_luces.png"));
        this.texturaLuces = contexto.getResourceManager().getResource(luces).isPresent() ? luces : null;
    }

    @Override
    public void render(AeronaveEntity aeronave, float yawEntidad, float tickParcial, PoseStack pose,
                       MultiBufferSource buffers, int luz) {
        super.render(aeronave, yawEntidad, tickParcial, pose, buffers, luz);
        TipoAeronave tipo = aeronave.getTipo();
        float tiempo = aeronave.tickCount + tickParcial;
        float rumbo = Mth.rotLerp(tickParcial, aeronave.yRotO, aeronave.getYRot());
        float cabeceo = Mth.lerp(tickParcial, aeronave.xRotO, aeronave.getXRot());
        boolean cayendo = aeronave.cayendo();
        // hacia qué lado se va cuando cae (uno u otro, según la aeronave)
        float lado = (aeronave.getId() & 1) == 0 ? 1.0F : -1.0F;
        float caida = cayendo ? Math.min(1.0F, (aeronave.ticksCayendo() + tickParcial) / 40.0F) : 0.0F;

        pose.pushPose();
        if (tipo.globo()) {
            // el normal gira solo, despacio; el bombardero mira hacia donde va
            float giro = tipo.hostil() ? rumbo : aeronave.getId() * 47.0F + tiempo * 0.25F;
            pose.mulPose(Axis.YP.rotationDegrees(-(giro + 90.0F)));
            // se mece colgado de la envoltura (y derribado se va de costado)
            float pivote = tipo.pivoteGlobo();
            pose.translate(0.0F, pivote, 0.0F);
            pose.mulPose(Axis.ZP.rotationDegrees(Mth.sin(tiempo * 0.05F + aeronave.getId()) * 1.6F
                    + lado * cabeceo * 0.8F));
            pose.mulPose(Axis.XP.rotationDegrees(Mth.cos(tiempo * 0.043F + aeronave.getId() * 0.7F) * 1.2F
                    + cabeceo * 0.5F));
            pose.translate(0.0F, -pivote, 0.0F);
        } else {
            pose.translate(0.0F, tipo.ejeY(), 0.0F);
            pose.mulPose(Axis.YP.rotationDegrees(-(rumbo + 90.0F)));
            // nariz abajo si cae; en las vueltas se inclina un poco hacia adentro, y derribado se va de costado
            pose.mulPose(Axis.ZP.rotationDegrees(-cabeceo));
            float viraje = Mth.wrapDegrees(aeronave.getYRot() - aeronave.yRotO);
            pose.mulPose(Axis.XP.rotationDegrees(Mth.clamp(viraje * 5.0F, -10.0F, 10.0F) + lado * caida * 24.0F));
        }
        pose.scale(-1.0F, -1.0F, 1.0F);
        animarHelices(tiempo, cayendo);
        int overlay = aeronave.golpeada() ? ROJO : OverlayTexture.NO_OVERLAY;
        this.raiz.render(pose, buffers.getBuffer(RenderType.entityCutout(this.datos.textura())), luz, overlay);
        if (this.texturaLuces != null) {
            this.raiz.render(pose, buffers.getBuffer(RenderType.entityTranslucentEmissive(this.texturaLuces)),
                    BRILLO_TOTAL, OverlayTexture.NO_OVERLAY);
        }
        pose.popPose();
    }

    /** Las hélices giran (derribado, se van frenando hasta quedar casi quietas). */
    private void animarHelices(float tiempo, boolean cayendo) {
        float velocidad = cayendo ? 0.12F : HELICE;
        for (int i = 0; i < this.helices.length; i++) {
            float vueltas = (float) ((tiempo * velocidad) % DOS_PI);
            this.helices[i].xRot = this.giros[i] - vueltas + this.fases[i];
        }
    }

    @Override
    public ResourceLocation getTextureLocation(AeronaveEntity aeronave) {
        return this.datos.textura();
    }
}
