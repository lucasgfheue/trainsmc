package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Coche mirador" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloCocheMirador {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("coche_mirador"), "main"),
            LocomotoraMod.id("textures/entity/coche_mirador.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 60.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 60.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 60.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 60.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 60.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 60.0F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloCocheMirador::crearCapa,
            16.0F,
            ModeloCocheMirador::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -58.0F, 52.0F)));

    private ModeloCocheMirador() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("caja", CubeListBuilder.create().texOffs(354, 51).addBox(-78.0F, -30.0F, 11.5F, 118.0F, 20.0F, 1.0F).texOffs(592, 51).addBox(-78.0F, -30.0F, -12.5F, 118.0F, 20.0F, 1.0F).texOffs(0, 51).addBox(-77.0F, -11.0F, -11.5F, 154.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("techo_0", CubeListBuilder.create().texOffs(656, 131).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -31.12720911311785F, -11.843999872406503F, -2.09785180323858F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_1", CubeListBuilder.create().texOffs(0, 137).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -33.23764708056636F, -10.331146448086997F, -2.2876228669387997F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_2", CubeListBuilder.create().texOffs(242, 137).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -35.02482159231407F, -8.447352095594452F, -2.4773939306390225F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_3", CubeListBuilder.create().texOffs(484, 137).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -36.42456395464183F, -6.260254654457326F, -2.66716499433924F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_4", CubeListBuilder.create().texOffs(726, 137).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -37.38661626696775F, -3.848382094334835F, -2.856936058039463F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_5", CubeListBuilder.create().texOffs(0, 141).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -37.876435937191474F, -1.2983329597914657F, -3.046707121739683F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_6", CubeListBuilder.create().texOffs(242, 141).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -37.876435937191474F, 1.298332959791464F, 3.0467071217396824F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_7", CubeListBuilder.create().texOffs(484, 141).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -37.38661626696775F, 3.8483820943348324F, 2.856936058039463F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_8", CubeListBuilder.create().texOffs(726, 141).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -36.42456395464183F, 6.260254654457325F, 2.6671649943392404F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_9", CubeListBuilder.create().texOffs(0, 145).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -35.02482159231407F, 8.447352095594452F, 2.477393930639022F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_10", CubeListBuilder.create().texOffs(242, 145).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -33.23764708056636F, 10.331146448086997F, 2.2876228669388F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_11", CubeListBuilder.create().texOffs(484, 145).addBox(-59.0F, -1.0F, -1.5F, 118.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.0F, -31.12720911311785F, 11.843999872406503F, 2.09785180323858F, 0.0F, 0.0F));
        g.addOrReplaceChild("punta", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -28.0F, 0.0F, 1.0F, 28.0F, 23.0F), PartPose.offset(-78.0F, -10.0F, -11.5F));
        g.addOrReplaceChild("cola_ladoi", CubeListBuilder.create().texOffs(48, 0).addBox(0.0F, -40.0F, -0.5F, 76.0F, 40.0F, 1.0F), PartPose.offset(40.0F, -10.0F, -12.0F));
        g.addOrReplaceChild("cola_ladod", CubeListBuilder.create().texOffs(202, 0).addBox(0.0F, -40.0F, -0.5F, 76.0F, 40.0F, 1.0F), PartPose.offset(40.0F, -10.0F, 12.0F));
        g.addOrReplaceChild("cola0_0", CubeListBuilder.create().texOffs(924, 145).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(41.266666666666666F, -30.40492101578619F, -12.287036414306677F, -2.0379426319920033F, 0.0F, 0.014140941870483346F));
        g.addOrReplaceChild("cola0_1", CubeListBuilder.create().texOffs(788, 124).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(41.266666666666666F, -31.771897149202005F, -11.44969518795942F, -2.154857755312506F, -0.0035841978769443252F, 0.010160336951445664F));
        g.addOrReplaceChild("cola0_2", CubeListBuilder.create().texOffs(974, 116).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(41.266666666666666F, -33.740158823266974F, -9.832076156068663F, -2.3412327799264965F, -0.00441289567157262F, 0.013111733911811774F));
        g.addOrReplaceChild("cola0_3", CubeListBuilder.create().texOffs(28, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.266666666666666F, -35.61852744206632F, -7.544417382415921F, -2.558033755099395F, -0.0045156237902625905F, 0.016658096408941867F));
        g.addOrReplaceChild("cola0_4", CubeListBuilder.create().texOffs(54, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.266666666666666F, -37.0301263367344F, -4.742619031890755F, -2.787834846733195F, -0.00343348416802725F, 0.01986022179056367F));
        g.addOrReplaceChild("cola0_5", CubeListBuilder.create().texOffs(80, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.266666666666666F, -37.77944350058621F, -1.6176190318907553F, -3.0231564693346713F, -0.0012860597041733548F, 0.021765293971228058F));
        g.addOrReplaceChild("cola0_6", CubeListBuilder.create().texOffs(106, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.266666666666666F, -37.77944350058621F, 1.6176190318907533F, 3.023156469334672F, 0.0012860597041733548F, 0.021765293971226674F));
        g.addOrReplaceChild("cola0_7", CubeListBuilder.create().texOffs(132, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.266666666666666F, -37.0301263367344F, 4.742619031890753F, 2.7878348467331944F, 0.003433484168026936F, 0.019860221790562335F));
        g.addOrReplaceChild("cola0_8", CubeListBuilder.create().texOffs(158, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.266666666666666F, -35.61852744206632F, 7.54441738241592F, 2.558033755099395F, 0.0045156237902625905F, 0.016658096408941867F));
        g.addOrReplaceChild("cola0_9", CubeListBuilder.create().texOffs(998, 116).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(41.266666666666666F, -33.740158823266974F, 9.832076156068663F, 2.3412327799264974F, 0.0044128956715725415F, 0.013111733911811814F));
        g.addOrReplaceChild("cola0_10", CubeListBuilder.create().texOffs(810, 124).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(41.266666666666666F, -31.771897149202008F, 11.449695187959417F, 2.1548577553125057F, 0.0035841978769444037F, 0.010160336951445586F));
        g.addOrReplaceChild("cola0_11", CubeListBuilder.create().texOffs(940, 145).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(41.266666666666666F, -30.40492101578619F, 12.287036414306677F, 2.0379426319920033F, 0.0F, 0.014140941870483346F));
        g.addOrReplaceChild("cola1_0", CubeListBuilder.create().texOffs(956, 145).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(43.8F, -30.33307589619742F, -12.287036414306677F, -2.0404319648479223F, 0.0F, 0.04255224509739537F));
        g.addOrReplaceChild("cola1_1", CubeListBuilder.create().texOffs(832, 124).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(43.8F, -31.692725573630042F, -11.44969518795942F, -2.157705268494175F, -0.010812588781864915F, 0.030629847040181707F));
        g.addOrReplaceChild("cola1_2", CubeListBuilder.create().texOffs(0, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(43.8F, -33.65043813702224F, -9.832076156068663F, -2.344466192465159F, -0.013282497091033485F, 0.03952507860786385F));
        g.addOrReplaceChild("cola1_3", CubeListBuilder.create().texOffs(184, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(43.8F, -35.518739436671375F, -7.544417382415921F, -2.5611608786845936F, -0.013553904528112472F, 0.05018113689823275F));
        g.addOrReplaceChild("cola1_4", CubeListBuilder.create().texOffs(210, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(43.8F, -36.92277271485582F, -4.742619031890755F, -2.7901415400950373F, -0.010279654312789306F, 0.05976670659401493F));
        g.addOrReplaceChild("cola1_5", CubeListBuilder.create().texOffs(236, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(43.8F, -37.66807383257178F, -1.6176190318907553F, -3.0240100188867216F, -0.003844548576395125F, 0.06545185027409232F));
        g.addOrReplaceChild("cola1_6", CubeListBuilder.create().texOffs(262, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(43.8F, -37.66807383257178F, 1.6176190318907533F, 3.0240100188867234F, 0.0038445485763950464F, 0.06545185027409234F));
        g.addOrReplaceChild("cola1_7", CubeListBuilder.create().texOffs(288, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(43.8F, -36.922772714855824F, 4.742619031890753F, 2.7901415400950356F, 0.010279654312789384F, 0.0597667065940149F));
        g.addOrReplaceChild("cola1_8", CubeListBuilder.create().texOffs(314, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(43.8F, -35.518739436671375F, 7.54441738241592F, 2.5611608786845936F, 0.013553904528112472F, 0.05018113689823275F));
        g.addOrReplaceChild("cola1_9", CubeListBuilder.create().texOffs(24, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(43.8F, -33.65043813702225F, 9.832076156068663F, 2.34446619246516F, 0.013282497091033485F, 0.03952507860786388F));
        g.addOrReplaceChild("cola1_10", CubeListBuilder.create().texOffs(854, 124).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(43.8F, -31.69272557363005F, 11.449695187959417F, 2.1577052684941744F, 0.010812588781864953F, 0.030629847040181627F));
        g.addOrReplaceChild("cola1_11", CubeListBuilder.create().texOffs(972, 145).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(43.8F, -30.33307589619742F, 12.287036414306677F, 2.0404319648479223F, 0.0F, 0.04255224509739537F));
        g.addOrReplaceChild("cola2_0", CubeListBuilder.create().texOffs(988, 145).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(46.33333333333333F, -30.18860170182772F, -12.287036414306677F, -2.0455103433661357F, 0.0F, 0.07135925668399962F));
        g.addOrReplaceChild("cola2_1", CubeListBuilder.create().texOffs(876, 124).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(46.33333333333333F, -31.53351852291862F, -11.44969518795942F, -2.163504713820138F, -0.01822368005278625F, 0.051556939015254946F));
        g.addOrReplaceChild("cola2_2", CubeListBuilder.create().texOffs(48, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(46.33333333333333F, -33.47001775582313F, -9.832076156068663F, -2.351030540749366F, -0.022283562503566803F, 0.06652029848469904F));
        g.addOrReplaceChild("cola2_3", CubeListBuilder.create().texOffs(340, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(46.33333333333333F, -35.318074565212996F, -7.544417382415921F, -2.567481878687235F, -0.02261107624527799F, 0.08433528040270351F));
        g.addOrReplaceChild("cola2_4", CubeListBuilder.create().texOffs(366, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(46.33333333333333F, -36.706894056397864F, -4.742619031890755F, -2.7947838529645836F, -0.01706160282967056F, 0.10023961417487987F));
        g.addOrReplaceChild("cola2_5", CubeListBuilder.create().texOffs(392, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(46.33333333333333F, -37.444119259794945F, -1.6176190318907553F, -3.0257230395887063F, -0.006361667600142109F, 0.1096140579828376F));
        g.addOrReplaceChild("cola2_6", CubeListBuilder.create().texOffs(418, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(46.33333333333333F, -37.444119259794945F, 1.6176190318907533F, 3.0257230395887085F, 0.00636166760014203F, 0.1096140579828376F));
        g.addOrReplaceChild("cola2_7", CubeListBuilder.create().texOffs(444, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(46.33333333333333F, -36.706894056397864F, 4.742619031890753F, 2.794783852964582F, 0.017061602829670636F, 0.10023961417487982F));
        g.addOrReplaceChild("cola2_8", CubeListBuilder.create().texOffs(470, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(46.33333333333333F, -35.318074565212996F, 7.54441738241592F, 2.567481878687235F, 0.02261107624527799F, 0.08433528040270351F));
        g.addOrReplaceChild("cola2_9", CubeListBuilder.create().texOffs(72, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(46.33333333333333F, -33.470017755823136F, 9.832076156068663F, 2.3510305407493663F, 0.02228356250356676F, 0.0665202984846991F));
        g.addOrReplaceChild("cola2_10", CubeListBuilder.create().texOffs(898, 124).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(46.33333333333333F, -31.533518522918627F, 11.449695187959417F, 2.1635047138201378F, 0.01822368005278621F, 0.05155693901525487F));
        g.addOrReplaceChild("cola2_11", CubeListBuilder.create().texOffs(1004, 145).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(46.33333333333333F, -30.18860170182773F, 12.287036414306677F, 2.0455103433661357F, 0.0F, 0.07135925668399962F));
        g.addOrReplaceChild("cola3_0", CubeListBuilder.create().texOffs(0, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(48.86666666666667F, -29.969879230480746F, -12.287036414306677F, -2.0533878479756877F, 0.0F, 0.10085168771744801F));
        g.addOrReplaceChild("cola3_1", CubeListBuilder.create().texOffs(920, 124).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(48.86666666666667F, -31.292491675602477F, -11.44969518795942F, -2.1724751053346747F, -0.025948456588675724F, 0.07328537012267934F));
        g.addOrReplaceChild("cola3_2", CubeListBuilder.create().texOffs(96, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(48.86666666666667F, -33.196875608677765F, -9.832076156068663F, -2.361128400197087F, -0.03150351237633306F, 0.09452777430081523F));
        g.addOrReplaceChild("cola3_3", CubeListBuilder.create().texOffs(496, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(48.86666666666667F, -35.01428386550095F, -7.544417382415921F, -2.577133758902576F, -0.03169195680521799F, 0.11957766551747483F));
        g.addOrReplaceChild("cola3_4", CubeListBuilder.create().texOffs(522, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(48.86666666666667F, -36.380070889845555F, -4.742619031890755F, -2.8018207180812147F, -0.02373023430472883F, 0.1416852449217302F));
        g.addOrReplaceChild("cola3_5", CubeListBuilder.create().texOffs(548, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(48.86666666666667F, -37.105069799502644F, -1.6176190318907553F, -3.028307668658485F, -0.008808193134205227F, 0.1545958623307161F));
        g.addOrReplaceChild("cola3_6", CubeListBuilder.create().texOffs(574, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(48.86666666666667F, -37.105069799502644F, 1.6176190318907533F, 3.0283076686584858F, 0.008808193134205227F, 0.15459586233071745F));
        g.addOrReplaceChild("cola3_7", CubeListBuilder.create().texOffs(600, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(48.86666666666667F, -36.38007088984556F, 4.742619031890753F, 2.801820718081214F, 0.023730234304729064F, 0.14168524492173143F));
        g.addOrReplaceChild("cola3_8", CubeListBuilder.create().texOffs(626, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(48.86666666666667F, -35.01428386550095F, 7.54441738241592F, 2.5771337589025762F, 0.03169195680521799F, 0.1195776655174748F));
        g.addOrReplaceChild("cola3_9", CubeListBuilder.create().texOffs(120, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(48.86666666666667F, -33.196875608677765F, 9.832076156068663F, 2.361128400197087F, 0.031503512376333455F, 0.09452777430081638F));
        g.addOrReplaceChild("cola3_10", CubeListBuilder.create().texOffs(942, 124).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(48.86666666666667F, -31.29249167560248F, 11.449695187959417F, 2.172475105334675F, 0.02594845658867604F, 0.0732853701226802F));
        g.addOrReplaceChild("cola3_11", CubeListBuilder.create().texOffs(16, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(48.86666666666667F, -29.969879230480743F, 12.287036414306677F, 2.0533878479756877F, 0.0F, 0.10085168771744801F));
        g.addOrReplaceChild("cola4_0", CubeListBuilder.create().texOffs(32, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(51.4F, -29.674343082845837F, -12.287036414306677F, -2.0644084462806043F, 0.0F, 0.13136215584701516F));
        g.addOrReplaceChild("cola4_1", CubeListBuilder.create().texOffs(964, 124).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(51.4F, -30.966818023994005F, -11.44969518795942F, -2.184972312788087F, -0.034132108036682283F, 0.09622372318926901F));
        g.addOrReplaceChild("cola4_2", CubeListBuilder.create().texOffs(144, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(51.4F, -32.82780800704112F, -9.832076156068663F, -2.3750835274854745F, -0.041028118877055125F, 0.12404773720927939F));
        g.addOrReplaceChild("cola4_3", CubeListBuilder.create().texOffs(652, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(51.4F, -34.603804171634565F, -7.544417382415921F, -2.590331109404706F, -0.04078815324521979F, 0.15642451981572447F));
        g.addOrReplaceChild("cola4_4", CubeListBuilder.create().texOffs(678, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(51.4F, -35.93846990113195F, -4.742619031890755F, -2.8113433548307114F, -0.030226326579047634F, 0.18455676423467482F));
        g.addOrReplaceChild("cola4_5", CubeListBuilder.create().texOffs(704, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(51.4F, -36.64694873523614F, -1.6176190318907553F, -3.0317828875491277F, -0.011152251067167938F, 0.20078531909589403F));
        g.addOrReplaceChild("cola4_6", CubeListBuilder.create().texOffs(730, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(51.4F, -36.64694873523614F, 1.6176190318907533F, 3.0317828875491277F, 0.011152251067167938F, 0.20078531909589403F));
        g.addOrReplaceChild("cola4_7", CubeListBuilder.create().texOffs(756, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(51.4F, -35.93846990113195F, 4.742619031890753F, 2.811343354830712F, 0.030226326579047554F, 0.18455676423467485F));
        g.addOrReplaceChild("cola4_8", CubeListBuilder.create().texOffs(782, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(51.4F, -34.603804171634565F, 7.54441738241592F, 2.5903311094047066F, 0.04078815324521971F, 0.15642451981572453F));
        g.addOrReplaceChild("cola4_9", CubeListBuilder.create().texOffs(168, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(51.4F, -32.82780800704112F, 9.832076156068663F, 2.375083527485474F, 0.04102811887705501F, 0.12404773720927877F));
        g.addOrReplaceChild("cola4_10", CubeListBuilder.create().texOffs(986, 124).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(51.4F, -30.966818023994005F, 11.449695187959417F, 2.184972312788088F, 0.034132108036682124F, 0.09622372318926863F));
        g.addOrReplaceChild("cola4_11", CubeListBuilder.create().texOffs(48, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(51.4F, -29.674343082845837F, 12.287036414306677F, 2.0644084462806043F, 0.0F, 0.13136215584701516F));
        g.addOrReplaceChild("cola5_0", CubeListBuilder.create().texOffs(64, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(53.93333333333334F, -29.29829170833369F, -12.287036414306677F, -2.07909156020483F, 0.0F, 0.16329263992948756F));
        g.addOrReplaceChild("cola5_1", CubeListBuilder.create().texOffs(0, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(53.93333333333334F, -30.552418549310964F, -11.44969518795942F, -2.2015278107228324F, -0.0429403522268538F, 0.12088690147929161F));
        g.addOrReplaceChild("cola5_2", CubeListBuilder.create().texOffs(192, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(53.93333333333334F, -32.35819242873016F, -9.832076156068663F, -2.393367969915525F, -0.05093763040914934F, 0.15569204336385695F));
        g.addOrReplaceChild("cola5_3", CubeListBuilder.create().texOffs(808, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(53.93333333333334F, -34.08149428053294F, -7.544417382415921F, -2.6073780179808557F, -0.049869306458898144F, 0.195484859278312F));
        g.addOrReplaceChild("cola5_4", CubeListBuilder.create().texOffs(834, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(53.93333333333334F, -35.37656009713456F, -4.742619031890755F, -2.8234790197524773F, -0.03647492098207149F, 0.22938168132465378F));
        g.addOrReplaceChild("cola5_5", CubeListBuilder.create().texOffs(860, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(53.93333333333334F, -36.06401816214356F, -1.6176190318907553F, -3.0361755771463455F, -0.01335784204392404F, 0.24864098766373482F));
        g.addOrReplaceChild("cola5_6", CubeListBuilder.create().texOffs(886, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(53.93333333333334F, -36.06401816214356F, 1.6176190318907533F, 3.0361755771463463F, 0.013357842043923962F, 0.2486409876637335F));
        g.addOrReplaceChild("cola5_7", CubeListBuilder.create().texOffs(912, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(53.93333333333334F, -35.37656009713456F, 4.742619031890753F, 2.8234790197524764F, 0.036474920982071335F, 0.22938168132465242F));
        g.addOrReplaceChild("cola5_8", CubeListBuilder.create().texOffs(938, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(53.93333333333334F, -34.08149428053294F, 7.54441738241592F, 2.607378017980856F, 0.049869306458898144F, 0.195484859278312F));
        g.addOrReplaceChild("cola5_9", CubeListBuilder.create().texOffs(216, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(53.93333333333334F, -32.35819242873016F, 9.832076156068663F, 2.393367969915525F, 0.05093763040914934F, 0.1556920433638569F));
        g.addOrReplaceChild("cola5_10", CubeListBuilder.create().texOffs(22, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(53.93333333333334F, -30.552418549310964F, 11.449695187959417F, 2.201527810722833F, 0.0429403522268538F, 0.12088690147929157F));
        g.addOrReplaceChild("cola5_11", CubeListBuilder.create().texOffs(80, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(53.93333333333334F, -29.29829170833369F, 12.287036414306677F, 2.07909156020483F, 0.0F, 0.16329263992948756F));
        g.addOrReplaceChild("cola6_0", CubeListBuilder.create().texOffs(96, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(56.46666666666667F, -28.836581521079395F, -12.287036414306677F, -2.098201763978651F, 0.0F, 0.19715360801406287F));
        g.addOrReplaceChild("cola6_1", CubeListBuilder.create().texOffs(44, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(56.46666666666667F, -30.04362514494645F, -11.44969518795942F, -2.2229122592558435F, -0.052565649530674025F, 0.14795883943666346F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("cola6_2", CubeListBuilder.create().texOffs(240, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(56.46666666666667F, -31.781605527855838F, -9.832076156068663F, -2.4166443971466456F, -0.06129801274608252F, 0.19024395640735242F));
        g.addOrReplaceChild("cola6_3", CubeListBuilder.create().texOffs(264, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(56.46666666666667F, -33.4402100997793F, -7.544417382415921F, -2.628685842350133F, -0.058869848253474875F, 0.2375073041816744F));
        g.addOrReplaceChild("cola6_4", CubeListBuilder.create().texOffs(964, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(56.46666666666667F, -34.68665574254941F, -4.742619031890755F, -2.8383967310277316F, -0.04237774703771826F, 0.27680103273299633F));
        g.addOrReplaceChild("cola6_5", CubeListBuilder.create().texOffs(990, 108).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(56.46666666666667F, -35.34830482534752F, -1.6176190318907553F, -3.0415221696519787F, -0.01538282825525504F, 0.29873004514478774F));
        g.addOrReplaceChild("cola6_6", CubeListBuilder.create().texOffs(0, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(56.46666666666667F, -35.34830482534752F, 1.6176190318907533F, 3.0415221696519796F, 0.01538282825525496F, 0.298730045144789F));
        g.addOrReplaceChild("cola6_7", CubeListBuilder.create().texOffs(26, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(56.46666666666667F, -34.68665574254941F, 4.742619031890753F, 2.838396731027731F, 0.042377747037718495F, 0.27680103273299744F));
        g.addOrReplaceChild("cola6_8", CubeListBuilder.create().texOffs(288, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(56.46666666666667F, -33.44021009977929F, 7.54441738241592F, 2.6286858423501336F, 0.0588698482534748F, 0.23750730418167446F));
        g.addOrReplaceChild("cola6_9", CubeListBuilder.create().texOffs(312, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(56.46666666666667F, -31.781605527855838F, 9.832076156068663F, 2.416644397146646F, 0.06129801274608256F, 0.19024395640735242F));
        g.addOrReplaceChild("cola6_10", CubeListBuilder.create().texOffs(66, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(56.46666666666667F, -30.04362514494645F, 11.449695187959417F, 2.222912259255844F, 0.05256564953067399F, 0.14795883943666355F));
        g.addOrReplaceChild("cola6_11", CubeListBuilder.create().texOffs(112, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(56.46666666666667F, -28.836581521079395F, 12.287036414306677F, 2.098201763978651F, 0.0F, 0.19715360801406287F));
        g.addOrReplaceChild("cola7_0", CubeListBuilder.create().texOffs(128, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -28.282136104251006F, -12.287036414306677F, -2.122865795907545F, 0.0F, 0.23362625163144937F));
        g.addOrReplaceChild("cola7_1", CubeListBuilder.create().texOffs(88, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(59.0F, -29.43263977154587F, -11.44969518795942F, -2.2502392107755544F, -0.06323129023976257F, 0.17839360337207089F));
        g.addOrReplaceChild("cola7_2", CubeListBuilder.create().texOffs(336, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(59.0F, -31.08921022574183F, -9.832076156068663F, -2.4458308142791148F, -0.07214256194220067F, 0.22874902396050853F));
        g.addOrReplaceChild("cola7_3", CubeListBuilder.create().texOffs(360, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(59.0F, -32.67012296564471F, -7.544417382415921F, -2.654798972988877F, -0.06766810987762648F, 0.2834497714396485F));
        g.addOrReplaceChild("cola7_4", CubeListBuilder.create().texOffs(52, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(59.0F, -33.85818299490565F, -4.742619031890755F, -2.856315876660584F, -0.0478023448333173F, 0.3276295283015748F));
        g.addOrReplaceChild("cola7_5", CubeListBuilder.create().texOffs(78, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(59.0F, -34.48883932013665F, -1.6176190318907553F, -3.0478712016620877F, -0.017175988615803155F, 0.35178736479771044F));
        g.addOrReplaceChild("cola7_6", CubeListBuilder.create().texOffs(104, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(59.0F, -34.48883932013665F, 1.6176190318907533F, 3.0478712016620877F, 0.017175988615803234F, 0.3517873647977104F));
        g.addOrReplaceChild("cola7_7", CubeListBuilder.create().texOffs(130, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(59.0F, -33.858182994905654F, 4.742619031890753F, 2.856315876660584F, 0.047802344833317224F, 0.3276295283015748F));
        g.addOrReplaceChild("cola7_8", CubeListBuilder.create().texOffs(384, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(59.0F, -32.67012296564471F, 7.54441738241592F, 2.6547989729888775F, 0.06766810987762648F, 0.28344977143964856F));
        g.addOrReplaceChild("cola7_9", CubeListBuilder.create().texOffs(408, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(59.0F, -31.08921022574183F, 9.832076156068663F, 2.4458308142791148F, 0.07214256194220067F, 0.22874902396050856F));
        g.addOrReplaceChild("cola7_10", CubeListBuilder.create().texOffs(110, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(59.0F, -29.432639771545876F, 11.449695187959417F, 2.250239210775555F, 0.06323129023976261F, 0.17839360337207083F));
        g.addOrReplaceChild("cola7_11", CubeListBuilder.create().texOffs(144, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(59.0F, -28.282136104251006F, 12.287036414306677F, 2.122865795907545F, 0.0F, 0.23362625163144937F));
        g.addOrReplaceChild("cola8_0", CubeListBuilder.create().texOffs(160, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(61.53333333333333F, -27.625137019132904F, -12.287036414306677F, -2.1547743824978816F, 0.0F, 0.27366863721505186F));
        g.addOrReplaceChild("cola8_1", CubeListBuilder.create().texOffs(296, 131).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(61.53333333333333F, -28.708642748284397F, -11.44969518795942F, -2.2851374155454502F, -0.0751871654899002F, 0.21358808327819384F));
        g.addOrReplaceChild("cola8_2", CubeListBuilder.create().texOffs(432, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(61.53333333333333F, -30.26874518766618F, -9.832076156068663F, -2.4821996935855117F, -0.08343422061229559F, 0.2726610838598423F));
        g.addOrReplaceChild("cola8_3", CubeListBuilder.create().texOffs(456, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(61.53333333333333F, -31.757595731707376F, -7.544417382415921F, -2.6864321945400804F, -0.07605217386030451F, 0.33459067394747055F));
        g.addOrReplaceChild("cola8_4", CubeListBuilder.create().texOffs(156, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(61.53333333333333F, -32.87647078171641F, -4.742619031890755F, -2.877519399376737F, -0.052565470984445035F, 0.3829547327541177F));
        g.addOrReplaceChild("cola8_5", CubeListBuilder.create().texOffs(182, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(61.53333333333333F, -33.47040173642607F, -1.6176190318907553F, -3.0552873275607317F, -0.018672410353416564F, 0.4088135407464163F));
        g.addOrReplaceChild("cola8_6", CubeListBuilder.create().texOffs(208, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(61.53333333333333F, -33.470401736426076F, 1.6176190318907533F, 3.0552873275607326F, 0.01867241035341625F, 0.4088135407464152F));
        g.addOrReplaceChild("cola8_7", CubeListBuilder.create().texOffs(234, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(61.53333333333333F, -32.87647078171641F, 4.742619031890753F, 2.877519399376736F, 0.05256547098444496F, 0.38295473275411646F));
        g.addOrReplaceChild("cola8_8", CubeListBuilder.create().texOffs(480, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(61.53333333333333F, -31.757595731707372F, 7.54441738241592F, 2.686432194540081F, 0.07605217386030451F, 0.33459067394747055F));
        g.addOrReplaceChild("cola8_9", CubeListBuilder.create().texOffs(504, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(61.53333333333333F, -30.26874518766618F, 9.832076156068663F, 2.482199693585512F, 0.08343422061229547F, 0.27266108385984233F));
        g.addOrReplaceChild("cola8_10", CubeListBuilder.create().texOffs(316, 131).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(61.53333333333333F, -28.708642748284397F, 11.449695187959417F, 2.2851374155454502F, 0.07518716548990013F, 0.21358808327819392F));
        g.addOrReplaceChild("cola8_11", CubeListBuilder.create().texOffs(176, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(61.53333333333333F, -27.625137019132907F, 12.287036414306677F, 2.1547743824978816F, 0.0F, 0.27366863721505186F));
        g.addOrReplaceChild("cola9_0", CubeListBuilder.create().texOffs(192, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(64.06666666666666F, -26.851619783825836F, -12.287036414306677F, -2.196545975946646F, 0.0F, 0.31871121492433097F));
        g.addOrReplaceChild("cola9_1", CubeListBuilder.create().texOffs(336, 131).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(64.06666666666666F, -27.856245555519514F, -11.44969518795942F, -2.3300466929990997F, -0.08867924180605305F, 0.2556950750233959F));
        g.addOrReplaceChild("cola9_2", CubeListBuilder.create().texOffs(132, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(64.06666666666666F, -29.302771471273097F, -9.832076156068663F, -2.5275322226188255F, -0.094988066235823F, 0.3240914050064682F));
        g.addOrReplaceChild("cola9_3", CubeListBuilder.create().texOffs(528, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(64.06666666666666F, -30.683232678354365F, -7.544417382415921F, -2.7245262092958673F, -0.08366179084495527F, 0.3927209066121255F));
        g.addOrReplaceChild("cola9_4", CubeListBuilder.create().texOffs(260, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(64.06666666666666F, -31.720652860178767F, -4.742619031890755F, -2.9023749137577055F, -0.056406002455389515F, 0.44431387835022673F));
        g.addOrReplaceChild("cola9_5", CubeListBuilder.create().texOffs(286, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(64.06666666666666F, -32.27134523554372F, -1.6176190318907553F, -3.0638578825487306F, -0.01978573146447617F, 0.4712500979376024F));
        g.addOrReplaceChild("cola9_6", CubeListBuilder.create().texOffs(312, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(64.06666666666666F, -32.27134523554372F, 1.6176190318907533F, 3.063857882548732F, 0.01978573146447601F, 0.4712500979376036F));
        g.addOrReplaceChild("cola9_7", CubeListBuilder.create().texOffs(338, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(64.06666666666666F, -31.720652860178774F, 4.742619031890753F, 2.9023749137577055F, 0.0564060024553896F, 0.4443138783502273F));
        g.addOrReplaceChild("cola9_8", CubeListBuilder.create().texOffs(552, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(64.06666666666666F, -30.683232678354365F, 7.54441738241592F, 2.724526209295867F, 0.08366179084495504F, 0.392720906612125F));
        g.addOrReplaceChild("cola9_9", CubeListBuilder.create().texOffs(154, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(64.06666666666666F, -29.302771471273097F, 9.832076156068663F, 2.5275322226188255F, 0.094988066235823F, 0.3240914050064683F));
        g.addOrReplaceChild("cola9_10", CubeListBuilder.create().texOffs(356, 131).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(64.06666666666666F, -27.856245555519518F, 11.449695187959417F, 2.3300466929990997F, 0.08867924180605305F, 0.2556950750233959F));
        g.addOrReplaceChild("cola9_11", CubeListBuilder.create().texOffs(208, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(64.06666666666666F, -26.851619783825836F, 12.287036414306677F, 2.196545975946646F, 0.0F, 0.31871121492433097F));
        g.addOrReplaceChild("cola10_0", CubeListBuilder.create().texOffs(224, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(66.6F, -25.940843286373124F, -12.287036414306677F, -2.252422043452905F, 0.0F, 0.37105240233941206F));
        g.addOrReplaceChild("cola10_1", CubeListBuilder.create().texOffs(376, 131).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(66.6F, -26.85259199199325F, -11.44969518795942F, -2.388748847086346F, -0.10383987371982623F, 0.30823150101258323F));
        g.addOrReplaceChild("cola10_2", CubeListBuilder.create().texOffs(176, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(66.6F, -28.165387431344605F, -9.832076156068663F, -2.5843650959115587F, -0.10630796120197353F, 0.386267886219961F));
        g.addOrReplaceChild("cola10_3", CubeListBuilder.create().texOffs(576, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(66.6F, -29.418225805770575F, -7.544417382415921F, -2.770334807739968F, -0.08988404229671108F, 0.4605098023833099F));
        g.addOrReplaceChild("cola10_4", CubeListBuilder.create().texOffs(364, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(66.6F, -30.35973709745084F, -4.742619031890755F, -2.9313710616963404F, -0.058936751058682776F, 0.5140401353738687F));
        g.addOrReplaceChild("cola10_5", CubeListBuilder.create().texOffs(390, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(66.6F, -30.859518284217923F, -1.6176190318907553F, -3.073704322221276F, -0.02039389254486056F, 0.5413224495631144F));
        g.addOrReplaceChild("cola10_6", CubeListBuilder.create().texOffs(416, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(66.6F, -30.859518284217927F, 1.6176190318907533F, 3.073704322221276F, 0.02039389254486056F, 0.5413224495631143F));
        g.addOrReplaceChild("cola10_7", CubeListBuilder.create().texOffs(442, 116).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(66.6F, -30.359737097450846F, 4.742619031890753F, 2.931371061696341F, 0.05893675105868262F, 0.5140401353738692F));
        g.addOrReplaceChild("cola10_8", CubeListBuilder.create().texOffs(600, 124).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(66.6F, -29.41822580577058F, 7.54441738241592F, 2.7703348077399674F, 0.08988404229671115F, 0.46050980238331024F));
        g.addOrReplaceChild("cola10_9", CubeListBuilder.create().texOffs(198, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(66.6F, -28.165387431344605F, 9.832076156068663F, 2.584365095911559F, 0.10630796120197353F, 0.386267886219961F));
        g.addOrReplaceChild("cola10_10", CubeListBuilder.create().texOffs(396, 131).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(66.6F, -26.85259199199325F, 11.449695187959417F, 2.388748847086346F, 0.10383987371982623F, 0.30823150101258323F));
        g.addOrReplaceChild("cola10_11", CubeListBuilder.create().texOffs(240, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(66.6F, -25.940843286373124F, 12.287036414306677F, 2.252422043452905F, 0.0F, 0.37105240233941206F));
        g.addOrReplaceChild("cola11_0", CubeListBuilder.create().texOffs(256, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(69.13333333333333F, -24.859772214517196F, -12.287036414306677F, -2.3297012388894864F, 0.0F, 0.43476651839986685F));
        g.addOrReplaceChild("cola11_1", CubeListBuilder.create().texOffs(416, 131).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(69.13333333333333F, -25.661277946529868F, -11.44969518795942F, -2.467374771032236F, -0.12033529224472406F, 0.3773712957952949F));
        g.addOrReplaceChild("cola11_2", CubeListBuilder.create().texOffs(220, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(69.13333333333333F, -26.815338339612133F, -9.832076156068663F, -2.6564052605321917F, -0.11622558138822037F, 0.4644831291526359F));
        g.addOrReplaceChild("cola11_3", CubeListBuilder.create().texOffs(870, 116).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(69.13333333333333F, -27.916691302548205F, -7.544417382415921F, -2.8255768348993198F, -0.09364926452965501F, 0.5423026400227093F));
        g.addOrReplaceChild("cola11_4", CubeListBuilder.create().texOffs(804, 95).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(69.13333333333333F, -28.74436091412515F, -4.742619031890755F, -2.965187367409799F, -0.05954818005228494F, 0.5960306972705013F));
        g.addOrReplaceChild("cola11_5", CubeListBuilder.create().texOffs(832, 95).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(69.13333333333333F, -29.183711673250667F, -1.6176190318907553F, -3.085004248915155F, -0.020309782867979558F, 0.6227983287532286F));
        g.addOrReplaceChild("cola11_6", CubeListBuilder.create().texOffs(860, 95).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(69.13333333333333F, -29.18371167325067F, 1.6176190318907533F, 3.085004248915155F, 0.020309782867979558F, 0.6227983287532286F));
        g.addOrReplaceChild("cola11_7", CubeListBuilder.create().texOffs(888, 95).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(69.13333333333333F, -28.744360914125146F, 4.742619031890753F, 2.965187367409799F, 0.05954818005228494F, 0.5960306972705013F));
        g.addOrReplaceChild("cola11_8", CubeListBuilder.create().texOffs(896, 116).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(69.13333333333333F, -27.916691302548205F, 7.54441738241592F, 2.8255768348993198F, 0.09364926452965501F, 0.5423026400227093F));
        g.addOrReplaceChild("cola11_9", CubeListBuilder.create().texOffs(242, 131).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(69.13333333333333F, -26.815338339612133F, 9.832076156068663F, 2.6564052605321917F, 0.11622558138822069F, 0.46448312915263634F));
        g.addOrReplaceChild("cola11_10", CubeListBuilder.create().texOffs(436, 131).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(69.13333333333333F, -25.661277946529868F, 11.449695187959417F, 2.4673747710322367F, 0.12033529224472422F, 0.37737129579529544F));
        g.addOrReplaceChild("cola11_11", CubeListBuilder.create().texOffs(272, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(69.13333333333333F, -24.859772214517193F, 12.287036414306677F, 2.3297012388894864F, 0.0F, 0.43476651839986685F));
        g.addOrReplaceChild("cola12_0", CubeListBuilder.create().texOffs(288, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(71.66666666666667F, -23.549281175870554F, -12.287036414306677F, -2.442017889119464F, 0.0F, 0.5182160037077627F));
        g.addOrReplaceChild("cola12_1", CubeListBuilder.create().texOffs(456, 131).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(71.66666666666667F, -24.217148673776844F, -11.44969518795942F, -2.5764671365604612F, -0.13621396394642282F, 0.4751022850557487F));
        g.addOrReplaceChild("cola12_2", CubeListBuilder.create().texOffs(692, 124).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(71.66666666666667F, -25.178787993841507F, -9.832076156068663F, -2.7493073416418836F, -0.12202856278429644F, 0.5684577811113941F));
        g.addOrReplaceChild("cola12_3", CubeListBuilder.create().texOffs(922, 116).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(71.66666666666667F, -26.096508002930797F, -7.544417382415921F, -2.8927584429189235F, -0.09296855497220143F, 0.6462359964785317F));
        g.addOrReplaceChild("cola12_4", CubeListBuilder.create().texOffs(916, 95).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(71.66666666666667F, -26.786176972844316F, -4.742619031890755F, -3.0048544958495897F, -0.057179385319026554F, 0.6977948041734137F));
        g.addOrReplaceChild("cola12_5", CubeListBuilder.create().texOffs(944, 95).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(71.66666666666667F, -27.15227303489437F, -1.6176190318907553F, -3.0980415735397644F, -0.019209622114083703F, 0.723000293850163F));
        g.addOrReplaceChild("cola12_6", CubeListBuilder.create().texOffs(972, 95).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(71.66666666666667F, -27.15227303489437F, 1.6176190318907533F, 3.0980415735397644F, 0.01920962211408378F, 0.723000293850163F));
        g.addOrReplaceChild("cola12_7", CubeListBuilder.create().texOffs(0, 108).addBox(-3.5F, -1.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(71.66666666666667F, -26.786176972844313F, 4.742619031890753F, 3.00485449584959F, 0.0571793853190264F, 0.6977948041734137F));
        g.addOrReplaceChild("cola12_8", CubeListBuilder.create().texOffs(948, 116).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(71.66666666666667F, -26.096508002930797F, 7.54441738241592F, 2.892758442918924F, 0.09296855497220134F, 0.6462359964785318F));
        g.addOrReplaceChild("cola12_9", CubeListBuilder.create().texOffs(716, 124).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(71.66666666666667F, -25.178787993841507F, 9.832076156068663F, 2.749307341641883F, 0.12202856278429668F, 0.5684577811113938F));
        g.addOrReplaceChild("cola12_10", CubeListBuilder.create().texOffs(476, 131).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(71.66666666666667F, -24.217148673776844F, 11.449695187959417F, 2.5764671365604626F, 0.13621396394642263F, 0.47510228505574914F));
        g.addOrReplaceChild("cola12_11", CubeListBuilder.create().texOffs(304, 149).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(71.66666666666667F, -23.549281175870554F, 12.287036414306677F, 2.442017889119464F, 0.0F, 0.5182160037077627F));
        g.addOrReplaceChild("cola13_0", CubeListBuilder.create().texOffs(888, 145).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.2F, -21.87662176079344F, -12.287036414306677F, -2.6182707190352574F, 0.0F, 0.6437091943666978F));
        g.addOrReplaceChild("cola13_1", CubeListBuilder.create().texOffs(782, 145).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(74.2F, -22.37391865279679F, -11.44969518795942F, -2.740394964944798F, 0.0F, 0.6908939562408013F));
        g.addOrReplaceChild("cola13_2", CubeListBuilder.create().texOffs(740, 124).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(74.2F, -23.089959254556202F, -9.832076156068663F, -2.8726788657585165F, -0.11687932036988358F, 0.7207648111046018F));
        g.addOrReplaceChild("cola13_3", CubeListBuilder.create().texOffs(814, 116).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(74.2F, -23.773297356320555F, -7.544417382415921F, -2.976183660307886F, -0.08352953056202117F, 0.7921088320515383F));
        g.addOrReplaceChild("cola13_4", CubeListBuilder.create().texOffs(684, 95).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(74.2F, -24.28682771424983F, -4.742619031890755F, -3.052275577475563F, -0.04957835153082754F, 0.8380192478642041F));
        g.addOrReplaceChild("cola13_5", CubeListBuilder.create().texOffs(714, 95).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(74.2F, -24.559424351161937F, -1.6176190318907553F, -3.113367929435228F, -0.016397362567341225F, 0.8601963017731993F));
        g.addOrReplaceChild("cola13_6", CubeListBuilder.create().texOffs(744, 95).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(74.2F, -24.559424351161937F, 1.6176190318907533F, 3.113367929435228F, 0.016397362567341225F, 0.8601963017731993F));
        g.addOrReplaceChild("cola13_7", CubeListBuilder.create().texOffs(774, 95).addBox(-4.0F, -1.0F, -3.5F, 8.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(74.2F, -24.286827714249828F, 4.742619031890753F, 3.052275577475563F, 0.04957835153082746F, 0.8380192478642041F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("cola13_8", CubeListBuilder.create().texOffs(842, 116).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(74.2F, -23.773297356320555F, 7.54441738241592F, 2.976183660307886F, 0.083529530562021F, 0.7921088320515384F));
        g.addOrReplaceChild("cola13_9", CubeListBuilder.create().texOffs(764, 124).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(74.2F, -23.089959254556202F, 9.832076156068663F, 2.8726788657585165F, 0.11687932036988358F, 0.7207648111046014F));
        g.addOrReplaceChild("cola13_10", CubeListBuilder.create().texOffs(802, 145).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(74.2F, -22.37391865279679F, 11.449695187959417F, 2.740394964944798F, 0.0F, 0.6908939562408009F));
        g.addOrReplaceChild("cola13_11", CubeListBuilder.create().texOffs(906, 145).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.2F, -21.87662176079344F, 12.287036414306677F, 2.6182707190352574F, 0.0F, 0.6437091943666978F));
        g.addOrReplaceChild("cola14_0", CubeListBuilder.create().texOffs(320, 149).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(76.73333333333333F, -18.96310493023695F, -12.287036414306677F, -2.9854396331501634F, 0.0F, 0.9977771837454243F));
        g.addOrReplaceChild("cola14_1", CubeListBuilder.create().texOffs(726, 145).addBox(-5.5F, -1.0F, -1.5F, 11.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(76.73333333333333F, -19.163293919330176F, -11.44969518795942F, -3.0300969081652633F, 0.0F, 1.0410868299208542F));
        g.addOrReplaceChild("cola14_2", CubeListBuilder.create().texOffs(624, 124).addBox(-6.0F, -1.0F, -2.5F, 12.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.73333333333333F, -19.451539123595317F, -9.832076156068663F, -3.07242796132296F, 0.0F, 1.0938921862132578F));
        g.addOrReplaceChild("cola14_3", CubeListBuilder.create().texOffs(738, 116).addBox(-6.5F, -1.0F, -3.0F, 13.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(76.73333333333333F, -19.726619796732063F, -7.544417382415921F, -3.1008695781317117F, 0.0F, 1.1359040573406756F));
        g.addOrReplaceChild("cola14_4", CubeListBuilder.create().texOffs(604, 95).addBox(-6.5F, -1.0F, -3.5F, 13.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(76.73333333333333F, -19.933343636908113F, -4.742619031890755F, -3.1201514340461562F, 0.0F, 1.1631660997482922F));
        g.addOrReplaceChild("cola14_5", CubeListBuilder.create().texOffs(520, 95).addBox(-7.0F, -1.0F, -3.5F, 14.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(76.73333333333333F, -20.043078578049233F, -1.6176190318907553F, -3.134894571305205F, 0.0F, 1.1763644320739215F));
        g.addOrReplaceChild("cola14_6", CubeListBuilder.create().texOffs(562, 95).addBox(-7.0F, -1.0F, -3.5F, 14.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(76.73333333333333F, -20.043078578049233F, 1.6176190318907533F, 3.134894571305205F, 0.0F, 1.1763644320739215F));
        g.addOrReplaceChild("cola14_7", CubeListBuilder.create().texOffs(644, 95).addBox(-6.5F, -1.0F, -3.5F, 13.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(76.73333333333333F, -19.933343636908113F, 4.742619031890753F, 3.1201514340461562F, 0.0F, 1.1631660997482922F));
        g.addOrReplaceChild("cola14_8", CubeListBuilder.create().texOffs(776, 116).addBox(-6.5F, -1.0F, -3.0F, 13.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(76.73333333333333F, -19.726619796732063F, 7.54441738241592F, 3.1008695781317117F, 0.0F, 1.1359040573406756F));
        g.addOrReplaceChild("cola14_9", CubeListBuilder.create().texOffs(658, 124).addBox(-6.0F, -1.0F, -2.5F, 12.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.73333333333333F, -19.451539123595317F, 9.832076156068663F, 3.0724279613229606F, 0.0F, 1.093892186213258F));
        g.addOrReplaceChild("cola14_10", CubeListBuilder.create().texOffs(754, 145).addBox(-5.5F, -1.0F, -1.5F, 11.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(76.73333333333333F, -19.16329391933018F, 11.449695187959417F, 3.0300969081652633F, 0.0F, 1.0410868299208544F));
        g.addOrReplaceChild("cola14_11", CubeListBuilder.create().texOffs(342, 149).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(76.73333333333333F, -18.96310493023695F, 12.287036414306677F, 2.9854396331501634F, 0.0F, 0.9977771837454243F));
        g.addOrReplaceChild("cola_fondo", CubeListBuilder.create().texOffs(396, 0).addBox(77.0F, -18.0F, -11.5F, 1.0F, 8.0F, 23.0F).texOffs(876, 145).addBox(78.0F, -15.0F, -9.0F, 1.0F, 2.0F, 2.0F).texOffs(882, 145).addBox(78.0F, -15.0F, 7.0F, 1.0F, 2.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("butacas", CubeListBuilder.create().texOffs(676, 75).addBox(-66.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(998, 51).addBox(-63.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(700, 75).addBox(-66.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(0, 75).addBox(-63.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(724, 75).addBox(-59.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(20, 75).addBox(-56.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(748, 75).addBox(-59.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(40, 75).addBox(-56.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(772, 75).addBox(-52.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(60, 75).addBox(-49.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(796, 75).addBox(-52.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(80, 75).addBox(-49.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(820, 75).addBox(-45.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(100, 75).addBox(-42.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(844, 75).addBox(-45.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(120, 75).addBox(-42.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(868, 75).addBox(-38.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(140, 75).addBox(-35.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(892, 75).addBox(-38.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(160, 75).addBox(-35.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(916, 75).addBox(-31.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(180, 75).addBox(-28.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(940, 75).addBox(-31.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(200, 75).addBox(-28.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(964, 75).addBox(-24.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(220, 75).addBox(-21.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(988, 75).addBox(-24.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(240, 75).addBox(-21.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(0, 95).addBox(-17.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(260, 75).addBox(-14.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(24, 95).addBox(-17.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(280, 75).addBox(-14.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(48, 95).addBox(-10.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(300, 75).addBox(-7.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(72, 95).addBox(-10.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(320, 75).addBox(-7.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(96, 95).addBox(-3.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(340, 75).addBox(-0.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(120, 95).addBox(-3.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(360, 75).addBox(-0.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(144, 95).addBox(3.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(380, 75).addBox(6.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(168, 95).addBox(3.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(400, 75).addBox(6.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(192, 95).addBox(10.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(420, 75).addBox(13.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(216, 95).addBox(10.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(440, 75).addBox(13.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(240, 95).addBox(17.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(460, 75).addBox(20.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(264, 95).addBox(17.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(480, 75).addBox(20.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F), PartPose.ZERO);
        g.addOrReplaceChild("sillones", CubeListBuilder.create().texOffs(318, 95).addBox(26.0F, -15.0F, -10.0F, 5.0F, 4.0F, 5.0F).texOffs(580, 75).addBox(25.0F, -20.0F, -10.0F, 1.0F, 9.0F, 5.0F).texOffs(338, 95).addBox(26.0F, -15.0F, 5.0F, 5.0F, 4.0F, 5.0F).texOffs(592, 75).addBox(25.0F, -20.0F, 5.0F, 1.0F, 9.0F, 5.0F).texOffs(358, 95).addBox(34.0F, -15.0F, -10.0F, 5.0F, 4.0F, 5.0F).texOffs(604, 75).addBox(33.0F, -20.0F, -10.0F, 1.0F, 9.0F, 5.0F).texOffs(378, 95).addBox(34.0F, -15.0F, 5.0F, 5.0F, 4.0F, 5.0F).texOffs(616, 75).addBox(33.0F, -20.0F, 5.0F, 1.0F, 9.0F, 5.0F).texOffs(398, 95).addBox(42.0F, -15.0F, -10.0F, 5.0F, 4.0F, 5.0F).texOffs(628, 75).addBox(41.0F, -20.0F, -10.0F, 1.0F, 9.0F, 5.0F).texOffs(418, 95).addBox(42.0F, -15.0F, 5.0F, 5.0F, 4.0F, 5.0F).texOffs(640, 75).addBox(41.0F, -20.0F, 5.0F, 1.0F, 9.0F, 5.0F).texOffs(438, 95).addBox(50.0F, -15.0F, -10.0F, 5.0F, 4.0F, 5.0F).texOffs(652, 75).addBox(49.0F, -20.0F, -10.0F, 1.0F, 9.0F, 5.0F).texOffs(458, 95).addBox(50.0F, -15.0F, 5.0F, 5.0F, 4.0F, 5.0F).texOffs(664, 75).addBox(49.0F, -20.0F, 5.0F, 1.0F, 9.0F, 5.0F), PartPose.ZERO);
        g.addOrReplaceChild("sillones_cola", CubeListBuilder.create().texOffs(468, 116).addBox(56.0F, -15.0F, -8.0F, 5.0F, 4.0F, 4.0F).texOffs(288, 95).addBox(55.0F, -19.0F, -8.0F, 1.0F, 8.0F, 4.0F).texOffs(486, 116).addBox(56.0F, -15.0F, -2.0F, 5.0F, 4.0F, 4.0F).texOffs(298, 95).addBox(55.0F, -19.0F, -2.0F, 1.0F, 8.0F, 4.0F).texOffs(504, 116).addBox(56.0F, -15.0F, 4.0F, 5.0F, 4.0F, 4.0F).texOffs(308, 95).addBox(55.0F, -19.0F, 4.0F, 1.0F, 8.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(478, 95).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(822, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 131).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-66.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(840, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(858, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(478, 95).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(822, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 131).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-50.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(840, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(858, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(478, 95).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(822, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(516, 131).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-66.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(840, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(858, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(478, 95).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(822, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(526, 131).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-50.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(840, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(858, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(522, 116).addBox(-71.0F, -9.0F, 7.0F, 26.0F, 6.0F, 1.0F).texOffs(576, 116).addBox(-71.0F, -9.0F, -8.0F, 26.0F, 6.0F, 1.0F).texOffs(536, 131).addBox(-68.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(546, 131).addBox(-68.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(556, 131).addBox(-52.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(566, 131).addBox(-52.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_pivote", CubeListBuilder.create().texOffs(500, 75).addBox(-61.0F, -10.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(478, 95).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(822, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(576, 131).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(840, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(858, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(478, 95).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(822, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(586, 131).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(60.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(840, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(60.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(858, 145).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 95).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(60.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(478, 95).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(822, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(596, 131).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(840, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(858, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(478, 95).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(822, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(606, 131).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(60.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(840, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(60.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(858, 145).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(512, 95).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(60.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(630, 116).addBox(39.0F, -9.0F, 7.0F, 26.0F, 6.0F, 1.0F).texOffs(684, 116).addBox(39.0F, -9.0F, -8.0F, 26.0F, 6.0F, 1.0F).texOffs(616, 131).addBox(42.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(626, 131).addBox(42.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(636, 131).addBox(58.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(646, 131).addBox(58.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_pivote", CubeListBuilder.create().texOffs(540, 75).addBox(49.0F, -10.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bajo_piso", CubeListBuilder.create().texOffs(444, 0).addBox(-78.0F, -10.0F, -11.0F, 156.0F, 2.0F, 22.0F).texOffs(830, 51).addBox(-36.0F, -8.0F, -9.0F, 66.0F, 3.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuelle", CubeListBuilder.create().texOffs(356, 0).addBox(-80.0F, -30.0F, -9.0F, 2.0F, 19.0F, 18.0F).texOffs(264, 131).addBox(-85.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(280, 131).addBox(78.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "techo_0", 1.0001694915254238F, 1.0F, 0.8761330552825338F);
        escalar(g0, "techo_1", 1.0001694915254238F, 1.0F, 0.8761330552825345F);
        escalar(g0, "techo_2", 1.0001694915254238F, 1.0F, 0.876133055282533F);
        escalar(g0, "techo_3", 1.0001694915254238F, 1.0F, 0.876133055282534F);
        escalar(g0, "techo_4", 1.0001694915254238F, 1.0F, 0.8761330552825334F);
        escalar(g0, "techo_5", 1.0001694915254238F, 1.0F, 0.876133055282534F);
        escalar(g0, "techo_6", 1.0001694915254238F, 1.0F, 0.8761330552825329F);
        escalar(g0, "techo_7", 1.0001694915254238F, 1.0F, 0.8761330552825339F);
        escalar(g0, "techo_8", 1.0001694915254238F, 1.0F, 0.8761330552825347F);
        escalar(g0, "techo_9", 1.0001694915254238F, 1.0F, 0.8761330552825326F);
        escalar(g0, "techo_10", 1.0001694915254238F, 1.0F, 0.8761330552825348F);
        escalar(g0, "techo_11", 1.0001694915254238F, 1.0F, 0.8761330552825338F);
        escalar(g0, "cola_ladoi", 0.5F, 0.5F, 1.0F);
        escalar(g0, "cola_ladod", 0.5F, 0.5F, 1.0F);
        escalar(g0, "cola0_0", 0.43059781605152336F, 1.0F, 0.49793268837645677F);
        escalar(g0, "cola0_1", 0.4306070328159241F, 1.0F, 0.4629579231062596F);
        escalar(g0, "cola0_2", 0.43062164048167667F, 1.0F, 0.48375067987515513F);
        escalar(g0, "cola0_3", 0.4306371686735569F, 1.0F, 0.4503430034380967F);
        escalar(g0, "cola0_4", 0.4306498858760579F, 1.0F, 0.46626429678696496F);
        escalar(g0, "cola0_5", 0.43065700509103605F, 1.0F, 0.47258184665395386F);
        escalar(g0, "cola0_6", 0.43065700509103594F, 1.0F, 0.4725818466539532F);
        escalar(g0, "cola0_7", 0.43064988587605785F, 1.0F, 0.4662642967869654F);
        escalar(g0, "cola0_8", 0.4306371686735569F, 1.0F, 0.4503430034380969F);
        escalar(g0, "cola0_9", 0.43062164048167667F, 1.0F, 0.4837506798751539F);
        escalar(g0, "cola0_10", 0.4306070328159241F, 1.0F, 0.46295792310626116F);
        escalar(g0, "cola0_11", 0.43059781605152336F, 1.0F, 0.49793268837645677F);
        escalar(g0, "cola1_0", 0.4309384804437198F, 1.0F, 0.49591359418896896F);
        escalar(g0, "cola1_1", 0.43102195014127326F, 1.0F, 0.4612703842952973F);
        escalar(g0, "cola1_2", 0.43115421441747853F, 1.0F, 0.4824409377722157F);
        escalar(g0, "cola1_3", 0.4312947759736876F, 1.0F, 0.44962369081653186F);
        escalar(g0, "cola1_4", 0.43140986327323905F, 1.0F, 0.4659699201370047F);
        escalar(g0, "cola1_5", 0.4314742788071664F, 1.0F, 0.4725471401017603F);
        escalar(g0, "cola1_6", 0.4314742788071664F, 1.0F, 0.4725471401017596F);
        escalar(g0, "cola1_7", 0.43140986327323905F, 1.0F, 0.4659699201370054F);
        escalar(g0, "cola1_8", 0.4312947759736876F, 1.0F, 0.44962369081653214F);
        escalar(g0, "cola1_9", 0.43115421441747853F, 1.0F, 0.4824409377722145F);
        escalar(g0, "cola1_10", 0.43102195014127326F, 1.0F, 0.4612703842952989F);
        escalar(g0, "cola1_11", 0.4309384804437198F, 1.0F, 0.49591359418896896F);
        escalar(g0, "cola2_0", 0.43163391146732694F, 1.0F, 0.49186020095678296F);
        escalar(g0, "cola2_1", 0.4318687188453832F, 1.0F, 0.4578854249460891F);
        escalar(g0, "cola2_2", 0.4322406354167258F, 1.0F, 0.4798176761018678F);
        escalar(g0, "cola2_3", 0.4326356690982393F, 1.0F, 0.4481854623993361F);
        escalar(g0, "cola2_4", 0.43295894435945065F, 1.0F, 0.46538219907798645F);
        escalar(g0, "cola2_5", 0.4331398196654506F, 1.0F, 0.47247790751344787F);
        escalar(g0, "cola2_6", 0.4331398196654506F, 1.0F, 0.4724779075134471F);
        escalar(g0, "cola2_7", 0.43295894435945065F, 1.0F, 0.46538219907798706F);
        escalar(g0, "cola2_8", 0.4326356690982393F, 1.0F, 0.4481854623993363F);
        escalar(g0, "cola2_9", 0.4322406354167258F, 1.0F, 0.4798176761018665F);
        escalar(g0, "cola2_10", 0.4318687188453832F, 1.0F, 0.4578854249460907F);
        escalar(g0, "cola2_11", 0.43163391146732694F, 1.0F, 0.49186020095678296F);
        escalar(g0, "cola3_0", 0.4327140302812169F, 1.0F, 0.4857415048384626F);
        escalar(g0, "cola3_1", 0.43318325014763587F, 1.0F, 0.4527830589577371F);
        escalar(g0, "cola3_2", 0.4339259841113809F, 1.0F, 0.47587344865879727F);
        escalar(g0, "cola3_3", 0.4347142274615843F, 1.0F, 0.44602926792526076F);
        escalar(g0, "cola3_4", 0.43535877906536696F, 1.0F, 0.46450326751517074F);
        escalar(g0, "cola3_5", 0.4357192126747406F, 1.0F, 0.4723745171077965F);
        escalar(g0, "cola3_6", 0.4357192126747407F, 1.0F, 0.4723745171077959F);
        escalar(g0, "cola3_7", 0.435358779065367F, 1.0F, 0.4645032675151712F);
        escalar(g0, "cola3_8", 0.4347142274615843F, 1.0F, 0.446029267925261F);
        escalar(g0, "cola3_9", 0.4339259841113809F, 1.0F, 0.4758734486587965F);
        escalar(g0, "cola3_10", 0.43318325014763587F, 1.0F, 0.45278305895773807F);
        escalar(g0, "cola3_11", 0.4327140302812169F, 1.0F, 0.4857415048384626F);
        escalar(g0, "cola4_0", 0.43422843333597094F, 1.0F, 0.47750947179699255F);
        escalar(g0, "cola4_1", 0.43502501856653025F, 1.0F, 0.4459327608459639F);
        escalar(g0, "cola4_2", 0.4362848315305259F, 1.0F, 0.47059739854651356F);
        escalar(g0, "cola4_3", 0.4376203020176391F, 1.0F, 0.4431569472781617F);
        escalar(g0, "cola4_4", 0.43871114646035797F, 1.0F, 0.4633365082493284F);
        escalar(g0, "cola4_5", 0.43932068669803553F, 1.0F, 0.47223754003813234F);
        escalar(g0, "cola4_6", 0.43932068669803553F, 1.0F, 0.47223754003813184F);
        escalar(g0, "cola4_7", 0.43871114646035797F, 1.0F, 0.4633365082493287F);
        escalar(g0, "cola4_8", 0.4376203020176391F, 1.0F, 0.44315694727816185F);
        escalar(g0, "cola4_9", 0.4362848315305259F, 1.0F, 0.470597398546513F);
        escalar(g0, "cola4_10", 0.43502501856653014F, 1.0F, 0.4459327608459646F);
        escalar(g0, "cola4_11", 0.43422843333597094F, 1.0F, 0.47750947179699255F);
        escalar(g0, "cola5_0", 0.43625341444977367F, 1.0F, 0.4670970830873022F);
        escalar(g0, "cola5_1", 0.43748540233741773F, 1.0F, 0.43729285086836284F);
        escalar(g0, "cola5_2", 0.4394315565038902F, 1.0F, 0.46397576080289243F);
        escalar(g0, "cola5_3", 0.441491488526532F, 1.0F, 0.4395718053904328F);
        escalar(g0, "cola5_4", 0.4431717262554587F, 1.0F, 0.46188679682986F);
        escalar(g0, "cola5_5", 0.4441096868632681F, 1.0F, 0.47206777560374275F);
        escalar(g0, "cola5_6", 0.44410968686326796F, 1.0F, 0.47206777560374213F);
        escalar(g0, "cola5_7", 0.44317172625545864F, 1.0F, 0.46188679682986045F);
        escalar(g0, "cola5_8", 0.441491488526532F, 1.0F, 0.439571805390433F);
        escalar(g0, "cola5_9", 0.4394315565038902F, 1.0F, 0.46397576080289155F);
        escalar(g0, "cola5_10", 0.43748540233741773F, 1.0F, 0.4372928508683639F);
        escalar(g0, "cola5_11", 0.43625341444977367F, 1.0F, 0.4670970830873022F);
        escalar(g0, "cola6_0", 0.4389042629119156F, 1.0F, 0.45441553224625253F);
        escalar(g0, "cola6_1", 0.44070226542957885F, 1.0F, 0.4268097874310136F);
        escalar(g0, "cola6_2", 0.44353834252475804F, 1.0F, 0.4559927943943643F);
        escalar(g0, "cola6_3", 0.4465344915256102F, 1.0F, 0.5078261164129731F);
        escalar(g0, "cola6_4", 0.44897403551100235F, 1.0F, 0.4601608762622531F);
        escalar(g0, "cola6_5", 0.4503341846066955F, 1.0F, 0.4718662899825006F);
        escalar(g0, "cola6_6", 0.45033418460669566F, 1.0F, 0.47186628998249996F);
        escalar(g0, "cola6_7", 0.44897403551100257F, 1.0F, 0.4601608762622535F);
        escalar(g0, "cola6_8", 0.4465344915256102F, 1.0F, 0.5078261164129735F);
        escalar(g0, "cola6_9", 0.44353834252475804F, 1.0F, 0.4559927943943635F);
        escalar(g0, "cola6_10", 0.44070226542957885F, 1.0F, 0.4268097874310145F);
        escalar(g0, "cola6_11", 0.4389042629119156F, 1.0F, 0.45441553224625253F);
        escalar(g0, "cola7_0", 0.4423571808370081F, 1.0F, 0.43935043486854775F);
        escalar(g0, "cola7_1", 0.4448858894968515F, 1.0F, 0.4144175862900691F);
        escalar(g0, "cola7_2", 0.4488670904188476F, 1.0F, 0.4466324921006762F);
        escalar(g0, "cola7_3", 0.4530629101945996F, 1.0F, 0.5020045605102746F);
        escalar(g0, "cola7_4", 0.4564716884242958F, 1.0F, 0.45816792258365524F);
        escalar(g0, "cola7_5", 0.45836932162306604F, 1.0F, 0.4716344747434739F);
        escalar(g0, "cola7_6", 0.45836932162306604F, 1.0F, 0.47163447474347336F);
        escalar(g0, "cola7_7", 0.4564716884242958F, 1.0F, 0.4581679225836556F);
        escalar(g0, "cola7_8", 0.4530629101945996F, 1.0F, 0.5020045605102749F);
        escalar(g0, "cola7_9", 0.4488670904188476F, 1.0F, 0.4466324921006754F);
        escalar(g0, "cola7_10", 0.4448858894968515F, 1.0F, 0.4144175862900701F);
        escalar(g0, "cola7_11", 0.4423571808370081F, 1.0F, 0.43935043486854775F);
        escalar(g0, "cola8_0", 0.44689025284292133F, 1.0F, 0.4217569980724828F);
        escalar(g0, "cola8_1", 0.45036732251483996F, 1.0F, 0.5000473837279042F);
        escalar(g0, "cola8_2", 0.455828712938571F, 1.0F, 0.4358817388270652F);
        escalar(g0, "cola8_3", 0.46156723174124004F, 1.0F, 0.4953873280661014F);
        escalar(g0, "cola8_4", 0.466216511457173F, 1.0F, 0.4559204087945397F);
        escalar(g0, "cola8_5", 0.46879984498284816F, 1.0F, 0.4713741364521274F);
        escalar(g0, "cola8_6", 0.4687998449828479F, 1.0F, 0.47137413645212684F);
        escalar(g0, "cola8_7", 0.4662165114571728F, 1.0F, 0.4559204087945402F);
        escalar(g0, "cola8_8", 0.46156723174124004F, 1.0F, 0.4953873280661017F);
        escalar(g0, "cola8_9", 0.455828712938571F, 1.0F, 0.4358817388270644F);
        escalar(g0, "cola8_10", 0.45036732251483996F, 1.0F, 0.5000473837279055F);
        escalar(g0, "cola8_11", 0.44689025284292133F, 1.0F, 0.4217569980724828F);
        escalar(g0, "cola9_0", 0.45296577714928904F, 1.0F, 0.40145452698618256F);
        escalar(g0, "cola9_1", 0.45769523938495543F, 1.0F, 0.4794776861243242F);
        escalar(g0, "cola9_2", 0.46510144368579365F, 1.0F, 0.5084835206624984F);
        escalar(g0, "cola9_3", 0.4728539943067364F, 1.0F, 0.4880041613265936F);
        escalar(g0, "cola9_4", 0.47911347767760243F, 1.0F, 0.4534354705095698F);
        escalar(g0, "cola9_5", 0.48258341376404523F, 1.0F, 0.47108763897864836F);
        escalar(g0, "cola9_6", 0.4825834137640455F, 1.0F, 0.4710876389786477F);
        escalar(g0, "cola9_7", 0.47911347767760254F, 1.0F, 0.45343547050957017F);
        escalar(g0, "cola9_8", 0.47285399430673625F, 1.0F, 0.48800416132659397F);
        escalar(g0, "cola9_9", 0.46510144368579365F, 1.0F, 0.5084835206624974F);
        escalar(g0, "cola9_10", 0.45769523938495543F, 1.0F, 0.47947768612432545F);
        escalar(g0, "cola9_11", 0.45296577714928904F, 1.0F, 0.40145452698618256F);
        escalar(g0, "cola10_0", 0.461413258350398F, 1.0F, 0.378222273264361F);
        escalar(g0, "cola10_1", 0.46785043935610604F, 1.0F, 0.456198782048529F);
        escalar(g0, "cola10_2", 0.4778915868799645F, 1.0F, 0.49225477448202426F);
        escalar(g0, "cola10_3", 0.4883512486456861F, 1.0F, 0.4799038974749106F);
        escalar(g0, "cola10_4", 0.49675984941296064F, 1.0F, 0.4507371919624039F);
        escalar(g0, "cola10_5", 0.5014075854938976F, 1.0F, 0.4707781434252737F);
        escalar(g0, "cola10_6", 0.5014075854938976F, 1.0F, 0.4707781434252731F);
        escalar(g0, "cola10_7", 0.4967598494129608F, 1.0F, 0.4507371919624042F);
        escalar(g0, "cola10_8", 0.48835124864568624F, 1.0F, 0.479903897474911F);
        escalar(g0, "cola10_9", 0.4778915868799645F, 1.0F, 0.4922547744820232F);
        escalar(g0, "cola10_10", 0.46785043935610604F, 1.0F, 0.4561987820485303F);
        escalar(g0, "cola10_11", 0.461413258350398F, 1.0F, 0.378222273264361F);
        escalar(g0, "cola11_0", 0.473898384549541F, 1.0F, 0.3518047103174139F);
        escalar(g0, "cola11_1", 0.48279312356911747F, 1.0F, 0.43012159611155737F);
        escalar(g0, "cola11_2", 0.4965950463299232F, 1.0F, 0.4744450205978577F);
        escalar(g0, "cola11_3", 0.43789701390955255F, 1.0F, 0.47116860475026084F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "cola11_4", 0.4476847028250222F, 1.0F, 0.44786078571678195F);
        escalar(g0, "cola11_5", 0.4530745735966057F, 1.0F, 0.47045005105906956F);
        escalar(g0, "cola11_6", 0.4530745735966057F, 1.0F, 0.470450051059069F);
        escalar(g0, "cola11_7", 0.4476847028250222F, 1.0F, 0.4478607857167823F);
        escalar(g0, "cola11_8", 0.43789701390955255F, 1.0F, 0.4711686047502612F);
        escalar(g0, "cola11_9", 0.49659504632992335F, 1.0F, 0.4744450205978568F);
        escalar(g0, "cola11_10", 0.48279312356911763F, 1.0F, 0.4301215961115583F);
        escalar(g0, "cola11_11", 0.473898384549541F, 1.0F, 0.3518047103174139F);
        escalar(g0, "cola12_0", 0.49441478193287924F, 1.0F, 0.32195946129496156F);
        escalar(g0, "cola12_1", 0.5071940429021908F, 1.0F, 0.40126760980801107F);
        escalar(g0, "cola12_2", 0.4516075073825191F, 1.0F, 0.4552482209308552F);
        escalar(g0, "cola12_3", 0.46891090203713975F, 1.0F, 0.46194351819563684F);
        escalar(g0, "cola12_4", 0.48263681072253434F, 1.0F, 0.44486138355627497F);
        escalar(g0, "cola12_5", 0.49015784126196243F, 1.0F, 0.47010994592043953F);
        escalar(g0, "cola12_6", 0.49015784126196243F, 1.0F, 0.47010994592043903F);
        escalar(g0, "cola12_7", 0.48263681072253434F, 1.0F, 0.44486138355627525F);
        escalar(g0, "cola12_8", 0.46891090203713975F, 1.0F, 0.4619435181956371F);
        escalar(g0, "cola12_9", 0.4516075073825191F, 1.0F, 0.4552482209308546F);
        escalar(g0, "cola12_10", 0.5071940429021908F, 1.0F, 0.4012676098080118F);
        escalar(g0, "cola12_11", 0.49441478193287924F, 1.0F, 0.32195946129496156F);
        escalar(g0, "cola13_0", 0.45964616914500606F, 1.0F, 0.28871283421736404F);
        escalar(g0, "cola13_1", 0.47696806848774387F, 1.0F, 0.493420559718593F);
        escalar(g0, "cola13_2", 0.5033272831696042F, 1.0F, 0.43516868156376487F);
        escalar(g0, "cola13_3", 0.463740350717059F, 1.0F, 0.4525173765975788F);
        escalar(g0, "cola13_4", 0.48203447983015985F, 1.0F, 0.44183783647711083F);
        escalar(g0, "cola13_5", 0.49198654589025453F, 1.0F, 0.46976918069901735F);
        escalar(g0, "cola13_6", 0.49198654589025453F, 1.0F, 0.4697691806990167F);
        escalar(g0, "cola13_7", 0.48203447983015985F, 1.0F, 0.44183783647711117F);
        escalar(g0, "cola13_8", 0.463740350717059F, 1.0F, 0.4525173765975791F);
        escalar(g0, "cola13_9", 0.5033272831696041F, 1.0F, 0.4351686815637641F);
        escalar(g0, "cola13_10", 0.47696806848774376F, 1.0F, 0.49342055971859433F);
        escalar(g0, "cola13_11", 0.45964616914500606F, 1.0F, 0.28871283421736404F);
        escalar(g0, "cola14_0", 0.4723050432169937F, 1.0F, 0.5092362314215942F);
        escalar(g0, "cola14_1", 0.46051351511910765F, 1.0F, 0.4524397503671669F);
        escalar(g0, "cola14_2", 0.4642159987474824F, 1.0F, 0.4161480542202636F);
        escalar(g0, "cola14_3", 0.46645224289277376F, 1.0F, 0.4438043144854055F);
        escalar(g0, "cola14_4", 0.4954320386093091F, 1.0F, 0.4390796791575064F);
        escalar(g0, "cola14_5", 0.47445615998192947F, 1.0F, 0.46946009723887666F);
        escalar(g0, "cola14_6", 0.47445615998192947F, 1.0F, 0.46946009723887616F);
        escalar(g0, "cola14_7", 0.4954320386093091F, 1.0F, 0.43907967915750673F);
        escalar(g0, "cola14_8", 0.46645224289277376F, 1.0F, 0.4438043144854058F);
        escalar(g0, "cola14_9", 0.46421599874748254F, 1.0F, 0.41614805422026285F);
        escalar(g0, "cola14_10", 0.4605135151191078F, 1.0F, 0.45243975036716827F);
        escalar(g0, "cola14_11", 0.4723050432169937F, 1.0F, 0.5092362314215942F);
    }
}
