package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Cisterna remachada" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonPetrolero {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_petrolero"), "main"),
            LocomotoraMod.id("textures/entity/vagon_petrolero.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloVagonPetrolero::crearCapa,
            16.0F,
            ModeloVagonPetrolero::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -28.0F, 28.0F)));

    private ModeloVagonPetrolero() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
        escalas2(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("tanque_0", CubeListBuilder.create().texOffs(60, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -25.63941574638825F, 0.21583317759611748F, 3.13391661073409F, -0.13067572076552167F, -1.5119545064066395F));
        g.addOrReplaceChild("tanque_1", CubeListBuilder.create().texOffs(502, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -28.187235907269162F, 0.5512600651796105F, 3.1205056732718157F, -0.12919963671860013F, -1.4085436964090263F));
        g.addOrReplaceChild("tanque_2", CubeListBuilder.create().texOffs(144, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -30.52177282598743F, 0.8586076812388539F, 3.1016584927528466F, -0.12469269124863261F, -1.2599482502094526F));
        g.addOrReplaceChild("tanque_3", CubeListBuilder.create().texOffs(516, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -32.21791318063485F, 1.0819087951869575F, 3.0719203131992248F, -0.11090726153269773F, -1.0082418122168324F));
        g.addOrReplaceChild("tanque_4", CubeListBuilder.create().texOffs(360, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -33.109626935593774F, 1.1993051381603355F, 3.024251693943523F, -0.05814951451246432F, -0.4580365812894047F));
        g.addOrReplaceChild("tanque_5", CubeListBuilder.create().texOffs(642, 40).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -33.33814767487307F, 1.2293904642369735F, 3.010692959690218F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_6", CubeListBuilder.create().texOffs(376, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -33.109626935593774F, 1.1993051381603355F, 3.024251693943523F, 0.05814951451246432F, 0.4580365812894047F));
        g.addOrReplaceChild("tanque_7", CubeListBuilder.create().texOffs(534, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -32.217913180634845F, 1.0819087951869575F, 3.0719203131992248F, 0.11090726153269773F, 1.0082418122168324F));
        g.addOrReplaceChild("tanque_8", CubeListBuilder.create().texOffs(162, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -30.521772825987433F, 0.8586076812388539F, 3.1016584927528466F, 0.12469269124863261F, 1.2599482502094526F));
        g.addOrReplaceChild("tanque_9", CubeListBuilder.create().texOffs(520, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -28.187235907269162F, 0.5512600651796105F, 3.1205056732718157F, 0.12919963671860013F, 1.4085436964090263F));
        g.addOrReplaceChild("tanque_10", CubeListBuilder.create().texOffs(74, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -25.63941574638825F, 0.21583317759611748F, 3.13391661073409F, 0.13067572076552167F, 1.5119545064066395F));
        g.addOrReplaceChild("tanque_11", CubeListBuilder.create().texOffs(88, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -25.52769227253451F, 0.6327908584163675F, 3.1174460131803037F, -0.3919944953820007F, -1.5076623134644438F));
        g.addOrReplaceChild("tanque_12", CubeListBuilder.create().texOffs(538, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -27.901882699923284F, 1.6162127330971723F, 3.0753347337562262F, -0.3873555445183933F, -1.3969076996331418F));
        g.addOrReplaceChild("tanque_13", CubeListBuilder.create().texOffs(180, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -30.07732478563557F, 2.517310349156416F, 3.0165383879201846F, -0.37323955188139657F, -1.2387994884292057F));
        g.addOrReplaceChild("tanque_14", CubeListBuilder.create().texOffs(552, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -31.65787597811823F, 3.171996089107702F, 2.9254592245915614F, -0.3304803681602526F, -0.9759313383489541F));
        g.addOrReplaceChild("tanque_15", CubeListBuilder.create().texOffs(392, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -32.48882091430336F, 3.5161847512608295F, 2.786430577428536F, -0.17122512601958162F, -0.43065021590619695F));
        g.addOrReplaceChild("tanque_16", CubeListBuilder.create().texOffs(0, 51).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -32.701768342849164F, 3.604390464236973F, 2.748893571891071F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_17", CubeListBuilder.create().texOffs(408, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -32.48882091430337F, 3.5161847512608295F, 2.786430577428536F, 0.17122512601958162F, 0.43065021590619695F));
        g.addOrReplaceChild("tanque_18", CubeListBuilder.create().texOffs(570, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -31.65787597811823F, 3.171996089107702F, 2.9254592245915614F, 0.3304803681602526F, 0.9759313383489541F));
        g.addOrReplaceChild("tanque_19", CubeListBuilder.create().texOffs(198, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -30.07732478563557F, 2.517310349156416F, 3.0165383879201846F, 0.37323955188139657F, 1.2387994884292057F));
        g.addOrReplaceChild("tanque_20", CubeListBuilder.create().texOffs(556, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -27.90188269992328F, 1.6162127330971723F, 3.0753347337562262F, 0.3873555445183933F, 1.3969076996331418F));
        g.addOrReplaceChild("tanque_21", CubeListBuilder.create().texOffs(102, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -25.52769227253451F, 0.6327908584163674F, 3.1174460131803037F, 0.3919944953820007F, 1.5076623134644438F));
        g.addOrReplaceChild("tanque_22", CubeListBuilder.create().texOffs(116, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -25.31185909493839F, 1.0066248879718795F, 3.09688233448035F, -0.6531936919684331F, -1.4973099403710963F));
        g.addOrReplaceChild("tanque_23", CubeListBuilder.create().texOffs(574, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -27.35062263474367F, 2.5710231741719882F, 3.0192840644189154F, -0.6446259398141242F, -1.3690165877347142F));
        g.addOrReplaceChild("tanque_24", CubeListBuilder.create().texOffs(216, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -29.218717104396717F, 4.004462476831014F, 2.9127933911408865F, -0.6187884661269457F, -1.1890159227971913F));
        g.addOrReplaceChild("tanque_25", CubeListBuilder.create().texOffs(588, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -30.575967182931272F, 5.045917091527143F, 2.75529075086925F, -0.5424091906342444F, -0.9034486197340212F));
        g.addOrReplaceChild("tanque_26", CubeListBuilder.create().texOffs(424, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -31.28951577614303F, 5.593442184332943F, 2.539597676218061F, -0.27448458218811267F, -0.37575844369007927F));
        g.addOrReplaceChild("tanque_27", CubeListBuilder.create().texOffs(258, 51).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -31.472377878612185F, 5.733757210636099F, 2.4870941840919185F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_28", CubeListBuilder.create().texOffs(440, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -31.289515776143027F, 5.593442184332942F, 2.539597676218061F, 0.27448458218811267F, 0.37575844369007927F));
        g.addOrReplaceChild("tanque_29", CubeListBuilder.create().texOffs(606, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -30.575967182931276F, 5.0459170915271425F, 2.75529075086925F, 0.5424091906342444F, 0.9034486197340212F));
        g.addOrReplaceChild("tanque_30", CubeListBuilder.create().texOffs(234, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -29.218717104396717F, 4.004462476831014F, 2.9127933911408865F, 0.6187884661269457F, 1.1890159227971913F));
        g.addOrReplaceChild("tanque_31", CubeListBuilder.create().texOffs(592, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -27.350622634743672F, 2.5710231741719887F, 3.0192840644189154F, 0.6446259398141242F, 1.3690165877347142F));
        g.addOrReplaceChild("tanque_32", CubeListBuilder.create().texOffs(130, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -25.31185909493839F, 1.0066248879718795F, 3.09688233448035F, 0.6531936919684331F, 1.4973099403710963F));
        g.addOrReplaceChild("tanque_33", CubeListBuilder.create().texOffs(144, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -25.00662488797188F, 1.3118590949383901F, 3.065751913109093F, -0.9140839112755557F, -1.4751470009149494F));
        g.addOrReplaceChild("tanque_34", CubeListBuilder.create().texOffs(610, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -26.57102317417199F, 3.35062263474367F, 2.9357782900537206F, -0.8996470368885585F, -1.3102632312840208F));
        g.addOrReplaceChild("tanque_35", CubeListBuilder.create().texOffs(252, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -28.004462476831016F, 5.218717104396717F, 2.7649562816731486F, -0.8570799341351946F, -1.088747993786975F));
        g.addOrReplaceChild("tanque_36", CubeListBuilder.create().texOffs(624, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -29.045917091527144F, 6.575967182931274F, 2.5370657404403785F, -0.7378870845282003F, -0.7721413459731633F));
        g.addOrReplaceChild("tanque_37", CubeListBuilder.create().texOffs(456, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -29.593442184332943F, 7.289515776143027F, 2.2793168452454324F, -0.3610324850495143F, -0.2939435953240309F));
        g.addOrReplaceChild("tanque_38", CubeListBuilder.create().texOffs(516, 51).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -29.7337572106361F, 7.472377878612184F, 2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_39", CubeListBuilder.create().texOffs(472, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -29.593442184332943F, 7.289515776143029F, 2.2793168452454324F, 0.3610324850495143F, 0.2939435953240309F));
        g.addOrReplaceChild("tanque_40", CubeListBuilder.create().texOffs(642, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -29.045917091527144F, 6.575967182931273F, 2.5370657404403785F, 0.7378870845282003F, 0.7721413459731633F));
        g.addOrReplaceChild("tanque_41", CubeListBuilder.create().texOffs(270, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -28.004462476831016F, 5.218717104396717F, 2.7649562816731486F, 0.8570799341351946F, 1.088747993786975F));
        g.addOrReplaceChild("tanque_42", CubeListBuilder.create().texOffs(628, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -26.57102317417199F, 3.35062263474367F, 2.9357782900537206F, 0.8996470368885585F, 1.3102632312840208F));
        g.addOrReplaceChild("tanque_43", CubeListBuilder.create().texOffs(158, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -25.00662488797188F, 1.3118590949383897F, 3.065751913109093F, 0.9140839112755557F, 1.4751470009149494F));
        g.addOrReplaceChild("tanque_44", CubeListBuilder.create().texOffs(172, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -24.63279085841637F, 1.5276922725345075F, 3.0017471900639143F, -1.1740101685179016F, -1.419343239816467F));
        g.addOrReplaceChild("tanque_45", CubeListBuilder.create().texOffs(646, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -25.61621273309717F, 3.9018826999232807F, 2.7725644640655718F, -1.1480068399802303F, -1.169698968206758F));
        g.addOrReplaceChild("tanque_46", CubeListBuilder.create().texOffs(288, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -26.517310349156418F, 6.077324785635571F, 2.5092602915710285F, -1.0765025963334227F, -0.876657409335284F));
        g.addOrReplaceChild("tanque_47", CubeListBuilder.create().texOffs(660, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -27.1719960891077F, 7.657875978118231F, 2.234110436481951F, -0.9001274374613577F, -0.549324532737704F));
        g.addOrReplaceChild("tanque_48", CubeListBuilder.create().texOffs(488, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -27.51618475126083F, 8.488820914303364F, 2.0040775299547993F, -0.42394246286923915F, -0.18804484041058164F));
        g.addOrReplaceChild("tanque_49", CubeListBuilder.create().texOffs(0, 57).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -27.60439046423697F, 8.701768342849157F, 1.963495408493621F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_50", CubeListBuilder.create().texOffs(504, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -27.51618475126083F, 8.488820914303362F, 2.0040775299547993F, 0.42394246286923915F, 0.18804484041058164F));
        g.addOrReplaceChild("tanque_51", CubeListBuilder.create().texOffs(678, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -27.171996089107704F, 7.6578759781182315F, 2.234110436481951F, 0.9001274374613577F, 0.549324532737704F));
        g.addOrReplaceChild("tanque_52", CubeListBuilder.create().texOffs(306, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -26.517310349156418F, 6.077324785635571F, 2.5092602915710285F, 1.0765025963334227F, 0.876657409335284F));
        g.addOrReplaceChild("tanque_53", CubeListBuilder.create().texOffs(664, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -25.61621273309717F, 3.9018826999232807F, 2.7725644640655718F, 1.1480068399802303F, 1.169698968206758F));
        g.addOrReplaceChild("tanque_54", CubeListBuilder.create().texOffs(186, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -24.63279085841637F, 1.5276922725345075F, 3.0017471900639143F, 1.1740101685179016F, 1.419343239816467F));
        g.addOrReplaceChild("tanque_55", CubeListBuilder.create().texOffs(200, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -24.215833177596117F, 1.6394157463882473F, 2.7246740697245206F, -1.4275525873227906F, -1.1500528854755139F));
        g.addOrReplaceChild("tanque_56", CubeListBuilder.create().texOffs(682, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -24.551260065179612F, 4.187235907269161F, 2.2587043438762424F, -1.3637418416201268F, -0.6773401222187035F));
        g.addOrReplaceChild("tanque_57", CubeListBuilder.create().texOffs(324, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -24.858607681238855F, 6.52177282598743F, 1.9800912182546129F, -1.2366253581302762F, -0.38892327927343473F));
        g.addOrReplaceChild("tanque_58", CubeListBuilder.create().texOffs(696, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -25.08190879518696F, 8.217913180634847F, 1.8142376717866382F, -0.9985715299994637F, -0.20584443191907092F));
        g.addOrReplaceChild("tanque_59", CubeListBuilder.create().texOffs(520, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -25.199305138160334F, 9.109626935593774F, 1.7167813422817704F, -0.4572034706522001F, -0.06481452715783166F));
        g.addOrReplaceChild("tanque_60", CubeListBuilder.create().texOffs(258, 57).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -25.229390464236975F, 9.338147674873074F, 1.7016960206944716F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_61", CubeListBuilder.create().texOffs(536, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -25.199305138160337F, 9.109626935593774F, 1.7167813422817704F, 0.4572034706522001F, 0.06481452715783166F));
        g.addOrReplaceChild("tanque_62", CubeListBuilder.create().texOffs(714, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -25.08190879518696F, 8.217913180634845F, 1.8142376717866382F, 0.9985715299994637F, 0.20584443191907092F));
        g.addOrReplaceChild("tanque_63", CubeListBuilder.create().texOffs(342, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -24.858607681238855F, 6.52177282598743F, 1.9800912182546129F, 1.2366253581302762F, 0.38892327927343473F));
        g.addOrReplaceChild("tanque_64", CubeListBuilder.create().texOffs(700, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -24.551260065179612F, 4.1872359072691605F, 2.2587043438762424F, 1.3637418416201268F, 0.6773401222187035F));
        g.addOrReplaceChild("tanque_65", CubeListBuilder.create().texOffs(214, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -24.215833177596117F, 1.6394157463882473F, 2.7246740697245206F, 1.4275525873227906F, 1.1500528854755139F));
        g.addOrReplaceChild("tanque_66", CubeListBuilder.create().texOffs(228, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -23.784166822403886F, 1.6394157463882475F, 0.4169185838652727F, -1.4275525873227906F, 1.1500528854755139F));
        g.addOrReplaceChild("tanque_67", CubeListBuilder.create().texOffs(718, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -23.44873993482039F, 4.187235907269161F, 0.8828883097135508F, -1.3637418416201268F, 0.6773401222187035F));
        g.addOrReplaceChild("tanque_68", CubeListBuilder.create().texOffs(360, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -23.14139231876115F, 6.521772825987431F, 1.1615014353351814F, -1.2366253581302762F, 0.38892327927343423F));
        g.addOrReplaceChild("tanque_69", CubeListBuilder.create().texOffs(732, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -22.918091204813045F, 8.217913180634845F, 1.3273549818031556F, -0.9985715299994642F, 0.20584443191907076F));
        g.addOrReplaceChild("tanque_70", CubeListBuilder.create().texOffs(552, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -22.800694861839666F, 9.109626935593774F, 1.4248113113080234F, -0.4572034706521999F, 0.06481452715783141F));
        g.addOrReplaceChild("tanque_71", CubeListBuilder.create().texOffs(516, 57).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -22.77060953576303F, 9.338147674873074F, 1.4398966328953222F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_72", CubeListBuilder.create().texOffs(568, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -22.800694861839666F, 9.109626935593774F, 1.4248113113080234F, 0.4572034706521999F, -0.06481452715783141F));
        g.addOrReplaceChild("tanque_73", CubeListBuilder.create().texOffs(750, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -22.918091204813045F, 8.217913180634847F, 1.3273549818031556F, 0.9985715299994642F, -0.20584443191907076F));
        g.addOrReplaceChild("tanque_74", CubeListBuilder.create().texOffs(378, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -23.14139231876115F, 6.521772825987431F, 1.1615014353351814F, 1.2366253581302762F, -0.38892327927343423F));
        g.addOrReplaceChild("tanque_75", CubeListBuilder.create().texOffs(736, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -23.44873993482039F, 4.187235907269162F, 0.8828883097135508F, 1.3637418416201268F, -0.6773401222187035F));
        g.addOrReplaceChild("tanque_76", CubeListBuilder.create().texOffs(242, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -23.784166822403883F, 1.6394157463882475F, 0.4169185838652727F, 1.4275525873227906F, -1.1500528854755139F));
        g.addOrReplaceChild("tanque_77", CubeListBuilder.create().texOffs(256, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -23.367209141583636F, 1.5276922725345077F, 0.13984546352587907F, -1.1740101685179016F, 1.419343239816467F));
        g.addOrReplaceChild("tanque_78", CubeListBuilder.create().texOffs(754, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -22.38378726690283F, 3.901882699923281F, 0.3690281895242216F, -1.1480068399802303F, 1.169698968206758F));
        g.addOrReplaceChild("tanque_79", CubeListBuilder.create().texOffs(396, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -21.482689650843586F, 6.077324785635571F, 0.6323323620187651F, -1.0765025963334232F, 0.8766574093352836F));
        g.addOrReplaceChild("tanque_80", CubeListBuilder.create().texOffs(768, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -20.8280039108923F, 7.657875978118233F, 0.9074822171078422F, -0.900127437461358F, 0.5493245327377042F));
        g.addOrReplaceChild("tanque_81", CubeListBuilder.create().texOffs(584, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -20.483815248739173F, 8.488820914303364F, 1.1375151236349943F, -0.42394246286923953F, 0.18804484041058162F));
        g.addOrReplaceChild("tanque_82", CubeListBuilder.create().texOffs(0, 63).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -20.39560953576303F, 8.70176834284916F, 1.1780972450961733F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_83", CubeListBuilder.create().texOffs(600, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -20.483815248739173F, 8.488820914303366F, 1.1375151236349943F, 0.42394246286923953F, -0.18804484041058162F));
        g.addOrReplaceChild("tanque_84", CubeListBuilder.create().texOffs(786, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -20.8280039108923F, 7.657875978118232F, 0.9074822171078422F, 0.900127437461358F, -0.5493245327377042F));
        g.addOrReplaceChild("tanque_85", CubeListBuilder.create().texOffs(414, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -21.48268965084359F, 6.077324785635572F, 0.6323323620187651F, 1.0765025963334232F, -0.8766574093352836F));
        g.addOrReplaceChild("tanque_86", CubeListBuilder.create().texOffs(772, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -22.38378726690283F, 3.901882699923281F, 0.3690281895242216F, 1.1480068399802303F, -1.169698968206758F));
        g.addOrReplaceChild("tanque_87", CubeListBuilder.create().texOffs(270, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -23.367209141583633F, 1.5276922725345077F, 0.13984546352587907F, 1.1740101685179016F, -1.419343239816467F));
        g.addOrReplaceChild("tanque_88", CubeListBuilder.create().texOffs(284, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -22.99337511202812F, 1.3118590949383901F, 0.07584074048070037F, -0.9140839112755557F, 1.4751470009149494F));
        g.addOrReplaceChild("tanque_89", CubeListBuilder.create().texOffs(790, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -21.428976825828013F, 3.3506226347436705F, 0.20581436353607246F, -0.8996470368885585F, 1.3102632312840208F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("tanque_90", CubeListBuilder.create().texOffs(432, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -19.995537523168984F, 5.218717104396718F, 0.37663637191664534F, -0.857079934135195F, 1.0887479937869744F));
        g.addOrReplaceChild("tanque_91", CubeListBuilder.create().texOffs(804, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -18.954082908472856F, 6.575967182931275F, 0.6045269131494144F, -0.7378870845282006F, 0.7721413459731639F));
        g.addOrReplaceChild("tanque_92", CubeListBuilder.create().texOffs(616, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -18.406557815667057F, 7.28951577614303F, 0.8622758083443608F, -0.3610324850495145F, 0.29394359532403114F));
        g.addOrReplaceChild("tanque_93", CubeListBuilder.create().texOffs(258, 63).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -18.2662427893639F, 7.4723778786121855F, 0.916297857297022F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_94", CubeListBuilder.create().texOffs(632, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -18.406557815667057F, 7.28951577614303F, 0.8622758083443608F, 0.3610324850495145F, -0.29394359532403114F));
        g.addOrReplaceChild("tanque_95", CubeListBuilder.create().texOffs(822, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -18.954082908472856F, 6.575967182931275F, 0.6045269131494144F, 0.7378870845282006F, -0.7721413459731639F));
        g.addOrReplaceChild("tanque_96", CubeListBuilder.create().texOffs(450, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -19.995537523168988F, 5.218717104396718F, 0.37663637191664534F, 0.857079934135195F, -1.0887479937869744F));
        g.addOrReplaceChild("tanque_97", CubeListBuilder.create().texOffs(808, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -21.42897682582801F, 3.3506226347436705F, 0.20581436353607246F, 0.8996470368885585F, -1.3102632312840208F));
        g.addOrReplaceChild("tanque_98", CubeListBuilder.create().texOffs(298, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -22.99337511202812F, 1.3118590949383901F, 0.07584074048070037F, 0.9140839112755557F, -1.4751470009149494F));
        g.addOrReplaceChild("tanque_99", CubeListBuilder.create().texOffs(312, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -22.688140905061612F, 1.00662488797188F, 0.044710319109443064F, -0.6531936919684331F, 1.4973099403710963F));
        g.addOrReplaceChild("tanque_100", CubeListBuilder.create().texOffs(826, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -20.649377365256328F, 2.5710231741719896F, 0.12230858917087785F, -0.6446259398141247F, 1.3690165877347142F));
        g.addOrReplaceChild("tanque_101", CubeListBuilder.create().texOffs(468, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -18.781282895603283F, 4.004462476831016F, 0.22879926244890686F, -0.6187884661269462F, 1.1890159227971913F));
        g.addOrReplaceChild("tanque_102", CubeListBuilder.create().texOffs(840, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -17.424032817068728F, 5.045917091527145F, 0.3863019027205438F, -0.5424091906342446F, 0.9034486197340211F));
        g.addOrReplaceChild("tanque_103", CubeListBuilder.create().texOffs(648, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -16.710484223856973F, 5.593442184332945F, 0.6019949773717322F, -0.27448458218811117F, 0.3757584436900775F));
        g.addOrReplaceChild("tanque_104", CubeListBuilder.create().texOffs(516, 63).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -16.527622121387818F, 5.733757210636103F, 0.6544984694978746F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_105", CubeListBuilder.create().texOffs(664, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -16.710484223856973F, 5.593442184332945F, 0.6019949773717322F, 0.27448458218811117F, -0.3757584436900775F));
        g.addOrReplaceChild("tanque_106", CubeListBuilder.create().texOffs(858, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -17.424032817068728F, 5.045917091527145F, 0.3863019027205438F, 0.5424091906342446F, -0.9034486197340211F));
        g.addOrReplaceChild("tanque_107", CubeListBuilder.create().texOffs(486, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -18.781282895603283F, 4.004462476831016F, 0.22879926244890686F, 0.6187884661269462F, -1.1890159227971913F));
        g.addOrReplaceChild("tanque_108", CubeListBuilder.create().texOffs(844, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -20.649377365256328F, 2.5710231741719896F, 0.12230858917087785F, 0.6446259398141247F, -1.3690165877347142F));
        g.addOrReplaceChild("tanque_109", CubeListBuilder.create().texOffs(326, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -22.68814090506161F, 1.00662488797188F, 0.04471031910944284F, 0.6531936919684328F, -1.4973099403710963F));
        g.addOrReplaceChild("tanque_110", CubeListBuilder.create().texOffs(340, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -22.47230772746549F, 0.632790858416368F, 0.024146640409489672F, -0.39199449538200104F, 1.5076623134644438F));
        g.addOrReplaceChild("tanque_111", CubeListBuilder.create().texOffs(862, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -20.09811730007672F, 1.6162127330971736F, 0.066257919833567F, -0.38735554451839416F, 1.3969076996331415F));
        g.addOrReplaceChild("tanque_112", CubeListBuilder.create().texOffs(504, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -17.922675214364432F, 2.5173103491564177F, 0.12505426566960823F, -0.3732395518813964F, 1.2387994884292062F));
        g.addOrReplaceChild("tanque_113", CubeListBuilder.create().texOffs(876, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -16.34212402188177F, 3.171996089107705F, 0.21613342899823224F, -0.3304803681602528F, 0.9759313383489527F));
        g.addOrReplaceChild("tanque_114", CubeListBuilder.create().texOffs(680, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -15.511179085696638F, 3.516184751260833F, 0.355162076161258F, -0.17122512601958226F, 0.4306502159061976F));
        g.addOrReplaceChild("tanque_115", CubeListBuilder.create().texOffs(0, 69).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -15.298231657150843F, 3.6043904642369764F, 0.3926990816987246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_116", CubeListBuilder.create().texOffs(696, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -15.511179085696638F, 3.516184751260833F, 0.355162076161258F, 0.17122512601958226F, -0.4306502159061976F));
        g.addOrReplaceChild("tanque_117", CubeListBuilder.create().texOffs(894, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -16.34212402188177F, 3.1719960891077053F, 0.21613342899823224F, 0.3304803681602528F, -0.9759313383489527F));
        g.addOrReplaceChild("tanque_118", CubeListBuilder.create().texOffs(522, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -17.922675214364432F, 2.5173103491564177F, 0.12505426566960823F, 0.3732395518813964F, -1.2387994884292062F));
        g.addOrReplaceChild("tanque_119", CubeListBuilder.create().texOffs(880, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -20.09811730007672F, 1.6162127330971736F, 0.066257919833567F, 0.38735554451839416F, -1.3969076996331415F));
        g.addOrReplaceChild("tanque_120", CubeListBuilder.create().texOffs(354, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -22.47230772746549F, 0.632790858416368F, 0.02414664040948987F, 0.39199449538200076F, -1.5076623134644438F));
        g.addOrReplaceChild("tanque_121", CubeListBuilder.create().texOffs(368, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -22.360584253611755F, 0.21583317759611784F, 0.007676042855703135F, -0.1306757207655219F, 1.5119545064066395F));
        g.addOrReplaceChild("tanque_122", CubeListBuilder.create().texOffs(898, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -19.812764092730838F, 0.5512600651796115F, 0.02108698031797767F, -0.12919963671860038F, 1.408543696409026F));
        g.addOrReplaceChild("tanque_123", CubeListBuilder.create().texOffs(540, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -17.478227174012574F, 0.8586076812388552F, 0.039934160836946786F, -0.12469269124863308F, 1.259948250209453F));
        g.addOrReplaceChild("tanque_124", CubeListBuilder.create().texOffs(912, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -15.782086819365153F, 1.0819087951869593F, 0.0696723403905691F, -0.11090726153269811F, 1.008241812216831F));
        g.addOrReplaceChild("tanque_125", CubeListBuilder.create().texOffs(712, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -14.890373064406226F, 1.1993051381603372F, 0.11734095964627038F, -0.05814951451246496F, 0.45803658128940766F));
        g.addOrReplaceChild("tanque_126", CubeListBuilder.create().texOffs(258, 69).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -14.661852325126926F, 1.2293904642369753F, 0.13089969389957487F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_127", CubeListBuilder.create().texOffs(728, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -14.890373064406226F, 1.1993051381603375F, 0.11734095964627038F, 0.05814951451246496F, -0.45803658128940766F));
        g.addOrReplaceChild("tanque_128", CubeListBuilder.create().texOffs(930, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -15.782086819365153F, 1.0819087951869593F, 0.0696723403905691F, 0.11090726153269811F, -1.008241812216831F));
        g.addOrReplaceChild("tanque_129", CubeListBuilder.create().texOffs(558, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -17.47822717401257F, 0.8586076812388553F, 0.039934160836946786F, 0.12469269124863308F, -1.259948250209453F));
        g.addOrReplaceChild("tanque_130", CubeListBuilder.create().texOffs(916, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -19.812764092730838F, 0.5512600651796115F, 0.02108698031797767F, 0.12919963671860038F, -1.408543696409026F));
        g.addOrReplaceChild("tanque_131", CubeListBuilder.create().texOffs(382, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -22.360584253611755F, 0.2158331775961178F, 0.007676042855703136F, 0.1306757207655219F, -1.5119545064066395F));
        g.addOrReplaceChild("tanque_132", CubeListBuilder.create().texOffs(396, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -22.36058425361175F, -0.21583317759611706F, -0.007676042855703147F, 0.1306757207655214F, 1.5119545064066395F));
        g.addOrReplaceChild("tanque_133", CubeListBuilder.create().texOffs(934, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -19.812764092730838F, -0.5512600651796095F, -0.021086980317977438F, 0.12919963671859983F, 1.4085436964090263F));
        g.addOrReplaceChild("tanque_134", CubeListBuilder.create().texOffs(576, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -17.47822717401257F, -0.8586076812388523F, -0.03993416083694663F, 0.12469269124863261F, 1.2599482502094526F));
        g.addOrReplaceChild("tanque_135", CubeListBuilder.create().texOffs(948, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -15.782086819365151F, -1.0819087951869555F, -0.06967234039056903F, 0.11090726153269788F, 1.0082418122168315F));
        g.addOrReplaceChild("tanque_136", CubeListBuilder.create().texOffs(744, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -14.890373064406226F, -1.1993051381603332F, -0.11734095964626992F, 0.05814951451246474F, 0.45803658128940766F));
        g.addOrReplaceChild("tanque_137", CubeListBuilder.create().texOffs(516, 69).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -14.661852325126926F, -1.229390464236971F, -0.13089969389957437F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_138", CubeListBuilder.create().texOffs(760, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -14.890373064406226F, -1.1993051381603332F, -0.11734095964626992F, -0.05814951451246474F, -0.45803658128940766F));
        g.addOrReplaceChild("tanque_139", CubeListBuilder.create().texOffs(966, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -15.782086819365155F, -1.0819087951869555F, -0.06967234039056903F, -0.11090726153269788F, -1.0082418122168315F));
        g.addOrReplaceChild("tanque_140", CubeListBuilder.create().texOffs(594, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -17.478227174012567F, -0.8586076812388523F, -0.03993416083694663F, -0.12469269124863261F, -1.2599482502094526F));
        g.addOrReplaceChild("tanque_141", CubeListBuilder.create().texOffs(952, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -19.812764092730838F, -0.5512600651796093F, -0.021086980317977438F, -0.12919963671859983F, -1.4085436964090263F));
        g.addOrReplaceChild("tanque_142", CubeListBuilder.create().texOffs(410, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -22.36058425361175F, -0.21583317759611706F, -0.007676042855703147F, -0.13067572076552142F, -1.5119545064066395F));
        g.addOrReplaceChild("tanque_143", CubeListBuilder.create().texOffs(424, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -22.47230772746549F, -0.6327908584163667F, -0.024146640409489693F, 0.3919944953820003F, 1.5076623134644438F));
        g.addOrReplaceChild("tanque_144", CubeListBuilder.create().texOffs(970, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -20.098117300076716F, -1.6162127330971703F, -0.06625791983356699F, 0.3873555445183929F, 1.3969076996331418F));
        g.addOrReplaceChild("tanque_145", CubeListBuilder.create().texOffs(612, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -17.922675214364425F, -2.5173103491564124F, -0.1250542656696082F, 0.37323955188139574F, 1.238799488429206F));
        g.addOrReplaceChild("tanque_146", CubeListBuilder.create().texOffs(984, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -16.342124021881766F, -3.171996089107698F, -0.21613342899823104F, 0.3304803681602518F, 0.9759313383489536F));
        g.addOrReplaceChild("tanque_147", CubeListBuilder.create().texOffs(776, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -15.511179085696632F, -3.516184751260826F, -0.35516207616125706F, 0.1712251260195814F, 0.4306502159061969F));
        g.addOrReplaceChild("tanque_148", CubeListBuilder.create().texOffs(0, 75).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -15.29823165715084F, -3.6043904642369684F, -0.3926990816987238F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_149", CubeListBuilder.create().texOffs(792, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -15.511179085696634F, -3.516184751260825F, -0.35516207616125706F, -0.1712251260195814F, -0.4306502159061969F));
        g.addOrReplaceChild("tanque_150", CubeListBuilder.create().texOffs(1002, 93).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -16.342124021881766F, -3.171996089107698F, -0.21613342899823104F, -0.3304803681602518F, -0.9759313383489536F));
        g.addOrReplaceChild("tanque_151", CubeListBuilder.create().texOffs(630, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -17.922675214364425F, -2.5173103491564124F, -0.1250542656696082F, -0.37323955188139574F, -1.238799488429206F));
        g.addOrReplaceChild("tanque_152", CubeListBuilder.create().texOffs(988, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -20.098117300076716F, -1.6162127330971705F, -0.06625791983356699F, -0.3873555445183929F, -1.3969076996331418F));
        g.addOrReplaceChild("tanque_153", CubeListBuilder.create().texOffs(438, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -22.47230772746549F, -0.6327908584163667F, -0.02414664040948969F, -0.39199449538200026F, -1.5076623134644438F));
        g.addOrReplaceChild("tanque_154", CubeListBuilder.create().texOffs(452, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -22.68814090506161F, -1.006624887971879F, -0.04471031910944296F, 0.6531936919684328F, 1.4973099403710963F));
        g.addOrReplaceChild("tanque_155", CubeListBuilder.create().texOffs(1006, 111).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -20.649377365256328F, -2.5710231741719873F, -0.12230858917087765F, 0.644625939814124F, 1.3690165877347142F));
        g.addOrReplaceChild("tanque_156", CubeListBuilder.create().texOffs(648, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -18.781282895603283F, -4.004462476831012F, -0.22879926244890622F, 0.6187884661269453F, 1.1890159227971915F));
        g.addOrReplaceChild("tanque_157", CubeListBuilder.create().texOffs(0, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -17.424032817068724F, -5.045917091527141F, -0.3863019027205436F, 0.5424091906342445F, 0.9034486197340212F));
        g.addOrReplaceChild("tanque_158", CubeListBuilder.create().texOffs(808, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -16.71048422385697F, -5.59344218433294F, -0.6019949773717318F, 0.27448458218811106F, 0.37575844369007777F));
        g.addOrReplaceChild("tanque_159", CubeListBuilder.create().texOffs(258, 75).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -16.527622121387815F, -5.733757210636098F, -0.6544984694978729F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_160", CubeListBuilder.create().texOffs(824, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -16.71048422385697F, -5.5934421843329405F, -0.6019949773717318F, -0.27448458218811106F, -0.37575844369007777F));
        g.addOrReplaceChild("tanque_161", CubeListBuilder.create().texOffs(18, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -17.424032817068724F, -5.045917091527141F, -0.3863019027205436F, -0.5424091906342445F, -0.9034486197340212F));
        g.addOrReplaceChild("tanque_162", CubeListBuilder.create().texOffs(666, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -18.781282895603283F, -4.004462476831012F, -0.22879926244890622F, -0.6187884661269453F, -1.1890159227971915F));
        g.addOrReplaceChild("tanque_163", CubeListBuilder.create().texOffs(0, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -20.649377365256328F, -2.5710231741719873F, -0.12230858917087765F, -0.644625939814124F, -1.3690165877347142F));
        g.addOrReplaceChild("tanque_164", CubeListBuilder.create().texOffs(466, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -22.68814090506161F, -1.006624887971879F, -0.04471031910944296F, -0.6531936919684328F, -1.4973099403710963F));
        g.addOrReplaceChild("tanque_165", CubeListBuilder.create().texOffs(480, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -22.99337511202812F, -1.3118590949383897F, -0.07584074048070039F, 0.9140839112755554F, 1.4751470009149494F));
        g.addOrReplaceChild("tanque_166", CubeListBuilder.create().texOffs(18, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -21.42897682582801F, -3.3506226347436696F, -0.20581436353607224F, 0.8996470368885582F, 1.3102632312840212F));
        g.addOrReplaceChild("tanque_167", CubeListBuilder.create().texOffs(684, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -19.995537523168984F, -5.218717104396716F, -0.3766363719166445F, 0.857079934135194F, 1.0887479937869753F));
        g.addOrReplaceChild("tanque_168", CubeListBuilder.create().texOffs(36, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -18.954082908472856F, -6.575967182931273F, -0.6045269131494143F, 0.7378870845282004F, 0.7721413459731633F));
        g.addOrReplaceChild("tanque_169", CubeListBuilder.create().texOffs(840, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -18.406557815667057F, -7.289515776143027F, -0.8622758083443607F, 0.36103248504951424F, 0.293943595324031F));
        g.addOrReplaceChild("tanque_170", CubeListBuilder.create().texOffs(516, 75).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -18.266242789363897F, -7.472377878612183F, -0.9162978572970227F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_171", CubeListBuilder.create().texOffs(856, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -18.406557815667053F, -7.289515776143027F, -0.8622758083443607F, -0.36103248504951424F, -0.293943595324031F));
        g.addOrReplaceChild("tanque_172", CubeListBuilder.create().texOffs(54, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -18.954082908472856F, -6.575967182931272F, -0.6045269131494143F, -0.7378870845282004F, -0.7721413459731633F));
        g.addOrReplaceChild("tanque_173", CubeListBuilder.create().texOffs(702, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -19.995537523168984F, -5.218717104396716F, -0.3766363719166445F, -0.857079934135194F, -1.0887479937869753F));
        g.addOrReplaceChild("tanque_174", CubeListBuilder.create().texOffs(36, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -21.42897682582801F, -3.35062263474367F, -0.20581436353607224F, -0.8996470368885582F, -1.3102632312840212F));
        g.addOrReplaceChild("tanque_175", CubeListBuilder.create().texOffs(494, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -22.99337511202812F, -1.3118590949383897F, -0.0758407404807004F, -0.9140839112755554F, -1.4751470009149494F));
        g.addOrReplaceChild("tanque_176", CubeListBuilder.create().texOffs(508, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -23.36720914158363F, -1.527692272534507F, -0.1398454635258789F, 1.1740101685179016F, 1.419343239816467F));
        g.addOrReplaceChild("tanque_177", CubeListBuilder.create().texOffs(54, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -22.38378726690282F, -3.90188269992328F, -0.36902818952422034F, 1.1480068399802292F, 1.1696989682067593F));
        g.addOrReplaceChild("tanque_178", CubeListBuilder.create().texOffs(720, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -21.482689650843582F, -6.077324785635569F, -0.632332362018764F, 1.0765025963334225F, 0.8766574093352845F));
        g.addOrReplaceChild("tanque_179", CubeListBuilder.create().texOffs(72, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -20.828003910892292F, -7.65787597811823F, -0.9074822171078414F, 0.9001274374613575F, 0.549324532737705F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("tanque_180", CubeListBuilder.create().texOffs(872, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -20.483815248739162F, -8.488820914303362F, -1.1375151236349932F, 0.4239424628692391F, 0.1880448404105819F));
        g.addOrReplaceChild("tanque_181", CubeListBuilder.create().texOffs(0, 81).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -20.395609535763022F, -8.701768342849157F, -1.1780972450961718F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_182", CubeListBuilder.create().texOffs(888, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -20.483815248739162F, -8.488820914303362F, -1.1375151236349932F, -0.4239424628692391F, -0.1880448404105819F));
        g.addOrReplaceChild("tanque_183", CubeListBuilder.create().texOffs(90, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -20.828003910892292F, -7.65787597811823F, -0.9074822171078414F, -0.9001274374613575F, -0.549324532737705F));
        g.addOrReplaceChild("tanque_184", CubeListBuilder.create().texOffs(738, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -21.482689650843582F, -6.077324785635569F, -0.632332362018764F, -1.0765025963334225F, -0.8766574093352845F));
        g.addOrReplaceChild("tanque_185", CubeListBuilder.create().texOffs(72, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -22.38378726690283F, -3.90188269992328F, -0.36902818952422034F, -1.1480068399802292F, -1.1696989682067593F));
        g.addOrReplaceChild("tanque_186", CubeListBuilder.create().texOffs(522, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -23.36720914158363F, -1.527692272534507F, -0.1398454635258789F, -1.1740101685179016F, -1.419343239816467F));
        g.addOrReplaceChild("tanque_187", CubeListBuilder.create().texOffs(536, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -23.784166822403883F, -1.6394157463882473F, -0.4169185838652727F, 1.4275525873227906F, 1.1500528854755139F));
        g.addOrReplaceChild("tanque_188", CubeListBuilder.create().texOffs(90, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -23.448739934820388F, -4.187235907269161F, -0.882888309713548F, 1.3637418416201268F, 0.6773401222187061F));
        g.addOrReplaceChild("tanque_189", CubeListBuilder.create().texOffs(756, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -23.14139231876114F, -6.52177282598743F, -1.1615014353351807F, 1.2366253581302753F, 0.3889232792734346F));
        g.addOrReplaceChild("tanque_190", CubeListBuilder.create().texOffs(108, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -22.918091204813038F, -8.217913180634845F, -1.3273549818031538F, 0.9985715299994635F, 0.20584443191907226F));
        g.addOrReplaceChild("tanque_191", CubeListBuilder.create().texOffs(904, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -22.80069486183966F, -9.109626935593774F, -1.4248113113080225F, 0.4572034706522001F, 0.06481452715783184F));
        g.addOrReplaceChild("tanque_192", CubeListBuilder.create().texOffs(258, 81).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -22.770609535763022F, -9.338147674873074F, -1.4398966328953213F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_193", CubeListBuilder.create().texOffs(920, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -22.80069486183966F, -9.109626935593774F, -1.4248113113080225F, -0.4572034706522001F, -0.06481452715783184F));
        g.addOrReplaceChild("tanque_194", CubeListBuilder.create().texOffs(126, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -22.918091204813038F, -8.217913180634845F, -1.3273549818031538F, -0.9985715299994635F, -0.20584443191907226F));
        g.addOrReplaceChild("tanque_195", CubeListBuilder.create().texOffs(774, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -23.14139231876114F, -6.52177282598743F, -1.1615014353351807F, -1.2366253581302753F, -0.3889232792734346F));
        g.addOrReplaceChild("tanque_196", CubeListBuilder.create().texOffs(108, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -23.448739934820388F, -4.1872359072691605F, -0.882888309713548F, -1.3637418416201268F, -0.6773401222187061F));
        g.addOrReplaceChild("tanque_197", CubeListBuilder.create().texOffs(550, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -23.784166822403883F, -1.6394157463882473F, -0.4169185838652727F, -1.4275525873227906F, -1.1500528854755139F));
        g.addOrReplaceChild("tanque_198", CubeListBuilder.create().texOffs(564, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -24.215833177596114F, -1.6394157463882475F, -2.7246740697245206F, 1.4275525873227906F, -1.1500528854755139F));
        g.addOrReplaceChild("tanque_199", CubeListBuilder.create().texOffs(126, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -24.55126006517961F, -4.187235907269161F, -2.2587043438762424F, 1.3637418416201268F, -0.6773401222187035F));
        g.addOrReplaceChild("tanque_200", CubeListBuilder.create().texOffs(792, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -24.85860768123885F, -6.521772825987431F, -1.9800912182546118F, 1.2366253581302762F, -0.38892327927343423F));
        g.addOrReplaceChild("tanque_201", CubeListBuilder.create().texOffs(144, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -25.081908795186955F, -8.217913180634845F, -1.8142376717866378F, 0.9985715299994642F, -0.20584443191907076F));
        g.addOrReplaceChild("tanque_202", CubeListBuilder.create().texOffs(936, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -25.199305138160334F, -9.109626935593774F, -1.71678134228177F, 0.4572034706521999F, -0.06481452715783141F));
        g.addOrReplaceChild("tanque_203", CubeListBuilder.create().texOffs(516, 81).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -25.22939046423697F, -9.338147674873074F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_204", CubeListBuilder.create().texOffs(952, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -25.199305138160334F, -9.109626935593774F, -1.71678134228177F, -0.4572034706521999F, 0.06481452715783141F));
        g.addOrReplaceChild("tanque_205", CubeListBuilder.create().texOffs(162, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -25.081908795186955F, -8.217913180634847F, -1.8142376717866378F, -0.9985715299994642F, 0.20584443191907076F));
        g.addOrReplaceChild("tanque_206", CubeListBuilder.create().texOffs(810, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -24.85860768123885F, -6.521772825987431F, -1.9800912182546118F, -1.2366253581302762F, 0.38892327927343423F));
        g.addOrReplaceChild("tanque_207", CubeListBuilder.create().texOffs(144, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -24.55126006517961F, -4.187235907269162F, -2.2587043438762424F, -1.3637418416201268F, 0.6773401222187035F));
        g.addOrReplaceChild("tanque_208", CubeListBuilder.create().texOffs(578, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -24.215833177596117F, -1.6394157463882475F, -2.7246740697245206F, -1.4275525873227906F, 1.1500528854755139F));
        g.addOrReplaceChild("tanque_209", CubeListBuilder.create().texOffs(592, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -24.632790858416364F, -1.527692272534508F, -3.001747190063914F, 1.1740101685179025F, -1.4193432398164667F));
        g.addOrReplaceChild("tanque_210", CubeListBuilder.create().texOffs(162, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -25.616212733097168F, -3.9018826999232825F, -2.7725644640655718F, 1.1480068399802306F, -1.169698968206758F));
        g.addOrReplaceChild("tanque_211", CubeListBuilder.create().texOffs(828, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -26.51731034915641F, -6.0773247856355725F, -2.5092602915710276F, 1.0765025963334238F, -0.8766574093352835F));
        g.addOrReplaceChild("tanque_212", CubeListBuilder.create().texOffs(180, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -27.171996089107697F, -7.657875978118234F, -2.2341104364819495F, 0.9001274374613583F, -0.5493245327377028F));
        g.addOrReplaceChild("tanque_213", CubeListBuilder.create().texOffs(968, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -27.516184751260823F, -8.488820914303368F, -2.004077529954799F, 0.4239424628692383F, -0.18804484041058092F));
        g.addOrReplaceChild("tanque_214", CubeListBuilder.create().texOffs(0, 87).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -27.60439046423697F, -8.70176834284916F, -1.9634954084936203F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_215", CubeListBuilder.create().texOffs(984, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -27.516184751260827F, -8.488820914303366F, -2.004077529954799F, -0.4239424628692383F, 0.18804484041058092F));
        g.addOrReplaceChild("tanque_216", CubeListBuilder.create().texOffs(198, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -27.1719960891077F, -7.657875978118234F, -2.2341104364819495F, -0.9001274374613583F, 0.5493245327377028F));
        g.addOrReplaceChild("tanque_217", CubeListBuilder.create().texOffs(846, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -26.51731034915641F, -6.0773247856355725F, -2.5092602915710276F, -1.0765025963334238F, 0.8766574093352835F));
        g.addOrReplaceChild("tanque_218", CubeListBuilder.create().texOffs(180, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -25.616212733097168F, -3.9018826999232825F, -2.7725644640655718F, -1.1480068399802306F, 1.169698968206758F));
        g.addOrReplaceChild("tanque_219", CubeListBuilder.create().texOffs(606, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -24.632790858416367F, -1.5276922725345081F, -3.001747190063914F, -1.1740101685179025F, 1.4193432398164667F));
        g.addOrReplaceChild("tanque_220", CubeListBuilder.create().texOffs(620, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -25.00662488797188F, -1.3118590949383906F, -3.065751913109093F, 0.9140839112755563F, -1.4751470009149492F));
        g.addOrReplaceChild("tanque_221", CubeListBuilder.create().texOffs(198, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -26.571023174171987F, -3.3506226347436714F, -2.9357782900537206F, 0.899647036888559F, -1.310263231284021F));
        g.addOrReplaceChild("tanque_222", CubeListBuilder.create().texOffs(864, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -28.004462476831016F, -5.218717104396719F, -2.764956281673148F, 0.8570799341351946F, -1.0887479937869748F));
        g.addOrReplaceChild("tanque_223", CubeListBuilder.create().texOffs(216, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -29.045917091527137F, -6.575967182931277F, -2.537065740440379F, 0.7378870845282007F, -0.7721413459731634F));
        g.addOrReplaceChild("tanque_224", CubeListBuilder.create().texOffs(1000, 99).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -29.59344218433294F, -7.289515776143031F, -2.279316845245431F, 0.3610324850495138F, -0.2939435953240299F));
        g.addOrReplaceChild("tanque_225", CubeListBuilder.create().texOffs(258, 87).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -29.733757210636096F, -7.472377878612186F, -2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_226", CubeListBuilder.create().texOffs(0, 105).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -29.593442184332936F, -7.289515776143031F, -2.279316845245431F, -0.3610324850495138F, 0.2939435953240299F));
        g.addOrReplaceChild("tanque_227", CubeListBuilder.create().texOffs(234, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -29.045917091527144F, -6.575967182931277F, -2.537065740440379F, -0.7378870845282007F, 0.7721413459731634F));
        g.addOrReplaceChild("tanque_228", CubeListBuilder.create().texOffs(882, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -28.004462476831012F, -5.218717104396719F, -2.764956281673148F, -0.8570799341351946F, 1.0887479937869748F));
        g.addOrReplaceChild("tanque_229", CubeListBuilder.create().texOffs(216, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -26.57102317417199F, -3.350622634743672F, -2.9357782900537206F, -0.899647036888559F, 1.310263231284021F));
        g.addOrReplaceChild("tanque_230", CubeListBuilder.create().texOffs(634, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -25.006624887971878F, -1.3118590949383904F, -3.065751913109093F, -0.9140839112755565F, 1.4751470009149492F));
        g.addOrReplaceChild("tanque_231", CubeListBuilder.create().texOffs(648, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -25.311859094938388F, -1.0066248879718802F, -3.0968823344803504F, 0.6531936919684332F, -1.4973099403710963F));
        g.addOrReplaceChild("tanque_232", CubeListBuilder.create().texOffs(234, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -27.35062263474367F, -2.57102317417199F, -3.019284064418916F, 0.6446259398141245F, -1.3690165877347145F));
        g.addOrReplaceChild("tanque_233", CubeListBuilder.create().texOffs(900, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -29.218717104396713F, -4.004462476831017F, -2.9127933911408865F, 0.618788466126946F, -1.189015922797191F));
        g.addOrReplaceChild("tanque_234", CubeListBuilder.create().texOffs(252, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -30.575967182931272F, -5.045917091527146F, -2.75529075086925F, 0.5424091906342446F, -0.9034486197340219F));
        g.addOrReplaceChild("tanque_235", CubeListBuilder.create().texOffs(16, 105).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -31.289515776143027F, -5.593442184332946F, -2.539597676218061F, 0.27448458218811117F, -0.3757584436900775F));
        g.addOrReplaceChild("tanque_236", CubeListBuilder.create().texOffs(516, 87).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -31.47237787861218F, -5.733757210636104F, -2.487094184091919F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_237", CubeListBuilder.create().texOffs(32, 105).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -31.289515776143027F, -5.593442184332947F, -2.539597676218061F, -0.27448458218811117F, 0.3757584436900775F));
        g.addOrReplaceChild("tanque_238", CubeListBuilder.create().texOffs(270, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -30.575967182931272F, -5.045917091527146F, -2.75529075086925F, -0.5424091906342446F, 0.9034486197340219F));
        g.addOrReplaceChild("tanque_239", CubeListBuilder.create().texOffs(918, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -29.218717104396717F, -4.004462476831017F, -2.9127933911408865F, -0.618788466126946F, 1.189015922797191F));
        g.addOrReplaceChild("tanque_240", CubeListBuilder.create().texOffs(252, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -27.35062263474367F, -2.57102317417199F, -3.019284064418916F, -0.6446259398141245F, 1.3690165877347145F));
        g.addOrReplaceChild("tanque_241", CubeListBuilder.create().texOffs(662, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -25.311859094938388F, -1.0066248879718802F, -3.0968823344803504F, -0.6531936919684332F, 1.4973099403710963F));
        g.addOrReplaceChild("tanque_242", CubeListBuilder.create().texOffs(676, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -25.52769227253451F, -0.6327908584163686F, -3.1174460131803032F, 0.3919944953820014F, -1.5076623134644438F));
        g.addOrReplaceChild("tanque_243", CubeListBuilder.create().texOffs(270, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -27.90188269992328F, -1.6162127330971754F, -3.075334733756226F, 0.38735554451839416F, -1.3969076996331415F));
        g.addOrReplaceChild("tanque_244", CubeListBuilder.create().texOffs(936, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -30.077324785635568F, -2.5173103491564204F, -3.016538387920184F, 0.37323955188139735F, -1.2387994884292057F));
        g.addOrReplaceChild("tanque_245", CubeListBuilder.create().texOffs(288, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -31.657875978118227F, -3.171996089107708F, -2.9254592245915605F, 0.33048036816025333F, -0.975931338348953F));
        g.addOrReplaceChild("tanque_246", CubeListBuilder.create().texOffs(48, 105).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -32.48882091430336F, -3.516184751260836F, -2.786430577428535F, 0.1712251260195826F, -0.43065021590619823F));
        g.addOrReplaceChild("tanque_247", CubeListBuilder.create().texOffs(0, 93).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -32.70176834284916F, -3.6043904642369795F, -2.748893571891068F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_248", CubeListBuilder.create().texOffs(64, 105).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -32.48882091430336F, -3.5161847512608366F, -2.786430577428535F, -0.1712251260195826F, 0.43065021590619823F));
        g.addOrReplaceChild("tanque_249", CubeListBuilder.create().texOffs(306, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -31.65787597811823F, -3.171996089107708F, -2.9254592245915605F, -0.33048036816025333F, 0.975931338348953F));
        g.addOrReplaceChild("tanque_250", CubeListBuilder.create().texOffs(954, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -30.077324785635568F, -2.5173103491564204F, -3.016538387920184F, -0.37323955188139735F, 1.2387994884292057F));
        g.addOrReplaceChild("tanque_251", CubeListBuilder.create().texOffs(288, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -27.90188269992328F, -1.6162127330971754F, -3.075334733756226F, -0.38735554451839416F, 1.3969076996331415F));
        g.addOrReplaceChild("tanque_252", CubeListBuilder.create().texOffs(690, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -25.52769227253451F, -0.6327908584163686F, -3.1174460131803032F, -0.3919944953820014F, 1.5076623134644438F));
        g.addOrReplaceChild("tanque_253", CubeListBuilder.create().texOffs(704, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.92658477444273F, -25.639415746388245F, -0.21583317759611836F, -3.13391661073409F, 0.1306757207655222F, -1.5119545064066395F));
        g.addOrReplaceChild("tanque_254", CubeListBuilder.create().texOffs(306, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.64011026600515F, -28.187235907269162F, -0.5512600651796128F, -3.1205056732718157F, 0.12919963671860074F, -1.408543696409026F));
        g.addOrReplaceChild("tanque_255", CubeListBuilder.create().texOffs(972, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.09520337000113F, -30.521772825987426F, -0.8586076812388574F, -3.1016584927528466F, 0.12469269124863316F, -1.2599482502094528F));
        g.addOrReplaceChild("tanque_256", CubeListBuilder.create().texOffs(324, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-32.34520337000113F, -32.21791318063485F, -1.081908795186962F, -3.071920313199224F, 0.11090726153269859F, -1.0082418122168313F));
        g.addOrReplaceChild("tanque_257", CubeListBuilder.create().texOffs(80, 105).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.46352549156242F, -33.109626935593774F, -1.1993051381603406F, -3.0242516939435222F, 0.0581495145124652F, -0.45803658128940766F));
        g.addOrReplaceChild("tanque_258", CubeListBuilder.create().texOffs(258, 93).addBox(-62.0F, -1.0F, -2.5F, 124.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -33.33814767487307F, -1.2293904642369788F, -3.0106929596902186F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_259", CubeListBuilder.create().texOffs(96, 105).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(31.46352549156242F, -33.10962693559377F, -1.1993051381603403F, -3.0242516939435222F, -0.0581495145124652F, 0.45803658128940766F));
        g.addOrReplaceChild("tanque_260", CubeListBuilder.create().texOffs(342, 99).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(32.34520337000113F, -32.217913180634845F, -1.081908795186962F, -3.071920313199224F, -0.11090726153269859F, 1.0082418122168313F));
        g.addOrReplaceChild("tanque_261", CubeListBuilder.create().texOffs(990, 105).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(33.09520337000113F, -30.52177282598743F, -0.8586076812388576F, -3.1016584927528466F, -0.12469269124863316F, 1.2599482502094528F));
        g.addOrReplaceChild("tanque_262", CubeListBuilder.create().texOffs(324, 116).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(33.64011026600515F, -28.187235907269162F, -0.5512600651796129F, -3.1205056732718157F, -0.12919963671860074F, 1.408543696409026F));
        g.addOrReplaceChild("tanque_263", CubeListBuilder.create().texOffs(718, 120).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(33.92658477444273F, -25.639415746388245F, -0.21583317759611836F, -3.13391661073409F, -0.1306757207655222F, 1.5119545064066395F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(422, 40).addBox(-36.0F, -11.5F, -2.0F, 72.0F, 3.0F, 4.0F).texOffs(360, 0).addBox(-38.0F, -13.0F, -10.0F, 2.0F, 5.0F, 20.0F).texOffs(404, 0).addBox(36.0F, -13.0F, -10.0F, 2.0F, 5.0F, 20.0F).texOffs(264, 0).addBox(-30.0F, -12.0F, -10.0F, 4.0F, 5.0F, 20.0F).texOffs(312, 0).addBox(26.0F, -12.0F, -10.0F, 4.0F, 5.0F, 20.0F), PartPose.ZERO);
        g.addOrReplaceChild("cunai0", CubeListBuilder.create().texOffs(448, 0).addBox(0.0F, -9.0F, 0.0F, 1.0F, 9.0F, 16.0F), PartPose.offset(-30.0F, -12.0F, -8.0F));
        g.addOrReplaceChild("cunai1", CubeListBuilder.create().texOffs(482, 0).addBox(0.0F, -9.0F, 0.0F, 1.0F, 9.0F, 16.0F), PartPose.offset(-27.0F, -12.0F, -8.0F));
        g.addOrReplaceChild("cunad0", CubeListBuilder.create().texOffs(516, 0).addBox(0.0F, -9.0F, 0.0F, 1.0F, 9.0F, 16.0F), PartPose.offset(26.0F, -12.0F, -8.0F));
        g.addOrReplaceChild("cunad1", CubeListBuilder.create().texOffs(550, 0).addBox(0.0F, -9.0F, 0.0F, 1.0F, 9.0F, 16.0F), PartPose.offset(29.0F, -12.0F, -8.0F));
        g.addOrReplaceChild("pasarelas", CubeListBuilder.create().texOffs(202, 111).addBox(-36.0F, -14.0F, 9.5F, 72.0F, 1.0F, 3.0F).texOffs(352, 111).addBox(-36.0F, -14.0F, -12.5F, 72.0F, 1.0F, 3.0F).texOffs(156, 0).addBox(-38.0F, -14.0F, -12.5F, 2.0F, 1.0F, 25.0F).texOffs(210, 0).addBox(36.0F, -14.0F, -12.5F, 2.0F, 1.0F, 25.0F).texOffs(48, 40).addBox(-20.5F, -13.0F, 2.0F, 1.0F, 1.0F, 10.0F).texOffs(70, 40).addBox(-20.5F, -13.0F, -12.0F, 1.0F, 1.0F, 10.0F).texOffs(92, 40).addBox(-10.5F, -13.0F, 2.0F, 1.0F, 1.0F, 10.0F).texOffs(114, 40).addBox(-10.5F, -13.0F, -12.0F, 1.0F, 1.0F, 10.0F).texOffs(136, 40).addBox(-0.5F, -13.0F, 2.0F, 1.0F, 1.0F, 10.0F).texOffs(158, 40).addBox(-0.5F, -13.0F, -12.0F, 1.0F, 1.0F, 10.0F).texOffs(180, 40).addBox(9.5F, -13.0F, 2.0F, 1.0F, 1.0F, 10.0F).texOffs(202, 40).addBox(9.5F, -13.0F, -12.0F, 1.0F, 1.0F, 10.0F).texOffs(224, 40).addBox(19.5F, -13.0F, 2.0F, 1.0F, 1.0F, 10.0F).texOffs(246, 40).addBox(19.5F, -13.0F, -12.0F, 1.0F, 1.0F, 10.0F), PartPose.ZERO);
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("domo_0", CubeListBuilder.create().texOffs(326, 40).addBox(-5.0F, -37.0F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(744, 0).addBox(-1.0F, -37.0F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.ZERO);
        g.addOrReplaceChild("domo_1", CubeListBuilder.create().texOffs(350, 40).addBox(-5.0F, -37.0F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(768, 0).addBox(-1.0F, -37.0F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("domo_2", CubeListBuilder.create().texOffs(374, 40).addBox(-5.0F, -37.0F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(792, 0).addBox(-1.0F, -37.0F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("domo_3", CubeListBuilder.create().texOffs(398, 40).addBox(-5.0F, -37.0F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(816, 0).addBox(-1.0F, -37.0F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("domo_aro_0", CubeListBuilder.create().texOffs(660, 116).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(976, 0).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.ZERO);
        g.addOrReplaceChild("domo_aro_1", CubeListBuilder.create().texOffs(684, 116).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(1000, 0).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("domo_aro_2", CubeListBuilder.create().texOffs(708, 116).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(0, 40).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("domo_aro_3", CubeListBuilder.create().texOffs(732, 116).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(24, 40).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("domo_tapa", CubeListBuilder.create().texOffs(0, 0).addBox(-19.5F, 0.0F, -19.5F, 39.0F, 1.0F, 39.0F), PartPose.offsetAndRotation(0.0F, -38.05F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("valvula_0", CubeListBuilder.create().texOffs(574, 40).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(840, 0).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(2.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("valvula_1", CubeListBuilder.create().texOffs(608, 40).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(874, 0).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(2.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("plataforma_domo", CubeListBuilder.create().texOffs(924, 0).addBox(-7.0F, -34.0F, -6.0F, 14.0F, 1.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("baranda_domo", CubeListBuilder.create().texOffs(0, 120).addBox(-7.0F, -38.0F, 5.5F, 14.0F, 1.0F, 1.0F).texOffs(460, 116).addBox(-7.5F, -37.0F, 5.5F, 1.0F, 3.0F, 1.0F).texOffs(464, 116).addBox(6.5F, -37.0F, 5.5F, 1.0F, 3.0F, 1.0F).texOffs(30, 120).addBox(-7.0F, -38.0F, -6.5F, 14.0F, 1.0F, 1.0F).texOffs(468, 116).addBox(-7.5F, -37.0F, -6.5F, 1.0F, 3.0F, 1.0F).texOffs(472, 116).addBox(6.5F, -37.0F, -6.5F, 1.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("pasamanos", CubeListBuilder.create().texOffs(756, 116).addBox(-30.0F, -28.0F, 9.5F, 60.0F, 1.0F, 1.0F).texOffs(878, 116).addBox(-30.0F, -28.0F, -10.5F, 60.0F, 1.0F, 1.0F).texOffs(788, 120).addBox(-30.0F, -28.0F, 8.5F, 1.0F, 1.0F, 1.0F).texOffs(792, 120).addBox(-30.0F, -28.0F, -9.5F, 1.0F, 1.0F, 1.0F).texOffs(796, 120).addBox(-18.0F, -28.0F, 8.5F, 1.0F, 1.0F, 1.0F).texOffs(800, 120).addBox(-18.0F, -28.0F, -9.5F, 1.0F, 1.0F, 1.0F).texOffs(804, 120).addBox(-6.0F, -28.0F, 8.5F, 1.0F, 1.0F, 1.0F).texOffs(808, 120).addBox(-6.0F, -28.0F, -9.5F, 1.0F, 1.0F, 1.0F).texOffs(812, 120).addBox(5.0F, -28.0F, 8.5F, 1.0F, 1.0F, 1.0F).texOffs(816, 120).addBox(5.0F, -28.0F, -9.5F, 1.0F, 1.0F, 1.0F).texOffs(820, 120).addBox(17.0F, -28.0F, 8.5F, 1.0F, 1.0F, 1.0F).texOffs(824, 120).addBox(17.0F, -28.0F, -9.5F, 1.0F, 1.0F, 1.0F).texOffs(828, 120).addBox(29.0F, -28.0F, 8.5F, 1.0F, 1.0F, 1.0F).texOffs(832, 120).addBox(29.0F, -28.0F, -9.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("escalerai_l00", CubeListBuilder.create().texOffs(908, 0).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 13.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -14.0F, -11.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("escalerai_l01", CubeListBuilder.create().texOffs(912, 0).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 13.0F, 1.0F), PartPose.offsetAndRotation(-2.5F, -14.0F, -11.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("escalerai_l10", CubeListBuilder.create().texOffs(268, 40).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 9.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -27.0F, -11.5F, 0.6260465224935315F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("escalerai_l11", CubeListBuilder.create().texOffs(272, 40).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 9.0F, 1.0F), PartPose.offsetAndRotation(-2.5F, -27.0F, -11.5F, 0.6260465224935315F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("escalerai_p0", CubeListBuilder.create().texOffs(476, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -15.5F, -11.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_p1", CubeListBuilder.create().texOffs(480, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -18.0F, -11.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_p2", CubeListBuilder.create().texOffs(484, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -20.5F, -11.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_p3", CubeListBuilder.create().texOffs(488, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -23.0F, -11.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_p4", CubeListBuilder.create().texOffs(492, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -25.5F, -11.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_p5", CubeListBuilder.create().texOffs(496, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -27.810350358072803F, -10.914054356470434F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_p6", CubeListBuilder.create().texOffs(500, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -29.836226253254814F, -9.449190247646518F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerai_p7", CubeListBuilder.create().texOffs(504, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -31.862102148436826F, -7.984326138822602F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_l00", CubeListBuilder.create().texOffs(916, 0).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 13.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -14.0F, 11.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("escalerad_l01", CubeListBuilder.create().texOffs(920, 0).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 13.0F, 1.0F), PartPose.offsetAndRotation(-2.5F, -14.0F, 11.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("escalerad_l10", CubeListBuilder.create().texOffs(276, 40).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 9.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -27.0F, 11.5F, -0.6260465224935315F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("escalerad_l11", CubeListBuilder.create().texOffs(280, 40).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 9.0F, 1.0F), PartPose.offsetAndRotation(-2.5F, -27.0F, 11.5F, -0.6260465224935315F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("escalerad_p0", CubeListBuilder.create().texOffs(508, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -15.5F, 11.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_p1", CubeListBuilder.create().texOffs(512, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -18.0F, 11.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_p2", CubeListBuilder.create().texOffs(516, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -20.5F, 11.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_p3", CubeListBuilder.create().texOffs(520, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -23.0F, 11.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_p4", CubeListBuilder.create().texOffs(524, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -25.5F, 11.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_p5", CubeListBuilder.create().texOffs(528, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -27.810350358072803F, 10.914054356470434F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_p6", CubeListBuilder.create().texOffs(532, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -29.836226253254814F, 9.449190247646518F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escalerad_p7", CubeListBuilder.create().texOffs(536, 116).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -31.862102148436826F, 7.984326138822602F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("freno", CubeListBuilder.create().texOffs(668, 0).addBox(36.5F, -30.0F, -0.5F, 1.0F, 16.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("volante", CubeListBuilder.create().texOffs(584, 0).addBox(-10.5F, 0.0F, -10.5F, 21.0F, 1.0F, 21.0F), PartPose.offsetAndRotation(37.0F, -30.3F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("puntai", CubeListBuilder.create().texOffs(112, 105).addBox(-43.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("puntad", CubeListBuilder.create().texOffs(128, 105).addBox(38.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(284, 40).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(342, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(302, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(42, 111).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-33.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(360, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(310, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(378, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(284, 40).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(342, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(302, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(52, 111).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-22.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(360, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(310, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(378, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(284, 40).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(342, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(302, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(62, 111).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-33.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(360, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(310, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(378, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(284, 40).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(342, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(302, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(72, 111).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-22.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(360, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(310, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(378, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(82, 111).addBox(-35.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(92, 111).addBox(-24.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(540, 116).addBox(-35.0F, -7.0F, -8.0F, 14.0F, 2.0F, 1.0F).texOffs(732, 120).addBox(-31.0F, -2.0F, -8.0F, 6.0F, 1.0F, 1.0F).texOffs(1008, 105).addBox(-30.5F, -5.0F, -8.5F, 5.0F, 3.0F, 2.0F).texOffs(102, 111).addBox(-35.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(112, 111).addBox(-24.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(570, 116).addBox(-35.0F, -7.0F, 7.0F, 14.0F, 2.0F, 1.0F).texOffs(746, 120).addBox(-31.0F, -2.0F, 7.0F, 6.0F, 1.0F, 1.0F).texOffs(0, 111).addBox(-30.5F, -5.0F, 6.5F, 5.0F, 3.0F, 2.0F).texOffs(672, 0).addBox(-30.0F, -7.0F, -7.0F, 4.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_cordonii", CubeListBuilder.create().texOffs(396, 116).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -2.5F, -7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordonid", CubeListBuilder.create().texOffs(404, 116).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.5F, -2.5F, -7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordondi", CubeListBuilder.create().texOffs(412, 116).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -2.5F, 7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordondd", CubeListBuilder.create().texOffs(420, 116).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.5F, -2.5F, 7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(284, 40).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(342, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(302, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(122, 111).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(22.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(360, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(310, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(378, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(284, 40).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(342, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(302, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(132, 111).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(33.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(360, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(310, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(378, 116).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 40).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(284, 40).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(342, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(302, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(142, 111).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(22.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(360, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(310, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(378, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(284, 40).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(342, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(302, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(152, 111).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(33.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(360, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(310, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(378, 116).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 40).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(162, 111).addBox(21.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(172, 111).addBox(32.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(600, 116).addBox(21.0F, -7.0F, -8.0F, 14.0F, 2.0F, 1.0F).texOffs(760, 120).addBox(25.0F, -2.0F, -8.0F, 6.0F, 1.0F, 1.0F).texOffs(14, 111).addBox(25.5F, -5.0F, -8.5F, 5.0F, 3.0F, 2.0F).texOffs(182, 111).addBox(21.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(192, 111).addBox(32.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(630, 116).addBox(21.0F, -7.0F, 7.0F, 14.0F, 2.0F, 1.0F).texOffs(774, 120).addBox(25.0F, -2.0F, 7.0F, 6.0F, 1.0F, 1.0F).texOffs(28, 111).addBox(25.5F, -5.0F, 6.5F, 5.0F, 3.0F, 2.0F).texOffs(708, 0).addBox(26.0F, -7.0F, -7.0F, 4.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_cordonii", CubeListBuilder.create().texOffs(428, 116).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(23.5F, -2.5F, -7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordonid", CubeListBuilder.create().texOffs(436, 116).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(32.5F, -2.5F, -7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordondi", CubeListBuilder.create().texOffs(444, 116).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(23.5F, -2.5F, 7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordondd", CubeListBuilder.create().texOffs(452, 116).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(32.5F, -2.5F, 7.5F, 0.0F, 0.0F, 0.982793723247329F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "tanque_0", 0.4233181806000528F, 1.0F, 0.4353911871549668F);
        escalar(g0, "tanque_1", 0.4470602033005601F, 1.0F, 0.3706779110343052F);
        escalar(g0, "tanque_2", 0.440801123306464F, 1.0F, 0.43300828653704015F);
        escalar(g0, "tanque_3", 0.3968800040556215F, 1.0F, 0.4364978174127785F);
        escalar(g0, "tanque_4", 0.3457060738075722F, 1.0F, 0.4838615579684382F);
        escalar(g0, "tanque_5", 0.5F, 1.0F, 0.49599953043619605F);
        escalar(g0, "tanque_6", 0.3457060738075722F, 1.0F, 0.4838615579684382F);
        escalar(g0, "tanque_7", 0.3968800040556215F, 1.0F, 0.4364978174127785F);
        escalar(g0, "tanque_8", 0.440801123306464F, 1.0F, 0.43300828653704015F);
        escalar(g0, "tanque_9", 0.4470602033005601F, 1.0F, 0.3706779110343052F);
        escalar(g0, "tanque_10", 0.4233181806000528F, 1.0F, 0.4353911871549668F);
        escalar(g0, "tanque_11", 0.42331818060005255F, 1.0F, 0.4353911871549668F);
        escalar(g0, "tanque_12", 0.44706020330056023F, 1.0F, 0.3706779110343051F);
        escalar(g0, "tanque_13", 0.4408011233064637F, 1.0F, 0.43300828653704015F);
        escalar(g0, "tanque_14", 0.3968800040556214F, 1.0F, 0.43649781741277865F);
        escalar(g0, "tanque_15", 0.3457060738075726F, 1.0F, 0.4838615579684381F);
        escalar(g0, "tanque_16", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_17", 0.3457060738075726F, 1.0F, 0.4838615579684381F);
        escalar(g0, "tanque_18", 0.3968800040556214F, 1.0F, 0.43649781741277865F);
        escalar(g0, "tanque_19", 0.4408011233064637F, 1.0F, 0.43300828653704015F);
        escalar(g0, "tanque_20", 0.44706020330056023F, 1.0F, 0.3706779110343051F);
        escalar(g0, "tanque_21", 0.42331818060005255F, 1.0F, 0.4353911871549668F);
        escalar(g0, "tanque_22", 0.4233181806000526F, 1.0F, 0.43539118715496816F);
        escalar(g0, "tanque_23", 0.4470602033005602F, 1.0F, 0.37067791103430553F);
        escalar(g0, "tanque_24", 0.440801123306464F, 1.0F, 0.4330082865370402F);
        escalar(g0, "tanque_25", 0.39688000405562074F, 1.0F, 0.4364978174127785F);
        escalar(g0, "tanque_26", 0.345706073807573F, 1.0F, 0.48386155796843855F);
        escalar(g0, "tanque_27", 0.5F, 1.0F, 0.4959995304361965F);
        escalar(g0, "tanque_28", 0.345706073807573F, 1.0F, 0.48386155796843855F);
        escalar(g0, "tanque_29", 0.39688000405562074F, 1.0F, 0.4364978174127785F);
        escalar(g0, "tanque_30", 0.440801123306464F, 1.0F, 0.4330082865370402F);
        escalar(g0, "tanque_31", 0.4470602033005602F, 1.0F, 0.37067791103430553F);
        escalar(g0, "tanque_32", 0.4233181806000526F, 1.0F, 0.43539118715496816F);
        escalar(g0, "tanque_33", 0.4233181806000527F, 1.0F, 0.43539118715496694F);
        escalar(g0, "tanque_34", 0.4470602033005601F, 1.0F, 0.3706779110343053F);
        escalar(g0, "tanque_35", 0.44080112330646415F, 1.0F, 0.4330082865370404F);
        escalar(g0, "tanque_36", 0.3968800040556207F, 1.0F, 0.43649781741277865F);
        escalar(g0, "tanque_37", 0.3457060738075728F, 1.0F, 0.4838615579684383F);
        escalar(g0, "tanque_38", 0.5F, 1.0F, 0.49599953043619627F);
        escalar(g0, "tanque_39", 0.3457060738075728F, 1.0F, 0.4838615579684383F);
        escalar(g0, "tanque_40", 0.3968800040556207F, 1.0F, 0.43649781741277865F);
        escalar(g0, "tanque_41", 0.44080112330646415F, 1.0F, 0.4330082865370404F);
        escalar(g0, "tanque_42", 0.4470602033005601F, 1.0F, 0.3706779110343053F);
        escalar(g0, "tanque_43", 0.4233181806000527F, 1.0F, 0.43539118715496694F);
        escalar(g0, "tanque_44", 0.4233181806000526F, 1.0F, 0.4353911871549655F);
        escalar(g0, "tanque_45", 0.4470602033005601F, 1.0F, 0.37067791103430486F);
        escalar(g0, "tanque_46", 0.44080112330646415F, 1.0F, 0.4330082865370399F);
        escalar(g0, "tanque_47", 0.39688000405562074F, 1.0F, 0.4364978174127785F);
        escalar(g0, "tanque_48", 0.3457060738075728F, 1.0F, 0.4838615579684381F);
        escalar(g0, "tanque_49", 0.5F, 1.0F, 0.4959995304361957F);
        escalar(g0, "tanque_50", 0.3457060738075728F, 1.0F, 0.4838615579684381F);
        escalar(g0, "tanque_51", 0.39688000405562074F, 1.0F, 0.4364978174127785F);
        escalar(g0, "tanque_52", 0.44080112330646415F, 1.0F, 0.4330082865370399F);
        escalar(g0, "tanque_53", 0.4470602033005601F, 1.0F, 0.37067791103430486F);
        escalar(g0, "tanque_54", 0.4233181806000526F, 1.0F, 0.4353911871549655F);
        escalar(g0, "tanque_55", 0.4233181806000526F, 1.0F, 0.43539118715496844F);
        escalar(g0, "tanque_56", 0.4470602033005601F, 1.0F, 0.37067791103430564F);
        escalar(g0, "tanque_57", 0.44080112330646415F, 1.0F, 0.4330082865370406F);
        escalar(g0, "tanque_58", 0.39688000405562074F, 1.0F, 0.4364978174127788F);
        escalar(g0, "tanque_59", 0.3457060738075728F, 1.0F, 0.48386155796843866F);
        escalar(g0, "tanque_60", 0.5F, 1.0F, 0.49599953043619643F);
        escalar(g0, "tanque_61", 0.3457060738075728F, 1.0F, 0.48386155796843866F);
        escalar(g0, "tanque_62", 0.39688000405562074F, 1.0F, 0.4364978174127788F);
        escalar(g0, "tanque_63", 0.44080112330646415F, 1.0F, 0.4330082865370406F);
        escalar(g0, "tanque_64", 0.4470602033005601F, 1.0F, 0.37067791103430564F);
        escalar(g0, "tanque_65", 0.4233181806000526F, 1.0F, 0.43539118715496844F);
        escalar(g0, "tanque_66", 0.4233181806000526F, 1.0F, 0.43539118715496483F);
        escalar(g0, "tanque_67", 0.44706020330056023F, 1.0F, 0.37067791103430436F);
        escalar(g0, "tanque_68", 0.44080112330646415F, 1.0F, 0.4330082865370397F);
        escalar(g0, "tanque_69", 0.39688000405562085F, 1.0F, 0.43649781741277816F);
        escalar(g0, "tanque_70", 0.3457060738075726F, 1.0F, 0.4838615579684375F);
        escalar(g0, "tanque_71", 0.5F, 1.0F, 0.495999530436195F);
        escalar(g0, "tanque_72", 0.3457060738075726F, 1.0F, 0.4838615579684375F);
        escalar(g0, "tanque_73", 0.39688000405562085F, 1.0F, 0.43649781741277816F);
        escalar(g0, "tanque_74", 0.44080112330646415F, 1.0F, 0.4330082865370397F);
        escalar(g0, "tanque_75", 0.44706020330056023F, 1.0F, 0.37067791103430436F);
        escalar(g0, "tanque_76", 0.4233181806000526F, 1.0F, 0.43539118715496483F);
        escalar(g0, "tanque_77", 0.4233181806000527F, 1.0F, 0.43539118715496894F);
        escalar(g0, "tanque_78", 0.4470602033005602F, 1.0F, 0.3706779110343061F);
        escalar(g0, "tanque_79", 0.440801123306464F, 1.0F, 0.4330082865370404F);
        escalar(g0, "tanque_80", 0.39688000405562085F, 1.0F, 0.4364978174127785F);
        escalar(g0, "tanque_81", 0.34570607380757284F, 1.0F, 0.4838615579684388F);
        escalar(g0, "tanque_82", 0.5F, 1.0F, 0.49599953043619693F);
        escalar(g0, "tanque_83", 0.34570607380757284F, 1.0F, 0.4838615579684388F);
        escalar(g0, "tanque_84", 0.39688000405562085F, 1.0F, 0.4364978174127785F);
        escalar(g0, "tanque_85", 0.440801123306464F, 1.0F, 0.4330082865370404F);
        escalar(g0, "tanque_86", 0.4470602033005602F, 1.0F, 0.3706779110343061F);
        escalar(g0, "tanque_87", 0.4233181806000527F, 1.0F, 0.43539118715496894F);
        escalar(g0, "tanque_88", 0.4233181806000527F, 1.0F, 0.4353911871549668F);
        escalar(g0, "tanque_89", 0.4470602033005601F, 1.0F, 0.3706779110343052F);
        escalar(g0, "tanque_90", 0.4408011233064638F, 1.0F, 0.4330082865370404F);
        escalar(g0, "tanque_91", 0.39688000405562096F, 1.0F, 0.4364978174127788F);
        escalar(g0, "tanque_92", 0.3457060738075728F, 1.0F, 0.4838615579684384F);
        escalar(g0, "tanque_93", 0.5F, 1.0F, 0.4959995304361958F);
        escalar(g0, "tanque_94", 0.3457060738075728F, 1.0F, 0.4838615579684384F);
        escalar(g0, "tanque_95", 0.39688000405562096F, 1.0F, 0.4364978174127788F);
        escalar(g0, "tanque_96", 0.4408011233064638F, 1.0F, 0.4330082865370404F);
        escalar(g0, "tanque_97", 0.4470602033005601F, 1.0F, 0.3706779110343052F);
        escalar(g0, "tanque_98", 0.4233181806000527F, 1.0F, 0.4353911871549668F);
        escalar(g0, "tanque_99", 0.4233181806000526F, 1.0F, 0.4353911871549679F);
        escalar(g0, "tanque_100", 0.44706020330055996F, 1.0F, 0.3706779110343048F);
        escalar(g0, "tanque_101", 0.44080112330646415F, 1.0F, 0.4330082865370397F);
        escalar(g0, "tanque_102", 0.39688000405562074F, 1.0F, 0.43649781741277816F);
        escalar(g0, "tanque_103", 0.3457060738075726F, 1.0F, 0.48386155796843766F);
        escalar(g0, "tanque_104", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_105", 0.3457060738075726F, 1.0F, 0.48386155796843766F);
        escalar(g0, "tanque_106", 0.39688000405562074F, 1.0F, 0.43649781741277816F);
        escalar(g0, "tanque_107", 0.44080112330646415F, 1.0F, 0.4330082865370397F);
        escalar(g0, "tanque_108", 0.44706020330055996F, 1.0F, 0.3706779110343048F);
        escalar(g0, "tanque_109", 0.42331818060005294F, 1.0F, 0.4353911871549668F);
        escalar(g0, "tanque_110", 0.4233181806000526F, 1.0F, 0.4353911871549669F);
        escalar(g0, "tanque_111", 0.44706020330055973F, 1.0F, 0.37067791103430525F);
        escalar(g0, "tanque_112", 0.4408011233064644F, 1.0F, 0.4330082865370404F);
        escalar(g0, "tanque_113", 0.39688000405562057F, 1.0F, 0.43649781741277877F);
        escalar(g0, "tanque_114", 0.3457060738075728F, 1.0F, 0.4838615579684385F);
        escalar(g0, "tanque_115", 0.5F, 1.0F, 0.4959995304361963F);
        escalar(g0, "tanque_116", 0.3457060738075728F, 1.0F, 0.4838615579684385F);
        escalar(g0, "tanque_117", 0.39688000405562057F, 1.0F, 0.43649781741277877F);
        escalar(g0, "tanque_118", 0.4408011233064644F, 1.0F, 0.4330082865370404F);
        escalar(g0, "tanque_119", 0.44706020330055973F, 1.0F, 0.37067791103430525F);
        escalar(g0, "tanque_120", 0.42331818060005283F, 1.0F, 0.43539118715496755F);
        escalar(g0, "tanque_121", 0.4233181806000528F, 1.0F, 0.4353911871549671F);
        escalar(g0, "tanque_122", 0.4470602033005599F, 1.0F, 0.3706779110343055F);
        escalar(g0, "tanque_123", 0.4408011233064643F, 1.0F, 0.4330082865370405F);
        escalar(g0, "tanque_124", 0.39688000405562074F, 1.0F, 0.4364978174127788F);
        escalar(g0, "tanque_125", 0.34570607380757273F, 1.0F, 0.48386155796843855F);
        escalar(g0, "tanque_126", 0.5F, 1.0F, 0.49599953043619627F);
        escalar(g0, "tanque_127", 0.34570607380757273F, 1.0F, 0.48386155796843855F);
        escalar(g0, "tanque_128", 0.39688000405562074F, 1.0F, 0.4364978174127788F);
        escalar(g0, "tanque_129", 0.4408011233064643F, 1.0F, 0.4330082865370405F);
        escalar(g0, "tanque_130", 0.4470602033005599F, 1.0F, 0.3706779110343055F);
        escalar(g0, "tanque_131", 0.4233181806000528F, 1.0F, 0.4353911871549671F);
        escalar(g0, "tanque_132", 0.4233181806000528F, 1.0F, 0.4353911871549664F);
        escalar(g0, "tanque_133", 0.4470602033005601F, 1.0F, 0.3706779110343048F);
        escalar(g0, "tanque_134", 0.440801123306464F, 1.0F, 0.4330082865370397F);
        escalar(g0, "tanque_135", 0.3968800040556209F, 1.0F, 0.43649781741277804F);
        escalar(g0, "tanque_136", 0.34570607380757273F, 1.0F, 0.48386155796843777F);
        escalar(g0, "tanque_137", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_138", 0.34570607380757273F, 1.0F, 0.48386155796843777F);
        escalar(g0, "tanque_139", 0.3968800040556209F, 1.0F, 0.43649781741277804F);
        escalar(g0, "tanque_140", 0.440801123306464F, 1.0F, 0.4330082865370397F);
        escalar(g0, "tanque_141", 0.4470602033005601F, 1.0F, 0.3706779110343048F);
        escalar(g0, "tanque_142", 0.4233181806000528F, 1.0F, 0.43539118715496633F);
        escalar(g0, "tanque_143", 0.4233181806000525F, 1.0F, 0.4353911871549665F);
        escalar(g0, "tanque_144", 0.4470602033005601F, 1.0F, 0.37067791103430486F);
        escalar(g0, "tanque_145", 0.440801123306464F, 1.0F, 0.4330082865370397F);
        escalar(g0, "tanque_146", 0.396880004055621F, 1.0F, 0.43649781741277793F);
        escalar(g0, "tanque_147", 0.34570607380757257F, 1.0F, 0.48386155796843777F);
        escalar(g0, "tanque_148", 0.5F, 1.0F, 0.49599953043619543F);
        escalar(g0, "tanque_149", 0.34570607380757257F, 1.0F, 0.48386155796843777F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "tanque_150", 0.396880004055621F, 1.0F, 0.43649781741277793F);
        escalar(g0, "tanque_151", 0.440801123306464F, 1.0F, 0.4330082865370397F);
        escalar(g0, "tanque_152", 0.4470602033005601F, 1.0F, 0.37067791103430486F);
        escalar(g0, "tanque_153", 0.4233181806000525F, 1.0F, 0.4353911871549665F);
        escalar(g0, "tanque_154", 0.42331818060005255F, 1.0F, 0.43539118715496883F);
        escalar(g0, "tanque_155", 0.4470602033005601F, 1.0F, 0.37067791103430614F);
        escalar(g0, "tanque_156", 0.44080112330646415F, 1.0F, 0.43300828653704115F);
        escalar(g0, "tanque_157", 0.39688000405562074F, 1.0F, 0.4364978174127797F);
        escalar(g0, "tanque_158", 0.3457060738075726F, 1.0F, 0.48386155796843955F);
        escalar(g0, "tanque_159", 0.5F, 1.0F, 0.4959995304361972F);
        escalar(g0, "tanque_160", 0.3457060738075726F, 1.0F, 0.48386155796843955F);
        escalar(g0, "tanque_161", 0.39688000405562074F, 1.0F, 0.4364978174127797F);
        escalar(g0, "tanque_162", 0.44080112330646415F, 1.0F, 0.43300828653704115F);
        escalar(g0, "tanque_163", 0.4470602033005601F, 1.0F, 0.37067791103430614F);
        escalar(g0, "tanque_164", 0.42331818060005255F, 1.0F, 0.43539118715496883F);
        escalar(g0, "tanque_165", 0.4233181806000526F, 1.0F, 0.43539118715496655F);
        escalar(g0, "tanque_166", 0.44706020330056023F, 1.0F, 0.37067791103430453F);
        escalar(g0, "tanque_167", 0.44080112330646415F, 1.0F, 0.4330082865370395F);
        escalar(g0, "tanque_168", 0.3968800040556207F, 1.0F, 0.4364978174127779F);
        escalar(g0, "tanque_169", 0.3457060738075728F, 1.0F, 0.4838615579684376F);
        escalar(g0, "tanque_170", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_171", 0.3457060738075728F, 1.0F, 0.4838615579684376F);
        escalar(g0, "tanque_172", 0.3968800040556207F, 1.0F, 0.4364978174127779F);
        escalar(g0, "tanque_173", 0.44080112330646415F, 1.0F, 0.4330082865370395F);
        escalar(g0, "tanque_174", 0.44706020330056023F, 1.0F, 0.37067791103430453F);
        escalar(g0, "tanque_175", 0.4233181806000526F, 1.0F, 0.43539118715496655F);
        escalar(g0, "tanque_176", 0.42331818060005255F, 1.0F, 0.43539118715496566F);
        escalar(g0, "tanque_177", 0.44706020330056023F, 1.0F, 0.37067791103430503F);
        escalar(g0, "tanque_178", 0.44080112330646404F, 1.0F, 0.43300828653703993F);
        escalar(g0, "tanque_179", 0.39688000405562074F, 1.0F, 0.43649781741277816F);
        escalar(g0, "tanque_180", 0.3457060738075728F, 1.0F, 0.48386155796843744F);
        escalar(g0, "tanque_181", 0.5F, 1.0F, 0.495999530436195F);
        escalar(g0, "tanque_182", 0.3457060738075728F, 1.0F, 0.48386155796843744F);
        escalar(g0, "tanque_183", 0.39688000405562074F, 1.0F, 0.43649781741277816F);
        escalar(g0, "tanque_184", 0.44080112330646404F, 1.0F, 0.43300828653703993F);
        escalar(g0, "tanque_185", 0.44706020330056023F, 1.0F, 0.37067791103430503F);
        escalar(g0, "tanque_186", 0.42331818060005255F, 1.0F, 0.43539118715496566F);
        escalar(g0, "tanque_187", 0.4233181806000526F, 1.0F, 0.43539118715496844F);
        escalar(g0, "tanque_188", 0.44706020330056023F, 1.0F, 0.3706779110343062F);
        escalar(g0, "tanque_189", 0.44080112330646415F, 1.0F, 0.4330082865370415F);
        escalar(g0, "tanque_190", 0.39688000405562074F, 1.0F, 0.43649781741277993F);
        escalar(g0, "tanque_191", 0.3457060738075728F, 1.0F, 0.4838615579684401F);
        escalar(g0, "tanque_192", 0.5F, 1.0F, 0.49599953043619793F);
        escalar(g0, "tanque_193", 0.3457060738075728F, 1.0F, 0.4838615579684401F);
        escalar(g0, "tanque_194", 0.39688000405562074F, 1.0F, 0.43649781741277993F);
        escalar(g0, "tanque_195", 0.44080112330646415F, 1.0F, 0.4330082865370415F);
        escalar(g0, "tanque_196", 0.44706020330056023F, 1.0F, 0.3706779110343062F);
        escalar(g0, "tanque_197", 0.4233181806000526F, 1.0F, 0.43539118715496844F);
        escalar(g0, "tanque_198", 0.4233181806000526F, 1.0F, 0.43539118715496483F);
        escalar(g0, "tanque_199", 0.44706020330056023F, 1.0F, 0.37067791103430436F);
        escalar(g0, "tanque_200", 0.44080112330646415F, 1.0F, 0.4330082865370397F);
        escalar(g0, "tanque_201", 0.39688000405562085F, 1.0F, 0.43649781741277816F);
        escalar(g0, "tanque_202", 0.3457060738075726F, 1.0F, 0.4838615579684375F);
        escalar(g0, "tanque_203", 0.5F, 1.0F, 0.495999530436195F);
        escalar(g0, "tanque_204", 0.3457060738075726F, 1.0F, 0.4838615579684375F);
        escalar(g0, "tanque_205", 0.39688000405562085F, 1.0F, 0.43649781741277816F);
        escalar(g0, "tanque_206", 0.44080112330646415F, 1.0F, 0.4330082865370397F);
        escalar(g0, "tanque_207", 0.44706020330056023F, 1.0F, 0.37067791103430436F);
        escalar(g0, "tanque_208", 0.4233181806000526F, 1.0F, 0.43539118715496483F);
        escalar(g0, "tanque_209", 0.4233181806000526F, 1.0F, 0.435391187154967F);
        escalar(g0, "tanque_210", 0.44706020330056023F, 1.0F, 0.37067791103430475F);
        escalar(g0, "tanque_211", 0.44080112330646415F, 1.0F, 0.43300828653703965F);
        escalar(g0, "tanque_212", 0.39688000405562074F, 1.0F, 0.4364978174127779F);
        escalar(g0, "tanque_213", 0.3457060738075726F, 1.0F, 0.4838615579684376F);
        escalar(g0, "tanque_214", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_215", 0.3457060738075726F, 1.0F, 0.4838615579684376F);
        escalar(g0, "tanque_216", 0.39688000405562074F, 1.0F, 0.4364978174127779F);
        escalar(g0, "tanque_217", 0.44080112330646415F, 1.0F, 0.43300828653703965F);
        escalar(g0, "tanque_218", 0.44706020330056023F, 1.0F, 0.37067791103430475F);
        escalar(g0, "tanque_219", 0.4233181806000526F, 1.0F, 0.435391187154967F);
        escalar(g0, "tanque_220", 0.4233181806000526F, 1.0F, 0.4353911871549686F);
        escalar(g0, "tanque_221", 0.44706020330056023F, 1.0F, 0.3706779110343064F);
        escalar(g0, "tanque_222", 0.440801123306464F, 1.0F, 0.43300828653704104F);
        escalar(g0, "tanque_223", 0.39688000405562085F, 1.0F, 0.4364978174127795F);
        escalar(g0, "tanque_224", 0.3457060738075725F, 1.0F, 0.4838615579684394F);
        escalar(g0, "tanque_225", 0.5F, 1.0F, 0.49599953043619693F);
        escalar(g0, "tanque_226", 0.3457060738075725F, 1.0F, 0.4838615579684394F);
        escalar(g0, "tanque_227", 0.39688000405562085F, 1.0F, 0.4364978174127795F);
        escalar(g0, "tanque_228", 0.440801123306464F, 1.0F, 0.43300828653704104F);
        escalar(g0, "tanque_229", 0.44706020330056023F, 1.0F, 0.3706779110343064F);
        escalar(g0, "tanque_230", 0.4233181806000526F, 1.0F, 0.4353911871549686F);
        escalar(g0, "tanque_231", 0.4233181806000527F, 1.0F, 0.4353911871549655F);
        escalar(g0, "tanque_232", 0.44706020330056023F, 1.0F, 0.3706779110343044F);
        escalar(g0, "tanque_233", 0.4408011233064638F, 1.0F, 0.4330082865370395F);
        escalar(g0, "tanque_234", 0.39688000405562107F, 1.0F, 0.4364978174127779F);
        escalar(g0, "tanque_235", 0.3457060738075726F, 1.0F, 0.48386155796843766F);
        escalar(g0, "tanque_236", 0.5F, 1.0F, 0.4959995304361957F);
        escalar(g0, "tanque_237", 0.3457060738075726F, 1.0F, 0.48386155796843766F);
        escalar(g0, "tanque_238", 0.39688000405562107F, 1.0F, 0.4364978174127779F);
        escalar(g0, "tanque_239", 0.4408011233064638F, 1.0F, 0.4330082865370395F);
        escalar(g0, "tanque_240", 0.44706020330056023F, 1.0F, 0.3706779110343044F);
        escalar(g0, "tanque_241", 0.4233181806000527F, 1.0F, 0.4353911871549655F);
        escalar(g0, "tanque_242", 0.4233181806000526F, 1.0F, 0.43539118715496766F);
        escalar(g0, "tanque_243", 0.4470602033005601F, 1.0F, 0.370677911034305F);
        escalar(g0, "tanque_244", 0.44080112330646415F, 1.0F, 0.4330082865370399F);
        escalar(g0, "tanque_245", 0.3968800040556208F, 1.0F, 0.4364978174127782F);
        escalar(g0, "tanque_246", 0.34570607380757296F, 1.0F, 0.48386155796843777F);
        escalar(g0, "tanque_247", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_248", 0.34570607380757296F, 1.0F, 0.48386155796843777F);
        escalar(g0, "tanque_249", 0.3968800040556208F, 1.0F, 0.4364978174127782F);
        escalar(g0, "tanque_250", 0.44080112330646415F, 1.0F, 0.4330082865370399F);
        escalar(g0, "tanque_251", 0.4470602033005601F, 1.0F, 0.370677911034305F);
        escalar(g0, "tanque_252", 0.4233181806000526F, 1.0F, 0.43539118715496766F);
        escalar(g0, "tanque_253", 0.4233181806000528F, 1.0F, 0.43539118715496783F);
        escalar(g0, "tanque_254", 0.44706020330055996F, 1.0F, 0.3706779110343061F);
        escalar(g0, "tanque_255", 0.4408011233064643F, 1.0F, 0.4330082865370412F);
        escalar(g0, "tanque_256", 0.3968800040556208F, 1.0F, 0.43649781741277954F);
        escalar(g0, "tanque_257", 0.34570607380757273F, 1.0F, 0.4838615579684394F);
        escalar(g0, "tanque_258", 0.5F, 1.0F, 0.4959995304361972F);
        escalar(g0, "tanque_259", 0.34570607380757273F, 1.0F, 0.4838615579684394F);
        escalar(g0, "tanque_260", 0.3968800040556208F, 1.0F, 0.43649781741277954F);
        escalar(g0, "tanque_261", 0.4408011233064643F, 1.0F, 0.4330082865370412F);
        escalar(g0, "tanque_262", 0.44706020330055996F, 1.0F, 0.3706779110343061F);
        escalar(g0, "tanque_263", 0.4233181806000528F, 1.0F, 0.4353911871549678F);
        escalar(g0, "domo_0", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "domo_1", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "domo_2", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "domo_3", 0.8827067523629074F, 1.0F, 0.8827067523629074F);
        escalar(g0, "domo_aro_0", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "domo_aro_1", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "domo_aro_2", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "domo_aro_3", 0.9807852804032304F, 1.0F, 0.9807852804032304F);
        escalar(g0, "domo_tapa", 0.24615384615384614F, 0.6F, 0.24615384615384614F);
        escalar(g0, "valvula_0", 0.12318393766817158F, 1.0F, 0.12318393766817158F);
        escalar(g0, "valvula_1", 0.12318393766817158F, 1.0F, 0.12318393766817158F);
        escalar(g0, "escalerai_l00", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_l01", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_l10", 0.6F, 0.8912468724513545F, 0.6F);
        escalar(g0, "escalerai_l11", 0.6F, 0.8912468724513545F, 0.6F);
        escalar(g0, "escalerai_p0", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_p1", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_p2", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_p3", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_p4", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_p5", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_p6", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerai_p7", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_l00", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_l01", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_l10", 0.6F, 0.8912468724513545F, 0.6F);
        escalar(g0, "escalerad_l11", 0.6F, 0.8912468724513545F, 0.6F);
        escalar(g0, "escalerad_p0", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_p1", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_p2", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_p3", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_p4", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_p5", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_p6", 0.6F, 1.0F, 0.6F);
        escalar(g0, "escalerad_p7", 0.6F, 1.0F, 0.6F);
        escalar(g0, "volante", 0.24761904761904763F, 0.6F, 0.24761904761904763F);
    }

    private static void escalas2(ModelPart g0) {
        escalar(g0, "bogie0_cordonii", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordonid", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordondi", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordondd", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordonii", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordonid", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordondi", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordondd", 0.75F, 0.9013878188659973F, 0.75F);
    }
}
