package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "P36" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloP36 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("p36"), "main"),
            LocomotoraMod.id("textures/entity/p36.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -36.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -36.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -36.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -17.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -17.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -17.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 2.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 2.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 2.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi3_0", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 21.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi3_1", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 21.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi3_2", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 21.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 8.5F, 3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_i", DatosModelo.MOTRIZ, 8.5F, 3.0F, 0.0F, -50.0F, 2.0F, -11.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_i", DatosModelo.CRUCETA, 8.5F, 3.0F, 0.0F, -50.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -36.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -36.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -36.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -17.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -17.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -17.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 2.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 2.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 2.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd3_0", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 21.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd3_1", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 21.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd3_2", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 21.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 8.5F, 3.0F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_d", DatosModelo.MOTRIZ, 8.5F, 3.0F, 1.5707963267948966F, -50.0F, 2.0F, -11.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_d", DatosModelo.CRUCETA, 8.5F, 3.0F, 1.5707963267948966F, -50.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -82.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -82.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -82.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -70.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -70.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -70.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -82.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -82.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -82.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -70.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -70.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -70.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 42.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 42.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 42.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 54.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 54.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 54.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 42.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 42.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 42.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 54.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 54.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 54.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 38.72F, -35.32F, 0.0F, "locomotora", 4.8F, -2.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.0F, 0.0F, 43.0F, -22.0F, 0.0F, "locomotora", -0.22F, -8.0F, 0.0F),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 90.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 90.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 90.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 102.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 102.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 102.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 136.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 136.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 136.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 148.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 148.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 148.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 160.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("tri5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 160.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 160.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 78.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 90.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 90.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 90.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 102.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 102.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 102.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 136.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 136.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 136.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 148.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 148.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 148.0F, -4.5F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 160.0F, -4.5F, 0.0F, "tender"),
                new DatosModelo.Animada("trd5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 160.0F, -4.5F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 160.0F, -4.5F, 1.0471975511965976F, "tender")),
            ModeloP36::crearCapa,
            16.0F,
            ModeloP36::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -76.0F, 48.0F),
                new DatosModelo.Segmento("tender", 90.0F, 148.0F)));

    private ModeloP36() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g1);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(72, 259).addBox(-8.5F, -8.5F, -6.0F, 17.0F, 17.0F, 2.0F).texOffs(770, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(110, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(96, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(896, 358).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-36.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(806, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(122, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-36.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(842, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(134, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-36.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(72, 259).addBox(-8.5F, -8.5F, -6.0F, 17.0F, 17.0F, 2.0F).texOffs(770, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(110, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(106, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(902, 358).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-17.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(806, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(122, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-17.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(842, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(134, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-17.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(72, 259).addBox(-8.5F, -8.5F, -6.0F, 17.0F, 17.0F, 2.0F).texOffs(770, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(110, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(116, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(908, 358).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(2.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(806, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(122, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(2.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(842, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(134, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(2.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi3_0", CubeListBuilder.create().texOffs(72, 259).addBox(-8.5F, -8.5F, -6.0F, 17.0F, 17.0F, 2.0F).texOffs(770, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(110, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(126, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(914, 358).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(21.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmi3_1", CubeListBuilder.create().texOffs(806, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(122, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(21.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi3_2", CubeListBuilder.create().texOffs(842, 315).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(134, 259).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(21.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(832, 365).addBox(-36.0F, -12.0F, -7.5F, 57.0F, 1.0F, 1.0F).texOffs(468, 351).addBox(-37.5F, -13.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(476, 351).addBox(-18.5F, -13.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(484, 351).addBox(0.5F, -13.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(492, 351).addBox(19.5F, -13.0F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_i", CubeListBuilder.create().texOffs(116, 367).addBox(-50.0F, -0.5F, -0.5F, 50.0F, 1.0F, 1.0F).texOffs(500, 351).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(2.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("cruceta_i", CubeListBuilder.create().texOffs(136, 322).addBox(-49.40991885387112F, -10.0F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(440, 367).addBox(-57.90991885387112F, -9.0F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_i", CubeListBuilder.create().texOffs(320, 367).addBox(-54.90991885387112F, -7.0F, -9.0F, 14.0F, 1.0F, 1.0F).texOffs(350, 367).addBox(-54.90991885387112F, -11.0F, -9.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_i_0", CubeListBuilder.create().texOffs(640, 278).addBox(-66.90991885387112F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(288, 278).addBox(-66.90991885387112F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, -8.5F));
        g.addOrReplaceChild("cil_i_1", CubeListBuilder.create().texOffs(668, 278).addBox(-66.90991885387112F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(332, 278).addBox(-66.90991885387112F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_2", CubeListBuilder.create().texOffs(696, 278).addBox(-66.90991885387112F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(376, 278).addBox(-66.90991885387112F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_3", CubeListBuilder.create().texOffs(724, 278).addBox(-66.90991885387112F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(420, 278).addBox(-66.90991885387112F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_0", CubeListBuilder.create().texOffs(602, 293).addBox(-67.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(888, 278).addBox(-67.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, -8.5F));
        g.addOrReplaceChild("cil_i_a_1", CubeListBuilder.create().texOffs(608, 293).addBox(-67.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(910, 278).addBox(-67.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_2", CubeListBuilder.create().texOffs(614, 293).addBox(-67.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(932, 278).addBox(-67.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_3", CubeListBuilder.create().texOffs(620, 293).addBox(-67.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(954, 278).addBox(-67.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_0", CubeListBuilder.create().texOffs(626, 293).addBox(-55.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(976, 278).addBox(-55.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, -8.5F));
        g.addOrReplaceChild("cil_i_b_1", CubeListBuilder.create().texOffs(632, 293).addBox(-55.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(998, 278).addBox(-55.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_2", CubeListBuilder.create().texOffs(638, 293).addBox(-55.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(0, 293).addBox(-55.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_3", CubeListBuilder.create().texOffs(644, 293).addBox(-55.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(22, 293).addBox(-55.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(72, 259).addBox(-8.5F, -8.5F, 4.0F, 17.0F, 17.0F, 2.0F).texOffs(770, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(110, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(146, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(920, 358).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-36.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(806, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(122, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-36.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(842, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(134, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-36.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(72, 259).addBox(-8.5F, -8.5F, 4.0F, 17.0F, 17.0F, 2.0F).texOffs(770, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(110, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(156, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(926, 358).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-17.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(806, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(122, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-17.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(842, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(134, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-17.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(72, 259).addBox(-8.5F, -8.5F, 4.0F, 17.0F, 17.0F, 2.0F).texOffs(770, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(110, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(166, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(932, 358).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(2.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(806, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(122, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(2.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(842, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(134, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(2.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd3_0", CubeListBuilder.create().texOffs(72, 259).addBox(-8.5F, -8.5F, 4.0F, 17.0F, 17.0F, 2.0F).texOffs(770, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(110, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(176, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(938, 358).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(21.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmd3_1", CubeListBuilder.create().texOffs(806, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(122, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(21.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd3_2", CubeListBuilder.create().texOffs(842, 315).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(134, 259).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(21.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(0, 367).addBox(-36.0F, -12.0F, 6.5F, 57.0F, 1.0F, 1.0F).texOffs(508, 351).addBox(-37.5F, -13.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(516, 351).addBox(-18.5F, -13.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(524, 351).addBox(0.5F, -13.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(532, 351).addBox(19.5F, -13.0F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_d", CubeListBuilder.create().texOffs(218, 367).addBox(-50.0F, -0.5F, -0.5F, 50.0F, 1.0F, 1.0F).texOffs(540, 351).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(2.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("cruceta_d", CubeListBuilder.create().texOffs(186, 322).addBox(-49.40991885387112F, -10.0F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(462, 367).addBox(-57.90991885387112F, -9.0F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_d", CubeListBuilder.create().texOffs(380, 367).addBox(-54.90991885387112F, -7.0F, 8.0F, 14.0F, 1.0F, 1.0F).texOffs(410, 367).addBox(-54.90991885387112F, -11.0F, 8.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_d_0", CubeListBuilder.create().texOffs(752, 278).addBox(-66.90991885387112F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(464, 278).addBox(-66.90991885387112F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, 8.5F));
        g.addOrReplaceChild("cil_d_1", CubeListBuilder.create().texOffs(780, 278).addBox(-66.90991885387112F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(508, 278).addBox(-66.90991885387112F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_2", CubeListBuilder.create().texOffs(808, 278).addBox(-66.90991885387112F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(552, 278).addBox(-66.90991885387112F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_3", CubeListBuilder.create().texOffs(836, 278).addBox(-66.90991885387112F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(596, 278).addBox(-66.90991885387112F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_0", CubeListBuilder.create().texOffs(650, 293).addBox(-67.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(44, 293).addBox(-67.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, 8.5F));
        g.addOrReplaceChild("cil_d_a_1", CubeListBuilder.create().texOffs(656, 293).addBox(-67.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(66, 293).addBox(-67.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_2", CubeListBuilder.create().texOffs(662, 293).addBox(-67.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(88, 293).addBox(-67.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_3", CubeListBuilder.create().texOffs(668, 293).addBox(-67.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(110, 293).addBox(-67.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_0", CubeListBuilder.create().texOffs(674, 293).addBox(-55.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(132, 293).addBox(-55.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, 8.5F));
        g.addOrReplaceChild("cil_d_b_1", CubeListBuilder.create().texOffs(680, 293).addBox(-55.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(154, 293).addBox(-55.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_2", CubeListBuilder.create().texOffs(686, 293).addBox(-55.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(176, 293).addBox(-55.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_3", CubeListBuilder.create().texOffs(692, 293).addBox(-55.40991885387112F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(198, 293).addBox(-55.40991885387112F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rbi0_0", CubeListBuilder.create().texOffs(794, 293).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(336, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(838, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(196, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-82.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi0_1", CubeListBuilder.create().texOffs(358, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(846, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-82.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi0_2", CubeListBuilder.create().texOffs(380, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(854, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-82.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbi1_0", CubeListBuilder.create().texOffs(794, 293).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(336, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(838, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(206, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-70.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi1_1", CubeListBuilder.create().texOffs(358, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(846, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-70.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi1_2", CubeListBuilder.create().texOffs(380, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(854, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-70.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd0_0", CubeListBuilder.create().texOffs(794, 293).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(336, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(838, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-82.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd0_1", CubeListBuilder.create().texOffs(358, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(846, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-82.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd0_2", CubeListBuilder.create().texOffs(380, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(854, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-82.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd1_0", CubeListBuilder.create().texOffs(794, 293).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(336, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(838, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(226, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-70.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd1_1", CubeListBuilder.create().texOffs(358, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(846, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-70.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd1_2", CubeListBuilder.create().texOffs(380, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(854, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-70.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(864, 278).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(882, 315).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(572, 293).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(236, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(42.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(906, 315).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(582, 293).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(930, 315).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(592, 293).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti1_0", CubeListBuilder.create().texOffs(864, 278).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(882, 315).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(572, 293).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(246, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(54.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti1_1", CubeListBuilder.create().texOffs(906, 315).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(582, 293).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(54.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti1_2", CubeListBuilder.create().texOffs(930, 315).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(592, 293).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(54.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(864, 278).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(882, 315).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(572, 293).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(256, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(42.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(906, 315).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(582, 293).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(930, 315).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(592, 293).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd1_0", CubeListBuilder.create().texOffs(864, 278).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(882, 315).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(572, 293).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(266, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(54.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd1_1", CubeListBuilder.create().texOffs(906, 315).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(582, 293).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(54.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd1_2", CubeListBuilder.create().texOffs(930, 315).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(592, 293).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(54.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(146, 259).addBox(-86.0F, -20.0F, 2.0F, 146.0F, 16.0F, 1.0F).texOffs(440, 259).addBox(-86.0F, -20.0F, -3.0F, 146.0F, 16.0F, 1.0F).texOffs(646, 199).addBox(-90.0F, -15.0F, -12.0F, 3.0F, 7.0F, 24.0F).texOffs(556, 351).addBox(-92.0F, -13.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(0, 232).addBox(-87.0F, -21.0F, -13.0F, 123.0F, 1.0F, 26.0F).texOffs(274, 315).addBox(-87.0F, -21.0F, 12.0F, 123.0F, 5.0F, 1.0F).texOffs(522, 315).addBox(-87.0F, -21.0F, -13.0F, 123.0F, 5.0F, 1.0F).texOffs(678, 139).addBox(34.0F, -36.0F, -10.0F, 2.0F, 15.0F, 20.0F), PartPose.ZERO);
        g.addOrReplaceChild("tope_i_0", CubeListBuilder.create().texOffs(406, 199).addBox(-93.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(722, 139).addBox(-93.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("tope_i_1", CubeListBuilder.create().texOffs(426, 199).addBox(-93.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(780, 139).addBox(-93.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_i_2", CubeListBuilder.create().texOffs(446, 199).addBox(-93.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(838, 139).addBox(-93.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_0", CubeListBuilder.create().texOffs(698, 293).addBox(-94.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(220, 293).addBox(-94.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("tope_ic_1", CubeListBuilder.create().texOffs(704, 293).addBox(-94.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(242, 293).addBox(-94.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_2", CubeListBuilder.create().texOffs(710, 293).addBox(-94.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(264, 293).addBox(-94.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_3", CubeListBuilder.create().texOffs(716, 293).addBox(-94.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(286, 293).addBox(-94.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_0", CubeListBuilder.create().texOffs(466, 199).addBox(-93.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(896, 139).addBox(-93.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("tope_d_1", CubeListBuilder.create().texOffs(486, 199).addBox(-93.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(954, 139).addBox(-93.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("tope_d_2", CubeListBuilder.create().texOffs(506, 199).addBox(-93.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(0, 199).addBox(-93.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_0", CubeListBuilder.create().texOffs(722, 293).addBox(-94.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(308, 293).addBox(-94.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("tope_dc_1", CubeListBuilder.create().texOffs(728, 293).addBox(-94.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(330, 293).addBox(-94.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_2", CubeListBuilder.create().texOffs(734, 293).addBox(-94.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(352, 293).addBox(-94.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_3", CubeListBuilder.create().texOffs(740, 293).addBox(-94.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(374, 293).addBox(-94.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_0", CubeListBuilder.create().texOffs(480, 70).addBox(-80.0F, -31.0F, -3.5F, 18.0F, 62.0F, 7.0F).texOffs(276, 0).addBox(-80.0F, -3.5F, -31.0F, 18.0F, 7.0F, 62.0F), PartPose.offset(0.0F, -31.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_1", CubeListBuilder.create().texOffs(530, 70).addBox(-80.0F, -31.0F, -3.5F, 18.0F, 62.0F, 7.0F).texOffs(436, 0).addBox(-80.0F, -3.5F, -31.0F, 18.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -31.0F, 0.0F, 0.2243994752564138F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_2", CubeListBuilder.create().texOffs(580, 70).addBox(-80.0F, -31.0F, -3.5F, 18.0F, 62.0F, 7.0F).texOffs(596, 0).addBox(-80.0F, -3.5F, -31.0F, 18.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -31.0F, 0.0F, 0.4487989505128276F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_3", CubeListBuilder.create().texOffs(630, 70).addBox(-80.0F, -31.0F, -3.5F, 18.0F, 62.0F, 7.0F).texOffs(756, 0).addBox(-80.0F, -3.5F, -31.0F, 18.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -31.0F, 0.0F, 0.6731984257692414F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_4", CubeListBuilder.create().texOffs(680, 70).addBox(-80.0F, -31.0F, -3.5F, 18.0F, 62.0F, 7.0F).texOffs(0, 70).addBox(-80.0F, -3.5F, -31.0F, 18.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -31.0F, 0.0F, 0.8975979010256552F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_5", CubeListBuilder.create().texOffs(730, 70).addBox(-80.0F, -31.0F, -3.5F, 18.0F, 62.0F, 7.0F).texOffs(160, 70).addBox(-80.0F, -3.5F, -31.0F, 18.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -31.0F, 0.0F, 1.121997376282069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_6", CubeListBuilder.create().texOffs(780, 70).addBox(-80.0F, -31.0F, -3.5F, 18.0F, 62.0F, 7.0F).texOffs(320, 70).addBox(-80.0F, -3.5F, -31.0F, 18.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -31.0F, 0.0F, 1.3463968515384828F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta", CubeListBuilder.create().texOffs(0, 0).addBox(-34.5F, 0.0F, -34.5F, 69.0F, 1.0F, 69.0F), PartPose.offsetAndRotation(-80.1F, -31.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("placa", CubeListBuilder.create().texOffs(392, 232).addBox(-11.5F, 0.0F, -11.5F, 23.0F, 1.0F, 23.0F), PartPose.offsetAndRotation(-80.7F, -31.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(120, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -40.331534385059115F, 1.0514114129435854F, 3.029393831116578F, -0.0004541206352953179F, -0.004030443302617234F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(176, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -40.43028078066821F, 1.0625374596414012F, 3.029393831116578F, -0.00045412063529533605F, -0.004030443302617088F));
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(232, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -40.529027176277296F, 1.073663506339217F, 3.0293938311165762F, -0.0004541206352953179F, -0.004030443302617088F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(288, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -40.627773571886394F, 1.0847895530370328F, 3.0293938311165776F, -0.0004541206352953179F, -0.004030443302617088F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(344, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -39.86361228589805F, 3.1015120802740475F, 2.8049960049145133F, -0.0013395907555966565F, -0.003828342072586356F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(400, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -39.95740712490226F, 3.1343323139277417F, 2.804996004914513F, -0.0013395907555966747F, -0.003828342072586211F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(456, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -40.05120196390647F, 3.167152547581435F, 2.8049960049145137F, -0.0013395907555966565F, -0.003828342072586211F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(512, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -40.14499680291068F, 3.199972781235129F, 2.8049960049145137F, -0.0013395907555966383F, -0.003828342072586356F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(568, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -38.95123165550037F, 4.996089981112978F, 2.5805976708439147F, -0.002157889110863485F, -0.003434272927728157F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(624, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -39.03537167301889F, 5.048958658161793F, 2.5805976708439156F, -0.002157889110863521F, -0.0034342729277283017F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(680, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -39.11951169053742F, 5.101827335210608F, 2.580597670843916F, -0.002157889110863485F, -0.003434272927728157F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(736, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -39.203651708055936F, 5.154696012259422F, 2.580597670843915F, -0.002157889110863467F, -0.003434272927728157F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(792, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -37.640143068443955F, 6.640143068443956F, 2.3561986028780333F, -0.002867982962466345F, -0.002867994757586897F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(848, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -37.710409132660295F, 6.710409132660295F, 2.3561986028780333F, -0.0028679829624664176F, -0.0028679947575870417F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(904, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -37.780675196876636F, 6.780675196876635F, 2.356198602878033F, -0.002867982962466345F, -0.002867994757586897F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(960, 327).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -37.85094126109297F, 6.850941261092972F, 2.3561986028780337F, -0.002867982962466345F, -0.002867994757586897F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(0, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -35.99608998111298F, 7.95123165550037F, 2.1317987203443125F, -0.0034342649318789254F, -0.0021579018362074547F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(56, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -36.048958658161794F, 8.035371673018894F, 2.1317987203443125F, -0.003434264931879034F, -0.0021579018362073094F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(112, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -36.10182733521061F, 8.119511690537417F, 2.131798720344312F, -0.0034342649318789614F, -0.0021579018362073094F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(168, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -36.15469601225942F, 8.203651708055938F, 2.1317987203443125F, -0.0034342649318789614F, -0.0021579018362074547F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(224, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -34.10151208027405F, 8.863612285898046F, 1.9073981039053474F, -0.0038283386375835247F, -0.001339600572301948F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(280, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -34.13433231392774F, 8.957407124902259F, 1.9073981039053478F, -0.0038283386375836696F, -0.001339600572301948F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(336, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -34.16715254758144F, 9.051201963906472F, 1.9073981039053483F, -0.0038283386375835607F, -0.001339600572301803F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(392, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -34.19997278123513F, 9.144996802910685F, 1.9073981039053471F, -0.0038283386375835607F, -0.001339600572301948F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(448, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -32.05141141294359F, 9.331534385059117F, 1.6829969795854336F, -0.004030442887024649F, -0.00045412432379497963F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(504, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -32.062537459641405F, 9.430280780668209F, 1.6829969795854334F, -0.004030442887024758F, -0.0004541243237951246F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(560, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -32.073663506339216F, 9.5290271762773F, 1.6829969795854332F, -0.004030442887024649F, -0.00045412432379497963F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(616, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -32.084789553037034F, 9.62777357188639F, 1.6829969795854334F, -0.004030442887024649F, -0.00045412432379497963F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(672, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -29.948588587056413F, 9.331534385059117F, 1.4585956740043595F, -0.004030442887024649F, 0.00045412432379497963F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(728, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -29.9374625403586F, 9.430280780668209F, 1.4585956740043597F, -0.004030442887024758F, 0.0004541243237950521F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(784, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -29.926336493660784F, 9.5290271762773F, 1.45859567400436F, -0.004030442887024649F, 0.0004541243237950521F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(840, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -29.915210446962966F, 9.62777357188639F, 1.45859567400436F, -0.004030442887024649F, 0.0004541243237950521F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(896, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -27.89848791972595F, 8.863612285898046F, 1.2341945496844458F, -0.0038283386375835607F, 0.001339600572301803F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(952, 331).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -27.86566768607226F, 8.957407124902259F, 1.2341945496844458F, -0.0038283386375836696F, 0.001339600572301948F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(0, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -27.832847452418566F, 9.051201963906472F, 1.2341945496844455F, -0.0038283386375835247F, 0.001339600572301948F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(56, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -27.80002721876487F, 9.144996802910685F, 1.2341945496844455F, -0.0038283386375835607F, 0.001339600572301948F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(112, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -26.003910018887026F, 7.951231655500373F, 1.0097939332454815F, -0.0034342649318789796F, 0.0021579018362073094F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(168, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -25.95104134183821F, 8.035371673018897F, 1.0097939332454817F, -0.003434264931879016F, 0.002157901836207382F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(224, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -25.898172664789396F, 8.119511690537419F, 1.0097939332454817F, -0.003434264931878943F, 0.002157901836207382F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(280, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -25.845303987740582F, 8.203651708055942F, 1.0097939332454817F, -0.0034342649318789614F, 0.002157901836207382F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(336, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -24.359856931556045F, 6.640143068443958F, 0.7853940507117603F, -0.0028679829624663634F, 0.002867994757586897F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(392, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -24.289590867339708F, 6.710409132660297F, 0.78539405071176F, -0.0028679829624663994F, 0.0028679947575869693F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(448, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -24.219324803123367F, 6.7806751968766354F, 0.7853940507117603F, -0.0028679829624663634F, 0.0028679947575869693F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(504, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -24.14905873890703F, 6.850941261092974F, 0.7853940507117598F, -0.002867982962466345F, 0.002867994757586897F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(560, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -23.048768344499628F, 4.996089981112979F, 0.5609949827458777F, -0.002157889110863485F, 0.0034342729277280844F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(616, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -22.964628326981106F, 5.048958658161794F, 0.5609949827458779F, -0.002157889110863521F, 0.0034342729277283017F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(672, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -22.880488309462585F, 5.101827335210608F, 0.560994982745878F, -0.002157889110863485F, 0.0034342729277282292F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(728, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -22.79634829194406F, 5.154696012259423F, 0.5609949827458783F, -0.002157889110863485F, 0.003434272927728157F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(784, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -22.136387714101954F, 3.101512080274051F, 0.33659664867528083F, -0.0013395907555966565F, 0.003828342072586211F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(840, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -22.04259287509774F, 3.134332313927745F, 0.3365966486752812F, -0.0013395907555966747F, 0.003828342072586356F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(896, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -21.948798036093528F, 3.167152547581438F, 0.33659664867528005F, -0.0013395907555966565F, 0.003828342072586211F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(952, 335).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -21.855003197089314F, 3.199972781235132F, 0.33659664867527955F, -0.0013395907555966656F, 0.0038283420725862835F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(0, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -21.668465614940885F, 1.0514114129435888F, 0.11219882247321568F, -0.0004541206352953182F, 0.004030443302617161F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(56, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -21.569719219331795F, 1.0625374596414046F, 0.11219882247321587F, -0.0004541206352953363F, 0.004030443302617161F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(112, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -21.4709728237227F, 1.0736635063392204F, 0.11219882247321689F, -0.0004541206352953182F, 0.004030443302617088F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(168, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -21.37222642811361F, 1.0847895530370362F, 0.1121988224732171F, -0.00045412063529532727F, 0.004030443302617088F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(224, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -21.66846561494088F, -1.0514114129435843F, -0.11219882247321589F, 0.0004541206352953267F, 0.004030443302617161F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(280, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -21.569719219331787F, -1.0625374596414001F, -0.11219882247321607F, 0.0004541206352953267F, 0.004030443302617161F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(336, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -21.4709728237227F, -1.073663506339216F, -0.11219882247321626F, 0.0004541206352953267F, 0.004030443302617161F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(392, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -21.37222642811361F, -1.0847895530370315F, -0.11219882247321569F, 0.0004541206352953176F, 0.004030443302617088F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(448, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -22.13638771410195F, -3.1015120802740466F, -0.3365966486752794F, 0.0013395907555966474F, 0.0038283420725862835F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(504, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -22.042592875097743F, -3.1343323139277404F, -0.3365966486752797F, 0.0013395907555966836F, 0.0038283420725862835F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(560, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -21.948798036093528F, -3.1671525475814346F, -0.33659664867528005F, 0.0013395907555966656F, 0.0038283420725862835F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(616, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -21.855003197089314F, -3.199972781235128F, -0.3365966486752805F, 0.0013395907555966383F, 0.0038283420725862835F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(672, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -23.048768344499628F, -4.996089981112975F, -0.5609949827458784F, 0.002157889110863467F, 0.0034342729277282292F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(728, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -22.964628326981106F, -5.04895865816179F, -0.5609949827458779F, 0.0021578891108635393F, 0.0034342729277282292F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(784, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -22.88048830946258F, -5.101827335210605F, -0.5609949827458776F, 0.002157889110863485F, 0.0034342729277282292F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(840, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -22.796348291944057F, -5.15469601225942F, -0.5609949827458777F, 0.002157889110863467F, 0.003434272927728157F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(896, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -24.35985693155604F, -6.640143068443954F, -0.7853940507117582F, 0.002867982962466345F, 0.0028679947575869693F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(952, 339).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -24.2895908673397F, -6.710409132660293F, -0.7853940507117584F, 0.0028679829624664176F, 0.0028679947575869693F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(0, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -24.219324803123364F, -6.780675196876631F, -0.7853940507117592F, 0.002867982962466345F, 0.002867994757586897F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(56, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -24.149058738907023F, -6.850941261092968F, -0.7853940507117595F, 0.002867982962466345F, 0.002867994757586897F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(112, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -26.003910018887016F, -7.951231655500369F, -1.009793933245481F, 0.0034342649318789614F, 0.002157901836207382F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(168, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -25.9510413418382F, -8.035371673018892F, -1.0097939332454808F, 0.003434264931878998F, 0.002157901836207382F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(224, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -25.89817266478939F, -8.119511690537415F, -1.0097939332454804F, 0.0034342649318789614F, 0.0021579018362073094F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(280, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -25.84530398774057F, -8.203651708055936F, -1.0097939332454797F, 0.0034342649318789614F, 0.002157901836207382F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(336, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -27.898487919725945F, -8.863612285898043F, -1.2341945496844444F, 0.0038283386375835607F, 0.001339600572301948F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(392, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -27.86566768607225F, -8.957407124902257F, -1.2341945496844446F, 0.003828338637583597F, 0.0013396005723018756F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(448, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -27.832847452418555F, -9.051201963906468F, -1.2341945496844446F, 0.003828338637583597F, 0.001339600572301948F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(504, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -27.80002721876486F, -9.144996802910683F, -1.2341945496844446F, 0.0038283386375835607F, 0.001339600572301948F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(560, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -29.94858858705641F, -9.331534385059115F, -1.4585956740043595F, 0.004030442887024649F, 0.0004541243237950521F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(616, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -29.937462540358595F, -9.430280780668207F, -1.458595674004359F, 0.0040304428870247214F, 0.00045412432379497963F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(672, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -29.926336493660777F, -9.5290271762773F, -1.4585956740043593F, 0.004030442887024685F, 0.0004541243237951246F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(728, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -29.91521044696296F, -9.62777357188639F, -1.4585956740043595F, 0.004030442887024649F, 0.0004541243237950521F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(784, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -32.05141141294359F, -9.331534385059117F, -1.6829969795854336F, 0.004030442887024649F, -0.00045412432379497963F));
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(840, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -32.062537459641405F, -9.430280780668209F, -1.6829969795854334F, 0.004030442887024758F, -0.0004541243237951246F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(896, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -32.073663506339216F, -9.5290271762773F, -1.682996979585433F, 0.004030442887024649F, -0.0004541243237949071F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(952, 343).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -32.08478955303703F, -9.62777357188639F, -1.6829969795854334F, 0.004030442887024649F, -0.00045412432379497963F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(0, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -34.10151208027405F, -8.863612285898046F, -1.9073981039053467F, 0.0038283386375835607F, -0.001339600572301803F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(56, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -34.13433231392774F, -8.95740712490226F, -1.9073981039053471F, 0.003828338637583633F, -0.0013396005723020931F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(112, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -34.16715254758144F, -9.051201963906472F, -1.9073981039053474F, 0.0038283386375835607F, -0.001339600572301803F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(168, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -34.19997278123513F, -9.144996802910685F, -1.907398103905347F, 0.0038283386375835607F, -0.001339600572301803F));
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(224, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -35.99608998111297F, -7.951231655500372F, -2.1317987203443125F, 0.0034342649318789614F, -0.0021579018362073094F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(280, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -36.048958658161794F, -8.035371673018895F, -2.1317987203443125F, 0.003434264931878998F, -0.0021579018362074547F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(336, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -36.10182733521061F, -8.119511690537419F, -2.1317987203443125F, 0.0034342649318789614F, -0.0021579018362073094F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(392, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -36.15469601225942F, -8.20365170805594F, -2.1317987203443116F, 0.0034342649318789796F, -0.0021579018362073094F));
        g.addOrReplaceChild("caldera_96", CubeListBuilder.create().texOffs(448, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -37.640143068443955F, -6.640143068443959F, -2.356198602878033F, 0.0028679829624663634F, -0.002867994757586897F));
        g.addOrReplaceChild("caldera_97", CubeListBuilder.create().texOffs(504, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -37.71040913266029F, -6.710409132660296F, -2.3561986028780337F, 0.0028679829624663994F, -0.002867994757586897F));
        g.addOrReplaceChild("caldera_98", CubeListBuilder.create().texOffs(560, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -37.78067519687663F, -6.780675196876635F, -2.3561986028780337F, 0.002867982962466345F, -0.0028679947575870417F));
        g.addOrReplaceChild("caldera_99", CubeListBuilder.create().texOffs(616, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -37.85094126109297F, -6.850941261092973F, -2.3561986028780337F, 0.0028679829624663634F, -0.002867994757586897F));
        g.addOrReplaceChild("caldera_100", CubeListBuilder.create().texOffs(672, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -38.95123165550037F, -4.996089981112983F, -2.580597670843916F, 0.002157889110863485F, -0.003434272927728157F));
        g.addOrReplaceChild("caldera_101", CubeListBuilder.create().texOffs(728, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -39.03537167301889F, -5.048958658161799F, -2.580597670843915F, 0.002157889110863521F, -0.003434272927728157F));
        g.addOrReplaceChild("caldera_102", CubeListBuilder.create().texOffs(784, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -39.119511690537415F, -5.101827335210614F, -2.5805976708439156F, 0.002157889110863485F, -0.0034342729277283017F));
        g.addOrReplaceChild("caldera_103", CubeListBuilder.create().texOffs(840, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -39.203651708055936F, -5.1546960122594285F, -2.580597670843916F, 0.002157889110863467F, -0.003434272927728157F));
        g.addOrReplaceChild("caldera_104", CubeListBuilder.create().texOffs(896, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -39.86361228589804F, -3.1015120802740577F, -2.8049960049145115F, 0.0013395907555966474F, -0.003828342072586211F));
        g.addOrReplaceChild("caldera_105", CubeListBuilder.create().texOffs(952, 347).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -39.957407124902254F, -3.1343323139277515F, -2.804996004914511F, 0.0013395907555966927F, -0.003828342072586356F));
        g.addOrReplaceChild("caldera_106", CubeListBuilder.create().texOffs(0, 351).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -40.051201963906465F, -3.1671525475814457F, -2.8049960049145106F, 0.0013395907555966565F, -0.003828342072586211F));
        g.addOrReplaceChild("caldera_107", CubeListBuilder.create().texOffs(56, 351).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -40.14499680291068F, -3.199972781235139F, -2.80499600491451F, 0.0013395907555966474F, -0.003828342072586356F));
        g.addOrReplaceChild("caldera_108", CubeListBuilder.create().texOffs(112, 351).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-49.75F, -40.331534385059115F, -1.0514114129435919F, -3.029393831116577F, 0.0004541206352953275F, -0.004030443302617088F));
        g.addOrReplaceChild("caldera_109", CubeListBuilder.create().texOffs(168, 351).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.25F, -40.430280780668205F, -1.0625374596414079F, -3.0293938311165767F, 0.00045412063529533654F, -0.004030443302617234F));
        g.addOrReplaceChild("caldera_110", CubeListBuilder.create().texOffs(224, 351).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-0.75F, -40.529027176277296F, -1.0736635063392237F, -3.0293938311165767F, 0.00045412063529531844F, -0.004030443302617088F));
        g.addOrReplaceChild("caldera_111", CubeListBuilder.create().texOffs(280, 351).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.75F, -40.627773571886394F, -1.0847895530370393F, -3.029393831116578F, 0.0004541206352953275F, -0.004030443302617088F));
        g.addOrReplaceChild("carcasa", CubeListBuilder.create().texOffs(734, 259).addBox(-76.0F, -41.0F, -6.0F, 112.0F, 3.0F, 12.0F).texOffs(458, 305).addBox(-76.0F, -44.0F, -3.0F, 112.0F, 3.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("carcasa_cantoi_0", CubeListBuilder.create().texOffs(0, 361).addBox(-56.0F, -1.0F, -0.5F, 112.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -41.46352549156242F, -5.9265847744427305F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_1", CubeListBuilder.create().texOffs(226, 361).addBox(-56.0F, -1.0F, -0.5F, 112.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -42.34520337000113F, -5.640110266005152F, -2.0420352248333677F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_2", CubeListBuilder.create().texOffs(452, 361).addBox(-56.0F, -1.0F, -0.5F, 112.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -43.09520337000113F, -5.095203370001131F, -2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_3", CubeListBuilder.create().texOffs(678, 361).addBox(-56.0F, -1.0F, -0.5F, 112.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -43.64011026600515F, -4.345203370001131F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_4", CubeListBuilder.create().texOffs(0, 363).addBox(-56.0F, -1.0F, -0.5F, 112.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -43.92658477444273F, -3.463525491562421F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_0", CubeListBuilder.create().texOffs(226, 363).addBox(-56.0F, -1.0F, -0.5F, 112.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -41.46352549156242F, 5.9265847744427305F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_1", CubeListBuilder.create().texOffs(452, 363).addBox(-56.0F, -1.0F, -0.5F, 112.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -42.34520337000113F, 5.640110266005152F, 2.0420352248333677F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_2", CubeListBuilder.create().texOffs(678, 363).addBox(-56.0F, -1.0F, -0.5F, 112.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -43.09520337000113F, 5.095203370001131F, 2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_3", CubeListBuilder.create().texOffs(0, 365).addBox(-56.0F, -1.0F, -0.5F, 112.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -43.64011026600515F, 4.345203370001131F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_4", CubeListBuilder.create().texOffs(226, 365).addBox(-56.0F, -1.0F, -0.5F, 112.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -43.92658477444273F, 3.463525491562421F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_tapaa", CubeListBuilder.create().texOffs(700, 199).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 24.0F), PartPose.offset(-76.0F, -41.0F, -6.0F));
        g.addOrReplaceChild("carcasa_tapab", CubeListBuilder.create().texOffs(750, 199).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 24.0F), PartPose.offset(35.0F, -41.0F, -6.0F));
        g.addOrReplaceChild("chimenea_0", CubeListBuilder.create().texOffs(140, 315).addBox(-5.0F, -45.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(982, 259).addBox(-1.0F, -45.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offset(-70.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_1", CubeListBuilder.create().texOffs(164, 315).addBox(-5.0F, -45.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(0, 278).addBox(-1.0F, -45.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offsetAndRotation(-70.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_2", CubeListBuilder.create().texOffs(188, 315).addBox(-5.0F, -45.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(24, 278).addBox(-1.0F, -45.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offsetAndRotation(-70.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_3", CubeListBuilder.create().texOffs(212, 315).addBox(-5.0F, -45.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(48, 278).addBox(-1.0F, -45.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offsetAndRotation(-70.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("faro_0", CubeListBuilder.create().texOffs(954, 315).addBox(-5.0F, -0.818181818181818F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(176, 278).addBox(-1.0F, -0.818181818181818F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-80.4F, -42.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_1", CubeListBuilder.create().texOffs(978, 315).addBox(-5.0F, -0.818181818181818F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(200, 278).addBox(-1.0F, -0.818181818181818F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-80.4F, -42.5F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_2", CubeListBuilder.create().texOffs(0, 322).addBox(-5.0F, -0.818181818181818F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(224, 278).addBox(-1.0F, -0.818181818181818F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-80.4F, -42.5F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_3", CubeListBuilder.create().texOffs(24, 322).addBox(-5.0F, -0.818181818181818F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(248, 278).addBox(-1.0F, -0.818181818181818F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-80.4F, -42.5F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_vidrio", CubeListBuilder.create().texOffs(0, 259).addBox(-9.0F, 0.0F, -9.0F, 18.0F, 1.0F, 18.0F), PartPose.offsetAndRotation(-82.02000000000001F, -42.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_base", CubeListBuilder.create().texOffs(236, 315).addBox(-82.0F, -41.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("deflectori", CubeListBuilder.create().texOffs(378, 139).addBox(0.0F, -42.0F, -0.5F, 48.0F, 42.0F, 1.0F), PartPose.offset(-86.0F, -21.0F, -13.0F));
        g.addOrReplaceChild("deflectord", CubeListBuilder.create().texOffs(476, 139).addBox(0.0F, -42.0F, -0.5F, 48.0F, 42.0F, 1.0F), PartPose.offset(-86.0F, -21.0F, 13.0F));
        g.addOrReplaceChild("pasamanos", CubeListBuilder.create().texOffs(452, 365).addBox(-60.0F, -37.0F, 9.5F, 94.0F, 1.0F, 1.0F).texOffs(642, 365).addBox(-60.0F, -37.0F, -10.5F, 94.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(740, 232).addBox(37.0F, -41.0F, 12.0F, 23.0F, 20.0F, 1.0F).texOffs(788, 232).addBox(37.0F, -41.0F, -13.0F, 23.0F, 20.0F, 1.0F).texOffs(298, 232).addBox(37.0F, -22.0F, -12.0F, 23.0F, 1.0F, 24.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_frente", CubeListBuilder.create().texOffs(624, 139).addBox(0.0F, -9.0F, 0.0F, 1.0F, 9.0F, 26.0F), PartPose.offset(36.0F, -35.0F, -13.0F));
        g.addOrReplaceChild("cabina_fuego", CubeListBuilder.create().texOffs(836, 232).addBox(37.0F, -33.0F, -5.0F, 2.0F, 11.0F, 10.0F).texOffs(260, 315).addBox(39.0F, -27.0F, -2.0F, 1.0F, 3.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(396, 322).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -41.28156684839221F, -11.982230097189813F, -2.6990003544068575F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(456, 322).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -42.16293955104396F, -9.911208526720891F, -2.7794716815310276F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(516, 322).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -42.87498202631751F, -7.77604021959999F, -2.859943008655197F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(576, 322).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -43.41308583508825F, -5.590544285649612F, -2.9404143357793693F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(636, 322).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -43.77376829376423F, -3.368865562177053F, -3.0208856629035403F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(696, 322).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -43.954695014704484F, -1.1253830665963498F, -3.101356990027708F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(756, 322).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -43.954695014704484F, 1.1253830665963482F, 3.101356990027708F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(816, 322).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -43.773768293764235F, 3.3688655621770502F, 3.0208856629035403F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(876, 322).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -43.41308583508825F, 5.590544285649611F, 2.9404143357793697F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(936, 322).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -42.87498202631751F, 7.776040219599987F, 2.8599430086551965F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(0, 327).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -42.16293955104396F, 9.911208526720891F, 2.779471681531028F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(60, 327).addBox(-13.5F, -1.0F, -1.5F, 27.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(48.5F, -41.28156684839221F, 11.982230097189813F, 2.6990003544068575F, 0.0F, 0.0F));
        g.addOrReplaceChild("numeroi", CubeListBuilder.create().texOffs(698, 305).addBox(0.0F, -7.0F, -0.5F, 33.0F, 7.0F, 1.0F), PartPose.offset(39.75F, -26.25F, -13.5F));
        g.addOrReplaceChild("numerod", CubeListBuilder.create().texOffs(766, 305).addBox(0.0F, -7.0F, -0.5F, 33.0F, 7.0F, 1.0F), PartPose.offset(39.75F, -26.25F, 13.5F));
        g.addOrReplaceChild("cab_fondo_caldera", CubeListBuilder.create().texOffs(574, 139).addBox(36.6F, -35.0F, -12.0F, 1.0F, 13.0F, 24.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_placa", CubeListBuilder.create().texOffs(272, 278).addBox(37.0F, -39.0F, -3.5F, 1.0F, 6.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(72, 278).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(38.6F, -35.32F, -2.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(962, 358).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(38.72F, -35.32F, -2.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_presion", CubeListBuilder.create().texOffs(124, 278).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(38.6F, -35.32F, 2.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_presion_aguja", CubeListBuilder.create().texOffs(966, 358).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(38.72F, -35.32F, 2.0F, 0.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_nivel", CubeListBuilder.create().texOffs(878, 315).addBox(39.0F, -31.0F, 3.5F, 1.0F, 5.0F, 1.0F).texOffs(944, 358).addBox(39.0F, -26.0F, 3.0F, 1.0F, 1.0F, 2.0F).texOffs(950, 358).addBox(39.0F, -32.0F, 3.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_regulador", CubeListBuilder.create().texOffs(270, 315).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(38.5F, -33.5F, 0.0F, -1.1920024339695F, 0.09966865249116204F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_valvulas", CubeListBuilder.create().texOffs(498, 367).addBox(39.0F, -31.0F, 1.0F, 1.0F, 1.0F, 1.0F).texOffs(502, 367).addBox(39.0F, -31.0F, -4.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_tubo", CubeListBuilder.create().texOffs(694, 305).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 8.0F, 1.0F), PartPose.offset(39.5F, -30.5F, -3.5F));
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(886, 293).addBox(-0.5F, -10.0F, -0.5F, 1.0F, 10.0F, 1.0F).texOffs(548, 351).addBox(-1.0F, -12.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(43.0F, -22.0F, -8.0F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("cab_palanca_cuadrante", CubeListBuilder.create().texOffs(484, 367).addBox(40.0F, -23.0F, -9.5F, 6.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(956, 358).addBox(46.0F, -33.0F, -12.0F, 2.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_freno_manija", CubeListBuilder.create().texOffs(562, 351).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(47.0F, -33.0F, -11.5F, 0.7297276562269664F, 0.0F, -2.0344439357957027F));
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(48, 322).addBox(49.0F, -23.0F, -6.5F, 4.0F, 1.0F, 4.0F).texOffs(428, 305).addBox(53.0F, -29.0F, -6.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(64, 322).addBox(55.0F, -23.0F, -2.0F, 4.0F, 1.0F, 4.0F).texOffs(438, 305).addBox(59.0F, -29.0F, -2.0F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento2", CubeListBuilder.create().texOffs(80, 322).addBox(49.0F, -23.0F, 2.5F, 4.0F, 1.0F, 4.0F).texOffs(448, 305).addBox(53.0F, -29.0F, 2.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(276, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(78.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(78.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(78.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(286, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(90.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri2_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(296, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(102.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri2_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(102.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri2_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(102.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri3_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(306, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(136.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri3_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(136.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri3_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(136.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri4_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(316, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(148.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri4_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(148.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri4_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(148.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri5_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(326, 322).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(160.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("tri5_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(160.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri5_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(160.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(336, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(78.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(78.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(78.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(346, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(90.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(90.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd2_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(356, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(102.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd2_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(102.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd2_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(102.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd3_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(366, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(136.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd3_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(136.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd3_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(136.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd4_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(376, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(148.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd4_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(148.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd4_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(148.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd5_0", CubeListBuilder.create().texOffs(816, 293).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(402, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(386, 322).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(160.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("trd5_1", CubeListBuilder.create().texOffs(424, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(160.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd5_2", CubeListBuilder.create().texOffs(446, 351).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 293).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(160.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(0, 305).addBox(66.0F, -13.0F, 2.0F, 106.0F, 9.0F, 1.0F).texOffs(214, 305).addBox(66.0F, -13.0F, -3.0F, 106.0F, 9.0F, 1.0F).texOffs(834, 305).addBox(73.0F, -9.0F, 7.0F, 34.0F, 6.0F, 1.0F).texOffs(904, 305).addBox(73.0F, -9.0F, -8.0F, 34.0F, 6.0F, 1.0F).texOffs(0, 315).addBox(131.0F, -9.0F, 7.0F, 34.0F, 6.0F, 1.0F).texOffs(70, 315).addBox(131.0F, -9.0F, -8.0F, 34.0F, 6.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(106, 139).addBox(64.0F, -34.0F, -13.0F, 110.0F, 21.0F, 26.0F).texOffs(484, 232).addBox(64.0F, -38.0F, -9.0F, 110.0F, 4.0F, 18.0F).texOffs(860, 232).addBox(66.0F, -39.0F, -9.0F, 44.0F, 1.0F, 18.0F).texOffs(800, 199).addBox(174.0F, -13.0F, -11.0F, 2.0F, 6.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender_caja_cantoi_0", CubeListBuilder.create().texOffs(566, 351).addBox(-55.0F, -1.0F, -1.0F, 110.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(119.0F, -34.61803398874989F, -12.902113032590307F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_1", CubeListBuilder.create().texOffs(790, 351).addBox(-55.0F, -1.0F, -1.0F, 110.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(119.0F, -35.79360449333484F, -12.5201470213402F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_2", CubeListBuilder.create().texOffs(0, 355).addBox(-55.0F, -1.0F, -1.0F, 110.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(119.0F, -36.79360449333484F, -11.79360449333484F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_3", CubeListBuilder.create().texOffs(224, 355).addBox(-55.0F, -1.0F, -1.0F, 110.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(119.0F, -37.5201470213402F, -10.79360449333484F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_4", CubeListBuilder.create().texOffs(448, 355).addBox(-55.0F, -1.0F, -1.0F, 110.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(119.0F, -37.90211303259031F, -9.618033988749895F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_0", CubeListBuilder.create().texOffs(672, 355).addBox(-55.0F, -1.0F, -1.0F, 110.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(119.0F, -34.61803398874989F, 12.902113032590307F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_1", CubeListBuilder.create().texOffs(0, 358).addBox(-55.0F, -1.0F, -1.0F, 110.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(119.0F, -35.79360449333484F, 12.5201470213402F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_2", CubeListBuilder.create().texOffs(224, 358).addBox(-55.0F, -1.0F, -1.0F, 110.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(119.0F, -36.79360449333484F, 11.79360449333484F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_3", CubeListBuilder.create().texOffs(448, 358).addBox(-55.0F, -1.0F, -1.0F, 110.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(119.0F, -37.5201470213402F, 10.79360449333484F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_4", CubeListBuilder.create().texOffs(672, 358).addBox(-55.0F, -1.0F, -1.0F, 110.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(119.0F, -37.90211303259031F, 9.618033988749895F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_tapaa", CubeListBuilder.create().texOffs(830, 70).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 52.0F), PartPose.offset(64.0F, -34.0F, -13.0F));
        g.addOrReplaceChild("tender_caja_tapab", CubeListBuilder.create().texOffs(0, 139).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 52.0F), PartPose.offset(173.0F, -34.0F, -13.0F));
        g.addOrReplaceChild("tope_ti_0", CubeListBuilder.create().texOffs(526, 199).addBox(176.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(58, 199).addBox(176.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("tope_ti_1", CubeListBuilder.create().texOffs(546, 199).addBox(176.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(116, 199).addBox(176.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ti_2", CubeListBuilder.create().texOffs(566, 199).addBox(176.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(174, 199).addBox(176.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_0", CubeListBuilder.create().texOffs(746, 293).addBox(179.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(396, 293).addBox(179.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("tope_tic_1", CubeListBuilder.create().texOffs(752, 293).addBox(179.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(418, 293).addBox(179.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_2", CubeListBuilder.create().texOffs(758, 293).addBox(179.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(440, 293).addBox(179.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_3", CubeListBuilder.create().texOffs(764, 293).addBox(179.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(462, 293).addBox(179.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_0", CubeListBuilder.create().texOffs(586, 199).addBox(176.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(232, 199).addBox(176.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("tope_td_1", CubeListBuilder.create().texOffs(606, 199).addBox(176.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(290, 199).addBox(176.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_2", CubeListBuilder.create().texOffs(626, 199).addBox(176.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(348, 199).addBox(176.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_0", CubeListBuilder.create().texOffs(770, 293).addBox(179.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(484, 293).addBox(179.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("tope_tdc_1", CubeListBuilder.create().texOffs(776, 293).addBox(179.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(506, 293).addBox(179.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_2", CubeListBuilder.create().texOffs(782, 293).addBox(179.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(528, 293).addBox(179.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_3", CubeListBuilder.create().texOffs(788, 293).addBox(179.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(550, 293).addBox(179.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "cil_i_0", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_i_1", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_i_2", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_i_3", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_i_a_0", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_a_1", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_a_2", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_a_3", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_b_0", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_b_1", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_b_2", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_i_b_3", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_0", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_d_1", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_d_2", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_d_3", 1.0F, 0.7453968131064551F, 0.7453968131064551F);
        escalar(g0, "cil_d_a_0", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_a_1", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_a_2", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_a_3", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_b_0", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_b_1", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_b_2", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "cil_d_b_3", 1.0F, 0.8434753411467781F, 0.8434753411467781F);
        escalar(g0, "tope_i_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_ic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_d_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_dc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "caja_humo_0", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_1", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_2", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_3", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_4", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_5", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "caja_humo_6", 1.0F, 0.3205523257720137F, 0.3205523257720137F);
        escalar(g0, "puerta", 0.24927536231884057F, 0.6F, 0.24927536231884057F);
        escalar(g0, "placa", 0.2434782608695652F, 0.6F, 0.2434782608695652F);
        escalar(g0, "caldera_0", 0.9800081632313069F, 1.0F, 0.709108348654283F);
        escalar(g0, "caldera_1", 0.9800081632313069F, 1.0F, 0.7165726470611705F);
        escalar(g0, "caldera_2", 0.9800081632313069F, 1.0F, 0.7240369454680576F);
        escalar(g0, "caldera_3", 0.9800081632313069F, 1.0F, 0.7315012438749444F);
        escalar(g0, "caldera_4", 0.9800081632313069F, 1.0F, 0.7091083486542834F);
        escalar(g0, "caldera_5", 0.9800081632313069F, 1.0F, 0.7165726470611702F);
        escalar(g0, "caldera_6", 0.9800081632313069F, 1.0F, 0.7240369454680572F);
        escalar(g0, "caldera_7", 0.9800081632313069F, 1.0F, 0.7315012438749448F);
        escalar(g0, "caldera_8", 0.9800081632313069F, 1.0F, 0.7091083486542833F);
        escalar(g0, "caldera_9", 0.9800081632313069F, 1.0F, 0.7165726470611701F);
        escalar(g0, "caldera_10", 0.9800081632313069F, 1.0F, 0.7240369454680575F);
        escalar(g0, "caldera_11", 0.9800081632313069F, 1.0F, 0.7315012438749452F);
        escalar(g0, "caldera_12", 0.9800081632313069F, 1.0F, 0.7091083486542832F);
        escalar(g0, "caldera_13", 0.9800081632313069F, 1.0F, 0.7165726470611714F);
        escalar(g0, "caldera_14", 0.9800081632313069F, 1.0F, 0.7240369454680579F);
        escalar(g0, "caldera_15", 0.9800081632313069F, 1.0F, 0.7315012438749443F);
        escalar(g0, "caldera_16", 0.9800081632313069F, 1.0F, 0.7091083486542812F);
        escalar(g0, "caldera_17", 0.9800081632313069F, 1.0F, 0.7165726470611694F);
        escalar(g0, "caldera_18", 0.9800081632313069F, 1.0F, 0.7240369454680575F);
        escalar(g0, "caldera_19", 0.9800081632313069F, 1.0F, 0.7315012438749439F);
        escalar(g0, "caldera_20", 0.9800081632313069F, 1.0F, 0.7091083486542855F);
        escalar(g0, "caldera_21", 0.9800081632313069F, 1.0F, 0.7165726470611706F);
        escalar(g0, "caldera_22", 0.9800081632313069F, 1.0F, 0.7240369454680575F);
        escalar(g0, "caldera_23", 0.9800081632313069F, 1.0F, 0.731501243874947F);
        escalar(g0, "caldera_24", 0.9800081632313069F, 1.0F, 0.7091083486542823F);
        escalar(g0, "caldera_25", 0.9800081632313069F, 1.0F, 0.7165726470611711F);
        escalar(g0, "caldera_26", 0.9800081632313069F, 1.0F, 0.7240369454680574F);
        escalar(g0, "caldera_27", 0.9800081632313069F, 1.0F, 0.7315012438749439F);
        escalar(g0, "caldera_28", 0.9800081632313069F, 1.0F, 0.7091083486542823F);
        escalar(g0, "caldera_29", 0.9800081632313069F, 1.0F, 0.7165726470611699F);
        escalar(g0, "caldera_30", 0.9800081632313069F, 1.0F, 0.7240369454680574F);
        escalar(g0, "caldera_31", 0.9800081632313069F, 1.0F, 0.731501243874945F);
        escalar(g0, "caldera_32", 0.9800081632313069F, 1.0F, 0.7091083486542832F);
        escalar(g0, "caldera_33", 0.9800081632313069F, 1.0F, 0.7165726470611703F);
        escalar(g0, "caldera_34", 0.9800081632313069F, 1.0F, 0.7240369454680575F);
        escalar(g0, "caldera_35", 0.9800081632313069F, 1.0F, 0.7315012438749448F);
        escalar(g0, "caldera_36", 0.9800081632313069F, 1.0F, 0.709108348654282F);
        escalar(g0, "caldera_37", 0.9800081632313069F, 1.0F, 0.7165726470611693F);
        escalar(g0, "caldera_38", 0.9800081632313069F, 1.0F, 0.7240369454680559F);
        escalar(g0, "caldera_39", 0.9800081632313069F, 1.0F, 0.7315012438749431F);
        escalar(g0, "caldera_40", 0.9800081632313069F, 1.0F, 0.7091083486542846F);
        escalar(g0, "caldera_41", 0.9800081632313069F, 1.0F, 0.7165726470611719F);
        escalar(g0, "caldera_42", 0.9800081632313069F, 1.0F, 0.7240369454680593F);
        escalar(g0, "caldera_43", 0.9800081632313069F, 1.0F, 0.7315012438749458F);
        escalar(g0, "caldera_44", 0.9800081632313069F, 1.0F, 0.7091083486542827F);
        escalar(g0, "caldera_45", 0.9800081632313069F, 1.0F, 0.7165726470611706F);
        escalar(g0, "caldera_46", 0.9800081632313069F, 1.0F, 0.7240369454680575F);
        escalar(g0, "caldera_47", 0.9800081632313069F, 1.0F, 0.731501243874945F);
        escalar(g0, "caldera_48", 0.9800081632313069F, 1.0F, 0.709108348654282F);
        escalar(g0, "caldera_49", 0.9800081632313069F, 1.0F, 0.7165726470611689F);
        escalar(g0, "caldera_50", 0.9800081632313069F, 1.0F, 0.7240369454680559F);
        escalar(g0, "caldera_51", 0.9800081632313069F, 1.0F, 0.7315012438749431F);
        escalar(g0, "caldera_52", 0.9800081632313069F, 1.0F, 0.7091083486542843F);
        escalar(g0, "caldera_53", 0.9800081632313069F, 1.0F, 0.7165726470611719F);
        escalar(g0, "caldera_54", 0.9800081632313069F, 1.0F, 0.724036945468059F);
        escalar(g0, "caldera_55", 0.9800081632313069F, 1.0F, 0.7315012438749462F);
        escalar(g0, "caldera_56", 0.9800081632313069F, 1.0F, 0.7091083486542832F);
        escalar(g0, "caldera_57", 0.9800081632313069F, 1.0F, 0.7165726470611705F);
        escalar(g0, "caldera_58", 0.9800081632313069F, 1.0F, 0.7240369454680576F);
        escalar(g0, "caldera_59", 0.9800081632313069F, 1.0F, 0.7315012438749448F);
        escalar(g0, "caldera_60", 0.9800081632313069F, 1.0F, 0.7091083486542827F);
        escalar(g0, "caldera_61", 0.9800081632313069F, 1.0F, 0.7165726470611703F);
        escalar(g0, "caldera_62", 0.9800081632313069F, 1.0F, 0.7240369454680575F);
        escalar(g0, "caldera_63", 0.9800081632313069F, 1.0F, 0.7315012438749448F);
        escalar(g0, "caldera_64", 0.9800081632313069F, 1.0F, 0.709108348654282F);
        escalar(g0, "caldera_65", 0.9800081632313069F, 1.0F, 0.716572647061169F);
        escalar(g0, "caldera_66", 0.9800081632313069F, 1.0F, 0.7240369454680559F);
        escalar(g0, "caldera_67", 0.9800081632313069F, 1.0F, 0.7315012438749435F);
        escalar(g0, "caldera_68", 0.9800081632313069F, 1.0F, 0.7091083486542841F);
        escalar(g0, "caldera_69", 0.9800081632313069F, 1.0F, 0.7165726470611712F);
        escalar(g0, "caldera_70", 0.9800081632313069F, 1.0F, 0.7240369454680594F);
        escalar(g0, "caldera_71", 0.9800081632313069F, 1.0F, 0.7315012438749461F);
        escalar(g0, "caldera_72", 0.9800081632313069F, 1.0F, 0.7091083486542811F);
        escalar(g0, "caldera_73", 0.9800081632313069F, 1.0F, 0.716572647061168F);
        escalar(g0, "caldera_74", 0.9800081632313069F, 1.0F, 0.7240369454680541F);
        escalar(g0, "caldera_75", 0.9800081632313069F, 1.0F, 0.7315012438749413F);
        escalar(g0, "caldera_76", 0.9800081632313069F, 1.0F, 0.7091083486542821F);
        escalar(g0, "caldera_77", 0.9800081632313069F, 1.0F, 0.7165726470611706F);
        escalar(g0, "caldera_78", 0.9800081632313069F, 1.0F, 0.7240369454680579F);
        escalar(g0, "caldera_79", 0.9800081632313069F, 1.0F, 0.7315012438749449F);
        escalar(g0, "caldera_80", 0.9800081632313069F, 1.0F, 0.7091083486542872F);
        escalar(g0, "caldera_81", 0.9800081632313069F, 1.0F, 0.7165726470611734F);
        escalar(g0, "caldera_82", 0.9800081632313069F, 1.0F, 0.7240369454680599F);
        escalar(g0, "caldera_83", 0.9800081632313069F, 1.0F, 0.7315012438749474F);
        escalar(g0, "caldera_84", 0.9800081632313069F, 1.0F, 0.7091083486542823F);
        escalar(g0, "caldera_85", 0.9800081632313069F, 1.0F, 0.7165726470611711F);
        escalar(g0, "caldera_86", 0.9800081632313069F, 1.0F, 0.7240369454680585F);
        escalar(g0, "caldera_87", 0.9800081632313069F, 1.0F, 0.731501243874945F);
        escalar(g0, "caldera_88", 0.9800081632313069F, 1.0F, 0.7091083486542828F);
        escalar(g0, "caldera_89", 0.9800081632313069F, 1.0F, 0.7165726470611703F);
        escalar(g0, "caldera_90", 0.9800081632313069F, 1.0F, 0.7240369454680574F);
        escalar(g0, "caldera_91", 0.9800081632313069F, 1.0F, 0.7315012438749445F);
        escalar(g0, "caldera_92", 0.9800081632313069F, 1.0F, 0.7091083486542837F);
        escalar(g0, "caldera_93", 0.9800081632313069F, 1.0F, 0.7165726470611696F);
        escalar(g0, "caldera_94", 0.9800081632313069F, 1.0F, 0.7240369454680576F);
        escalar(g0, "caldera_95", 0.9800081632313069F, 1.0F, 0.7315012438749458F);
        escalar(g0, "caldera_96", 0.9800081632313069F, 1.0F, 0.7091083486542827F);
        escalar(g0, "caldera_97", 0.9800081632313069F, 1.0F, 0.7165726470611694F);
        escalar(g0, "caldera_98", 0.9800081632313069F, 1.0F, 0.7240369454680576F);
        escalar(g0, "caldera_99", 0.9800081632313069F, 1.0F, 0.7315012438749443F);
        escalar(g0, "caldera_100", 0.9800081632313069F, 1.0F, 0.7091083486542803F);
        escalar(g0, "caldera_101", 0.9800081632313069F, 1.0F, 0.7165726470611679F);
        escalar(g0, "caldera_102", 0.9800081632313069F, 1.0F, 0.724036945468054F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "caldera_103", 0.9800081632313069F, 1.0F, 0.7315012438749416F);
        escalar(g0, "caldera_104", 0.9800081632313069F, 1.0F, 0.7091083486542828F);
        escalar(g0, "caldera_105", 0.9800081632313069F, 1.0F, 0.7165726470611706F);
        escalar(g0, "caldera_106", 0.9800081632313069F, 1.0F, 0.7240369454680576F);
        escalar(g0, "caldera_107", 0.9800081632313069F, 1.0F, 0.7315012438749452F);
        escalar(g0, "caldera_108", 0.9800081632313069F, 1.0F, 0.709108348654286F);
        escalar(g0, "caldera_109", 0.9800081632313069F, 1.0F, 0.7165726470611733F);
        escalar(g0, "caldera_110", 0.9800081632313069F, 1.0F, 0.7240369454680605F);
        escalar(g0, "caldera_111", 0.9800081632313069F, 1.0F, 0.7315012438749474F);
        escalar(g0, "carcasa_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "carcasa_cantoi_1", 1.0F, 1.0F, 0.9386067902413818F);
        escalar(g0, "carcasa_cantoi_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "carcasa_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "carcasa_cantoi_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "carcasa_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "carcasa_cantod_1", 1.0F, 1.0F, 0.9386067902413818F);
        escalar(g0, "carcasa_cantod_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "carcasa_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "carcasa_cantod_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "carcasa_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "carcasa_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "chimenea_0", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "chimenea_1", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "chimenea_2", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "chimenea_3", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "faro_0", 0.4315455233774214F, 0.7333333333333334F, 0.4315455233774214F);
        escalar(g0, "faro_1", 0.4315455233774214F, 0.7333333333333334F, 0.4315455233774214F);
        escalar(g0, "faro_2", 0.4315455233774214F, 0.7333333333333334F, 0.4315455233774214F);
        escalar(g0, "faro_3", 0.4315455233774214F, 0.7333333333333334F, 0.4315455233774214F);
        escalar(g0, "faro_vidrio", 0.24444444444444446F, 0.15F, 0.24444444444444446F);
        escalar(g0, "deflectori", 0.5F, 0.5F, 1.0F);
        escalar(g0, "deflectord", 0.5F, 0.5F, 1.0F);
        escalar(g0, "cabina_techo_0", 1.0007407407407407F, 1.0F, 0.7575297517670156F);
        escalar(g0, "cabina_techo_1", 1.0007407407407407F, 1.0F, 0.7575297517670149F);
        escalar(g0, "cabina_techo_2", 1.0007407407407407F, 1.0F, 0.757529751767016F);
        escalar(g0, "cabina_techo_3", 1.0007407407407407F, 1.0F, 0.7575297517670149F);
        escalar(g0, "cabina_techo_4", 1.0007407407407407F, 1.0F, 0.7575297517670148F);
        escalar(g0, "cabina_techo_5", 1.0007407407407407F, 1.0F, 0.7575297517670156F);
        escalar(g0, "cabina_techo_6", 1.0007407407407407F, 1.0F, 0.7575297517670146F);
        escalar(g0, "cabina_techo_7", 1.0007407407407407F, 1.0F, 0.7575297517670152F);
        escalar(g0, "cabina_techo_8", 1.0007407407407407F, 1.0F, 0.7575297517670155F);
        escalar(g0, "cabina_techo_9", 1.0007407407407407F, 1.0F, 0.7575297517670149F);
        escalar(g0, "cabina_techo_10", 1.0007407407407407F, 1.0F, 0.7575297517670161F);
        escalar(g0, "cabina_techo_11", 1.0007407407407407F, 1.0F, 0.7575297517670156F);
        escalar(g0, "numeroi", 0.5F, 0.5F, 1.0F);
        escalar(g0, "numerod", 0.5F, 0.5F, 1.0F);
        escalar(g0, "cab_velocimetro", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.656F, 0.6F);
        escalar(g0, "cab_presion", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "cab_presion_aguja", 0.3F, 0.656F, 0.6F);
        escalar(g0, "cab_regulador", 0.8F, 0.9013878188659974F, 0.8F);
        escalar(g0, "cab_tubo", 0.6F, 0.9375F, 0.6F);
        escalar(g0, "cab_freno_manija", 0.6F, 1.0F, 0.6F);
        escalar(g1, "tender_caja_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g1, "tender_caja_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g1, "tender_caja_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g1, "tender_caja_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g1, "tender_caja_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g1, "tender_caja_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g1, "tender_caja_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g1, "tender_caja_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g1, "tender_caja_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g1, "tender_caja_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g1, "tender_caja_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tender_caja_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tope_ti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_td_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
    }
}
