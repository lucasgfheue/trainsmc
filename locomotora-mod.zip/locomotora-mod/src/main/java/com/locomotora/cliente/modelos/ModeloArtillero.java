package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Tren artillero" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloArtillero {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("artillero"), "main"),
            LocomotoraMod.id("textures/entity/artillero.png"),
            List.of(
                new DatosModelo.Animada("bogiefi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("torreta", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, -8.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon", DatosModelo.CANON, 1.0F, 0.0F, 0.0F, 0.0F, -8.0F, -35.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 1.5707963267948966F)),
            ModeloArtillero::crearCapa,
            16.0F,
            ModeloArtillero::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -30.0F, 30.0F)));

    private ModeloArtillero() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogiefi0_0", CubeListBuilder.create().texOffs(0, 119).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(586, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(426, 119).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-38.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi0_1", CubeListBuilder.create().texOffs(608, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(46, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi0_2", CubeListBuilder.create().texOffs(630, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(54, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefi1_0", CubeListBuilder.create().texOffs(0, 119).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(586, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(436, 119).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-22.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi1_1", CubeListBuilder.create().texOffs(608, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(46, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi1_2", CubeListBuilder.create().texOffs(630, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(54, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd0_0", CubeListBuilder.create().texOffs(0, 119).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(586, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(446, 119).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-38.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd0_1", CubeListBuilder.create().texOffs(608, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(46, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd0_2", CubeListBuilder.create().texOffs(630, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(54, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd1_0", CubeListBuilder.create().texOffs(0, 119).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(586, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(456, 119).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-22.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd1_1", CubeListBuilder.create().texOffs(608, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(46, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd1_2", CubeListBuilder.create().texOffs(630, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(54, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogief", CubeListBuilder.create().texOffs(118, 119).addBox(-44.0F, -9.0F, 7.0F, 28.0F, 6.0F, 1.0F).texOffs(176, 119).addBox(-44.0F, -9.0F, -8.0F, 28.0F, 6.0F, 1.0F).texOffs(466, 119).addBox(-40.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(476, 119).addBox(-40.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(486, 119).addBox(-24.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(496, 119).addBox(-24.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogieti0_0", CubeListBuilder.create().texOffs(0, 119).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(586, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 119).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(22.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti0_1", CubeListBuilder.create().texOffs(608, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(46, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti0_2", CubeListBuilder.create().texOffs(630, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(54, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogieti1_0", CubeListBuilder.create().texOffs(0, 119).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(586, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(516, 119).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(38.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti1_1", CubeListBuilder.create().texOffs(608, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(46, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti1_2", CubeListBuilder.create().texOffs(630, 119).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(54, 119).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd0_0", CubeListBuilder.create().texOffs(0, 119).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(586, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(526, 119).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(22.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd0_1", CubeListBuilder.create().texOffs(608, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(46, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd0_2", CubeListBuilder.create().texOffs(630, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(54, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd1_0", CubeListBuilder.create().texOffs(0, 119).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(586, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(38, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(536, 119).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(38.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd1_1", CubeListBuilder.create().texOffs(608, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(46, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd1_2", CubeListBuilder.create().texOffs(630, 119).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(54, 119).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiet", CubeListBuilder.create().texOffs(234, 119).addBox(16.0F, -9.0F, 7.0F, 28.0F, 6.0F, 1.0F).texOffs(292, 119).addBox(16.0F, -9.0F, -8.0F, 28.0F, 6.0F, 1.0F).texOffs(546, 119).addBox(20.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(556, 119).addBox(20.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(566, 119).addBox(36.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(576, 119).addBox(36.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(634, 42).addBox(-48.0F, -14.0F, -11.0F, 96.0F, 5.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("faldones", CubeListBuilder.create().texOffs(656, 102).addBox(-44.0F, -14.0F, 12.0F, 88.0F, 10.0F, 1.0F).texOffs(834, 102).addBox(-44.0F, -14.0F, -13.0F, 88.0F, 10.0F, 1.0F).texOffs(676, 119).addBox(-42.0F, -4.0F, 11.0F, 84.0F, 1.0F, 1.0F).texOffs(846, 119).addBox(-42.0F, -4.0F, -12.0F, 84.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("casco", CubeListBuilder.create().texOffs(0, 0).addBox(-38.0F, -30.0F, -13.0F, 78.0F, 16.0F, 26.0F).texOffs(0, 75).addBox(-38.0F, -31.0F, -13.0F, 78.0F, 1.0F, 26.0F), PartPose.ZERO);
        g.addOrReplaceChild("frente_0", CubeListBuilder.create().texOffs(208, 75).addBox(-12.0F, -1.0F, -13.0F, 24.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(-43.0F, -20.5F, 0.0F, 3.141592653589793F, 0.0F, -1.1263771168937977F));
        g.addOrReplaceChild("frente_mejillai", CubeListBuilder.create().texOffs(406, 75).addBox(0.0F, -21.0F, -0.5F, 10.0F, 21.0F, 1.0F), PartPose.offset(-48.0F, -10.0F, -12.4F));
        g.addOrReplaceChild("frente_mejillad", CubeListBuilder.create().texOffs(428, 75).addBox(0.0F, -21.0F, -0.5F, 10.0F, 21.0F, 1.0F), PartPose.offset(-48.0F, -10.0F, 12.4F));
        g.addOrReplaceChild("cola_0", CubeListBuilder.create().texOffs(308, 75).addBox(-11.5F, -1.0F, -13.0F, 23.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(44.0F, -20.5F, 0.0F, 0.0F, 0.0F, -1.9347752833045406F));
        g.addOrReplaceChild("cola_mejillai", CubeListBuilder.create().texOffs(450, 75).addBox(0.0F, -21.0F, -0.5F, 8.0F, 21.0F, 1.0F), PartPose.offset(40.0F, -10.0F, -12.4F));
        g.addOrReplaceChild("cola_mejillad", CubeListBuilder.create().texOffs(468, 75).addBox(0.0F, -21.0F, -0.5F, 8.0F, 21.0F, 1.0F), PartPose.offset(40.0F, -10.0F, 12.4F));
        g.addOrReplaceChild("puertas", CubeListBuilder.create().texOffs(496, 102).addBox(-30.0F, -28.0F, -14.0F, 7.0F, 11.0F, 1.0F).texOffs(1016, 119).addBox(-25.0F, -23.0F, -14.5F, 1.0F, 1.0F, 1.0F).texOffs(512, 102).addBox(-30.0F, -28.0F, 13.0F, 7.0F, 11.0F, 1.0F).texOffs(1020, 119).addBox(-25.0F, -23.0F, 13.5F, 1.0F, 1.0F, 1.0F).texOffs(528, 102).addBox(26.0F, -28.0F, -14.0F, 7.0F, 11.0F, 1.0F).texOffs(0, 130).addBox(31.0F, -23.0F, -14.5F, 1.0F, 1.0F, 1.0F).texOffs(544, 102).addBox(26.0F, -28.0F, 13.0F, 7.0F, 11.0F, 1.0F).texOffs(4, 130).addBox(31.0F, -23.0F, 13.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motor", CubeListBuilder.create().texOffs(914, 75).addBox(14.0F, -32.0F, -8.0F, 22.0F, 1.0F, 16.0F), PartPose.ZERO);
        g.addOrReplaceChild("escapei_0", CubeListBuilder.create().texOffs(554, 75).addBox(-17.0F, -34.0F, -5.5F, 34.0F, 8.0F, 11.0F).texOffs(208, 0).addBox(-5.5F, -34.0F, -17.0F, 11.0F, 8.0F, 34.0F), PartPose.offset(37.0F, 0.0F, -10.0F));
        g.addOrReplaceChild("escapei_1", CubeListBuilder.create().texOffs(644, 75).addBox(-17.0F, -34.0F, -5.5F, 34.0F, 8.0F, 11.0F).texOffs(298, 0).addBox(-5.5F, -34.0F, -17.0F, 11.0F, 8.0F, 34.0F), PartPose.offsetAndRotation(37.0F, 0.0F, -10.0F, 0.0F, 0.6283185307179586F, 0.0F));
        g.addOrReplaceChild("escaped_0", CubeListBuilder.create().texOffs(734, 75).addBox(-17.0F, -34.0F, -5.5F, 34.0F, 8.0F, 11.0F).texOffs(388, 0).addBox(-5.5F, -34.0F, -17.0F, 11.0F, 8.0F, 34.0F), PartPose.offset(37.0F, 0.0F, 10.0F));
        g.addOrReplaceChild("escaped_1", CubeListBuilder.create().texOffs(824, 75).addBox(-17.0F, -34.0F, -5.5F, 34.0F, 8.0F, 11.0F).texOffs(478, 0).addBox(-5.5F, -34.0F, -17.0F, 11.0F, 8.0F, 34.0F), PartPose.offsetAndRotation(37.0F, 0.0F, 10.0F, 0.0F, 0.6283185307179586F, 0.0F));
        g.addOrReplaceChild("antena", CubeListBuilder.create().texOffs(0, 102).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 16.0F, 1.0F), PartPose.offsetAndRotation(34.0F, -31.0F, -10.0F, 0.0F, 0.0F, -3.0750244898139694F));
        g.addOrReplaceChild("ametralladora", CubeListBuilder.create().texOffs(350, 119).addBox(-46.0F, -20.0F, 4.0F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("ametralladora_cano", CubeListBuilder.create().texOffs(394, 119).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F), PartPose.offsetAndRotation(-46.0F, -18.5F, 5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faros", CubeListBuilder.create().texOffs(374, 119).addBox(-51.0F, -17.0F, -10.5F, 2.0F, 3.0F, 3.0F).texOffs(652, 119).addBox(-52.0F, -16.5F, -10.0F, 1.0F, 2.0F, 2.0F).texOffs(398, 119).addBox(-52.0F, -18.0F, -11.0F, 3.0F, 1.0F, 4.0F).texOffs(384, 119).addBox(-51.0F, -17.0F, 7.5F, 2.0F, 3.0F, 3.0F).texOffs(658, 119).addBox(-52.0F, -16.5F, 8.0F, 1.0F, 2.0F, 2.0F).texOffs(412, 119).addBox(-52.0F, -18.0F, 7.0F, 3.0F, 1.0F, 4.0F).texOffs(530, 42).addBox(-51.0F, -14.0F, -12.0F, 2.0F, 7.0F, 24.0F).texOffs(664, 119).addBox(-53.0F, -12.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(582, 42).addBox(49.0F, -14.0F, -12.0F, 2.0F, 7.0F, 24.0F).texOffs(670, 119).addBox(51.0F, -12.0F, -0.5F, 2.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topefi_0", CubeListBuilder.create().texOffs(290, 42).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(568, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefi_1", CubeListBuilder.create().texOffs(310, 42).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(626, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefi_2", CubeListBuilder.create().texOffs(330, 42).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(684, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_0", CubeListBuilder.create().texOffs(560, 102).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(144, 102).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefic_1", CubeListBuilder.create().texOffs(566, 102).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(166, 102).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_2", CubeListBuilder.create().texOffs(572, 102).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(188, 102).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_3", CubeListBuilder.create().texOffs(578, 102).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(210, 102).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_0", CubeListBuilder.create().texOffs(350, 42).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(742, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefd_1", CubeListBuilder.create().texOffs(370, 42).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(800, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_2", CubeListBuilder.create().texOffs(390, 42).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(858, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_0", CubeListBuilder.create().texOffs(584, 102).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(232, 102).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefdc_1", CubeListBuilder.create().texOffs(590, 102).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(254, 102).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_2", CubeListBuilder.create().texOffs(596, 102).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(276, 102).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_3", CubeListBuilder.create().texOffs(602, 102).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(298, 102).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_0", CubeListBuilder.create().texOffs(410, 42).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(916, 0).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topeti_1", CubeListBuilder.create().texOffs(430, 42).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(0, 42).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_2", CubeListBuilder.create().texOffs(450, 42).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(58, 42).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_0", CubeListBuilder.create().texOffs(608, 102).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(320, 102).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topetic_1", CubeListBuilder.create().texOffs(614, 102).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(342, 102).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_2", CubeListBuilder.create().texOffs(620, 102).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(364, 102).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_3", CubeListBuilder.create().texOffs(626, 102).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(386, 102).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_0", CubeListBuilder.create().texOffs(470, 42).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(116, 42).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetd_1", CubeListBuilder.create().texOffs(490, 42).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(174, 42).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_2", CubeListBuilder.create().texOffs(510, 42).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(232, 42).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_0", CubeListBuilder.create().texOffs(632, 102).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(408, 102).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetdc_1", CubeListBuilder.create().texOffs(638, 102).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(430, 102).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_2", CubeListBuilder.create().texOffs(644, 102).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(452, 102).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_3", CubeListBuilder.create().texOffs(650, 102).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(474, 102).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("torreta", CubeListBuilder.create().texOffs(92, 102).addBox(-7.0F, -1.0F, -6.0F, 14.0F, 1.0F, 12.0F).texOffs(486, 75).addBox(-9.0F, -6.0F, -8.0F, 18.0F, 5.0F, 16.0F).texOffs(4, 102).addBox(-7.0F, -8.0F, -7.0F, 15.0F, 2.0F, 14.0F).texOffs(22, 119).addBox(-11.0F, -7.0F, -3.0F, 2.0F, 5.0F, 6.0F).texOffs(62, 102).addBox(9.0F, -6.0F, -6.0F, 3.0F, 4.0F, 12.0F).texOffs(94, 119).addBox(-3.0F, -10.0F, -3.0F, 6.0F, 2.0F, 6.0F).texOffs(62, 119).addBox(3.0F, -14.0F, -3.0F, 1.0F, 4.0F, 6.0F).texOffs(8, 130).addBox(-6.0F, -9.0F, -5.5F, 1.0F, 1.0F, 1.0F).texOffs(12, 130).addBox(-6.0F, -9.0F, 4.5F, 1.0F, 1.0F, 1.0F), PartPose.offset(-8.0F, -31.0F, 0.0F));
        g.addOrReplaceChild("torreta_canon", CubeListBuilder.create().texOffs(76, 119).addBox(-2.0F, -2.0F, -13.0F, 4.0F, 4.0F, 5.0F).texOffs(990, 75).addBox(-1.0F, -1.0F, -28.0F, 2.0F, 2.0F, 15.0F).texOffs(362, 119).addBox(-2.0F, -2.0F, -30.0F, 4.0F, 4.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -35.0F, 0.0F, 0.0F, 1.5707963267948966F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "frente_0", 0.969141945801084F, 1.0F, 1.0F);
        escalar(g0, "cola_0", 0.9770523936627926F, 1.0F, 1.0F);
        escalar(g0, "escapei_0", 0.055944500958538444F, 1.0F, 0.055944500958538444F);
        escalar(g0, "escapei_1", 0.055944500958538444F, 1.0F, 0.055944500958538444F);
        escalar(g0, "escaped_0", 0.055944500958538444F, 1.0F, 0.055944500958538444F);
        escalar(g0, "escaped_1", 0.055944500958538444F, 1.0F, 0.055944500958538444F);
        escalar(g0, "antena", 0.5F, 0.9395810236483068F, 0.5F);
        escalar(g0, "ametralladora_cano", 0.8F, 1.0F, 0.8F);
        escalar(g0, "topefi_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topeti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
    }
}
