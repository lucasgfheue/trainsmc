package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Tren artillero" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloArtillero {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("artillero"), "main"),
            LocomotoraMod.id("textures/entity/artillero.png"),
            List.of(
                new DatosModelo.Animada("bogiefi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -38.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -22.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 22.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 38.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("torreta", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, -8.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon", DatosModelo.CANON, 1.0F, 0.0F, 0.0F, 0.0F, -8.0F, -35.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 1.5707963267948966F)),
            ModeloArtillero::crearCapa,
            16.0F,
            ModeloArtillero::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -30.0F, 30.0F)));

    private ModeloArtillero() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogiefi0_0", CubeListBuilder.create().texOffs(178, 125).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(940, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(780, 125).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-38.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi0_1", CubeListBuilder.create().texOffs(962, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(224, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi0_2", CubeListBuilder.create().texOffs(984, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefi1_0", CubeListBuilder.create().texOffs(178, 125).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(940, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(790, 125).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-22.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefi1_1", CubeListBuilder.create().texOffs(962, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(224, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi1_2", CubeListBuilder.create().texOffs(984, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd0_0", CubeListBuilder.create().texOffs(178, 125).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(940, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(800, 125).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-38.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd0_1", CubeListBuilder.create().texOffs(962, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(224, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd0_2", CubeListBuilder.create().texOffs(984, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd1_0", CubeListBuilder.create().texOffs(178, 125).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(940, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 125).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-22.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogiefd1_1", CubeListBuilder.create().texOffs(962, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(224, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd1_2", CubeListBuilder.create().texOffs(984, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogief", CubeListBuilder.create().texOffs(296, 125).addBox(-44.0F, -9.0F, 7.0F, 28.0F, 6.0F, 1.0F).texOffs(354, 125).addBox(-44.0F, -9.0F, -8.0F, 28.0F, 6.0F, 1.0F).texOffs(820, 125).addBox(-40.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(830, 125).addBox(-40.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(840, 125).addBox(-24.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(850, 125).addBox(-24.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogieti0_0", CubeListBuilder.create().texOffs(178, 125).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(940, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(860, 125).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(22.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti0_1", CubeListBuilder.create().texOffs(962, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(224, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti0_2", CubeListBuilder.create().texOffs(984, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogieti1_0", CubeListBuilder.create().texOffs(178, 125).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(940, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(870, 125).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(38.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogieti1_1", CubeListBuilder.create().texOffs(962, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(224, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti1_2", CubeListBuilder.create().texOffs(984, 125).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 125).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd0_0", CubeListBuilder.create().texOffs(178, 125).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(940, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(880, 125).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(22.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd0_1", CubeListBuilder.create().texOffs(962, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(224, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd0_2", CubeListBuilder.create().texOffs(984, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd1_0", CubeListBuilder.create().texOffs(178, 125).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(940, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(890, 125).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(38.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogietd1_1", CubeListBuilder.create().texOffs(962, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(224, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd1_2", CubeListBuilder.create().texOffs(984, 125).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 125).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(38.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiet", CubeListBuilder.create().texOffs(412, 125).addBox(16.0F, -9.0F, 7.0F, 28.0F, 6.0F, 1.0F).texOffs(470, 125).addBox(16.0F, -9.0F, -8.0F, 28.0F, 6.0F, 1.0F).texOffs(900, 125).addBox(20.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(910, 125).addBox(20.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(920, 125).addBox(36.0F, -6.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(930, 125).addBox(36.0F, -6.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(730, 48).addBox(-48.0F, -14.0F, -11.0F, 96.0F, 5.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("faldones", CubeListBuilder.create().texOffs(750, 108).addBox(-44.0F, -14.0F, 12.0F, 88.0F, 10.0F, 1.0F).texOffs(0, 125).addBox(-44.0F, -14.0F, -13.0F, 88.0F, 10.0F, 1.0F).texOffs(106, 136).addBox(-42.0F, -4.0F, 11.0F, 84.0F, 1.0F, 1.0F).texOffs(276, 136).addBox(-42.0F, -4.0F, -12.0F, 84.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("casco", CubeListBuilder.create().texOffs(360, 0).addBox(-38.0F, -30.0F, -13.0F, 78.0F, 16.0F, 26.0F).texOffs(0, 81).addBox(-38.0F, -31.0F, -13.0F, 78.0F, 1.0F, 26.0F), PartPose.ZERO);
        g.addOrReplaceChild("frente_0", CubeListBuilder.create().texOffs(208, 81).addBox(-12.0F, -1.0F, -13.0F, 24.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(-43.0F, -20.5F, 0.0F, 3.141592653589793F, 0.0F, -1.1263771168937977F));
        g.addOrReplaceChild("frente_mejillai", CubeListBuilder.create().texOffs(846, 81).addBox(0.0F, -21.0F, -0.5F, 10.0F, 21.0F, 1.0F), PartPose.offset(-48.0F, -10.0F, -12.4F));
        g.addOrReplaceChild("frente_mejillad", CubeListBuilder.create().texOffs(868, 81).addBox(0.0F, -21.0F, -0.5F, 10.0F, 21.0F, 1.0F), PartPose.offset(-48.0F, -10.0F, 12.4F));
        g.addOrReplaceChild("cola_0", CubeListBuilder.create().texOffs(308, 81).addBox(-11.5F, -1.0F, -13.0F, 23.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(44.0F, -20.5F, 0.0F, 0.0F, 0.0F, -1.9347752833045406F));
        g.addOrReplaceChild("cola_mejillai", CubeListBuilder.create().texOffs(890, 81).addBox(0.0F, -21.0F, -0.5F, 8.0F, 21.0F, 1.0F), PartPose.offset(40.0F, -10.0F, -12.4F));
        g.addOrReplaceChild("cola_mejillad", CubeListBuilder.create().texOffs(908, 81).addBox(0.0F, -21.0F, -0.5F, 8.0F, 21.0F, 1.0F), PartPose.offset(40.0F, -10.0F, 12.4F));
        g.addOrReplaceChild("puertas", CubeListBuilder.create().texOffs(590, 108).addBox(-30.0F, -28.0F, -14.0F, 7.0F, 11.0F, 1.0F).texOffs(446, 136).addBox(-25.0F, -23.0F, -14.5F, 1.0F, 1.0F, 1.0F).texOffs(606, 108).addBox(-30.0F, -28.0F, 13.0F, 7.0F, 11.0F, 1.0F).texOffs(450, 136).addBox(-25.0F, -23.0F, 13.5F, 1.0F, 1.0F, 1.0F).texOffs(622, 108).addBox(26.0F, -28.0F, -14.0F, 7.0F, 11.0F, 1.0F).texOffs(454, 136).addBox(31.0F, -23.0F, -14.5F, 1.0F, 1.0F, 1.0F).texOffs(638, 108).addBox(26.0F, -28.0F, 13.0F, 7.0F, 11.0F, 1.0F).texOffs(458, 136).addBox(31.0F, -23.0F, 13.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motor", CubeListBuilder.create().texOffs(0, 108).addBox(6.0F, -32.0F, -8.0F, 14.0F, 1.0F, 16.0F).texOffs(94, 136).addBox(15.0F, -22.0F, -13.5F, 2.0F, 2.0F, 1.0F).texOffs(100, 136).addBox(15.0F, -22.0F, 12.5F, 2.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("escapei_0", CubeListBuilder.create().texOffs(406, 81).addBox(-17.0F, -34.0F, -5.5F, 34.0F, 14.0F, 11.0F).texOffs(0, 0).addBox(-5.5F, -34.0F, -17.0F, 11.0F, 14.0F, 34.0F), PartPose.offset(16.0F, 0.0F, -14.0F));
        g.addOrReplaceChild("escapei_1", CubeListBuilder.create().texOffs(496, 81).addBox(-17.0F, -34.0F, -5.5F, 34.0F, 14.0F, 11.0F).texOffs(90, 0).addBox(-5.5F, -34.0F, -17.0F, 11.0F, 14.0F, 34.0F), PartPose.offsetAndRotation(16.0F, 0.0F, -14.0F, 0.0F, 0.6283185307179586F, 0.0F));
        g.addOrReplaceChild("escaped_0", CubeListBuilder.create().texOffs(586, 81).addBox(-17.0F, -34.0F, -5.5F, 34.0F, 14.0F, 11.0F).texOffs(180, 0).addBox(-5.5F, -34.0F, -17.0F, 11.0F, 14.0F, 34.0F), PartPose.offset(16.0F, 0.0F, 14.0F));
        g.addOrReplaceChild("escaped_1", CubeListBuilder.create().texOffs(676, 81).addBox(-17.0F, -34.0F, -5.5F, 34.0F, 14.0F, 11.0F).texOffs(270, 0).addBox(-5.5F, -34.0F, -17.0F, 11.0F, 14.0F, 34.0F), PartPose.offsetAndRotation(16.0F, 0.0F, 14.0F, 0.0F, 0.6283185307179586F, 0.0F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(766, 81).addBox(23.0F, -32.0F, -11.5F, 17.0F, 1.0F, 23.0F).texOffs(624, 125).addBox(22.0F, -36.0F, 11.5F, 19.0F, 5.0F, 1.0F).texOffs(664, 125).addBox(22.0F, -36.0F, -12.5F, 19.0F, 5.0F, 1.0F).texOffs(634, 48).addBox(22.0F, -36.0F, -11.5F, 1.0F, 5.0F, 23.0F).texOffs(682, 48).addBox(40.0F, -36.0F, -11.5F, 1.0F, 5.0F, 23.0F).texOffs(6, 136).addBox(21.5F, -37.0F, 11.0F, 20.0F, 1.0F, 2.0F).texOffs(50, 136).addBox(21.5F, -37.0F, -13.0F, 20.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_bancos", CubeListBuilder.create().texOffs(528, 125).addBox(23.5F, -33.0F, -8.5F, 6.0F, 1.0F, 6.0F).texOffs(552, 125).addBox(23.5F, -33.0F, 2.5F, 6.0F, 1.0F, 6.0F).texOffs(576, 125).addBox(32.5F, -33.0F, -8.5F, 6.0F, 1.0F, 6.0F).texOffs(600, 125).addBox(32.5F, -33.0F, 2.5F, 6.0F, 1.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("antena", CubeListBuilder.create().texOffs(94, 108).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 16.0F, 1.0F), PartPose.offsetAndRotation(39.0F, -37.0F, -11.0F, 0.0F, 0.0F, -3.0750244898139694F));
        g.addOrReplaceChild("ametralladora", CubeListBuilder.create().texOffs(704, 125).addBox(-46.0F, -20.0F, 4.0F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("ametralladora_cano", CubeListBuilder.create().texOffs(748, 125).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F), PartPose.offsetAndRotation(-46.0F, -18.5F, 5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faros", CubeListBuilder.create().texOffs(728, 125).addBox(-51.0F, -17.0F, -10.5F, 2.0F, 3.0F, 3.0F).texOffs(1006, 125).addBox(-52.0F, -16.5F, -10.0F, 1.0F, 2.0F, 2.0F).texOffs(752, 125).addBox(-52.0F, -18.0F, -11.0F, 3.0F, 1.0F, 4.0F).texOffs(738, 125).addBox(-51.0F, -17.0F, 7.5F, 2.0F, 3.0F, 3.0F).texOffs(1012, 125).addBox(-52.0F, -16.5F, 8.0F, 1.0F, 2.0F, 2.0F).texOffs(766, 125).addBox(-52.0F, -18.0F, 7.0F, 3.0F, 1.0F, 4.0F).texOffs(530, 48).addBox(-51.0F, -14.0F, -12.0F, 2.0F, 7.0F, 24.0F).texOffs(1018, 125).addBox(-53.0F, -12.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(582, 48).addBox(49.0F, -14.0F, -12.0F, 2.0F, 7.0F, 24.0F).texOffs(0, 136).addBox(51.0F, -12.0F, -0.5F, 2.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topefi_0", CubeListBuilder.create().texOffs(290, 48).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(568, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefi_1", CubeListBuilder.create().texOffs(310, 48).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(626, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefi_2", CubeListBuilder.create().texOffs(330, 48).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(684, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_0", CubeListBuilder.create().texOffs(654, 108).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(238, 108).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefic_1", CubeListBuilder.create().texOffs(660, 108).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(260, 108).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_2", CubeListBuilder.create().texOffs(666, 108).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(282, 108).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_3", CubeListBuilder.create().texOffs(672, 108).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(304, 108).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_0", CubeListBuilder.create().texOffs(350, 48).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(742, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefd_1", CubeListBuilder.create().texOffs(370, 48).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(800, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_2", CubeListBuilder.create().texOffs(390, 48).addBox(-54.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(858, 0).addBox(-54.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_0", CubeListBuilder.create().texOffs(678, 108).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(326, 108).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefdc_1", CubeListBuilder.create().texOffs(684, 108).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(348, 108).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_2", CubeListBuilder.create().texOffs(690, 108).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(370, 108).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_3", CubeListBuilder.create().texOffs(696, 108).addBox(-55.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(392, 108).addBox(-55.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_0", CubeListBuilder.create().texOffs(410, 48).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(916, 0).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topeti_1", CubeListBuilder.create().texOffs(430, 48).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(0, 48).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_2", CubeListBuilder.create().texOffs(450, 48).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(58, 48).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_0", CubeListBuilder.create().texOffs(702, 108).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(414, 108).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topetic_1", CubeListBuilder.create().texOffs(708, 108).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(436, 108).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_2", CubeListBuilder.create().texOffs(714, 108).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(458, 108).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_3", CubeListBuilder.create().texOffs(720, 108).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(480, 108).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_0", CubeListBuilder.create().texOffs(470, 48).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(116, 48).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetd_1", CubeListBuilder.create().texOffs(490, 48).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(174, 48).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_2", CubeListBuilder.create().texOffs(510, 48).addBox(51.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(232, 48).addBox(51.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_0", CubeListBuilder.create().texOffs(726, 108).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(502, 108).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetdc_1", CubeListBuilder.create().texOffs(732, 108).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(524, 108).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_2", CubeListBuilder.create().texOffs(738, 108).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(546, 108).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_3", CubeListBuilder.create().texOffs(744, 108).addBox(54.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(568, 108).addBox(54.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("torreta", CubeListBuilder.create().texOffs(186, 108).addBox(-7.0F, -1.0F, -6.0F, 14.0F, 1.0F, 12.0F).texOffs(926, 81).addBox(-9.0F, -6.0F, -8.0F, 18.0F, 5.0F, 16.0F).texOffs(98, 108).addBox(-7.0F, -8.0F, -7.0F, 15.0F, 2.0F, 14.0F).texOffs(200, 125).addBox(-11.0F, -7.0F, -3.0F, 2.0F, 5.0F, 6.0F).texOffs(156, 108).addBox(9.0F, -6.0F, -6.0F, 3.0F, 4.0F, 12.0F).texOffs(272, 125).addBox(-3.0F, -10.0F, -3.0F, 6.0F, 2.0F, 6.0F).texOffs(240, 125).addBox(3.0F, -14.0F, -3.0F, 1.0F, 4.0F, 6.0F).texOffs(462, 136).addBox(-6.0F, -9.0F, -5.5F, 1.0F, 1.0F, 1.0F).texOffs(466, 136).addBox(-6.0F, -9.0F, 4.5F, 1.0F, 1.0F, 1.0F), PartPose.offset(-8.0F, -31.0F, 0.0F));
        g.addOrReplaceChild("torreta_canon", CubeListBuilder.create().texOffs(254, 125).addBox(-2.0F, -2.0F, -13.0F, 4.0F, 4.0F, 5.0F).texOffs(60, 108).addBox(-1.0F, -1.0F, -28.0F, 2.0F, 2.0F, 15.0F).texOffs(716, 125).addBox(-2.0F, -2.0F, -30.0F, 4.0F, 4.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -35.0F, 0.0F, 0.0F, 1.5707963267948966F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "frente_0", 0.969141945801084F, 1.0F, 1.0F);
        escalar(g0, "cola_0", 0.9770523936627926F, 1.0F, 1.0F);
        escalar(g0, "escapei_0", 0.055944500958538444F, 1.0F, 0.055944500958538444F);
        escalar(g0, "escapei_1", 0.055944500958538444F, 1.0F, 0.055944500958538444F);
        escalar(g0, "escaped_0", 0.055944500958538444F, 1.0F, 0.055944500958538444F);
        escalar(g0, "escaped_1", 0.055944500958538444F, 1.0F, 0.055944500958538444F);
        escalar(g0, "antena", 0.5F, 0.9395810236483068F, 0.5F);
        escalar(g0, "ametralladora_cano", 0.8F, 1.0F, 0.8F);
        escalar(g0, "topefi_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topeti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
    }
}
