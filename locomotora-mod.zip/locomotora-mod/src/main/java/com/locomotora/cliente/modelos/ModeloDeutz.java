package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Deutz OMZ 117" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloDeutz {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("deutz"), "main"),
            LocomotoraMod.id("textures/entity/deutz.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, -6.0F, -3.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, -6.0F, -3.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, -6.0F, -3.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, 6.0F, -3.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, 6.0F, -3.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, 6.0F, -3.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 3.0F, 0.0F, 1.5707963267948966F, 0.0F, -6.0F, -3.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 3.0F, 0.0F, 1.5707963267948966F, 0.0F, -6.0F, -3.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 3.0F, 0.0F, 1.5707963267948966F, 0.0F, -6.0F, -3.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 3.0F, 0.0F, 1.5707963267948966F, 0.0F, 6.0F, -3.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 3.0F, 0.0F, 1.5707963267948966F, 0.0F, 6.0F, -3.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 3.0F, 0.0F, 1.5707963267948966F, 0.0F, 6.0F, -3.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 3.0F, 1.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 3.0F, 1.2F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("cab_manometro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 3.72F, -16.6F, 0.0F, "cuerpo", 4.8F, 0.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.0F, 0.0F, 5.5F, -9.0F, 0.0F, "cuerpo", -0.22F, -1.0F, 0.0F)),
            ModeloDeutz::crearCapa,
            16.0F,
            ModeloDeutz::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -6.0F, 6.0F)));

    private ModeloDeutz() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 64);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(272, 35).addBox(-3.0F, -3.0F, -6.0F, 6.0F, 6.0F, 2.0F).texOffs(600, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(560, 35).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(260, 46).addBox(-1.0F, -2.2F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-6.0F, -3.0F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(616, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(320, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.0F, -3.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(632, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(328, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.0F, -3.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(272, 35).addBox(-3.0F, -3.0F, -6.0F, 6.0F, 6.0F, 2.0F).texOffs(600, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(570, 35).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(266, 46).addBox(-1.0F, -2.2F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(6.0F, -3.0F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(616, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(320, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.0F, -3.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(632, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(328, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.0F, -3.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(272, 35).addBox(-3.0F, -3.0F, 4.0F, 6.0F, 6.0F, 2.0F).texOffs(600, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(580, 35).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(272, 46).addBox(-1.0F, -2.2F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-6.0F, -3.0F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(616, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(320, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.0F, -3.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(632, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(328, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.0F, -3.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(272, 35).addBox(-3.0F, -3.0F, 4.0F, 6.0F, 6.0F, 2.0F).texOffs(600, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(590, 35).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(278, 46).addBox(-1.0F, -2.2F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(6.0F, -3.0F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(616, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(320, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.0F, -3.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(632, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(328, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.0F, -3.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(644, 46).addBox(-6.0F, -4.7F, -7.5F, 12.0F, 1.0F, 1.0F).texOffs(648, 35).addBox(-7.5F, -5.7F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(656, 35).addBox(4.5F, -5.7F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(670, 46).addBox(-6.0F, -4.7F, 6.5F, 12.0F, 1.0F, 1.0F).texOffs(664, 35).addBox(-7.5F, -5.7F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(672, 35).addBox(4.5F, -5.7F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(336, 35).addBox(-15.0F, -8.0F, 2.0F, 30.0F, 6.0F, 1.0F).texOffs(398, 35).addBox(-15.0F, -8.0F, -3.0F, 30.0F, 6.0F, 1.0F).texOffs(532, 0).addBox(-15.0F, -9.0F, -6.5F, 31.0F, 1.0F, 13.0F).texOffs(256, 0).addBox(-17.0F, -9.0F, -6.5F, 2.0F, 6.0F, 13.0F).texOffs(288, 35).addBox(-19.0F, -8.0F, -2.0F, 2.0F, 4.0F, 4.0F).texOffs(702, 46).addBox(-20.0F, -6.5F, -0.5F, 1.0F, 1.0F, 1.0F).texOffs(286, 0).addBox(15.0F, -9.0F, -6.5F, 2.0F, 6.0F, 13.0F).texOffs(300, 35).addBox(17.0F, -8.0F, -2.0F, 2.0F, 4.0F, 4.0F).texOffs(706, 46).addBox(19.0F, -6.5F, -0.5F, 1.0F, 1.0F, 1.0F).texOffs(680, 35).addBox(-7.5F, -4.5F, 3.0F, 3.0F, 3.0F, 1.0F).texOffs(688, 35).addBox(-7.5F, -4.5F, -4.0F, 3.0F, 3.0F, 1.0F).texOffs(696, 35).addBox(4.5F, -4.5F, 3.0F, 3.0F, 3.0F, 1.0F).texOffs(704, 35).addBox(4.5F, -4.5F, -4.0F, 3.0F, 3.0F, 1.0F).texOffs(412, 0).addBox(-14.0F, -17.0F, -4.5F, 17.0F, 8.0F, 9.0F).texOffs(460, 35).addBox(-14.0F, -19.0F, -2.5F, 17.0F, 2.0F, 5.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_cantoi_0", CubeListBuilder.create().texOffs(284, 46).addBox(-8.5F, -1.0F, -0.5F, 17.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -17.309016994374947F, -4.451056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_1", CubeListBuilder.create().texOffs(320, 46).addBox(-8.5F, -1.0F, -0.5F, 17.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -17.89680224666742F, -4.260073510670101F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_2", CubeListBuilder.create().texOffs(356, 46).addBox(-8.5F, -1.0F, -0.5F, 17.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -18.39680224666742F, -3.896802246667421F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_3", CubeListBuilder.create().texOffs(392, 46).addBox(-8.5F, -1.0F, -0.5F, 17.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -18.7600735106701F, -3.3968022466674204F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_4", CubeListBuilder.create().texOffs(428, 46).addBox(-8.5F, -1.0F, -0.5F, 17.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -18.951056516295154F, -2.8090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_0", CubeListBuilder.create().texOffs(464, 46).addBox(-8.5F, -1.0F, -0.5F, 17.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -17.309016994374947F, 4.451056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_1", CubeListBuilder.create().texOffs(500, 46).addBox(-8.5F, -1.0F, -0.5F, 17.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -17.89680224666742F, 4.260073510670101F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_2", CubeListBuilder.create().texOffs(536, 46).addBox(-8.5F, -1.0F, -0.5F, 17.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -18.39680224666742F, 3.896802246667421F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_3", CubeListBuilder.create().texOffs(572, 46).addBox(-8.5F, -1.0F, -0.5F, 17.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -18.7600735106701F, 3.3968022466674204F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_4", CubeListBuilder.create().texOffs(608, 46).addBox(-8.5F, -1.0F, -0.5F, 17.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.5F, -18.951056516295154F, 2.8090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_tapaa", CubeListBuilder.create().texOffs(180, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 18.0F), PartPose.offset(-14.0F, -17.0F, -4.5F));
        g.addOrReplaceChild("capo_tapab", CubeListBuilder.create().texOffs(218, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 18.0F), PartPose.offset(2.0F, -17.0F, -4.5F));
        g.addOrReplaceChild("tapa_radiador_0", CubeListBuilder.create().texOffs(668, 0).addBox(-17.0F, -20.0F, -5.5F, 34.0F, 1.0F, 11.0F).texOffs(0, 0).addBox(-5.5F, -20.0F, -17.0F, 11.0F, 1.0F, 34.0F), PartPose.offset(-12.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("tapa_radiador_1", CubeListBuilder.create().texOffs(758, 0).addBox(-17.0F, -20.0F, -5.5F, 34.0F, 1.0F, 11.0F).texOffs(90, 0).addBox(-5.5F, -20.0F, -17.0F, 11.0F, 1.0F, 34.0F), PartPose.offsetAndRotation(-12.5F, 0.0F, 0.0F, 0.0F, 0.6283185307179586F, 0.0F));
        g.addOrReplaceChild("escape_0", CubeListBuilder.create().texOffs(148, 35).addBox(-6.0F, -24.0F, -2.5F, 12.0F, 5.0F, 5.0F).texOffs(464, 0).addBox(-2.5F, -24.0F, -6.0F, 5.0F, 5.0F, 12.0F), PartPose.offset(-4.0F, 0.0F, -2.0F));
        g.addOrReplaceChild("escape_1", CubeListBuilder.create().texOffs(182, 35).addBox(-6.0F, -24.0F, -2.5F, 12.0F, 5.0F, 5.0F).texOffs(498, 0).addBox(-2.5F, -24.0F, -6.0F, 5.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(-4.0F, 0.0F, -2.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("escape_codo", CubeListBuilder.create().texOffs(720, 35).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -23.5F, -2.0F, 0.0F, 0.0F, -2.1112158270654806F));
        g.addOrReplaceChild("manivela", CubeListBuilder.create().texOffs(724, 35).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-14.0F, -11.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("manivela_mango", CubeListBuilder.create().texOffs(728, 35).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(-16.5F, -11.0F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("farol_0", CubeListBuilder.create().texOffs(68, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(916, 0).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-14.05F, -17.5F, 3.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_1", CubeListBuilder.create().texOffs(92, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(940, 0).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-14.05F, -17.5F, 3.5F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_2", CubeListBuilder.create().texOffs(116, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(964, 0).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-14.05F, -17.5F, 3.5F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_3", CubeListBuilder.create().texOffs(140, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(988, 0).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-14.05F, -17.5F, 3.5F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_vidrio", CubeListBuilder.create().texOffs(216, 35).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-14.47F, -17.5F, 3.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("plataforma", CubeListBuilder.create().texOffs(508, 35).addBox(3.0F, -13.0F, 5.5F, 12.0F, 4.0F, 1.0F).texOffs(534, 35).addBox(3.0F, -13.0F, -6.5F, 12.0F, 4.0F, 1.0F).texOffs(384, 0).addBox(15.0F, -14.0F, -6.5F, 1.0F, 5.0F, 13.0F).texOffs(96, 35).addBox(3.0F, -23.0F, 5.5F, 1.0F, 10.0F, 1.0F).texOffs(100, 35).addBox(3.0F, -23.0F, -6.5F, 1.0F, 10.0F, 1.0F).texOffs(104, 35).addBox(14.5F, -23.0F, 5.5F, 1.0F, 10.0F, 1.0F).texOffs(108, 35).addBox(14.5F, -23.0F, -6.5F, 1.0F, 10.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("techo_0", CubeListBuilder.create().texOffs(732, 35).addBox(-7.5F, -1.0F, -1.0F, 15.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.5F, -21.46150634905875F, -6.9104063648006555F, -2.3226367257150553F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_1", CubeListBuilder.create().texOffs(766, 35).addBox(-7.5F, -1.0F, -1.0F, 15.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.5F, -22.605492985277237F, -5.626833645710766F, -2.504626931909442F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_2", CubeListBuilder.create().texOffs(800, 35).addBox(-7.5F, -1.0F, -1.0F, 15.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.5F, -23.498276862689735F, -4.157411549350906F, -2.6866171381038297F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_3", CubeListBuilder.create().texOffs(834, 35).addBox(-7.5F, -1.0F, -1.0F, 15.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.5F, -24.110370113322702F, -2.5506737980150325F, -2.868607344298213F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_4", CubeListBuilder.create().texOffs(868, 35).addBox(-7.5F, -1.0F, -1.0F, 15.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.5F, -24.421555834274105F, -0.8596895295742373F, -3.050597550492601F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_5", CubeListBuilder.create().texOffs(902, 35).addBox(-7.5F, -1.0F, -1.0F, 15.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.5F, -24.421555834274102F, 0.8596895295742383F, 3.050597550492601F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_6", CubeListBuilder.create().texOffs(936, 35).addBox(-7.5F, -1.0F, -1.0F, 15.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.5F, -24.110370113322706F, 2.5506737980150342F, 2.868607344298213F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_7", CubeListBuilder.create().texOffs(970, 35).addBox(-7.5F, -1.0F, -1.0F, 15.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.5F, -23.498276862689735F, 4.157411549350908F, 2.6866171381038293F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_8", CubeListBuilder.create().texOffs(0, 46).addBox(-7.5F, -1.0F, -1.0F, 15.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.5F, -22.605492985277237F, 5.626833645710766F, 2.504626931909442F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_9", CubeListBuilder.create().texOffs(34, 46).addBox(-7.5F, -1.0F, -1.0F, 15.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.5F, -21.46150634905875F, 6.9104063648006555F, 2.3226367257150553F, 0.0F, 0.0F));
        g.addOrReplaceChild("freno_0", CubeListBuilder.create().texOffs(848, 0).addBox(-6.0F, -15.0F, -2.5F, 12.0F, 6.0F, 5.0F).texOffs(316, 0).addBox(-2.5F, -15.0F, -6.0F, 5.0F, 6.0F, 12.0F), PartPose.offset(8.0F, 0.0F, 3.5F));
        g.addOrReplaceChild("freno_1", CubeListBuilder.create().texOffs(882, 0).addBox(-6.0F, -15.0F, -2.5F, 12.0F, 6.0F, 5.0F).texOffs(350, 0).addBox(-2.5F, -15.0F, -6.0F, 5.0F, 6.0F, 12.0F), PartPose.offsetAndRotation(8.0F, 0.0F, 3.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("volante_freno", CubeListBuilder.create().texOffs(620, 0).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(8.0F, -15.1F, 3.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("farol_t_0", CubeListBuilder.create().texOffs(164, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(0, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(16.05F, -12.0F, -3.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("farol_t_1", CubeListBuilder.create().texOffs(188, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(24, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(16.05F, -12.0F, -3.5F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("farol_t_2", CubeListBuilder.create().texOffs(212, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(48, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(16.05F, -12.0F, -3.5F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("farol_t_3", CubeListBuilder.create().texOffs(236, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(72, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(16.05F, -12.0F, -3.5F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("farol_t_vidrio", CubeListBuilder.create().texOffs(244, 35).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.470000000000002F, -12.0F, -3.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro", CubeListBuilder.create().texOffs(112, 35).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(3.6F, -16.6F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro_aguja", CubeListBuilder.create().texOffs(710, 46).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.72F, -16.6F, 0.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(504, 35).addBox(-0.5F, -6.0F, -0.5F, 1.0F, 6.0F, 1.0F).texOffs(712, 35).addBox(-1.0F, -8.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(5.5F, -9.0F, -1.0F));
        g.addOrReplaceChild("cab_palanca_cuadrante", CubeListBuilder.create().texOffs(696, 46).addBox(4.5F, -10.0F, -1.5F, 2.0F, 1.0F, 1.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "capo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "tapa_radiador_0", 0.0503500508626846F, 1.0F, 0.0503500508626846F);
        escalar(g0, "tapa_radiador_1", 0.0503500508626846F, 1.0F, 0.0503500508626846F);
        escalar(g0, "escape_0", 0.09238795325112868F, 1.0F, 0.09238795325112868F);
        escalar(g0, "escape_1", 0.09238795325112868F, 1.0F, 0.09238795325112868F);
        escalar(g0, "escape_codo", 1.2F, 0.9718253158075502F, 1.2F);
        escalar(g0, "manivela", 0.6F, 0.8333333333333334F, 0.6F);
        escalar(g0, "manivela_mango", 0.6F, 0.8333333333333334F, 0.6F);
        escalar(g0, "farol_0", 0.15692564486451688F, 1.0F, 0.15692564486451688F);
        escalar(g0, "farol_1", 0.15692564486451688F, 1.0F, 0.15692564486451688F);
        escalar(g0, "farol_2", 0.15692564486451688F, 1.0F, 0.15692564486451688F);
        escalar(g0, "farol_3", 0.15692564486451688F, 1.0F, 0.15692564486451688F);
        escalar(g0, "farol_vidrio", 0.2285714285714286F, 0.15F, 0.2285714285714286F);
        escalar(g0, "techo_0", 1.0013333333333334F, 1.0F, 0.8732610117432648F);
        escalar(g0, "techo_1", 1.0013333333333334F, 1.0F, 0.8732610117432659F);
        escalar(g0, "techo_2", 1.0013333333333334F, 1.0F, 0.873261011743265F);
        escalar(g0, "techo_3", 1.0013333333333334F, 1.0F, 0.8732610117432651F);
        escalar(g0, "techo_4", 1.0013333333333334F, 1.0F, 0.8732610117432646F);
        escalar(g0, "techo_5", 1.0013333333333334F, 1.0F, 0.8732610117432658F);
        escalar(g0, "techo_6", 1.0013333333333334F, 1.0F, 0.873261011743265F);
        escalar(g0, "techo_7", 1.0013333333333334F, 1.0F, 0.8732610117432642F);
        escalar(g0, "techo_8", 1.0013333333333334F, 1.0F, 0.8732610117432659F);
        escalar(g0, "techo_9", 1.0013333333333334F, 1.0F, 0.8732610117432648F);
        escalar(g0, "freno_0", 0.06159196883408579F, 1.0F, 0.06159196883408579F);
        escalar(g0, "freno_1", 0.06159196883408579F, 1.0F, 0.06159196883408579F);
        escalar(g0, "volante_freno", 0.25F, 0.6F, 0.25F);
        escalar(g0, "farol_t_0", 0.15692564486451688F, 1.0F, 0.15692564486451688F);
        escalar(g0, "farol_t_1", 0.15692564486451688F, 1.0F, 0.15692564486451688F);
        escalar(g0, "farol_t_2", 0.15692564486451688F, 1.0F, 0.15692564486451688F);
        escalar(g0, "farol_t_3", 0.15692564486451688F, 1.0F, 0.15692564486451688F);
        escalar(g0, "farol_t_vidrio", 0.2285714285714286F, 0.15F, 0.2285714285714286F);
        escalar(g0, "cab_manometro", 0.24444444444444446F, 0.6F, 0.24444444444444446F);
        escalar(g0, "cab_manometro_aguja", 0.3F, 0.902F, 0.6F);
    }
}
