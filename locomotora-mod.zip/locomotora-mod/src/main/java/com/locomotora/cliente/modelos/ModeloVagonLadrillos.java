package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Vagón de ladrillera" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonLadrillos {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_ladrillos"), "main"),
            LocomotoraMod.id("textures/entity/vagon_ladrillos.png"),
            List.of(
                new DatosModelo.Animada("ri0_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -6.0F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri0_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -6.0F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri0_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -6.0F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("ri1_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 6.0F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri1_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 6.0F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri1_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 6.0F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd0_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -6.0F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd0_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -6.0F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd0_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -6.0F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd1_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 6.0F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd1_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 6.0F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd1_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 6.0F, -2.5F, 1.0471975511965976F, "cuerpo")),
            ModeloVagonLadrillos::crearCapa,
            16.0F,
            ModeloVagonLadrillos::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -6.0F, 6.0F)));

    private ModeloVagonLadrillos() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 32);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");

    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("ri0_0", CubeListBuilder.create().texOffs(184, 0).addBox(-2.5F, -2.5F, -6.0F, 5.0F, 5.0F, 2.0F).texOffs(348, 0).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(198, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 0).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-6.0F, -2.5F, 0.0F));
        g.addOrReplaceChild("ri0_1", CubeListBuilder.create().texOffs(362, 0).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.0F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri0_2", CubeListBuilder.create().texOffs(376, 0).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(210, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.0F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ri1_0", CubeListBuilder.create().texOffs(184, 0).addBox(-2.5F, -2.5F, -6.0F, 5.0F, 5.0F, 2.0F).texOffs(348, 0).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(198, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(226, 0).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(6.0F, -2.5F, 0.0F));
        g.addOrReplaceChild("ri1_1", CubeListBuilder.create().texOffs(362, 0).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.0F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri1_2", CubeListBuilder.create().texOffs(376, 0).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(210, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.0F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd0_0", CubeListBuilder.create().texOffs(184, 0).addBox(-2.5F, -2.5F, 4.0F, 5.0F, 5.0F, 2.0F).texOffs(348, 0).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(198, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(236, 0).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-6.0F, -2.5F, 0.0F));
        g.addOrReplaceChild("rd0_1", CubeListBuilder.create().texOffs(362, 0).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.0F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd0_2", CubeListBuilder.create().texOffs(376, 0).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(210, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.0F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd1_0", CubeListBuilder.create().texOffs(184, 0).addBox(-2.5F, -2.5F, 4.0F, 5.0F, 5.0F, 2.0F).texOffs(348, 0).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(198, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(246, 0).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(6.0F, -2.5F, 0.0F));
        g.addOrReplaceChild("rd1_1", CubeListBuilder.create().texOffs(362, 0).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.0F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd1_2", CubeListBuilder.create().texOffs(376, 0).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(210, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.0F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(256, 0).addBox(-11.0F, -5.0F, 2.0F, 22.0F, 2.0F, 1.0F).texOffs(302, 0).addBox(-11.0F, -5.0F, -3.0F, 22.0F, 2.0F, 1.0F).texOffs(76, 0).addBox(-11.0F, -7.0F, -6.0F, 22.0F, 2.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("topei", CubeListBuilder.create().texOffs(160, 0).addBox(-13.0F, -7.0F, -2.0F, 2.0F, 4.0F, 4.0F).texOffs(390, 0).addBox(-14.0F, -5.5F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("toped", CubeListBuilder.create().texOffs(172, 0).addBox(11.0F, -7.0F, -2.0F, 2.0F, 4.0F, 4.0F).texOffs(394, 0).addBox(13.0F, -5.5F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("ladrillos", CubeListBuilder.create().texOffs(0, 0).addBox(-10.0F, -14.0F, -5.0F, 9.0F, 7.0F, 10.0F).texOffs(38, 0).addBox(1.0F, -14.0F, -5.0F, 9.0F, 7.0F, 10.0F), PartPose.ZERO);
        g.addOrReplaceChild("estacas", CubeListBuilder.create().texOffs(144, 0).addBox(-11.0F, -15.0F, 5.0F, 1.0F, 8.0F, 1.0F).texOffs(148, 0).addBox(-11.0F, -15.0F, -6.0F, 1.0F, 8.0F, 1.0F).texOffs(152, 0).addBox(10.0F, -15.0F, 5.0F, 1.0F, 8.0F, 1.0F).texOffs(156, 0).addBox(10.0F, -15.0F, -6.0F, 1.0F, 8.0F, 1.0F), PartPose.ZERO);
    }


}
