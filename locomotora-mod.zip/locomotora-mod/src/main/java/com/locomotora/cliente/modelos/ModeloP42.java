package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "GE P42 Genesis" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloP42 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("p42"), "main"),
            LocomotoraMod.id("textures/entity/p42.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -66.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -66.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -66.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -66.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -66.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -66.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 52.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 72.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, -79.28F, -26.0F, 0.0F, "cuerpo", 4.8F, 5.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.15F, 0.0F, -79.0F, -25.0F, 0.15F, "cuerpo", -0.24F, 7.5F, 0.0F)),
            ModeloP42::crearCapa,
            16.0F,
            ModeloP42::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -56.0F, 62.0F)));

    private ModeloP42() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(260, 51).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(808, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(668, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(138, 302).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-66.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(832, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(856, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(688, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(260, 51).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(808, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(668, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(148, 302).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(832, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(856, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(688, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(260, 51).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(808, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(668, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(158, 302).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-66.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(832, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(856, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(688, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(260, 51).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(808, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(668, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(168, 302).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(832, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(856, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(688, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(724, 288).addBox(-72.5F, -9.0F, 7.0F, 33.0F, 6.0F, 1.0F).texOffs(792, 288).addBox(-72.5F, -9.0F, -8.0F, 33.0F, 6.0F, 1.0F).texOffs(178, 302).addBox(-68.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(188, 302).addBox(-68.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(198, 302).addBox(-48.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(208, 302).addBox(-48.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(260, 51).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(808, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(668, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(218, 302).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(52.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(832, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(856, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(688, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(260, 51).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(808, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(668, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(228, 302).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(72.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(832, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(856, 295).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(688, 51).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(260, 51).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(808, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(668, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(238, 302).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(52.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(832, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(856, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(688, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(52.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(260, 51).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(808, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(668, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(248, 302).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(72.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(832, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(856, 295).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(688, 51).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(860, 288).addBox(45.5F, -9.0F, 7.0F, 33.0F, 6.0F, 1.0F).texOffs(928, 288).addBox(45.5F, -9.0F, -8.0F, 33.0F, 6.0F, 1.0F).texOffs(258, 302).addBox(50.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(268, 302).addBox(50.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(278, 302).addBox(70.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(288, 302).addBox(70.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("chasis", CubeListBuilder.create().texOffs(130, 0).addBox(-82.0F, -12.0F, -13.0F, 178.0F, 3.0F, 26.0F).texOffs(556, 0).addBox(-30.0F, -9.0F, -11.0F, 64.0F, 5.0F, 22.0F).texOffs(776, 295).addBox(96.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_0", CubeListBuilder.create().texOffs(0, 99).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -12.516973827236846F, -14.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_1", CubeListBuilder.create().texOffs(0, 107).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -15.550921481710542F, -14.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_2", CubeListBuilder.create().texOffs(0, 115).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -18.58486913618424F, -14.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_3", CubeListBuilder.create().texOffs(0, 123).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -21.61881679065793F, -14.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_4", CubeListBuilder.create().texOffs(0, 131).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -24.652764445131623F, -14.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_5", CubeListBuilder.create().texOffs(0, 267).addBox(-178.0F, -1.0F, -3.0F, 356.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(7.0F, -27.587950033510847F, -13.544054137578811F, -1.8818534545803636F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_6", CubeListBuilder.create().texOffs(0, 139).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -30.387163914157796F, -12.460380039019183F, -1.9974238199217726F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_7", CubeListBuilder.create().texOffs(0, 147).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -33.14916815316694F, -11.204923566742298F, -1.9974238199217726F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_8", CubeListBuilder.create().texOffs(0, 274).addBox(-178.0F, -1.0F, -3.0F, 356.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(7.0F, -35.73844405299126F, -9.824474262626467F, -2.12793617510914F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_9", CubeListBuilder.create().texOffs(0, 155).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -37.11122986787612F, -7.56372621113557F, -3.0329314377492054F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_10", CubeListBuilder.create().texOffs(0, 163).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -37.38787095122061F, -4.54482344104788F, -3.067513853943748F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_11", CubeListBuilder.create().texOffs(0, 171).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -37.5F, -1.5169738272368498F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_12", CubeListBuilder.create().texOffs(0, 179).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -37.5F, 1.5169738272368463F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_13", CubeListBuilder.create().texOffs(0, 187).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -37.38787095122062F, 4.544823441047875F, 3.0675138539437503F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_14", CubeListBuilder.create().texOffs(0, 195).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -37.11122986787612F, 7.56372621113557F, 3.032931437749203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_15", CubeListBuilder.create().texOffs(0, 281).addBox(-178.0F, -1.0F, -3.0F, 356.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(7.0F, -35.73844405299126F, 9.824474262626467F, 2.127936175109139F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_16", CubeListBuilder.create().texOffs(0, 203).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -33.14916815316695F, 11.204923566742297F, 1.997423819921773F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_17", CubeListBuilder.create().texOffs(0, 211).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -30.387163914157796F, 12.460380039019181F, 1.9974238199217726F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_18", CubeListBuilder.create().texOffs(0, 288).addBox(-178.0F, -1.0F, -3.0F, 356.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(7.0F, -27.58795003351085F, 13.544054137578813F, 1.881853454580364F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_19", CubeListBuilder.create().texOffs(0, 219).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -24.65276444513163F, 14.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_20", CubeListBuilder.create().texOffs(0, 227).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -21.618816790657938F, 14.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_21", CubeListBuilder.create().texOffs(0, 235).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -18.584869136184242F, 14.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_22", CubeListBuilder.create().texOffs(0, 243).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -15.550921481710553F, 14.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_23", CubeListBuilder.create().texOffs(0, 251).addBox(-178.0F, -1.0F, -3.5F, 356.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(7.0F, -12.516973827236853F, 14.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("cola", CubeListBuilder.create().texOffs(0, 0).addBox(95.0F, -36.0F, -13.0F, 1.0F, 25.0F, 26.0F).texOffs(538, 0).addBox(96.0F, -33.0F, -4.0F, 1.0F, 20.0F, 8.0F).texOffs(792, 295).addBox(-103.5F, -10.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("nariz_0", CubeListBuilder.create().texOffs(104, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.77569724577556F, -6.97453125F, -13.102248632243429F, -2.0388973896350366F, 0.0027823475660651987F, -1.57220302132486F));
        g.addOrReplaceChild("nariz_1", CubeListBuilder.create().texOffs(128, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.78651776091647F, -8.92359375F, -13.10357712844698F, -2.0358616815091417F, 0.0027657617008483674F, -1.5721841098988354F));
        g.addOrReplaceChild("nariz_2", CubeListBuilder.create().texOffs(36, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-83.79732631213159F, -10.87265625F, -13.104891731366243F, -2.0328622662009974F, 0.0027493043228910834F, -1.5721655450527077F));
        g.addOrReplaceChild("nariz_3", CubeListBuilder.create().texOffs(62, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-83.80812316561924F, -12.82171875F, -13.106192618509635F, -2.029898549751896F, 0.002732975655404939F, -1.5721473191860955F));
        g.addOrReplaceChild("nariz_4", CubeListBuilder.create().texOffs(88, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-83.79957637556483F, -14.770781249999999F, -13.105155154409797F, -2.032256460180725F, -0.0070894332697842375F, -1.5672710180996536F));
        g.addOrReplaceChild("nariz_5", CubeListBuilder.create().texOffs(152, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.76938331321543F, -16.719843750000003F, -13.10145500390533F, -2.0407056935351195F, -0.008376137006572828F, -1.5665425652409242F));
        g.addOrReplaceChild("nariz_6", CubeListBuilder.create().texOffs(176, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.73682408825559F, -18.66890625F, -13.097358666993049F, -2.050104624855384F, -0.008528370520765431F, -1.5663639426323097F));
        g.addOrReplaceChild("nariz_7", CubeListBuilder.create().texOffs(200, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.70414525531699F, -20.61796875F, -13.093129737371113F, -2.0598992728827135F, -0.005444139902582937F, -1.560087235102791F));
        g.addOrReplaceChild("nariz_8", CubeListBuilder.create().texOffs(224, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.61443180256369F, -22.56703125F, -13.080591304179912F, -2.0898059777623375F, -0.025515169575836664F, -1.5217214514959039F));
        g.addOrReplaceChild("nariz_9", CubeListBuilder.create().texOffs(264, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-83.45158659957045F, -24.516093750000003F, -13.055752414737267F, -2.149645185331898F, -0.03355482408595328F, -1.5079507087901964F));
        g.addOrReplaceChild("nariz_10", CubeListBuilder.create().texOffs(286, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-83.27127738820477F, -26.465156250000003F, -12.933474179689934F, -2.226183434749212F, -0.11190126339550356F, -1.4807280955628936F));
        g.addOrReplaceChild("nariz_11", CubeListBuilder.create().texOffs(216, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-83.0810879326334F, -28.41421875F, -12.401869587691982F, -2.307419612897888F, -0.34402114035361125F, -1.3907799248638089F));
        g.addOrReplaceChild("nariz_12", CubeListBuilder.create().texOffs(238, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-82.87889047811316F, -30.363281249999996F, -11.553068654134393F, -2.388996493159141F, -0.32905394040990615F, -1.3827882859701193F));
        g.addOrReplaceChild("nariz_13", CubeListBuilder.create().texOffs(656, 295).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.66771724780907F, -32.31234375F, -10.70211068674021F, -2.502260177253806F, -0.3067266413883465F, -1.3757629732065266F));
        g.addOrReplaceChild("nariz_14", CubeListBuilder.create().texOffs(1000, 295).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-82.4378599821022F, -34.26140625F, -9.850674441248335F, -2.6695494473654153F, -0.2734057673991434F, -1.3711627660361492F));
        g.addOrReplaceChild("nariz_15", CubeListBuilder.create().texOffs(690, 302).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-82.18078031500193F, -36.210468750000004F, -7.869728961498944F, -2.7173689067967324F, -1.0067757049089925F, -1.4325598189163622F));
        g.addOrReplaceChild("nariz_16", CubeListBuilder.create().texOffs(248, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-87.3270917373267F, -6.97453125F, -11.306745896730288F, -2.038913044818339F, 0.008346804326552451F, -1.5750163881165895F));
        g.addOrReplaceChild("nariz_17", CubeListBuilder.create().texOffs(272, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-87.35955328274939F, -8.92359375F, -11.31073138534094F, -2.0358770341670036F, 0.008297051941499605F, -1.5749596547246003F));
        g.addOrReplaceChild("nariz_18", CubeListBuilder.create().texOffs(114, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-87.39197893639479F, -10.87265625F, -11.314675194098726F, -2.032877323356919F, 0.008247684879591046F, -1.5749039610328923F));
        g.addOrReplaceChild("nariz_19", CubeListBuilder.create().texOffs(140, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-87.42436949685771F, -12.82171875F, -11.318577855528906F, -2.0299133182504603F, 0.008198703814625528F, -1.5748492842422348F));
        g.addOrReplaceChild("nariz_20", CubeListBuilder.create().texOffs(166, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-87.39872912669446F, -14.770781249999999F, -11.31546546322939F, -2.032356410779569F, -0.02126439327317924F, -1.560220751182081F));
        g.addOrReplaceChild("nariz_21", CubeListBuilder.create().texOffs(296, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-87.30814993964626F, -16.719843750000003F, -11.30436501171599F, -2.040848175050379F, -0.02512189390267939F, -1.558035657834353F));
        g.addOrReplaceChild("nariz_22", CubeListBuilder.create().texOffs(320, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-87.21047226476678F, -18.66890625F, -11.292076000979149F, -2.050255785297979F, -0.02557814194036489F, -1.5574998708687084F));
        g.addOrReplaceChild("nariz_23", CubeListBuilder.create().texOffs(344, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-87.11243576595095F, -20.61796875F, -11.27938921211334F, -2.060403318521115F, -0.016327336430997742F, -1.5386858013398876F));
        g.addOrReplaceChild("nariz_24", CubeListBuilder.create().texOffs(966, 71).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-86.84329540769107F, -22.56703125F, -11.241773912539735F, -2.100174303867194F, -0.07600191707927526F, -1.4250393181083807F));
        g.addOrReplaceChild("nariz_25", CubeListBuilder.create().texOffs(934, 251).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-86.35475979871134F, -24.516093750000003F, -11.167257244211802F, -2.1661055895643293F, -0.09933075547890545F, -1.3849541573748276F));
        g.addOrReplaceChild("nariz_26", CubeListBuilder.create().texOffs(958, 251).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-85.8138321646143F, -26.465156250000003F, -11.000280493615255F, -2.2483005471926303F, -0.16560989160099654F, -1.3530546032021864F));
        g.addOrReplaceChild("nariz_27", CubeListBuilder.create().texOffs(260, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-85.24326379790018F, -28.41421875F, -10.491262172166856F, -2.3461678909064894F, -0.351348603771947F, -1.2627657296493087F));
        g.addOrReplaceChild("nariz_28", CubeListBuilder.create().texOffs(282, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-84.63667143433949F, -30.363281249999996F, -9.716734371494082F, -2.4275714679584004F, -0.34038394937371624F, -1.2425270039456957F));
        g.addOrReplaceChild("nariz_29", CubeListBuilder.create().texOffs(676, 295).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.0031517434272F, -32.31234375F, -8.935735469311535F, -2.5394028200402223F, -0.3208079981382712F, -1.216653896472374F));
        g.addOrReplaceChild("nariz_30", CubeListBuilder.create().texOffs(0, 302).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-83.3135799463066F, -34.26140625F, -8.153301732835914F, -2.7030297429345445F, -0.28566833445596934F, -1.1760251368075447F));
        g.addOrReplaceChild("nariz_31", CubeListBuilder.create().texOffs(734, 302).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-82.54234094500578F, -36.210468750000004F, -6.465294839042308F, -2.817904277678776F, -0.8876246712935253F, -1.1754048063042737F));
        g.addOrReplaceChild("nariz_32", CubeListBuilder.create().texOffs(368, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.87848622887782F, -6.97453125F, -9.511243161217141F, -2.038944352615726F, 0.013910546084868669F, -1.5778296881058387F));
        g.addOrReplaceChild("nariz_33", CubeListBuilder.create().texOffs(392, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.93258880458231F, -8.92359375F, -9.517885642234898F, -2.0359077370093113F, 0.01382764280764046F, -1.5777351354060065F));
        g.addOrReplaceChild("nariz_34", CubeListBuilder.create().texOffs(192, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-90.98663156065797F, -10.87265625F, -9.524458656831213F, -2.032907435287087F, 0.013745381273696415F, -1.5776423154086117F));
        g.addOrReplaceChild("nariz_35", CubeListBuilder.create().texOffs(218, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-91.04061582809618F, -12.82171875F, -9.530963092548177F, -2.0299428529537877F, 0.013663762619924422F, -1.5775511901213255F));
        g.addOrReplaceChild("nariz_36", CubeListBuilder.create().texOffs(244, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-90.99788187782411F, -14.770781249999999F, -9.525775772048986F, -2.032556207063725F, -0.035427645566813236F, -1.5531715354742248F));
        g.addOrReplaceChild("nariz_37", CubeListBuilder.create().texOffs(416, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.84691656607711F, -16.719843750000003F, -9.507275019526652F, -2.041132925558189F, -0.04184812740487105F, -1.5495305969973232F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("nariz_38", CubeListBuilder.create().texOffs(440, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.68412044127795F, -18.66890625F, -9.486793334965247F, -2.050557867632409F, -0.042607035819450675F, -1.5486378881331995F));
        g.addOrReplaceChild("nariz_39", CubeListBuilder.create().texOffs(464, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.52072627658492F, -20.61796875F, -9.46564868685557F, -2.061408673091006F, -0.027195304173521083F, -1.517334393504282F));
        g.addOrReplaceChild("nariz_40", CubeListBuilder.create().texOffs(992, 71).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.07215901281846F, -22.56703125F, -9.402956520899558F, -2.119829646501336F, -0.12491177578673424F, -1.3324131722011274F));
        g.addOrReplaceChild("nariz_41", CubeListBuilder.create().texOffs(982, 251).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-89.25793299785224F, -24.516093750000003F, -9.278762073686337F, -2.19638451940096F, -0.16135817343946643F, -1.2691806954864404F));
        g.addOrReplaceChild("nariz_42", CubeListBuilder.create().texOffs(0, 259).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-88.35638694102383F, -26.465156250000003F, -9.06708680754058F, -2.2821809886958255F, -0.21421817983545308F, -1.2333692125248992F));
        g.addOrReplaceChild("nariz_43", CubeListBuilder.create().texOffs(304, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-87.40543966316697F, -28.41421875F, -8.580654756641726F, -2.3891395853216757F, -0.352955881871795F, -1.1439056464327608F));
        g.addOrReplaceChild("nariz_44", CubeListBuilder.create().texOffs(326, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-86.39445239056583F, -30.363281249999996F, -7.880400088853775F, -2.4714779780845006F, -0.34439254779172357F, -1.1136795888926576F));
        g.addOrReplaceChild("nariz_45", CubeListBuilder.create().texOffs(696, 295).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-85.33858623904533F, -32.31234375F, -7.169360251882859F, -2.582956000868633F, -0.3254874206523905F, -1.0732238942749883F));
        g.addOrReplaceChild("nariz_46", CubeListBuilder.create().texOffs(18, 302).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.18929991051101F, -34.26140625F, -6.455929024423493F, -2.7435706369238577F, -0.28594449675772504F, -1.0070352578881634F));
        g.addOrReplaceChild("nariz_47", CubeListBuilder.create().texOffs(754, 302).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-82.90390157500963F, -36.210468750000004F, -5.0608607165856725F, -2.897680614855606F, -0.7191586936347124F, -0.9630165964629926F));
        g.addOrReplaceChild("nariz_48", CubeListBuilder.create().texOffs(488, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-94.42988072042894F, -6.97453125F, -7.715740425704F, -2.038991307890236F, 0.019473096548650308F, -1.5806428767646679F));
        g.addOrReplaceChild("nariz_49", CubeListBuilder.create().texOffs(512, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-94.50562432641524F, -8.92359375F, -7.725039899128857F, -2.035953785090623F, 0.01935706841155213F, -1.5805105091867373F));
        g.addOrReplaceChild("nariz_50", CubeListBuilder.create().texOffs(270, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-94.58128418492116F, -10.87265625F, -7.734242119563698F, -2.032952597229468F, 0.01924193774553882F, -1.5803805671163829F));
        g.addOrReplaceChild("nariz_51", CubeListBuilder.create().texOffs(296, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-94.65686215933462F, -12.82171875F, -7.743348329567447F, -2.0299871492755193F, 0.01912770617139866F, -1.5802529973777613F));
        g.addOrReplaceChild("nariz_52", CubeListBuilder.create().texOffs(322, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-94.59703462895376F, -14.770781249999999F, -7.7360860808685805F, -2.032855639592185F, -0.04957142458388514F, -1.5461240710861368F));
        g.addOrReplaceChild("nariz_53", CubeListBuilder.create().texOffs(536, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-94.38568319250795F, -16.719843750000003F, -7.710185027337313F, -2.0415595211156417F, -0.05854191481213895F, -1.5410286119954193F));
        g.addOrReplaceChild("nariz_54", CubeListBuilder.create().texOffs(560, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-94.15776861778912F, -18.66890625F, -7.681510668951346F, -2.0530843741472284F, -0.03725613223699149F, -1.4969464428863801F));
        g.addOrReplaceChild("nariz_55", CubeListBuilder.create().texOffs(584, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-93.92901678721888F, -20.61796875F, -7.651908161597796F, -2.06290991452617F, -0.03803796061341438F, -1.4960656269121362F));
        g.addOrReplaceChild("nariz_56", CubeListBuilder.create().texOffs(0, 81).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-93.30102261794585F, -22.56703125F, -7.564139129259379F, -2.146953162882756F, -0.17136199069766903F, -1.245590165777329F));
        g.addOrReplaceChild("nariz_57", CubeListBuilder.create().texOffs(24, 259).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-92.16110619699315F, -24.516093750000003F, -7.390266903160873F, -2.236384615170245F, -0.21787529142548515F, -1.1632388610342959F));
        g.addOrReplaceChild("nariz_58", CubeListBuilder.create().texOffs(48, 259).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-90.89894171743336F, -26.465156250000003F, -7.133893121465902F, -2.323590596619187F, -0.2570890620692166F, -1.1245406077331366F));
        g.addOrReplaceChild("nariz_59", CubeListBuilder.create().texOffs(348, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-89.56761552843378F, -28.41421875F, -6.6700473411166F, -2.432853828125348F, -0.3518048690397752F, -1.0378160473050808F));
        g.addOrReplaceChild("nariz_60", CubeListBuilder.create().texOffs(996, 288).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-88.1036546690869F, -30.363281249999996F, -6.026016766999118F, -2.563347840008206F, -0.3493702708914607F, -0.9605154133842376F));
        g.addOrReplaceChild("nariz_61", CubeListBuilder.create().texOffs(524, 295).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-86.55010052814943F, -32.31234375F, -5.362722963759906F, -2.7285716734822447F, -0.29736087572912373F, -0.9111448373658236F));
        g.addOrReplaceChild("nariz_62", CubeListBuilder.create().texOffs(880, 295).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.92297230741772F, -34.26140625F, -4.724078354292313F, -2.8994046342875475F, -0.2267864846448856F, -0.8557684227127252F));
        g.addOrReplaceChild("nariz_63", CubeListBuilder.create().texOffs(774, 302).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-83.18710657000578F, -36.210468750000004F, -3.6437030699536406F, -3.0264758004543113F, -0.5270349792578066F, -0.8284662002541207F));
        g.addOrReplaceChild("nariz_64", CubeListBuilder.create().texOffs(308, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.13324308466477F, -6.97453125F, -5.398735079521454F, -2.5633528323079955F, 0.017024631707267535F, -1.6179187619263333F));
        g.addOrReplaceChild("nariz_65", CubeListBuilder.create().texOffs(330, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.23743334835335F, -8.92359375F, -5.413115350042622F, -2.553483490321905F, 0.017141993959079893F, -1.6176647563150401F));
        g.addOrReplaceChild("nariz_66", CubeListBuilder.create().texOffs(352, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.34157575633887F, -10.87265625F, -5.427453785821222F, -2.5436449275546114F, 0.01725441535727299F, -1.6174094811812647F));
        g.addOrReplaceChild("nariz_67", CubeListBuilder.create().texOffs(374, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.44567137341443F, -12.82171875F, -5.441750851802746F, -2.533838975802667F, 0.01736187205098413F, -1.6171530828477692F));
        g.addOrReplaceChild("nariz_68", CubeListBuilder.create().texOffs(396, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.3633103850718F, -14.770781249999999F, -5.43041711700315F, -2.5454393069941617F, -0.04433343618880671F, -1.4510903317917612F));
        g.addOrReplaceChild("nariz_69", CubeListBuilder.create().texOffs(418, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.07254790129919F, -16.719843750000003F, -5.390305904587059F, -2.574407791404495F, -0.050407308440391575F, -1.4298442385890295F));
        g.addOrReplaceChild("nariz_70", CubeListBuilder.create().texOffs(440, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-96.75958639208487F, -18.66890625F, -5.346832693980858F, -2.6040863374110113F, -0.04923232894866987F, -1.4276302003803771F));
        g.addOrReplaceChild("nariz_71", CubeListBuilder.create().texOffs(462, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-96.44614645095542F, -20.61796875F, -5.302963622873674F, -2.633940380353378F, -0.04793180469045491F, -1.425469160639148F));
        g.addOrReplaceChild("nariz_72", CubeListBuilder.create().texOffs(72, 259).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-95.59143814775477F, -22.56703125F, -5.180794314886833F, -2.7849556736710626F, -0.16232815021530414F, -0.9788205412833267F));
        g.addOrReplaceChild("nariz_73", CubeListBuilder.create().texOffs(726, 251).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-94.05511375939291F, -24.516093750000003F, -4.955759904646562F, -2.9220016295186952F, -0.14183806152114117F, -0.870394517313343F));
        g.addOrReplaceChild("nariz_74", CubeListBuilder.create().texOffs(752, 251).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-92.39323021254128F, -26.465156250000003F, -4.681838979722391F, -3.0280459462344558F, -0.10656096033060042F, -0.8681297703425894F));
        g.addOrReplaceChild("nariz_75", CubeListBuilder.create().texOffs(0, 295).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-90.7120817652558F, -28.41421875F, -4.3009820461058075F, -3.107951784975F, -0.10324659999099582F, -0.846552785541912F));
        g.addOrReplaceChild("nariz_76", CubeListBuilder.create().texOffs(24, 295).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-88.93432264446963F, -30.363281249999996F, -3.817426698230853F, -3.1413882294194635F, -0.09292465008661603F, -0.8141357714462659F));
        g.addOrReplaceChild("nariz_77", CubeListBuilder.create().texOffs(546, 295).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-87.09389756944445F, -32.31234375F, -3.329454963263469F, -3.141592653589793F, -0.0872279409583081F, -0.8139618212362095F));
        g.addOrReplaceChild("nariz_78", CubeListBuilder.create().texOffs(900, 295).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-85.21878472222224F, -34.26140625F, -2.8806855287755093F, 3.141592653589793F, -0.07726623754781174F, -0.7956655191275965F));
        g.addOrReplaceChild("nariz_79", CubeListBuilder.create().texOffs(854, 302).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-83.28953125F, -36.210468750000004F, -2.1965718634124447F, 3.141592653589793F, -0.16484758754993462F, -0.7853981633974502F));
        g.addOrReplaceChild("nariz_80", CubeListBuilder.create().texOffs(608, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-98.060908203125F, -6.97453125F, -1.989740550547741F, 3.141592653589793F, 0.0F, -1.6332151367908565F));
        g.addOrReplaceChild("nariz_81", CubeListBuilder.create().texOffs(632, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-98.182724609375F, -8.92359375F, -1.9988068362547038F, 3.141592653589793F, 0.0F, -1.6332151367908494F));
        g.addOrReplaceChild("nariz_82", CubeListBuilder.create().texOffs(348, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-98.304541015625F, -10.87265625F, -2.007886860356253F, 3.141592653589793F, 0.0F, -1.6332151367908565F));
        g.addOrReplaceChild("nariz_83", CubeListBuilder.create().texOffs(374, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-98.426357421875F, -12.82171875F, -2.016980377764206F, 3.141592653589793F, 0.0F, -1.6332151367908494F));
        g.addOrReplaceChild("nariz_84", CubeListBuilder.create().texOffs(400, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-98.330009765625F, -14.770781249999999F, -2.0097964993639614F, -3.141592653589793F, 0.0F, -1.4108097962386679F));
        g.addOrReplaceChild("nariz_85", CubeListBuilder.create().texOffs(656, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.990029296875F, -16.719843750000003F, -1.9844858889657377F, -3.141592653589793F, 0.0F, -1.3854483767992014F));
        g.addOrReplaceChild("nariz_86", CubeListBuilder.create().texOffs(680, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.624580078125F, -18.66890625F, -1.9573980260086605F, 3.141592653589793F, -0.006813015456470001F, -1.385448376799208F));
        g.addOrReplaceChild("nariz_87", CubeListBuilder.create().texOffs(704, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.259130859375F, -20.61796875F, -1.9304446733892195F, 3.141592653589793F, -0.006778169739965444F, -1.3854483767992016F));
        g.addOrReplaceChild("nariz_88", CubeListBuilder.create().texOffs(910, 71).addBox(-3.0F, -1.0F, -4.0F, 6.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-96.26742187500001F, -22.56703125F, -1.8584290981671883F, -3.141592653589793F, -0.023106637582737007F, -0.8779534984581673F));
        g.addOrReplaceChild("nariz_89", CubeListBuilder.create().texOffs(778, 251).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-94.49753472222221F, -24.516093750000003F, -1.732750245697491F, 3.141592653589793F, -0.02449659014039355F, -0.7924396056703372F));
        g.addOrReplaceChild("nariz_90", CubeListBuilder.create().texOffs(804, 251).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-92.61624131944444F, -26.465156250000003F, -1.59819084050811F, -3.141592653589793F, -0.02513958367782266F, -0.8139618212362105F));
        g.addOrReplaceChild("nariz_91", CubeListBuilder.create().texOffs(48, 295).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-90.77546006944445F, -28.41421875F, -1.4436102294287898F, -3.141592653589793F, -0.03245314682243595F, -0.8139618212362058F));
        g.addOrReplaceChild("nariz_92", CubeListBuilder.create().texOffs(72, 295).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-88.93467881944446F, -30.363281249999996F, -1.2725264049985454F, -3.141592653589793F, -0.031275741982155304F, -0.8139618212362105F));
        g.addOrReplaceChild("nariz_93", CubeListBuilder.create().texOffs(568, 295).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-87.09389756944445F, -32.31234375F, -1.1098183210878236F, -3.141592653589793F, -0.02934086520012581F, -0.8139618212362096F));
        g.addOrReplaceChild("nariz_94", CubeListBuilder.create().texOffs(920, 295).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-85.21878472222224F, -34.26140625F, -0.9602285095918366F, 3.141592653589793F, -0.02593911001515553F, -0.7956655191275966F));
        g.addOrReplaceChild("nariz_95", CubeListBuilder.create().texOffs(872, 302).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-83.28953125F, -36.210468750000004F, -0.7321906211374818F, -3.141592653589793F, -0.056785308591843935F, -0.7853981633974502F));
        g.addOrReplaceChild("nariz_96", CubeListBuilder.create().texOffs(728, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-98.060908203125F, -6.97453125F, 1.9897405505477366F, 3.141592653589793F, 0.0F, -1.6332151367908565F));
        g.addOrReplaceChild("nariz_97", CubeListBuilder.create().texOffs(752, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-98.182724609375F, -8.92359375F, 1.9988068362546985F, 3.141592653589793F, 0.0F, -1.6332151367908494F));
        g.addOrReplaceChild("nariz_98", CubeListBuilder.create().texOffs(426, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-98.304541015625F, -10.87265625F, 2.0078868603562476F, 3.141592653589793F, 0.0F, -1.6332151367908565F));
        g.addOrReplaceChild("nariz_99", CubeListBuilder.create().texOffs(452, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-98.426357421875F, -12.82171875F, 2.0169803777642006F, 3.141592653589793F, 0.0F, -1.6332151367908494F));
        g.addOrReplaceChild("nariz_100", CubeListBuilder.create().texOffs(478, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-98.330009765625F, -14.770781249999999F, 2.009796499363956F, -3.141592653589793F, 0.0F, -1.4108097962386679F));
        g.addOrReplaceChild("nariz_101", CubeListBuilder.create().texOffs(776, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.990029296875F, -16.719843750000003F, 1.9844858889657333F, -3.141592653589793F, 0.0F, -1.3854483767992014F));
        g.addOrReplaceChild("nariz_102", CubeListBuilder.create().texOffs(800, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.624580078125F, -18.66890625F, 1.957398026008657F, -3.141592653589793F, 0.006813015456470001F, -1.385448376799208F));
        g.addOrReplaceChild("nariz_103", CubeListBuilder.create().texOffs(824, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-97.259130859375F, -20.61796875F, 1.930444673389215F, -3.141592653589793F, 0.006778169739965836F, -1.3854483767992016F));
        g.addOrReplaceChild("nariz_104", CubeListBuilder.create().texOffs(938, 71).addBox(-3.0F, -1.0F, -4.0F, 6.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-96.26742187500001F, -22.56703125F, 1.8584290981671838F, 3.141592653589793F, 0.023106637582736612F, -0.8779534984581673F));
        g.addOrReplaceChild("nariz_105", CubeListBuilder.create().texOffs(830, 251).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-94.49753472222221F, -24.516093750000003F, 1.7327502456974893F, 3.141592653589793F, 0.024496590140392998F, -0.792439605670337F));
        g.addOrReplaceChild("nariz_106", CubeListBuilder.create().texOffs(856, 251).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-92.61624131944444F, -26.465156250000003F, 1.5981908405081082F, 3.141592653589793F, 0.025139583677823287F, -0.8139618212362105F));
        g.addOrReplaceChild("nariz_107", CubeListBuilder.create().texOffs(96, 295).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-90.77546006944445F, -28.41421875F, 1.4436102294287876F, -3.141592653589793F, 0.03245314682243555F, -0.8139618212362058F));
        g.addOrReplaceChild("nariz_108", CubeListBuilder.create().texOffs(120, 295).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-88.93467881944446F, -30.363281249999996F, 1.2725264049985432F, -3.141592653589793F, 0.03127574198215577F, -0.8139618212362105F));
        g.addOrReplaceChild("nariz_109", CubeListBuilder.create().texOffs(590, 295).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-87.09389756944445F, -32.31234375F, 1.1098183210878214F, 3.141592653589793F, 0.02934086520012526F, -0.8139618212362096F));
        g.addOrReplaceChild("nariz_110", CubeListBuilder.create().texOffs(940, 295).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-85.21878472222224F, -34.26140625F, 0.9602285095918353F, 3.141592653589793F, 0.025939110015155607F, -0.7956655191275965F));
        g.addOrReplaceChild("nariz_111", CubeListBuilder.create().texOffs(890, 302).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-83.28953125F, -36.210468750000004F, 0.7321906211374805F, 3.141592653589793F, 0.056785308591843935F, -0.7853981633974503F));
        g.addOrReplaceChild("nariz_112", CubeListBuilder.create().texOffs(484, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.13324308466477F, -6.97453125F, 5.398735079521451F, 2.5633528323079964F, -0.01702463170726675F, -1.617918761926333F));
        g.addOrReplaceChild("nariz_113", CubeListBuilder.create().texOffs(506, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.23743334835335F, -8.92359375F, 5.413115350042617F, 2.553483490321908F, -0.01714199395908013F, -1.617664756315043F));
        g.addOrReplaceChild("nariz_114", CubeListBuilder.create().texOffs(528, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.34157575633887F, -10.87265625F, 5.427453785821217F, 2.543644927554614F, -0.0172544153572726F, -1.6174094811812618F));
        g.addOrReplaceChild("nariz_115", CubeListBuilder.create().texOffs(550, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.44567137341443F, -12.82171875F, 5.441750851802743F, 2.5338389758026687F, -0.017361872050983895F, -1.6171530828477692F));
        g.addOrReplaceChild("nariz_116", CubeListBuilder.create().texOffs(572, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.3633103850718F, -14.770781249999999F, 5.430417117003145F, 2.545439306994163F, 0.044333436188806793F, -1.4510903317917612F));
        g.addOrReplaceChild("nariz_117", CubeListBuilder.create().texOffs(594, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-97.07254790129919F, -16.719843750000003F, 5.390305904587056F, 2.574407791404496F, 0.050407308440390784F, -1.4298442385890298F));
        g.addOrReplaceChild("nariz_118", CubeListBuilder.create().texOffs(616, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-96.75958639208486F, -18.66890625F, 5.346832693980855F, 2.604086337411012F, 0.04923232894866971F, -1.4276302003803771F));
        g.addOrReplaceChild("nariz_119", CubeListBuilder.create().texOffs(638, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-96.44614645095542F, -20.61796875F, 5.302963622873671F, 2.633940380353379F, 0.04793180469045578F, -1.4254691606391479F));
        g.addOrReplaceChild("nariz_120", CubeListBuilder.create().texOffs(96, 259).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-95.59143814775476F, -22.56703125F, 5.180794314886828F, 2.7849556736710634F, 0.1623281502153036F, -0.9788205412833269F));
        g.addOrReplaceChild("nariz_121", CubeListBuilder.create().texOffs(882, 251).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-94.05511375939291F, -24.516093750000003F, 4.955759904646559F, 2.9220016295186957F, 0.1418380615211403F, -0.870394517313343F));
        g.addOrReplaceChild("nariz_122", CubeListBuilder.create().texOffs(908, 251).addBox(-3.0F, -1.0F, -3.5F, 6.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-92.39323021254128F, -26.465156250000003F, 4.681838979722389F, 3.028045946234456F, 0.10656096033060113F, -0.8681297703425894F));
        g.addOrReplaceChild("nariz_123", CubeListBuilder.create().texOffs(144, 295).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-90.71208176525579F, -28.41421875F, 4.300982046105805F, 3.107951784975F, 0.10324659999099543F, -0.8465527855419119F));
        g.addOrReplaceChild("nariz_124", CubeListBuilder.create().texOffs(168, 295).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-88.93432264446963F, -30.363281249999996F, 3.817426698230851F, 3.1413882294194635F, 0.09292465008661642F, -0.8141357714462659F));
        g.addOrReplaceChild("nariz_125", CubeListBuilder.create().texOffs(612, 295).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-87.09389756944445F, -32.31234375F, 3.3294549632634665F, 3.141592653589793F, 0.08722794095830771F, -0.8139618212362096F));
        g.addOrReplaceChild("nariz_126", CubeListBuilder.create().texOffs(960, 295).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-85.21878472222224F, -34.26140625F, 2.880685528775507F, 3.141592653589793F, 0.07726623754781198F, -0.7956655191275965F));
        g.addOrReplaceChild("nariz_127", CubeListBuilder.create().texOffs(908, 302).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-83.28953125F, -36.210468750000004F, 2.1965718634124425F, -3.141592653589793F, 0.16484758754993445F, -0.78539816339745F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("nariz_128", CubeListBuilder.create().texOffs(848, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-94.42988072042897F, -6.97453125F, 7.7157404257039985F, 2.038991307890236F, -0.019473096548650492F, -1.5806428767646679F));
        g.addOrReplaceChild("nariz_129", CubeListBuilder.create().texOffs(872, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-94.50562432641524F, -8.92359375F, 7.725039899128856F, 2.0359537850906224F, -0.01935706841155304F, -1.5805105091867377F));
        g.addOrReplaceChild("nariz_130", CubeListBuilder.create().texOffs(504, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-94.58128418492116F, -10.87265625F, 7.734242119563697F, 2.0329525972294675F, -0.019241937745538455F, -1.5803805671163826F));
        g.addOrReplaceChild("nariz_131", CubeListBuilder.create().texOffs(530, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-94.65686215933462F, -12.82171875F, 7.743348329567448F, 2.0299871492755193F, -0.019127706171397755F, -1.5802529973777608F));
        g.addOrReplaceChild("nariz_132", CubeListBuilder.create().texOffs(556, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-94.59703462895375F, -14.770781249999999F, 7.73608608086858F, 2.032855639592186F, 0.0495714245838832F, -1.5461240710861377F));
        g.addOrReplaceChild("nariz_133", CubeListBuilder.create().texOffs(896, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-94.38568319250795F, -16.719843750000003F, 7.710185027337312F, 2.041559521115643F, 0.058541914812140654F, -1.5410286119954182F));
        g.addOrReplaceChild("nariz_134", CubeListBuilder.create().texOffs(920, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-94.15776861778912F, -18.66890625F, 7.681510668951345F, 2.053084374147228F, 0.03725613223699169F, -1.4969464428863801F));
        g.addOrReplaceChild("nariz_135", CubeListBuilder.create().texOffs(944, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-93.92901678721888F, -20.61796875F, 7.651908161597795F, 2.06290991452617F, 0.03803796061341481F, -1.4960656269121362F));
        g.addOrReplaceChild("nariz_136", CubeListBuilder.create().texOffs(26, 81).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-93.30102261794585F, -22.56703125F, 7.564139129259377F, 2.1469531628827565F, 0.17136199069766803F, -1.2455901657773305F));
        g.addOrReplaceChild("nariz_137", CubeListBuilder.create().texOffs(120, 259).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-92.16110619699315F, -24.516093750000003F, 7.390266903160873F, 2.2363846151702464F, 0.2178752914254847F, -1.1632388610342939F));
        g.addOrReplaceChild("nariz_138", CubeListBuilder.create().texOffs(144, 259).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-90.89894171743336F, -26.465156250000003F, 7.133893121465901F, 2.3235905966191877F, 0.25708906206921806F, -1.1245406077331361F));
        g.addOrReplaceChild("nariz_139", CubeListBuilder.create().texOffs(370, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-89.56761552843376F, -28.41421875F, 6.670047341116599F, 2.4328538281253476F, 0.3518048690397745F, -1.037816047305081F));
        g.addOrReplaceChild("nariz_140", CubeListBuilder.create().texOffs(192, 295).addBox(-3.0F, -1.0F, -3.0F, 6.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-88.10365466908691F, -30.363281249999996F, 6.026016766999117F, 2.563347840008206F, 0.3493702708914614F, -0.9605154133842374F));
        g.addOrReplaceChild("nariz_141", CubeListBuilder.create().texOffs(634, 295).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-86.55010052814943F, -32.31234375F, 5.362722963759905F, 2.728571673482245F, 0.2973608757291233F, -0.9111448373658236F));
        g.addOrReplaceChild("nariz_142", CubeListBuilder.create().texOffs(980, 295).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.92297230741772F, -34.26140625F, 4.724078354292313F, 2.899404634287548F, 0.22678648464488552F, -0.855768422712725F));
        g.addOrReplaceChild("nariz_143", CubeListBuilder.create().texOffs(794, 302).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-83.18710657000578F, -36.210468750000004F, 3.6437030699536392F, 3.0264758004543113F, 0.5270349792578066F, -0.8284662002541207F));
        g.addOrReplaceChild("nariz_144", CubeListBuilder.create().texOffs(968, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.87848622887782F, -6.97453125F, 9.511243161217141F, 2.038944352615727F, -0.013910546084868688F, -1.5778296881058387F));
        g.addOrReplaceChild("nariz_145", CubeListBuilder.create().texOffs(992, 81).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.93258880458232F, -8.92359375F, 9.517885642234896F, 2.0359077370093113F, -0.013827642807638997F, -1.5777351354060056F));
        g.addOrReplaceChild("nariz_146", CubeListBuilder.create().texOffs(582, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-90.98663156065797F, -10.87265625F, 9.52445865683121F, 2.0329074352870866F, -0.013745381273697134F, -1.5776423154086119F));
        g.addOrReplaceChild("nariz_147", CubeListBuilder.create().texOffs(608, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-91.04061582809618F, -12.82171875F, 9.530963092548175F, 2.0299428529537873F, -0.013663762619923686F, -1.5775511901213253F));
        g.addOrReplaceChild("nariz_148", CubeListBuilder.create().texOffs(634, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-90.99788187782411F, -14.770781249999999F, 9.525775772048984F, 2.0325562070637235F, 0.035427645566811F, -1.553171535474226F));
        g.addOrReplaceChild("nariz_149", CubeListBuilder.create().texOffs(0, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.84691656607711F, -16.719843750000003F, 9.50727501952665F, 2.0411329255581876F, 0.04184812740487283F, -1.5495305969973223F));
        g.addOrReplaceChild("nariz_150", CubeListBuilder.create().texOffs(24, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.68412044127795F, -18.66890625F, 9.486793334965245F, 2.050557867632409F, 0.042607035819450675F, -1.5486378881331995F));
        g.addOrReplaceChild("nariz_151", CubeListBuilder.create().texOffs(48, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.52072627658492F, -20.61796875F, 9.465648686855566F, 2.061408673091007F, 0.027195304173521163F, -1.517334393504284F));
        g.addOrReplaceChild("nariz_152", CubeListBuilder.create().texOffs(52, 81).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-90.07215901281847F, -22.56703125F, 9.402956520899554F, 2.1198296465013358F, 0.12491177578673353F, -1.3324131722011276F));
        g.addOrReplaceChild("nariz_153", CubeListBuilder.create().texOffs(168, 259).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-89.25793299785225F, -24.516093750000003F, 9.278762073686337F, 2.1963845194009597F, 0.16135817343946565F, -1.2691806954864406F));
        g.addOrReplaceChild("nariz_154", CubeListBuilder.create().texOffs(192, 259).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-88.35638694102383F, -26.465156250000003F, 9.067086807540576F, 2.2821809886958273F, 0.2142181798354552F, -1.2333692125248963F));
        g.addOrReplaceChild("nariz_155", CubeListBuilder.create().texOffs(392, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-87.40543966316697F, -28.41421875F, 8.580654756641726F, 2.3891395853216753F, 0.352955881871794F, -1.1439056464327613F));
        g.addOrReplaceChild("nariz_156", CubeListBuilder.create().texOffs(414, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-86.39445239056582F, -30.363281249999996F, 7.880400088853774F, 2.4714779780845006F, 0.3443925477917246F, -1.1136795888926574F));
        g.addOrReplaceChild("nariz_157", CubeListBuilder.create().texOffs(716, 295).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-85.33858623904533F, -32.31234375F, 7.169360251882858F, 2.5829560008686325F, 0.32548742065238956F, -1.0732238942749888F));
        g.addOrReplaceChild("nariz_158", CubeListBuilder.create().texOffs(36, 302).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-84.18929991051101F, -34.26140625F, 6.455929024423492F, 2.7435706369238573F, 0.28594449675772554F, -1.0070352578881634F));
        g.addOrReplaceChild("nariz_159", CubeListBuilder.create().texOffs(814, 302).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-82.90390157500963F, -36.210468750000004F, 5.060860716585672F, 2.8976806148556054F, 0.7191586936347124F, -0.9630165964629928F));
        g.addOrReplaceChild("nariz_160", CubeListBuilder.create().texOffs(72, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-87.32709173732671F, -6.97453125F, 11.306745896730286F, 2.038913044818339F, -0.008346804326553194F, -1.5750163881165897F));
        g.addOrReplaceChild("nariz_161", CubeListBuilder.create().texOffs(96, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-87.3595532827494F, -8.92359375F, 11.310731385340938F, 2.0358770341670045F, -0.008297051941496691F, -1.574959654724599F));
        g.addOrReplaceChild("nariz_162", CubeListBuilder.create().texOffs(660, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-87.39197893639479F, -10.87265625F, 11.314675194098726F, 2.0328773233569195F, -0.00824768487959105F, -1.5749039610328923F));
        g.addOrReplaceChild("nariz_163", CubeListBuilder.create().texOffs(686, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-87.42436949685771F, -12.82171875F, 11.318577855528904F, 2.029913318250461F, -0.008198703814627352F, -1.5748492842422357F));
        g.addOrReplaceChild("nariz_164", CubeListBuilder.create().texOffs(712, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-87.39872912669448F, -14.770781249999999F, 11.31546546322939F, 2.0323564107795713F, 0.021264393273179274F, -1.5602207511820807F));
        g.addOrReplaceChild("nariz_165", CubeListBuilder.create().texOffs(120, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-87.30814993964627F, -16.719843750000003F, 11.30436501171599F, 2.0408481750503804F, 0.025121893902681235F, -1.558035657834352F));
        g.addOrReplaceChild("nariz_166", CubeListBuilder.create().texOffs(144, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-87.21047226476676F, -18.66890625F, 11.292076000979147F, 2.050255785297979F, 0.025578141940364167F, -1.557499870868709F));
        g.addOrReplaceChild("nariz_167", CubeListBuilder.create().texOffs(168, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-87.11243576595095F, -20.61796875F, 11.27938921211334F, 2.060403318521115F, 0.016327336430997506F, -1.5386858013398919F));
        g.addOrReplaceChild("nariz_168", CubeListBuilder.create().texOffs(78, 81).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-86.84329540769107F, -22.56703125F, 11.241773912539733F, 2.100174303867195F, 0.07600191707927596F, -1.4250393181083765F));
        g.addOrReplaceChild("nariz_169", CubeListBuilder.create().texOffs(216, 259).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-86.35475979871134F, -24.516093750000003F, 11.167257244211802F, 2.166105589564328F, 0.09933075547890352F, -1.3849541573748303F));
        g.addOrReplaceChild("nariz_170", CubeListBuilder.create().texOffs(240, 259).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-85.8138321646143F, -26.465156250000003F, 11.000280493615254F, 2.2483005471926303F, 0.16560989160099915F, -1.3530546032021837F));
        g.addOrReplaceChild("nariz_171", CubeListBuilder.create().texOffs(436, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-85.24326379790018F, -28.41421875F, 10.491262172166852F, 2.3461678909064894F, 0.3513486037719457F, -1.262765729649309F));
        g.addOrReplaceChild("nariz_172", CubeListBuilder.create().texOffs(458, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-84.63667143433949F, -30.363281249999996F, 9.71673437149408F, 2.427571467958401F, 0.34038394937371746F, -1.2425270039456953F));
        g.addOrReplaceChild("nariz_173", CubeListBuilder.create().texOffs(736, 295).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-84.0031517434272F, -32.31234375F, 8.935735469311531F, 2.5394028200402223F, 0.3208079981382704F, -1.2166538964723743F));
        g.addOrReplaceChild("nariz_174", CubeListBuilder.create().texOffs(54, 302).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-83.31357994630662F, -34.26140625F, 8.153301732835914F, 2.7030297429345445F, 0.28566833445596934F, -1.1760251368075447F));
        g.addOrReplaceChild("nariz_175", CubeListBuilder.create().texOffs(834, 302).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-82.54234094500578F, -36.210468750000004F, 6.465294839042308F, 2.817904277678776F, 0.8876246712935251F, -1.1754048063042737F));
        g.addOrReplaceChild("nariz_176", CubeListBuilder.create().texOffs(192, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.77569724577556F, -6.97453125F, 13.102248632243429F, 2.0388973896350358F, -0.0027823475660663003F, -1.5722030213248606F));
        g.addOrReplaceChild("nariz_177", CubeListBuilder.create().texOffs(216, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.78651776091647F, -8.92359375F, 13.10357712844698F, 2.035861681509141F, -0.002765761700846905F, -1.5721841098988345F));
        g.addOrReplaceChild("nariz_178", CubeListBuilder.create().texOffs(738, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-83.79732631213159F, -10.87265625F, 13.104891731366243F, 2.0328622662009974F, -0.0027493043228907187F, -1.5721655450527074F));
        g.addOrReplaceChild("nariz_179", CubeListBuilder.create().texOffs(764, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-83.80812316561924F, -12.82171875F, 13.106192618509635F, 2.0298985497518953F, -0.0027329756554067526F, -1.5721473191860964F));
        g.addOrReplaceChild("nariz_180", CubeListBuilder.create().texOffs(790, 71).addBox(-2.0F, -1.0F, -4.5F, 4.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-83.79957637556483F, -14.770781249999999F, 13.105155154409797F, 2.032256460180723F, 0.007089433269784228F, -1.5672710180996536F));
        g.addOrReplaceChild("nariz_181", CubeListBuilder.create().texOffs(240, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.76938331321543F, -16.719843750000003F, 13.101455003905329F, 2.040705693535119F, 0.00837613700657466F, -1.5665425652409233F));
        g.addOrReplaceChild("nariz_182", CubeListBuilder.create().texOffs(264, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.73682408825559F, -18.66890625F, 13.097358666993049F, 2.050104624855384F, 0.008528370520765074F, -1.56636394263231F));
        g.addOrReplaceChild("nariz_183", CubeListBuilder.create().texOffs(288, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.70414525531699F, -20.61796875F, 13.093129737371113F, 2.059899272882713F, 0.005444139902582505F, -1.560087235102793F));
        g.addOrReplaceChild("nariz_184", CubeListBuilder.create().texOffs(312, 90).addBox(-2.0F, -1.0F, -4.0F, 4.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-83.6144318025637F, -22.56703125F, 13.080591304179912F, 2.0898059777623366F, 0.025515169575837056F, -1.5217214514959017F));
        g.addOrReplaceChild("nariz_185", CubeListBuilder.create().texOffs(660, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-83.45158659957045F, -24.516093750000003F, 13.055752414737269F, 2.1496451853318974F, 0.033554824085952464F, -1.5079507087901964F));
        g.addOrReplaceChild("nariz_186", CubeListBuilder.create().texOffs(682, 259).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-83.27127738820477F, -26.465156250000003F, 12.933474179689933F, 2.2261834347492115F, 0.11190126339550498F, -1.4807280955628932F));
        g.addOrReplaceChild("nariz_187", CubeListBuilder.create().texOffs(480, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-83.0810879326334F, -28.41421875F, 12.401869587691982F, 2.3074196128978874F, 0.34402114035361014F, -1.3907799248638093F));
        g.addOrReplaceChild("nariz_188", CubeListBuilder.create().texOffs(502, 295).addBox(-2.5F, -1.0F, -3.0F, 5.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-82.87889047811316F, -30.363281249999996F, 11.553068654134389F, 2.388996493159141F, 0.32905394040990754F, -1.3827882859701188F));
        g.addOrReplaceChild("nariz_189", CubeListBuilder.create().texOffs(756, 295).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-82.66771724780907F, -32.31234375F, 10.702110686740209F, 2.5022601772538065F, 0.3067266413883458F, -1.3757629732065269F));
        g.addOrReplaceChild("nariz_190", CubeListBuilder.create().texOffs(72, 302).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-82.4378599821022F, -34.26140625F, 9.850674441248335F, 2.6695494473654158F, 0.2734057673991427F, -1.3711627660361494F));
        g.addOrReplaceChild("nariz_191", CubeListBuilder.create().texOffs(712, 302).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-82.18078031500193F, -36.210468750000004F, 7.869728961498945F, 2.7173689067967324F, 1.0067757049089927F, -1.4325598189163622F));
        g.addOrReplaceChild("faro4_0", CubeListBuilder.create().texOffs(306, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(284, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-96.25568218262502F, -22.42816890337166F, -5.738280215471892F, -0.9013447586428813F, 0.0F, 2.352838705940769F));
        g.addOrReplaceChild("faro4_1", CubeListBuilder.create().texOffs(330, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(308, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-96.25568218262502F, -22.42816890337166F, -5.738280215471892F, -0.9394863235555732F, 0.2397672160048644F, 2.038778136919323F));
        g.addOrReplaceChild("faro4_2", CubeListBuilder.create().texOffs(354, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(332, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-96.25568218262502F, -22.42816890337166F, -5.738280215471892F, -1.0606298011912416F, 0.45426210342420326F, 1.6878298933280718F));
        g.addOrReplaceChild("faro4_3", CubeListBuilder.create().texOffs(378, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(356, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-96.25568218262502F, -22.42816890337166F, -5.738280215471892F, -1.2767350725650874F, 0.6105510089292779F, 1.2680137264293567F));
        g.addOrReplaceChild("faro4_vidrio", CubeListBuilder.create().texOffs(172, 51).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-96.48462227739546F, -22.65557758435861F, -6.1460445160405905F, -0.9013447586428813F, 0.0F, 2.352838705940769F));
        g.addOrReplaceChild("faro_bajo4_0", CubeListBuilder.create().texOffs(402, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(380, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.17571028766643F, -13.094349988015454F, -5.733262548664847F, -1.1113387190451607F, 0.0F, 1.5089704797837928F));
        g.addOrReplaceChild("faro_bajo4_1", CubeListBuilder.create().texOffs(426, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(404, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.17571028766643F, -13.094349988015454F, -5.733262548664847F, -1.14204462223052F, 0.17053089951095873F, 1.1534855661362058F));
        g.addOrReplaceChild("faro_bajo4_2", CubeListBuilder.create().texOffs(450, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(428, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.17571028766643F, -13.094349988015454F, -5.733262548664847F, -1.234248338252645F, 0.3189556007097206F, 0.7782071349355489F));
        g.addOrReplaceChild("faro_bajo4_3", CubeListBuilder.create().texOffs(474, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(452, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.17571028766643F, -13.094349988015454F, -5.733262548664847F, -1.3836699268003443F, 0.42213119126110826F, 0.3710783072856088F));
        g.addOrReplaceChild("faro_bajo4_vidrio", CubeListBuilder.create().texOffs(846, 71).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-98.40586995622442F, -13.080102012943312F, -6.199334991720239F, -1.1113387190451607F, 0.0F, 1.5089704797837928F));
        g.addOrReplaceChild("faro16_0", CubeListBuilder.create().texOffs(498, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(476, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-96.25568218262504F, -22.428168903371663F, 5.738280215471891F, 0.9013447586428819F, 0.0F, 2.352838705940727F));
        g.addOrReplaceChild("faro16_1", CubeListBuilder.create().texOffs(522, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(500, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-96.25568218262504F, -22.428168903371663F, 5.738280215471891F, 0.9394863235555737F, 0.2397672160048643F, 2.666899274962173F));
        g.addOrReplaceChild("faro16_2", CubeListBuilder.create().texOffs(546, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(524, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-96.25568218262504F, -22.428168903371663F, 5.738280215471891F, 1.060629801191242F, 0.4542621034242029F, 3.0178475185534244F));
        g.addOrReplaceChild("faro16_3", CubeListBuilder.create().texOffs(570, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(548, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-96.25568218262504F, -22.428168903371663F, 5.738280215471891F, 1.2767350725650877F, 0.6105510089292775F, -2.845521621727447F));
        g.addOrReplaceChild("faro16_vidrio", CubeListBuilder.create().texOffs(216, 51).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-96.48462227739547F, -22.655577584358607F, 6.146044516040589F, 0.9013447586428819F, 0.0F, 2.352838705940727F));
        g.addOrReplaceChild("faro_bajo16_0", CubeListBuilder.create().texOffs(594, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(572, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.17571028766643F, -13.094349988015455F, 5.733262548664847F, 1.11133871904516F, 0.0F, 1.5089704797837644F));
        g.addOrReplaceChild("faro_bajo16_1", CubeListBuilder.create().texOffs(618, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(596, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.17571028766643F, -13.094349988015455F, 5.733262548664847F, 1.1420446222305194F, 0.170530899510959F, 1.8644553934313512F));
        g.addOrReplaceChild("faro_bajo16_2", CubeListBuilder.create().texOffs(642, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(620, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.17571028766643F, -13.094349988015455F, 5.733262548664847F, 1.2342483382526444F, 0.3189556007097211F, 2.239733824632008F));
        g.addOrReplaceChild("faro_bajo16_3", CubeListBuilder.create().texOffs(666, 302).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(644, 51).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-98.17571028766643F, -13.094349988015455F, 5.733262548664847F, 1.3836699268003438F, 0.422131191261109F, 2.6468626522819485F));
        g.addOrReplaceChild("faro_bajo16_vidrio", CubeListBuilder.create().texOffs(878, 71).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-98.40586995622442F, -13.080102012943307F, 6.199334991720239F, 1.11133871904516F, 0.0F, 1.5089704797837644F));
        g.addOrReplaceChild("ventilador40_0", CubeListBuilder.create().texOffs(934, 302).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(698, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(40.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador40_1", CubeListBuilder.create().texOffs(958, 302).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(722, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(40.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador40_2", CubeListBuilder.create().texOffs(982, 302).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(746, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(40.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador40_3", CubeListBuilder.create().texOffs(0, 307).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(770, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(40.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador58_0", CubeListBuilder.create().texOffs(24, 307).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(794, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(58.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador58_1", CubeListBuilder.create().texOffs(48, 307).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(818, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(58.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("ventilador58_2", CubeListBuilder.create().texOffs(72, 307).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(842, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(58.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador58_3", CubeListBuilder.create().texOffs(96, 307).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(866, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(58.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador76_0", CubeListBuilder.create().texOffs(120, 307).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(890, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(76.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador76_1", CubeListBuilder.create().texOffs(144, 307).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(914, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(76.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador76_2", CubeListBuilder.create().texOffs(168, 307).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(938, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(76.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador76_3", CubeListBuilder.create().texOffs(192, 307).addBox(-5.0F, -38.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(962, 51).addBox(-1.0F, -38.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(76.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("bocina_0", CubeListBuilder.create().texOffs(88, 51).addBox(-60.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(24, 51).addBox(-60.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -38.5F, 0.0F));
        g.addOrReplaceChild("bocina_1", CubeListBuilder.create().texOffs(106, 51).addBox(-60.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(56, 51).addBox(-60.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -38.5F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_forro", CubeListBuilder.create().texOffs(728, 0).addBox(-82.0F, -35.0F, 9.0F, 26.0F, 22.0F, 1.0F).texOffs(782, 0).addBox(-82.0F, -35.0F, -10.0F, 26.0F, 22.0F, 1.0F).texOffs(54, 0).addBox(-57.0F, -35.0F, -9.0F, 1.0F, 22.0F, 18.0F).texOffs(836, 0).addBox(-82.0F, -13.0F, -10.0F, 26.0F, 1.0F, 20.0F).texOffs(928, 0).addBox(-82.0F, -36.0F, -10.0F, 26.0F, 1.0F, 20.0F).texOffs(92, 0).addBox(-82.0F, -35.0F, -9.0F, 1.0F, 22.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_pupitre", CubeListBuilder.create().texOffs(0, 51).addBox(-81.0F, -25.0F, 1.0F, 4.0F, 12.0F, 8.0F).texOffs(336, 90).addBox(-81.0F, -27.0F, 1.5F, 1.0F, 2.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(124, 51).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-79.4F, -26.0F, 5.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(216, 307).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-79.28F, -26.0F, 5.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro0", CubeListBuilder.create().texOffs(986, 51).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-79.4F, -26.0F, 1.4000000000000004F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro0_aguja", CubeListBuilder.create().texOffs(220, 307).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-79.28F, -26.0F, 1.4000000000000004F, 0.4F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro1", CubeListBuilder.create().texOffs(0, 71).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-79.4F, -26.0F, 8.6F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro1_aguja", CubeListBuilder.create().texOffs(224, 307).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-79.28F, -26.0F, 8.6F, 1.1F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_luces", CubeListBuilder.create().texOffs(228, 307).addBox(-79.0F, -26.0F, 1.5F, 1.0F, 1.0F, 1.0F).texOffs(232, 307).addBox(-79.0F, -26.0F, 2.7F, 1.0F, 1.0F, 1.0F).texOffs(236, 307).addBox(-79.0F, -26.0F, 3.9000000000000004F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(298, 302).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F).texOffs(926, 302).addBox(-1.0F, -6.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-79.0F, -25.0F, 7.5F, 0.0F, 0.0F, 0.15F));
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(302, 302).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(-79.0F, -25.5F, 2.5F, 0.0F, 0.0F, -2.4668517113662407F));
        g.addOrReplaceChild("cab_freno_perilla", CubeListBuilder.create().texOffs(240, 307).addBox(-77.5F, -28.5F, 2.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(90, 302).addBox(-73.0F, -15.269736783722799F, 4.0F, 4.0F, 1.0F, 4.0F).texOffs(816, 71).addBox(-69.0F, -21.2697367837228F, 4.0F, 1.0F, 6.0F, 4.0F).texOffs(244, 307).addBox(-71.5F, -14.269736783722799F, 5.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(106, 302).addBox(-73.0F, -15.269736783722799F, -8.0F, 4.0F, 1.0F, 4.0F).texOffs(826, 71).addBox(-69.0F, -21.2697367837228F, -8.0F, 1.0F, 6.0F, 4.0F).texOffs(248, 307).addBox(-71.5F, -14.269736783722799F, -6.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento2", CubeListBuilder.create().texOffs(122, 302).addBox(-66.0F, -15.269736783722799F, -2.0F, 4.0F, 1.0F, 4.0F).texOffs(836, 71).addBox(-62.0F, -21.2697367837228F, -2.0F, 1.0F, 6.0F, 4.0F).texOffs(252, 307).addBox(-64.5F, -14.269736783722799F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "caja_0", 0.5F, 1.0F, 0.433421093496242F);
        escalar(g0, "caja_1", 0.5F, 1.0F, 0.433421093496242F);
        escalar(g0, "caja_2", 0.5F, 1.0F, 0.4334210934962423F);
        escalar(g0, "caja_3", 0.5F, 1.0F, 0.4334210934962418F);
        escalar(g0, "caja_4", 0.5F, 1.0F, 0.4334210934962423F);
        escalar(g0, "caja_5", 0.5F, 1.0F, 0.49656724160329563F);
        escalar(g0, "caja_6", 0.5F, 1.0F, 0.43342109349624186F);
        escalar(g0, "caja_7", 0.5F, 1.0F, 0.43342109349624236F);
        escalar(g0, "caja_8", 0.5F, 1.0F, 0.47451900025009913F);
        escalar(g0, "caja_9", 0.5F, 1.0F, 0.4334210934962419F);
        escalar(g0, "caja_10", 0.5F, 1.0F, 0.43286596559007756F);
        escalar(g0, "caja_11", 0.5F, 1.0F, 0.4334210934962428F);
        escalar(g0, "caja_12", 0.5F, 1.0F, 0.4334210934962418F);
        escalar(g0, "caja_13", 0.5F, 1.0F, 0.43286596559007784F);
        escalar(g0, "caja_14", 0.5F, 1.0F, 0.43342109349624286F);
        escalar(g0, "caja_15", 0.5F, 1.0F, 0.4745190002500988F);
        escalar(g0, "caja_16", 0.5F, 1.0F, 0.4334210934962414F);
        escalar(g0, "caja_17", 0.5F, 1.0F, 0.43342109349624297F);
        escalar(g0, "caja_18", 0.5F, 1.0F, 0.49656724160329513F);
        escalar(g0, "caja_19", 0.5F, 1.0F, 0.4334210934962418F);
        escalar(g0, "caja_20", 0.5F, 1.0F, 0.4334210934962428F);
        escalar(g0, "caja_21", 0.5F, 1.0F, 0.43342109349624075F);
        escalar(g0, "caja_22", 0.5F, 1.0F, 0.4334210934962418F);
        escalar(g0, "caja_23", 0.5F, 1.0F, 0.4334210934962438F);
        escalar(g0, "nariz_0", 0.49978088801730486F, 1.0F, 0.5036851376369346F);
        escalar(g0, "nariz_1", 0.4997808496703777F, 1.0F, 0.505951709063675F);
        escalar(g0, "nariz_2", 0.4997808122182324F, 1.0F, 0.4517526356347227F);
        escalar(g0, "nariz_3", 0.49978077563674117F, 1.0F, 0.453773417280934F);
        escalar(g0, "nariz_4", 0.49986679416946567F, 1.0F, 0.452176999858657F);
        escalar(g0, "nariz_5", 0.4999031647826321F, 1.0F, 0.5023714722414336F);
        escalar(g0, "nariz_6", 0.49990426557687084F, 1.0F, 0.4955995065021651F);
        escalar(g0, "nariz_7", 0.49990544860352654F, 1.0F, 0.48886116834730464F);
        escalar(g0, "nariz_8", 0.5025648299045883F, 1.0F, 0.47085727454179616F);
        escalar(g0, "nariz_9", 0.5039468452309643F, 1.0F, 0.5022143559135682F);
        escalar(g0, "nariz_10", 0.5069208734147431F, 1.0F, 0.46376881157374544F);
        escalar(g0, "nariz_11", 0.4388432643251134F, 1.0F, 0.48953674314292944F);
        escalar(g0, "nariz_12", 0.43929047841521723F, 1.0F, 0.43250880166618105F);
        escalar(g0, "nariz_13", 0.43986232112267204F, 1.0F, 0.4539273284351288F);
        escalar(g0, "nariz_14", 0.4409148847856443F, 1.0F, 0.4926142547959182F);
        escalar(g0, "nariz_15", 0.4680927613279964F, 1.0F, 0.5047937474249878F);
        escalar(g0, "nariz_16", 0.49984193435081087F, 1.0F, 0.5036851376369346F);
        escalar(g0, "nariz_17", 0.49984174264495596F, 1.0F, 0.5059517090636758F);
        escalar(g0, "nariz_18", 0.49984155541226905F, 1.0F, 0.4517526356347227F);
        escalar(g0, "nariz_19", 0.4998413725321341F, 1.0F, 0.45377341728093484F);
        escalar(g0, "nariz_20", 0.5002712192005956F, 1.0F, 0.45217699985865845F);
        escalar(g0, "nariz_21", 0.5004528590844373F, 1.0F, 0.5023714722414343F);
        escalar(g0, "nariz_22", 0.5004583555938924F, 1.0F, 0.49559950650216433F);
        escalar(g0, "nariz_23", 0.5004642626419217F, 1.0F, 0.48886116834730386F);
        escalar(g0, "nariz_24", 0.41086167487659664F, 1.0F, 0.4708572745417969F);
        escalar(g0, "nariz_25", 0.41621481883472156F, 1.0F, 0.502214355913569F);
        escalar(g0, "nariz_26", 0.4192697524509038F, 1.0F, 0.4637688115737455F);
        escalar(g0, "nariz_27", 0.44762243354702436F, 1.0F, 0.48953674314293044F);
        escalar(g0, "nariz_28", 0.44939335905750627F, 1.0F, 0.43250880166618194F);
        escalar(g0, "nariz_29", 0.4518690539991792F, 1.0F, 0.4539273284351288F);
        escalar(g0, "nariz_30", 0.45704571077011363F, 1.0F, 0.49261425479591736F);
        escalar(g0, "nariz_31", 0.4877081385975007F, 1.0F, 0.504793747424987F);
        escalar(g0, "nariz_32", 0.4999640040857405F, 1.0F, 0.5036851376369355F);
        escalar(g0, "nariz_33", 0.49996350577707344F, 1.0F, 0.5059517090636759F);
        escalar(g0, "nariz_34", 0.4999630190953834F, 1.0F, 0.45175263563472196F);
        escalar(g0, "nariz_35", 0.4999625437271695F, 1.0F, 0.45377341728093346F);
        escalar(g0, "nariz_36", 0.501079065795297F, 1.0F, 0.4521769998586571F);
        escalar(g0, "nariz_37", 0.5015503961926061F, 1.0F, 0.5023714722414337F);
        escalar(g0, "nariz_38", 0.5015646544742042F, 1.0F, 0.49559950650216517F);
        escalar(g0, "nariz_39", 0.5015799774301357F, 1.0F, 0.4888611683473054F);
        escalar(g0, "nariz_40", 0.427935498660079F, 1.0F, 0.47085727454179693F);
        escalar(g0, "nariz_41", 0.44117731947110406F, 1.0F, 0.502214355913569F);
        escalar(g0, "nariz_42", 0.4448964264302493F, 1.0F, 0.4637688115737454F);
        escalar(g0, "nariz_43", 0.47059268973459273F, 1.0F, 0.4895367431429285F);
        escalar(g0, "nariz_44", 0.47442417070157905F, 1.0F, 0.43250880166618105F);
        escalar(g0, "nariz_45", 0.4801125654029919F, 1.0F, 0.4539273284351296F);
        escalar(g0, "nariz_46", 0.4928543927078556F, 1.0F, 0.4926142547959191F);
        escalar(g0, "nariz_47", 0.46105839821545935F, 1.0F, 0.5047937474249876F);
        escalar(g0, "nariz_48", 0.5001470514009686F, 1.0F, 0.5036851376369346F);
        escalar(g0, "nariz_49", 0.5001460934753688F, 1.0F, 0.5059517090636741F);
        escalar(g0, "nariz_50", 0.5001451579000599F, 1.0F, 0.4517526356347219F);
        escalar(g0, "nariz_51", 0.5001442440724426F, 1.0F, 0.45377341728093484F);
        escalar(g0, "nariz_52", 0.502288339406161F, 1.0F, 0.4521769998586584F);
        escalar(g0, "nariz_53", 0.5031921040891788F, 1.0F, 0.5023714722414343F);
        escalar(g0, "nariz_54", 0.5032194316281634F, 1.0F, 0.49559950650216433F);
        escalar(g0, "nariz_55", 0.5032487989225041F, 1.0F, 0.48886116834730386F);
        escalar(g0, "nariz_56", 0.45233255678082196F, 1.0F, 0.47085727454179693F);
        escalar(g0, "nariz_57", 0.4761748031364963F, 1.0F, 0.502214355913569F);
        escalar(g0, "nariz_58", 0.4805156457334059F, 1.0F, 0.46376881157374544F);
        escalar(g0, "nariz_59", 0.5058327594061323F, 1.0F, 0.48953674314293033F);
        escalar(g0, "nariz_60", 0.4387437352736497F, 1.0F, 0.4271738056143451F);
        escalar(g0, "nariz_61", 0.44117012485507373F, 1.0F, 0.4409281361229622F);
        escalar(g0, "nariz_62", 0.45108521716965866F, 1.0F, 0.4807926647940956F);
        escalar(g0, "nariz_63", 0.4467166144669678F, 1.0F, 0.4998787638944468F);
        escalar(g0, "nariz_64", 0.5004956065717188F, 1.0F, 0.491587813341471F);
        escalar(g0, "nariz_65", 0.5004950257727564F, 1.0F, 0.4934694436274511F);
        escalar(g0, "nariz_66", 0.5004944587480836F, 1.0F, 0.4953894658410786F);
        escalar(g0, "nariz_67", 0.50049390512237F, 1.0F, 0.4973480337851817F);
        escalar(g0, "nariz_68", 0.5046006314861236F, 1.0F, 0.49582308280593157F);
        escalar(g0, "nariz_69", 0.5062955764085739F, 1.0F, 0.49054868920805916F);
        escalar(g0, "nariz_70", 0.5063121483933055F, 1.0F, 0.48519762492775564F);
        escalar(g0, "nariz_71", 0.5063299777175924F, 1.0F, 0.48018280531364077F);
        escalar(g0, "nariz_72", 0.4925057506402496F, 1.0F, 0.46888178226510585F);
        escalar(g0, "nariz_73", 0.439993794996921F, 1.0F, 0.45262085891308096F);
        escalar(g0, "nariz_74", 0.4372721972103288F, 1.0F, 0.43715171642770695F);
        escalar(g0, "nariz_75", 0.4487193396451905F, 1.0F, 0.48048539144473007F);
        escalar(g0, "nariz_76", 0.46371221591011996F, 1.0F, 0.4324579939254865F);
        escalar(g0, "nariz_77", 0.4627757031445798F, 1.0F, 0.4539273284351289F);
        escalar(g0, "nariz_78", 0.469162135762703F, 1.0F, 0.4926142547959181F);
        escalar(g0, "nariz_79", 0.49641050736582315F, 1.0F, 0.5047937474249874F);
        escalar(g0, "nariz_80", 0.5007268944725801F, 1.0F, 0.503685137636935F);
        escalar(g0, "nariz_81", 0.500726926649478F, 1.0F, 0.5059517090636757F);
        escalar(g0, "nariz_82", 0.5007269582989659F, 1.0F, 0.4517526356347227F);
        escalar(g0, "nariz_83", 0.5007269894312992F, 1.0F, 0.45377341728093445F);
        escalar(g0, "nariz_84", 0.5061385103658564F, 1.0F, 0.4521769998586579F);
        escalar(g0, "nariz_85", 0.5083497895858647F, 1.0F, 0.5023714722414342F);
        escalar(g0, "nariz_86", 0.5083488965979931F, 1.0F, 0.4955995065021649F);
        escalar(g0, "nariz_87", 0.5083479575624974F, 1.0F, 0.48886116834730464F);
        escalar(g0, "nariz_88", 0.4314200422260528F, 1.0F, 0.4708572745417968F);
        escalar(g0, "nariz_89", 0.46562497375982376F, 1.0F, 0.5022143559135689F);
        escalar(g0, "nariz_90", 0.4562815796369522F, 1.0F, 0.46376881157374567F);
        escalar(g0, "nariz_91", 0.4570327313576244F, 1.0F, 0.4895367431429299F);
        escalar(g0, "nariz_92", 0.45689897980952043F, 1.0F, 0.4325088016661818F);
        escalar(g0, "nariz_93", 0.45668986285188523F, 1.0F, 0.45392732843512923F);
        escalar(g0, "nariz_94", 0.4643095187246807F, 1.0F, 0.4926142547959183F);
        escalar(g0, "nariz_95", 0.47363275108455366F, 1.0F, 0.5047937474249878F);
        escalar(g0, "nariz_96", 0.5007268944725801F, 1.0F, 0.5036851376369343F);
        escalar(g0, "nariz_97", 0.500726926649478F, 1.0F, 0.5059517090636748F);
        escalar(g0, "nariz_98", 0.5007269582989659F, 1.0F, 0.4517526356347219F);
        escalar(g0, "nariz_99", 0.5007269894312992F, 1.0F, 0.4537734172809336F);
        escalar(g0, "nariz_100", 0.5061385103658564F, 1.0F, 0.4521769998586571F);
        escalar(g0, "nariz_101", 0.5083497895858647F, 1.0F, 0.5023714722414335F);
        escalar(g0, "nariz_102", 0.5083488965979931F, 1.0F, 0.49559950650216444F);
        escalar(g0, "nariz_103", 0.5083479575624974F, 1.0F, 0.488861168347304F);
        escalar(g0, "nariz_104", 0.4314200422260528F, 1.0F, 0.47085727454179616F);
        escalar(g0, "nariz_105", 0.46562497375982376F, 1.0F, 0.5022143559135683F);
        escalar(g0, "nariz_106", 0.4562815796369523F, 1.0F, 0.46376881157374517F);
        escalar(g0, "nariz_107", 0.4570327313576244F, 1.0F, 0.48953674314292916F);
        escalar(g0, "nariz_108", 0.45689897980952043F, 1.0F, 0.43250880166618105F);
        escalar(g0, "nariz_109", 0.45668986285188523F, 1.0F, 0.45392732843512873F);
        escalar(g0, "nariz_110", 0.4643095187246807F, 1.0F, 0.49261425479591764F);
        escalar(g0, "nariz_111", 0.47363275108455366F, 1.0F, 0.504793747424987F);
        escalar(g0, "nariz_112", 0.5004956065717188F, 1.0F, 0.4915878133414718F);
        escalar(g0, "nariz_113", 0.5004950257727564F, 1.0F, 0.4934694436274513F);
        escalar(g0, "nariz_114", 0.5004944587480835F, 1.0F, 0.4953894658410789F);
        escalar(g0, "nariz_115", 0.50049390512237F, 1.0F, 0.4973480337851827F);
        escalar(g0, "nariz_116", 0.5046006314861236F, 1.0F, 0.49582308280593246F);
        escalar(g0, "nariz_117", 0.5062955764085739F, 1.0F, 0.49054868920805983F);
        escalar(g0, "nariz_118", 0.5063121483933055F, 1.0F, 0.4851976249277562F);
        escalar(g0, "nariz_119", 0.5063299777175924F, 1.0F, 0.48018280531364155F);
        escalar(g0, "nariz_120", 0.4925057506402496F, 1.0F, 0.4688817822651066F);
        escalar(g0, "nariz_121", 0.4399937949969209F, 1.0F, 0.45262085891308146F);
        escalar(g0, "nariz_122", 0.4372721972103289F, 1.0F, 0.4371517164277075F);
        escalar(g0, "nariz_123", 0.44871933964519045F, 1.0F, 0.48048539144473074F);
        escalar(g0, "nariz_124", 0.46371221591011996F, 1.0F, 0.43245799392548717F);
        escalar(g0, "nariz_125", 0.4627757031445798F, 1.0F, 0.45392732843512923F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "nariz_126", 0.469162135762703F, 1.0F, 0.4926142547959183F);
        escalar(g0, "nariz_127", 0.49641050736582315F, 1.0F, 0.5047937474249877F);
        escalar(g0, "nariz_128", 0.5001470514009686F, 1.0F, 0.5036851376369346F);
        escalar(g0, "nariz_129", 0.5001460934753689F, 1.0F, 0.5059517090636751F);
        escalar(g0, "nariz_130", 0.5001451579000598F, 1.0F, 0.4517526356347228F);
        escalar(g0, "nariz_131", 0.5001442440724426F, 1.0F, 0.45377341728093484F);
        escalar(g0, "nariz_132", 0.5022883394061608F, 1.0F, 0.45217699985865767F);
        escalar(g0, "nariz_133", 0.5031921040891789F, 1.0F, 0.5023714722414336F);
        escalar(g0, "nariz_134", 0.5032194316281634F, 1.0F, 0.4955995065021643F);
        escalar(g0, "nariz_135", 0.5032487989225041F, 1.0F, 0.48886116834730375F);
        escalar(g0, "nariz_136", 0.45233255678082146F, 1.0F, 0.4708572745417962F);
        escalar(g0, "nariz_137", 0.4761748031364969F, 1.0F, 0.5022143559135682F);
        escalar(g0, "nariz_138", 0.48051564573340605F, 1.0F, 0.46376881157374544F);
        escalar(g0, "nariz_139", 0.5058327594061321F, 1.0F, 0.48953674314293033F);
        escalar(g0, "nariz_140", 0.43874373527364985F, 1.0F, 0.427173805614345F);
        escalar(g0, "nariz_141", 0.4411701248550737F, 1.0F, 0.4409281361229624F);
        escalar(g0, "nariz_142", 0.45108521716965866F, 1.0F, 0.48079266479409616F);
        escalar(g0, "nariz_143", 0.4467166144669678F, 1.0F, 0.49987876389444735F);
        escalar(g0, "nariz_144", 0.4999640040857405F, 1.0F, 0.5036851376369337F);
        escalar(g0, "nariz_145", 0.49996350577707344F, 1.0F, 0.5059517090636749F);
        escalar(g0, "nariz_146", 0.4999630190953834F, 1.0F, 0.4517526356347218F);
        escalar(g0, "nariz_147", 0.4999625437271695F, 1.0F, 0.45377341728093323F);
        escalar(g0, "nariz_148", 0.5010790657952969F, 1.0F, 0.45217699985865767F);
        escalar(g0, "nariz_149", 0.5015503961926063F, 1.0F, 0.5023714722414343F);
        escalar(g0, "nariz_150", 0.5015646544742042F, 1.0F, 0.49559950650216517F);
        escalar(g0, "nariz_151", 0.5015799774301356F, 1.0F, 0.4888611683473046F);
        escalar(g0, "nariz_152", 0.42793549866007885F, 1.0F, 0.4708572745417968F);
        escalar(g0, "nariz_153", 0.4411773194711042F, 1.0F, 0.5022143559135689F);
        escalar(g0, "nariz_154", 0.44489642643024985F, 1.0F, 0.46376881157374444F);
        escalar(g0, "nariz_155", 0.47059268973459256F, 1.0F, 0.48953674314292844F);
        escalar(g0, "nariz_156", 0.47442417070157933F, 1.0F, 0.4325088016661809F);
        escalar(g0, "nariz_157", 0.48011256540299174F, 1.0F, 0.4539273284351294F);
        escalar(g0, "nariz_158", 0.4928543927078556F, 1.0F, 0.49261425479591875F);
        escalar(g0, "nariz_159", 0.4610583982154593F, 1.0F, 0.5047937474249872F);
        escalar(g0, "nariz_160", 0.49984193435081087F, 1.0F, 0.5036851376369356F);
        escalar(g0, "nariz_161", 0.4998417426449559F, 1.0F, 0.505951709063676F);
        escalar(g0, "nariz_162", 0.49984155541226905F, 1.0F, 0.4517526356347227F);
        escalar(g0, "nariz_163", 0.4998413725321341F, 1.0F, 0.4537734172809341F);
        escalar(g0, "nariz_164", 0.5002712192005956F, 1.0F, 0.4521769998586571F);
        escalar(g0, "nariz_165", 0.5004528590844374F, 1.0F, 0.5023714722414336F);
        escalar(g0, "nariz_166", 0.5004583555938924F, 1.0F, 0.49559950650216433F);
        escalar(g0, "nariz_167", 0.5004642626419216F, 1.0F, 0.48886116834730386F);
        escalar(g0, "nariz_168", 0.41086167487659714F, 1.0F, 0.47085727454179693F);
        escalar(g0, "nariz_169", 0.4162148188347211F, 1.0F, 0.50221435591357F);
        escalar(g0, "nariz_170", 0.4192697524509044F, 1.0F, 0.46376881157374655F);
        escalar(g0, "nariz_171", 0.44762243354702413F, 1.0F, 0.48953674314293066F);
        escalar(g0, "nariz_172", 0.44939335905750666F, 1.0F, 0.43250880166618205F);
        escalar(g0, "nariz_173", 0.45186905399917904F, 1.0F, 0.45392732843512873F);
        escalar(g0, "nariz_174", 0.45704571077011363F, 1.0F, 0.4926142547959174F);
        escalar(g0, "nariz_175", 0.48770813859750056F, 1.0F, 0.5047937474249876F);
        escalar(g0, "nariz_176", 0.4997808880173049F, 1.0F, 0.5036851376369353F);
        escalar(g0, "nariz_177", 0.49978084967037767F, 1.0F, 0.5059517090636758F);
        escalar(g0, "nariz_178", 0.4997808122182324F, 1.0F, 0.4517526356347227F);
        escalar(g0, "nariz_179", 0.49978077563674117F, 1.0F, 0.45377341728093484F);
        escalar(g0, "nariz_180", 0.49986679416946567F, 1.0F, 0.4521769998586584F);
        escalar(g0, "nariz_181", 0.49990316478263214F, 1.0F, 0.5023714722414344F);
        escalar(g0, "nariz_182", 0.49990426557687084F, 1.0F, 0.49559950650216517F);
        escalar(g0, "nariz_183", 0.4999054486035264F, 1.0F, 0.4888611683473054F);
        escalar(g0, "nariz_184", 0.5025648299045885F, 1.0F, 0.470857274541797F);
        escalar(g0, "nariz_185", 0.5039468452309643F, 1.0F, 0.502214355913568F);
        escalar(g0, "nariz_186", 0.5069208734147432F, 1.0F, 0.46376881157374533F);
        escalar(g0, "nariz_187", 0.43884326432511306F, 1.0F, 0.48953674314292944F);
        escalar(g0, "nariz_188", 0.43929047841521757F, 1.0F, 0.43250880166618116F);
        escalar(g0, "nariz_189", 0.43986232112267204F, 1.0F, 0.45392732843512906F);
        escalar(g0, "nariz_190", 0.4409148847856441F, 1.0F, 0.4926142547959186F);
        escalar(g0, "nariz_191", 0.4680927613279965F, 1.0F, 0.5047937474249881F);
        escalar(g0, "faro4_0", 0.2550041729048399F, 0.55F, 0.2550041729048399F);
        escalar(g0, "faro4_1", 0.2550041729048399F, 0.55F, 0.2550041729048399F);
        escalar(g0, "faro4_2", 0.2550041729048399F, 0.55F, 0.2550041729048399F);
        escalar(g0, "faro4_3", 0.2550041729048399F, 0.55F, 0.2550041729048399F);
        escalar(g0, "faro4_vidrio", 0.23636363636363636F, 0.15F, 0.23636363636363636F);
        escalar(g0, "faro_bajo4_0", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_bajo4_1", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_bajo4_2", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_bajo4_3", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_bajo4_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "faro16_0", 0.2550041729048399F, 0.55F, 0.2550041729048399F);
        escalar(g0, "faro16_1", 0.2550041729048399F, 0.55F, 0.2550041729048399F);
        escalar(g0, "faro16_2", 0.2550041729048399F, 0.55F, 0.2550041729048399F);
        escalar(g0, "faro16_3", 0.2550041729048399F, 0.55F, 0.2550041729048399F);
        escalar(g0, "faro16_vidrio", 0.23636363636363636F, 0.15F, 0.23636363636363636F);
        escalar(g0, "faro_bajo16_0", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_bajo16_1", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_bajo16_2", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_bajo16_3", 0.1961570560806461F, 0.55F, 0.1961570560806461F);
        escalar(g0, "faro_bajo16_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "ventilador40_0", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador40_1", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador40_2", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador40_3", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador58_0", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador58_1", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador58_2", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador58_3", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador76_0", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador76_1", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador76_2", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador76_3", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "bocina_0", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
        escalar(g0, "bocina_1", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
        escalar(g0, "cab_velocimetro", 0.2333333333333333F, 0.6F, 0.2333333333333333F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.574F, 0.6F);
        escalar(g0, "cab_manometro0", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro0_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_manometro1", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro1_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_freno", 0.8F, 0.8003905296791061F, 0.8F);
    }
}
