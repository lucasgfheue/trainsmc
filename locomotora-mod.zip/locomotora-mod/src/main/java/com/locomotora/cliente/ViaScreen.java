package com.locomotora.cliente;

import com.locomotora.via.ConfigVia;
import com.locomotora.via.Pieza;
import com.locomotora.via.TipoVia;
import com.locomotora.via.ViaMenu;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/**
 * Pantalla del menú de una vía: botones para el largo, el radio, el lado, cuánto sube y la pendiente (hasta 30
 * bloques), y a la derecha cómo queda la pieza vista desde arriba (o de costado, la subida).
 */
public class ViaScreen extends AbstractContainerScreen<ViaMenu> {
    private static final int ANCHO = 232;
    private static final int ALTO = 140;
    // la vista previa
    private static final int VX0 = 120;
    private static final int VY0 = 18;
    private static final int VX1 = 224;
    private static final int VY1 = 112;
    // las tres filas de botones
    private static final int[] FILAS = {20, 50, 80};

    private Button largoMenos;
    private Button largoMas;
    private Button radioMenos;
    private Button radioMas;
    private Button altoMenos;
    private Button altoMas;
    private Button pasoMenos;
    private Button pasoMas;
    private Button lado;
    private Button sentido;

    public ViaScreen(ViaMenu menu, Inventory inventario, Component titulo) {
        super(menu, inventario, titulo);
        this.imageWidth = ANCHO;
        this.imageHeight = ALTO;
    }

    @Override
    public void init() {
        super.init();
        this.largoMenos = boton("-", ViaMenu.LARGO_MENOS, 18);
        this.largoMas = boton("+", ViaMenu.LARGO_MAS, 18);
        this.radioMenos = boton("-", ViaMenu.RADIO_MENOS, 18);
        this.radioMas = boton("+", ViaMenu.RADIO_MAS, 18);
        this.altoMenos = boton("-", ViaMenu.ALTO_MENOS, 18);
        this.altoMas = boton("+", ViaMenu.ALTO_MAS, 18);
        this.pasoMenos = boton("-", ViaMenu.PASO_MENOS, 18);
        this.pasoMas = boton("+", ViaMenu.PASO_MAS, 18);
        this.lado = boton("", ViaMenu.LADO, 100);
        this.sentido = boton("", ViaMenu.BAJA, 100);
        acomodar();
    }

    private Button boton(String texto, int id, int ancho) {
        return this.addRenderableWidget(Button.builder(Component.literal(texto), b -> apretar(id))
                .bounds(this.leftPos, this.topPos, ancho, 16)
                .build());
    }

    /** Manda el botón al servidor (con Shift, de a 5). */
    private void apretar(int id) {
        int boton = Screen.hasShiftDown() && id != ViaMenu.LADO && id != ViaMenu.BAJA ? id + ViaMenu.DE_A_CINCO : id;
        if (this.minecraft != null && this.minecraft.gameMode != null) {
            this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, boton);
        }
    }

    @Override
    public void containerTick() {
        super.containerTick();
        acomodar();
    }

    /** Muestra los botones que usa este tipo de vía, cada uno en su fila. */
    private void acomodar() {
        ConfigVia c = this.menu.config();
        Button[] todos = {this.largoMenos, this.largoMas, this.radioMenos, this.radioMas, this.altoMenos, this.altoMas,
                this.pasoMenos, this.pasoMas, this.lado, this.sentido};
        for (Button b : todos) {
            b.visible = false;
        }
        switch (c.tipo) {
            case RECTA -> fila(0, this.largoMenos, this.largoMas);
            case CURVA -> {
                fila(0, this.radioMenos, this.radioMas);
                fila(1, this.lado, null);
            }
            case DOS_CAMINOS -> {
                fila(0, this.largoMenos, this.largoMas);
                fila(1, this.radioMenos, this.radioMas);
                fila(2, this.lado, null);
            }
            case SUBIDA -> {
                fila(0, this.altoMenos, this.altoMas);
                fila(1, this.pasoMenos, this.pasoMas);
                fila(2, this.sentido, null);
            }
        }
        this.lado.setMessage(Component.translatable(c.izquierda ? "pantalla.locomotora.a_la_izquierda"
                : "pantalla.locomotora.a_la_derecha"));
        this.sentido.setMessage(Component.translatable(c.baja ? "pantalla.locomotora.para_abajo"
                : "pantalla.locomotora.para_arriba"));
    }

    private void fila(int fila, Button a, Button b) {
        int y = this.topPos + FILAS[fila] + 10;
        a.visible = true;
        a.setX(this.leftPos + 8);
        a.setY(y);
        if (b != null) {
            b.visible = true;
            b.setX(this.leftPos + 90);
            b.setY(y);
        }
    }

    // ------------------------------------------------------------------ dibujo
    @Override
    public void renderBg(GuiGraphics g, float tickParcial, int mouseX, int mouseY) {
        int x0 = this.leftPos;
        int y0 = this.topPos;
        int x1 = x0 + this.imageWidth;
        int y1 = y0 + this.imageHeight;
        // panel como los del juego: gris claro con borde en relieve
        g.fill(x0, y0, x1, y1, 0xFF000000);
        g.fill(x0 + 1, y0 + 1, x1 - 1, y1 - 1, 0xFFC6C6C6);
        g.fill(x0 + 1, y0 + 1, x1 - 2, y0 + 3, 0xFFFFFFFF);
        g.fill(x0 + 1, y0 + 1, x0 + 3, y1 - 2, 0xFFFFFFFF);
        g.fill(x0 + 3, y1 - 3, x1 - 1, y1 - 1, 0xFF555555);
        g.fill(x1 - 3, y0 + 3, x1 - 1, y1 - 1, 0xFF555555);
        // marco de la vista previa
        g.fill(x0 + VX0 - 1, y0 + VY0 - 1, x0 + VX1 + 1, y0 + VY1 + 1, 0xFF373737);
        g.fill(x0 + VX0, y0 + VY0, x0 + VX1, y0 + VY1, 0xFF6F9A4E);
        ConfigVia c = this.menu.config();
        if (c.tipo == TipoVia.SUBIDA) {
            vistaDeCostado(g, c, x0 + VX0, y0 + VY0, VX1 - VX0, VY1 - VY0);
        } else {
            vistaDeArriba(g, c, x0 + VX0, y0 + VY0, VX1 - VX0, VY1 - VY0);
        }
    }

    @Override
    public void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        g.drawString(this.font, this.title, 8, 6, 0x404040, false);
        ConfigVia c = this.menu.config();
        switch (c.tipo) {
            case RECTA -> valor(g, 0, "pantalla.locomotora.largo", Component.translatable("pantalla.locomotora.bloques", c.largo));
            case CURVA -> {
                valor(g, 0, "pantalla.locomotora.radio", Component.translatable("pantalla.locomotora.bloques", c.radio));
                etiqueta(g, 1, "pantalla.locomotora.lado");
            }
            case DOS_CAMINOS -> {
                valor(g, 0, "pantalla.locomotora.largo_recta",
                        Component.translatable("pantalla.locomotora.bloques", c.pieza(0, 0, 0, Pieza.Rumbo.NORTE).largo));
                valor(g, 1, "pantalla.locomotora.radio", Component.translatable("pantalla.locomotora.bloques", c.radio));
                etiqueta(g, 2, "pantalla.locomotora.lado");
            }
            case SUBIDA -> {
                valor(g, 0, c.baja ? "pantalla.locomotora.cuanto_baja" : "pantalla.locomotora.cuanto_sube",
                        Component.translatable("pantalla.locomotora.bloques", c.alto));
                valor(g, 1, "pantalla.locomotora.pendiente", Component.translatable("pantalla.locomotora.uno_cada", c.paso));
                etiqueta(g, 2, "pantalla.locomotora.sentido");
            }
        }
        Pieza p = c.pieza(0, 0, 0, Pieza.Rumbo.NORTE);
        Component info;
        if (c.tipo == TipoVia.SUBIDA) {
            info = Component.translatable(c.baja ? "pantalla.locomotora.ocupa_bajada" : "pantalla.locomotora.ocupa_subida",
                    p.largo, c.alto);
        } else {
            int[] t = p.tamano();
            info = Component.translatable("pantalla.locomotora.ocupa", t[0], t[1]);
        }
        g.drawString(this.font, info, 8, 116, 0x404040, false);
        g.drawString(this.font, Component.translatable("pantalla.locomotora.de_a_cinco"), 8, 127, 0x707070, false);
    }

    private void etiqueta(GuiGraphics g, int fila, String clave) {
        g.drawString(this.font, Component.translatable(clave), 8, FILAS[fila], 0x404040, false);
    }

    private void valor(GuiGraphics g, int fila, String clave, Component valor) {
        etiqueta(g, fila, clave);
        int ancho = this.font.width(valor);
        g.drawString(this.font, valor, 58 - ancho / 2, FILAS[fila] + 14, 0x202020, false);
    }

    /** La pieza vista desde arriba, mirando hacia adelante (hacia arriba en la pantalla). */
    private void vistaDeArriba(GuiGraphics g, ConfigVia c, int x, int y, int ancho, int alto) {
        Pieza p = c.pieza(0, 0, 0, Pieza.Rumbo.NORTE);
        int minX = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxZ = Integer.MIN_VALUE;
        for (Pieza.Celda ce : p.celdas()) {
            minX = Math.min(minX, ce.x);
            maxX = Math.max(maxX, ce.x);
            minZ = Math.min(minZ, ce.z);
            maxZ = Math.max(maxZ, ce.z);
        }
        int w = maxX - minX + 1;
        int h = maxZ - minZ + 2;               // una fila más abajo para el jugador
        int s = Math.max(1, Math.min(10, Math.min((ancho - 8) / w, (alto - 8) / h)));
        int ox = x + (ancho - w * s) / 2;
        int oz = y + (alto - h * s) / 2;
        int hueco = s >= 4 ? 1 : 0;
        for (Pieza.Celda ce : p.celdas()) {
            int color;
            if (ce.esAguja()) {
                color = 0xFFE8B828;
            } else if (ce.formas.length == 2 && ce.rutaUnica() == Pieza.CURVA) {
                color = 0xFF9AA8B8;
            } else {
                color = 0xFF8C8478;
            }
            int px = ox + (ce.x - minX) * s;
            int pz = oz + (ce.z - minZ) * s;
            g.fill(px, pz, px + s - hueco, pz + s - hueco, color);
        }
        // el trazo dibujado (rieles redondos)
        if (s >= 3) {
            for (int r = 0; r < p.cantidadRutas(); r++) {
                Pieza.Trazo tr = p.ruta(r).trazo;
                int n = (int) Math.ceil(tr.largo() / 0.2);
                for (int k = 0; k <= n; k++) {
                    double[] l = tr.punto(tr.largo() * k / n);
                    double[] m = p.aMundo(l[0], l[1], l[2]);
                    int px = ox + (int) Math.floor((m[0] - minX) * s);
                    int pz = oz + (int) Math.floor((m[2] - minZ) * s);
                    g.fill(px, pz, px + 1, pz + 1, 0xFF3A2A1C);
                }
            }
        }
        // el jugador, atrás de la primera celda
        int jx = ox + (0 - minX) * s + s / 2;
        int jz = oz + (1 - minZ) * s + s / 2;
        int t = Math.max(2, s / 2);
        g.fill(jx - t / 2 - 1, jz - 1, jx + t / 2 + 2, jz + t + 1, 0xFF2F6FD0);
    }

    /** La subida vista de costado: el jugador a la izquierda (abajo si sube, arriba si baja). */
    private void vistaDeCostado(GuiGraphics g, ConfigVia c, int x, int y, int ancho, int alto) {
        Pieza p = c.pieza(0, 0, 0, Pieza.Rumbo.NORTE);
        int n = p.largo;
        int a = p.alto;
        int s = Math.max(1, Math.min(10, Math.min((ancho - 8) / (n + 1), (alto - 8) / (a + 2))));
        int ox = x + (ancho - (n + 1) * s) / 2 + s;
        int base = y + alto - (alto - (a + 2) * s) / 2 - s;      // altura 0 (el piso)
        for (int i = 0; i < n; i++) {
            int col = c.baja ? n - 1 - i : i;
            int k = (int) Math.round(p.pisoDibujo(i) + (p.hunde(i) ? 0.5 : 0.0));
            int px = ox + col * s;
            // soporte de balasto
            double tope = p.pisoDibujo(i);
            if (tope > 0) {
                g.fill(px, base - (int) Math.round(tope * s), px + s, base, 0xFF7C756C);
            }
            // la celda del riel
            int py = base - (k + 1) * s;
            g.fill(px, py, px + s - (s >= 4 ? 1 : 0), py + s - (s >= 4 ? 1 : 0), 0x40FFFFFF);
        }
        // la rampa dibujada
        int pasos = n * 4;
        for (int k = 0; k <= pasos; k++) {
            double u = (double) n * k / pasos;
            double h = (double) a * k / pasos;
            int col = (int) Math.floor((c.baja ? n - u : u) * s);
            g.fill(ox + col, base - (int) Math.round(h * s) - 1, ox + col + 2, base - (int) Math.round(h * s) + 1,
                    0xFF3A2A1C);
        }
        // el jugador
        int jy = c.baja ? base - a * s : base;
        g.fill(ox - s + 1, jy - 2 * s, ox - 1, jy, 0xFF2F6FD0);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float tickParcial) {
        super.render(g, mouseX, mouseY, tickParcial);
        this.renderTooltip(g, mouseX, mouseY);
    }
}
