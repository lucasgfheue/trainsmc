package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "UP Big Boy" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloBigBoy {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("bigboy"), "main"),
            LocomotoraMod.id("textures/entity/bigboy.png"),
            List.of(
                new DatosModelo.Animada("fermi0_0", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -78.0F, -7.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fermi0_1", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -78.0F, -7.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fermi0_2", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -78.0F, -7.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("fermi1_0", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -62.0F, -7.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fermi1_1", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -62.0F, -7.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fermi1_2", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -62.0F, -7.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("fermi2_0", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -46.0F, -7.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fermi2_1", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -46.0F, -7.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fermi2_2", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -46.0F, -7.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("fermi3_0", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -30.0F, -7.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fermi3_1", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -30.0F, -7.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fermi3_2", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, -30.0F, -7.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("febiela_i", DatosModelo.BIELA, 7.5F, 3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("femotriz_i", DatosModelo.MOTRIZ, 7.5F, 3.0F, 0.0F, -34.0F, -46.0F, -10.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fecruceta_i", DatosModelo.CRUCETA, 7.5F, 3.0F, 0.0F, -34.0F, 0.0F, 0.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fermd0_0", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -78.0F, -7.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fermd0_1", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -78.0F, -7.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fermd0_2", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -78.0F, -7.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("fermd1_0", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -62.0F, -7.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fermd1_1", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -62.0F, -7.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fermd1_2", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -62.0F, -7.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("fermd2_0", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -46.0F, -7.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fermd2_1", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -46.0F, -7.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fermd2_2", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -46.0F, -7.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("fermd3_0", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -30.0F, -7.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fermd3_1", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -30.0F, -7.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fermd3_2", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, -30.0F, -7.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("febiela_d", DatosModelo.BIELA, 7.5F, 3.0F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("femotriz_d", DatosModelo.MOTRIZ, 7.5F, 3.0F, 1.5707963267948966F, -34.0F, -46.0F, -10.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fecruceta_d", DatosModelo.CRUCETA, 7.5F, 3.0F, 1.5707963267948966F, -34.0F, 0.0F, 0.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("febi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -118.0F, -4.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("febi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -118.0F, -4.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("febi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -118.0F, -4.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("febi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -106.0F, -4.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("febi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -106.0F, -4.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("febi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -106.0F, -4.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("febd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -118.0F, -4.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("febd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -118.0F, -4.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("febd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -118.0F, -4.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("febd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -106.0F, -4.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("febd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -106.0F, -4.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("febd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -106.0F, -4.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("rermi0_0", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 0.0F, -7.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermi0_1", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 0.0F, -7.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermi0_2", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 0.0F, -7.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rermi1_0", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 16.0F, -7.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermi1_1", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 16.0F, -7.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermi1_2", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 16.0F, -7.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rermi2_0", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 32.0F, -7.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermi2_1", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 32.0F, -7.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermi2_2", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 32.0F, -7.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rermi3_0", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 48.0F, -7.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermi3_1", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 48.0F, -7.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermi3_2", DatosModelo.RUEDA, 7.5F, 0.0F, 0.0F, 0.0F, 48.0F, -7.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rebiela_i", DatosModelo.BIELA, 7.5F, 3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("remotriz_i", DatosModelo.MOTRIZ, 7.5F, 3.0F, 0.0F, -34.0F, 32.0F, -10.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("recruceta_i", DatosModelo.CRUCETA, 7.5F, 3.0F, 0.0F, -34.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermd0_0", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 0.0F, -7.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermd0_1", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 0.0F, -7.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermd0_2", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 0.0F, -7.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rermd1_0", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -7.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermd1_1", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -7.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermd1_2", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -7.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rermd2_0", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 32.0F, -7.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermd2_1", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 32.0F, -7.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermd2_2", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 32.0F, -7.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rermd3_0", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 48.0F, -7.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rermd3_1", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 48.0F, -7.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rermd3_2", DatosModelo.RUEDA, 7.5F, 0.0F, 1.5707963267948966F, 0.0F, 48.0F, -7.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rebiela_d", DatosModelo.BIELA, 7.5F, 3.0F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("remotriz_d", DatosModelo.MOTRIZ, 7.5F, 3.0F, 1.5707963267948966F, -34.0F, 32.0F, -10.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("recruceta_d", DatosModelo.CRUCETA, 7.5F, 3.0F, 1.5707963267948966F, -34.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 82.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 82.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 82.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 82.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 82.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 82.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 130.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 130.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 130.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 142.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 142.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 142.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 172.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 172.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 172.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri3_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 186.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri3_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 186.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri3_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 186.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri4_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 200.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri4_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 200.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri4_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 200.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri5_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 214.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri5_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 214.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri5_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 214.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri6_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 228.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri6_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 228.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri6_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 228.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 130.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 130.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 130.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 142.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 142.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 142.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 172.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 172.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 172.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd3_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 186.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd3_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 186.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd3_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 186.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd4_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 200.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd4_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 200.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd4_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 200.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd5_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 214.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd5_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 214.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd5_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 214.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd6_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 228.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd6_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 228.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd6_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 228.0F, -5.0F, 1.0471975511965976F, "tender")),
            ModeloBigBoy::crearCapa,
            16.0F,
            ModeloBigBoy::preparar,
            List.of(
                new DatosModelo.Segmento("unidad_delantera", -112.0F, -30.0F, 1, -24.0F, 15.0F),
                new DatosModelo.Segmento("locomotora", -54.0F, 89.0F),
                new DatosModelo.Segmento("tender", 136.0F, 228.0F)));

    private ModeloBigBoy() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("unidad_delantera", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g2 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g1);
        piezas2(g1);
        piezas3(g1);
        piezas4(g1);
        piezas5(g1);
        piezas6(g1);
        piezas7(g1);
        piezas8(g1);
        piezas9(g2);
        return LayerDefinition.create(malla, 1024, 1024);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("unidad_delantera");
        ModelPart g1 = raiz.getChild("locomotora");
        ModelPart g2 = raiz.getChild("tender");
        escalas0(g0, g1, g2);
        escalas1(g0, g1, g2);
        escalas2(g0, g1, g2);
        escalas3(g0, g1, g2);
        escalas4(g0, g1, g2);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("fermi0_0", CubeListBuilder.create().texOffs(24, 646).addBox(-7.5F, -7.5F, -6.0F, 15.0F, 15.0F, 2.0F).texOffs(390, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(852, 723).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(342, 802).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-78.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("fermi0_1", CubeListBuilder.create().texOffs(422, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-78.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermi0_2", CubeListBuilder.create().texOffs(454, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-78.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fermi1_0", CubeListBuilder.create().texOffs(24, 646).addBox(-7.5F, -7.5F, -6.0F, 15.0F, 15.0F, 2.0F).texOffs(390, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(862, 723).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(348, 802).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-62.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("fermi1_1", CubeListBuilder.create().texOffs(422, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermi1_2", CubeListBuilder.create().texOffs(454, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fermi2_0", CubeListBuilder.create().texOffs(24, 646).addBox(-7.5F, -7.5F, -6.0F, 15.0F, 15.0F, 2.0F).texOffs(390, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 723).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(354, 802).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-46.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("fermi2_1", CubeListBuilder.create().texOffs(422, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermi2_2", CubeListBuilder.create().texOffs(454, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fermi3_0", CubeListBuilder.create().texOffs(24, 646).addBox(-7.5F, -7.5F, -6.0F, 15.0F, 15.0F, 2.0F).texOffs(390, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 723).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(360, 802).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-30.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("fermi3_1", CubeListBuilder.create().texOffs(422, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-30.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermi3_2", CubeListBuilder.create().texOffs(454, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-30.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("febiela_i", CubeListBuilder.create().texOffs(362, 805).addBox(-78.0F, -11.0F, -7.5F, 48.0F, 1.0F, 1.0F).texOffs(376, 786).addBox(-79.5F, -12.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(384, 786).addBox(-63.5F, -12.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(392, 786).addBox(-47.5F, -12.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(400, 786).addBox(-31.5F, -12.0F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("femotriz_i", CubeListBuilder.create().texOffs(754, 805).addBox(-34.0F, -0.5F, -0.5F, 34.0F, 1.0F, 1.0F).texOffs(408, 786).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(-46.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("fecruceta_i", CubeListBuilder.create().texOffs(892, 723).addBox(-81.36738844375219F, -9.0F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(310, 807).addBox(-89.86738844375219F, -8.0F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("feguias_i", CubeListBuilder.create().texOffs(70, 807).addBox(-86.86738844375219F, -6.0F, -9.0F, 14.0F, 1.0F, 1.0F).texOffs(100, 807).addBox(-86.86738844375219F, -10.0F, -9.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fecil_i_0", CubeListBuilder.create().texOffs(260, 682).addBox(-98.86738844375219F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(494, 667).addBox(-98.86738844375219F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, -8.5F));
        g.addOrReplaceChild("fecil_i_1", CubeListBuilder.create().texOffs(288, 682).addBox(-98.86738844375219F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(538, 667).addBox(-98.86738844375219F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_2", CubeListBuilder.create().texOffs(316, 682).addBox(-98.86738844375219F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(582, 667).addBox(-98.86738844375219F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_3", CubeListBuilder.create().texOffs(344, 682).addBox(-98.86738844375219F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(626, 667).addBox(-98.86738844375219F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_a_0", CubeListBuilder.create().texOffs(500, 694).addBox(-99.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(756, 682).addBox(-99.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, -8.5F));
        g.addOrReplaceChild("fecil_i_a_1", CubeListBuilder.create().texOffs(506, 694).addBox(-99.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(778, 682).addBox(-99.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_a_2", CubeListBuilder.create().texOffs(512, 694).addBox(-99.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(800, 682).addBox(-99.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_a_3", CubeListBuilder.create().texOffs(518, 694).addBox(-99.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(822, 682).addBox(-99.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_b_0", CubeListBuilder.create().texOffs(524, 694).addBox(-87.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(844, 682).addBox(-87.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, -8.5F));
        g.addOrReplaceChild("fecil_i_b_1", CubeListBuilder.create().texOffs(530, 694).addBox(-87.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(866, 682).addBox(-87.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_b_2", CubeListBuilder.create().texOffs(536, 694).addBox(-87.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(888, 682).addBox(-87.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_i_b_3", CubeListBuilder.create().texOffs(542, 694).addBox(-87.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(910, 682).addBox(-87.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fermd0_0", CubeListBuilder.create().texOffs(24, 646).addBox(-7.5F, -7.5F, 4.0F, 15.0F, 15.0F, 2.0F).texOffs(390, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(902, 723).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(366, 802).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-78.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("fermd0_1", CubeListBuilder.create().texOffs(422, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-78.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermd0_2", CubeListBuilder.create().texOffs(454, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-78.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fermd1_0", CubeListBuilder.create().texOffs(24, 646).addBox(-7.5F, -7.5F, 4.0F, 15.0F, 15.0F, 2.0F).texOffs(390, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(912, 723).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(372, 802).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-62.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("fermd1_1", CubeListBuilder.create().texOffs(422, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermd1_2", CubeListBuilder.create().texOffs(454, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fermd2_0", CubeListBuilder.create().texOffs(24, 646).addBox(-7.5F, -7.5F, 4.0F, 15.0F, 15.0F, 2.0F).texOffs(390, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(922, 723).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(378, 802).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-46.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("fermd2_1", CubeListBuilder.create().texOffs(422, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermd2_2", CubeListBuilder.create().texOffs(454, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fermd3_0", CubeListBuilder.create().texOffs(24, 646).addBox(-7.5F, -7.5F, 4.0F, 15.0F, 15.0F, 2.0F).texOffs(390, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(932, 723).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(384, 802).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-30.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("fermd3_1", CubeListBuilder.create().texOffs(422, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(204, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-30.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fermd3_2", CubeListBuilder.create().texOffs(454, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-30.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("febiela_d", CubeListBuilder.create().texOffs(460, 805).addBox(-78.0F, -11.0F, 6.5F, 48.0F, 1.0F, 1.0F).texOffs(416, 786).addBox(-79.5F, -12.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(424, 786).addBox(-63.5F, -12.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(432, 786).addBox(-47.5F, -12.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(440, 786).addBox(-31.5F, -12.0F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("femotriz_d", CubeListBuilder.create().texOffs(824, 805).addBox(-34.0F, -0.5F, -0.5F, 34.0F, 1.0F, 1.0F).texOffs(448, 786).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(-46.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("fecruceta_d", CubeListBuilder.create().texOffs(942, 723).addBox(-81.36738844375219F, -9.0F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(332, 807).addBox(-89.86738844375219F, -8.0F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("feguias_d", CubeListBuilder.create().texOffs(130, 807).addBox(-86.86738844375219F, -6.0F, 8.0F, 14.0F, 1.0F, 1.0F).texOffs(160, 807).addBox(-86.86738844375219F, -10.0F, 8.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fecil_d_0", CubeListBuilder.create().texOffs(372, 682).addBox(-98.86738844375219F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(670, 667).addBox(-98.86738844375219F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, 8.5F));
        g.addOrReplaceChild("fecil_d_1", CubeListBuilder.create().texOffs(400, 682).addBox(-98.86738844375219F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(714, 667).addBox(-98.86738844375219F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_2", CubeListBuilder.create().texOffs(428, 682).addBox(-98.86738844375219F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(758, 667).addBox(-98.86738844375219F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_3", CubeListBuilder.create().texOffs(456, 682).addBox(-98.86738844375219F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(802, 667).addBox(-98.86738844375219F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_a_0", CubeListBuilder.create().texOffs(548, 694).addBox(-99.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(932, 682).addBox(-99.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, 8.5F));
        g.addOrReplaceChild("fecil_d_a_1", CubeListBuilder.create().texOffs(554, 694).addBox(-99.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(954, 682).addBox(-99.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_a_2", CubeListBuilder.create().texOffs(560, 694).addBox(-99.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(976, 682).addBox(-99.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_a_3", CubeListBuilder.create().texOffs(566, 694).addBox(-99.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(998, 682).addBox(-99.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_b_0", CubeListBuilder.create().texOffs(572, 694).addBox(-87.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(0, 694).addBox(-87.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, 8.5F));
        g.addOrReplaceChild("fecil_d_b_1", CubeListBuilder.create().texOffs(578, 694).addBox(-87.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(22, 694).addBox(-87.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_b_2", CubeListBuilder.create().texOffs(584, 694).addBox(-87.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(44, 694).addBox(-87.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fecil_d_b_3", CubeListBuilder.create().texOffs(590, 694).addBox(-87.36738844375219F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(66, 694).addBox(-87.36738844375219F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("febi0_0", CubeListBuilder.create().texOffs(884, 694).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(792, 778).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(906, 694).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(952, 723).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-118.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("febi0_1", CubeListBuilder.create().texOffs(814, 778).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(914, 694).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-118.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("febi0_2", CubeListBuilder.create().texOffs(836, 778).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(922, 694).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-118.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("febi1_0", CubeListBuilder.create().texOffs(884, 694).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(792, 778).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(906, 694).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(962, 723).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-106.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("febi1_1", CubeListBuilder.create().texOffs(814, 778).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(914, 694).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-106.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("febi1_2", CubeListBuilder.create().texOffs(836, 778).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(922, 694).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-106.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("febd0_0", CubeListBuilder.create().texOffs(884, 694).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(792, 778).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(906, 694).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(972, 723).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-118.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("febd0_1", CubeListBuilder.create().texOffs(814, 778).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(914, 694).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-118.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("febd0_2", CubeListBuilder.create().texOffs(836, 778).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(922, 694).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-118.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("febd1_0", CubeListBuilder.create().texOffs(884, 694).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(792, 778).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(906, 694).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(982, 723).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-106.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("febd1_1", CubeListBuilder.create().texOffs(814, 778).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(914, 694).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-106.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("febd1_2", CubeListBuilder.create().texOffs(836, 778).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(922, 694).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-106.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fe_bastidor", CubeListBuilder.create().texOffs(804, 646).addBox(-122.0F, -18.0F, 2.0F, 102.0F, 14.0F, 1.0F).texOffs(0, 667).addBox(-122.0F, -18.0F, -3.0F, 102.0F, 14.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fe_piloto", CubeListBuilder.create().texOffs(166, 615).addBox(-124.0F, -14.0F, -12.0F, 4.0F, 5.0F, 24.0F).texOffs(774, 716).addBox(-130.0F, -11.0F, -1.5F, 6.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("fe_piloto_rejas_0", CubeListBuilder.create().texOffs(176, 682).addBox(-5.0F, -1.0F, -5.5F, 10.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-125.5F, -6.0F, -5.5F, 3.141592653589793F, 0.0F, -1.0121970114513341F));
        g.addOrReplaceChild("fe_piloto_rejas_1", CubeListBuilder.create().texOffs(218, 682).addBox(-5.0F, -1.0F, -5.5F, 10.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-125.5F, -6.0F, 5.5F, 3.141592653589793F, 0.0F, -1.0121970114513341F));
        g.addOrReplaceChild("fe_escalones", CubeListBuilder.create().texOffs(604, 706).addBox(-129.0F, -8.0F, 4.0F, 5.0F, 1.0F, 7.0F).texOffs(628, 706).addBox(-129.0F, -8.0F, -11.0F, 5.0F, 1.0F, 7.0F), PartPose.ZERO);
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("rermi0_0", CubeListBuilder.create().texOffs(58, 646).addBox(-7.5F, -7.5F, -6.0F, 15.0F, 15.0F, 2.0F).texOffs(486, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(228, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 723).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(390, 802).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(0.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("rermi0_1", CubeListBuilder.create().texOffs(518, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(240, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermi0_2", CubeListBuilder.create().texOffs(550, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(252, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rermi1_0", CubeListBuilder.create().texOffs(58, 646).addBox(-7.5F, -7.5F, -6.0F, 15.0F, 15.0F, 2.0F).texOffs(486, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(228, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1002, 723).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(396, 802).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(16.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("rermi1_1", CubeListBuilder.create().texOffs(518, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(240, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermi1_2", CubeListBuilder.create().texOffs(550, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(252, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rermi2_0", CubeListBuilder.create().texOffs(58, 646).addBox(-7.5F, -7.5F, -6.0F, 15.0F, 15.0F, 2.0F).texOffs(486, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(228, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1012, 723).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(402, 802).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(32.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("rermi2_1", CubeListBuilder.create().texOffs(518, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(240, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermi2_2", CubeListBuilder.create().texOffs(550, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(252, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rermi3_0", CubeListBuilder.create().texOffs(58, 646).addBox(-7.5F, -7.5F, -6.0F, 15.0F, 15.0F, 2.0F).texOffs(486, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(228, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 729).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(408, 802).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(48.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("rermi3_1", CubeListBuilder.create().texOffs(518, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(240, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(48.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermi3_2", CubeListBuilder.create().texOffs(550, 716).addBox(-7.0F, -2.0F, -6.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(252, 646).addBox(-2.0F, -7.0F, -6.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(48.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rebiela_i", CubeListBuilder.create().texOffs(558, 805).addBox(0.0F, -11.0F, -7.5F, 48.0F, 1.0F, 1.0F).texOffs(456, 786).addBox(-1.5F, -12.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(464, 786).addBox(14.5F, -12.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(472, 786).addBox(30.5F, -12.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(480, 786).addBox(46.5F, -12.0F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("remotriz_i", CubeListBuilder.create().texOffs(894, 805).addBox(-34.0F, -0.5F, -0.5F, 34.0F, 1.0F, 1.0F).texOffs(488, 786).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(32.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("recruceta_i", CubeListBuilder.create().texOffs(10, 729).addBox(-3.3673884437521977F, -9.0F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(354, 807).addBox(-11.867388443752198F, -8.0F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("reguias_i", CubeListBuilder.create().texOffs(190, 807).addBox(-8.867388443752198F, -6.0F, -9.0F, 14.0F, 1.0F, 1.0F).texOffs(220, 807).addBox(-8.867388443752198F, -10.0F, -9.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("recil_i_0", CubeListBuilder.create().texOffs(484, 682).addBox(-20.867388443752198F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(846, 667).addBox(-20.867388443752198F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, -8.5F));
        g.addOrReplaceChild("recil_i_1", CubeListBuilder.create().texOffs(512, 682).addBox(-20.867388443752198F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(890, 667).addBox(-20.867388443752198F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_2", CubeListBuilder.create().texOffs(540, 682).addBox(-20.867388443752198F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(934, 667).addBox(-20.867388443752198F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_3", CubeListBuilder.create().texOffs(568, 682).addBox(-20.867388443752198F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(978, 667).addBox(-20.867388443752198F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_a_0", CubeListBuilder.create().texOffs(596, 694).addBox(-21.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(88, 694).addBox(-21.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, -8.5F));
        g.addOrReplaceChild("recil_i_a_1", CubeListBuilder.create().texOffs(602, 694).addBox(-21.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(110, 694).addBox(-21.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_a_2", CubeListBuilder.create().texOffs(608, 694).addBox(-21.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(132, 694).addBox(-21.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_a_3", CubeListBuilder.create().texOffs(614, 694).addBox(-21.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(154, 694).addBox(-21.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_b_0", CubeListBuilder.create().texOffs(620, 694).addBox(-9.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(176, 694).addBox(-9.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, -8.5F));
        g.addOrReplaceChild("recil_i_b_1", CubeListBuilder.create().texOffs(626, 694).addBox(-9.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(198, 694).addBox(-9.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_b_2", CubeListBuilder.create().texOffs(632, 694).addBox(-9.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(220, 694).addBox(-9.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_i_b_3", CubeListBuilder.create().texOffs(638, 694).addBox(-9.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(242, 694).addBox(-9.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rermd0_0", CubeListBuilder.create().texOffs(58, 646).addBox(-7.5F, -7.5F, 4.0F, 15.0F, 15.0F, 2.0F).texOffs(486, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(228, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(20, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(414, 802).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(0.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("rermd0_1", CubeListBuilder.create().texOffs(518, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(240, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermd0_2", CubeListBuilder.create().texOffs(550, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(252, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rermd1_0", CubeListBuilder.create().texOffs(58, 646).addBox(-7.5F, -7.5F, 4.0F, 15.0F, 15.0F, 2.0F).texOffs(486, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(228, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(420, 802).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(16.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("rermd1_1", CubeListBuilder.create().texOffs(518, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(240, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermd1_2", CubeListBuilder.create().texOffs(550, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(252, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rermd2_0", CubeListBuilder.create().texOffs(58, 646).addBox(-7.5F, -7.5F, 4.0F, 15.0F, 15.0F, 2.0F).texOffs(486, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(228, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(426, 802).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(32.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("rermd2_1", CubeListBuilder.create().texOffs(518, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(240, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermd2_2", CubeListBuilder.create().texOffs(550, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(252, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(32.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rermd3_0", CubeListBuilder.create().texOffs(58, 646).addBox(-7.5F, -7.5F, 4.0F, 15.0F, 15.0F, 2.0F).texOffs(486, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(228, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(432, 802).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(48.0F, -7.5F, 0.0F));
        g.addOrReplaceChild("rermd3_1", CubeListBuilder.create().texOffs(518, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(240, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(48.0F, -7.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rermd3_2", CubeListBuilder.create().texOffs(550, 716).addBox(-7.0F, -2.0F, 4.0F, 14.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(252, 646).addBox(-2.0F, -7.0F, 4.0F, 4.0F, 14.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(48.0F, -7.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rebiela_d", CubeListBuilder.create().texOffs(656, 805).addBox(0.0F, -11.0F, 6.5F, 48.0F, 1.0F, 1.0F).texOffs(496, 786).addBox(-1.5F, -12.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(504, 786).addBox(14.5F, -12.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(512, 786).addBox(30.5F, -12.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(520, 786).addBox(46.5F, -12.0F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("remotriz_d", CubeListBuilder.create().texOffs(0, 807).addBox(-34.0F, -0.5F, -0.5F, 34.0F, 1.0F, 1.0F).texOffs(528, 786).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(32.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("recruceta_d", CubeListBuilder.create().texOffs(60, 729).addBox(-3.3673884437521977F, -9.0F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(376, 807).addBox(-11.867388443752198F, -8.0F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("reguias_d", CubeListBuilder.create().texOffs(250, 807).addBox(-8.867388443752198F, -6.0F, 8.0F, 14.0F, 1.0F, 1.0F).texOffs(280, 807).addBox(-8.867388443752198F, -10.0F, 8.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("recil_d_0", CubeListBuilder.create().texOffs(596, 682).addBox(-20.867388443752198F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(0, 682).addBox(-20.867388443752198F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, 8.5F));
        g.addOrReplaceChild("recil_d_1", CubeListBuilder.create().texOffs(624, 682).addBox(-20.867388443752198F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(44, 682).addBox(-20.867388443752198F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_2", CubeListBuilder.create().texOffs(652, 682).addBox(-20.867388443752198F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(88, 682).addBox(-20.867388443752198F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_3", CubeListBuilder.create().texOffs(680, 682).addBox(-20.867388443752198F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(132, 682).addBox(-20.867388443752198F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_a_0", CubeListBuilder.create().texOffs(644, 694).addBox(-21.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(264, 694).addBox(-21.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, 8.5F));
        g.addOrReplaceChild("recil_d_a_1", CubeListBuilder.create().texOffs(650, 694).addBox(-21.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(286, 694).addBox(-21.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_a_2", CubeListBuilder.create().texOffs(656, 694).addBox(-21.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(308, 694).addBox(-21.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_a_3", CubeListBuilder.create().texOffs(662, 694).addBox(-21.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(330, 694).addBox(-21.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_b_0", CubeListBuilder.create().texOffs(668, 694).addBox(-9.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(352, 694).addBox(-9.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -7.5F, 8.5F));
        g.addOrReplaceChild("recil_d_b_1", CubeListBuilder.create().texOffs(674, 694).addBox(-9.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(374, 694).addBox(-9.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_b_2", CubeListBuilder.create().texOffs(680, 694).addBox(-9.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(396, 694).addBox(-9.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("recil_d_b_3", CubeListBuilder.create().texOffs(686, 694).addBox(-9.367388443752198F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(418, 694).addBox(-9.367388443752198F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -7.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(708, 682).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(28, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(440, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 729).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(82.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(52, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(82.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(76, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(460, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(82.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti1_0", CubeListBuilder.create().texOffs(708, 682).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(28, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(440, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 729).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(96.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rti1_1", CubeListBuilder.create().texOffs(52, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti1_2", CubeListBuilder.create().texOffs(76, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(460, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(708, 682).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(28, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(440, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(90, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(82.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(52, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(82.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(76, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(460, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(82.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd1_0", CubeListBuilder.create().texOffs(708, 682).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(28, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(440, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(100, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(96.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("rtd1_1", CubeListBuilder.create().texOffs(52, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd1_2", CubeListBuilder.create().texOffs(76, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(460, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(264, 646).addBox(-22.0F, -18.0F, 2.0F, 134.0F, 14.0F, 1.0F).texOffs(534, 646).addBox(-22.0F, -18.0F, -3.0F, 134.0F, 14.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("pasillo", CubeListBuilder.create().texOffs(494, 560).addBox(-122.0F, -19.0F, -15.0F, 234.0F, 1.0F, 30.0F), PartPose.ZERO);
        g.addOrReplaceChild("barandas", CubeListBuilder.create().texOffs(438, 802).addBox(-110.0F, -29.0F, 14.0F, 180.0F, 1.0F, 1.0F).texOffs(0, 805).addBox(-110.0F, -29.0F, -15.0F, 180.0F, 1.0F, 1.0F).texOffs(282, 716).addBox(-121.0F, -25.0F, 13.0F, 1.0F, 6.0F, 1.0F).texOffs(286, 716).addBox(-121.0F, -25.0F, -14.0F, 1.0F, 6.0F, 1.0F).texOffs(222, 615).addBox(-121.0F, -25.0F, -13.0F, 1.0F, 1.0F, 26.0F).texOffs(332, 560).addBox(52.0F, -34.0F, -14.0F, 22.0F, 17.0F, 28.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_humo_0", CubeListBuilder.create().texOffs(832, 336).addBox(-112.0F, -51.0F, -5.0F, 22.0F, 102.0F, 10.0F).texOffs(0, 0).addBox(-112.0F, -5.0F, -51.0F, 22.0F, 10.0F, 102.0F), PartPose.offset(0.0F, -30.5F, 0.0F));
        g.addOrReplaceChild("caja_humo_1", CubeListBuilder.create().texOffs(896, 336).addBox(-112.0F, -51.0F, -5.0F, 22.0F, 102.0F, 10.0F).texOffs(248, 0).addBox(-112.0F, -5.0F, -51.0F, 22.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 0.19634954084936207F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_2", CubeListBuilder.create().texOffs(960, 336).addBox(-112.0F, -51.0F, -5.0F, 22.0F, 102.0F, 10.0F).texOffs(496, 0).addBox(-112.0F, -5.0F, -51.0F, 22.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_3", CubeListBuilder.create().texOffs(0, 448).addBox(-112.0F, -51.0F, -5.0F, 22.0F, 102.0F, 10.0F).texOffs(744, 0).addBox(-112.0F, -5.0F, -51.0F, 22.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 0.5890486225480862F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_4", CubeListBuilder.create().texOffs(64, 448).addBox(-112.0F, -51.0F, -5.0F, 22.0F, 102.0F, 10.0F).texOffs(0, 112).addBox(-112.0F, -5.0F, -51.0F, 22.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_5", CubeListBuilder.create().texOffs(128, 448).addBox(-112.0F, -51.0F, -5.0F, 22.0F, 102.0F, 10.0F).texOffs(248, 112).addBox(-112.0F, -5.0F, -51.0F, 22.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 0.9817477042468103F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_6", CubeListBuilder.create().texOffs(192, 448).addBox(-112.0F, -51.0F, -5.0F, 22.0F, 102.0F, 10.0F).texOffs(496, 112).addBox(-112.0F, -5.0F, -51.0F, 22.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_7", CubeListBuilder.create().texOffs(256, 448).addBox(-112.0F, -51.0F, -5.0F, 22.0F, 102.0F, 10.0F).texOffs(744, 112).addBox(-112.0F, -5.0F, -51.0F, 22.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 1.3744467859455345F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_0", CubeListBuilder.create().texOffs(320, 448).addBox(-114.0F, -51.0F, -5.0F, 2.0F, 102.0F, 10.0F).texOffs(0, 224).addBox(-114.0F, -5.0F, -51.0F, 2.0F, 10.0F, 102.0F), PartPose.offset(0.0F, -30.5F, 0.0F));
        g.addOrReplaceChild("puerta_1", CubeListBuilder.create().texOffs(344, 448).addBox(-114.0F, -51.0F, -5.0F, 2.0F, 102.0F, 10.0F).texOffs(208, 224).addBox(-114.0F, -5.0F, -51.0F, 2.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 0.19634954084936207F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_2", CubeListBuilder.create().texOffs(368, 448).addBox(-114.0F, -51.0F, -5.0F, 2.0F, 102.0F, 10.0F).texOffs(416, 224).addBox(-114.0F, -5.0F, -51.0F, 2.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_3", CubeListBuilder.create().texOffs(392, 448).addBox(-114.0F, -51.0F, -5.0F, 2.0F, 102.0F, 10.0F).texOffs(624, 224).addBox(-114.0F, -5.0F, -51.0F, 2.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 0.5890486225480862F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_4", CubeListBuilder.create().texOffs(416, 448).addBox(-114.0F, -51.0F, -5.0F, 2.0F, 102.0F, 10.0F).texOffs(0, 336).addBox(-114.0F, -5.0F, -51.0F, 2.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_5", CubeListBuilder.create().texOffs(440, 448).addBox(-114.0F, -51.0F, -5.0F, 2.0F, 102.0F, 10.0F).texOffs(208, 336).addBox(-114.0F, -5.0F, -51.0F, 2.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 0.9817477042468103F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_6", CubeListBuilder.create().texOffs(464, 448).addBox(-114.0F, -51.0F, -5.0F, 2.0F, 102.0F, 10.0F).texOffs(416, 336).addBox(-114.0F, -5.0F, -51.0F, 2.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_7", CubeListBuilder.create().texOffs(488, 448).addBox(-114.0F, -51.0F, -5.0F, 2.0F, 102.0F, 10.0F).texOffs(624, 336).addBox(-114.0F, -5.0F, -51.0F, 2.0F, 10.0F, 102.0F), PartPose.offsetAndRotation(0.0F, -30.5F, 0.0F, 1.3744467859455345F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(250, 729).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -42.85514818651515F, 1.2168758835756002F, 3.0434185297025147F, -0.0003568701824677669F, -0.003623371851101476F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(340, 729).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -43.00370708254539F, 1.2315076577268096F, 3.043418529702514F, -0.00035687018246776146F, -0.0036233718511015627F));
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(430, 729).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -43.15226597857564F, 1.246139431878019F, 3.043418529702513F, -0.0003568701824677669F, -0.003623371851101476F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(520, 729).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -43.30082487460588F, 1.2607712060292289F, 3.043418529702514F, -0.0003568701824677669F, -0.003623371851101476F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(610, 729).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -42.3803467705543F, 3.603863792952847F, 2.847070183499404F, -0.0010568964007565895F, -0.0034841288522595303F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(700, 729).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -42.52319663152289F, 3.647196824531439F, 2.8470701834994045F, -0.0010568964007565732F, -0.0034841288522595303F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(790, 729).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -42.666046492491475F, 3.69052985611003F, 2.8470701834994045F, -0.0010568964007565895F, -0.0034841288522595303F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(880, 729).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -42.80889635346007F, 3.7338628876886215F, 2.8470701834994045F, -0.0010568964007565786F, -0.0034841288522595303F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(0, 734).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -41.44899029077628F, 5.8523572378370154F, 2.650721556994978F, -0.0017163071473106325F, -0.0032109934975232766F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(90, 734).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -41.58064147663731F, 5.922726262740868F, 2.6507215569949785F, -0.0017163071473106108F, -0.0032109934975232766F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(180, 734).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -41.71229266249835F, 5.993095287644719F, 2.6507215569949776F, -0.0017163071473106325F, -0.00321099349752319F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(270, 734).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -41.84394384835939F, 6.063464312548572F, 2.650721556994977F, -0.0017163071473106216F, -0.0032109934975232766F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(360, 734).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -40.096870254388215F, 7.875947876110859F, 2.4543725109884984F, -0.0023097617703702112F, -0.002814461581157861F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(450, 734).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -40.2122634838999F, 7.970648652176319F, 2.4543725109884984F, -0.002309761770370157F, -0.002814461581157774F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(540, 734).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -40.327656713411585F, 8.065349428241781F, 2.454372510988498F, -0.0023097617703701895F, -0.0028144615811576874F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(630, 734).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -40.44304994292327F, 8.160050204307241F, 2.4543725109884993F, -0.0023097617703702112F, -0.002814461581157861F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(720, 734).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -38.375947876110864F, 9.596870254388216F, 2.2580229701433407F, -0.0028144540735658367F, -0.002309770918403483F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(810, 734).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -38.47064865217632F, 9.712263483899896F, 2.2580229701433403F, -0.0028144540735657933F, -0.00230977091840331F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(900, 734).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -38.56534942824178F, 9.827656713411578F, 2.2580229701433403F, -0.002814454073565815F, -0.00230977091840331F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(0, 738).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -38.66005020430725F, 9.94304994292326F, 2.25802297014334F, -0.0028144540735658367F, -0.002309770918403483F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(90, 738).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -36.35235723783702F, 10.948990290776276F, 2.0616729344570377F, -0.003210988768179974F, -0.001716315995305929F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(180, 738).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -36.422726262740866F, 11.080641476637314F, 2.0616729344570373F, -0.0032109887681799525F, -0.0017163159953057555F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(270, 738).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -36.49309528764472F, 11.212292662498351F, 2.0616729344570373F, -0.003210988768179974F, -0.0017163159953058422F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(360, 738).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -36.56346431254857F, 11.343943848359388F, 2.0616729344570377F, -0.003210988768179974F, -0.001716315995305929F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(450, 738).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -34.10386379295285F, 11.8803467705543F, 1.8653224792627419F, -0.0034841269063136076F, -0.0010569028156983404F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(540, 738).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -34.147196824531434F, 12.02319663152289F, 1.8653224792627425F, -0.003484126906313586F, -0.001056902815698167F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(630, 738).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -34.19052985611003F, 12.166046492491478F, 1.8653224792627427F, -0.0034841269063136076F, -0.0010569028156982537F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(720, 738).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -34.23386288768862F, 12.308896353460067F, 1.8653224792627427F, -0.0034841269063136076F, -0.0010569028156983404F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(810, 738).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -31.7168758835756F, 12.355148186515152F, 1.668971743761182F, -0.003623371620370825F, -0.00035687252512327445F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(900, 738).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -31.73150765772681F, 12.503707082545393F, 1.6689717437611817F, -0.003623371620370803F, -0.0003568725251231878F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(0, 742).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -31.74613943187802F, 12.652265978575635F, 1.6689717437611815F, -0.003623371620370825F, -0.0003568725251231878F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(90, 742).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -31.76077120602923F, 12.800824874605876F, 1.6689717437611817F, -0.003623371620370825F, -0.00035687252512327445F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(180, 742).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -29.283124116424403F, 12.355148186515152F, 1.4726209098286114F, -0.003623371620370825F, 0.00035687252512323113F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(270, 742).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -29.26849234227319F, 12.503707082545393F, 1.4726209098286116F, -0.003623371620370803F, 0.00035687252512323113F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(360, 742).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -29.25386056812198F, 12.652265978575635F, 1.4726209098286116F, -0.003623371620370825F, 0.0003568725251231878F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(450, 742).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -29.23922879397077F, 12.800824874605876F, 1.4726209098286114F, -0.003623371620370825F, 0.00035687252512323113F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(540, 742).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -26.896136207047153F, 11.8803467705543F, 1.2762701743270513F, -0.0034841269063136076F, 0.0010569028156982537F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(630, 742).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -26.852803175468562F, 12.02319663152289F, 1.2762701743270506F, -0.003484126906313586F, 0.0010569028156982537F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(720, 742).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -26.809470143889975F, 12.166046492491478F, 1.2762701743270504F, -0.0034841269063136076F, 0.0010569028156982537F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(810, 742).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -26.76613711231138F, 12.308896353460067F, 1.2762701743270508F, -0.0034841269063136076F, 0.001056902815698297F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(900, 742).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -24.64764276216298F, 10.94899029077628F, 1.079919719132756F, -0.003210988768179974F, 0.0017163159953058422F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(0, 746).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -24.577273737259134F, 11.080641476637316F, 1.079919719132756F, -0.003210988768179931F, 0.0017163159953057989F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(90, 746).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -24.506904712355283F, 11.212292662498353F, 1.0799197191327563F, -0.003210988768179996F, 0.001716315995305929F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(180, 746).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -24.436535687451432F, 11.343943848359391F, 1.0799197191327563F, -0.003210988768179974F, 0.0017163159953058422F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(270, 746).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -22.624052123889143F, 9.596870254388218F, 0.8835696834464529F, -0.002814454073565815F, 0.0023097709184034397F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(360, 746).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -22.529351347823685F, 9.7122634838999F, 0.883569683446454F, -0.0028144540735657933F, 0.00230977091840331F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(450, 746).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -22.43465057175822F, 9.827656713411582F, 0.8835696834464535F, -0.0028144540735658367F, 0.002309770918403397F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(540, 746).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -22.339949795692757F, 9.943049942923263F, 0.8835696834464534F, -0.0028144540735658367F, 0.0023097709184033534F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(630, 746).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -20.903129745611785F, 7.875947876110859F, 0.6872201426012947F, -0.0023097617703701895F, 0.002814461581157861F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(720, 746).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -20.7877365161001F, 7.97064865217632F, 0.6872201426012947F, -0.0023097617703701787F, 0.002814461581157774F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(810, 746).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -20.67234328658842F, 8.065349428241781F, 0.6872201426012953F, -0.0023097617703701895F, 0.0028144615811577308F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(900, 746).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -20.55695005707674F, 8.160050204307243F, 0.6872201426012946F, -0.0023097617703702112F, 0.002814461581157774F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(0, 750).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -19.551009709223724F, 5.852357237837017F, 0.4908710965948167F, -0.0017163071473106325F, 0.0032109934975232766F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(90, 750).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -19.419358523362686F, 5.922726262740868F, 0.49087109659481565F, -0.0017163071473106108F, 0.003210993497523233F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(180, 750).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -19.287707337501647F, 5.993095287644721F, 0.4908710965948152F, -0.0017163071473106216F, 0.003210993497523233F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(270, 750).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -19.156056151640612F, 6.063464312548572F, 0.4908710965948159F, -0.0017163071473106325F, 0.003210993497523233F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(360, 750).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -18.6196532294457F, 3.603863792952851F, 0.29452247009038796F, -0.0010568964007565895F, 0.0034841288522595303F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(450, 750).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -18.47680336847711F, 3.647196824531442F, 0.2945224700903885F, -0.0010568964007565732F, 0.003484128852259487F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(540, 750).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -18.33395350750852F, 3.6905298561100333F, 0.29452247009038907F, -0.001056896400756584F, 0.0034841288522595303F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(630, 750).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -18.191103646539933F, 3.7338628876886246F, 0.294522470090389F, -0.0010568964007565895F, 0.0034841288522595303F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(720, 750).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -18.14485181348485F, 1.216875883575603F, 0.09817412388727897F, -0.00035687018246776704F, 0.0036233718511015194F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(810, 750).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -17.996292917454607F, 1.2315076577268127F, 0.09817412388727918F, -0.0003568701824677617F, 0.003623371851101476F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(900, 750).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -17.847734021424365F, 1.2461394318780223F, 0.09817412388727936F, -0.00035687018246777246F, 0.0036233718511015194F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(0, 754).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -17.69917512539412F, 1.260771206029232F, 0.09817412388727954F, -0.00035687018246776704F, 0.003623371851101476F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(90, 754).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -18.14485181348485F, -1.2168758835756002F, -0.09817412388727897F, 0.00035687018246776666F, 0.0036233718511015194F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(180, 754).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -17.996292917454607F, -1.2315076577268096F, -0.09817412388727918F, 0.00035687018246776124F, 0.003623371851101476F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(270, 754).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -17.847734021424365F, -1.246139431878019F, -0.09817412388727935F, 0.00035687018246776666F, 0.0036233718511015194F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(360, 754).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -17.69917512539412F, -1.2607712060292284F, -0.09817412388727954F, 0.00035687018246776666F, 0.003623371851101476F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(450, 754).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -18.6196532294457F, -3.603863792952848F, -0.29452247009038796F, 0.0010568964007565895F, 0.0034841288522595303F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(540, 754).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -18.47680336847711F, -3.647196824531439F, -0.29452247009038784F, 0.0010568964007565624F, 0.0034841288522595303F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(630, 754).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -18.33395350750852F, -3.6905298561100297F, -0.29452247009038773F, 0.0010568964007565895F, 0.0034841288522595303F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(720, 754).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -18.191103646539933F, -3.7338628876886215F, -0.29452247009038757F, 0.0010568964007565895F, 0.0034841288522595303F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(810, 754).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -19.55100970922372F, -5.852357237837015F, -0.49087109659481615F, 0.0017163071473106325F, 0.003210993497523233F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(900, 754).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -19.419358523362686F, -5.922726262740866F, -0.4908710965948162F, 0.0017163071473106F, 0.0032109934975232766F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(0, 758).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -19.287707337501647F, -5.993095287644717F, -0.4908710965948157F, 0.0017163071473106325F, 0.0032109934975232766F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(90, 758).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -19.15605615164061F, -6.06346431254857F, -0.4908710965948159F, 0.0017163071473106325F, 0.003210993497523233F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(180, 758).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -20.90312974561178F, -7.875947876110857F, -0.6872201426012937F, 0.0023097617703702112F, 0.0028144615811577308F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(270, 758).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -20.7877365161001F, -7.970648652176319F, -0.6872201426012943F, 0.002309761770370157F, 0.002814461581157774F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(360, 758).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -20.67234328658842F, -8.06534942824178F, -0.687220142601295F, 0.0023097617703701895F, 0.0028144615811578175F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(450, 758).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -20.556950057076733F, -8.16005020430724F, -0.6872201426012944F, 0.0023097617703702112F, 0.002814461581157774F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(540, 758).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -22.624052123889136F, -9.596870254388216F, -0.8835696834464543F, 0.0028144540735658367F, 0.00230977091840331F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(630, 758).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -22.529351347823678F, -9.712263483899896F, -0.8835696834464541F, 0.0028144540735657933F, 0.0023097709184033534F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(720, 758).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -22.43465057175822F, -9.827656713411578F, -0.8835696834464537F, 0.002814454073565815F, 0.002309770918403397F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(810, 758).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -22.339949795692757F, -9.94304994292326F, -0.8835696834464543F, 0.0028144540735658367F, 0.002309770918403397F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(900, 758).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -24.64764276216298F, -10.948990290776276F, -1.079919719132755F, 0.003210988768179974F, 0.0017163159953057989F));
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(0, 762).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -24.577273737259127F, -11.080641476637314F, -1.079919719132755F, 0.0032109887681799525F, 0.0017163159953058856F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(90, 762).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -24.506904712355276F, -11.21229266249835F, -1.0799197191327552F, 0.003210988768179974F, 0.0017163159953058422F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(180, 762).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -24.436535687451425F, -11.343943848359388F, -1.0799197191327552F, 0.003210988768179974F, 0.0017163159953058856F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(270, 762).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -26.896136207047146F, -11.8803467705543F, -1.2762701743270506F, 0.0034841269063136076F, 0.0010569028156982537F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(360, 762).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -26.852803175468555F, -12.023196631522886F, -1.2762701743270504F, 0.003484126906313586F, 0.0010569028156982537F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(450, 762).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -26.809470143889964F, -12.166046492491475F, -1.2762701743270501F, 0.0034841269063136076F, 0.0010569028156982537F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(540, 762).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -26.76613711231137F, -12.308896353460064F, -1.2762701743270504F, 0.0034841269063136076F, 0.0010569028156982537F));
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(630, 762).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -29.283124116424396F, -12.355148186515148F, -1.4726209098286107F, 0.003623371620370825F, 0.00035687252512323113F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(720, 762).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -29.268492342273188F, -12.503707082545393F, -1.472620909828611F, 0.003623371620370803F, 0.0003568725251231878F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(810, 762).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -29.25386056812198F, -12.652265978575633F, -1.472620909828611F, 0.003623371620370825F, 0.00035687252512323113F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(900, 762).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -29.239228793970767F, -12.800824874605876F, -1.472620909828611F, 0.003623371620370825F, 0.0003568725251231878F));
        g.addOrReplaceChild("caldera_96", CubeListBuilder.create().texOffs(0, 766).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -31.716875883575597F, -12.355148186515152F, -1.6689717437611817F, 0.003623371620370825F, -0.00035687252512327445F));
        g.addOrReplaceChild("caldera_97", CubeListBuilder.create().texOffs(90, 766).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -31.73150765772681F, -12.503707082545393F, -1.6689717437611815F, 0.003623371620370803F, -0.0003568725251231878F));
        g.addOrReplaceChild("caldera_98", CubeListBuilder.create().texOffs(180, 766).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -31.74613943187802F, -12.652265978575635F, -1.6689717437611815F, 0.003623371620370825F, -0.0003568725251231878F));
        g.addOrReplaceChild("caldera_99", CubeListBuilder.create().texOffs(270, 766).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -31.760771206029226F, -12.800824874605876F, -1.6689717437611815F, 0.003623371620370825F, -0.00035687252512327445F));
        g.addOrReplaceChild("caldera_100", CubeListBuilder.create().texOffs(360, 766).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -34.10386379295285F, -11.8803467705543F, -1.8653224792627425F, 0.0034841269063136076F, -0.0010569028156983404F));
        g.addOrReplaceChild("caldera_101", CubeListBuilder.create().texOffs(450, 766).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -34.14719682453144F, -12.02319663152289F, -1.865322479262743F, 0.003484126906313586F, -0.0010569028156982537F));
        g.addOrReplaceChild("caldera_102", CubeListBuilder.create().texOffs(540, 766).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -34.19052985611003F, -12.166046492491478F, -1.8653224792627425F, 0.0034841269063136076F, -0.0010569028156982537F));
        g.addOrReplaceChild("caldera_103", CubeListBuilder.create().texOffs(630, 766).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -34.23386288768862F, -12.308896353460067F, -1.865322479262743F, 0.0034841269063136076F, -0.0010569028156982537F));
        g.addOrReplaceChild("caldera_104", CubeListBuilder.create().texOffs(720, 766).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -36.35235723783702F, -10.948990290776278F, -2.0616729344570373F, 0.003210988768179974F, -0.001716315995305929F));
        g.addOrReplaceChild("caldera_105", CubeListBuilder.create().texOffs(810, 766).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -36.42272626274087F, -11.080641476637314F, -2.0616729344570377F, 0.003210988768179931F, -0.0017163159953058422F));
        g.addOrReplaceChild("caldera_106", CubeListBuilder.create().texOffs(900, 766).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -36.49309528764472F, -11.212292662498353F, -2.0616729344570377F, 0.003210988768179996F, -0.001716315995305929F));
        g.addOrReplaceChild("caldera_107", CubeListBuilder.create().texOffs(0, 770).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -36.563464312548575F, -11.343943848359391F, -2.0616729344570373F, 0.003210988768179974F, -0.0017163159953057555F));
        g.addOrReplaceChild("caldera_108", CubeListBuilder.create().texOffs(90, 770).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -38.37594787611086F, -9.596870254388218F, -2.2580229701433403F, 0.002814454073565815F, -0.002309770918403397F));
        g.addOrReplaceChild("caldera_109", CubeListBuilder.create().texOffs(180, 770).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -38.470648652176315F, -9.7122634838999F, -2.2580229701433403F, 0.0028144540735657933F, -0.00230977091840331F));
        g.addOrReplaceChild("caldera_110", CubeListBuilder.create().texOffs(270, 770).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -38.56534942824178F, -9.827656713411582F, -2.2580229701433403F, 0.0028144540735658367F, -0.002309770918403483F));
        g.addOrReplaceChild("caldera_111", CubeListBuilder.create().texOffs(360, 770).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -38.66005020430724F, -9.943049942923263F, -2.2580229701433403F, 0.002814454073565815F, -0.00230977091840331F));
        g.addOrReplaceChild("caldera_112", CubeListBuilder.create().texOffs(450, 770).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -40.096870254388215F, -7.87594787611086F, -2.454372510988498F, 0.0023097617703701895F, -0.002814461581157774F));
        g.addOrReplaceChild("caldera_113", CubeListBuilder.create().texOffs(540, 770).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -40.212263483899896F, -7.970648652176321F, -2.4543725109884966F, 0.0023097617703701787F, -0.002814461581157774F));
        g.addOrReplaceChild("caldera_114", CubeListBuilder.create().texOffs(630, 770).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -40.32765671341158F, -8.065349428241783F, -2.454372510988498F, 0.0023097617703701895F, -0.002814461581157774F));
        g.addOrReplaceChild("caldera_115", CubeListBuilder.create().texOffs(720, 770).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -40.44304994292326F, -8.160050204307243F, -2.454372510988499F, 0.0023097617703701895F, -0.002814461581157774F));
        g.addOrReplaceChild("caldera_116", CubeListBuilder.create().texOffs(810, 770).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -41.44899029077628F, -5.852357237837021F, -2.6507215569949767F, 0.0017163071473106325F, -0.0032109934975232766F));
        g.addOrReplaceChild("caldera_117", CubeListBuilder.create().texOffs(900, 770).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -41.58064147663731F, -5.922726262740872F, -2.650721556994977F, 0.0017163071473106108F, -0.0032109934975232766F));
        g.addOrReplaceChild("caldera_118", CubeListBuilder.create().texOffs(0, 774).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -41.712292662498356F, -5.993095287644723F, -2.6507215569949762F, 0.0017163071473106325F, -0.00321099349752319F));
        g.addOrReplaceChild("caldera_119", CubeListBuilder.create().texOffs(90, 774).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -41.84394384835939F, -6.063464312548575F, -2.6507215569949754F, 0.0017163071473106216F, -0.0032109934975232766F));
        g.addOrReplaceChild("caldera_120", CubeListBuilder.create().texOffs(180, 774).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -42.3803467705543F, -3.6038637929528545F, -2.8470701834994045F, 0.0010568964007565895F, -0.0034841288522595303F));
        g.addOrReplaceChild("caldera_121", CubeListBuilder.create().texOffs(270, 774).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -42.52319663152289F, -3.647196824531446F, -2.8470701834994045F, 0.0010568964007565786F, -0.0034841288522595303F));
        g.addOrReplaceChild("caldera_122", CubeListBuilder.create().texOffs(360, 774).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -42.666046492491475F, -3.690529856110037F, -2.8470701834994045F, 0.0010568964007565895F, -0.0034841288522595303F));
        g.addOrReplaceChild("caldera_123", CubeListBuilder.create().texOffs(450, 774).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -42.80889635346007F, -3.7338628876886286F, -2.847070183499405F, 0.0010568964007565786F, -0.0034841288522595303F));
        g.addOrReplaceChild("caldera_124", CubeListBuilder.create().texOffs(540, 774).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-69.5F, -42.85514818651515F, -1.2168758835756044F, -3.043418529702515F, 0.0003568701824677673F, -0.003623371851101476F));
        g.addOrReplaceChild("caldera_125", CubeListBuilder.create().texOffs(630, 774).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-28.5F, -43.00370708254539F, -1.2315076577268143F, -3.0434185297025143F, 0.0003568701824677673F, -0.0036233718511015627F));
        g.addOrReplaceChild("caldera_126", CubeListBuilder.create().texOffs(720, 774).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.5F, -43.152265978575635F, -1.246139431878024F, -3.0434185297025134F, 0.0003568701824677673F, -0.003623371851101476F));
        g.addOrReplaceChild("caldera_127", CubeListBuilder.create().texOffs(810, 774).addBox(-21.0F, -1.0F, -1.5F, 42.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(53.5F, -43.30082487460588F, -1.2607712060292335F, -3.043418529702514F, 0.0003568701824677673F, -0.003623371851101476F));
        g.addOrReplaceChild("chimenea_a_0", CubeListBuilder.create().texOffs(582, 716).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(206, 667).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offset(-106.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_a_1", CubeListBuilder.create().texOffs(606, 716).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(230, 667).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-106.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_a_2", CubeListBuilder.create().texOffs(630, 716).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(254, 667).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-106.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_a_3", CubeListBuilder.create().texOffs(654, 716).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(278, 667).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-106.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea_a_labio_0", CubeListBuilder.create().texOffs(828, 796).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(692, 694).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(-106.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_a_labio_1", CubeListBuilder.create().texOffs(852, 796).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(716, 694).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-106.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_a_labio_2", CubeListBuilder.create().texOffs(876, 796).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(740, 694).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-106.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_a_labio_3", CubeListBuilder.create().texOffs(900, 796).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(764, 694).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-106.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea_b_0", CubeListBuilder.create().texOffs(678, 716).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(302, 667).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offset(-98.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_b_1", CubeListBuilder.create().texOffs(702, 716).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(326, 667).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-98.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_b_2", CubeListBuilder.create().texOffs(726, 716).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(350, 667).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-98.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_b_3", CubeListBuilder.create().texOffs(750, 716).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(374, 667).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-98.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea_b_labio_0", CubeListBuilder.create().texOffs(924, 796).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(788, 694).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(-98.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_b_labio_1", CubeListBuilder.create().texOffs(948, 796).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(812, 694).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-98.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_b_labio_2", CubeListBuilder.create().texOffs(972, 796).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(836, 694).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-98.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_b_labio_3", CubeListBuilder.create().texOffs(996, 796).addBox(-5.0F, -46.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(860, 694).addBox(-1.0F, -46.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-98.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("domo_arena_0", CubeListBuilder.create().texOffs(268, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-52.20400508676547F, -41.67830806393077F, 0.7658551282258839F, 0.12135375693632047F, 0.017418823406282036F, -1.7285989706316267F));
        g.addOrReplaceChild("domo_arena_1", CubeListBuilder.create().texOffs(914, 778).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.633587919559396F, -42.82700641892781F, 0.723654200806791F, 0.10142779921596269F, 0.06240277051586609F, -2.169600461358726F));
        g.addOrReplaceChild("domo_arena_2", CubeListBuilder.create().texOffs(926, 778).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-53.48244135266682F, -43.66441492150743F, 0.6402653887189512F, 0.07015356352245088F, 0.09069455124487415F, -2.53287737599169F));
        g.addOrReplaceChild("domo_arena_3", CubeListBuilder.create().texOffs(858, 778).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.73505128433989F, -44.298319024476406F, 0.517212750727878F, 0.04240637968450463F, 0.1036433541034486F, -2.7884756228001937F));
        g.addOrReplaceChild("domo_arena_4", CubeListBuilder.create().texOffs(0, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-56.38979086132929F, -44.72789543167236F, 0.35465610401120307F, 0.02114163727623145F, 0.09646560605067135F, -2.96831822839412F));
        g.addOrReplaceChild("domo_arena_5", CubeListBuilder.create().texOffs(398, 807).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-58.65964676102517F, -44.94529297370636F, 0.13167227699961997F, 0.005000519888763606F, 0.09784185822747148F, -3.1007999160427575F));
        g.addOrReplaceChild("domo_arena_6", CubeListBuilder.create().texOffs(938, 778).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.58190715160627F, -41.67830806393077F, 1.9801614791227664F, 0.5575908924073385F, 0.05961519779315753F, -1.7090570036171344F));
        g.addOrReplaceChild("domo_arena_7", CubeListBuilder.create().texOffs(950, 778).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.99066644085768F, -42.82700641892781F, 1.8710486093661558F, 0.4783633542155586F, 0.2188568280674344F, -2.108539921753755F));
        g.addOrReplaceChild("domo_arena_8", CubeListBuilder.create().texOffs(288, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-53.79837266072438F, -43.66441492150743F, 1.6554421488222955F, 0.3423544326037741F, 0.32824454311324014F, -2.4679923565737854F));
        g.addOrReplaceChild("domo_arena_9", CubeListBuilder.create().texOffs(12, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-54.99026373805138F, -44.298319024476406F, 1.3372826370895554F, 0.20200017500490042F, 0.24400537571845873F, -2.772564741186941F));
        g.addOrReplaceChild("domo_arena_10", CubeListBuilder.create().texOffs(646, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-56.56479167946666F, -44.72789543167236F, 0.9169832904632714F, 0.10124529151044118F, 0.2567383948015715F, -2.959679981613646F));
        g.addOrReplaceChild("domo_arena_11", CubeListBuilder.create().texOffs(962, 778).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-53.337194962420654F, -41.67830806393077F, 2.7620134152537776F, 0.9492937049774701F, 0.07860522394039147F, -1.6744515434239287F));
        g.addOrReplaceChild("domo_arena_12", CubeListBuilder.create().texOffs(974, 778).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-53.70433561531385F, -42.82700641892781F, 2.609818145715402F, 0.8549507986855416F, 0.3026164670485477F, -1.9881437770074217F));
        g.addOrReplaceChild("domo_arena_13", CubeListBuilder.create().texOffs(298, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-54.429803627186644F, -43.66441492150743F, 2.3090810883005983F, 0.6621146724659414F, 0.48873295381034504F, -2.3166353661085424F));
        g.addOrReplaceChild("domo_arena_14", CubeListBuilder.create().texOffs(308, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-55.5003399545905F, -44.298319024476406F, 1.865298675168453F, 0.4354207669859591F, 0.6021486925614539F, -2.6189861878674736F));
        g.addOrReplaceChild("domo_arena_15", CubeListBuilder.create().texOffs(24, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-56.91455421616351F, -44.72789543167236F, 1.279047277975092F, 0.19364699491375872F, 0.3857650349287219F, -2.9395877687618315F));
        g.addOrReplaceChild("domo_arena_16", CubeListBuilder.create().texOffs(986, 778).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.47597316949245F, -41.67830806393077F, 3.3314025187896696F, 1.2255346203883555F, 0.08169261108015309F, -1.6440542386860824F));
        g.addOrReplaceChild("domo_arena_17", CubeListBuilder.create().texOffs(998, 778).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.7803637085692F, -42.82700641892781F, 3.147832192343073F, 1.1475345632835252F, 0.32555992965505054F, -1.8720046219353021F));
        g.addOrReplaceChild("domo_arena_18", CubeListBuilder.create().texOffs(1010, 778).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-55.381837823398804F, -43.66441492150743F, 2.7850981864066755F, 0.9629451124801143F, 0.5627936468302007F, -2.138957199018896F));
        g.addOrReplaceChild("domo_arena_19", CubeListBuilder.create().texOffs(318, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-56.26940264966309F, -44.298319024476406F, 2.2498300227047463F, 0.6928156990833166F, 0.7430990383799654F, -2.4401241925690376F));
        g.addOrReplaceChild("domo_arena_20", CubeListBuilder.create().texOffs(36, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-57.44190544404981F, -44.72789543167236F, 1.542722891918244F, 0.29264637757448564F, 0.529672585548455F, -2.8994232038220873F));
        g.addOrReplaceChild("domo_arena_21", CubeListBuilder.create().texOffs(454, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-59.050262687846896F, -44.94529297370636F, 0.5727628360568049F, 0.07017376204187097F, 0.5419452934959487F, -3.0840539643116904F));
        g.addOrReplaceChild("domo_arena_22", CubeListBuilder.create().texOffs(282, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-56.03967704175446F, -41.67830806393077F, 3.70904642419686F, 1.410759912154734F, 0.08087653665382621F, -1.6180293270019992F));
        g.addOrReplaceChild("domo_arena_23", CubeListBuilder.create().texOffs(296, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-56.25790278126769F, -42.82700641892781F, 3.504666779571158F, 1.356956097380228F, 0.3291487584855865F, -1.7684452776741852F));
        g.addOrReplaceChild("domo_arena_24", CubeListBuilder.create().texOffs(310, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-56.68911570235541F, -43.66441492150743F, 3.1008136696378106F, 1.2146989449748746F, 0.5965084975207443F, -1.960473911314869F));
        g.addOrReplaceChild("domo_arena_25", CubeListBuilder.create().texOffs(0, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-57.32543472582089F, -44.298319024476406F, 2.504868130974307F, 0.9636828453957541F, 0.8372845086418872F, -2.2185207513719507F));
        g.addOrReplaceChild("domo_arena_26", CubeListBuilder.create().texOffs(328, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-58.16603341907346F, -44.72789543167236F, 1.7176041602666707F, 0.5947777563033354F, 1.0059379758423672F, -2.572779113763929F));
        g.addOrReplaceChild("domo_arena_27", CubeListBuilder.create().texOffs(656, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-59.31910785428303F, -44.94529297370636F, 0.6376905633610317F, 0.10031844098635387F, 0.7510411641528473F, -3.0614187814220037F));
        g.addOrReplaceChild("domo_arena_28", CubeListBuilder.create().texOffs(652, 706).addBox(-1.5F, -1.0F, -3.5F, 3.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-58.468289743530576F, -41.67830806393077F, 3.8979974566172624F, 1.5398284750690292F, 0.08040141352767019F, -1.5732842943914243F));
        g.addOrReplaceChild("domo_arena_29", CubeListBuilder.create().texOffs(0, 716).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-58.552691598369734F, -42.82700641892781F, 3.683206040220302F, 1.5381373669747784F, 0.33267255768769655F, -1.581465159275263F));
        g.addOrReplaceChild("domo_arena_30", CubeListBuilder.create().texOffs(144, 716).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-58.71946922254733F, -43.66441492150743F, 3.258779323666589F, 1.5326428897884465F, 0.6281585140873784F, -1.5932245391852002F));
        g.addOrReplaceChild("domo_arena_31", CubeListBuilder.create().texOffs(920, 716).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-58.96557449853232F, -44.298319024476406F, 2.6324743578300533F, 1.5183585384203144F, 0.9411838353960407F, -1.6131929400992666F));
        g.addOrReplaceChild("domo_arena_32", CubeListBuilder.create().texOffs(12, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.29068779196942F, -44.72789543167236F, 1.805104569335355F, 1.0586703309179544F, 1.186450228418149F, -2.105224576500843F));
        g.addOrReplaceChild("domo_arena_33", CubeListBuilder.create().texOffs(48, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-59.73665544599772F, -44.94529297370636F, 0.6701766194874135F, 0.21754939699869846F, 1.189137557883955F, -2.9367666077280994F));
        g.addOrReplaceChild("domo_arena_34", CubeListBuilder.create().texOffs(672, 706).addBox(-1.5F, -1.0F, -3.5F, 3.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-61.53171025643411F, -41.67830806393077F, 3.8979974566172633F, 1.6017641785200503F, 0.08040141352762951F, -1.5683083591984277F));
        g.addOrReplaceChild("domo_arena_35", CubeListBuilder.create().texOffs(18, 716).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-61.44730840159689F, -42.82700641892781F, 3.6832060402203024F, 1.60345528661426F, 0.3326725576875404F, -1.5601274943147816F));
        g.addOrReplaceChild("domo_arena_36", CubeListBuilder.create().texOffs(160, 716).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-61.28053077742314F, -43.66441492150743F, 3.25877932366659F, 1.6089497638004604F, 0.6281585140871419F, -1.5483681144051218F));
        g.addOrReplaceChild("domo_arena_37", CubeListBuilder.create().texOffs(934, 716).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-61.034425501443835F, -44.298319024476406F, 2.6324743578300533F, 1.6232341151682534F, 0.9411838353958187F, -1.5283997134915248F));
        g.addOrReplaceChild("domo_arena_38", CubeListBuilder.create().texOffs(24, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-60.709312208014225F, -44.72789543167236F, 1.805104569335355F, 2.082922322662613F, 1.1864502284200462F, -1.036368077098627F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("domo_arena_39", CubeListBuilder.create().texOffs(60, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-60.263344553996205F, -44.94529297370636F, 0.6701766194874136F, 2.9240432565867644F, 1.1891375578915966F, -0.20482604586628647F));
        g.addOrReplaceChild("domo_arena_40", CubeListBuilder.create().texOffs(324, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-63.96032295824553F, -41.67830806393077F, 3.709046424196861F, 1.730832741435059F, 0.08087653665382581F, -1.5235633265877968F));
        g.addOrReplaceChild("domo_arena_41", CubeListBuilder.create().texOffs(338, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-63.74209721873231F, -42.82700641892781F, 3.504666779571159F, 1.784636556209567F, 0.32914875848558695F, -1.3731473759156043F));
        g.addOrReplaceChild("domo_arena_42", CubeListBuilder.create().texOffs(352, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-63.310884297644584F, -43.66441492150743F, 3.1008136696378115F, 1.9268937086149167F, 0.5965084975207448F, -1.1811187422749276F));
        g.addOrReplaceChild("domo_arena_43", CubeListBuilder.create().texOffs(36, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-62.67456527417911F, -44.298319024476406F, 2.5048681309743075F, 2.17790980819404F, 0.8372845086418875F, -0.923071902217842F));
        g.addOrReplaceChild("domo_arena_44", CubeListBuilder.create().texOffs(338, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-61.83396658092654F, -44.72789543167236F, 1.717604160266671F, 2.546814897286459F, 1.0059379758423665F, -0.5688135398258632F));
        g.addOrReplaceChild("domo_arena_45", CubeListBuilder.create().texOffs(666, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-60.68089214571697F, -44.94529297370636F, 0.6376905633610318F, 3.041274212603439F, 0.7510411641528487F, -0.08017387216778989F));
        g.addOrReplaceChild("domo_arena_46", CubeListBuilder.create().texOffs(48, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-65.52402683050755F, -41.67830806393077F, 3.33140251878967F, 1.9160580332014359F, 0.08169261108015229F, -1.4975384149037139F));
        g.addOrReplaceChild("domo_arena_47", CubeListBuilder.create().texOffs(60, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-65.2196362914308F, -42.82700641892781F, 3.1478321923430737F, 1.994058090306268F, 0.32555992965505126F, -1.269588031654488F));
        g.addOrReplaceChild("domo_arena_48", CubeListBuilder.create().texOffs(72, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-64.61816217660119F, -43.66441492150743F, 2.7850981864066764F, 2.178647541109679F, 0.5627936468302007F, -1.002635454570897F));
        g.addOrReplaceChild("domo_arena_49", CubeListBuilder.create().texOffs(348, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-63.73059735033691F, -44.298319024476406F, 2.2498300227047463F, 2.4487769545064766F, 0.7430990383799654F, -0.7014684610207564F));
        g.addOrReplaceChild("domo_arena_50", CubeListBuilder.create().texOffs(72, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-62.558094555950184F, -44.72789543167236F, 1.5427228919182443F, 2.8489462760153077F, 0.5296725855484548F, -0.24216944976770616F));
        g.addOrReplaceChild("domo_arena_51", CubeListBuilder.create().texOffs(466, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-60.949737312153104F, -44.94529297370636F, 0.572762836056805F, 3.071418891547922F, 0.541945293495949F, -0.05753868927810285F));
        g.addOrReplaceChild("domo_arena_52", CubeListBuilder.create().texOffs(84, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-66.66280503757935F, -41.67830806393077F, 2.762013415253778F, 2.1922989486123226F, 0.07860522394039152F, -1.4671411101658647F));
        g.addOrReplaceChild("domo_arena_53", CubeListBuilder.create().texOffs(96, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-66.29566438468615F, -42.82700641892781F, 2.609818145715403F, 2.286641854904254F, 0.30261646704854833F, -1.1534488765823692F));
        g.addOrReplaceChild("domo_arena_54", CubeListBuilder.create().texOffs(358, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-65.57019637281334F, -43.66441492150743F, 2.3090810883005988F, 2.4794779811238477F, 0.4887329538103459F, -0.8249572874812526F));
        g.addOrReplaceChild("domo_arena_55", CubeListBuilder.create().texOffs(368, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.4996600454095F, -44.298319024476406F, 1.8652986751684537F, 2.7061718866038302F, 0.602148692561456F, -0.5226064657223216F));
        g.addOrReplaceChild("domo_arena_56", CubeListBuilder.create().texOffs(84, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-63.08544578383649F, -44.72789543167236F, 1.2790472779750928F, 2.9479456586760344F, 0.385765034928722F, -0.20200488482796175F));
        g.addOrReplaceChild("domo_arena_57", CubeListBuilder.create().texOffs(108, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-67.41809284839371F, -41.67830806393077F, 1.980161479122768F, 2.5840017611824577F, 0.059615197793157916F, -1.4325356499726565F));
        g.addOrReplaceChild("domo_arena_58", CubeListBuilder.create().texOffs(120, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-67.0093335591423F, -42.82700641892781F, 1.871048609366157F, 2.663229299374238F, 0.21885682806743437F, -1.033052731836035F));
        g.addOrReplaceChild("domo_arena_59", CubeListBuilder.create().texOffs(378, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-66.20162733927563F, -43.66441492150743F, 1.6554421488222961F, 2.7992382209860223F, 0.32824454311323775F, -0.6736002970160095F));
        g.addOrReplaceChild("domo_arena_60", CubeListBuilder.create().texOffs(96, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-65.00973626194862F, -44.298319024476406F, 1.3372826370895563F, 2.939592478584893F, 0.2440053757184588F, -0.369027912402852F));
        g.addOrReplaceChild("domo_arena_61", CubeListBuilder.create().texOffs(676, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-63.43520832053334F, -44.72789543167236F, 0.9169832904632721F, 3.040347362079351F, 0.2567383948015712F, -0.18191267197614716F));
        g.addOrReplaceChild("domo_arena_62", CubeListBuilder.create().texOffs(366, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.79599491323452F, -41.67830806393077F, 0.765855128240228F, 3.020238896651223F, 0.01741882340660709F, -1.4129936829581753F));
        g.addOrReplaceChild("domo_arena_63", CubeListBuilder.create().texOffs(132, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-67.3664120804406F, -42.82700641892781F, 0.7236542008203448F, 3.0401648543719495F, 0.06240277051702975F, -0.9719921922310915F));
        g.addOrReplaceChild("domo_arena_64", CubeListBuilder.create().texOffs(144, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-66.51755864733317F, -43.66441492150743F, 0.6402653887309432F, 3.0714390900660415F, 0.09069455124656234F, -0.6087152775981316F));
        g.addOrReplaceChild("domo_arena_65", CubeListBuilder.create().texOffs(872, 778).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-65.26494871566011F, -44.298319024476406F, 0.5172127507375651F, 3.099186273904506F, 0.10364335410537139F, -0.3531170307896176F));
        g.addOrReplaceChild("domo_arena_66", CubeListBuilder.create().texOffs(108, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-63.61020913867071F, -44.72789543167236F, 0.3546561040178457F, 3.120451016313173F, 0.09646560605246692F, -0.17327442519567318F));
        g.addOrReplaceChild("domo_arena_67", CubeListBuilder.create().texOffs(412, 807).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-61.34035323897483F, -44.94529297370636F, 0.13167227700208614F, 3.1365921337009373F, 0.09784185822929234F, -0.04079273754703566F));
        g.addOrReplaceChild("domo_arena_68", CubeListBuilder.create().texOffs(380, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-67.79599491323452F, -41.67830806393077F, -0.7658551282115393F, -3.0202388966557225F, -0.017418823405956897F, -1.4129936829581577F));
        g.addOrReplaceChild("domo_arena_69", CubeListBuilder.create().texOffs(156, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-67.3664120804406F, -42.82700641892781F, -0.723654200793237F, -3.0401648543757083F, -0.06240277051470392F, -0.9719921922310385F));
        g.addOrReplaceChild("domo_arena_70", CubeListBuilder.create().texOffs(168, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-66.51755864733317F, -43.66441492150743F, -0.6402653887069591F, -3.0714390900686395F, -0.09069455124318825F, -0.6087152775980784F));
        g.addOrReplaceChild("domo_arena_71", CubeListBuilder.create().texOffs(886, 778).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-65.26494871566011F, -44.298319024476406F, -0.5172127507181906F, -3.099186273906076F, -0.10364335410151954F, -0.35311703078958073F));
        g.addOrReplaceChild("domo_arena_72", CubeListBuilder.create().texOffs(120, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-63.61020913867071F, -44.72789543167236F, -0.35465610400456044F, -3.120451016313954F, -0.09646560604887573F, -0.17327442519567315F));
        g.addOrReplaceChild("domo_arena_73", CubeListBuilder.create().texOffs(426, 807).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-61.34035323897483F, -44.94529297370636F, -0.13167227699715378F, -3.136592133701122F, -0.0978418582256506F, -0.04079273754703566F));
        g.addOrReplaceChild("domo_arena_74", CubeListBuilder.create().texOffs(180, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-67.41809284839373F, -41.67830806393077F, -1.9801614791227644F, -2.5840017611824573F, -0.059615197793157916F, -1.4325356499726565F));
        g.addOrReplaceChild("domo_arena_75", CubeListBuilder.create().texOffs(192, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-67.0093335591423F, -42.82700641892781F, -1.871048609366154F, -2.6632292993742377F, -0.21885682806743417F, -1.0330527318360352F));
        g.addOrReplaceChild("domo_arena_76", CubeListBuilder.create().texOffs(388, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-66.20162733927562F, -43.66441492150743F, -1.6554421488222937F, -2.799238220986022F, -0.32824454311323764F, -0.6736002970160098F));
        g.addOrReplaceChild("domo_arena_77", CubeListBuilder.create().texOffs(132, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-65.00973626194862F, -44.298319024476406F, -1.3372826370895543F, -2.939592478584893F, -0.2440053757184585F, -0.369027912402852F));
        g.addOrReplaceChild("domo_arena_78", CubeListBuilder.create().texOffs(686, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-63.43520832053334F, -44.72789543167236F, -0.9169832904632705F, -3.040347362079352F, -0.25673839480157123F, -0.18191267197614752F));
        g.addOrReplaceChild("domo_arena_79", CubeListBuilder.create().texOffs(204, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-66.66280503757935F, -41.67830806393077F, -2.7620134152537763F, -2.1922989486123248F, -0.07860522394039147F, -1.4671411101658645F));
        g.addOrReplaceChild("domo_arena_80", CubeListBuilder.create().texOffs(216, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-66.29566438468615F, -42.82700641892781F, -2.6098181457154013F, -2.2866418549042558F, -0.30261646704854805F, -1.1534488765823685F));
        g.addOrReplaceChild("domo_arena_81", CubeListBuilder.create().texOffs(398, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-65.57019637281334F, -43.66441492150743F, -2.3090810883005974F, -2.4794779811238494F, -0.4887329538103454F, -0.8249572874812519F));
        g.addOrReplaceChild("domo_arena_82", CubeListBuilder.create().texOffs(408, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.4996600454095F, -44.298319024476406F, -1.8652986751684524F, -2.7061718866038316F, -0.6021486925614552F, -0.5226064657223208F));
        g.addOrReplaceChild("domo_arena_83", CubeListBuilder.create().texOffs(144, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-63.08544578383649F, -44.72789543167236F, -1.2790472779750919F, -2.9479456586760335F, -0.38576503492872244F, -0.20200488482796222F));
        g.addOrReplaceChild("domo_arena_84", CubeListBuilder.create().texOffs(228, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-65.52402683050755F, -41.67830806393077F, -3.3314025187896696F, -1.9160580332014374F, -0.0816926110801531F, -1.497538414903711F));
        g.addOrReplaceChild("domo_arena_85", CubeListBuilder.create().texOffs(240, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-65.2196362914308F, -42.82700641892781F, -3.147832192343073F, -1.994058090306268F, -0.3255599296550504F, -1.2695880316544912F));
        g.addOrReplaceChild("domo_arena_86", CubeListBuilder.create().texOffs(252, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-64.61816217660119F, -43.66441492150743F, -2.7850981864066755F, -2.178647541109683F, -0.5627936468302008F, -1.002635454570893F));
        g.addOrReplaceChild("domo_arena_87", CubeListBuilder.create().texOffs(418, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-63.73059735033691F, -44.298319024476406F, -2.249830022704746F, -2.448776954506476F, -0.7430990383799654F, -0.7014684610207568F));
        g.addOrReplaceChild("domo_arena_88", CubeListBuilder.create().texOffs(156, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-62.55809455595019F, -44.72789543167236F, -1.542722891918244F, -2.8489462760153073F, -0.5296725855484548F, -0.24216944976770616F));
        g.addOrReplaceChild("domo_arena_89", CubeListBuilder.create().texOffs(478, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-60.949737312153104F, -44.94529297370636F, -0.5727628360568049F, -3.071418891547922F, -0.5419452934959487F, -0.05753868927810285F));
        g.addOrReplaceChild("domo_arena_90", CubeListBuilder.create().texOffs(394, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-63.96032295824554F, -41.67830806393077F, -3.7090464241968597F, -1.7308327414350593F, -0.08087653665382624F, -1.5235633265877941F));
        g.addOrReplaceChild("domo_arena_91", CubeListBuilder.create().texOffs(408, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-63.74209721873231F, -42.82700641892781F, -3.504666779571158F, -1.7846365562095656F, -0.3291487584855864F, -1.3731473759156079F));
        g.addOrReplaceChild("domo_arena_92", CubeListBuilder.create().texOffs(422, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-63.31088429764459F, -43.66441492150743F, -3.10081366963781F, -1.926893708614919F, -0.5965084975207448F, -1.181118742274924F));
        g.addOrReplaceChild("domo_arena_93", CubeListBuilder.create().texOffs(264, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-62.67456527417911F, -44.298319024476406F, -2.504868130974307F, -2.1779098081940416F, -0.8372845086418871F, -0.92307190221784F));
        g.addOrReplaceChild("domo_arena_94", CubeListBuilder.create().texOffs(428, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-61.83396658092654F, -44.72789543167236F, -1.7176041602666707F, -2.5468148972864584F, -1.0059379758423672F, -0.568813539825864F));
        g.addOrReplaceChild("domo_arena_95", CubeListBuilder.create().texOffs(696, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-60.68089214571697F, -44.94529297370636F, -0.6376905633610317F, -3.0412742126034393F, -0.7510411641528473F, -0.08017387216778969F));
        g.addOrReplaceChild("domo_arena_96", CubeListBuilder.create().texOffs(692, 706).addBox(-1.5F, -1.0F, -3.5F, 3.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-61.53171025648987F, -41.67830806393077F, -3.8979974566172624F, -1.6017641785211771F, -0.08040141352769382F, -1.5683083591983351F));
        g.addOrReplaceChild("domo_arena_97", CubeListBuilder.create().texOffs(36, 716).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-61.447308401649586F, -42.82700641892781F, -3.683206040220302F, -1.6034552866154512F, -0.332672557687787F, -1.5601274943143846F));
        g.addOrReplaceChild("domo_arena_98", CubeListBuilder.create().texOffs(176, 716).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-61.28053077746976F, -43.66441492150743F, -3.258779323666589F, -1.6089497638018595F, -0.6281585140875152F, -1.5483681144042873F));
        g.addOrReplaceChild("domo_arena_99", CubeListBuilder.create().texOffs(948, 716).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-61.034425501481486F, -44.298319024476406F, -2.6324743578300533F, -1.623234115170188F, -0.9411838353961692F, -1.528399713489949F));
        g.addOrReplaceChild("domo_arena_100", CubeListBuilder.create().texOffs(276, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-60.709312208040046F, -44.72789543167236F, -1.805104569335355F, -2.0829223226771822F, -1.1864502284170506F, -1.0363680770833472F));
        g.addOrReplaceChild("domo_arena_101", CubeListBuilder.create().texOffs(168, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-60.26334455400579F, -44.94529297370636F, -0.6701766194874135F, -2.924043256593601F, -1.1891375578795313F, -0.2048260458590353F));
        g.addOrReplaceChild("domo_arena_102", CubeListBuilder.create().texOffs(712, 706).addBox(-1.5F, -1.0F, -3.5F, 3.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-58.46828974358634F, -41.67830806393077F, -3.8979974566172633F, -1.539828475070156F, -0.08040141352760591F, -1.5732842943913317F));
        g.addOrReplaceChild("domo_arena_103", CubeListBuilder.create().texOffs(54, 716).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-58.55269159842243F, -42.82700641892781F, -3.6832060402203024F, -1.5381373669759697F, -0.3326725576874498F, -1.581465159274866F));
        g.addOrReplaceChild("domo_arena_104", CubeListBuilder.create().texOffs(192, 716).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-58.71946922259395F, -43.66441492150743F, -3.25877932366659F, -1.5326428897898456F, -0.6281585140870052F, -1.5932245391843656F));
        g.addOrReplaceChild("domo_arena_105", CubeListBuilder.create().texOffs(962, 716).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-58.96557449856998F, -44.298319024476406F, -2.6324743578300533F, -1.518358538422249F, -0.94118383539569F, -1.6131929400976908F));
        g.addOrReplaceChild("domo_arena_106", CubeListBuilder.create().texOffs(288, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-59.29068779199524F, -44.72789543167236F, -1.805104569335355F, -1.0586703309325236F, -1.186450228421145F, -2.1052245764855626F));
        g.addOrReplaceChild("domo_arena_107", CubeListBuilder.create().texOffs(180, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-59.73665544600731F, -44.94529297370636F, -0.6701766194874136F, -0.21754939700553555F, -1.1891375578960202F, -2.9367666077208483F));
        g.addOrReplaceChild("domo_arena_108", CubeListBuilder.create().texOffs(436, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-56.03967704175447F, -41.67830806393077F, -3.709046424196861F, -1.4107599121547343F, -0.08087653665382621F, -1.6180293270019992F));
        g.addOrReplaceChild("domo_arena_109", CubeListBuilder.create().texOffs(450, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-56.25790278126769F, -42.82700641892781F, -3.50466677957116F, -1.3569560973802282F, -0.3291487584855865F, -1.7684452776741852F));
        g.addOrReplaceChild("domo_arena_110", CubeListBuilder.create().texOffs(464, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-56.689115702355416F, -43.66441492150743F, -3.1008136696378115F, -1.214698944974877F, -0.5965084975207448F, -1.9604739113148655F));
        g.addOrReplaceChild("domo_arena_111", CubeListBuilder.create().texOffs(300, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-57.32543472582089F, -44.298319024476406F, -2.504868130974308F, -0.963682845395752F, -0.8372845086418872F, -2.218520751371953F));
        g.addOrReplaceChild("domo_arena_112", CubeListBuilder.create().texOffs(438, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-58.16603341907346F, -44.72789543167236F, -1.7176041602666712F, -0.5947777563033354F, -1.0059379758423677F, -2.5727791137639286F));
        g.addOrReplaceChild("domo_arena_113", CubeListBuilder.create().texOffs(706, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-59.31910785428303F, -44.94529297370636F, -0.6376905633610318F, -0.10031844098635423F, -0.7510411641528487F, -3.0614187814220033F));
        g.addOrReplaceChild("domo_arena_114", CubeListBuilder.create().texOffs(312, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.47597316949245F, -41.67830806393077F, -3.3314025187896705F, -1.2255346203883568F, -0.08169261108015308F, -1.6440542386860821F));
        g.addOrReplaceChild("domo_arena_115", CubeListBuilder.create().texOffs(324, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.7803637085692F, -42.82700641892781F, -3.147832192343074F, -1.1475345632835265F, -0.32555992965505043F, -1.8720046219353017F));
        g.addOrReplaceChild("domo_arena_116", CubeListBuilder.create().texOffs(336, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-55.381837823398804F, -43.66441492150743F, -2.7850981864066773F, -0.9629451124801162F, -0.5627936468302007F, -2.1389571990188943F));
        g.addOrReplaceChild("domo_arena_117", CubeListBuilder.create().texOffs(448, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-56.26940264966309F, -44.298319024476406F, -2.2498300227047467F, -0.6928156990833171F, -0.7430990383799654F, -2.4401241925690376F));
        g.addOrReplaceChild("domo_arena_118", CubeListBuilder.create().texOffs(192, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-57.441905444049816F, -44.72789543167236F, -1.5427228919182445F, -0.29264637757448675F, -0.5296725855484561F, -2.8994232038220864F));
        g.addOrReplaceChild("domo_arena_119", CubeListBuilder.create().texOffs(490, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-59.050262687846896F, -44.94529297370636F, -0.5727628360568051F, -0.07017376204187095F, -0.541945293495949F, -3.0840539643116904F));
        g.addOrReplaceChild("domo_arena_120", CubeListBuilder.create().texOffs(348, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-53.337194962420654F, -41.67830806393077F, -2.7620134152537785F, -0.9492937049774703F, -0.07860522394039147F, -1.6744515434239289F));
        g.addOrReplaceChild("domo_arena_121", CubeListBuilder.create().texOffs(360, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-53.70433561531385F, -42.82700641892781F, -2.6098181457154035F, -0.8549507986855419F, -0.3026164670485479F, -1.9881437770074215F));
        g.addOrReplaceChild("domo_arena_122", CubeListBuilder.create().texOffs(458, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-54.42980362718665F, -43.66441492150743F, -2.309081088300599F, -0.6621146724659414F, -0.48873295381034504F, -2.3166353661085424F));
        g.addOrReplaceChild("domo_arena_123", CubeListBuilder.create().texOffs(468, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-55.5003399545905F, -44.298319024476406F, -1.865298675168454F, -0.43542076698595933F, -0.602148692561454F, -2.6189861878674736F));
        g.addOrReplaceChild("domo_arena_124", CubeListBuilder.create().texOffs(204, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-56.91455421616351F, -44.72789543167236F, -1.279047277975093F, -0.19364699491375875F, -0.385765034928722F, -2.9395877687618315F));
        g.addOrReplaceChild("domo_arena_125", CubeListBuilder.create().texOffs(372, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.58190715160628F, -41.67830806393077F, -1.9801614791227689F, -0.5575908924073395F, -0.059615197793157604F, -1.7090570036171344F));
        g.addOrReplaceChild("domo_arena_126", CubeListBuilder.create().texOffs(384, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.99066644085769F, -42.82700641892781F, -1.871048609366158F, -0.4783633542155596F, -0.2188568280674347F, -2.108539921753755F));
        g.addOrReplaceChild("domo_arena_127", CubeListBuilder.create().texOffs(478, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-53.79837266072438F, -43.66441492150743F, -1.655442148822297F, -0.342354432603775F, -0.3282445431132406F, -2.4679923565737854F));
        g.addOrReplaceChild("domo_arena_128", CubeListBuilder.create().texOffs(216, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-54.99026373805138F, -44.298319024476406F, -1.337282637089557F, -0.20200017500490083F, -0.24400537571845898F, -2.772564741186941F));
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("domo_arena_129", CubeListBuilder.create().texOffs(716, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-56.56479167946666F, -44.72789543167236F, -0.9169832904632726F, -0.10124529151044133F, -0.25673839480157185F, -2.959679981613646F));
        g.addOrReplaceChild("domo_arena_130", CubeListBuilder.create().texOffs(478, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-52.20400508676548F, -41.67830806393077F, -0.7658551282491866F, -0.12135375693997517F, -0.017418823406810138F, -1.7285989706316125F));
        g.addOrReplaceChild("domo_arena_131", CubeListBuilder.create().texOffs(396, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-52.63358791955939F, -42.82700641892781F, -0.7236542008288097F, -0.10142779921901567F, -0.06240277051775521F, -2.169600461358683F));
        g.addOrReplaceChild("domo_arena_132", CubeListBuilder.create().texOffs(408, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-53.48244135266682F, -43.66441492150743F, -0.6402653887384329F, -0.07015356352456112F, -0.09069455124761487F, -2.5328773759916463F));
        g.addOrReplaceChild("domo_arena_133", CubeListBuilder.create().texOffs(900, 778).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.73505128433989F, -44.298319024476406F, -0.5172127507436153F, -0.04240637968577975F, -0.10364335410657732F, -2.788475622800164F));
        g.addOrReplaceChild("domo_arena_134", CubeListBuilder.create().texOffs(228, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-56.38979086132929F, -44.72789543167236F, -0.35465610402199427F, -0.021141637276865438F, -0.09646560605358835F, -2.96831822839412F));
        g.addOrReplaceChild("domo_arena_135", CubeListBuilder.create().texOffs(440, 807).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-58.65964676102517F, -44.94529297370636F, -0.13167227700362638F, -0.0050005198889135445F, -0.09784185823042957F, -3.1007999160427575F));
        g.addOrReplaceChild("domo_vapor_0", CubeListBuilder.create().texOffs(492, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-14.153003815074106F, -41.67830806393077F, 0.7658551282258839F, 0.0917124222369761F, 0.013287935489238246F, -1.6899674681387808F));
        g.addOrReplaceChild("domo_vapor_1", CubeListBuilder.create().texOffs(420, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-14.475190939669545F, -42.82700641892781F, 0.723654200806791F, 0.08214842116357234F, 0.05101112314649748F, -2.0451679429618497F));
        g.addOrReplaceChild("domo_vapor_2", CubeListBuilder.create().texOffs(432, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.111831014500115F, -43.66441492150743F, 0.6402653887189512F, 0.06272740337882104F, 0.08181496133189496F, -2.394444365056915F));
        g.addOrReplaceChild("domo_vapor_3", CubeListBuilder.create().texOffs(444, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.05128846325492F, -44.298319024476406F, 0.517212750727878F, 0.040589831515169414F, 0.10003977799836292F, -2.6861371286521605F));
        g.addOrReplaceChild("domo_vapor_4", CubeListBuilder.create().texOffs(488, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.292343145996966F, -44.72789543167236F, 0.35465610401120307F, 0.020978357513781846F, 0.12687008650861623F, -2.9123232416576403F));
        g.addOrReplaceChild("domo_vapor_5", CubeListBuilder.create().texOffs(502, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.99473507076888F, -44.94529297370636F, 0.13167227699961997F, 0.005015822127194472F, 0.13005094463242683F, -3.0872257759160218F));
        g.addOrReplaceChild("domo_vapor_6", CubeListBuilder.create().texOffs(498, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.436430363704709F, -41.67830806393077F, 1.9801614791227664F, 0.4395927264691096F, 0.04564237262150406F, -1.6814816887701047F));
        g.addOrReplaceChild("domo_vapor_7", CubeListBuilder.create().texOffs(508, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.742999830643262F, -42.82700641892781F, 1.8710486093661558F, 0.39697665187236825F, 0.1760681441525653F, -2.0155470840725638F));
        g.addOrReplaceChild("domo_vapor_8", CubeListBuilder.create().texOffs(518, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.348779495543283F, -43.66441492150743F, 1.6554421488222955F, 0.30749551927563606F, 0.2847770976689796F, -2.3572043817799186F));
        g.addOrReplaceChild("domo_vapor_9", CubeListBuilder.create().texOffs(528, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.24269780353854F, -44.298319024476406F, 1.3372826370895554F, 0.20140521267700492F, 0.3506796583367502F, -2.656013729712594F));
        g.addOrReplaceChild("domo_vapor_10", CubeListBuilder.create().texOffs(886, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.423593759599996F, -44.72789543167236F, 0.9169832904632714F, 0.10266569899659392F, 0.33281291717297634F, -2.901078576973079F));
        g.addOrReplaceChild("domo_vapor_11", CubeListBuilder.create().texOffs(538, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.002896221815494F, -41.67830806393077F, 2.7620134152537776F, 0.8113095686354062F, 0.06831031869041816F, -1.6597349090298252F));
        g.addOrReplaceChild("domo_vapor_12", CubeListBuilder.create().texOffs(548, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.278251711485389F, -42.82700641892781F, 2.609818145715402F, 0.7499347912394131F, 0.2687057141172314F, -1.9358306628821114F));
        g.addOrReplaceChild("domo_vapor_13", CubeListBuilder.create().texOffs(558, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.822352720389986F, -43.66441492150743F, 2.3090810883005983F, 0.6080628542224318F, 0.4507998827921534F, -2.247103907677976F));
        g.addOrReplaceChild("domo_vapor_14", CubeListBuilder.create().texOffs(568, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.62525496594288F, -44.298319024476406F, 1.865298675168453F, 0.4165836181854043F, 0.5742581234272429F, -2.558561067316057F));
        g.addOrReplaceChild("domo_vapor_15", CubeListBuilder.create().texOffs(894, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.685915662122635F, -44.72789543167236F, 1.279047277975092F, 0.20219857688825688F, 0.4898545833735189F, -2.8750270232667074F));
        g.addOrReplaceChild("domo_vapor_16", CubeListBuilder.create().texOffs(456, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.856979877119333F, -41.67830806393077F, 3.3314025187896696F, 1.1262821031513224F, 0.07793653958971498F, -1.6339016223996998F));
        g.addOrReplaceChild("domo_vapor_17", CubeListBuilder.create().texOffs(468, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.085272781426895F, -42.82700641892781F, 3.147832192343073F, 1.0692385907260036F, 0.31358537932896835F, -1.8347198526803918F));
        g.addOrReplaceChild("domo_vapor_18", CubeListBuilder.create().texOffs(578, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.536378367549105F, -43.66441492150743F, 2.7850981864066755F, 0.9222808812978119F, 0.5522110492097261F, -2.0851339043366823F));
        g.addOrReplaceChild("domo_vapor_19", CubeListBuilder.create().texOffs(588, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.20205198724732F, -44.298319024476406F, 2.2498300227047463F, 0.6840961755158423F, 0.7431667356155238F, -2.386700583729181F));
        g.addOrReplaceChild("domo_vapor_20", CubeListBuilder.create().texOffs(598, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.081429083037364F, -44.72789543167236F, 1.542722891918244F, 0.3176329817763581F, 0.6522384862066533F, -2.8234256020152286F));
        g.addOrReplaceChild("domo_vapor_21", CubeListBuilder.create().texOffs(480, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.029757781315848F, -41.67830806393077F, 3.70904642419686F, 1.3607271128316212F, 0.08010314844514789F, -1.6100594526714451F));
        g.addOrReplaceChild("domo_vapor_22", CubeListBuilder.create().texOffs(492, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.193427085950766F, -42.82700641892781F, 3.504666779571158F, 1.3200179948485344F, 0.3276459677183525F, -1.737049881934542F));
        g.addOrReplaceChild("domo_vapor_23", CubeListBuilder.create().texOffs(216, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.516836776766556F, -43.66441492150743F, 3.1008136696378106F, 1.2061643370349078F, 0.6002966062494474F, -1.9073080600598338F));
        g.addOrReplaceChild("domo_vapor_24", CubeListBuilder.create().texOffs(608, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.994076044365666F, -44.298319024476406F, 2.504868130974307F, 0.987774421239287F, 0.8543232539035999F, -2.150864086566531F));
        g.addOrReplaceChild("domo_vapor_25", CubeListBuilder.create().texOffs(618, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.624525064305093F, -44.72789543167236F, 1.7176041602666707F, 0.6336210536511955F, 1.0400743469827627F, -2.5106261917351755F));
        g.addOrReplaceChild("domo_vapor_26", CubeListBuilder.create().texOffs(726, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.48933089071228F, -44.94529297370636F, 0.6376905633610317F, 0.1169722238076682F, 0.8927760241313168F, -3.034871541801811F));
        g.addOrReplaceChild("domo_vapor_27", CubeListBuilder.create().texOffs(792, 716).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-18.85121730764793F, -41.67830806393077F, 3.8979974566172624F, 1.5287091115800908F, 0.07992276899132501F, -1.5841939976972552F));
        g.addOrReplaceChild("domo_vapor_28", CubeListBuilder.create().texOffs(808, 716).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-18.9145186987773F, -42.82700641892781F, 3.683206040220302F, 1.5272647979702385F, 0.332430427698784F, -1.5850104879236337F));
        g.addOrReplaceChild("domo_vapor_29", CubeListBuilder.create().texOffs(660, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.0396019169105F, -43.66441492150743F, 3.258779323666589F, 1.5199507533130994F, 0.6277137867646481F, -1.6006745893300562F));
        g.addOrReplaceChild("domo_vapor_30", CubeListBuilder.create().texOffs(672, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.224180873899236F, -44.298319024476406F, 2.6324743578300533F, 1.3669888920134934F, 0.9268292249827591F, -1.7937705519305192F));
        g.addOrReplaceChild("domo_vapor_31", CubeListBuilder.create().texOffs(504, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.468015843977064F, -44.72789543167236F, 1.805104569335355F, 1.1396559926728225F, 1.2027891253717946F, -2.0145988087055704F));
        g.addOrReplaceChild("domo_vapor_32", CubeListBuilder.create().texOffs(902, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.80249158449829F, -44.94529297370636F, 0.6701766194874135F, 0.2784831504859361F, 1.2740202202888278F, -2.871381200007799F));
        g.addOrReplaceChild("domo_vapor_33", CubeListBuilder.create().texOffs(824, 716).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-21.148782692325582F, -41.67830806393077F, 3.8979974566172633F, 1.6128835420087324F, 0.07992276899130633F, -1.5573986558928479F));
        g.addOrReplaceChild("domo_vapor_34", CubeListBuilder.create().texOffs(840, 716).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-21.08548130119767F, -42.82700641892781F, 3.6832060402203024F, 1.6143278556185496F, 0.3324304276986391F, -1.556582165666494F));
        g.addOrReplaceChild("domo_vapor_35", CubeListBuilder.create().texOffs(684, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-20.960398083067354F, -43.66441492150743F, 3.25877932366659F, 1.621641900275514F, 0.6277137867644325F, -1.54091806426044F));
        g.addOrReplaceChild("domo_vapor_36", CubeListBuilder.create().texOffs(696, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-20.775819126082872F, -44.298319024476406F, 2.6324743578300533F, 1.774603761571791F, 0.9268292249831777F, -1.347822101664188F));
        g.addOrReplaceChild("domo_vapor_37", CubeListBuilder.create().texOffs(516, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.531984156010672F, -44.72789543167236F, 1.805104569335355F, 2.0019366609084432F, 1.2027891253731149F, -1.1269938448930121F));
        g.addOrReplaceChild("domo_vapor_38", CubeListBuilder.create().texOffs(910, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.197508415497154F, -44.94529297370636F, 0.6701766194874136F, 2.8631095030981F, 1.2740202202948174F, -0.27021145358792614F));
        g.addOrReplaceChild("domo_vapor_39", CubeListBuilder.create().texOffs(528, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.97024221868415F, -41.67830806393077F, 3.709046424196861F, 1.7808655407581724F, 0.08010314844514789F, -1.5315332009183482F));
        g.addOrReplaceChild("domo_vapor_40", CubeListBuilder.create().texOffs(540, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.806572914049234F, -42.82700641892781F, 3.504666779571159F, 1.8215746587412585F, 0.3276459677183524F, -1.4045427716552523F));
        g.addOrReplaceChild("domo_vapor_41", CubeListBuilder.create().texOffs(226, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.48316322323344F, -43.66441492150743F, 3.1008136696378115F, 1.9354283165548851F, 0.6002966062494471F, -1.2342845935299596F));
        g.addOrReplaceChild("domo_vapor_42", CubeListBuilder.create().texOffs(628, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.005923955634334F, -44.298319024476406F, 2.5048681309743075F, 2.1538182323505053F, 0.8543232539036003F, -0.9907285670232634F));
        g.addOrReplaceChild("domo_vapor_43", CubeListBuilder.create().texOffs(638, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.375474935694907F, -44.72789543167236F, 1.717604160266671F, 2.5079715999385983F, 1.0400743469827627F, -0.6309664618546176F));
        g.addOrReplaceChild("domo_vapor_44", CubeListBuilder.create().texOffs(736, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.51066910928772F, -44.94529297370636F, 0.6376905633610318F, 3.024620429782125F, 0.8927760241313168F, -0.10672111178798237F));
        g.addOrReplaceChild("domo_vapor_45", CubeListBuilder.create().texOffs(552, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-24.143020122880664F, -41.67830806393077F, 3.33140251878967F, 2.0153105504384703F, 0.07793653958971522F, -1.5076910311900926F));
        g.addOrReplaceChild("domo_vapor_46", CubeListBuilder.create().texOffs(564, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-23.914727218573105F, -42.82700641892781F, 3.1478321923430737F, 2.07235406286379F, 0.3135853793289681F, -1.3068728009094022F));
        g.addOrReplaceChild("domo_vapor_47", CubeListBuilder.create().texOffs(648, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.4636216324509F, -43.66441492150743F, 2.7850981864066764F, 2.2193117722919813F, 0.552211049209726F, -1.0564587492531117F));
        g.addOrReplaceChild("domo_vapor_48", CubeListBuilder.create().texOffs(658, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.797948012752677F, -44.298319024476406F, 2.2498300227047463F, 2.457496478073951F, 0.7431667356155239F, -0.7548920698606126F));
        g.addOrReplaceChild("domo_vapor_49", CubeListBuilder.create().texOffs(668, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.918570916962636F, -44.72789543167236F, 1.5427228919182443F, 2.823959671813435F, 0.652238486206653F, -0.3181670515745645F));
        g.addOrReplaceChild("domo_vapor_50", CubeListBuilder.create().texOffs(678, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.99710377818451F, -41.67830806393077F, 2.762013415253778F, 2.3302830849543845F, 0.06831031869041833F, -1.4818577445599677F));
        g.addOrReplaceChild("domo_vapor_51", CubeListBuilder.create().texOffs(688, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.721748288514608F, -42.82700641892781F, 2.609818145715403F, 2.391657862350377F, 0.2687057141172321F, -1.205761990707682F));
        g.addOrReplaceChild("domo_vapor_52", CubeListBuilder.create().texOffs(698, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.177647279610014F, -43.66441492150743F, 2.3090810883005988F, 2.533529799367359F, 0.4507998827921537F, -0.8944887459118188F));
        g.addOrReplaceChild("domo_vapor_53", CubeListBuilder.create().texOffs(708, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.37474503405712F, -44.298319024476406F, 1.8652986751684537F, 2.7250090354043888F, 0.5742581234272431F, -0.5830315862737366F));
        g.addOrReplaceChild("domo_vapor_54", CubeListBuilder.create().texOffs(918, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.314084337877365F, -44.72789543167236F, 1.2790472779750928F, 2.9393940767015363F, 0.489854583373519F, -0.26656563032308594F));
        g.addOrReplaceChild("domo_vapor_55", CubeListBuilder.create().texOffs(718, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-25.563569636295288F, -41.67830806393077F, 1.980161479122768F, 2.7019999271206863F, 0.04564237262150373F, -1.460110964819689F));
        g.addOrReplaceChild("domo_vapor_56", CubeListBuilder.create().texOffs(728, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-25.25700016935674F, -42.82700641892781F, 1.871048609366157F, 2.7446160017174264F, 0.17606814415256516F, -1.1260455695172291F));
        g.addOrReplaceChild("domo_vapor_57", CubeListBuilder.create().texOffs(738, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.651220504456717F, -43.66441492150743F, 1.6554421488222961F, 2.834097134314158F, 0.28477709766897935F, -0.7843882718098741F));
        g.addOrReplaceChild("domo_vapor_58", CubeListBuilder.create().texOffs(748, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.75730219646146F, -44.298319024476406F, 1.3372826370895563F, 2.94018744091279F, 0.35067965833674875F, -0.4855789238771981F));
        g.addOrReplaceChild("domo_vapor_59", CubeListBuilder.create().texOffs(926, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.576406240400004F, -44.72789543167236F, 0.9169832904632721F, 3.0389269545932F, 0.33281291717297695F, -0.24051407661671428F));
        g.addOrReplaceChild("domo_vapor_60", CubeListBuilder.create().texOffs(506, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.846996184925892F, -41.67830806393077F, 0.765855128240228F, 3.0498802313511084F, 0.013287935489487913F, -1.4516251854510047F));
        g.addOrReplaceChild("domo_vapor_61", CubeListBuilder.create().texOffs(576, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.52480906033045F, -42.82700641892781F, 0.7236542008203448F, 3.0594442324246924F, 0.051011123147453256F, -1.0964247106279177F));
        g.addOrReplaceChild("domo_vapor_62", CubeListBuilder.create().texOffs(588, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-24.88816898549988F, -43.66441492150743F, 0.6402653887309432F, 3.078865250209807F, 0.08181496133342235F, -0.7471482885328459F));
        g.addOrReplaceChild("domo_vapor_63", CubeListBuilder.create().texOffs(600, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-23.94871153674508F, -44.298319024476406F, 0.5172127507375651F, 3.10100282207387F, 0.10003977800022541F, -0.4554555249376063F));
        g.addOrReplaceChild("domo_vapor_64", CubeListBuilder.create().texOffs(758, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.707656854003034F, -44.72789543167236F, 0.3546561040178457F, 3.1206142960756207F, 0.12687008651096718F, -0.22926941193215308F));
        g.addOrReplaceChild("domo_vapor_65", CubeListBuilder.create().texOffs(514, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.00526492923112F, -44.94529297370636F, 0.13167227700208614F, 3.1365768314625053F, 0.1300509446348353F, -0.05436687767377126F));
        g.addOrReplaceChild("domo_vapor_66", CubeListBuilder.create().texOffs(520, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.846996184925892F, -41.67830806393077F, -0.7658551282115393F, -3.049880231354526F, -0.013287935488988658F, -1.45162518545102F));
        g.addOrReplaceChild("domo_vapor_67", CubeListBuilder.create().texOffs(612, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-25.524809060330455F, -42.82700641892781F, -0.723654200793237F, -3.0594442324277504F, -0.05101112314554114F, -1.0964247106279708F));
        g.addOrReplaceChild("domo_vapor_68", CubeListBuilder.create().texOffs(624, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-24.888168985499888F, -43.66441492150743F, -0.6402653887069591F, -3.0788652502121368F, -0.08181496133036804F, -0.7471482885329098F));
        g.addOrReplaceChild("domo_vapor_69", CubeListBuilder.create().texOffs(636, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-23.948711536745083F, -44.298319024476406F, -0.5172127507181906F, -3.101002822075375F, -0.10003977799650256F, -0.45545552493765856F));
        g.addOrReplaceChild("domo_vapor_70", CubeListBuilder.create().texOffs(768, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.707656854003034F, -44.72789543167236F, -0.35465610400456044F, -3.1206142960764014F, -0.12687008650626536F, -0.2292694119321528F));
        g.addOrReplaceChild("domo_vapor_71", CubeListBuilder.create().texOffs(526, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.00526492923112F, -44.94529297370636F, -0.13167227699715378F, -3.136576831462692F, -0.13005094463001843F, -0.05436687767377127F));
        g.addOrReplaceChild("domo_vapor_72", CubeListBuilder.create().texOffs(778, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-25.56356963629529F, -41.67830806393077F, -1.9801614791227644F, -2.7019999271206827F, -0.045642372621503974F, -1.460110964819689F));
        g.addOrReplaceChild("domo_vapor_73", CubeListBuilder.create().texOffs(788, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-25.25700016935674F, -42.82700641892781F, -1.871048609366154F, -2.7446160017174233F, -0.1760681441525657F, -1.1260455695172296F));
        g.addOrReplaceChild("domo_vapor_74", CubeListBuilder.create().texOffs(798, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.651220504456717F, -43.66441492150743F, -1.6554421488222937F, -2.834097134314157F, -0.28477709766897996F, -0.7843882718098732F));
        g.addOrReplaceChild("domo_vapor_75", CubeListBuilder.create().texOffs(808, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.757302196461463F, -44.298319024476406F, -1.3372826370895543F, -2.9401874409127897F, -0.35067965833674897F, -0.48557892387719953F));
        g.addOrReplaceChild("domo_vapor_76", CubeListBuilder.create().texOffs(934, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.576406240400004F, -44.72789543167236F, -0.9169832904632705F, -3.0389269545932F, -0.3328129171729756F, -0.24051407661671365F));
        g.addOrReplaceChild("domo_vapor_77", CubeListBuilder.create().texOffs(818, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.99710377818451F, -41.67830806393077F, -2.7620134152537763F, -2.330283084954388F, -0.06831031869041801F, -1.4818577445599685F));
        g.addOrReplaceChild("domo_vapor_78", CubeListBuilder.create().texOffs(828, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.72174828851461F, -42.82700641892781F, -2.6098181457154013F, -2.3916578623503812F, -0.26870571411723126F, -1.205761990707681F));
        g.addOrReplaceChild("domo_vapor_79", CubeListBuilder.create().texOffs(838, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.177647279610017F, -43.66441492150743F, -2.3090810883005974F, -2.5335297993673627F, -0.45079988279215283F, -0.8944887459118166F));
        g.addOrReplaceChild("domo_vapor_80", CubeListBuilder.create().texOffs(848, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.37474503405712F, -44.298319024476406F, -1.8652986751684524F, -2.7250090354043883F, -0.5742581234272429F, -0.5830315862737374F));
        g.addOrReplaceChild("domo_vapor_81", CubeListBuilder.create().texOffs(942, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.314084337877365F, -44.72789543167236F, -1.2790472779750919F, -2.9393940767015363F, -0.48985458337351817F, -0.2665656303230855F));
        g.addOrReplaceChild("domo_vapor_82", CubeListBuilder.create().texOffs(648, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-24.143020122880667F, -41.67830806393077F, -3.3314025187896696F, -2.0153105504384703F, -0.077936539589715F, -1.5076910311900935F));
    }

    private static void piezas6(PartDefinition g) {
        g.addOrReplaceChild("domo_vapor_83", CubeListBuilder.create().texOffs(660, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-23.914727218573105F, -42.82700641892781F, -3.147832192343073F, -2.0723540628637895F, -0.3135853793289682F, -1.3068728009094015F));
        g.addOrReplaceChild("domo_vapor_84", CubeListBuilder.create().texOffs(858, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.463621632450895F, -43.66441492150743F, -2.7850981864066755F, -2.2193117722919813F, -0.5522110492097262F, -1.0564587492531112F));
        g.addOrReplaceChild("domo_vapor_85", CubeListBuilder.create().texOffs(868, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.79794801275268F, -44.298319024476406F, -2.249830022704746F, -2.4574964780739506F, -0.7431667356155238F, -0.7548920698606133F));
        g.addOrReplaceChild("domo_vapor_86", CubeListBuilder.create().texOffs(878, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.918570916962636F, -44.72789543167236F, -1.542722891918244F, -2.823959671813436F, -0.6522384862066524F, -0.31816705157456393F));
        g.addOrReplaceChild("domo_vapor_87", CubeListBuilder.create().texOffs(672, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.970242218684152F, -41.67830806393077F, -3.7090464241968597F, -1.7808655407581728F, -0.08010314844514792F, -1.5315332009183482F));
        g.addOrReplaceChild("domo_vapor_88", CubeListBuilder.create().texOffs(684, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.806572914049234F, -42.82700641892781F, -3.504666779571158F, -1.8215746587412593F, -0.3276459677183524F, -1.4045427716552514F));
        g.addOrReplaceChild("domo_vapor_89", CubeListBuilder.create().texOffs(236, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.483163223233444F, -43.66441492150743F, -3.10081366963781F, -1.9354283165548862F, -0.6002966062494474F, -1.2342845935299591F));
        g.addOrReplaceChild("domo_vapor_90", CubeListBuilder.create().texOffs(888, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.005923955634334F, -44.298319024476406F, -2.504868130974307F, -2.153818232350506F, -0.8543232539035999F, -0.9907285670232628F));
        g.addOrReplaceChild("domo_vapor_91", CubeListBuilder.create().texOffs(898, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.375474935694907F, -44.72789543167236F, -1.7176041602666707F, -2.507971599938599F, -1.0400743469827622F, -0.6309664618546162F));
        g.addOrReplaceChild("domo_vapor_92", CubeListBuilder.create().texOffs(746, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.51066910928772F, -44.94529297370636F, -0.6376905633610317F, -3.024620429782125F, -0.892776024131316F, -0.10672111178798221F));
        g.addOrReplaceChild("domo_vapor_93", CubeListBuilder.create().texOffs(856, 716).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-21.148782692367405F, -41.67830806393077F, -3.8979974566172624F, -1.6128835420102636F, -0.07992276899133581F, -1.557398655892359F));
        g.addOrReplaceChild("domo_vapor_94", CubeListBuilder.create().texOffs(872, 716).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-21.085481301237188F, -42.82700641892781F, -3.683206040220302F, -1.6143278556201364F, -0.332430427698868F, -1.556582165665966F));
        g.addOrReplaceChild("domo_vapor_95", CubeListBuilder.create().texOffs(708, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-20.96039808310232F, -43.66441492150743F, -3.258779323666589F, -1.6216419002773763F, -0.627713786764773F, -1.5409180642593303F));
        g.addOrReplaceChild("domo_vapor_96", CubeListBuilder.create().texOffs(720, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-20.775819126111116F, -44.298319024476406F, -2.6324743578300533F, -1.7746037615789094F, -0.9268292249825171F, -1.3478221016564307F));
        g.addOrReplaceChild("domo_vapor_97", CubeListBuilder.create().texOffs(696, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.53198415603004F, -44.72789543167236F, -1.805104569335355F, -2.001936660921905F, -1.20278912537103F, -1.1269938448791363F));
        g.addOrReplaceChild("domo_vapor_98", CubeListBuilder.create().texOffs(950, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.197508415504345F, -44.94529297370636F, -0.6701766194874135F, -2.8631095031071903F, -1.27402022028536F, -0.2702114535785593F));
        g.addOrReplaceChild("domo_vapor_99", CubeListBuilder.create().texOffs(888, 716).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-18.85121730768975F, -41.67830806393077F, -3.8979974566172633F, -1.5287091115816223F, -0.07992276899129555F, -1.5841939976967663F));
        g.addOrReplaceChild("domo_vapor_100", CubeListBuilder.create().texOffs(904, 716).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-18.914518698816817F, -42.82700641892781F, -3.6832060402203024F, -1.5272647979718252F, -0.3324304276985551F, -1.5850104879231057F));
        g.addOrReplaceChild("domo_vapor_101", CubeListBuilder.create().texOffs(732, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.039601916945465F, -43.66441492150743F, -3.25877932366659F, -1.5199507533149619F, -0.6277137867643074F, -1.6006745893289465F));
        g.addOrReplaceChild("domo_vapor_102", CubeListBuilder.create().texOffs(744, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.224180873927484F, -44.298319024476406F, -2.6324743578300533F, -1.366988892020612F, -0.9268292249834195F, -1.7937705519227618F));
        g.addOrReplaceChild("domo_vapor_103", CubeListBuilder.create().texOffs(708, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.46801584399643F, -44.72789543167236F, -1.805104569335355F, -1.1396559926862848F, -1.202789125373879F, -2.014598808691695F));
        g.addOrReplaceChild("domo_vapor_104", CubeListBuilder.create().texOffs(958, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.802491584505482F, -44.94529297370636F, -0.6701766194874136F, -0.2784831504950249F, -1.2740202202982835F, -2.8713811999984338F));
        g.addOrReplaceChild("domo_vapor_105", CubeListBuilder.create().texOffs(720, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.02975778131585F, -41.67830806393077F, -3.709046424196861F, -1.3607271128316214F, -0.08010314844514792F, -1.610059452671445F));
        g.addOrReplaceChild("domo_vapor_106", CubeListBuilder.create().texOffs(732, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.19342708595077F, -42.82700641892781F, -3.50466677957116F, -1.3200179948485349F, -0.3276459677183525F, -1.737049881934542F));
        g.addOrReplaceChild("domo_vapor_107", CubeListBuilder.create().texOffs(246, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.51683677676656F, -43.66441492150743F, -3.1008136696378115F, -1.206164337034908F, -0.6002966062494475F, -1.9073080600598338F));
        g.addOrReplaceChild("domo_vapor_108", CubeListBuilder.create().texOffs(908, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.994076044365666F, -44.298319024476406F, -2.504868130974308F, -0.9877744212392884F, -0.8543232539036005F, -2.150864086566529F));
        g.addOrReplaceChild("domo_vapor_109", CubeListBuilder.create().texOffs(918, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.624525064305093F, -44.72789543167236F, -1.7176041602666712F, -0.6336210536511943F, -1.0400743469827625F, -2.5106261917351764F));
        g.addOrReplaceChild("domo_vapor_110", CubeListBuilder.create().texOffs(756, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.48933089071228F, -44.94529297370636F, -0.6376905633610318F, -0.11697222380766827F, -0.892776024131318F, -3.034871541801811F));
        g.addOrReplaceChild("domo_vapor_111", CubeListBuilder.create().texOffs(744, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.856979877119336F, -41.67830806393077F, -3.3314025187896705F, -1.1262821031513226F, -0.07793653958971498F, -1.6339016223996998F));
        g.addOrReplaceChild("domo_vapor_112", CubeListBuilder.create().texOffs(756, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.085272781426898F, -42.82700641892781F, -3.147832192343074F, -1.0692385907260036F, -0.3135853793289684F, -1.8347198526803918F));
        g.addOrReplaceChild("domo_vapor_113", CubeListBuilder.create().texOffs(928, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.536378367549105F, -43.66441492150743F, -2.7850981864066773F, -0.9222808812978133F, -0.5522110492097265F, -2.0851339043366814F));
        g.addOrReplaceChild("domo_vapor_114", CubeListBuilder.create().texOffs(938, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.202051987247323F, -44.298319024476406F, -2.2498300227047467F, -0.684096175515844F, -0.7431667356155243F, -2.3867005837291795F));
        g.addOrReplaceChild("domo_vapor_115", CubeListBuilder.create().texOffs(948, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.081429083037364F, -44.72789543167236F, -1.5427228919182445F, -0.3176329817763582F, -0.6522384862066525F, -2.823425602015229F));
        g.addOrReplaceChild("domo_vapor_116", CubeListBuilder.create().texOffs(958, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.002896221815497F, -41.67830806393077F, -2.7620134152537785F, -0.8113095686354065F, -0.0683103186904182F, -1.6597349090298252F));
        g.addOrReplaceChild("domo_vapor_117", CubeListBuilder.create().texOffs(968, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.27825171148539F, -42.82700641892781F, -2.6098181457154035F, -0.7499347912394141F, -0.26870571411723154F, -1.9358306628821105F));
        g.addOrReplaceChild("domo_vapor_118", CubeListBuilder.create().texOffs(978, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.822352720389986F, -43.66441492150743F, -2.309081088300599F, -0.6080628542224328F, -0.45079988279215355F, -2.247103907677975F));
        g.addOrReplaceChild("domo_vapor_119", CubeListBuilder.create().texOffs(988, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.62525496594288F, -44.298319024476406F, -1.865298675168454F, -0.4165836181854043F, -0.5742581234272429F, -2.558561067316057F));
        g.addOrReplaceChild("domo_vapor_120", CubeListBuilder.create().texOffs(966, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.685915662122635F, -44.72789543167236F, -1.279047277975093F, -0.20219857688825693F, -0.489854583373519F, -2.8750270232667074F));
        g.addOrReplaceChild("domo_vapor_121", CubeListBuilder.create().texOffs(998, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.436430363704712F, -41.67830806393077F, -1.9801614791227689F, -0.43959272646911046F, -0.04564237262150413F, -1.6814816887701047F));
        g.addOrReplaceChild("domo_vapor_122", CubeListBuilder.create().texOffs(1008, 799).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.742999830643264F, -42.82700641892781F, -1.871048609366158F, -0.39697665187236947F, -0.17606814415256547F, -2.0155470840725624F));
        g.addOrReplaceChild("domo_vapor_123", CubeListBuilder.create().texOffs(0, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.348779495543285F, -43.66441492150743F, -1.655442148822297F, -0.30749551927563595F, -0.28477709766897963F, -2.357204381779919F));
        g.addOrReplaceChild("domo_vapor_124", CubeListBuilder.create().texOffs(10, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.24269780353854F, -44.298319024476406F, -1.337282637089557F, -0.20140521267700345F, -0.35067965833674913F, -2.656013729712595F));
        g.addOrReplaceChild("domo_vapor_125", CubeListBuilder.create().texOffs(974, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.423593759599996F, -44.72789543167236F, -0.9169832904632726F, -0.1026656989965934F, -0.3328129171729771F, -2.901078576973079F));
        g.addOrReplaceChild("domo_vapor_126", CubeListBuilder.create().texOffs(534, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-14.153003815074108F, -41.67830806393077F, -0.7658551282491866F, -0.09171242223975136F, -0.013287935489643759F, -1.6899674681387935F));
        g.addOrReplaceChild("domo_vapor_127", CubeListBuilder.create().texOffs(768, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-14.475190939669549F, -42.82700641892781F, -0.7236542008288097F, -0.08214842116605478F, -0.05101112314805012F, -2.0451679429618923F));
        g.addOrReplaceChild("domo_vapor_128", CubeListBuilder.create().texOffs(780, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.111831014500115F, -43.66441492150743F, -0.6402653887384329F, -0.06272740338071278F, -0.08181496133437577F, -2.3944443650569682F));
        g.addOrReplaceChild("domo_vapor_129", CubeListBuilder.create().texOffs(792, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.05128846325492F, -44.298319024476406F, -0.5172127507436153F, -0.0405898315163924F, -0.10003977800138736F, -2.6861371286522027F));
        g.addOrReplaceChild("domo_vapor_130", CubeListBuilder.create().texOffs(20, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.292343145996966F, -44.72789543167236F, -0.35465610402199427F, -0.020978357514416162F, -0.12687008651243536F, -2.9123232416576403F));
        g.addOrReplaceChild("domo_vapor_131", CubeListBuilder.create().texOffs(538, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.99473507076888F, -44.94529297370636F, -0.13167227700362638F, -0.005015822127345983F, -0.13005094463633946F, -3.0872257759160218F));
        g.addOrReplaceChild("domo_arena2_0", CubeListBuilder.create().texOffs(548, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(16.82149554908021F, -41.59351955593942F, 0.7658551282258839F, 0.1063063982082435F, 0.017341220414173207F, -1.7288727740268326F));
        g.addOrReplaceChild("domo_arena2_1", CubeListBuilder.create().texOffs(804, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.445610570385526F, -42.598630616561834F, 0.723654200806791F, 0.08881847387048886F, 0.062093060879785014F, -2.170421474839431F));
        g.addOrReplaceChild("domo_arena2_2", CubeListBuilder.create().texOffs(816, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.702863816416532F, -43.331363056319F, 0.6402653887189512F, 0.061404853150623905F, 0.09018894671497364F, -2.533704121888088F));
        g.addOrReplaceChild("domo_arena2_3", CubeListBuilder.create().texOffs(828, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.606830126202594F, -43.88602914641685F, 0.517212750727878F, 0.03710834472946242F, 0.10302877946070531F, -2.789047299922215F));
        g.addOrReplaceChild("domo_arena2_4", CubeListBuilder.create().texOffs(240, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.15893299633687F, -44.26190850271332F, 0.35465610401120307F, 0.01852582179448102F, 0.11014209461223352F, -2.968318228394122F));
        g.addOrReplaceChild("domo_arena2_5", CubeListBuilder.create().texOffs(550, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.172809084102974F, -44.45213135199306F, 0.13167227699961997F, 0.004381849465865326F, 0.1117104367737082F, -3.100799916042757F));
        g.addOrReplaceChild("domo_arena2_6", CubeListBuilder.create().texOffs(840, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.490831242344505F, -41.59351955593942F, 1.9801614791227664F, 0.49943975524398004F, 0.059964068547562595F, -1.7135101880717842F));
        g.addOrReplaceChild("domo_arena2_7", CubeListBuilder.create().texOffs(310, 802).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.133166864249528F, -42.598630616561834F, 1.8710486093661558F, 0.42530453322997336F, 0.2180869303556845F, -2.1229590787379413F));
        g.addOrReplaceChild("domo_arena2_8", CubeListBuilder.create().texOffs(30, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.426423921866169F, -43.331363056319F, 1.6554421488222955F, 0.30129945060776275F, 0.323055935073626F, -2.484046144070343F));
        g.addOrReplaceChild("domo_arena2_9", CubeListBuilder.create().texOffs(40, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.383519229205039F, -43.88602914641685F, 1.3372826370895554F, 0.18483065286163233F, 0.37346075400362516F, -2.7538940743348017F));
        g.addOrReplaceChild("domo_arena2_10", CubeListBuilder.create().texOffs(766, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(13.005807280466673F, -44.26190850271332F, 0.9169832904632714F, 0.08952664524891395F, 0.29149048875815836F, -2.9596799816136476F));
        g.addOrReplaceChild("domo_arena2_11", CubeListBuilder.create().texOffs(852, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.829954407881923F, -41.59351955593942F, 2.7620134152537776F, 0.8847683966059876F, 0.08438772665045209F, -1.6810645805168447F));
        g.addOrReplaceChild("domo_arena2_12", CubeListBuilder.create().texOffs(256, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.50870633660038F, -42.598630616561834F, 2.609818145715402F, 0.7870679376106251F, 0.31958253345362597F, -2.012894677381925F));
        g.addOrReplaceChild("domo_arena2_13", CubeListBuilder.create().texOffs(50, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.873921826211681F, -43.331363056319F, 2.3090810883005983F, 0.5963305050920963F, 0.5022144647947391F, -2.351675167236507F));
        g.addOrReplaceChild("domo_arena2_14", CubeListBuilder.create().texOffs(60, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.937202539733306F, -43.88602914641685F, 1.865298675168453F, 0.38461498481160306F, 0.6052234955087744F, -2.650277273841465F));
        g.addOrReplaceChild("domo_arena2_15", CubeListBuilder.create().texOffs(776, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.699765060856926F, -44.26190850271332F, 1.279047277975092F, 0.1735079219998871F, 0.434541361886448F, -2.9395877687618337F));
        g.addOrReplaceChild("domo_arena2_16", CubeListBuilder.create().texOffs(864, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.833523476694111F, -41.59351955593942F, 3.3314025187896696F, 1.1807472069076628F, 0.0914730098602353F, -1.648518837986345F));
        g.addOrReplaceChild("domo_arena2_17", CubeListBuilder.create().texOffs(266, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.567181755001956F, -42.598630616561834F, 3.147832192343073F, 1.0949821843013847F, 0.3593321341197578F, -1.89057211356328F));
        g.addOrReplaceChild("domo_arena2_18", CubeListBuilder.create().texOffs(876, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.040891904526047F, -43.331363056319F, 2.7850981864066755F, 0.8999559454600516F, 0.6033195193025513F, -2.1725151496343207F));
        g.addOrReplaceChild("domo_arena2_19", CubeListBuilder.create().texOffs(70, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.264272681544794F, -43.88602914641685F, 2.2498300227047463F, 0.6311743610305368F, 0.7724212580152208F, -2.480154912985848F));
        g.addOrReplaceChild("domo_arena2_20", CubeListBuilder.create().texOffs(80, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.238332736456412F, -44.26190850271332F, 1.542722891918244F, 0.2671965520379578F, 0.5896969964311092F, -2.89942320382209F));
        g.addOrReplaceChild("domo_arena2_21", CubeListBuilder.create().texOffs(562, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.831020148133968F, -44.45213135199306F, 0.5727628360568049F, 0.06387156514565406F, 0.6026865009580076F, -3.08405396431169F));
        g.addOrReplaceChild("domo_arena2_22", CubeListBuilder.create().texOffs(562, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(13.465282588464841F, -41.59351955593942F, 3.70904642419686F, 1.388362407651256F, 0.09199686630712586F, -1.6200549863013392F));
        g.addOrReplaceChild("domo_arena2_23", CubeListBuilder.create().texOffs(756, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(13.274335066390773F, -42.598630616561834F, 3.504666779571158F, 1.3279901424616887F, 0.3701595284991956F, -1.7772476489482132F));
        g.addOrReplaceChild("domo_arena2_24", CubeListBuilder.create().texOffs(276, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.897023760439016F, -43.331363056319F, 3.1008136696378106F, 1.1738023331747576F, 0.6538616217372165F, -1.9791120227842862F));
        g.addOrReplaceChild("domo_arena2_25", CubeListBuilder.create().texOffs(888, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.340244614906723F, -43.88602914641685F, 2.504868130974307F, 0.914024452573079F, 0.8889453868902242F, -2.248507404368447F));
        g.addOrReplaceChild("domo_arena2_26", CubeListBuilder.create().texOffs(90, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.604720758310725F, -44.26190850271332F, 1.7176041602666707F, 0.5519059748483929F, 1.040350068204514F, -2.603682924532266F));
        g.addOrReplaceChild("domo_arena2_27", CubeListBuilder.create().texOffs(786, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.595780627502341F, -44.45213135199306F, 0.6376905633610317F, 0.09386615044579615F, 0.8177571792018357F, -3.061418781422003F));
        g.addOrReplaceChild("domo_arena2_28", CubeListBuilder.create().texOffs(72, 716).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(11.34024647441075F, -41.59351955593942F, 3.8979974566172624F, 1.5353730754073647F, 0.09180005121860314F, -1.5740449651379116F));
        g.addOrReplaceChild("domo_arena2_29", CubeListBuilder.create().texOffs(208, 716).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(11.266394851426485F, -42.598630616561834F, 3.683206040220302F, 1.532872296186219F, 0.3759653144199257F, -1.5847266937991096F));
        g.addOrReplaceChild("domo_arena2_30", CubeListBuilder.create().texOffs(976, 716).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(11.120464430271085F, -43.331363056319F, 3.258779323666589F, 1.5249559860545225F, 0.6925699879103443F, -1.6000783186506589F));
        g.addOrReplaceChild("domo_arena2_31", CubeListBuilder.create().texOffs(768, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.905122313784222F, -43.88602914641685F, 2.6324743578300533F, 1.314247203651368F, 0.982568319764085F, -1.8538064806450085F));
        g.addOrReplaceChild("domo_arena2_32", CubeListBuilder.create().texOffs(900, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.620648182026763F, -44.26190850271332F, 1.805104569335355F, 1.0394767832826994F, 1.228175731201096F, -2.1179661653808326F));
        g.addOrReplaceChild("domo_arena2_33", CubeListBuilder.create().texOffs(982, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.230426484751991F, -44.45213135199306F, 0.6701766194874135F, 0.21409228772637354F, 1.2330793779131022F, -2.9367666077280976F));
        g.addOrReplaceChild("domo_arena2_34", CubeListBuilder.create().texOffs(90, 716).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(8.659753525620156F, -41.59351955593942F, 3.8979974566172633F, 1.606219578181612F, 0.09180005121855793F, -1.5675476884519584F));
        g.addOrReplaceChild("domo_arena2_35", CubeListBuilder.create().texOffs(224, 716).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(8.733605148602717F, -42.598630616561834F, 3.6832060402203024F, 1.6087203574026976F, 0.37596531441975795F, -1.5568659597910117F));
        g.addOrReplaceChild("domo_arena2_36", CubeListBuilder.create().texOffs(990, 716).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(8.879535569754754F, -43.331363056319F, 3.25877932366659F, 1.616636667534205F, 0.6925699879101107F, -1.5415143349398241F));
        g.addOrReplaceChild("domo_arena2_37", CubeListBuilder.create().texOffs(780, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(9.09487768623665F, -43.88602914641685F, 2.6324743578300533F, 1.8273454499329358F, 0.9825683197647778F, -1.2877861729508269F));
        g.addOrReplaceChild("domo_arena2_38", CubeListBuilder.create().texOffs(912, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(9.379351817987551F, -44.26190850271332F, 1.805104569335355F, 2.1021158702974763F, 1.2281757312029298F, -1.0236264882189021F));
        g.addOrReplaceChild("domo_arena2_39", CubeListBuilder.create().texOffs(990, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.769573515253322F, -44.45213135199306F, 0.6701766194874136F, 2.9275003658590215F, 1.2330793779200122F, -0.20482604586628772F));
        g.addOrReplaceChild("domo_arena2_40", CubeListBuilder.create().texOffs(576, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.534717411535161F, -41.59351955593942F, 3.709046424196861F, 1.7532302459385372F, 0.09199686630712582F, -1.5215376672884544F));
    }

    private static void piezas7(PartDefinition g) {
        g.addOrReplaceChild("domo_arena2_41", CubeListBuilder.create().texOffs(792, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.725664933609229F, -42.598630616561834F, 3.504666779571159F, 1.8136025111281042F, 0.3701595284991956F, -1.3643450046415808F));
        g.addOrReplaceChild("domo_arena2_42", CubeListBuilder.create().texOffs(286, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(7.102976239560984F, -43.331363056319F, 3.1008136696378115F, 1.967790320415036F, 0.6538616217372165F, -1.1624806308055067F));
        g.addOrReplaceChild("domo_arena2_43", CubeListBuilder.create().texOffs(924, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(7.65975538509328F, -43.88602914641685F, 2.5048681309743075F, 2.2275682010167146F, 0.8889453868902246F, -0.8930852492213466F));
        g.addOrReplaceChild("domo_arena2_44", CubeListBuilder.create().texOffs(100, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.395279241689277F, -44.26190850271332F, 1.717604160266671F, 2.5896866787414003F, 1.0403500682045144F, -0.5379097290575274F));
        g.addOrReplaceChild("domo_arena2_45", CubeListBuilder.create().texOffs(796, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.404219372497659F, -44.45213135199306F, 0.6376905633610318F, 3.047726503143997F, 0.8177571792018361F, -0.08017387216779064F));
        g.addOrReplaceChild("domo_arena2_46", CubeListBuilder.create().texOffs(936, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.1664765233058905F, -41.59351955593942F, 3.33140251878967F, 1.9608454466821303F, 0.09147300986023515F, -1.4930738156034489F));
        g.addOrReplaceChild("domo_arena2_47", CubeListBuilder.create().texOffs(296, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.432818244998047F, -42.598630616561834F, 3.1478321923430737F, 2.0466104692884084F, 0.3593321341197578F, -1.2510205400265133F));
        g.addOrReplaceChild("domo_arena2_48", CubeListBuilder.create().texOffs(948, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.959108095473955F, -43.331363056319F, 2.7850981864066764F, 2.2416367081297417F, 0.6033195193025513F, -0.9690775039554725F));
        g.addOrReplaceChild("domo_arena2_49", CubeListBuilder.create().texOffs(110, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.735727318455208F, -43.88602914641685F, 2.2498300227047463F, 2.5104182925592564F, 0.7724212580152209F, -0.6614377406039456F));
        g.addOrReplaceChild("domo_arena2_50", CubeListBuilder.create().texOffs(120, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.761667263543589F, -44.26190850271332F, 1.5427228919182443F, 2.874396101551835F, 0.5896969964311096F, -0.24216944976770344F));
        g.addOrReplaceChild("domo_arena2_51", CubeListBuilder.create().texOffs(574, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.168979851866032F, -44.45213135199306F, 0.572762836056805F, 3.077721088444139F, 0.6026865009580079F, -0.057538689278103405F));
        g.addOrReplaceChild("domo_arena2_52", CubeListBuilder.create().texOffs(960, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(4.170045592118078F, -41.59351955593942F, 2.762013415253778F, 2.2568242569838044F, 0.08438772665045177F, -1.4605280730729495F));
        g.addOrReplaceChild("domo_arena2_53", CubeListBuilder.create().texOffs(306, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(4.491293663399622F, -42.598630616561834F, 2.609818145715403F, 2.3545247159791676F, 0.3195825334536262F, -1.1286979762078684F));
        g.addOrReplaceChild("domo_arena2_54", CubeListBuilder.create().texOffs(130, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.126078173788317F, -43.331363056319F, 2.3090810883005988F, 2.5452621484976965F, 0.5022144647947393F, -0.7899174863532864F));
        g.addOrReplaceChild("domo_arena2_55", CubeListBuilder.create().texOffs(140, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.062797460266695F, -43.88602914641685F, 1.8652986751684537F, 2.7569776687781893F, 0.605223495508775F, -0.49131537974832856F));
        g.addOrReplaceChild("domo_arena2_56", CubeListBuilder.create().texOffs(806, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.300234939143072F, -44.26190850271332F, 1.2790472779750928F, 2.9680847315899057F, 0.4345413618864484F, -0.20200488482795975F));
        g.addOrReplaceChild("domo_arena2_57", CubeListBuilder.create().texOffs(972, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.5091687576554946F, -41.59351955593942F, 1.980161479122768F, 2.6421528983458122F, 0.05996406854756236F, -1.42808246551801F));
        g.addOrReplaceChild("domo_arena2_58", CubeListBuilder.create().texOffs(318, 802).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.866833135750473F, -42.598630616561834F, 1.871048609366157F, 2.716288120359819F, 0.21808693035568494F, -1.0186335748518518F));
        g.addOrReplaceChild("domo_arena2_59", CubeListBuilder.create().texOffs(150, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.573576078133832F, -43.331363056319F, 1.6554421488222961F, 2.8402932029820303F, 0.3230559350736263F, -0.6575465095194503F));
        g.addOrReplaceChild("domo_arena2_60", CubeListBuilder.create().texOffs(160, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.616480770794963F, -43.88602914641685F, 1.3372826370895563F, 2.956762000728161F, 0.37346075400362516F, -0.3876985792549914F));
        g.addOrReplaceChild("domo_arena2_61", CubeListBuilder.create().texOffs(816, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.994192719533326F, -44.26190850271332F, 0.9169832904632721F, 3.052066008340879F, 0.29149048875815864F, -0.18191267197614563F));
        g.addOrReplaceChild("domo_arena2_62", CubeListBuilder.create().texOffs(590, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.178504450919791F, -41.59351955593942F, 0.765855128240228F, 3.035286255379574F, 0.017341220414498107F, -1.4127198795629605F));
        g.addOrReplaceChild("domo_arena2_63", CubeListBuilder.create().texOffs(984, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.5543894296144716F, -42.598630616561834F, 0.7236542008203448F, 3.0527741797176557F, 0.06209306088094543F, -0.9711711787503581F));
        g.addOrReplaceChild("domo_arena2_64", CubeListBuilder.create().texOffs(996, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(4.2971361835834685F, -43.331363056319F, 0.6402653887309432F, 3.0801878004380314F, 0.09018894671665419F, -0.6078885317017013F));
        g.addOrReplaceChild("domo_arena2_65", CubeListBuilder.create().texOffs(1008, 782).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.393169873797407F, -43.88602914641685F, 0.5172127507375651F, 3.1044843088596434F, 0.10302877946262172F, -0.35254535366757545F));
        g.addOrReplaceChild("domo_arena2_66", CubeListBuilder.create().texOffs(252, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.841067003663129F, -44.26190850271332F, 0.3546561040178457F, 3.123066831794969F, 0.11014209461427979F, -0.17327442519567135F));
        g.addOrReplaceChild("domo_arena2_67", CubeListBuilder.create().texOffs(586, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.827190915897027F, -44.45213135199306F, 0.13167227700208614F, 3.1372108041238467F, 0.11171043677578314F, -0.04079273754703598F));
        g.addOrReplaceChild("domo_arena2_68", CubeListBuilder.create().texOffs(604, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.17850445091979F, -41.59351955593942F, -0.7658551282115393F, -3.0352862553835256F, -0.017341220413848307F, -1.4127198795629627F));
        g.addOrReplaceChild("domo_arena2_69", CubeListBuilder.create().texOffs(0, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.5543894296144707F, -42.598630616561834F, -0.723654200793237F, -3.052774179720953F, -0.062093060878624526F, -0.9711711787503663F));
        g.addOrReplaceChild("domo_arena2_70", CubeListBuilder.create().texOffs(12, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(4.2971361835834685F, -43.331363056319F, -0.6402653887069591F, -3.0801878004403074F, -0.09018894671329333F, -0.6078885317017088F));
        g.addOrReplaceChild("domo_arena2_71", CubeListBuilder.create().texOffs(24, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.393169873797406F, -43.88602914641685F, -0.5172127507181906F, -3.104484308861018F, -0.10302877945878906F, -0.3525453536675809F));
        g.addOrReplaceChild("domo_arena2_72", CubeListBuilder.create().texOffs(264, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.841067003663129F, -44.26190850271332F, -0.35465610400456044F, -3.1230668317956556F, -0.11014209461018716F, -0.1732744251956713F));
        g.addOrReplaceChild("domo_arena2_73", CubeListBuilder.create().texOffs(598, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.827190915897026F, -44.45213135199306F, -0.13167227699715378F, -3.137210804124009F, -0.11171043677163325F, -0.04079273754703598F));
        g.addOrReplaceChild("domo_arena2_74", CubeListBuilder.create().texOffs(36, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.509168757655493F, -41.59351955593942F, -1.9801614791227644F, -2.6421528983458122F, -0.05996406854756244F, -1.42808246551801F));
        g.addOrReplaceChild("domo_arena2_75", CubeListBuilder.create().texOffs(326, 802).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.8668331357504706F, -42.598630616561834F, -1.871048609366154F, -2.71628812035982F, -0.21808693035568452F, -1.0186335748518522F));
        g.addOrReplaceChild("domo_arena2_76", CubeListBuilder.create().texOffs(170, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.57357607813383F, -43.331363056319F, -1.6554421488222937F, -2.8402932029820307F, -0.3230559350736258F, -0.6575465095194498F));
        g.addOrReplaceChild("domo_arena2_77", CubeListBuilder.create().texOffs(180, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.616480770794962F, -43.88602914641685F, -1.3372826370895543F, -2.956762000728161F, -0.3734607540036253F, -0.3876985792549915F));
        g.addOrReplaceChild("domo_arena2_78", CubeListBuilder.create().texOffs(826, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(6.994192719533325F, -44.26190850271332F, -0.9169832904632705F, -3.052066008340879F, -0.2914904887581579F, -0.1819126719761455F));
        g.addOrReplaceChild("domo_arena2_79", CubeListBuilder.create().texOffs(48, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(4.1700455921180755F, -41.59351955593942F, -2.7620134152537763F, -2.2568242569838066F, -0.08438772665045173F, -1.4605280730729495F));
        g.addOrReplaceChild("domo_arena2_80", CubeListBuilder.create().texOffs(316, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(4.49129366339962F, -42.598630616561834F, -2.6098181457154013F, -2.3545247159791693F, -0.31958253345362586F, -1.128697976207868F));
        g.addOrReplaceChild("domo_arena2_81", CubeListBuilder.create().texOffs(190, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.126078173788316F, -43.331363056319F, -2.3090810883005974F, -2.545262148497698F, -0.5022144647947389F, -0.7899174863532855F));
        g.addOrReplaceChild("domo_arena2_82", CubeListBuilder.create().texOffs(200, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.062797460266694F, -43.88602914641685F, -1.8652986751684524F, -2.7569776687781906F, -0.605223495508774F, -0.49131537974832795F));
        g.addOrReplaceChild("domo_arena2_83", CubeListBuilder.create().texOffs(836, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.300234939143072F, -44.26190850271332F, -1.2790472779750919F, -2.9680847315899066F, -0.43454136188644776F, -0.20200488482795964F));
        g.addOrReplaceChild("domo_arena2_84", CubeListBuilder.create().texOffs(60, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.166476523305888F, -41.59351955593942F, -3.3314025187896696F, -1.9608454466821306F, -0.0914730098602351F, -1.4930738156034489F));
        g.addOrReplaceChild("domo_arena2_85", CubeListBuilder.create().texOffs(326, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.432818244998044F, -42.598630616561834F, -3.147832192343073F, -2.046610469288409F, -0.3593321341197577F, -1.251020540026513F));
        g.addOrReplaceChild("domo_arena2_86", CubeListBuilder.create().texOffs(72, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.959108095473951F, -43.331363056319F, -2.7850981864066755F, -2.2416367081297426F, -0.6033195193025515F, -0.9690775039554722F));
        g.addOrReplaceChild("domo_arena2_87", CubeListBuilder.create().texOffs(210, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.735727318455206F, -43.88602914641685F, -2.249830022704746F, -2.510418292559257F, -0.7724212580152208F, -0.661437740603945F));
        g.addOrReplaceChild("domo_arena2_88", CubeListBuilder.create().texOffs(220, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.761667263543588F, -44.26190850271332F, -1.542722891918244F, -2.8743961015518353F, -0.5896969964311093F, -0.24216944976770327F));
        g.addOrReplaceChild("domo_arena2_89", CubeListBuilder.create().texOffs(610, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.16897985186603F, -44.45213135199306F, -0.5727628360568049F, -3.0777210884441395F, -0.6026865009580075F, -0.05753868927810338F));
        g.addOrReplaceChild("domo_arena2_90", CubeListBuilder.create().texOffs(618, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.534717411535155F, -41.59351955593942F, -3.7090464241968597F, -1.7532302459385378F, -0.09199686630712586F, -1.5215376672884542F));
        g.addOrReplaceChild("domo_arena2_91", CubeListBuilder.create().texOffs(804, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.725664933609224F, -42.598630616561834F, -3.504666779571158F, -1.8136025111281049F, -0.3701595284991955F, -1.3643450046415802F));
        g.addOrReplaceChild("domo_arena2_92", CubeListBuilder.create().texOffs(336, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(7.102976239560981F, -43.331363056319F, -3.10081366963781F, -1.9677903204150364F, -0.6538616217372167F, -1.1624806308055062F));
        g.addOrReplaceChild("domo_arena2_93", CubeListBuilder.create().texOffs(84, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(7.659755385093275F, -43.88602914641685F, -2.504868130974307F, -2.227568201016715F, -0.8889453868902242F, -0.8930852492213461F));
        g.addOrReplaceChild("domo_arena2_94", CubeListBuilder.create().texOffs(230, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.395279241689273F, -44.26190850271332F, -1.7176041602666707F, -2.5896866787414012F, -1.0403500682045133F, -0.5379097290575267F));
        g.addOrReplaceChild("domo_arena2_95", CubeListBuilder.create().texOffs(846, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.404219372497659F, -44.45213135199306F, -0.6376905633610317F, -3.047726503143997F, -0.8177571792018353F, -0.08017387216779051F));
        g.addOrReplaceChild("domo_arena2_96", CubeListBuilder.create().texOffs(108, 716).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(8.659753525571361F, -41.59351955593942F, -3.8979974566172624F, -1.606219578182901F, -0.09180005121862932F, -1.5675476884518376F));
        g.addOrReplaceChild("domo_arena2_97", CubeListBuilder.create().texOffs(240, 716).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(8.733605148556611F, -42.598630616561834F, -3.683206040220302F, -1.6087203574040814F, -0.3759653144200227F, -1.5568659597904937F));
        g.addOrReplaceChild("domo_arena2_98", CubeListBuilder.create().texOffs(1004, 716).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(8.879535569713962F, -43.331363056319F, -3.258779323666589F, -1.6166366675358874F, -0.6925699879104795F, -1.5415143349387355F));
        g.addOrReplaceChild("domo_arena2_99", CubeListBuilder.create().texOffs(816, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(9.094877686203697F, -43.88602914641685F, -2.6324743578300533F, -1.827345449941601F, -0.9825683197636841F, -1.2877861729412892F));
        g.addOrReplaceChild("domo_arena2_100", CubeListBuilder.create().texOffs(96, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(9.379351817964954F, -44.26190850271332F, -1.805104569335355F, -2.1021158703126632F, -1.2281757312000325F, -1.0236264882032033F));
        g.addOrReplaceChild("domo_arena2_101", CubeListBuilder.create().texOffs(998, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.769573515244932F, -44.45213135199306F, -0.6701766194874135F, -2.9275003658659653F, -1.233079377909102F, -0.20482604585903774F));
        g.addOrReplaceChild("domo_arena2_102", CubeListBuilder.create().texOffs(126, 716).addBox(-1.5F, -1.0F, -3.0F, 3.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(11.340246474361956F, -41.59351955593942F, -3.8979974566172633F, -1.5353730754086536F, -0.09180005121853176F, -1.5740449651377906F));
        g.addOrReplaceChild("domo_arena2_103", CubeListBuilder.create().texOffs(256, 716).addBox(-1.0F, -1.0F, -3.0F, 2.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(11.266394851380381F, -42.598630616561834F, -3.6832060402203024F, -1.532872296187603F, -0.37596531441966097F, -1.5847266937985915F));
        g.addOrReplaceChild("domo_arena2_104", CubeListBuilder.create().texOffs(0, 723).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(11.120464430230292F, -43.331363056319F, -3.25877932366659F, -1.5249559860562047F, -0.6925699879099755F, -1.6000783186495702F));
        g.addOrReplaceChild("domo_arena2_105", CubeListBuilder.create().texOffs(828, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.90512231375127F, -43.88602914641685F, -2.6324743578300533F, -1.3142472036600343F, -0.9825683197651782F, -1.85380648063547F));
        g.addOrReplaceChild("domo_arena2_106", CubeListBuilder.create().texOffs(108, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.620648182004166F, -44.26190850271332F, -1.805104569335355F, -1.0394767832978846F, -1.2281757312039914F, -2.117966165365136F));
        g.addOrReplaceChild("domo_arena2_107", CubeListBuilder.create().texOffs(1006, 807).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.230426484743603F, -44.45213135199306F, -0.6701766194874136F, -0.21409228773331748F, -1.2330793779240123F, -2.9367666077208474F));
        g.addOrReplaceChild("domo_arena2_108", CubeListBuilder.create().texOffs(632, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(13.465282588464838F, -41.59351955593942F, -3.709046424196861F, -1.3883624076512564F, -0.09199686630712586F, -1.6200549863013392F));
        g.addOrReplaceChild("domo_arena2_109", CubeListBuilder.create().texOffs(840, 723).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(13.274335066390769F, -42.598630616561834F, -3.50466677957116F, -1.3279901424616893F, -0.3701595284991956F, -1.7772476489482123F));
        g.addOrReplaceChild("domo_arena2_110", CubeListBuilder.create().texOffs(346, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.897023760439012F, -43.331363056319F, -3.1008136696378115F, -1.1738023331747576F, -0.6538616217372167F, -1.9791120227842864F));
        g.addOrReplaceChild("domo_arena2_111", CubeListBuilder.create().texOffs(120, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.34024461490672F, -43.88602914641685F, -2.504868130974308F, -0.9140244525730796F, -0.8889453868902251F, -2.2485074043684463F));
        g.addOrReplaceChild("domo_arena2_112", CubeListBuilder.create().texOffs(240, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.604720758310725F, -44.26190850271332F, -1.7176041602666712F, -0.5519059748483933F, -1.0403500682045144F, -2.6036829245322655F));
        g.addOrReplaceChild("domo_arena2_113", CubeListBuilder.create().texOffs(856, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.595780627502341F, -44.45213135199306F, -0.6376905633610318F, -0.09386615044579627F, -0.8177571792018361F, -3.0614187814220024F));
        g.addOrReplaceChild("domo_arena2_114", CubeListBuilder.create().texOffs(132, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.833523476694108F, -41.59351955593942F, -3.3314025187896705F, -1.180747206907663F, -0.09147300986023524F, -1.648518837986345F));
        g.addOrReplaceChild("domo_arena2_115", CubeListBuilder.create().texOffs(356, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.56718175500195F, -42.598630616561834F, -3.147832192343074F, -1.0949821843013854F, -0.35933213411975773F, -1.8905721135632791F));
        g.addOrReplaceChild("domo_arena2_116", CubeListBuilder.create().texOffs(144, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.040891904526045F, -43.331363056319F, -2.7850981864066773F, -0.8999559454600519F, -0.6033195193025518F, -2.1725151496343207F));
        g.addOrReplaceChild("domo_arena2_117", CubeListBuilder.create().texOffs(250, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.264272681544792F, -43.88602914641685F, -2.2498300227047467F, -0.6311743610305377F, -0.7724212580152214F, -2.480154912985847F));
        g.addOrReplaceChild("domo_arena2_118", CubeListBuilder.create().texOffs(260, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.23833273645641F, -44.26190850271332F, -1.5427228919182445F, -0.2671965520379581F, -0.5896969964311095F, -2.89942320382209F));
        g.addOrReplaceChild("domo_arena2_119", CubeListBuilder.create().texOffs(622, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.831020148133968F, -44.45213135199306F, -0.5727628360568051F, -0.06387156514565406F, -0.6026865009580079F, -3.08405396431169F));
        g.addOrReplaceChild("domo_arena2_120", CubeListBuilder.create().texOffs(156, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.829954407881921F, -41.59351955593942F, -2.7620134152537785F, -0.8847683966059882F, -0.08438772665045169F, -1.6810645805168436F));
        g.addOrReplaceChild("domo_arena2_121", CubeListBuilder.create().texOffs(366, 786).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.508706336600378F, -42.598630616561834F, -2.6098181457154035F, -0.7870679376106261F, -0.3195825334536261F, -2.012894677381924F));
        g.addOrReplaceChild("domo_arena2_122", CubeListBuilder.create().texOffs(270, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.873921826211683F, -43.331363056319F, -2.309081088300599F, -0.5963305050920965F, -0.5022144647947393F, -2.351675167236507F));
        g.addOrReplaceChild("domo_arena2_123", CubeListBuilder.create().texOffs(280, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.937202539733304F, -43.88602914641685F, -1.865298675168454F, -0.3846149848116031F, -0.6052234955087744F, -2.650277273841465F));
        g.addOrReplaceChild("domo_arena2_124", CubeListBuilder.create().texOffs(866, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.699765060856926F, -44.26190850271332F, -1.279047277975093F, -0.17350792199988702F, -0.4345413618864484F, -2.9395877687618333F));
        g.addOrReplaceChild("domo_arena2_125", CubeListBuilder.create().texOffs(168, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.490831242344505F, -41.59351955593942F, -1.9801614791227689F, -0.49943975524398276F, -0.05996406854756252F, -1.713510188071783F));
        g.addOrReplaceChild("domo_arena2_126", CubeListBuilder.create().texOffs(334, 802).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.133166864249528F, -42.598630616561834F, -1.871048609366158F, -0.42530453322997425F, -0.218086930355685F, -2.1229590787379413F));
        g.addOrReplaceChild("domo_arena2_127", CubeListBuilder.create().texOffs(290, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.426423921866167F, -43.331363056319F, -1.655442148822297F, -0.3012994506077627F, -0.3230559350736263F, -2.4840461440703434F));
        g.addOrReplaceChild("domo_arena2_128", CubeListBuilder.create().texOffs(300, 802).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.383519229205037F, -43.88602914641685F, -1.337282637089557F, -0.18483065286163272F, -0.3734607540036257F, -2.7538940743348017F));
        g.addOrReplaceChild("domo_arena2_129", CubeListBuilder.create().texOffs(876, 807).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(13.005807280466673F, -44.26190850271332F, -0.9169832904632726F, -0.08952664524891443F, -0.29149048875815886F, -2.9596799816136476F));
        g.addOrReplaceChild("domo_arena2_130", CubeListBuilder.create().texOffs(646, 723).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(16.82149554908021F, -41.59351955593942F, -0.7658551282491866F, -0.10630639821145234F, -0.017341220414700993F, -1.7288727740268346F));
    }

    private static void piezas8(PartDefinition g) {
        g.addOrReplaceChild("domo_arena2_131", CubeListBuilder.create().texOffs(180, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.445610570385526F, -42.598630616561834F, -0.7236542008288097F, -0.08881847387316644F, -0.06209306088166986F, -2.1704214748394373F));
        g.addOrReplaceChild("domo_arena2_132", CubeListBuilder.create().texOffs(192, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.702863816416532F, -43.331363056319F, -0.6402653887384329F, -0.061404853152472606F, -0.09018894671770351F, -2.5337041218880945F));
        g.addOrReplaceChild("domo_arena2_133", CubeListBuilder.create().texOffs(204, 786).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.606830126202594F, -43.88602914641685F, -0.5172127507436153F, -0.03710834473057871F, -0.10302877946381844F, -2.789047299922219F));
        g.addOrReplaceChild("domo_arena2_134", CubeListBuilder.create().texOffs(276, 799).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.15893299633687F, -44.26190850271332F, -0.35465610402199427F, -0.01852582179503819F, -0.11014209461555781F, -2.968318228394122F));
        g.addOrReplaceChild("domo_arena2_135", CubeListBuilder.create().texOffs(634, 807).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.172809084102973F, -44.45213135199306F, -0.13167227700362638F, -0.004381849465997097F, -0.11171043677707901F, -3.100799916042757F));
        g.addOrReplaceChild("silbato_0", CubeListBuilder.create().texOffs(156, 646).addBox(40.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(92, 646).addBox(40.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -44.5F, 4.0F));
        g.addOrReplaceChild("silbato_1", CubeListBuilder.create().texOffs(174, 646).addBox(40.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(124, 646).addBox(40.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -44.5F, 4.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("faro_0", CubeListBuilder.create().texOffs(100, 723).addBox(-5.0F, -0.818181818181818F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(398, 667).addBox(-1.0F, -0.818181818181818F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-114.5F, -37.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_1", CubeListBuilder.create().texOffs(124, 723).addBox(-5.0F, -0.818181818181818F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(422, 667).addBox(-1.0F, -0.818181818181818F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-114.5F, -37.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_2", CubeListBuilder.create().texOffs(148, 723).addBox(-5.0F, -0.818181818181818F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(446, 667).addBox(-1.0F, -0.818181818181818F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-114.5F, -37.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_3", CubeListBuilder.create().texOffs(172, 723).addBox(-5.0F, -0.818181818181818F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(470, 667).addBox(-1.0F, -0.818181818181818F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-114.5F, -37.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_vidrio", CubeListBuilder.create().texOffs(856, 615).addBox(-10.5F, 0.0F, -10.5F, 21.0F, 1.0F, 21.0F), PartPose.offsetAndRotation(-116.12F, -37.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("num_frentei", CubeListBuilder.create().texOffs(940, 615).addBox(0.0F, -7.0F, 0.0F, 1.0F, 7.0F, 15.0F), PartPose.offset(-115.0F, -35.0F, -10.75F));
        g.addOrReplaceChild("num_frented", CubeListBuilder.create().texOffs(972, 615).addBox(0.0F, -7.0F, 0.0F, 1.0F, 7.0F, 15.0F), PartPose.offset(-115.0F, -35.0F, 3.25F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(736, 615).addBox(75.0F, -41.0F, 14.0F, 29.0F, 22.0F, 1.0F).texOffs(796, 615).addBox(75.0F, -41.0F, -15.0F, 29.0F, 22.0F, 1.0F).texOffs(52, 615).addBox(75.0F, -20.0F, -14.0F, 29.0F, 1.0F, 28.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_frente", CubeListBuilder.create().texOffs(432, 560).addBox(0.0F, -7.0F, 0.0F, 1.0F, 7.0F, 30.0F), PartPose.offset(74.0F, -38.0F, -15.0F));
        g.addOrReplaceChild("cabina_fuego", CubeListBuilder.create().texOffs(0, 646).addBox(75.0F, -31.0F, -5.0F, 2.0F, 11.0F, 10.0F).texOffs(272, 716).addBox(77.0F, -25.0F, -2.0F, 1.0F, 3.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(900, 774).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -41.58499786231633F, -13.839273926110494F, -2.6616271092913535F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(0, 778).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -42.69000611733837F, -11.469576075995526F, -2.7488935718910703F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(72, 778).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -43.58427670612464F, -9.012587826422845F, -2.8361600344907827F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(144, 778).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -44.26100368951915F, -6.487008341541767F, -2.9234264970905026F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(216, 778).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -44.71503676655931F, -3.9120588062188295F, -3.010692959690218F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(288, 778).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -44.94292047137618F, -1.3073361412148734F, -3.0979594222899354F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(360, 778).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -44.94292047137618F, 1.3073361412148714F, 3.0979594222899354F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(432, 778).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -44.71503676655931F, 3.912058806218826F, 3.0106929596902186F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(504, 778).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -44.26100368951914F, 6.487008341541767F, 2.9234264970905026F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(576, 778).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -43.58427670612465F, 9.012587826422843F, 2.836160034490785F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(648, 778).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -42.69000611733837F, 11.469576075995523F, 2.748893571891068F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(720, 778).addBox(-16.5F, -1.0F, -1.5F, 33.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(89.5F, -41.58499786231633F, 13.839273926110492F, 2.661627109291354F, 0.0F, 0.0F));
        g.addOrReplaceChild("numeroi", CubeListBuilder.create().texOffs(532, 706).addBox(0.0F, -7.0F, -0.5F, 17.0F, 7.0F, 1.0F), PartPose.offset(87.75F, -25.25F, -15.5F));
        g.addOrReplaceChild("numerod", CubeListBuilder.create().texOffs(568, 706).addBox(0.0F, -7.0F, -0.5F, 17.0F, 7.0F, 1.0F), PartPose.offset(87.75F, -25.25F, 15.5F));
    }

    private static void piezas9(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(110, 729).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(130.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(130.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(130.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(120, 729).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(142.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(142.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(142.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri2_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(130, 729).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(172.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri2_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(172.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri2_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(172.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri3_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(140, 729).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(186.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri3_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(186.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri3_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(186.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri4_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(150, 729).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(200.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri4_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(200.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri4_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(200.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri5_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(160, 729).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(214.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri5_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(214.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri5_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(214.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri6_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(170, 729).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(228.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri6_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(228.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri6_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(228.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(180, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(130.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(130.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(130.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(190, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(142.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(142.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(142.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd2_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(200, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(172.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd2_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(172.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd2_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(172.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd3_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(210, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(186.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd3_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(186.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd3_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(186.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd4_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(220, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(200.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd4_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(200.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd4_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(200.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd5_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(230, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(214.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd5_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(214.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd5_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(214.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd6_0", CubeListBuilder.create().texOffs(732, 682).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(196, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(240, 729).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(228.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd6_1", CubeListBuilder.create().texOffs(220, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(228.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd6_2", CubeListBuilder.create().texOffs(244, 723).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 694).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(228.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(0, 706).addBox(120.0F, -13.0F, 2.0F, 132.0F, 9.0F, 1.0F).texOffs(266, 706).addBox(120.0F, -13.0F, -3.0F, 132.0F, 9.0F, 1.0F).texOffs(290, 716).addBox(124.0F, -10.0F, 7.0F, 24.0F, 5.0F, 1.0F).texOffs(340, 716).addBox(124.0F, -10.0F, -8.0F, 24.0F, 5.0F, 1.0F).texOffs(732, 706).addBox(164.0F, -11.0F, 7.0F, 72.0F, 6.0F, 1.0F).texOffs(878, 706).addBox(164.0F, -11.0F, -8.0F, 72.0F, 6.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(0, 560).addBox(116.0F, -38.0F, -15.0F, 136.0F, 25.0F, 30.0F).texOffs(276, 615).addBox(116.0F, -42.0F, -11.0F, 136.0F, 4.0F, 22.0F).texOffs(592, 615).addBox(118.0F, -43.0F, -11.0F, 50.0F, 1.0F, 22.0F).texOffs(0, 615).addBox(252.0F, -13.0F, -12.0F, 2.0F, 7.0F, 24.0F).texOffs(14, 723).addBox(254.0F, -11.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender_caja_cantoi_0", CubeListBuilder.create().texOffs(536, 786).addBox(-68.0F, -1.0F, -1.0F, 136.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(184.0F, -38.61803398874989F, -14.902113032590307F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_1", CubeListBuilder.create().texOffs(0, 790).addBox(-68.0F, -1.0F, -1.0F, 136.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(184.0F, -39.79360449333484F, -14.5201470213402F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_2", CubeListBuilder.create().texOffs(276, 790).addBox(-68.0F, -1.0F, -1.0F, 136.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(184.0F, -40.79360449333484F, -13.79360449333484F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_3", CubeListBuilder.create().texOffs(552, 790).addBox(-68.0F, -1.0F, -1.0F, 136.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(184.0F, -41.5201470213402F, -12.79360449333484F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_4", CubeListBuilder.create().texOffs(0, 793).addBox(-68.0F, -1.0F, -1.0F, 136.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(184.0F, -41.90211303259031F, -11.618033988749895F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_0", CubeListBuilder.create().texOffs(276, 793).addBox(-68.0F, -1.0F, -1.0F, 136.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(184.0F, -38.61803398874989F, 14.902113032590307F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_1", CubeListBuilder.create().texOffs(552, 793).addBox(-68.0F, -1.0F, -1.0F, 136.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(184.0F, -39.79360449333484F, 14.5201470213402F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_2", CubeListBuilder.create().texOffs(0, 796).addBox(-68.0F, -1.0F, -1.0F, 136.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(184.0F, -40.79360449333484F, 13.79360449333484F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_3", CubeListBuilder.create().texOffs(276, 796).addBox(-68.0F, -1.0F, -1.0F, 136.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(184.0F, -41.5201470213402F, 12.79360449333484F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_4", CubeListBuilder.create().texOffs(552, 796).addBox(-68.0F, -1.0F, -1.0F, 136.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(184.0F, -41.90211303259031F, 11.618033988749895F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_tapaa", CubeListBuilder.create().texOffs(512, 448).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 60.0F), PartPose.offset(116.0F, -38.0F, -15.0F));
        g.addOrReplaceChild("tender_caja_tapab", CubeListBuilder.create().texOffs(634, 448).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 60.0F), PartPose.offset(251.0F, -38.0F, -15.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "fecil_i_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_i_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_i_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_i_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_i_a_0", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_i_a_1", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_i_a_2", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_i_a_3", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_i_b_0", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_i_b_1", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_i_b_2", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_i_b_3", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_d_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "fecil_d_a_0", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_d_a_1", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_d_a_2", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_d_a_3", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_d_b_0", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_d_b_1", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_d_b_2", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fecil_d_b_3", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g0, "fe_piloto_rejas_0", 0.9453981132056603F, 1.0F, 1.0018181818181817F);
        escalar(g0, "fe_piloto_rejas_1", 0.9453981132056603F, 1.0F, 1.0018181818181817F);
        escalar(g1, "recil_i_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g1, "recil_i_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g1, "recil_i_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g1, "recil_i_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g1, "recil_i_a_0", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_i_a_1", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_i_a_2", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_i_a_3", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_i_b_0", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_i_b_1", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_i_b_2", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_i_b_3", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_d_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g1, "recil_d_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g1, "recil_d_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g1, "recil_d_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g1, "recil_d_a_0", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_d_a_1", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_d_a_2", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_d_a_3", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_d_b_0", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_d_b_1", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_d_b_2", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "recil_d_b_3", 1.0F, 0.8827067523629074F, 0.8827067523629074F);
        escalar(g1, "caja_humo_0", 1.0F, 0.25367453817134433F, 0.25367453817134433F);
        escalar(g1, "caja_humo_1", 1.0F, 0.25367453817134433F, 0.25367453817134433F);
        escalar(g1, "caja_humo_2", 1.0F, 0.25367453817134433F, 0.25367453817134433F);
        escalar(g1, "caja_humo_3", 1.0F, 0.25367453817134433F, 0.25367453817134433F);
        escalar(g1, "caja_humo_4", 1.0F, 0.25367453817134433F, 0.25367453817134433F);
        escalar(g1, "caja_humo_5", 1.0F, 0.25367453817134433F, 0.25367453817134433F);
        escalar(g1, "caja_humo_6", 1.0F, 0.25367453817134433F, 0.25367453817134433F);
        escalar(g1, "caja_humo_7", 1.0F, 0.25367453817134433F, 0.25367453817134433F);
        escalar(g1, "puerta_0", 1.0F, 0.22635574175289186F, 0.22635574175289186F);
        escalar(g1, "puerta_1", 1.0F, 0.22635574175289186F, 0.22635574175289186F);
        escalar(g1, "puerta_2", 1.0F, 0.22635574175289186F, 0.22635574175289186F);
        escalar(g1, "puerta_3", 1.0F, 0.22635574175289186F, 0.22635574175289186F);
        escalar(g1, "puerta_4", 1.0F, 0.22635574175289186F, 0.22635574175289186F);
        escalar(g1, "puerta_5", 1.0F, 0.22635574175289186F, 0.22635574175289186F);
        escalar(g1, "puerta_6", 1.0F, 0.22635574175289186F, 0.22635574175289186F);
        escalar(g1, "puerta_7", 1.0F, 0.22635574175289186F, 0.22635574175289186F);
        escalar(g1, "caldera_0", 0.9761970092696605F, 1.0F, 0.8200767407573236F);
        escalar(g1, "caldera_1", 0.9761970092696605F, 1.0F, 0.8298784547902797F);
        escalar(g1, "caldera_2", 0.9761970092696605F, 1.0F, 0.8396801688232357F);
        escalar(g1, "caldera_3", 0.9761970092696605F, 1.0F, 0.8494818828561916F);
        escalar(g1, "caldera_4", 0.9761970092696605F, 1.0F, 0.8200767407573242F);
        escalar(g1, "caldera_5", 0.9761970092696605F, 1.0F, 0.8298784547902803F);
        escalar(g1, "caldera_6", 0.9761970092696605F, 1.0F, 0.8396801688232364F);
        escalar(g1, "caldera_7", 0.9761970092696605F, 1.0F, 0.8494818828561922F);
        escalar(g1, "caldera_8", 0.9761970092696605F, 1.0F, 0.8200767407573228F);
        escalar(g1, "caldera_9", 0.9761970092696605F, 1.0F, 0.8298784547902787F);
        escalar(g1, "caldera_10", 0.9761970092696605F, 1.0F, 0.8396801688232355F);
        escalar(g1, "caldera_11", 0.9761970092696605F, 1.0F, 0.8494818828561916F);
        escalar(g1, "caldera_12", 0.9761970092696605F, 1.0F, 0.8200767407573237F);
        escalar(g1, "caldera_13", 0.9761970092696605F, 1.0F, 0.8298784547902803F);
        escalar(g1, "caldera_14", 0.9761970092696605F, 1.0F, 0.8396801688232354F);
        escalar(g1, "caldera_15", 0.9761970092696605F, 1.0F, 0.8494818828561912F);
        escalar(g1, "caldera_16", 0.9761970092696605F, 1.0F, 0.8200767407573228F);
        escalar(g1, "caldera_17", 0.9761970092696605F, 1.0F, 0.8298784547902797F);
        escalar(g1, "caldera_18", 0.9761970092696605F, 1.0F, 0.8396801688232359F);
        escalar(g1, "caldera_19", 0.9761970092696605F, 1.0F, 0.8494818828561921F);
        escalar(g1, "caldera_20", 0.9761970092696605F, 1.0F, 0.8200767407573245F);
        escalar(g1, "caldera_21", 0.9761970092696605F, 1.0F, 0.829878454790281F);
        escalar(g1, "caldera_22", 0.9761970092696605F, 1.0F, 0.8396801688232358F);
        escalar(g1, "caldera_23", 0.9761970092696605F, 1.0F, 0.8494818828561926F);
        escalar(g1, "caldera_24", 0.9761970092696605F, 1.0F, 0.8200767407573237F);
        escalar(g1, "caldera_25", 0.9761970092696605F, 1.0F, 0.8298784547902788F);
        escalar(g1, "caldera_26", 0.9761970092696605F, 1.0F, 0.8396801688232359F);
        escalar(g1, "caldera_27", 0.9761970092696605F, 1.0F, 0.8494818828561908F);
        escalar(g1, "caldera_28", 0.9761970092696605F, 1.0F, 0.8200767407573246F);
        escalar(g1, "caldera_29", 0.9761970092696605F, 1.0F, 0.82987845479028F);
        escalar(g1, "caldera_30", 0.9761970092696605F, 1.0F, 0.8396801688232353F);
        escalar(g1, "caldera_31", 0.9761970092696605F, 1.0F, 0.849481882856193F);
        escalar(g1, "caldera_32", 0.9761970092696605F, 1.0F, 0.8200767407573234F);
        escalar(g1, "caldera_33", 0.9761970092696605F, 1.0F, 0.82987845479028F);
        escalar(g1, "caldera_34", 0.9761970092696605F, 1.0F, 0.8396801688232353F);
        escalar(g1, "caldera_35", 0.9761970092696605F, 1.0F, 0.8494818828561918F);
        escalar(g1, "caldera_36", 0.9761970092696605F, 1.0F, 0.8200767407573237F);
        escalar(g1, "caldera_37", 0.9761970092696605F, 1.0F, 0.8298784547902788F);
        escalar(g1, "caldera_38", 0.9761970092696605F, 1.0F, 0.8396801688232359F);
        escalar(g1, "caldera_39", 0.9761970092696605F, 1.0F, 0.849481882856192F);
        escalar(g1, "caldera_40", 0.9761970092696605F, 1.0F, 0.8200767407573228F);
        escalar(g1, "caldera_41", 0.9761970092696605F, 1.0F, 0.8298784547902787F);
        escalar(g1, "caldera_42", 0.9761970092696605F, 1.0F, 0.8396801688232353F);
        escalar(g1, "caldera_43", 0.9761970092696605F, 1.0F, 0.8494818828561902F);
        escalar(g1, "caldera_44", 0.9761970092696605F, 1.0F, 0.8200767407573255F);
        escalar(g1, "caldera_45", 0.9761970092696605F, 1.0F, 0.8298784547902814F);
        escalar(g1, "caldera_46", 0.9761970092696605F, 1.0F, 0.8396801688232364F);
        escalar(g1, "caldera_47", 0.9761970092696605F, 1.0F, 0.8494818828561934F);
        escalar(g1, "caldera_48", 0.9761970092696605F, 1.0F, 0.8200767407573237F);
        escalar(g1, "caldera_49", 0.9761970092696605F, 1.0F, 0.8298784547902808F);
        escalar(g1, "caldera_50", 0.9761970092696605F, 1.0F, 0.8396801688232367F);
        escalar(g1, "caldera_51", 0.9761970092696605F, 1.0F, 0.8494818828561922F);
        escalar(g1, "caldera_52", 0.9761970092696605F, 1.0F, 0.8200767407573228F);
        escalar(g1, "caldera_53", 0.9761970092696605F, 1.0F, 0.8298784547902782F);
        escalar(g1, "caldera_54", 0.9761970092696605F, 1.0F, 0.8396801688232348F);
        escalar(g1, "caldera_55", 0.9761970092696605F, 1.0F, 0.8494818828561912F);
        escalar(g1, "caldera_56", 0.9761970092696605F, 1.0F, 0.820076740757323F);
        escalar(g1, "caldera_57", 0.9761970092696605F, 1.0F, 0.8298784547902794F);
        escalar(g1, "caldera_58", 0.9761970092696605F, 1.0F, 0.839680168823235F);
        escalar(g1, "caldera_59", 0.9761970092696605F, 1.0F, 0.8494818828561912F);
        escalar(g1, "caldera_60", 0.9761970092696605F, 1.0F, 0.8200767407573247F);
        escalar(g1, "caldera_61", 0.9761970092696605F, 1.0F, 0.8298784547902804F);
        escalar(g1, "caldera_62", 0.9761970092696605F, 1.0F, 0.8396801688232367F);
        escalar(g1, "caldera_63", 0.9761970092696605F, 1.0F, 0.8494818828561929F);
        escalar(g1, "caldera_64", 0.9761970092696605F, 1.0F, 0.8200767407573246F);
        escalar(g1, "caldera_65", 0.9761970092696605F, 1.0F, 0.8298784547902806F);
        escalar(g1, "caldera_66", 0.9761970092696605F, 1.0F, 0.8396801688232367F);
        escalar(g1, "caldera_67", 0.9761970092696605F, 1.0F, 0.8494818828561929F);
        escalar(g1, "caldera_68", 0.9761970092696605F, 1.0F, 0.8200767407573232F);
        escalar(g1, "caldera_69", 0.9761970092696605F, 1.0F, 0.8298784547902788F);
        escalar(g1, "caldera_70", 0.9761970092696605F, 1.0F, 0.839680168823235F);
        escalar(g1, "caldera_71", 0.9761970092696605F, 1.0F, 0.8494818828561912F);
        escalar(g1, "caldera_72", 0.9761970092696605F, 1.0F, 0.8200767407573228F);
        escalar(g1, "caldera_73", 0.9761970092696605F, 1.0F, 0.829878454790279F);
        escalar(g1, "caldera_74", 0.9761970092696605F, 1.0F, 0.8396801688232348F);
        escalar(g1, "caldera_75", 0.9761970092696605F, 1.0F, 0.8494818828561912F);
        escalar(g1, "caldera_76", 0.9761970092696605F, 1.0F, 0.8200767407573245F);
        escalar(g1, "caldera_77", 0.9761970092696605F, 1.0F, 0.8298784547902809F);
        escalar(g1, "caldera_78", 0.9761970092696605F, 1.0F, 0.8396801688232368F);
        escalar(g1, "caldera_79", 0.9761970092696605F, 1.0F, 0.8494818828561925F);
        escalar(g1, "caldera_80", 0.9761970092696605F, 1.0F, 0.8200767407573247F);
        escalar(g1, "caldera_81", 0.9761970092696605F, 1.0F, 0.8298784547902806F);
        escalar(g1, "caldera_82", 0.9761970092696605F, 1.0F, 0.839680168823237F);
        escalar(g1, "caldera_83", 0.9761970092696605F, 1.0F, 0.849481882856193F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g1, "caldera_84", 0.9761970092696605F, 1.0F, 0.8200767407573207F);
        escalar(g1, "caldera_85", 0.9761970092696605F, 1.0F, 0.8298784547902763F);
        escalar(g1, "caldera_86", 0.9761970092696605F, 1.0F, 0.8396801688232332F);
        escalar(g1, "caldera_87", 0.9761970092696605F, 1.0F, 0.849481882856189F);
        escalar(g1, "caldera_88", 0.9761970092696605F, 1.0F, 0.8200767407573238F);
        escalar(g1, "caldera_89", 0.9761970092696605F, 1.0F, 0.8298784547902812F);
        escalar(g1, "caldera_90", 0.9761970092696605F, 1.0F, 0.8396801688232362F);
        escalar(g1, "caldera_91", 0.9761970092696605F, 1.0F, 0.8494818828561931F);
        escalar(g1, "caldera_92", 0.9761970092696605F, 1.0F, 0.8200767407573246F);
        escalar(g1, "caldera_93", 0.9761970092696605F, 1.0F, 0.82987845479028F);
        escalar(g1, "caldera_94", 0.9761970092696605F, 1.0F, 0.8396801688232366F);
        escalar(g1, "caldera_95", 0.9761970092696605F, 1.0F, 0.8494818828561918F);
        escalar(g1, "caldera_96", 0.9761970092696605F, 1.0F, 0.8200767407573258F);
        escalar(g1, "caldera_97", 0.9761970092696605F, 1.0F, 0.8298784547902812F);
        escalar(g1, "caldera_98", 0.9761970092696605F, 1.0F, 0.8396801688232364F);
        escalar(g1, "caldera_99", 0.9761970092696605F, 1.0F, 0.8494818828561942F);
        escalar(g1, "caldera_100", 0.9761970092696605F, 1.0F, 0.8200767407573238F);
        escalar(g1, "caldera_101", 0.9761970092696605F, 1.0F, 0.8298784547902812F);
        escalar(g1, "caldera_102", 0.9761970092696605F, 1.0F, 0.8396801688232384F);
        escalar(g1, "caldera_103", 0.9761970092696605F, 1.0F, 0.8494818828561909F);
        escalar(g1, "caldera_104", 0.9761970092696605F, 1.0F, 0.8200767407573215F);
        escalar(g1, "caldera_105", 0.9761970092696605F, 1.0F, 0.8298784547902763F);
        escalar(g1, "caldera_106", 0.9761970092696605F, 1.0F, 0.8396801688232328F);
        escalar(g1, "caldera_107", 0.9761970092696605F, 1.0F, 0.8494818828561899F);
        escalar(g1, "caldera_108", 0.9761970092696605F, 1.0F, 0.8200767407573233F);
        escalar(g1, "caldera_109", 0.9761970092696605F, 1.0F, 0.8298784547902792F);
        escalar(g1, "caldera_110", 0.9761970092696605F, 1.0F, 0.8396801688232359F);
        escalar(g1, "caldera_111", 0.9761970092696605F, 1.0F, 0.8494818828561925F);
        escalar(g1, "caldera_112", 0.9761970092696605F, 1.0F, 0.8200767407573256F);
        escalar(g1, "caldera_113", 0.9761970092696605F, 1.0F, 0.8298784547902827F);
        escalar(g1, "caldera_114", 0.9761970092696605F, 1.0F, 0.8396801688232364F);
        escalar(g1, "caldera_115", 0.9761970092696605F, 1.0F, 0.8494818828561931F);
        escalar(g1, "caldera_116", 0.9761970092696605F, 1.0F, 0.8200767407573205F);
        escalar(g1, "caldera_117", 0.9761970092696605F, 1.0F, 0.8298784547902763F);
        escalar(g1, "caldera_118", 0.9761970092696605F, 1.0F, 0.8396801688232332F);
        escalar(g1, "caldera_119", 0.9761970092696605F, 1.0F, 0.8494818828561893F);
        escalar(g1, "caldera_120", 0.9761970092696605F, 1.0F, 0.820076740757325F);
        escalar(g1, "caldera_121", 0.9761970092696605F, 1.0F, 0.8298784547902808F);
        escalar(g1, "caldera_122", 0.9761970092696605F, 1.0F, 0.8396801688232368F);
        escalar(g1, "caldera_123", 0.9761970092696605F, 1.0F, 0.8494818828561929F);
        escalar(g1, "caldera_124", 0.9761970092696605F, 1.0F, 0.8200767407573245F);
        escalar(g1, "caldera_125", 0.9761970092696605F, 1.0F, 0.8298784547902808F);
        escalar(g1, "caldera_126", 0.9761970092696605F, 1.0F, 0.8396801688232367F);
        escalar(g1, "caldera_127", 0.9761970092696605F, 1.0F, 0.8494818828561929F);
        escalar(g1, "chimenea_a_0", 0.6277025794580675F, 1.0F, 0.6277025794580675F);
        escalar(g1, "chimenea_a_1", 0.6277025794580675F, 1.0F, 0.6277025794580675F);
        escalar(g1, "chimenea_a_2", 0.6277025794580675F, 1.0F, 0.6277025794580675F);
        escalar(g1, "chimenea_a_3", 0.6277025794580675F, 1.0F, 0.6277025794580675F);
        escalar(g1, "chimenea_a_labio_0", 0.7453968131064552F, 1.0F, 0.7453968131064552F);
        escalar(g1, "chimenea_a_labio_1", 0.7453968131064552F, 1.0F, 0.7453968131064552F);
        escalar(g1, "chimenea_a_labio_2", 0.7453968131064552F, 1.0F, 0.7453968131064552F);
        escalar(g1, "chimenea_a_labio_3", 0.7453968131064552F, 1.0F, 0.7453968131064552F);
        escalar(g1, "chimenea_b_0", 0.6277025794580675F, 1.0F, 0.6277025794580675F);
        escalar(g1, "chimenea_b_1", 0.6277025794580675F, 1.0F, 0.6277025794580675F);
        escalar(g1, "chimenea_b_2", 0.6277025794580675F, 1.0F, 0.6277025794580675F);
        escalar(g1, "chimenea_b_3", 0.6277025794580675F, 1.0F, 0.6277025794580675F);
        escalar(g1, "chimenea_b_labio_0", 0.7453968131064552F, 1.0F, 0.7453968131064552F);
        escalar(g1, "chimenea_b_labio_1", 0.7453968131064552F, 1.0F, 0.7453968131064552F);
        escalar(g1, "chimenea_b_labio_2", 0.7453968131064552F, 1.0F, 0.7453968131064552F);
        escalar(g1, "chimenea_b_labio_3", 0.7453968131064552F, 1.0F, 0.7453968131064552F);
        escalar(g1, "domo_arena_0", 0.4646890991910901F, 1.0F, 0.39083725234118566F);
        escalar(g1, "domo_arena_1", 0.3876749497123056F, 1.0F, 0.492768608046015F);
        escalar(g1, "domo_arena_2", 0.43780599026257416F, 1.0F, 0.43675364482183404F);
        escalar(g1, "domo_arena_3", 0.39468673806785126F, 1.0F, 0.35409520636791125F);
        escalar(g1, "domo_arena_4", 0.4812460284135627F, 1.0F, 0.36735097058030663F);
        escalar(g1, "domo_arena_5", 0.4548085051918251F, 1.0F, 0.28534558662408827F);
        escalar(g1, "domo_arena_6", 0.46443438517478547F, 1.0F, 0.360297760831338F);
        escalar(g1, "domo_arena_7", 0.3849509871607247F, 1.0F, 0.340811620975425F);
        escalar(g1, "domo_arena_8", 0.431281186612845F, 1.0F, 0.4534606656475973F);
        escalar(g1, "domo_arena_9", 0.38697504395553195F, 1.0F, 0.36823193750660466F);
        escalar(g1, "domo_arena_10", 0.47086185050294466F, 1.0F, 0.5112838792534791F);
        escalar(g1, "domo_arena_11", 0.46379209471812866F, 1.0F, 0.39190432303424666F);
        escalar(g1, "domo_arena_12", 0.37800027177214196F, 1.0F, 0.3706765662741267F);
        escalar(g1, "domo_arena_13", 0.41437485791875067F, 1.0F, 0.4930959447410342F);
        escalar(g1, "domo_arena_14", 0.48907081656787726F, 1.0F, 0.40024971027236433F);
        escalar(g1, "domo_arena_15", 0.44358400438143136F, 1.0F, 0.2775967319868268F);
        escalar(g1, "domo_arena_16", 0.46283360368054066F, 1.0F, 0.47821949777926326F);
        escalar(g1, "domo_arena_17", 0.3674043396320113F, 1.0F, 0.45223551456020544F);
        escalar(g1, "domo_arena_18", 0.38782201799287225F, 1.0F, 0.4008912994810075F);
        escalar(g1, "domo_arena_19", 0.44597411124026903F, 1.0F, 0.48768787053417184F);
        escalar(g1, "domo_arena_20", 0.3994619346681685F, 1.0F, 0.3375536398873346F);
        escalar(g1, "domo_arena_21", 0.4497684517782516F, 1.0F, 0.26322002703845676F);
        escalar(g1, "domo_arena_22", 0.4617224641775975F, 1.0F, 0.45900998928554226F);
        escalar(g1, "domo_arena_23", 0.35476333274295674F, 1.0F, 0.43399266956116367F);
        escalar(g1, "domo_arena_24", 0.3546745372141813F, 1.0F, 0.38455857649680525F);
        escalar(g1, "domo_arena_25", 0.3902608061838199F, 1.0F, 0.41548159220882747F);
        escalar(g1, "domo_arena_26", 0.45517843657172347F, 1.0F, 0.4304905289468468F);
        escalar(g1, "domo_arena_27", 0.47633341802539286F, 1.0F, 0.3322289157129893F);
        escalar(g1, "domo_arena_28", 0.46074724549989793F, 1.0F, 0.4406972194858339F);
        escalar(g1, "domo_arena_29", 0.3433394536396362F, 1.0F, 0.48599939583771073F);
        escalar(g1, "domo_arena_30", 0.48463770935017175F, 1.0F, 0.4303803590899355F);
        escalar(g1, "domo_arena_31", 0.501832952648919F, 1.0F, 0.41796740309263003F);
        escalar(g1, "domo_arena_32", 0.375515423888797F, 1.0F, 0.479766843727435F);
        escalar(g1, "domo_arena_33", 0.3870678101082573F, 1.0F, 0.2734700637799279F);
        escalar(g1, "domo_arena_34", 0.46074724549989776F, 1.0F, 0.4406972194959193F);
        escalar(g1, "domo_arena_35", 0.3433394536396365F, 1.0F, 0.4859993958488296F);
        escalar(g1, "domo_arena_36", 0.48463770935017103F, 1.0F, 0.4303803590997724F);
        escalar(g1, "domo_arena_37", 0.5018329526489191F, 1.0F, 0.41796740310216524F);
        escalar(g1, "domo_arena_38", 0.3755154238887977F, 1.0F, 0.47976684373833073F);
        escalar(g1, "domo_arena_39", 0.38706781010825675F, 1.0F, 0.2734700637859948F);
        escalar(g1, "domo_arena_40", 0.46172246417759727F, 1.0F, 0.45900998928554226F);
        escalar(g1, "domo_arena_41", 0.3547633327429575F, 1.0F, 0.43399266956116367F);
        escalar(g1, "domo_arena_42", 0.35467453721418013F, 1.0F, 0.38455857649680525F);
        escalar(g1, "domo_arena_43", 0.39026080618382F, 1.0F, 0.4154815922088275F);
        escalar(g1, "domo_arena_44", 0.4551784365717242F, 1.0F, 0.4304905289468486F);
        escalar(g1, "domo_arena_45", 0.4763334180253923F, 1.0F, 0.3322289157129928F);
        escalar(g1, "domo_arena_46", 0.46283360368054033F, 1.0F, 0.4782194977792655F);
        escalar(g1, "domo_arena_47", 0.3674043396320122F, 1.0F, 0.45223551456020766F);
        escalar(g1, "domo_arena_48", 0.3878220179928724F, 1.0F, 0.4008912994810075F);
        escalar(g1, "domo_arena_49", 0.44597411124026815F, 1.0F, 0.4876878705341701F);
        escalar(g1, "domo_arena_50", 0.39946193466816843F, 1.0F, 0.33755363988733456F);
        escalar(g1, "domo_arena_51", 0.4497684517782516F, 1.0F, 0.26322002703845676F);
        escalar(g1, "domo_arena_52", 0.46379209471812866F, 1.0F, 0.39190432303424644F);
        escalar(g1, "domo_arena_53", 0.3780002717721425F, 1.0F, 0.37067656627412554F);
        escalar(g1, "domo_arena_54", 0.41437485791875056F, 1.0F, 0.49309594474103696F);
        escalar(g1, "domo_arena_55", 0.48907081656787743F, 1.0F, 0.4002497102723671F);
        escalar(g1, "domo_arena_56", 0.4435840043814314F, 1.0F, 0.27759673198682666F);
        escalar(g1, "domo_arena_57", 0.46443438517478564F, 1.0F, 0.3602977608313375F);
        escalar(g1, "domo_arena_58", 0.38495098716072534F, 1.0F, 0.34081162097542433F);
        escalar(g1, "domo_arena_59", 0.4312811866128432F, 1.0F, 0.45346066564759535F);
        escalar(g1, "domo_arena_60", 0.38697504395553195F, 1.0F, 0.36823193750660466F);
        escalar(g1, "domo_arena_61", 0.47086185050294554F, 1.0F, 0.5112838792534811F);
        escalar(g1, "domo_arena_62", 0.4646890991910901F, 1.0F, 0.3908372523340683F);
        escalar(g1, "domo_arena_63", 0.38767494971230626F, 1.0F, 0.4927686080370482F);
        escalar(g1, "domo_arena_64", 0.4378059902625732F, 1.0F, 0.43675364481390044F);
        escalar(g1, "domo_arena_65", 0.39468673806785126F, 1.0F, 0.354095206361502F);
        escalar(g1, "domo_arena_66", 0.4812460284135626F, 1.0F, 0.36735097057371435F);
        escalar(g1, "domo_arena_67", 0.45480850519182514F, 1.0F, 0.28534558661919357F);
        escalar(g1, "domo_arena_68", 0.4646890991910901F, 1.0F, 0.39083725234830297F);
        escalar(g1, "domo_arena_69", 0.38767494971230626F, 1.0F, 0.49276860805498196F);
        escalar(g1, "domo_arena_70", 0.4378059902625731F, 1.0F, 0.4367536448297677F);
        escalar(g1, "domo_arena_71", 0.39468673806785126F, 1.0F, 0.3540952063743197F);
        escalar(g1, "domo_arena_72", 0.48124602841356257F, 1.0F, 0.36735097058689803F);
        escalar(g1, "domo_arena_73", 0.4548085051918251F, 1.0F, 0.2853455866289829F);
        escalar(g1, "domo_arena_74", 0.46443438517478564F, 1.0F, 0.3602977608313373F);
        escalar(g1, "domo_arena_75", 0.38495098716072534F, 1.0F, 0.34081162097542417F);
        escalar(g1, "domo_arena_76", 0.43128118661284315F, 1.0F, 0.4534606656475952F);
        escalar(g1, "domo_arena_77", 0.38697504395553195F, 1.0F, 0.36823193750660443F);
        escalar(g1, "domo_arena_78", 0.4708618505029446F, 1.0F, 0.5112838792534788F);
        escalar(g1, "domo_arena_79", 0.46379209471812866F, 1.0F, 0.391904323034247F);
        escalar(g1, "domo_arena_80", 0.3780002717721425F, 1.0F, 0.3706765662741261F);
        escalar(g1, "domo_arena_81", 0.41437485791875056F, 1.0F, 0.4930959447410377F);
        escalar(g1, "domo_arena_82", 0.4890708165678774F, 1.0F, 0.40024971027236766F);
        escalar(g1, "domo_arena_83", 0.44358400438143053F, 1.0F, 0.27759673198682855F);
        escalar(g1, "domo_arena_84", 0.46283360368054066F, 1.0F, 0.47821949777926315F);
        escalar(g1, "domo_arena_85", 0.3674043396320113F, 1.0F, 0.45223551456020544F);
        escalar(g1, "domo_arena_86", 0.3878220179928739F, 1.0F, 0.40089129948100527F);
        escalar(g1, "domo_arena_87", 0.44597411124026803F, 1.0F, 0.48768787053417006F);
        escalar(g1, "domo_arena_88", 0.3994619346681684F, 1.0F, 0.33755363988733456F);
        escalar(g1, "domo_arena_89", 0.4497684517782516F, 1.0F, 0.26322002703845676F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g1, "domo_arena_90", 0.4617224641775975F, 1.0F, 0.45900998928554226F);
        escalar(g1, "domo_arena_91", 0.3547633327429566F, 1.0F, 0.43399266956116367F);
        escalar(g1, "domo_arena_92", 0.3546745372141816F, 1.0F, 0.38455857649680525F);
        escalar(g1, "domo_arena_93", 0.3902608061838205F, 1.0F, 0.41548159220882636F);
        escalar(g1, "domo_arena_94", 0.45517843657172347F, 1.0F, 0.43049052894684686F);
        escalar(g1, "domo_arena_95", 0.47633341802539286F, 1.0F, 0.3322289157129893F);
        escalar(g1, "domo_arena_96", 0.46074724549989776F, 1.0F, 0.440697219479996F);
        escalar(g1, "domo_arena_97", 0.3433394536396365F, 1.0F, 0.48599939583127577F);
        escalar(g1, "domo_arena_98", 0.48463770935017103F, 1.0F, 0.43038035908424144F);
        escalar(g1, "domo_arena_99", 0.50183295264892F, 1.0F, 0.41796740308711033F);
        escalar(g1, "domo_arena_100", 0.375515423888797F, 1.0F, 0.47976684372112605F);
        escalar(g1, "domo_arena_101", 0.3870678101082573F, 1.0F, 0.27347006377641414F);
        escalar(g1, "domo_arena_102", 0.46074724549989793F, 1.0F, 0.4406972195017572F);
        escalar(g1, "domo_arena_103", 0.3433394536396362F, 1.0F, 0.4859993958552647F);
        escalar(g1, "domo_arena_104", 0.48463770935017103F, 1.0F, 0.43038035910546707F);
        escalar(g1, "domo_arena_105", 0.5018329526489191F, 1.0F, 0.4179674031076856F);
        escalar(g1, "domo_arena_106", 0.3755154238887977F, 1.0F, 0.4797668437446398F);
        escalar(g1, "domo_arena_107", 0.38706781010825675F, 1.0F, 0.27347006378950856F);
        escalar(g1, "domo_arena_108", 0.4617224641775975F, 1.0F, 0.45900998928554226F);
        escalar(g1, "domo_arena_109", 0.35476333274295674F, 1.0F, 0.43399266956116367F);
        escalar(g1, "domo_arena_110", 0.3546745372141802F, 1.0F, 0.38455857649680525F);
        escalar(g1, "domo_arena_111", 0.3902608061838208F, 1.0F, 0.41548159220882636F);
        escalar(g1, "domo_arena_112", 0.4551784365717233F, 1.0F, 0.4304905289468468F);
        escalar(g1, "domo_arena_113", 0.4763334180253923F, 1.0F, 0.3322289157129928F);
        escalar(g1, "domo_arena_114", 0.46283360368054066F, 1.0F, 0.47821949777926553F);
        escalar(g1, "domo_arena_115", 0.3674043396320113F, 1.0F, 0.4522355145602077F);
        escalar(g1, "domo_arena_116", 0.3878220179928717F, 1.0F, 0.4008912994810087F);
        escalar(g1, "domo_arena_117", 0.44597411124027F, 1.0F, 0.4876878705341735F);
        escalar(g1, "domo_arena_118", 0.39946193466816776F, 1.0F, 0.3375536398873363F);
        escalar(g1, "domo_arena_119", 0.4497684517782516F, 1.0F, 0.26322002703845676F);
        escalar(g1, "domo_arena_120", 0.46379209471812866F, 1.0F, 0.39190432303424655F);
        escalar(g1, "domo_arena_121", 0.378000271772142F, 1.0F, 0.37067656627412654F);
        escalar(g1, "domo_arena_122", 0.41437485791875067F, 1.0F, 0.4930959447410342F);
        escalar(g1, "domo_arena_123", 0.4890708165678774F, 1.0F, 0.40024971027236433F);
        escalar(g1, "domo_arena_124", 0.4435840043814314F, 1.0F, 0.2775967319868267F);
        escalar(g1, "domo_arena_125", 0.46443438517478547F, 1.0F, 0.3602977608313375F);
        escalar(g1, "domo_arena_126", 0.3849509871607248F, 1.0F, 0.3408116209754244F);
        escalar(g1, "domo_arena_127", 0.43128118661284504F, 1.0F, 0.45346066564759646F);
        escalar(g1, "domo_arena_128", 0.38697504395553195F, 1.0F, 0.36823193750660405F);
        escalar(g1, "domo_arena_129", 0.4708618505029447F, 1.0F, 0.5112838792534784F);
        escalar(g1, "domo_arena_130", 0.4646890991910901F, 1.0F, 0.39083725232962374F);
        escalar(g1, "domo_arena_131", 0.3876749497123056F, 1.0F, 0.4927686080314486F);
        escalar(g1, "domo_arena_132", 0.43780599026257416F, 1.0F, 0.4367536448089462F);
        escalar(g1, "domo_arena_133", 0.39468673806785126F, 1.0F, 0.35409520635750025F);
        escalar(g1, "domo_arena_134", 0.4812460284135627F, 1.0F, 0.36735097056959837F);
        escalar(g1, "domo_arena_135", 0.45480850519182514F, 1.0F, 0.285345586616137F);
        escalar(g1, "domo_vapor_0", 0.4622014188603647F, 1.0F, 0.38956697264179985F);
        escalar(g1, "domo_vapor_1", 0.3603169758796863F, 1.0F, 0.4911682301037105F);
        escalar(g1, "domo_vapor_2", 0.3697002745979802F, 1.0F, 0.4353376831592269F);
        escalar(g1, "domo_vapor_3", 0.4161513490824537F, 1.0F, 0.3529513784500729F);
        escalar(g1, "domo_vapor_4", 0.4916363720166224F, 1.0F, 0.3661744753592526F);
        escalar(g1, "domo_vapor_5", 0.41355581893743565F, 1.0F, 0.284471997798839F);
        escalar(g1, "domo_vapor_6", 0.4621784485755081F, 1.0F, 0.5062435293468485F);
        escalar(g1, "domo_vapor_7", 0.3600548724362287F, 1.0F, 0.4788990141868167F);
        escalar(g1, "domo_vapor_8", 0.36901125248762795F, 1.0F, 0.42486639510078805F);
        escalar(g1, "domo_vapor_9", 0.4149935443424737F, 1.0F, 0.3451332012869842F);
        escalar(g1, "domo_vapor_10", 0.49002866087262725F, 1.0F, 0.47960597578453235F);
        escalar(g1, "domo_vapor_11", 0.4619640925243487F, 1.0F, 0.4962712270940036F);
        escalar(g1, "domo_vapor_12", 0.35759948506202077F, 1.0F, 0.46947621586501986F);
        escalar(g1, "domo_vapor_13", 0.36251331859976393F, 1.0F, 0.4165294136756832F);
        escalar(g1, "domo_vapor_14", 0.4040139996814009F, 1.0F, 0.33839850475079725F);
        escalar(g1, "domo_vapor_15", 0.47473716749980205F, 1.0F, 0.4703699264726754F);
        escalar(g1, "domo_vapor_16", 0.46156338130648483F, 1.0F, 0.3753228453335211F);
        escalar(g1, "domo_vapor_17", 0.3529671814075277F, 1.0F, 0.355008778005201F);
        escalar(g1, "domo_vapor_18", 0.3500511561381816F, 1.0F, 0.472302430652705F);
        escalar(g1, "domo_vapor_19", 0.3826523798408812F, 1.0F, 0.3834525027262216F);
        escalar(g1, "domo_vapor_20", 0.4447475826764277F, 1.0F, 0.2660787789236069F);
        escalar(g1, "domo_vapor_21", 0.4610448819138743F, 1.0F, 0.46495352881151514F);
        escalar(g1, "domo_vapor_22", 0.34688998089900247F, 1.0F, 0.4397005404933451F);
        escalar(g1, "domo_vapor_23", 0.4998983470344225F, 1.0F, 0.3898007675189832F);
        escalar(g1, "domo_vapor_24", 0.3531525843074943F, 1.0F, 0.47424930745349864F);
        escalar(g1, "domo_vapor_25", 0.40271276608017553F, 1.0F, 0.32833873089873655F);
        escalar(g1, "domo_vapor_26", 0.41779951872539944F, 1.0F, 0.2563776350133365F);
        escalar(g1, "domo_vapor_27", 0.4605541646707656F, 1.0F, 0.4639023444382146F);
        escalar(g1, "domo_vapor_28", 0.34105275366568305F, 1.0F, 0.4385603381733124F);
        escalar(g1, "domo_vapor_29", 0.47496927109517945F, 1.0F, 0.48560583275163716F);
        escalar(g1, "domo_vapor_30", 0.4845020678350829F, 1.0F, 0.39323817303429237F);
        escalar(g1, "domo_vapor_31", 0.35885383493412526F, 1.0F, 0.36162321064976455F);
        escalar(g1, "domo_vapor_32", 0.49112836445160557F, 1.0F, 0.41535146177007953F);
        escalar(g1, "domo_vapor_33", 0.4605541646707656F, 1.0F, 0.46390234444879974F);
        escalar(g1, "domo_vapor_34", 0.34105275366568305F, 1.0F, 0.4385603381833147F);
        escalar(g1, "domo_vapor_35", 0.47496927109517945F, 1.0F, 0.48560583276269975F);
        escalar(g1, "domo_vapor_36", 0.48450206783508254F, 1.0F, 0.3932381730432292F);
        escalar(g1, "domo_vapor_37", 0.3588538349341253F, 1.0F, 0.36162321065793596F);
        escalar(g1, "domo_vapor_38", 0.49112836445160557F, 1.0F, 0.41535146177918103F);
        escalar(g1, "domo_vapor_39", 0.4610448819138743F, 1.0F, 0.46495352881151514F);
        escalar(g1, "domo_vapor_40", 0.3468899808990023F, 1.0F, 0.4397005404933458F);
        escalar(g1, "domo_vapor_41", 0.4998983470344225F, 1.0F, 0.38980076751898435F);
        escalar(g1, "domo_vapor_42", 0.3531525843074941F, 1.0F, 0.4742493074534996F);
        escalar(g1, "domo_vapor_43", 0.40271276608017553F, 1.0F, 0.3283387308987366F);
        escalar(g1, "domo_vapor_44", 0.41779951872539944F, 1.0F, 0.2563776350133365F);
        escalar(g1, "domo_vapor_45", 0.461563381306485F, 1.0F, 0.3753228453335217F);
        escalar(g1, "domo_vapor_46", 0.3529671814075275F, 1.0F, 0.3550087780052005F);
        escalar(g1, "domo_vapor_47", 0.3500511561381812F, 1.0F, 0.4723024306527042F);
        escalar(g1, "domo_vapor_48", 0.38265237984088124F, 1.0F, 0.38345250272622156F);
        escalar(g1, "domo_vapor_49", 0.4447475826764277F, 1.0F, 0.2660787789236068F);
        escalar(g1, "domo_vapor_50", 0.46196409252434883F, 1.0F, 0.4962712270940043F);
        escalar(g1, "domo_vapor_51", 0.35759948506202094F, 1.0F, 0.4694762158650213F);
        escalar(g1, "domo_vapor_52", 0.36251331859976355F, 1.0F, 0.41652941367568375F);
        escalar(g1, "domo_vapor_53", 0.4040139996814009F, 1.0F, 0.338398504750797F);
        escalar(g1, "domo_vapor_54", 0.47473716749980216F, 1.0F, 0.47036992647267506F);
        escalar(g1, "domo_vapor_55", 0.46217844857550805F, 1.0F, 0.5062435293468479F);
        escalar(g1, "domo_vapor_56", 0.3600548724362287F, 1.0F, 0.47889901418681624F);
        escalar(g1, "domo_vapor_57", 0.3690112524876281F, 1.0F, 0.42486639510078783F);
        escalar(g1, "domo_vapor_58", 0.414993544342474F, 1.0F, 0.3451332012869837F);
        escalar(g1, "domo_vapor_59", 0.49002866087262675F, 1.0F, 0.4796059757845317F);
        escalar(g1, "domo_vapor_60", 0.4622014188603647F, 1.0F, 0.389566972634659F);
        escalar(g1, "domo_vapor_61", 0.3603169758796862F, 1.0F, 0.49116823009471394F);
        escalar(g1, "domo_vapor_62", 0.3697002745979801F, 1.0F, 0.4353376831512672F);
        escalar(g1, "domo_vapor_63", 0.4161513490824542F, 1.0F, 0.35295137844364305F);
        escalar(g1, "domo_vapor_64", 0.49163637201662186F, 1.0F, 0.36617447535263903F);
        escalar(g1, "domo_vapor_65", 0.41355581893743565F, 1.0F, 0.2844719977939281F);
        escalar(g1, "domo_vapor_66", 0.4622014188603647F, 1.0F, 0.3895669726489406F);
        escalar(g1, "domo_vapor_67", 0.3603169758796862F, 1.0F, 0.49116823011270677F);
        escalar(g1, "domo_vapor_68", 0.36970027459798055F, 1.0F, 0.4353376831671867F);
        escalar(g1, "domo_vapor_69", 0.41615134908245377F, 1.0F, 0.352951378456503F);
        escalar(g1, "domo_vapor_70", 0.49163637201662236F, 1.0F, 0.36617447536586617F);
        escalar(g1, "domo_vapor_71", 0.41355581893743565F, 1.0F, 0.2844719978037498F);
        escalar(g1, "domo_vapor_72", 0.46217844857550805F, 1.0F, 0.5062435293468485F);
        escalar(g1, "domo_vapor_73", 0.36005487243622863F, 1.0F, 0.4788990141868168F);
        escalar(g1, "domo_vapor_74", 0.36901125248762856F, 1.0F, 0.42486639510078805F);
        escalar(g1, "domo_vapor_75", 0.414993544342473F, 1.0F, 0.34513320128698355F);
        escalar(g1, "domo_vapor_76", 0.4900286608726277F, 1.0F, 0.47960597578453135F);
        escalar(g1, "domo_vapor_77", 0.46196409252434867F, 1.0F, 0.49627122709400473F);
        escalar(g1, "domo_vapor_78", 0.3575994850620208F, 1.0F, 0.469476215865021F);
        escalar(g1, "domo_vapor_79", 0.3625133185997638F, 1.0F, 0.4165294136756839F);
        escalar(g1, "domo_vapor_80", 0.40401399968140034F, 1.0F, 0.3383985047507984F);
        escalar(g1, "domo_vapor_81", 0.4747371674998026F, 1.0F, 0.4703699264726774F);
        escalar(g1, "domo_vapor_82", 0.46156338130648483F, 1.0F, 0.3753228453335211F);
        escalar(g1, "domo_vapor_83", 0.35296718140752764F, 1.0F, 0.3550087780052009F);
        escalar(g1, "domo_vapor_84", 0.3500511561381816F, 1.0F, 0.47230243065270494F);
        escalar(g1, "domo_vapor_85", 0.3826523798408808F, 1.0F, 0.38345250272622067F);
        escalar(g1, "domo_vapor_86", 0.44474758267642805F, 1.0F, 0.266078778923606F);
        escalar(g1, "domo_vapor_87", 0.4610448819138743F, 1.0F, 0.4649535288115139F);
        escalar(g1, "domo_vapor_88", 0.34688998089900247F, 1.0F, 0.439700540493344F);
        escalar(g1, "domo_vapor_89", 0.49989834703442254F, 1.0F, 0.389800767518982F);
        escalar(g1, "domo_vapor_90", 0.3531525843074939F, 1.0F, 0.4742493074534978F);
        escalar(g1, "domo_vapor_91", 0.4027127660801759F, 1.0F, 0.3283387308987357F);
        escalar(g1, "domo_vapor_92", 0.41779951872539967F, 1.0F, 0.25637763501333477F);
        escalar(g1, "domo_vapor_93", 0.4605541646707656F, 1.0F, 0.46390234443208744F);
        escalar(g1, "domo_vapor_94", 0.34105275366568305F, 1.0F, 0.43856033816752327F);
        escalar(g1, "domo_vapor_95", 0.47496927109517945F, 1.0F, 0.4856058327452348F);
        escalar(g1, "domo_vapor_96", 0.4845020678350829F, 1.0F, 0.39323817302912045F);
        escalar(g1, "domo_vapor_97", 0.35885383493412526F, 1.0F, 0.36162321064503633F);
        escalar(g1, "domo_vapor_98", 0.49112836445160585F, 1.0F, 0.4153514617648136F);
        escalar(g1, "domo_vapor_99", 0.4605541646707656F, 1.0F, 0.4639023444549276F);
        escalar(g1, "domo_vapor_100", 0.34105275366568305F, 1.0F, 0.4385603381891047F);
        escalar(g1, "domo_vapor_101", 0.47496927109517945F, 1.0F, 0.48560583276910296F);
        escalar(g1, "domo_vapor_102", 0.48450206783508254F, 1.0F, 0.39323817304840203F);
        escalar(g1, "domo_vapor_103", 0.3588538349341253F, 1.0F, 0.36162321066266534F);
    }

    private static void escalas3(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g1, "domo_vapor_104", 0.49112836445160557F, 1.0F, 0.41535146178444876F);
        escalar(g1, "domo_vapor_105", 0.4610448819138743F, 1.0F, 0.464953528811515F);
        escalar(g1, "domo_vapor_106", 0.34688998089900247F, 1.0F, 0.4397005404933451F);
        escalar(g1, "domo_vapor_107", 0.49989834703442254F, 1.0F, 0.3898007675189831F);
        escalar(g1, "domo_vapor_108", 0.3531525843074938F, 1.0F, 0.47424930745349864F);
        escalar(g1, "domo_vapor_109", 0.402712766080176F, 1.0F, 0.32833873089873566F);
        escalar(g1, "domo_vapor_110", 0.41779951872539917F, 1.0F, 0.2563776350133347F);
        escalar(g1, "domo_vapor_111", 0.46156338130648483F, 1.0F, 0.3753228453335217F);
        escalar(g1, "domo_vapor_112", 0.3529671814075277F, 1.0F, 0.3550087780052016F);
        escalar(g1, "domo_vapor_113", 0.35005115613818144F, 1.0F, 0.4723024306527063F);
        escalar(g1, "domo_vapor_114", 0.3826523798408809F, 1.0F, 0.3834525027262224F);
        escalar(g1, "domo_vapor_115", 0.44474758267642817F, 1.0F, 0.26607877892360765F);
        escalar(g1, "domo_vapor_116", 0.4619640925243487F, 1.0F, 0.4962712270940035F);
        escalar(g1, "domo_vapor_117", 0.3575994850620206F, 1.0F, 0.4694762158650201F);
        escalar(g1, "domo_vapor_118", 0.3625133185997637F, 1.0F, 0.4165294136756835F);
        escalar(g1, "domo_vapor_119", 0.4040139996814009F, 1.0F, 0.33839850475079725F);
        escalar(g1, "domo_vapor_120", 0.47473716749980216F, 1.0F, 0.47036992647267534F);
        escalar(g1, "domo_vapor_121", 0.4621784485755081F, 1.0F, 0.5062435293468476F);
        escalar(g1, "domo_vapor_122", 0.36005487243622847F, 1.0F, 0.4788990141868158F);
        escalar(g1, "domo_vapor_123", 0.36901125248762817F, 1.0F, 0.424866395100787F);
        escalar(g1, "domo_vapor_124", 0.414993544342474F, 1.0F, 0.34513320128698305F);
        escalar(g1, "domo_vapor_125", 0.49002866087262675F, 1.0F, 0.4796059757845308F);
        escalar(g1, "domo_vapor_126", 0.4622014188603647F, 1.0F, 0.38956697263019974F);
        escalar(g1, "domo_vapor_127", 0.3603169758796862F, 1.0F, 0.4911682300890959F);
        escalar(g1, "domo_vapor_128", 0.36970027459798044F, 1.0F, 0.4353376831462965F);
        escalar(g1, "domo_vapor_129", 0.416151349082454F, 1.0F, 0.35295137843962765F);
        escalar(g1, "domo_vapor_130", 0.49163637201662186F, 1.0F, 0.366174475348509F);
        escalar(g1, "domo_vapor_131", 0.41355581893743576F, 1.0F, 0.28447199779086146F);
        escalar(g1, "domo_arena2_0", 0.40746560742201304F, 1.0F, 0.3901572663734595F);
        escalar(g1, "domo_arena2_1", 0.3403605023710514F, 1.0F, 0.49191191912596705F);
        escalar(g1, "domo_arena2_2", 0.3846544638537161F, 1.0F, 0.43599567469771355F);
        escalar(g1, "domo_arena2_3", 0.46246371192794045F, 1.0F, 0.35348291056093295F);
        escalar(g1, "domo_arena2_4", 0.422887116449304F, 1.0F, 0.3667211878310425F);
        escalar(g1, "domo_arena2_5", 0.4794198024108156F, 1.0F, 0.28487795091911783F);
        escalar(g1, "domo_arena2_6", 0.4073164882196891F, 1.0F, 0.34827169980707673F);
        escalar(g1, "domo_arena2_7", 0.5081539557772465F, 1.0F, 0.49417234827712037F);
        escalar(g1, "domo_arena2_8", 0.3808533828095828F, 1.0F, 0.43837973776840533F);
        escalar(g1, "domo_arena2_9", 0.45648337492631913F, 1.0F, 0.3560494139322291F);
        escalar(g1, "domo_arena2_10", 0.416851768549851F, 1.0F, 0.49457660998437303F);
        escalar(g1, "domo_arena2_11", 0.40684519223577514F, 1.0F, 0.3605079707082293F);
        escalar(g1, "domo_arena2_12", 0.500538633576458F, 1.0F, 0.34101024765409726F);
        escalar(g1, "domo_arena2_13", 0.36857903799965225F, 1.0F, 0.45372427315686437F);
        escalar(g1, "domo_arena2_14", 0.43703020849300084F, 1.0F, 0.3684448822751069F);
        escalar(g1, "domo_arena2_15", 0.3971560375245963F, 1.0F, 0.5115759144434867F);
        escalar(g1, "domo_arena2_16", 0.40609253209696483F, 1.0F, 0.4262462868109882F);
        escalar(g1, "domo_arena2_17", 0.48815125412929133F, 1.0F, 0.403126184269847F);
        escalar(g1, "domo_arena2_18", 0.34810851057365194F, 1.0F, 0.3574409824469476F);
        escalar(g1, "domo_arena2_19", 0.4040564629778644F, 1.0F, 0.4350384729816613F);
        escalar(g1, "domo_arena2_20", 0.4846941685742708F, 1.0F, 0.3014516099427283F);
        escalar(g1, "domo_arena2_21", 0.4097860426034064F, 1.0F, 0.23641300788186564F);
        escalar(g1, "domo_arena2_22", 0.4051868778791694F, 1.0F, 0.40373583472137703F);
        escalar(g1, "domo_arena2_23", 0.4728570788405233F, 1.0F, 0.3817642876228441F);
        escalar(g1, "domo_arena2_24", 0.4827515778437593F, 1.0F, 0.4511315004713879F);
        escalar(g1, "domo_arena2_25", 0.36052156435887367F, 1.0F, 0.36570978120062686F);
        escalar(g1, "domo_arena2_26", 0.42464717324921586F, 1.0F, 0.37929725338400944F);
        escalar(g1, "domo_arena2_27", 0.445818044241309F, 1.0F, 0.2942161191802977F);
        escalar(g1, "domo_arena2_28", 0.40437002696214946F, 1.0F, 0.45036023757268073F);
        escalar(g1, "domo_arena2_29", 0.4586874178572232F, 1.0F, 0.4257277068956485F);
        escalar(g1, "domo_arena2_30", 0.44453860514779153F, 1.0F, 0.45246474597407305F);
        escalar(g1, "domo_arena2_31", 0.4750110621588915F, 1.0F, 0.4578428542221774F);
        escalar(g1, "domo_arena2_32", 0.36289408514497595F, 1.0F, 0.4206896702417125F);
        escalar(g1, "domo_arena2_33", 0.5026890758134998F, 1.0F, 0.4811398280844991F);
        escalar(g1, "domo_arena2_34", 0.40437002696214946F, 1.0F, 0.45036023758297455F);
        escalar(g1, "domo_arena2_35", 0.4586874178572231F, 1.0F, 0.4257277069053753F);
        escalar(g1, "domo_arena2_36", 0.44453860514779164F, 1.0F, 0.4524647459844001F);
        escalar(g1, "domo_arena2_37", 0.47501106215889133F, 1.0F, 0.457842854232605F);
        escalar(g1, "domo_arena2_38", 0.36289408514497595F, 1.0F, 0.4206896702512462F);
        escalar(g1, "domo_arena2_39", 0.5026890758134996F, 1.0F, 0.4811398280951178F);
        escalar(g1, "domo_arena2_40", 0.4051868778791694F, 1.0F, 0.40373583472137803F);
        escalar(g1, "domo_arena2_41", 0.4728570788405233F, 1.0F, 0.38176428762284476F);
        escalar(g1, "domo_arena2_42", 0.48275157784375944F, 1.0F, 0.45113150047138834F);
        escalar(g1, "domo_arena2_43", 0.36052156435887356F, 1.0F, 0.36570978120062714F);
        escalar(g1, "domo_arena2_44", 0.42464717324921564F, 1.0F, 0.3792972533840099F);
        escalar(g1, "domo_arena2_45", 0.445818044241309F, 1.0F, 0.29421611918029855F);
        escalar(g1, "domo_arena2_46", 0.4060925320969648F, 1.0F, 0.4262462868109882F);
        escalar(g1, "domo_arena2_47", 0.4881512541292913F, 1.0F, 0.40312618426984725F);
        escalar(g1, "domo_arena2_48", 0.3481085105736523F, 1.0F, 0.35744098244694794F);
        escalar(g1, "domo_arena2_49", 0.40405646297786424F, 1.0F, 0.43503847298166154F);
        escalar(g1, "domo_arena2_50", 0.48469416857427045F, 1.0F, 0.3014516099427285F);
        escalar(g1, "domo_arena2_51", 0.40978604260340645F, 1.0F, 0.23641300788186564F);
        escalar(g1, "domo_arena2_52", 0.40684519223577503F, 1.0F, 0.36050797070822926F);
        escalar(g1, "domo_arena2_53", 0.500538633576458F, 1.0F, 0.34101024765409704F);
        escalar(g1, "domo_arena2_54", 0.3685790379996523F, 1.0F, 0.45372427315686437F);
        escalar(g1, "domo_arena2_55", 0.4370302084930009F, 1.0F, 0.3684448822751071F);
        escalar(g1, "domo_arena2_56", 0.39715603752459605F, 1.0F, 0.5115759144434864F);
        escalar(g1, "domo_arena2_57", 0.4073164882196891F, 1.0F, 0.348271699807077F);
        escalar(g1, "domo_arena2_58", 0.5081539557772466F, 1.0F, 0.4941723482771207F);
        escalar(g1, "domo_arena2_59", 0.3808533828095828F, 1.0F, 0.43837973776840544F);
        escalar(g1, "domo_arena2_60", 0.45648337492631924F, 1.0F, 0.3560494139322292F);
        escalar(g1, "domo_arena2_61", 0.41685176854985095F, 1.0F, 0.49457660998437325F);
        escalar(g1, "domo_arena2_62", 0.4074656074220129F, 1.0F, 0.3901572663663295F);
        escalar(g1, "domo_arena2_63", 0.3403605023710515F, 1.0F, 0.4919119191169843F);
        escalar(g1, "domo_arena2_64", 0.3846544638537163F, 1.0F, 0.4359956746897659F);
        escalar(g1, "domo_arena2_65", 0.46246371192794045F, 1.0F, 0.35348291055451275F);
        escalar(g1, "domo_arena2_66", 0.422887116449304F, 1.0F, 0.36672118782443897F);
        escalar(g1, "domo_arena2_67", 0.4794198024108156F, 1.0F, 0.2848779509142145F);
        escalar(g1, "domo_arena2_68", 0.4074656074220129F, 1.0F, 0.3901572663805893F);
        escalar(g1, "domo_arena2_69", 0.3403605023710514F, 1.0F, 0.4919119191349497F);
        escalar(g1, "domo_arena2_70", 0.38465446385371643F, 1.0F, 0.4359956747056611F);
        escalar(g1, "domo_arena2_71", 0.4624637119279403F, 1.0F, 0.353482910567353F);
        escalar(g1, "domo_arena2_72", 0.4228871164493042F, 1.0F, 0.36672118783764585F);
        escalar(g1, "domo_arena2_73", 0.4794198024108156F, 1.0F, 0.2848779509240211F);
        escalar(g1, "domo_arena2_74", 0.4073164882196891F, 1.0F, 0.3482716998070767F);
        escalar(g1, "domo_arena2_75", 0.5081539557772465F, 1.0F, 0.4941723482771201F);
        escalar(g1, "domo_arena2_76", 0.3808533828095831F, 1.0F, 0.438379737768405F);
        escalar(g1, "domo_arena2_77", 0.45648337492631913F, 1.0F, 0.356049413932229F);
        escalar(g1, "domo_arena2_78", 0.4168517685498512F, 1.0F, 0.4945766099843732F);
        escalar(g1, "domo_arena2_79", 0.40684519223577503F, 1.0F, 0.36050797070823F);
        escalar(g1, "domo_arena2_80", 0.500538633576458F, 1.0F, 0.34101024765409793F);
        escalar(g1, "domo_arena2_81", 0.3685790379996525F, 1.0F, 0.4537242731568655F);
        escalar(g1, "domo_arena2_82", 0.43703020849300095F, 1.0F, 0.3684448822751079F);
        escalar(g1, "domo_arena2_83", 0.3971560375245962F, 1.0F, 0.5115759144434873F);
        escalar(g1, "domo_arena2_84", 0.4060925320969648F, 1.0F, 0.4262462868109876F);
        escalar(g1, "domo_arena2_85", 0.4881512541292914F, 1.0F, 0.40312618426984675F);
        escalar(g1, "domo_arena2_86", 0.3481085105736523F, 1.0F, 0.35744098244694733F);
        escalar(g1, "domo_arena2_87", 0.4040564629778644F, 1.0F, 0.43503847298166043F);
        escalar(g1, "domo_arena2_88", 0.48469416857427067F, 1.0F, 0.3014516099427276F);
        escalar(g1, "domo_arena2_89", 0.40978604260340656F, 1.0F, 0.23641300788186478F);
        escalar(g1, "domo_arena2_90", 0.4051868778791694F, 1.0F, 0.40373583472137686F);
        escalar(g1, "domo_arena2_91", 0.47285707884052336F, 1.0F, 0.3817642876228437F);
        escalar(g1, "domo_arena2_92", 0.48275157784375955F, 1.0F, 0.45113150047138734F);
        escalar(g1, "domo_arena2_93", 0.36052156435887367F, 1.0F, 0.3657097812006264F);
        escalar(g1, "domo_arena2_94", 0.4246471732492161F, 1.0F, 0.37929725338400927F);
        escalar(g1, "domo_arena2_95", 0.4458180442413092F, 1.0F, 0.29421611918029855F);
        escalar(g1, "domo_arena2_96", 0.40437002696214946F, 1.0F, 0.45036023756672255F);
        escalar(g1, "domo_arena2_97", 0.4586874178572231F, 1.0F, 0.42572770689001865F);
        escalar(g1, "domo_arena2_98", 0.44453860514779175F, 1.0F, 0.45246474596809555F);
        escalar(g1, "domo_arena2_99", 0.4750110621588913F, 1.0F, 0.45784285421614157F);
        escalar(g1, "domo_arena2_100", 0.36289408514497623F, 1.0F, 0.42068967023619414F);
        escalar(g1, "domo_arena2_101", 0.5026890758134998F, 1.0F, 0.4811398280783523F);
        escalar(g1, "domo_arena2_102", 0.40437002696214946F, 1.0F, 0.45036023758893334F);
        escalar(g1, "domo_arena2_103", 0.4586874178572231F, 1.0F, 0.42572770691100575F);
        escalar(g1, "domo_arena2_104", 0.44453860514779153F, 1.0F, 0.45246474599037817F);
        escalar(g1, "domo_arena2_105", 0.47501106215889133F, 1.0F, 0.4578428542386415F);
        escalar(g1, "domo_arena2_106", 0.36289408514497595F, 1.0F, 0.4206896702567651F);
        escalar(g1, "domo_arena2_107", 0.5026890758134996F, 1.0F, 0.4811398281012646F);
        escalar(g1, "domo_arena2_108", 0.4051868778791694F, 1.0F, 0.4037358347213774F);
        escalar(g1, "domo_arena2_109", 0.4728570788405232F, 1.0F, 0.3817642876228443F);
        escalar(g1, "domo_arena2_110", 0.4827515778437594F, 1.0F, 0.4511315004713879F);
        escalar(g1, "domo_arena2_111", 0.36052156435887345F, 1.0F, 0.36570978120062686F);
        escalar(g1, "domo_arena2_112", 0.42464717324921564F, 1.0F, 0.3792972533840099F);
        escalar(g1, "domo_arena2_113", 0.445818044241309F, 1.0F, 0.29421611918029855F);
        escalar(g1, "domo_arena2_114", 0.40609253209696483F, 1.0F, 0.4262462868109888F);
        escalar(g1, "domo_arena2_115", 0.4881512541292911F, 1.0F, 0.40312618426984786F);
        escalar(g1, "domo_arena2_116", 0.3481085105736523F, 1.0F, 0.35744098244694844F);
        escalar(g1, "domo_arena2_117", 0.40405646297786396F, 1.0F, 0.4350384729816622F);
        escalar(g1, "domo_arena2_118", 0.48469416857427056F, 1.0F, 0.30145160994272874F);
        escalar(g1, "domo_arena2_119", 0.40978604260340645F, 1.0F, 0.23641300788186564F);
        escalar(g1, "domo_arena2_120", 0.40684519223577503F, 1.0F, 0.3605079707082292F);
        escalar(g1, "domo_arena2_121", 0.5005386335764578F, 1.0F, 0.34101024765409743F);
    }

    private static void escalas4(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g1, "domo_arena2_122", 0.36857903799965247F, 1.0F, 0.4537242731568647F);
        escalar(g1, "domo_arena2_123", 0.4370302084930009F, 1.0F, 0.36844488227510686F);
        escalar(g1, "domo_arena2_124", 0.39715603752459605F, 1.0F, 0.5115759144434859F);
        escalar(g1, "domo_arena2_125", 0.40731648821968897F, 1.0F, 0.34827169980707645F);
        escalar(g1, "domo_arena2_126", 0.5081539557772465F, 1.0F, 0.49417234827711953F);
        escalar(g1, "domo_arena2_127", 0.38085338280958303F, 1.0F, 0.4383797377684043F);
        escalar(g1, "domo_arena2_128", 0.45648337492631924F, 1.0F, 0.35604941393222855F);
        escalar(g1, "domo_arena2_129", 0.41685176854985084F, 1.0F, 0.4945766099843727F);
        escalar(g1, "domo_arena2_130", 0.40746560742201304F, 1.0F, 0.3901572663618771F);
        escalar(g1, "domo_arena2_131", 0.3403605023710514F, 1.0F, 0.49191191911137494F);
        escalar(g1, "domo_arena2_132", 0.3846544638537163F, 1.0F, 0.435995674684803F);
        escalar(g1, "domo_arena2_133", 0.4624637119279402F, 1.0F, 0.35348291055050357F);
        escalar(g1, "domo_arena2_134", 0.42288711644930405F, 1.0F, 0.36672118782031526F);
        escalar(g1, "domo_arena2_135", 0.4794198024108156F, 1.0F, 0.2848779509111525F);
        escalar(g1, "silbato_0", 1.0F, 0.12318393766817158F, 0.12318393766817158F);
        escalar(g1, "silbato_1", 1.0F, 0.12318393766817158F, 0.12318393766817158F);
        escalar(g1, "faro_0", 0.5100083458096798F, 0.7333333333333334F, 0.5100083458096798F);
        escalar(g1, "faro_1", 0.5100083458096798F, 0.7333333333333334F, 0.5100083458096798F);
        escalar(g1, "faro_2", 0.5100083458096798F, 0.7333333333333334F, 0.5100083458096798F);
        escalar(g1, "faro_3", 0.5100083458096798F, 0.7333333333333334F, 0.5100083458096798F);
        escalar(g1, "faro_vidrio", 0.24761904761904763F, 0.15F, 0.24761904761904763F);
        escalar(g1, "num_frentei", 1.0F, 0.5F, 0.5F);
        escalar(g1, "num_frented", 1.0F, 0.5F, 0.5F);
        escalar(g1, "cabina_techo_0", 1.0006060606060607F, 1.0F, 0.8790544139733855F);
        escalar(g1, "cabina_techo_1", 1.0006060606060607F, 1.0F, 0.8790544139733858F);
        escalar(g1, "cabina_techo_2", 1.0006060606060607F, 1.0F, 0.8790544139733883F);
        escalar(g1, "cabina_techo_3", 1.0006060606060607F, 1.0F, 0.8790544139733867F);
        escalar(g1, "cabina_techo_4", 1.0006060606060607F, 1.0F, 0.8790544139733864F);
        escalar(g1, "cabina_techo_5", 1.0006060606060607F, 1.0F, 0.8790544139733871F);
        escalar(g1, "cabina_techo_6", 1.0006060606060607F, 1.0F, 0.8790544139733858F);
        escalar(g1, "cabina_techo_7", 1.0006060606060607F, 1.0F, 0.8790544139733871F);
        escalar(g1, "cabina_techo_8", 1.0006060606060607F, 1.0F, 0.8790544139733872F);
        escalar(g1, "cabina_techo_9", 1.0006060606060607F, 1.0F, 0.8790544139733864F);
        escalar(g1, "cabina_techo_10", 1.0006060606060607F, 1.0F, 0.8790544139733872F);
        escalar(g1, "cabina_techo_11", 1.0006060606060607F, 1.0F, 0.8790544139733859F);
        escalar(g1, "numeroi", 0.5F, 0.5F, 1.0F);
        escalar(g1, "numerod", 0.5F, 0.5F, 1.0F);
        escalar(g2, "tender_caja_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g2, "tender_caja_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g2, "tender_caja_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g2, "tender_caja_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g2, "tender_caja_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g2, "tender_caja_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g2, "tender_caja_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g2, "tender_caja_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g2, "tender_caja_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g2, "tender_caja_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g2, "tender_caja_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g2, "tender_caja_tapab", 1.0F, 0.5F, 0.5F);
    }
}
