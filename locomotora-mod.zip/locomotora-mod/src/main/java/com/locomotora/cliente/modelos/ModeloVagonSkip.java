package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Vagoneta volcadora en V" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonSkip {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_skip"), "main"),
            LocomotoraMod.id("textures/entity/vagon_skip.png"),
            List.of(
                new DatosModelo.Animada("ri0_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.0F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri0_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.0F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri0_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.0F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("ri1_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.0F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri1_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.0F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri1_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.0F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd0_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.0F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd0_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.0F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd0_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.0F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd1_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.0F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd1_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.0F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd1_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.0F, -2.5F, 1.0471975511965976F, "cuerpo")),
            ModeloVagonSkip::crearCapa,
            16.0F,
            ModeloVagonSkip::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -5.0F, 5.0F)));

    private ModeloVagonSkip() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 64);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("ri0_0", CubeListBuilder.create().texOffs(192, 0).addBox(-2.5F, -2.5F, -6.0F, 5.0F, 5.0F, 2.0F).texOffs(870, 48).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(226, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(594, 48).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-5.0F, -2.5F, 0.0F));
        g.addOrReplaceChild("ri0_1", CubeListBuilder.create().texOffs(884, 48).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-5.0F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri0_2", CubeListBuilder.create().texOffs(898, 48).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(238, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-5.0F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ri1_0", CubeListBuilder.create().texOffs(192, 0).addBox(-2.5F, -2.5F, -6.0F, 5.0F, 5.0F, 2.0F).texOffs(870, 48).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(226, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(604, 48).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(5.0F, -2.5F, 0.0F));
        g.addOrReplaceChild("ri1_1", CubeListBuilder.create().texOffs(884, 48).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(5.0F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri1_2", CubeListBuilder.create().texOffs(898, 48).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(238, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(5.0F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd0_0", CubeListBuilder.create().texOffs(192, 0).addBox(-2.5F, -2.5F, 4.0F, 5.0F, 5.0F, 2.0F).texOffs(870, 48).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(226, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(614, 48).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-5.0F, -2.5F, 0.0F));
        g.addOrReplaceChild("rd0_1", CubeListBuilder.create().texOffs(884, 48).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-5.0F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd0_2", CubeListBuilder.create().texOffs(898, 48).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(238, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-5.0F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd1_0", CubeListBuilder.create().texOffs(192, 0).addBox(-2.5F, -2.5F, 4.0F, 5.0F, 5.0F, 2.0F).texOffs(870, 48).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(226, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(624, 48).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(5.0F, -2.5F, 0.0F));
        g.addOrReplaceChild("rd1_1", CubeListBuilder.create().texOffs(884, 48).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(5.0F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd1_2", CubeListBuilder.create().texOffs(898, 48).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(238, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(5.0F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(794, 48).addBox(-9.0F, -6.0F, 2.0F, 18.0F, 3.0F, 1.0F).texOffs(832, 48).addBox(-9.0F, -6.0F, -3.0F, 18.0F, 3.0F, 1.0F).texOffs(116, 0).addBox(-11.0F, -7.0F, -5.5F, 2.0F, 4.0F, 11.0F).texOffs(206, 0).addBox(-11.0F, -11.0F, -1.5F, 2.0F, 4.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("topei", CubeListBuilder.create().texOffs(168, 0).addBox(-13.0F, -7.0F, -2.0F, 2.0F, 4.0F, 4.0F).texOffs(984, 48).addBox(-14.0F, -5.5F, -0.5F, 1.0F, 1.0F, 1.0F).texOffs(142, 0).addBox(9.0F, -7.0F, -5.5F, 2.0F, 4.0F, 11.0F).texOffs(216, 0).addBox(9.0F, -11.0F, -1.5F, 2.0F, 4.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("toped", CubeListBuilder.create().texOffs(180, 0).addBox(11.0F, -7.0F, -2.0F, 2.0F, 4.0F, 4.0F).texOffs(988, 48).addBox(13.0F, -5.5F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cuba_0", CubeListBuilder.create().texOffs(244, 0).addBox(-8.5F, -1.0F, -2.5F, 17.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -14.5F, -6.699999999999999F, -1.4219063791853994F, 0.0F, 0.0F));
        g.addOrReplaceChild("cuba_1", CubeListBuilder.create().texOffs(572, 0).addBox(-8.5F, -1.0F, -2.0F, 17.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -10.95F, -5.45F, -1.0209431441183114F, 0.0F, 0.0F));
        g.addOrReplaceChild("cuba_2", CubeListBuilder.create().texOffs(634, 48).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -8.65F, -3.45F, -0.6202494859828215F, 0.0F, 0.0F));
        g.addOrReplaceChild("cuba_3", CubeListBuilder.create().texOffs(674, 48).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -7.7F, -1.2F, -0.165148677414627F, 0.0F, 0.0F));
        g.addOrReplaceChild("cuba_4", CubeListBuilder.create().texOffs(714, 48).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -7.699999999999999F, 1.2F, 0.165148677414627F, 0.0F, 0.0F));
        g.addOrReplaceChild("cuba_5", CubeListBuilder.create().texOffs(754, 48).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -8.65F, 3.45F, 0.6202494859828215F, 0.0F, 0.0F));
        g.addOrReplaceChild("cuba_6", CubeListBuilder.create().texOffs(614, 0).addBox(-8.5F, -1.0F, -2.0F, 17.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -10.95F, 5.45F, 1.0209431441183114F, 0.0F, 0.0F));
        g.addOrReplaceChild("cuba_7", CubeListBuilder.create().texOffs(288, 0).addBox(-8.5F, -1.0F, -2.5F, 17.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -14.5F, 6.7F, 1.4219063791853994F, 0.0F, 0.0F));
        g.addOrReplaceChild("cuba_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -20.0F, 0.0F, 1.0F, 20.0F, 28.0F), PartPose.offset(-9.0F, -7.0F, -7.0F));
        g.addOrReplaceChild("cuba_tapab", CubeListBuilder.create().texOffs(58, 0).addBox(0.0F, -20.0F, 0.0F, 1.0F, 20.0F, 28.0F), PartPose.offset(8.0F, -7.0F, -7.0F));
        g.addOrReplaceChild("cuba_borde", CubeListBuilder.create().texOffs(912, 48).addBox(-8.5F, -17.0F, 6.5F, 17.0F, 1.0F, 1.0F).texOffs(948, 48).addBox(-8.5F, -17.0F, -7.5F, 17.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("carga_0", CubeListBuilder.create().texOffs(816, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.0F, -15.884374999999999F, -5.512499999999999F, -2.8069542478980205F, 0.04394153768575067F, -0.26178795331901156F));
        g.addOrReplaceChild("carga_1", CubeListBuilder.create().texOffs(332, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-5.0F, -16.25670927521516F, -5.512499999999999F, -2.4482113286612273F, 0.021593049837610862F, -0.06979218427049326F));
        g.addOrReplaceChild("carga_2", CubeListBuilder.create().texOffs(352, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-3.0F, -16.38861665008227F, -5.512499999999999F, -2.3559080531594163F, 0.010983266407408068F, -0.03293094114465508F));
        g.addOrReplaceChild("carga_3", CubeListBuilder.create().texOffs(372, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.0F, -16.446216962915106F, -5.512499999999999F, -2.320309479855671F, 0.003404148990516646F, -0.009993717153748805F));
        g.addOrReplaceChild("carga_4", CubeListBuilder.create().texOffs(392, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(1.0F, -16.446216962915106F, -5.512499999999999F, -2.320309479855671F, -0.003404148990516646F, 0.009993717153748805F));
        g.addOrReplaceChild("carga_5", CubeListBuilder.create().texOffs(412, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(3.0F, -16.38861665008227F, -5.512499999999999F, -2.3559080531594163F, -0.010983266407408068F, 0.03293094114465508F));
        g.addOrReplaceChild("carga_6", CubeListBuilder.create().texOffs(432, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(5.0F, -16.25670927521516F, -5.512499999999999F, -2.4482113286612273F, -0.021593049837610862F, 0.06979218427049326F));
        g.addOrReplaceChild("carga_7", CubeListBuilder.create().texOffs(834, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -15.884375F, -5.512499999999999F, -2.8069542478980205F, -0.04394153768575067F, 0.26178795331901156F));
        g.addOrReplaceChild("carga_8", CubeListBuilder.create().texOffs(852, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.0F, -16.25670927521516F, -3.9375F, -3.048457354577388F, 0.03035327627504174F, -0.5782425874825006F));
        g.addOrReplaceChild("carga_9", CubeListBuilder.create().texOffs(870, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -17.116543550430322F, -3.9375F, -2.8939309095919996F, 0.02411053684644055F, -0.19430280578133385F));
        g.addOrReplaceChild("carga_10", CubeListBuilder.create().texOffs(888, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, -17.421158219597842F, -3.9375F, -2.842632446344867F, 0.014277151602585228F, -0.09674335181447509F));
        g.addOrReplaceChild("carga_11", CubeListBuilder.create().texOffs(906, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -17.554175044890563F, -3.9375F, -2.820854593514517F, 0.004716091416807445F, -0.02994999715862135F));
        g.addOrReplaceChild("carga_12", CubeListBuilder.create().texOffs(924, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -17.554175044890563F, -3.9375F, -2.820854593514517F, -0.004716091416807445F, 0.02994999715862135F));
        g.addOrReplaceChild("carga_13", CubeListBuilder.create().texOffs(942, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -17.421158219597846F, -3.9375F, -2.842632446344867F, -0.014277151602585228F, 0.09674335181447509F));
        g.addOrReplaceChild("carga_14", CubeListBuilder.create().texOffs(960, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.0F, -17.116543550430322F, -3.9375F, -2.8939309095919996F, -0.02411053684644055F, 0.19430280578133385F));
        g.addOrReplaceChild("carga_15", CubeListBuilder.create().texOffs(978, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -16.25670927521516F, -3.9375F, -3.048457354577388F, -0.03035327627504174F, 0.5782425874825006F));
        g.addOrReplaceChild("carga_16", CubeListBuilder.create().texOffs(656, 0).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.0F, -16.38861665008227F, -2.3625F, -3.0977938592701464F, 0.017238744545181532F, -0.6670057487604275F));
        g.addOrReplaceChild("carga_17", CubeListBuilder.create().texOffs(996, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -17.421158219597846F, -2.3625F, -3.0170218872840673F, 0.015029988930452324F, -0.23737084868274308F));
        g.addOrReplaceChild("carga_18", CubeListBuilder.create().texOffs(0, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, -17.78695813903115F, -2.3625F, -2.989152779830681F, 0.009144642548817519F, -0.11987201038370261F));
        g.addOrReplaceChild("carga_19", CubeListBuilder.create().texOffs(18, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -17.946692875734165F, -2.3625F, -2.977143714937088F, 0.0030571222452943857F, -0.03733434218299329F));
        g.addOrReplaceChild("carga_20", CubeListBuilder.create().texOffs(36, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -17.946692875734165F, -2.3625F, -2.977143714937088F, -0.0030571222452943857F, 0.03733434218299329F));
        g.addOrReplaceChild("carga_21", CubeListBuilder.create().texOffs(54, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -17.78695813903115F, -2.3625F, -2.989152779830681F, -0.009144642548817519F, 0.11987201038370261F));
        g.addOrReplaceChild("carga_22", CubeListBuilder.create().texOffs(72, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.0F, -17.421158219597842F, -2.3625F, -3.0170218872840673F, -0.015029988930452324F, 0.23737084868274308F));
        g.addOrReplaceChild("carga_23", CubeListBuilder.create().texOffs(676, 0).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -16.38861665008227F, -2.3625F, -3.0977938592701464F, -0.017238744545181532F, 0.6670057487604275F));
        g.addOrReplaceChild("carga_24", CubeListBuilder.create().texOffs(696, 0).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.0F, -16.446216962915102F, -0.7875000000000001F, -3.128359456221122F, 0.0055981027191624325F, -0.7022196274653288F));
        g.addOrReplaceChild("carga_25", CubeListBuilder.create().texOffs(90, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -17.554175044890563F, -0.7875000000000001F, -3.1028817043921357F, 0.005060826076847208F, -0.25580223151505843F));
        g.addOrReplaceChild("carga_26", CubeListBuilder.create().texOffs(108, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, -17.946692875734165F, -0.7875000000000001F, -3.0939585371547143F, 0.003109951935220501F, -0.1298904798519232F));
        g.addOrReplaceChild("carga_27", CubeListBuilder.create().texOffs(126, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.11809458751741F, -0.7875000000000001F, -3.0900934174220116F, 0.0010442275391640546F, -0.04054884856184047F));
        g.addOrReplaceChild("carga_28", CubeListBuilder.create().texOffs(144, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -18.11809458751741F, -0.7875000000000001F, -3.0900934174220116F, -0.0010442275391640546F, 0.04054884856184047F));
        g.addOrReplaceChild("carga_29", CubeListBuilder.create().texOffs(162, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -17.946692875734165F, -0.7875000000000001F, -3.0939585371547143F, -0.003109951935220501F, 0.1298904798519232F));
        g.addOrReplaceChild("carga_30", CubeListBuilder.create().texOffs(180, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.0F, -17.554175044890563F, -0.7875000000000001F, -3.1028817043921357F, -0.005060826076847208F, 0.25580223151505843F));
        g.addOrReplaceChild("carga_31", CubeListBuilder.create().texOffs(716, 0).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -16.446216962915106F, -0.7875000000000001F, -3.128359456221122F, -0.0055981027191624325F, 0.7022196274653288F));
        g.addOrReplaceChild("carga_32", CubeListBuilder.create().texOffs(736, 0).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.0F, -16.446216962915102F, 0.7875000000000001F, 3.128359456221122F, -0.0055981027191624325F, -0.7022196274653288F));
        g.addOrReplaceChild("carga_33", CubeListBuilder.create().texOffs(198, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -17.554175044890563F, 0.7875000000000001F, 3.1028817043921357F, -0.005060826076847208F, -0.25580223151505843F));
        g.addOrReplaceChild("carga_34", CubeListBuilder.create().texOffs(216, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, -17.946692875734165F, 0.7875000000000001F, 3.0939585371547143F, -0.003109951935220501F, -0.1298904798519232F));
        g.addOrReplaceChild("carga_35", CubeListBuilder.create().texOffs(234, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.11809458751741F, 0.7875000000000001F, 3.0900934174220116F, -0.0010442275391640546F, -0.04054884856184047F));
        g.addOrReplaceChild("carga_36", CubeListBuilder.create().texOffs(252, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -18.11809458751741F, 0.7875000000000001F, 3.0900934174220116F, 0.0010442275391640546F, 0.04054884856184047F));
        g.addOrReplaceChild("carga_37", CubeListBuilder.create().texOffs(270, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -17.946692875734165F, 0.7875000000000001F, 3.0939585371547143F, 0.003109951935220501F, 0.1298904798519232F));
        g.addOrReplaceChild("carga_38", CubeListBuilder.create().texOffs(288, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.0F, -17.554175044890563F, 0.7875000000000001F, 3.1028817043921357F, 0.005060826076847208F, 0.25580223151505843F));
        g.addOrReplaceChild("carga_39", CubeListBuilder.create().texOffs(756, 0).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -16.446216962915106F, 0.7875000000000001F, 3.128359456221122F, 0.0055981027191624325F, 0.7022196274653288F));
        g.addOrReplaceChild("carga_40", CubeListBuilder.create().texOffs(776, 0).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.0F, -16.38861665008227F, 2.3625F, 3.0977938592701464F, -0.017238744545181532F, -0.6670057487604275F));
        g.addOrReplaceChild("carga_41", CubeListBuilder.create().texOffs(306, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -17.421158219597846F, 2.3625F, 3.0170218872840673F, -0.015029988930452324F, -0.23737084868274308F));
        g.addOrReplaceChild("carga_42", CubeListBuilder.create().texOffs(324, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, -17.78695813903115F, 2.3625F, 2.989152779830681F, -0.009144642548817519F, -0.11987201038370264F));
        g.addOrReplaceChild("carga_43", CubeListBuilder.create().texOffs(342, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -17.946692875734165F, 2.3625F, 2.977143714937088F, -0.0030571222452944642F, -0.03733434218299329F));
        g.addOrReplaceChild("carga_44", CubeListBuilder.create().texOffs(360, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -17.946692875734165F, 2.3625F, 2.977143714937088F, 0.0030571222452944642F, 0.03733434218299329F));
        g.addOrReplaceChild("carga_45", CubeListBuilder.create().texOffs(378, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -17.78695813903115F, 2.3625F, 2.989152779830681F, 0.009144642548817519F, 0.11987201038370264F));
        g.addOrReplaceChild("carga_46", CubeListBuilder.create().texOffs(396, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.0F, -17.421158219597842F, 2.3625F, 3.0170218872840673F, 0.015029988930452324F, 0.23737084868274308F));
        g.addOrReplaceChild("carga_47", CubeListBuilder.create().texOffs(796, 0).addBox(-3.0F, -1.0F, -2.0F, 6.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -16.38861665008227F, 2.3625F, 3.0977938592701464F, 0.017238744545181532F, 0.6670057487604275F));
        g.addOrReplaceChild("carga_48", CubeListBuilder.create().texOffs(414, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.0F, -16.25670927521516F, 3.9375F, 3.048457354577388F, -0.03035327627504174F, -0.5782425874825006F));
        g.addOrReplaceChild("carga_49", CubeListBuilder.create().texOffs(432, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -17.116543550430322F, 3.9375F, 2.893930909592F, -0.02411053684644055F, -0.19430280578133385F));
        g.addOrReplaceChild("carga_50", CubeListBuilder.create().texOffs(450, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-3.0F, -17.421158219597842F, 3.9375F, 2.842632446344867F, -0.014277151602585228F, -0.09674335181447513F));
        g.addOrReplaceChild("carga_51", CubeListBuilder.create().texOffs(468, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -17.554175044890563F, 3.9375F, 2.8208545935145173F, -0.004716091416807445F, -0.02994999715862135F));
        g.addOrReplaceChild("carga_52", CubeListBuilder.create().texOffs(486, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.0F, -17.554175044890563F, 3.9375F, 2.8208545935145173F, 0.004716091416807445F, 0.02994999715862135F));
        g.addOrReplaceChild("carga_53", CubeListBuilder.create().texOffs(504, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -17.421158219597846F, 3.9375F, 2.842632446344867F, 0.014277151602585228F, 0.09674335181447513F));
        g.addOrReplaceChild("carga_54", CubeListBuilder.create().texOffs(522, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.0F, -17.116543550430322F, 3.9375F, 2.893930909592F, 0.02411053684644055F, 0.19430280578133385F));
        g.addOrReplaceChild("carga_55", CubeListBuilder.create().texOffs(540, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -16.25670927521516F, 3.9375F, 3.048457354577388F, 0.03035327627504174F, 0.5782425874825006F));
        g.addOrReplaceChild("carga_56", CubeListBuilder.create().texOffs(558, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.0F, -15.884375F, 5.5125F, 2.80695424789802F, -0.04394153768575067F, -0.26178795331901156F));
        g.addOrReplaceChild("carga_57", CubeListBuilder.create().texOffs(452, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-5.0F, -16.25670927521516F, 5.5125F, 2.4482113286612273F, -0.021593049837610862F, -0.06979218427049326F));
        g.addOrReplaceChild("carga_58", CubeListBuilder.create().texOffs(472, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-3.0F, -16.38861665008227F, 5.5125F, 2.355908053159416F, -0.01098326640740799F, -0.03293094114465508F));
        g.addOrReplaceChild("carga_59", CubeListBuilder.create().texOffs(492, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.0F, -16.446216962915106F, 5.5125F, 2.3203094798556707F, -0.0034041489905166857F, -0.009993717153748723F));
        g.addOrReplaceChild("carga_60", CubeListBuilder.create().texOffs(512, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(1.0F, -16.446216962915106F, 5.5125F, 2.3203094798556707F, 0.0034041489905166857F, 0.009993717153748723F));
        g.addOrReplaceChild("carga_61", CubeListBuilder.create().texOffs(532, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(3.0F, -16.38861665008227F, 5.5125F, 2.355908053159416F, 0.01098326640740799F, 0.03293094114465508F));
        g.addOrReplaceChild("carga_62", CubeListBuilder.create().texOffs(552, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(5.0F, -16.25670927521516F, 5.5125F, 2.4482113286612273F, 0.021593049837610862F, 0.06979218427049326F));
        g.addOrReplaceChild("carga_63", CubeListBuilder.create().texOffs(576, 48).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -15.884375F, 5.5125F, 2.80695424789802F, 0.04394153768575067F, 0.26178795331901156F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "cuba_0", 1.0029411764705882F, 1.0F, 0.8189499366462674F);
        escalar(g0, "cuba_1", 1.0029411764705882F, 1.0F, 0.9214829481348921F);
        escalar(g0, "cuba_2", 1.0029411764705882F, 1.0F, 0.8768991933709294F);
        escalar(g0, "cuba_3", 1.0029411764705882F, 1.0F, 0.8277016707064292F);
        escalar(g0, "cuba_4", 1.0029411764705882F, 1.0F, 0.8277016707064292F);
        escalar(g0, "cuba_5", 1.0029411764705882F, 1.0F, 0.8768991933709294F);
        escalar(g0, "cuba_6", 1.0029411764705882F, 1.0F, 0.9214829481348921F);
        escalar(g0, "cuba_7", 1.0029411764705882F, 1.0F, 0.8189499366462674F);
        escalar(g0, "cuba_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cuba_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "carga_0", 0.44008490280763757F, 1.0F, 0.4522269112159714F);
        escalar(g0, "carga_1", 0.413071153676292F, 1.0F, 0.4210475318422307F);
        escalar(g0, "carga_2", 0.41077108774443294F, 1.0F, 0.45596637917804533F);
        escalar(g0, "carga_3", 0.41007453927963394F, 1.0F, 0.4723982536574217F);
        escalar(g0, "carga_4", 0.41007453927963394F, 1.0F, 0.4723982536574217F);
        escalar(g0, "carga_5", 0.41077108774443294F, 1.0F, 0.45596637917804533F);
        escalar(g0, "carga_6", 0.413071153676292F, 1.0F, 0.4210475318422307F);
        escalar(g0, "carga_7", 0.44008490280763757F, 1.0F, 0.4522269112159714F);
        escalar(g0, "carga_8", 0.48944658791583534F, 1.0F, 0.4111024749484911F);
        escalar(g0, "carga_9", 0.4183078537726314F, 1.0F, 0.41935073463959555F);
        escalar(g0, "carga_10", 0.4120911442603461F, 1.0F, 0.42475726987926815F);
        escalar(g0, "carga_11", 0.4102023039042407F, 1.0F, 0.427433946858203F);
        escalar(g0, "carga_12", 0.4102023039042407F, 1.0F, 0.427433946858203F);
        escalar(g0, "carga_13", 0.4120911442603461F, 1.0F, 0.42475726987926815F);
        escalar(g0, "carga_14", 0.4183078537726314F, 1.0F, 0.41935073463959555F);
        escalar(g0, "carga_15", 0.48944658791583534F, 1.0F, 0.4111024749484911F);
        escalar(g0, "carga_16", 0.43300413393147547F, 1.0F, 0.40747251258093664F);
        escalar(g0, "carga_17", 0.42176182891373876F, 1.0F, 0.4095636496007293F);
        escalar(g0, "carga_18", 0.412968776929565F, 1.0F, 0.41095163322057815F);
        escalar(g0, "carga_19", 0.41028745766257196F, 1.0F, 0.41164381191149796F);
        escalar(g0, "carga_20", 0.41028745766257196F, 1.0F, 0.41164381191149796F);
        escalar(g0, "carga_21", 0.412968776929565F, 1.0F, 0.41095163322057815F);
        escalar(g0, "carga_22", 0.42176182891373876F, 1.0F, 0.4095636496007293F);
        escalar(g0, "carga_23", 0.43300413393147547F, 1.0F, 0.40747251258093664F);
        escalar(g0, "carga_24", 0.4450116744931436F, 1.0F, 0.40636830282063935F);
        escalar(g0, "carga_25", 0.42347795135250355F, 1.0F, 0.4065710641772054F);
        escalar(g0, "carga_26", 0.4134068764836373F, 1.0F, 0.4067061804655177F);
        escalar(g0, "carga_27", 0.4103300277486543F, 1.0F, 0.4067737212427352F);
        escalar(g0, "carga_28", 0.4103300277486543F, 1.0F, 0.4067737212427352F);
        escalar(g0, "carga_29", 0.4134068764836373F, 1.0F, 0.4067061804655177F);
        escalar(g0, "carga_30", 0.42347795135250355F, 1.0F, 0.4065710641772054F);
        escalar(g0, "carga_31", 0.4450116744931436F, 1.0F, 0.40636830282063935F);
        escalar(g0, "carga_32", 0.4450116744931436F, 1.0F, 0.40636830282063935F);
        escalar(g0, "carga_33", 0.42347795135250355F, 1.0F, 0.4065710641772054F);
        escalar(g0, "carga_34", 0.4134068764836373F, 1.0F, 0.4067061804655177F);
        escalar(g0, "carga_35", 0.4103300277486543F, 1.0F, 0.4067737212427352F);
        escalar(g0, "carga_36", 0.4103300277486543F, 1.0F, 0.4067737212427352F);
        escalar(g0, "carga_37", 0.4134068764836373F, 1.0F, 0.4067061804655177F);
        escalar(g0, "carga_38", 0.42347795135250355F, 1.0F, 0.4065710641772054F);
        escalar(g0, "carga_39", 0.4450116744931436F, 1.0F, 0.40636830282063935F);
        escalar(g0, "carga_40", 0.43300413393147547F, 1.0F, 0.4074725125809366F);
        escalar(g0, "carga_41", 0.42176182891373876F, 1.0F, 0.4095636496007292F);
        escalar(g0, "carga_42", 0.412968776929565F, 1.0F, 0.41095163322057804F);
        escalar(g0, "carga_43", 0.41028745766257196F, 1.0F, 0.41164381191149785F);
        escalar(g0, "carga_44", 0.41028745766257196F, 1.0F, 0.41164381191149785F);
        escalar(g0, "carga_45", 0.412968776929565F, 1.0F, 0.41095163322057804F);
        escalar(g0, "carga_46", 0.42176182891373876F, 1.0F, 0.4095636496007292F);
        escalar(g0, "carga_47", 0.43300413393147547F, 1.0F, 0.4074725125809366F);
        escalar(g0, "carga_48", 0.48944658791583534F, 1.0F, 0.41110247494849145F);
        escalar(g0, "carga_49", 0.4183078537726314F, 1.0F, 0.41935073463959593F);
        escalar(g0, "carga_50", 0.4120911442603461F, 1.0F, 0.4247572698792685F);
        escalar(g0, "carga_51", 0.4102023039042407F, 1.0F, 0.42743394685820335F);
        escalar(g0, "carga_52", 0.4102023039042407F, 1.0F, 0.42743394685820335F);
        escalar(g0, "carga_53", 0.4120911442603461F, 1.0F, 0.4247572698792685F);
        escalar(g0, "carga_54", 0.4183078537726314F, 1.0F, 0.41935073463959593F);
        escalar(g0, "carga_55", 0.48944658791583534F, 1.0F, 0.41110247494849145F);
        escalar(g0, "carga_56", 0.44008490280763757F, 1.0F, 0.4522269112159712F);
        escalar(g0, "carga_57", 0.413071153676292F, 1.0F, 0.42104753184223054F);
        escalar(g0, "carga_58", 0.41077108774443294F, 1.0F, 0.45596637917804517F);
        escalar(g0, "carga_59", 0.41007453927963394F, 1.0F, 0.47239825365742166F);
        escalar(g0, "carga_60", 0.41007453927963394F, 1.0F, 0.47239825365742166F);
        escalar(g0, "carga_61", 0.41077108774443294F, 1.0F, 0.45596637917804517F);
        escalar(g0, "carga_62", 0.413071153676292F, 1.0F, 0.42104753184223054F);
        escalar(g0, "carga_63", 0.44008490280763757F, 1.0F, 0.4522269112159712F);
    }
}
