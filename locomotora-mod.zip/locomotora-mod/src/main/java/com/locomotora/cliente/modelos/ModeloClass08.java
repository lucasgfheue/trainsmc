package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "BR Class 08" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloClass08 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("class08"), "main"),
            LocomotoraMod.id("textures/entity/class08.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, -16.0F, -6.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, -16.0F, -6.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, -16.0F, -6.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F, -6.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F, -6.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F, -6.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 16.0F, -6.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 16.0F, -6.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 16.0F, -6.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 6.0F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -6.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 6.0F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -6.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 6.0F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -6.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 6.0F, 0.0F, 1.5707963267948966F, 0.0F, 0.0F, -6.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 6.0F, 0.0F, 1.5707963267948966F, 0.0F, 0.0F, -6.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 6.0F, 0.0F, 1.5707963267948966F, 0.0F, 0.0F, -6.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 6.0F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -6.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 6.0F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -6.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 6.0F, 0.0F, 1.5707963267948966F, 0.0F, 16.0F, -6.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 6.0F, 2.2F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 6.0F, 2.2F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "cuerpo")),
            ModeloClass08::crearCapa,
            16.0F,
            ModeloClass08::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -16.0F, 16.0F)));

    private ModeloClass08() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(316, 119).addBox(-6.0F, -6.0F, -6.0F, 12.0F, 12.0F, 2.0F).texOffs(260, 157).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(344, 119).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(376, 157).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(942, 167).addBox(-1.0F, -3.2F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-16.0F, -6.0F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(288, 157).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(354, 119).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(316, 157).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(364, 119).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(316, 119).addBox(-6.0F, -6.0F, -6.0F, 12.0F, 12.0F, 2.0F).texOffs(260, 157).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(344, 119).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(386, 157).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(948, 167).addBox(-1.0F, -3.2F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(0.0F, -6.0F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(288, 157).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(354, 119).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(316, 157).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(364, 119).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(316, 119).addBox(-6.0F, -6.0F, -6.0F, 12.0F, 12.0F, 2.0F).texOffs(260, 157).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(344, 119).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 157).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(954, 167).addBox(-1.0F, -3.2F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(16.0F, -6.0F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(288, 157).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(354, 119).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(316, 157).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(364, 119).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(316, 119).addBox(-6.0F, -6.0F, 4.0F, 12.0F, 12.0F, 2.0F).texOffs(260, 157).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(344, 119).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(406, 157).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(960, 167).addBox(-1.0F, -3.2F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-16.0F, -6.0F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(288, 157).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(354, 119).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(316, 157).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(364, 119).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(316, 119).addBox(-6.0F, -6.0F, 4.0F, 12.0F, 12.0F, 2.0F).texOffs(260, 157).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(344, 119).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(416, 157).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(966, 167).addBox(-1.0F, -3.2F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(0.0F, -6.0F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(288, 157).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(354, 119).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(316, 157).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(364, 119).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(316, 119).addBox(-6.0F, -6.0F, 4.0F, 12.0F, 12.0F, 2.0F).texOffs(260, 157).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(344, 119).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(426, 157).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(972, 167).addBox(-1.0F, -3.2F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(16.0F, -6.0F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(288, 157).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(354, 119).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(316, 157).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(364, 119).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(82, 174).addBox(-16.0F, -8.7F, -7.5F, 32.0F, 1.0F, 1.0F).texOffs(270, 167).addBox(-17.5F, -9.7F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(278, 167).addBox(-1.5F, -9.7F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(286, 167).addBox(14.5F, -9.7F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(148, 174).addBox(-16.0F, -8.7F, 6.5F, 32.0F, 1.0F, 1.0F).texOffs(294, 167).addBox(-17.5F, -9.7F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(302, 167).addBox(-1.5F, -9.7F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(310, 167).addBox(14.5F, -9.7F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(708, 145).addBox(-36.0F, -10.0F, 2.0F, 72.0F, 7.0F, 1.0F).texOffs(854, 145).addBox(-36.0F, -10.0F, -3.0F, 72.0F, 7.0F, 1.0F).texOffs(0, 119).addBox(-36.0F, -13.0F, -11.5F, 72.0F, 3.0F, 23.0F).texOffs(366, 167).addBox(-40.0F, -11.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(372, 167).addBox(38.0F, -11.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(1000, 145).addBox(13.0F, -10.0F, 10.5F, 1.0F, 7.0F, 1.0F).texOffs(1004, 145).addBox(13.0F, -10.0F, -11.5F, 1.0F, 7.0F, 1.0F).texOffs(1008, 145).addBox(20.0F, -10.0F, 10.5F, 1.0F, 7.0F, 1.0F).texOffs(1012, 145).addBox(20.0F, -10.0F, -11.5F, 1.0F, 7.0F, 1.0F).texOffs(214, 174).addBox(13.0F, -4.0F, 10.5F, 8.0F, 1.0F, 1.0F).texOffs(232, 174).addBox(13.0F, -4.0F, -11.5F, 8.0F, 1.0F, 1.0F).texOffs(250, 174).addBox(13.0F, -7.5F, 10.5F, 8.0F, 1.0F, 1.0F).texOffs(268, 174).addBox(13.0F, -7.5F, -11.5F, 8.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("viga_rayasf", CubeListBuilder.create().texOffs(196, 0).addBox(0.0F, -14.0F, 0.0F, 4.0F, 14.0F, 44.0F), PartPose.offset(-38.0F, -6.0F, -11.0F));
        g.addOrReplaceChild("tope_fi_0", CubeListBuilder.create().texOffs(464, 86).addBox(-41.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(756, 0).addBox(-41.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -9.5F, -8.0F));
        g.addOrReplaceChild("tope_fi_1", CubeListBuilder.create().texOffs(484, 86).addBox(-41.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(814, 0).addBox(-41.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_fi_2", CubeListBuilder.create().texOffs(504, 86).addBox(-41.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(872, 0).addBox(-41.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_fic_0", CubeListBuilder.create().texOffs(286, 145).addBox(-42.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(938, 119).addBox(-42.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, -8.0F));
        g.addOrReplaceChild("tope_fic_1", CubeListBuilder.create().texOffs(292, 145).addBox(-42.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(960, 119).addBox(-42.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_fic_2", CubeListBuilder.create().texOffs(298, 145).addBox(-42.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(982, 119).addBox(-42.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_fic_3", CubeListBuilder.create().texOffs(304, 145).addBox(-42.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(0, 145).addBox(-42.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_fd_0", CubeListBuilder.create().texOffs(524, 86).addBox(-41.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(930, 0).addBox(-41.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -9.5F, 8.0F));
        g.addOrReplaceChild("tope_fd_1", CubeListBuilder.create().texOffs(544, 86).addBox(-41.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(0, 86).addBox(-41.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_fd_2", CubeListBuilder.create().texOffs(564, 86).addBox(-41.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(58, 86).addBox(-41.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_fdc_0", CubeListBuilder.create().texOffs(310, 145).addBox(-42.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(22, 145).addBox(-42.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, 8.0F));
        g.addOrReplaceChild("tope_fdc_1", CubeListBuilder.create().texOffs(316, 145).addBox(-42.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(44, 145).addBox(-42.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_fdc_2", CubeListBuilder.create().texOffs(322, 145).addBox(-42.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(66, 145).addBox(-42.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_fdc_3", CubeListBuilder.create().texOffs(328, 145).addBox(-42.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(88, 145).addBox(-42.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("viga_rayast", CubeListBuilder.create().texOffs(292, 0).addBox(0.0F, -14.0F, 0.0F, 4.0F, 14.0F, 44.0F), PartPose.offset(36.0F, -6.0F, -11.0F));
        g.addOrReplaceChild("tope_ti_0", CubeListBuilder.create().texOffs(584, 86).addBox(38.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(116, 86).addBox(38.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -9.5F, -8.0F));
        g.addOrReplaceChild("tope_ti_1", CubeListBuilder.create().texOffs(604, 86).addBox(38.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(174, 86).addBox(38.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ti_2", CubeListBuilder.create().texOffs(624, 86).addBox(38.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(232, 86).addBox(38.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_0", CubeListBuilder.create().texOffs(334, 145).addBox(41.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(110, 145).addBox(41.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, -8.0F));
        g.addOrReplaceChild("tope_tic_1", CubeListBuilder.create().texOffs(340, 145).addBox(41.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(132, 145).addBox(41.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_2", CubeListBuilder.create().texOffs(346, 145).addBox(41.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(154, 145).addBox(41.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_3", CubeListBuilder.create().texOffs(352, 145).addBox(41.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(176, 145).addBox(41.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, -8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_0", CubeListBuilder.create().texOffs(644, 86).addBox(38.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(290, 86).addBox(38.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -9.5F, 8.0F));
        g.addOrReplaceChild("tope_td_1", CubeListBuilder.create().texOffs(664, 86).addBox(38.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(348, 86).addBox(38.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_2", CubeListBuilder.create().texOffs(684, 86).addBox(38.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(406, 86).addBox(38.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_0", CubeListBuilder.create().texOffs(358, 145).addBox(41.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(198, 145).addBox(41.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -9.5F, 8.0F));
        g.addOrReplaceChild("tope_tdc_1", CubeListBuilder.create().texOffs(364, 145).addBox(41.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(220, 145).addBox(41.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_2", CubeListBuilder.create().texOffs(370, 145).addBox(41.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(242, 145).addBox(41.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_3", CubeListBuilder.create().texOffs(376, 145).addBox(41.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(264, 145).addBox(41.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -9.5F, 8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo", CubeListBuilder.create().texOffs(902, 86).addBox(-33.0F, -25.0F, -8.0F, 43.0F, 12.0F, 16.0F).texOffs(206, 119).addBox(-33.0F, -27.0F, -6.0F, 43.0F, 2.0F, 12.0F).texOffs(910, 171).addBox(-32.0F, -24.5F, 8.4F, 40.0F, 1.0F, 1.0F).texOffs(0, 174).addBox(-32.0F, -24.5F, -9.4F, 40.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_cantoi_0", CubeListBuilder.create().texOffs(30, 171).addBox(-21.5F, -1.0F, -0.5F, 43.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-11.5F, -25.309016994374943F, -7.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_1", CubeListBuilder.create().texOffs(118, 171).addBox(-21.5F, -1.0F, -0.5F, 43.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-11.5F, -25.89680224666742F, -7.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_2", CubeListBuilder.create().texOffs(206, 171).addBox(-21.5F, -1.0F, -0.5F, 43.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-11.5F, -26.39680224666742F, -7.39680224666742F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_3", CubeListBuilder.create().texOffs(294, 171).addBox(-21.5F, -1.0F, -0.5F, 43.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-11.5F, -26.7600735106701F, -6.89680224666742F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_4", CubeListBuilder.create().texOffs(382, 171).addBox(-21.5F, -1.0F, -0.5F, 43.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-11.5F, -26.951056516295154F, -6.3090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_0", CubeListBuilder.create().texOffs(470, 171).addBox(-21.5F, -1.0F, -0.5F, 43.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-11.5F, -25.309016994374943F, 7.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_1", CubeListBuilder.create().texOffs(558, 171).addBox(-21.5F, -1.0F, -0.5F, 43.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-11.5F, -25.89680224666742F, 7.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_2", CubeListBuilder.create().texOffs(646, 171).addBox(-21.5F, -1.0F, -0.5F, 43.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-11.5F, -26.39680224666742F, 7.39680224666742F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_3", CubeListBuilder.create().texOffs(734, 171).addBox(-21.5F, -1.0F, -0.5F, 43.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-11.5F, -26.7600735106701F, 6.89680224666742F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_4", CubeListBuilder.create().texOffs(822, 171).addBox(-21.5F, -1.0F, -0.5F, 43.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-11.5F, -26.951056516295154F, 6.3090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_frente_0", CubeListBuilder.create().texOffs(570, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.70527366969348F, -14.437499626791322F, -7.9988062836025495F, -1.5724895200131381F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_1", CubeListBuilder.create().texOffs(588, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.70527366969348F, -17.31249967135846F, -7.9988062836025495F, -1.5724895200131381F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_2", CubeListBuilder.create().texOffs(606, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.70527366969348F, -20.187499715925597F, -7.9988062836025495F, -1.5724895200131381F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_3", CubeListBuilder.create().texOffs(624, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.70527366969328F, -23.062499689147934F, -7.998806283602552F, -1.5724895200131346F, 0.0F, -1.5707963267947533F));
        g.addOrReplaceChild("capo_frente_4", CubeListBuilder.create().texOffs(318, 167).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.616315753905496F, -24.650085957812152F, -7.9993457482427655F, -1.5718581923163426F, 0.001465869556479385F, -1.555767055889732F));
        g.addOrReplaceChild("capo_frente_5", CubeListBuilder.create().texOffs(978, 167).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-33.456130012075775F, -24.835861919556343F, -7.999557031475202F, -1.5717670705424978F, -0.0006722040147826342F, -1.5298437047516065F));
        g.addOrReplaceChild("capo_frente_6", CubeListBuilder.create().texOffs(984, 167).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-33.17471568127527F, -25.07473005237761F, -7.988276888388134F, -1.6362698288332467F, -0.0611116979861682F, -0.8205827751138147F));
        g.addOrReplaceChild("capo_frente_7", CubeListBuilder.create().texOffs(378, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-34.730988448131825F, -14.437499626791322F, -7.974362021625746F, -1.6431676068275858F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_8", CubeListBuilder.create().texOffs(394, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-34.730988448131825F, -17.31249967135846F, -7.974362021625746F, -1.6431676068275858F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_9", CubeListBuilder.create().texOffs(410, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-34.730988448131825F, -20.187499715925597F, -7.974362021625746F, -1.6431676068275858F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_10", CubeListBuilder.create().texOffs(426, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-34.73098844813163F, -23.062499696270642F, -7.974362021625748F, -1.6431676068275531F, 0.0F, -1.570796326794762F));
        g.addOrReplaceChild("capo_frente_11", CubeListBuilder.create().texOffs(990, 167).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-34.536841439007716F, -24.696120648243593F, -7.982791469421615F, -1.6223588766682921F, 0.010841973962772044F, -1.0594346888362502F));
        g.addOrReplaceChild("capo_frente_12", CubeListBuilder.create().texOffs(858, 174).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-34.118916009209016F, -24.914455778086644F, -7.990783396048497F, -1.6207648072618377F, -0.014005322287305565F, -0.8313487595250781F));
        g.addOrReplaceChild("capo_frente_13", CubeListBuilder.create().texOffs(794, 174).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.41821741365317F, -25.32710393960607F, -7.940213360636905F, -1.7943809391377064F, -0.10330180208767632F, -0.624333310918868F));
        g.addOrReplaceChild("capo_frente_14", CubeListBuilder.create().texOffs(286, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.182050046023775F, -14.437499626791322F, -7.9095651408788665F, -1.8793346344193314F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_15", CubeListBuilder.create().texOffs(300, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.182050046023775F, -17.31249967135846F, -7.9095651408788665F, -1.8793346344193314F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_16", CubeListBuilder.create().texOffs(314, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.182050046023775F, -20.187499715925597F, -7.9095651408788665F, -1.8793346344193314F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_17", CubeListBuilder.create().texOffs(328, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.182050046023804F, -23.0624997062667F, -7.909565140878854F, -1.8793346344193689F, 0.0F, -1.5707963267949177F));
        g.addOrReplaceChild("capo_frente_18", CubeListBuilder.create().texOffs(918, 174).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-34.989341757218575F, -24.77528436722414F, -7.9283308210086805F, -1.8269032145868755F, -0.007265333864741584F, -1.0215569264854705F));
        g.addOrReplaceChild("capo_frente_19", CubeListBuilder.create().texOffs(864, 174).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-34.46244116334165F, -25.06914089959557F, -7.950740303439033F, -1.7810366336941796F, 0.02475664162148197F, -0.36967330815317356F));
        g.addOrReplaceChild("capo_frente_20", CubeListBuilder.create().texOffs(802, 174).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.54491195326878F, -25.613238679394282F, -7.835998614320338F, -1.9294741922161605F, -0.18238027739538612F, -0.6328815259400016F));
        g.addOrReplaceChild("capo_frente_21", CubeListBuilder.create().texOffs(342, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.3981472040777F, -14.437499626791322F, -7.81116264331272F, -2.1563305784914517F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_22", CubeListBuilder.create().texOffs(356, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.3981472040777F, -17.31249967135846F, -7.81116264331272F, -2.1563305784914517F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_23", CubeListBuilder.create().texOffs(370, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.3981472040777F, -20.187499715925597F, -7.81116264331272F, -2.1563305784914517F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_24", CubeListBuilder.create().texOffs(384, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.39814720407777F, -23.0624997147088F, -7.811162643312663F, -2.15633057849158F, 0.0F, -1.5707963267949447F));
        g.addOrReplaceChild("capo_frente_25", CubeListBuilder.create().texOffs(922, 174).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.23463211173455F, -24.859834803437806F, -7.828561560383108F, -2.096818528474545F, 0.0012231120655283863F, -1.0557780568263646F));
        g.addOrReplaceChild("capo_frente_26", CubeListBuilder.create().texOffs(870, 174).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-34.6993479167685F, -25.28558142546767F, -7.845332781457886F, -2.0125275229646418F, 0.011323822834983586F, -0.5116429693593894F));
        g.addOrReplaceChild("capo_frente_27", CubeListBuilder.create().texOffs(734, 174).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.650341469571174F, -25.930584876336276F, -7.654579366187051F, -2.107835442923829F, -0.24768836872798428F, -0.5746698011436921F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("capo_frente_28", CubeListBuilder.create().texOffs(398, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.55630956779289F, -14.437499626791322F, -7.669252555237458F, -2.4362495477334636F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_29", CubeListBuilder.create().texOffs(412, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.55630956779289F, -17.31249967135846F, -7.669252555237458F, -2.4362495477334636F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_30", CubeListBuilder.create().texOffs(426, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.55630956779289F, -20.187499715925597F, -7.669252555237458F, -2.4362495477334636F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_31", CubeListBuilder.create().texOffs(440, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.55630956779302F, -23.062499722913813F, -7.669252555237279F, -2.4362495477337207F, 0.0F, -1.5707963267949918F));
        g.addOrReplaceChild("capo_frente_32", CubeListBuilder.create().texOffs(876, 174).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.4110223702013F, -24.94717515561989F, -7.669091889261562F, -2.394717766691333F, -0.010730510522158346F, -1.1230582493164136F));
        g.addOrReplaceChild("capo_frente_33", CubeListBuilder.create().texOffs(810, 174).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-34.87450981630213F, -25.53499429873846F, -7.6381904925261015F, -2.304485412187027F, -0.05264129103984518F, -0.6743042314302874F));
        g.addOrReplaceChild("capo_frente_34", CubeListBuilder.create().texOffs(744, 174).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.73096568510887F, -26.247106013097273F, -7.375208002342765F, -2.351844197956565F, -0.2776951743772187F, -0.48193080149068934F));
        g.addOrReplaceChild("capo_frente_35", CubeListBuilder.create().texOffs(454, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.69857093884184F, -14.437499626791322F, -7.435840647592164F, -2.7016091721540123F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_36", CubeListBuilder.create().texOffs(468, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.69857093884184F, -17.31249967135846F, -7.435840647592164F, -2.7016091721540123F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_37", CubeListBuilder.create().texOffs(482, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.69857093884184F, -20.187499715925597F, -7.435840647592164F, -2.7016091721540123F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_38", CubeListBuilder.create().texOffs(496, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.698570938841975F, -23.062499732152425F, -7.435840647591874F, -2.7016091721542668F, 0.0F, -1.5707963267949918F));
        g.addOrReplaceChild("capo_frente_39", CubeListBuilder.create().texOffs(926, 174).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.68948604333088F, -24.612037550279794F, -7.4340270175187335F, -2.7011780284069253F, 0.0006482423880475556F, -1.4819756305575418F));
        g.addOrReplaceChild("capo_frente_40", CubeListBuilder.create().texOffs(882, 174).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.560764122323526F, -25.041932476857248F, -7.399495913067151F, -2.683543954135357F, -0.006979373109433154F, -1.1667413613714395F));
        g.addOrReplaceChild("capo_frente_41", CubeListBuilder.create().texOffs(818, 174).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.00533521407168F, -25.777937777729594F, -7.293698776028079F, -2.6049401576682043F, -0.12041633798404765F, -0.7647391287456143F));
        g.addOrReplaceChild("capo_frente_42", CubeListBuilder.create().texOffs(754, 174).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.78477166565798F, -26.51482689680989F, -6.995297351917653F, -2.6191412747087903F, -0.2599923917475921F, -0.3858037278998088F));
        g.addOrReplaceChild("capo_frente_43", CubeListBuilder.create().texOffs(442, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.83229015924029F, -14.437499626791322F, -6.9998140694555335F, -2.92308334760323F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_44", CubeListBuilder.create().texOffs(458, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.83229015924029F, -17.31249967135846F, -6.9998140694555335F, -2.92308334760323F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_45", CubeListBuilder.create().texOffs(474, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.83229015924029F, -20.187499715925597F, -6.9998140694555335F, -2.92308334760323F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_46", CubeListBuilder.create().texOffs(490, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.83229015924037F, -23.062499742656204F, -6.9998140694551285F, -2.923083347603355F, 0.0F, -1.5707963267949558F));
        g.addOrReplaceChild("capo_frente_47", CubeListBuilder.create().texOffs(996, 167).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.82344478086475F, -24.631587547497677F, -6.99355476789596F, -2.923801828263123F, 0.01684440854174656F, -1.4894475680720574F));
        g.addOrReplaceChild("capo_frente_48", CubeListBuilder.create().texOffs(894, 167).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.68790297111244F, -25.134820260644286F, -6.930919395421587F, -2.9158810227803413F, -0.038580871549983194F, -1.2181524047430123F));
        g.addOrReplaceChild("capo_frente_49", CubeListBuilder.create().texOffs(834, 167).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.097826650505425F, -25.971588940747882F, -6.7862447806512F, -2.8680949890008844F, -0.13368610297632702F, -0.7872758957142875F));
        g.addOrReplaceChild("capo_frente_50", CubeListBuilder.create().texOffs(762, 167).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-33.81722338063749F, -26.695791948339934F, -6.531530632577154F, -2.879833364017626F, -0.19172981396603034F, -0.3070012867559466F));
        g.addOrReplaceChild("capo_frente_51", CubeListBuilder.create().texOffs(642, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.93498444781447F, -14.437499626791322F, -6.213248159229256F, -3.0639452462379526F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_52", CubeListBuilder.create().texOffs(660, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.93498444781447F, -17.31249967135846F, -6.213248159229256F, -3.0639452462379526F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_53", CubeListBuilder.create().texOffs(678, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.93498444781447F, -20.187499715925597F, -6.213248159229256F, -3.0639452462379526F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_54", CubeListBuilder.create().texOffs(696, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.93498444781451F, -23.06249975026525F, -6.2132481592288F, -3.063945246238003F, 0.0F, -1.5707963267949239F));
        g.addOrReplaceChild("capo_frente_55", CubeListBuilder.create().texOffs(1002, 167).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.925070976818546F, -24.645387611487745F, -6.209542591335369F, -3.0643568187790713F, 0.002102320445714939F, -1.5005845438910153F));
        g.addOrReplaceChild("capo_frente_56", CubeListBuilder.create().texOffs(902, 167).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.776585861481436F, -25.1911283965154F, -6.171610777294612F, -3.0667102919984255F, -0.038629146124019645F, -1.234420174856726F));
        g.addOrReplaceChild("capo_frente_57", CubeListBuilder.create().texOffs(844, 167).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.154748025003066F, -26.06797106643779F, -6.056145075601017F, -3.0792458691426394F, -0.061965772757201505F, -0.7747445979064441F));
        g.addOrReplaceChild("capo_frente_58", CubeListBuilder.create().texOffs(774, 167).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-33.835740916432904F, -26.770702972049847F, -5.821577586992753F, -3.116301572314689F, -0.09197698282503222F, -0.26223512297016077F));
        g.addOrReplaceChild("capo_frente_59", CubeListBuilder.create().texOffs(714, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.98534880728789F, -14.437499626791322F, -5.052918751392011F, -3.124134984076425F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_60", CubeListBuilder.create().texOffs(732, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.98534880728789F, -17.31249967135846F, -5.052918751392011F, -3.124134984076425F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_61", CubeListBuilder.create().texOffs(750, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.98534880728789F, -20.187499715925597F, -5.052918751392011F, -3.124134984076425F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_62", CubeListBuilder.create().texOffs(768, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.98534880728789F, -23.06249975238962F, -5.052918751391532F, -3.1241349840764348F, 0.0F, -1.5707963267949003F));
        g.addOrReplaceChild("capo_frente_63", CubeListBuilder.create().texOffs(326, 167).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.97467383628165F, -24.64910654668894F, -5.052954147474949F, -3.1242342464041304F, -0.0012424172433269031F, -1.4993509650644756F));
        g.addOrReplaceChild("capo_frente_64", CubeListBuilder.create().texOffs(230, 167).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.819611046182075F, -25.204126459383943F, -5.040201166586288F, -3.1262805864942877F, -0.017563616247535753F, -1.2288575025632267F));
        g.addOrReplaceChild("capo_frente_65", CubeListBuilder.create().texOffs(182, 167).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.18277809512947F, -26.085899972708603F, -4.946045725166244F, -3.1336690111915866F, -0.0632316648889222F, -0.7678329011720835F));
        g.addOrReplaceChild("capo_frente_66", CubeListBuilder.create().texOffs(126, 167).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.845166481585096F, -26.78087997898244F, -4.698851679071616F, -3.140610726392593F, -0.09573216436093279F, -0.2535854018387893F));
        g.addOrReplaceChild("capo_frente_67", CubeListBuilder.create().texOffs(786, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.998385117573484F, -14.437499626791322F, -3.6687051497061205F, -3.139533840438004F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_68", CubeListBuilder.create().texOffs(804, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.998385117573484F, -17.31249967135846F, -3.6687051497061205F, -3.139533840438004F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_69", CubeListBuilder.create().texOffs(822, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.998385117573484F, -20.187499715925597F, -3.6687051497061205F, -3.139533840438004F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_70", CubeListBuilder.create().texOffs(840, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.998385117573484F, -23.06249975238962F, -3.668705149705598F, -3.139533840438007F, 0.0F, -1.570796326794895F));
        g.addOrReplaceChild("capo_frente_71", CubeListBuilder.create().texOffs(334, 167).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.98768389591548F, -24.64910654668894F, -3.6677659641934115F, -3.1395499568818352F, -0.00014662831534976707F, -1.499137598796283F));
        g.addOrReplaceChild("capo_frente_72", CubeListBuilder.create().texOffs(240, 167).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.83184656012773F, -25.204126459383943F, -3.6510042705039183F, -3.139818036207148F, -0.018661191327436582F, -1.227375553103932F));
        g.addOrReplaceChild("capo_frente_73", CubeListBuilder.create().texOffs(194, 167).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.191390738119715F, -26.085899972708603F, -3.565832876843541F, -3.1406982445264915F, -0.05077661986780212F, -0.7653188519963298F));
        g.addOrReplaceChild("capo_frente_74", CubeListBuilder.create().texOffs(140, 167).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.84803551512073F, -26.78087997898244F, -3.37122539101714F, -3.1414843978863227F, -0.07123128411827281F, -0.2528473910256289F));
        g.addOrReplaceChild("capo_frente_75", CubeListBuilder.create().texOffs(506, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.99993343310125F, -14.437499626791322F, -2.485573542754441F, -3.1414617937275144F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_76", CubeListBuilder.create().texOffs(522, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.99993343310125F, -17.31249967135846F, -2.485573542754441F, -3.1414617937275144F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_77", CubeListBuilder.create().texOffs(538, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.99993343310125F, -20.187499715925597F, -2.485573542754441F, -3.1414617937275144F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_78", CubeListBuilder.create().texOffs(554, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.99993343310125F, -23.06249975238962F, -2.485573542754093F, -3.141461793727514F, 0.0F, -1.5707963267948941F));
        g.addOrReplaceChild("capo_frente_79", CubeListBuilder.create().texOffs(1008, 167).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.98922387416317F, -24.64910654668894F, -2.485046328170452F, -3.141462816880301F, -9.325575097517493e-06F, -1.4990940478323411F));
        g.addOrReplaceChild("capo_frente_80", CubeListBuilder.create().texOffs(910, 167).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.83325772871284F, -25.204126459383943F, -2.4767373035112197F, -3.1414793074638103F, -0.009044389205366554F, -1.2271434167126014F));
        g.addOrReplaceChild("capo_frente_81", CubeListBuilder.create().texOffs(854, 167).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.19233455120924F, -26.085899972708603F, -2.435735799588677F, -3.1415336922136583F, -0.024185178138472627F, -0.765012467156931F));
        g.addOrReplaceChild("capo_frente_82", CubeListBuilder.create().texOffs(786, 167).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-33.84833398010897F, -26.78087997898244F, -2.3431339002880494F, -3.141584822365528F, -0.06767081495254217F, -0.25276990955106593F));
        g.addOrReplaceChild("capo_frente_83", CubeListBuilder.create().texOffs(0, 157).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.99999683722608F, -14.437499626791322F, -1.0134078869715117F, -3.1415895277494124F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_84", CubeListBuilder.create().texOffs(22, 157).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.99999683722608F, -17.31249967135846F, -1.0134078869715117F, -3.1415895277494124F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_85", CubeListBuilder.create().texOffs(44, 157).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.99999683722608F, -20.187499715925597F, -1.0134078869715117F, -3.1415895277494124F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_86", CubeListBuilder.create().texOffs(66, 157).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.99999683722607F, -23.06249975238962F, -1.012601096993027F, -3.1415895302397505F, -0.0002806224917753273F, -1.5707963259184117F));
        g.addOrReplaceChild("capo_frente_87", CubeListBuilder.create().texOffs(236, 157).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.98928690207886F, -24.64910654668894F, -1.012513036323159F, -3.1415895512682632F, -2.2283187631367345e-07F, -1.499092009296175F));
        g.addOrReplaceChild("capo_frente_88", CubeListBuilder.create().texOffs(208, 157).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.83331538563992F, -25.204126459383943F, -1.0110517117088968F, -3.141589902697879F, -9.844434819678994e-07F, -1.2271335153866507F));
        g.addOrReplaceChild("capo_frente_89", CubeListBuilder.create().texOffs(176, 157).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.19237302696495F, -26.085899972708603F, -1.0038528144589989F, -3.1415911433404307F, -0.0036527761480420525F, -0.7649995872231479F));
        g.addOrReplaceChild("capo_frente_90", CubeListBuilder.create().texOffs(344, 157).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.84834612479085F, -26.78087997898244F, -0.9901066602365538F, -3.141592449964002F, -0.004980504698410265F, -0.2527664421279249F));
        g.addOrReplaceChild("capo_frente_91", CubeListBuilder.create().texOffs(88, 157).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.99999683722608F, -14.437499626791322F, 1.011815556738012F, 3.1415895326609293F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_92", CubeListBuilder.create().texOffs(110, 157).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.99999683722608F, -17.31249967135846F, 1.011815556738012F, 3.1415895326609293F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_93", CubeListBuilder.create().texOffs(132, 157).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.99999683722608F, -20.187499715925597F, 1.011815556738012F, 3.1415895326609293F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_94", CubeListBuilder.create().texOffs(154, 157).addBox(-3.0F, -1.0F, -2.5F, 6.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.99999683722608F, -23.06249975238962F, 1.0126223467164972F, 3.141589530174206F, -0.0002806224917754058F, -1.570796327671395F));
        g.addOrReplaceChild("capo_frente_95", CubeListBuilder.create().texOffs(248, 157).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.98928690207885F, -24.64910654668894F, 1.012534286046629F, 3.141589551203162F, 2.228366567979634e-07F, -1.4990919758097576F));
        g.addOrReplaceChild("capo_frente_96", CubeListBuilder.create().texOffs(222, 157).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.83331538563992F, -25.204126459383943F, 1.0112729550146788F, 3.141589902095904F, 9.84658870888288e-07F, -1.2271335269581256F));
        g.addOrReplaceChild("capo_frente_97", CubeListBuilder.create().texOffs(192, 157).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-35.19237302696495F, -26.085899972708603F, 1.005589639276198F, 3.1415911407262267F, 0.0038696046719396415F, -0.7649995868855493F));
        g.addOrReplaceChild("capo_frente_98", CubeListBuilder.create().texOffs(360, 157).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.84834612479085F, -26.78087997898244F, 0.9901066602365391F, 3.141592449963101F, 0.005801484823790476F, -0.2527664419607201F));
        g.addOrReplaceChild("capo_frente_99", CubeListBuilder.create().texOffs(570, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.99993343310125F, -14.437499626791322F, 2.4855735427537624F, 3.141461793727514F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_100", CubeListBuilder.create().texOffs(586, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.99993343310125F, -17.31249967135846F, 2.4855735427537624F, 3.141461793727514F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_101", CubeListBuilder.create().texOffs(602, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.99993343310125F, -20.187499715925597F, 2.4855735427537624F, 3.141461793727514F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_102", CubeListBuilder.create().texOffs(618, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.99993343310124F, -23.06249975238962F, 2.485573542754114F, 3.141461793727514F, 0.0F, -1.5707963267948941F));
        g.addOrReplaceChild("capo_frente_103", CubeListBuilder.create().texOffs(1014, 167).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.98922387416317F, -24.64910654668894F, 2.4850463281704793F, 3.141462816880301F, 9.325575097518077e-06F, -1.4990940478323405F));
        g.addOrReplaceChild("capo_frente_104", CubeListBuilder.create().texOffs(918, 167).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.83325772871284F, -25.204126459383943F, 2.476737303511862F, 3.1414793074638103F, 0.009044389203850174F, -1.2271434167126016F));
        g.addOrReplaceChild("capo_frente_105", CubeListBuilder.create().texOffs(864, 167).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.19233455120924F, -26.085899972708603F, 2.4357357995898616F, 3.1415336922136583F, 0.024185178139028055F, -0.7650124671569309F));
        g.addOrReplaceChild("capo_frente_106", CubeListBuilder.create().texOffs(798, 167).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-33.84833398010897F, -26.78087997898244F, 2.343133900288038F, 3.141584822365528F, 0.06767081495303219F, -0.25276990955106593F));
        g.addOrReplaceChild("capo_frente_107", CubeListBuilder.create().texOffs(858, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.99838511757349F, -14.437499626791322F, 3.668705149705084F, 3.139533840438009F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_108", CubeListBuilder.create().texOffs(876, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.99838511757349F, -17.31249967135846F, 3.668705149705084F, 3.139533840438009F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_109", CubeListBuilder.create().texOffs(894, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.99838511757349F, -20.187499715925597F, 3.668705149705084F, 3.139533840438009F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_110", CubeListBuilder.create().texOffs(912, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.998385117573484F, -23.06249975238962F, 3.6687051497056196F, 3.139533840438007F, 0.0F, -1.5707963267948932F));
        g.addOrReplaceChild("capo_frente_111", CubeListBuilder.create().texOffs(342, 167).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.98768389591548F, -24.64910654668894F, 3.667765964193332F, 3.1395499568818352F, 0.00014662831534977404F, -1.499137598796291F));
        g.addOrReplaceChild("capo_frente_112", CubeListBuilder.create().texOffs(250, 167).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.83184656012773F, -25.204126459383943F, 3.6510042705047443F, 3.139818036207148F, 0.01866119132504609F, -1.2273755531039285F));
        g.addOrReplaceChild("capo_frente_113", CubeListBuilder.create().texOffs(206, 167).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.191390738119715F, -26.085899972708603F, 3.565832876844797F, 3.140698244526489F, 0.05077661986898097F, -0.7653188519963303F));
        g.addOrReplaceChild("capo_frente_114", CubeListBuilder.create().texOffs(154, 167).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.84803551512073F, -26.78087997898244F, 3.371225391016618F, 3.1414843978863227F, 0.07123128411835317F, -0.2528473910256289F));
        g.addOrReplaceChild("capo_frente_115", CubeListBuilder.create().texOffs(930, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.985348807287906F, -14.437499626791322F, 5.052918751391216F, 3.124134984076443F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_116", CubeListBuilder.create().texOffs(948, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.985348807287906F, -17.31249967135846F, 5.052918751391216F, 3.124134984076443F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_117", CubeListBuilder.create().texOffs(966, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.985348807287906F, -20.187499715925597F, 5.052918751391216F, 3.124134984076443F, 0.0F, -1.5707963267948966F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("capo_frente_118", CubeListBuilder.create().texOffs(984, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.9853488072879F, -23.06249975238962F, 5.052918751391539F, 3.124134984076437F, 0.0F, -1.5707963267948917F));
        g.addOrReplaceChild("capo_frente_119", CubeListBuilder.create().texOffs(350, 167).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.97467383628164F, -24.64910654668894F, 5.052954147475055F, 3.1242342464041273F, 0.001242417243328114F, -1.4993509650644177F));
        g.addOrReplaceChild("capo_frente_120", CubeListBuilder.create().texOffs(260, 167).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.819611046182075F, -25.204126459383943F, 5.040201166586622F, 3.126280586494279F, 0.017563616246457244F, -1.2288575025632509F));
        g.addOrReplaceChild("capo_frente_121", CubeListBuilder.create().texOffs(218, 167).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.18277809512948F, -26.085899972708603F, 4.946045725166186F, 3.133669011191587F, 0.06323166488987605F, -0.7678329011720796F));
        g.addOrReplaceChild("capo_frente_122", CubeListBuilder.create().texOffs(168, 167).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.8451664815851F, -26.78087997898244F, 4.698851679070564F, 3.140610726392595F, 0.09573216436074462F, -0.25358540183878814F));
        g.addOrReplaceChild("capo_frente_123", CubeListBuilder.create().texOffs(1002, 163).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.93498444781447F, -14.437499626791322F, 6.213248159229039F, 3.0639452462379624F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_124", CubeListBuilder.create().texOffs(0, 167).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.93498444781447F, -17.31249967135846F, 6.213248159229039F, 3.0639452462379624F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_125", CubeListBuilder.create().texOffs(18, 167).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.93498444781447F, -20.187499715925597F, 6.213248159229039F, 3.0639452462379624F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_126", CubeListBuilder.create().texOffs(36, 167).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-35.934984447814486F, -23.06249975026525F, 6.213248159228963F, 3.063945246237976F, 0.0F, -1.5707963267949052F));
        g.addOrReplaceChild("capo_frente_127", CubeListBuilder.create().texOffs(0, 171).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.92507097681852F, -24.64538761148774F, 6.209542591335797F, 3.0643568187790247F, -0.002102320445719273F, -1.5005845438910255F));
        g.addOrReplaceChild("capo_frente_128", CubeListBuilder.create().texOffs(926, 167).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.77658586148143F, -25.191128396515396F, 6.171610777294657F, 3.0667102919984215F, 0.038629146124338376F, -1.234420174856749F));
        g.addOrReplaceChild("capo_frente_129", CubeListBuilder.create().texOffs(874, 167).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.15474802500307F, -26.0679710664378F, 6.05614507560051F, 3.0792458691427056F, 0.06196577275741513F, -0.7747445979064476F));
        g.addOrReplaceChild("capo_frente_130", CubeListBuilder.create().texOffs(810, 167).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-33.83574091643291F, -26.770702972049857F, 5.821577586992113F, 3.1163015723147387F, 0.09197698282494866F, -0.26223512297015966F));
        g.addOrReplaceChild("capo_frente_131", CubeListBuilder.create().texOffs(634, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.83229015924029F, -14.437499626791322F, 6.999814069455573F, 2.9230833476032254F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_132", CubeListBuilder.create().texOffs(650, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.83229015924029F, -17.31249967135846F, 6.999814069455573F, 2.9230833476032254F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_133", CubeListBuilder.create().texOffs(666, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.83229015924029F, -20.187499715925597F, 6.999814069455573F, 2.9230833476032254F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_134", CubeListBuilder.create().texOffs(682, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.83229015924034F, -23.0624997426562F, 6.999814069455345F, 2.923083347603294F, 0.0F, -1.5707963267949312F));
        g.addOrReplaceChild("capo_frente_135", CubeListBuilder.create().texOffs(6, 171).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.823444780864705F, -24.631587547497677F, 6.993554767896223F, 2.9238018282630507F, -0.016844408541749782F, -1.4894475680720802F));
        g.addOrReplaceChild("capo_frente_136", CubeListBuilder.create().texOffs(934, 167).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.68790297111244F, -25.134820260644283F, 6.93091939542166F, 2.915881022780317F, 0.0385808715500418F, -1.218152404742999F));
        g.addOrReplaceChild("capo_frente_137", CubeListBuilder.create().texOffs(884, 167).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-35.09782665050543F, -25.9715889407479F, 6.786244780651138F, 2.8680949890009044F, 0.13368610297644462F, -0.787275895714319F));
        g.addOrReplaceChild("capo_frente_138", CubeListBuilder.create().texOffs(822, 167).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-33.8172233806375F, -26.695791948339973F, 6.531530632576968F, 2.879833364017708F, 0.19172981396608027F, -0.30700128675594807F));
        g.addOrReplaceChild("capo_frente_139", CubeListBuilder.create().texOffs(510, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.698570938841826F, -14.437499626791322F, 7.435840647592193F, 2.701609172153992F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_140", CubeListBuilder.create().texOffs(524, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.698570938841826F, -17.31249967135846F, 7.435840647592193F, 2.701609172153992F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_141", CubeListBuilder.create().texOffs(538, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.698570938841826F, -20.187499715925597F, 7.435840647592193F, 2.701609172153992F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_142", CubeListBuilder.create().texOffs(552, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.69857093884194F, -23.062499732152425F, 7.435840647591963F, 2.7016091721541935F, 0.0F, -1.5707963267949745F));
        g.addOrReplaceChild("capo_frente_143", CubeListBuilder.create().texOffs(930, 174).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.68948604333086F, -24.6120375502798F, 7.434027017518782F, 2.7011780284068845F, -0.0006482423876023557F, -1.481975630557743F));
        g.addOrReplaceChild("capo_frente_144", CubeListBuilder.create().texOffs(888, 174).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.56076412232353F, -25.041932476857237F, 7.399495913067149F, 2.6835439541353447F, 0.006979373109358809F, -1.166741361371396F));
        g.addOrReplaceChild("capo_frente_145", CubeListBuilder.create().texOffs(826, 174).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.00533521407168F, -25.777937777729605F, 7.293698776028075F, 2.6049401576681936F, 0.1204163379841346F, -0.7647391287456696F));
        g.addOrReplaceChild("capo_frente_146", CubeListBuilder.create().texOffs(764, 174).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.784771665657985F, -26.51482689680995F, 6.995297351917523F, 2.619141274708852F, 0.2599923917476651F, -0.3858037278998299F));
        g.addOrReplaceChild("capo_frente_147", CubeListBuilder.create().texOffs(566, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.55630956779287F, -14.437499626791322F, 7.669252555237485F, 2.4362495477334107F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_148", CubeListBuilder.create().texOffs(580, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.55630956779287F, -17.31249967135846F, 7.669252555237485F, 2.4362495477334107F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_149", CubeListBuilder.create().texOffs(594, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.55630956779287F, -20.187499715925597F, 7.669252555237485F, 2.4362495477334107F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_150", CubeListBuilder.create().texOffs(608, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.55630956779299F, -23.062499722913813F, 7.669252555237328F, 2.4362495477336497F, 0.0F, -1.5707963267949756F));
        g.addOrReplaceChild("capo_frente_151", CubeListBuilder.create().texOffs(894, 174).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.411022370201295F, -24.947175155619885F, 7.669091889261567F, 2.394717766691334F, 0.010730510522108033F, -1.1230582493163817F));
        g.addOrReplaceChild("capo_frente_152", CubeListBuilder.create().texOffs(834, 174).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-34.874509816302115F, -25.534994298738454F, 7.638190492526107F, 2.3044854121870078F, 0.05264129103987204F, -0.6743042314303029F));
        g.addOrReplaceChild("capo_frente_153", CubeListBuilder.create().texOffs(774, 174).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.73096568510887F, -26.24710601309733F, 7.37520800234268F, 2.3518441979565723F, 0.27769517437729613F, -0.4819308014907514F));
        g.addOrReplaceChild("capo_frente_154", CubeListBuilder.create().texOffs(622, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.398147204077716F, -14.437499626791322F, 7.811162643312713F, 2.156330578491478F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_155", CubeListBuilder.create().texOffs(636, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.398147204077716F, -17.31249967135846F, 7.811162643312713F, 2.156330578491478F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_156", CubeListBuilder.create().texOffs(650, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.398147204077716F, -20.187499715925597F, 7.811162643312713F, 2.156330578491478F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_157", CubeListBuilder.create().texOffs(664, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.398147204077745F, -23.0624997147088F, 7.811162643312683F, 2.156330578491534F, 0.0F, -1.5707963267949177F));
        g.addOrReplaceChild("capo_frente_158", CubeListBuilder.create().texOffs(934, 174).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.234632111734534F, -24.859834803437806F, 7.8285615603831165F, 2.096818528474533F, -0.0012231120655044425F, -1.0557780568264001F));
        g.addOrReplaceChild("capo_frente_159", CubeListBuilder.create().texOffs(900, 174).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-34.699347916768495F, -25.285581425467647F, 7.845332781457895F, 2.0125275229646253F, -0.011323822835004474F, -0.5116429693593407F));
        g.addOrReplaceChild("capo_frente_160", CubeListBuilder.create().texOffs(784, 174).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.65034146957116F, -25.930584876336322F, 7.654579366186998F, 2.1078354429238386F, 0.24768836872805874F, -0.574669801143792F));
        g.addOrReplaceChild("capo_frente_161", CubeListBuilder.create().texOffs(678, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.18205004602379F, -14.437499626791322F, 7.909565140878861F, 1.8793346344193467F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_162", CubeListBuilder.create().texOffs(692, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.18205004602379F, -17.31249967135846F, 7.909565140878861F, 1.8793346344193467F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_163", CubeListBuilder.create().texOffs(706, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.18205004602379F, -20.187499715925597F, 7.909565140878861F, 1.8793346344193467F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_164", CubeListBuilder.create().texOffs(720, 174).addBox(-3.0F, -1.0F, -0.5F, 6.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-35.18205004602376F, -23.0624997062667F, 7.9095651408788665F, 1.879334634419326F, 0.0F, -1.5707963267948792F));
        g.addOrReplaceChild("capo_frente_165", CubeListBuilder.create().texOffs(938, 174).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-34.98934175721854F, -24.775284367224135F, 7.9283308210086885F, 1.8269032145868525F, 0.007265333864755166F, -1.0215569264855415F));
        g.addOrReplaceChild("capo_frente_166", CubeListBuilder.create().texOffs(906, 174).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-34.462441163341644F, -25.06914089959556F, 7.950740303439035F, 1.7810366336941783F, -0.024756641621486792F, -0.36967330815315425F));
        g.addOrReplaceChild("capo_frente_167", CubeListBuilder.create().texOffs(842, 174).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.54491195326877F, -25.613238679394314F, 7.835998614320312F, 1.9294741922162177F, 0.18238027739542298F, -0.6328815259400614F));
        g.addOrReplaceChild("capo_frente_168", CubeListBuilder.create().texOffs(698, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-34.73098844813183F, -14.437499626791322F, 7.974362021625746F, 1.6431676068275882F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_169", CubeListBuilder.create().texOffs(714, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-34.73098844813183F, -17.31249967135846F, 7.974362021625746F, 1.6431676068275882F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_170", CubeListBuilder.create().texOffs(730, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-34.73098844813183F, -20.187499715925597F, 7.974362021625746F, 1.6431676068275882F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_171", CubeListBuilder.create().texOffs(746, 167).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-34.730988448131605F, -23.062499696270642F, 7.974362021625752F, 1.6431676068275443F, 0.0F, -1.5707963267947396F));
        g.addOrReplaceChild("capo_frente_172", CubeListBuilder.create().texOffs(12, 171).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-34.53684143900769F, -24.696120648243586F, 7.98279146942162F, 1.6223588766682882F, -0.010841973962751635F, -1.0594346888362987F));
        g.addOrReplaceChild("capo_frente_173", CubeListBuilder.create().texOffs(912, 174).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-34.118916009209016F, -24.914455778086644F, 7.990783396048497F, 1.6207648072618381F, 0.014005322287307108F, -0.8313487595250799F));
        g.addOrReplaceChild("capo_frente_174", CubeListBuilder.create().texOffs(850, 174).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.41821741365317F, -25.327103939606076F, 7.940213360636902F, 1.794380939137711F, 0.10330180208768051F, -0.624333310918875F));
        g.addOrReplaceChild("capo_frente_175", CubeListBuilder.create().texOffs(54, 167).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.70527366969348F, -14.437499626791322F, 7.9988062836025495F, 1.5724895200131381F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_176", CubeListBuilder.create().texOffs(72, 167).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.70527366969348F, -17.31249967135846F, 7.9988062836025495F, 1.5724895200131381F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_177", CubeListBuilder.create().texOffs(90, 167).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.70527366969348F, -20.187499715925597F, 7.9988062836025495F, 1.5724895200131381F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_frente_178", CubeListBuilder.create().texOffs(108, 167).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.705273669693284F, -23.062499689147934F, 7.998806283602552F, 1.5724895200131346F, 0.0F, -1.5707963267947533F));
        g.addOrReplaceChild("capo_frente_179", CubeListBuilder.create().texOffs(358, 167).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-33.616315753905496F, -24.650085957812152F, 7.9993457482427655F, 1.5718581923163426F, -0.0014658695564793644F, -1.555767055889732F));
        g.addOrReplaceChild("capo_frente_180", CubeListBuilder.create().texOffs(18, 171).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-33.456130012075775F, -24.83586191955634F, 7.999557031475203F, 1.5717670705424978F, 0.0006722040147826342F, -1.5298437047516065F));
        g.addOrReplaceChild("capo_frente_181", CubeListBuilder.create().texOffs(24, 171).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-33.17471568127527F, -25.07473005237761F, 7.988276888388133F, 1.6362698288332473F, 0.061111697986168945F, -0.8205827751138144F));
        g.addOrReplaceChild("faro_fi_0", CubeListBuilder.create().texOffs(186, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(554, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-35.9F, -14.6F, -5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_fi_1", CubeListBuilder.create().texOffs(210, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(578, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-35.9F, -14.6F, -5.5F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_fi_2", CubeListBuilder.create().texOffs(234, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(602, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-35.9F, -14.6F, -5.5F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_fi_3", CubeListBuilder.create().texOffs(258, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(626, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-35.9F, -14.6F, -5.5F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_fi_vidrio", CubeListBuilder.create().texOffs(580, 145).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-36.519999999999996F, -14.6F, -5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_fd_0", CubeListBuilder.create().texOffs(282, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(650, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-35.9F, -14.6F, 5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_fd_1", CubeListBuilder.create().texOffs(306, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(674, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-35.9F, -14.6F, 5.5F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_fd_2", CubeListBuilder.create().texOffs(330, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(698, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-35.9F, -14.6F, 5.5F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_fd_3", CubeListBuilder.create().texOffs(354, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(722, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-35.9F, -14.6F, 5.5F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_fd_vidrio", CubeListBuilder.create().texOffs(612, 145).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-36.519999999999996F, -14.6F, 5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escape_0", CubeListBuilder.create().texOffs(382, 145).addBox(-13.0F, -30.0F, -3.5F, 26.0F, 4.0F, 7.0F).texOffs(704, 86).addBox(-3.5F, -30.0F, -13.0F, 7.0F, 4.0F, 26.0F), PartPose.offset(-24.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("escape_1", CubeListBuilder.create().texOffs(448, 145).addBox(-13.0F, -30.0F, -3.5F, 26.0F, 4.0F, 7.0F).texOffs(770, 86).addBox(-3.5F, -30.0F, -13.0F, 7.0F, 4.0F, 26.0F), PartPose.offsetAndRotation(-24.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("escape_2", CubeListBuilder.create().texOffs(514, 145).addBox(-13.0F, -30.0F, -3.5F, 26.0F, 4.0F, 7.0F).texOffs(836, 86).addBox(-3.5F, -30.0F, -13.0F, 7.0F, 4.0F, 26.0F), PartPose.offsetAndRotation(-24.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("tapa_radiador_0", CubeListBuilder.create().texOffs(374, 119).addBox(-17.0F, -28.0F, -5.5F, 34.0F, 2.0F, 11.0F).texOffs(576, 0).addBox(-5.5F, -28.0F, -17.0F, 11.0F, 2.0F, 34.0F), PartPose.offset(-34.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("tapa_radiador_1", CubeListBuilder.create().texOffs(464, 119).addBox(-17.0F, -28.0F, -5.5F, 34.0F, 2.0F, 11.0F).texOffs(666, 0).addBox(-5.5F, -28.0F, -17.0F, 11.0F, 2.0F, 34.0F), PartPose.offsetAndRotation(-34.0F, 0.0F, 0.0F, 0.0F, 0.6283185307179586F, 0.0F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(190, 119).addBox(11.6F, -29.0F, 11.6F, 1.0F, 14.0F, 1.0F).texOffs(194, 119).addBox(11.6F, -29.0F, -12.6F, 1.0F, 14.0F, 1.0F).texOffs(198, 119).addBox(21.4F, -29.0F, 11.6F, 1.0F, 14.0F, 1.0F).texOffs(202, 119).addBox(21.4F, -29.0F, -12.6F, 1.0F, 14.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_caja", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -40.0F, 0.0F, 52.0F, 40.0F, 46.0F), PartPose.offset(10.0F, -13.0F, -11.5F));
        g.addOrReplaceChild("cabina_frente_arco", CubeListBuilder.create().texOffs(388, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 46.0F), PartPose.offset(10.0F, -33.0F, -11.5F));
        g.addOrReplaceChild("cabina_cola_arco", CubeListBuilder.create().texOffs(482, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 46.0F), PartPose.offset(35.0F, -33.0F, -11.5F));
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(436, 157).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -33.37432607408971F, -11.043728878291013F, -2.764368878027928F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(498, 157).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -34.0656435769368F, -9.107469937215573F, -2.8329550190391806F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(560, 157).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -34.62263928167516F, -7.12838571426286F, -2.901541160050422F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(622, 157).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -35.0426940747393F, -5.115782288979785F, -2.9701273010616753F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(684, 157).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -35.323832768174626F, -3.079123355409709F, -3.0387134420729196F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(746, 157).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -35.46473338739587F, -1.027985721768222F, -3.10729958308417F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(808, 157).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -35.46473338739587F, 1.0279857217682207F, 3.10729958308417F, 0.0F, 0.0F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(870, 157).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -35.323832768174626F, 3.079123355409706F, 3.0387134420729196F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(932, 157).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -35.0426940747393F, 5.115782288979785F, 2.9701273010616753F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(0, 163).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -34.62263928167516F, 7.128385714262858F, 2.9015411600504217F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(62, 163).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -34.0656435769368F, 9.10746993721557F, 2.8329550190391806F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(124, 163).addBox(-14.0F, -1.0F, -1.5F, 28.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(23.0F, -33.37432607408971F, 11.04372887829101F, 2.7643688780279283F, 0.0F, 0.0F));
        g.addOrReplaceChild("faro_ti_0", CubeListBuilder.create().texOffs(378, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(746, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(36.1F, -15.5F, -6.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_ti_1", CubeListBuilder.create().texOffs(402, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(770, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(36.1F, -15.5F, -6.5F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_ti_2", CubeListBuilder.create().texOffs(426, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(794, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(36.1F, -15.5F, -6.5F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_ti_3", CubeListBuilder.create().texOffs(450, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(818, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(36.1F, -15.5F, -6.5F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_ti_vidrio", CubeListBuilder.create().texOffs(644, 145).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(36.72F, -15.5F, -6.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_td_0", CubeListBuilder.create().texOffs(474, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(842, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(36.1F, -15.5F, 6.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_td_1", CubeListBuilder.create().texOffs(498, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(866, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(36.1F, -15.5F, 6.5F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_td_2", CubeListBuilder.create().texOffs(522, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(890, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(36.1F, -15.5F, 6.5F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_td_3", CubeListBuilder.create().texOffs(546, 163).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(914, 119).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(36.1F, -15.5F, 6.5F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_td_vidrio", CubeListBuilder.create().texOffs(676, 145).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(36.72F, -15.5F, 6.5F, 0.0F, 0.0F, -1.5707963267948966F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "viga_rayasf", 0.5F, 0.5F, 0.5F);
        escalar(g0, "tope_fi_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_fi_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_fi_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_fic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_fic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_fic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_fic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_fd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_fd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_fd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_fdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_fdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_fdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_fdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "viga_rayast", 0.5F, 0.5F, 0.5F);
        escalar(g0, "tope_ti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_ti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_ti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_tic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_td_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_td_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_td_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_tdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "capo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_frente_0", 0.4874998755971072F, 1.0F, 0.48667286756108424F);
        escalar(g0, "capo_frente_1", 0.4875001392586052F, 1.0F, 0.48667286756108424F);
        escalar(g0, "capo_frente_2", 0.4874998755971072F, 1.0F, 0.48667286756108424F);
        escalar(g0, "capo_frente_3", 0.4875001154770057F, 1.0F, 0.48667286756094685F);
        escalar(g0, "capo_frente_4", 0.27093872332155733F, 1.0F, 0.4274380490401333F);
        escalar(g0, "capo_frente_5", 0.38307285646289274F, 1.0F, 0.48142125184503015F);
        escalar(g0, "capo_frente_6", 0.514632983652317F, 1.0F, 0.307356843373726F);
        escalar(g0, "capo_frente_7", 0.4874998755971072F, 1.0F, 0.34654819097337697F);
        escalar(g0, "capo_frente_8", 0.4875001392586052F, 1.0F, 0.34654819097337697F);
        escalar(g0, "capo_frente_9", 0.4874998755971072F, 1.0F, 0.34654819097337697F);
        escalar(g0, "capo_frente_10", 0.48750011785124164F, 1.0F, 0.34654819097359535F);
        escalar(g0, "capo_frente_11", 0.3955682134019463F, 1.0F, 0.3327822812235396F);
        escalar(g0, "capo_frente_12", 0.32932086761332247F, 1.0F, 0.4842173437965901F);
        escalar(g0, "capo_frente_13", 0.36258033496664427F, 1.0F, 0.41535036561342403F);
        escalar(g0, "capo_frente_14", 0.4874998755971072F, 1.0F, 0.3236315239206101F);
        escalar(g0, "capo_frente_15", 0.4875001392586052F, 1.0F, 0.3236315239206101F);
        escalar(g0, "capo_frente_16", 0.4874998755971072F, 1.0F, 0.3236315239206101F);
        escalar(g0, "capo_frente_17", 0.48750012118326075F, 1.0F, 0.32363152392062483F);
        escalar(g0, "capo_frente_18", 0.48327046697518633F, 1.0F, 0.37075557399735776F);
        escalar(g0, "capo_frente_19", 0.42513795414162536F, 1.0F, 0.39552648259359596F);
        escalar(g0, "capo_frente_20", 0.4752234064587622F, 1.0F, 0.4326902504661328F);
        escalar(g0, "capo_frente_21", 0.4874998755971072F, 1.0F, 0.2557602680120661F);
        escalar(g0, "capo_frente_22", 0.4875001392586052F, 1.0F, 0.2557602680120661F);
        escalar(g0, "capo_frente_23", 0.4874998755971072F, 1.0F, 0.2557602680120661F);
        escalar(g0, "capo_frente_24", 0.48750012399729387F, 1.0F, 0.25576026801216484F);
        escalar(g0, "capo_frente_25", 0.5401199970139021F, 1.0F, 0.298942666159383F);
        escalar(g0, "capo_frente_26", 0.484394853915571F, 1.0F, 0.4066328601196552F);
        escalar(g0, "capo_frente_27", 0.4125888794075108F, 1.0F, 0.47753412305463877F);
        escalar(g0, "capo_frente_28", 0.4874998755971072F, 1.0F, 0.27341774703249855F);
        escalar(g0, "capo_frente_29", 0.4875001392586052F, 1.0F, 0.27341774703249855F);
        escalar(g0, "capo_frente_30", 0.4874998755971072F, 1.0F, 0.27341774703249855F);
        escalar(g0, "capo_frente_31", 0.4875001267322987F, 1.0F, 0.27341774703267047F);
        escalar(g0, "capo_frente_32", 0.31199100672822444F, 1.0F, 0.3223150584517556F);
        escalar(g0, "capo_frente_33", 0.37040346643419914F, 1.0F, 0.45554434119050796F);
        escalar(g0, "capo_frente_34", 0.44190046897671603F, 1.0F, 0.5115000677133107F);
        escalar(g0, "capo_frente_35", 0.4874998755971072F, 1.0F, 0.3779503852945915F);
        escalar(g0, "capo_frente_36", 0.4875001392586052F, 1.0F, 0.3779503852945915F);
        escalar(g0, "capo_frente_37", 0.4874998755971072F, 1.0F, 0.3779503852945915F);
        escalar(g0, "capo_frente_38", 0.48750012981183505F, 1.0F, 0.3779503852946105F);
        escalar(g0, "capo_frente_39", 0.2748938038529519F, 1.0F, 0.3835169269356894F);
        escalar(g0, "capo_frente_40", 0.36672333323291756F, 1.0F, 0.4372957715471173F);
        escalar(g0, "capo_frente_41", 0.42252590537806073F, 1.0F, 0.5474108518526806F);
        escalar(g0, "capo_frente_42", 0.451288986453406F, 1.0F, 0.5421778693493016F);
        escalar(g0, "capo_frente_43", 0.4874998755971072F, 1.0F, 0.31967548457886114F);
        escalar(g0, "capo_frente_44", 0.4875001392586052F, 1.0F, 0.31967548457886114F);
        escalar(g0, "capo_frente_45", 0.4874998755971072F, 1.0F, 0.31967548457886114F);
        escalar(g0, "capo_frente_46", 0.48750013331309444F, 1.0F, 0.31967548457894535F);
        escalar(g0, "capo_frente_47", 0.3140897055241269F, 1.0F, 0.32211668345162914F);
        escalar(g0, "capo_frente_48", 0.42167937351010365F, 1.0F, 0.3315656593411189F);
        escalar(g0, "capo_frente_49", 0.45834369629749916F, 1.0F, 0.33433763257111115F);
        escalar(g0, "capo_frente_50", 0.4498528343652675F, 1.0F, 0.28381486153777924F);
        escalar(g0, "capo_frente_51", 0.4874998755971072F, 1.0F, 0.35027003822413544F);
        escalar(g0, "capo_frente_52", 0.4875001392586052F, 1.0F, 0.35027003822413544F);
        escalar(g0, "capo_frente_53", 0.4874998755971072F, 1.0F, 0.35027003822413544F);
        escalar(g0, "capo_frente_54", 0.4875001358494437F, 1.0F, 0.3502700382241067F);
        escalar(g0, "capo_frente_55", 0.3417087244653884F, 1.0F, 0.5206138336471399F);
        escalar(g0, "capo_frente_56", 0.4509529147064316F, 1.0F, 0.48842128538353624F);
        escalar(g0, "capo_frente_57", 0.47235506461444393F, 1.0F, 0.4595864428002693F);
        escalar(g0, "capo_frente_58", 0.4523669287344874F, 1.0F, 0.4855563507386052F);
        escalar(g0, "capo_frente_59", 0.4874998755971072F, 1.0F, 0.45768859932258904F);
        escalar(g0, "capo_frente_60", 0.4875001392586052F, 1.0F, 0.45768859932258904F);
        escalar(g0, "capo_frente_61", 0.4874998755971072F, 1.0F, 0.45768859932258904F);
        escalar(g0, "capo_frente_62", 0.487500136557567F, 1.0F, 0.457688599322632F);
        escalar(g0, "capo_frente_63", 0.34898322831960155F, 1.0F, 0.4583785889524247F);
        escalar(g0, "capo_frente_64", 0.45605861484098764F, 1.0F, 0.462954243808295F);
        escalar(g0, "capo_frente_65", 0.4764103908814727F, 1.0F, 0.4676385508967351F);
        escalar(g0, "capo_frente_66", 0.4569253401389828F, 1.0F, 0.4583101429971718F);
        escalar(g0, "capo_frente_67", 0.4874998755971072F, 1.0F, 0.49852202649388677F);
        escalar(g0, "capo_frente_68", 0.4875001392586052F, 1.0F, 0.49852202649388677F);
        escalar(g0, "capo_frente_69", 0.4874998755971072F, 1.0F, 0.49852202649388677F);
        escalar(g0, "capo_frente_70", 0.487500136557567F, 1.0F, 0.49852202649387345F);
        escalar(g0, "capo_frente_71", 0.3489857248797767F, 1.0F, 0.4984814305682388F);
        escalar(g0, "capo_frente_72", 0.4563797808610899F, 1.0F, 0.4965704111348461F);
        escalar(g0, "capo_frente_73", 0.47698924030083245F, 1.0F, 0.4858695917128409F);
        escalar(g0, "capo_frente_74", 0.455078000022016F, 1.0F, 0.4601140201987218F);
        escalar(g0, "capo_frente_75", 0.4874998755971072F, 1.0F, 0.4853501029863215F);
        escalar(g0, "capo_frente_76", 0.4875001392586052F, 1.0F, 0.4853501029863215F);
        escalar(g0, "capo_frente_77", 0.4874998755971072F, 1.0F, 0.4853501029863215F);
        escalar(g0, "capo_frente_78", 0.487500136557567F, 1.0F, 0.4853501029861668F);
        escalar(g0, "capo_frente_79", 0.34898367720940693F, 1.0F, 0.4849990096980187F);
        escalar(g0, "capo_frente_80", 0.4562229403404786F, 1.0F, 0.4794126400996154F);
        escalar(g0, "capo_frente_81", 0.475531993360929F, 1.0F, 0.4512933475577305F);
        escalar(g0, "capo_frente_82", 0.4520572461972929F, 1.0F, 0.38792058013363034F);
        escalar(g0, "capo_frente_83", 0.4874998755971072F, 1.0F, 0.4147262226972551F);
        escalar(g0, "capo_frente_84", 0.4875001392586052F, 1.0F, 0.4147262226972551F);
        escalar(g0, "capo_frente_85", 0.4874998755971072F, 1.0F, 0.4147262226972551F);
        escalar(g0, "capo_frente_86", 0.48750028749314467F, 1.0F, 0.41504893868857023F);
        escalar(g0, "capo_frente_87", 0.348989859080633F, 1.0F, 0.41501371442060647F);
        escalar(g0, "capo_frente_88", 0.45612829437197666F, 1.0F, 0.41450918200753256F);
        escalar(g0, "capo_frente_89", 0.474776607225152F, 1.0F, 0.41223585571137156F);
        escalar(g0, "capo_frente_90", 0.45064502091147923F, 1.0F, 0.5075533301186017F);
        escalar(g0, "capo_frente_91", 0.4874998755971072F, 1.0F, 0.4153631547905058F);
        escalar(g0, "capo_frente_92", 0.4875001392586052F, 1.0F, 0.4153631547905058F);
        escalar(g0, "capo_frente_93", 0.4874998755971072F, 1.0F, 0.4153631547905058F);
        escalar(g0, "capo_frente_94", 0.48750028749314467F, 1.0F, 0.4150404387991907F);
        escalar(g0, "capo_frente_95", 0.34898985908063346F, 1.0F, 0.41500521453122696F);
        escalar(g0, "capo_frente_96", 0.45612829437197455F, 1.0F, 0.41442068468536347F);
        escalar(g0, "capo_frente_97", 0.47477660722515425F, 1.0F, 0.41154112578475066F);
        escalar(g0, "capo_frente_98", 0.45064502091148045F, 1.0F, 0.5075533301185948F);
        escalar(g0, "capo_frente_99", 0.4874998755971072F, 1.0F, 0.4853501029860084F);
        escalar(g0, "capo_frente_100", 0.4875001392586052F, 1.0F, 0.4853501029860084F);
        escalar(g0, "capo_frente_101", 0.4874998755971072F, 1.0F, 0.4853501029860084F);
        escalar(g0, "capo_frente_102", 0.487500136557567F, 1.0F, 0.4853501029861665F);
        escalar(g0, "capo_frente_103", 0.34898367720941326F, 1.0F, 0.4849990096980248F);
        escalar(g0, "capo_frente_104", 0.4562229403404479F, 1.0F, 0.4794126400998985F);
        escalar(g0, "capo_frente_105", 0.4755319933609607F, 1.0F, 0.45129334755827305F);
        escalar(g0, "capo_frente_106", 0.45205724619731197F, 1.0F, 0.38792058013364844F);
        escalar(g0, "capo_frente_107", 0.4874998755971072F, 1.0F, 0.498522026493857F);
        escalar(g0, "capo_frente_108", 0.4875001392586052F, 1.0F, 0.498522026493857F);
        escalar(g0, "capo_frente_109", 0.4874998755971072F, 1.0F, 0.498522026493857F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "capo_frente_110", 0.487500136557567F, 1.0F, 0.4985220264938739F);
        escalar(g0, "capo_frente_111", 0.3489857248797909F, 1.0F, 0.4984814305681635F);
        escalar(g0, "capo_frente_112", 0.4563797808610143F, 1.0F, 0.49657041113477995F);
        escalar(g0, "capo_frente_113", 0.4769892403009479F, 1.0F, 0.48586959171252636F);
        escalar(g0, "capo_frente_114", 0.4550780000220192F, 1.0F, 0.4601140201983695F);
        escalar(g0, "capo_frente_115", 0.4874998755971072F, 1.0F, 0.45768859932277994F);
        escalar(g0, "capo_frente_116", 0.4875001392586052F, 1.0F, 0.45768859932277994F);
        escalar(g0, "capo_frente_117", 0.4874998755971072F, 1.0F, 0.45768859932277994F);
        escalar(g0, "capo_frente_118", 0.487500136557567F, 1.0F, 0.4576885993226219F);
        escalar(g0, "capo_frente_119", 0.3489832283196092F, 1.0F, 0.4583785889526238F);
        escalar(g0, "capo_frente_120", 0.4560586148409412F, 1.0F, 0.46295424380803385F);
        escalar(g0, "capo_frente_121", 0.47641039088157605F, 1.0F, 0.4676385508961732F);
        escalar(g0, "capo_frente_122", 0.4569253401389544F, 1.0F, 0.4583101429971707F);
        escalar(g0, "capo_frente_123", 0.4874998755971072F, 1.0F, 0.3502700382243303F);
        escalar(g0, "capo_frente_124", 0.4875001392586052F, 1.0F, 0.3502700382243303F);
        escalar(g0, "capo_frente_125", 0.4874998755971072F, 1.0F, 0.3502700382243303F);
        escalar(g0, "capo_frente_126", 0.4875001358494437F, 1.0F, 0.35027003822422115F);
        escalar(g0, "capo_frente_127", 0.3417087244653875F, 1.0F, 0.5206138336471657F);
        escalar(g0, "capo_frente_128", 0.4509529147064447F, 1.0F, 0.48842128538363916F);
        escalar(g0, "capo_frente_129", 0.4723550646144681F, 1.0F, 0.45958644280066274F);
        escalar(g0, "capo_frente_130", 0.4523669287344754F, 1.0F, 0.4855563507390188F);
        escalar(g0, "capo_frente_131", 0.4874998755971072F, 1.0F, 0.3196754845788227F);
        escalar(g0, "capo_frente_132", 0.4875001392586052F, 1.0F, 0.3196754845788227F);
        escalar(g0, "capo_frente_133", 0.4874998755971072F, 1.0F, 0.3196754845788227F);
        escalar(g0, "capo_frente_134", 0.48750013331309444F, 1.0F, 0.31967548457883177F);
        escalar(g0, "capo_frente_135", 0.3140897055241313F, 1.0F, 0.32211668345143923F);
        escalar(g0, "capo_frente_136", 0.42167937351011F, 1.0F, 0.3315656593410439F);
        escalar(g0, "capo_frente_137", 0.4583436962975116F, 1.0F, 0.3343376325711632F);
        escalar(g0, "capo_frente_138", 0.44985283436527657F, 1.0F, 0.2838148615378137F);
        escalar(g0, "capo_frente_139", 0.4874998755971072F, 1.0F, 0.3779503852946605F);
        escalar(g0, "capo_frente_140", 0.4875001392586052F, 1.0F, 0.3779503852946605F);
        escalar(g0, "capo_frente_141", 0.4874998755971072F, 1.0F, 0.3779503852946605F);
        escalar(g0, "capo_frente_142", 0.48750012981183505F, 1.0F, 0.37795038529459285F);
        escalar(g0, "capo_frente_143", 0.27489380385295553F, 1.0F, 0.38351692693564415F);
        escalar(g0, "capo_frente_144", 0.3667233332329085F, 1.0F, 0.43729577154712074F);
        escalar(g0, "capo_frente_145", 0.42252590537807005F, 1.0F, 0.547410851852687F);
        escalar(g0, "capo_frente_146", 0.45128898645342225F, 1.0F, 0.5421778693493258F);
        escalar(g0, "capo_frente_147", 0.4874998755971072F, 1.0F, 0.27341774703241883F);
        escalar(g0, "capo_frente_148", 0.4875001392586052F, 1.0F, 0.27341774703241883F);
        escalar(g0, "capo_frente_149", 0.4874998755971072F, 1.0F, 0.27341774703241883F);
        escalar(g0, "capo_frente_150", 0.4875001267322987F, 1.0F, 0.2734177470326134F);
        escalar(g0, "capo_frente_151", 0.31199100672821944F, 1.0F, 0.32231505845177083F);
        escalar(g0, "capo_frente_152", 0.3704034664342016F, 1.0F, 0.4555443411905384F);
        escalar(g0, "capo_frente_153", 0.441900468976739F, 1.0F, 0.5115000677133741F);
        escalar(g0, "capo_frente_154", 0.4874998755971072F, 1.0F, 0.25576026801206114F);
        escalar(g0, "capo_frente_155", 0.4875001392586052F, 1.0F, 0.25576026801206114F);
        escalar(g0, "capo_frente_156", 0.4874998755971072F, 1.0F, 0.25576026801206114F);
        escalar(g0, "capo_frente_157", 0.48750012399729387F, 1.0F, 0.25576026801216706F);
        escalar(g0, "capo_frente_158", 0.5401199970138875F, 1.0F, 0.2989426661593844F);
        escalar(g0, "capo_frente_159", 0.48439485391557074F, 1.0F, 0.40663286011964944F);
        escalar(g0, "capo_frente_160", 0.4125888794075378F, 1.0F, 0.47753412305464515F);
        escalar(g0, "capo_frente_161", 0.4874998755971072F, 1.0F, 0.32363152392061145F);
        escalar(g0, "capo_frente_162", 0.4875001392586052F, 1.0F, 0.32363152392061145F);
        escalar(g0, "capo_frente_163", 0.4874998755971072F, 1.0F, 0.32363152392061145F);
        escalar(g0, "capo_frente_164", 0.48750012118326075F, 1.0F, 0.32363152392063976F);
        escalar(g0, "capo_frente_165", 0.48327046697513515F, 1.0F, 0.3707555739973932F);
        escalar(g0, "capo_frente_166", 0.42513795414162764F, 1.0F, 0.3955264825935734F);
        escalar(g0, "capo_frente_167", 0.4752234064587811F, 1.0F, 0.43269025046618165F);
        escalar(g0, "capo_frente_168", 0.4874998755971072F, 1.0F, 0.3465481909733842F);
        escalar(g0, "capo_frente_169", 0.4875001392586052F, 1.0F, 0.3465481909733842F);
        escalar(g0, "capo_frente_170", 0.4874998755971072F, 1.0F, 0.3465481909733842F);
        escalar(g0, "capo_frente_171", 0.48750011785124164F, 1.0F, 0.34654819097357026F);
        escalar(g0, "capo_frente_172", 0.39556821340190834F, 1.0F, 0.3327822812235106F);
        escalar(g0, "capo_frente_173", 0.3293208676133233F, 1.0F, 0.48421734379659126F);
        escalar(g0, "capo_frente_174", 0.36258033496664616F, 1.0F, 0.41535036561343547F);
        escalar(g0, "capo_frente_175", 0.4874998755971072F, 1.0F, 0.48667286756108424F);
        escalar(g0, "capo_frente_176", 0.4875001392586052F, 1.0F, 0.48667286756108424F);
        escalar(g0, "capo_frente_177", 0.4874998755971072F, 1.0F, 0.48667286756108424F);
        escalar(g0, "capo_frente_178", 0.4875001154770057F, 1.0F, 0.48667286756094685F);
        escalar(g0, "capo_frente_179", 0.27093872332156005F, 1.0F, 0.42743804904013455F);
        escalar(g0, "capo_frente_180", 0.38307285646289274F, 1.0F, 0.48142125184503015F);
        escalar(g0, "capo_frente_181", 0.514632983652318F, 1.0F, 0.30735684337372693F);
        escalar(g0, "faro_fi_0", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_fi_1", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_fi_2", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_fi_3", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_fi_vidrio", 0.225F, 0.15F, 0.225F);
        escalar(g0, "faro_fd_0", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_fd_1", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_fd_2", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_fd_3", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_fd_vidrio", 0.225F, 0.15F, 0.225F);
        escalar(g0, "escape_0", 0.08916238396514477F, 1.0F, 0.08916238396514477F);
        escalar(g0, "escape_1", 0.08916238396514477F, 1.0F, 0.08916238396514477F);
        escalar(g0, "escape_2", 0.08916238396514477F, 1.0F, 0.08916238396514477F);
        escalar(g0, "tapa_radiador_0", 0.055944500958538444F, 1.0F, 0.055944500958538444F);
        escalar(g0, "tapa_radiador_1", 0.055944500958538444F, 1.0F, 0.055944500958538444F);
        escalar(g0, "cabina_caja", 0.5F, 0.5F, 0.5F);
        escalar(g0, "cabina_frente_arco", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_cola_arco", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_techo_0", 1.0007142857142857F, 1.0F, 0.6923936541685443F);
        escalar(g0, "cabina_techo_1", 1.0007142857142857F, 1.0F, 0.6923936541685437F);
        escalar(g0, "cabina_techo_2", 1.0007142857142857F, 1.0F, 0.6923936541685453F);
        escalar(g0, "cabina_techo_3", 1.0007142857142857F, 1.0F, 0.6923936541685438F);
        escalar(g0, "cabina_techo_4", 1.0007142857142857F, 1.0F, 0.6923936541685446F);
        escalar(g0, "cabina_techo_5", 1.0007142857142857F, 1.0F, 0.6923936541685447F);
        escalar(g0, "cabina_techo_6", 1.0007142857142857F, 1.0F, 0.6923936541685439F);
        escalar(g0, "cabina_techo_7", 1.0007142857142857F, 1.0F, 0.6923936541685448F);
        escalar(g0, "cabina_techo_8", 1.0007142857142857F, 1.0F, 0.6923936541685444F);
        escalar(g0, "cabina_techo_9", 1.0007142857142857F, 1.0F, 0.6923936541685441F);
        escalar(g0, "cabina_techo_10", 1.0007142857142857F, 1.0F, 0.6923936541685441F);
        escalar(g0, "cabina_techo_11", 1.0007142857142857F, 1.0F, 0.6923936541685447F);
        escalar(g0, "faro_ti_0", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_ti_1", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_ti_2", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_ti_3", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_ti_vidrio", 0.225F, 0.15F, 0.225F);
        escalar(g0, "faro_td_0", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_td_1", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_td_2", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_td_3", 0.1765413504725815F, 0.6F, 0.1765413504725815F);
        escalar(g0, "faro_td_vidrio", 0.225F, 0.15F, 0.225F);
    }
}
