package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Motor Rail Simplex" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloSimplex {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("simplex"), "main"),
            LocomotoraMod.id("textures/entity/simplex.png"),
            List.of(
                new DatosModelo.Animada("ri0_0", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, -6.5F, -3.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri0_1", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, -6.5F, -3.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri0_2", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, -6.5F, -3.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("ri1_0", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, 6.5F, -3.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri1_1", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, 6.5F, -3.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri1_2", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, 6.5F, -3.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd0_0", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, -6.5F, -3.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd0_1", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, -6.5F, -3.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd0_2", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, -6.5F, -3.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd1_0", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, 6.5F, -3.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd1_1", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, 6.5F, -3.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd1_2", DatosModelo.RUEDA, 3.0F, 0.0F, 0.0F, 0.0F, 6.5F, -3.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("cab_manometro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 4.72F, -14.4F, 0.0F, "cuerpo", 4.8F, 0.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.0F, 0.0F, 5.5F, -9.0F, 0.0F, "cuerpo", -0.22F, -1.5F, 0.0F)),
            ModeloSimplex::crearCapa,
            16.0F,
            ModeloSimplex::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -6.5F, 6.5F)));

    private ModeloSimplex() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 64);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("ri0_0", CubeListBuilder.create().texOffs(436, 35).addBox(-3.0F, -3.0F, -6.0F, 6.0F, 6.0F, 2.0F).texOffs(830, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(476, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(748, 35).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-6.5F, -3.0F, 0.0F));
        g.addOrReplaceChild("ri0_1", CubeListBuilder.create().texOffs(846, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.5F, -3.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri0_2", CubeListBuilder.create().texOffs(862, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(492, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.5F, -3.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ri1_0", CubeListBuilder.create().texOffs(436, 35).addBox(-3.0F, -3.0F, -6.0F, 6.0F, 6.0F, 2.0F).texOffs(830, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(476, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(758, 35).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(6.5F, -3.0F, 0.0F));
        g.addOrReplaceChild("ri1_1", CubeListBuilder.create().texOffs(846, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.5F, -3.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri1_2", CubeListBuilder.create().texOffs(862, 35).addBox(-3.0F, -1.0F, -6.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(492, 35).addBox(-1.0F, -3.0F, -6.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.5F, -3.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd0_0", CubeListBuilder.create().texOffs(436, 35).addBox(-3.0F, -3.0F, 4.0F, 6.0F, 6.0F, 2.0F).texOffs(830, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(476, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(768, 35).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-6.5F, -3.0F, 0.0F));
        g.addOrReplaceChild("rd0_1", CubeListBuilder.create().texOffs(846, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.5F, -3.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd0_2", CubeListBuilder.create().texOffs(862, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(492, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-6.5F, -3.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd1_0", CubeListBuilder.create().texOffs(436, 35).addBox(-3.0F, -3.0F, 4.0F, 6.0F, 6.0F, 2.0F).texOffs(830, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(476, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(778, 35).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(6.5F, -3.0F, 0.0F));
        g.addOrReplaceChild("rd1_1", CubeListBuilder.create().texOffs(846, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.5F, -3.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd1_2", CubeListBuilder.create().texOffs(862, 35).addBox(-3.0F, -1.0F, 4.0F, 6.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(492, 35).addBox(-1.0F, -3.0F, 4.0F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(6.5F, -3.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(608, 35).addBox(-15.0F, -8.0F, 6.0F, 30.0F, 4.0F, 1.0F).texOffs(670, 35).addBox(-15.0F, -8.0F, -7.0F, 30.0F, 4.0F, 1.0F).texOffs(798, 35).addBox(-8.0F, -5.0F, 7.0F, 3.0F, 4.0F, 1.0F).texOffs(806, 35).addBox(-8.0F, -5.0F, -8.0F, 3.0F, 4.0F, 1.0F).texOffs(898, 35).addBox(-9.0F, -7.5F, 7.0F, 1.0F, 3.0F, 1.0F).texOffs(902, 35).addBox(-9.0F, -7.5F, -8.0F, 1.0F, 3.0F, 1.0F).texOffs(906, 35).addBox(-5.0F, -7.5F, 7.0F, 1.0F, 3.0F, 1.0F).texOffs(910, 35).addBox(-5.0F, -7.5F, -8.0F, 1.0F, 3.0F, 1.0F).texOffs(814, 35).addBox(5.0F, -5.0F, 7.0F, 3.0F, 4.0F, 1.0F).texOffs(822, 35).addBox(5.0F, -5.0F, -8.0F, 3.0F, 4.0F, 1.0F).texOffs(914, 35).addBox(4.0F, -7.5F, 7.0F, 1.0F, 3.0F, 1.0F).texOffs(918, 35).addBox(4.0F, -7.5F, -8.0F, 1.0F, 3.0F, 1.0F).texOffs(922, 35).addBox(8.0F, -7.5F, 7.0F, 1.0F, 3.0F, 1.0F).texOffs(926, 35).addBox(8.0F, -7.5F, -8.0F, 1.0F, 3.0F, 1.0F).texOffs(524, 0).addBox(-15.0F, -9.0F, -7.0F, 30.0F, 1.0F, 14.0F).texOffs(264, 0).addBox(-17.0F, -9.0F, -7.0F, 2.0F, 7.0F, 14.0F).texOffs(452, 35).addBox(-19.0F, -8.0F, -2.0F, 2.0F, 4.0F, 4.0F).texOffs(482, 46).addBox(-20.0F, -6.5F, -0.5F, 1.0F, 1.0F, 1.0F).texOffs(296, 0).addBox(15.0F, -9.0F, -7.0F, 2.0F, 7.0F, 14.0F).texOffs(464, 35).addBox(17.0F, -8.0F, -2.0F, 2.0F, 4.0F, 4.0F).texOffs(486, 46).addBox(19.0F, -6.5F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("radiador", CubeListBuilder.create().texOffs(328, 0).addBox(-15.0F, -18.0F, -5.5F, 4.0F, 9.0F, 11.0F), PartPose.ZERO);
        g.addOrReplaceChild("tapa_radiador_0", CubeListBuilder.create().texOffs(782, 0).addBox(-17.0F, -19.0F, -5.5F, 34.0F, 1.0F, 11.0F).texOffs(0, 0).addBox(-5.5F, -19.0F, -17.0F, 11.0F, 1.0F, 34.0F), PartPose.offset(-13.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("tapa_radiador_1", CubeListBuilder.create().texOffs(872, 0).addBox(-17.0F, -19.0F, -5.5F, 34.0F, 1.0F, 11.0F).texOffs(90, 0).addBox(-5.5F, -19.0F, -17.0F, 11.0F, 1.0F, 34.0F), PartPose.offsetAndRotation(-13.0F, 0.0F, 0.0F, 0.0F, 0.6283185307179586F, 0.0F));
        g.addOrReplaceChild("farol_caja", CubeListBuilder.create().texOffs(588, 35).addBox(-15.0F, -21.0F, 2.0F, 3.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("farol_0", CubeListBuilder.create().texOffs(934, 35).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(34, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-15.05F, -19.5F, 3.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_1", CubeListBuilder.create().texOffs(958, 35).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(58, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-15.05F, -19.5F, 3.5F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_2", CubeListBuilder.create().texOffs(982, 35).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(82, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-15.05F, -19.5F, 3.5F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_3", CubeListBuilder.create().texOffs(0, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(106, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-15.05F, -19.5F, 3.5F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_vidrio", CubeListBuilder.create().texOffs(226, 35).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-15.47F, -19.5F, 3.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol_t_caja", CubeListBuilder.create().texOffs(600, 35).addBox(14.0F, -15.0F, -6.0F, 1.0F, 3.0F, 3.0F).texOffs(612, 0).addBox(-11.0F, -14.0F, -5.0F, 15.0F, 5.0F, 10.0F).texOffs(394, 35).addBox(-11.0F, -16.0F, -3.0F, 15.0F, 2.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("farol_t_0", CubeListBuilder.create().texOffs(24, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(130, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(15.05F, -13.5F, -4.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("farol_t_1", CubeListBuilder.create().texOffs(48, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(154, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(15.05F, -13.5F, -4.5F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("farol_t_2", CubeListBuilder.create().texOffs(72, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(178, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(15.05F, -13.5F, -4.5F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("farol_t_3", CubeListBuilder.create().texOffs(96, 46).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(202, 35).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(15.05F, -13.5F, -4.5F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("farol_t_vidrio", CubeListBuilder.create().texOffs(330, 35).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(15.47F, -13.5F, -4.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_cantoi_0", CubeListBuilder.create().texOffs(144, 46).addBox(-7.5F, -1.0F, -0.5F, 15.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.5F, -14.309016994374947F, -4.951056516295154F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_1", CubeListBuilder.create().texOffs(176, 46).addBox(-7.5F, -1.0F, -0.5F, 15.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.5F, -14.89680224666742F, -4.760073510670101F, -2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_2", CubeListBuilder.create().texOffs(208, 46).addBox(-7.5F, -1.0F, -0.5F, 15.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.5F, -15.39680224666742F, -4.39680224666742F, -2.356194490192346F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_3", CubeListBuilder.create().texOffs(240, 46).addBox(-7.5F, -1.0F, -0.5F, 15.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.5F, -15.7600735106701F, -3.8968022466674204F, -2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_4", CubeListBuilder.create().texOffs(272, 46).addBox(-7.5F, -1.0F, -0.5F, 15.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.5F, -15.951056516295154F, -3.3090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_0", CubeListBuilder.create().texOffs(304, 46).addBox(-7.5F, -1.0F, -0.5F, 15.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.5F, -14.309016994374947F, 4.951056516295154F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_1", CubeListBuilder.create().texOffs(336, 46).addBox(-7.5F, -1.0F, -0.5F, 15.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.5F, -14.89680224666742F, 4.760073510670101F, 2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_2", CubeListBuilder.create().texOffs(368, 46).addBox(-7.5F, -1.0F, -0.5F, 15.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.5F, -15.39680224666742F, 4.39680224666742F, 2.356194490192346F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_3", CubeListBuilder.create().texOffs(400, 46).addBox(-7.5F, -1.0F, -0.5F, 15.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.5F, -15.7600735106701F, 3.8968022466674204F, 2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_4", CubeListBuilder.create().texOffs(432, 46).addBox(-7.5F, -1.0F, -0.5F, 15.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.5F, -15.951056516295154F, 3.3090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_tapaa", CubeListBuilder.create().texOffs(180, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 20.0F), PartPose.offset(-11.0F, -14.0F, -5.0F));
        g.addOrReplaceChild("capo_tapab", CubeListBuilder.create().texOffs(222, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 20.0F), PartPose.offset(3.0F, -14.0F, -5.0F));
        g.addOrReplaceChild("escape_0", CubeListBuilder.create().texOffs(262, 35).addBox(-6.0F, -21.0F, -2.5F, 12.0F, 5.0F, 5.0F).texOffs(426, 0).addBox(-2.5F, -21.0F, -6.0F, 5.0F, 5.0F, 12.0F), PartPose.offset(-8.0F, 0.0F, 3.0F));
        g.addOrReplaceChild("escape_1", CubeListBuilder.create().texOffs(296, 35).addBox(-6.0F, -21.0F, -2.5F, 12.0F, 5.0F, 5.0F).texOffs(460, 0).addBox(-2.5F, -21.0F, -6.0F, 5.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(-8.0F, 0.0F, 3.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("escape_tapa_0", CubeListBuilder.create().texOffs(520, 35).addBox(-6.0F, -22.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(714, 0).addBox(-2.5F, -22.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offset(-8.0F, 0.0F, 3.0F));
        g.addOrReplaceChild("escape_tapa_1", CubeListBuilder.create().texOffs(554, 35).addBox(-6.0F, -22.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(748, 0).addBox(-2.5F, -22.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-8.0F, 0.0F, 3.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("argollas", CubeListBuilder.create().texOffs(464, 46).addBox(-9.0F, -17.0F, -0.5F, 2.0F, 1.0F, 1.0F).texOffs(470, 46).addBox(0.0F, -17.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("asiento", CubeListBuilder.create().texOffs(500, 35).addBox(8.0F, -12.0F, 2.0F, 4.0F, 3.0F, 4.0F).texOffs(732, 35).addBox(8.0F, -13.0F, 2.0F, 4.0F, 1.0F, 4.0F).texOffs(788, 35).addBox(8.0F, -17.0F, 5.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("freno_0", CubeListBuilder.create().texOffs(962, 0).addBox(-6.0F, -15.0F, -2.5F, 12.0F, 6.0F, 5.0F).texOffs(358, 0).addBox(-2.5F, -15.0F, -6.0F, 5.0F, 6.0F, 12.0F), PartPose.offset(13.0F, 0.0F, -4.5F));
        g.addOrReplaceChild("freno_1", CubeListBuilder.create().texOffs(0, 35).addBox(-6.0F, -15.0F, -2.5F, 12.0F, 6.0F, 5.0F).texOffs(392, 0).addBox(-2.5F, -15.0F, -6.0F, 5.0F, 6.0F, 12.0F), PartPose.offsetAndRotation(13.0F, 0.0F, -4.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("volante_freno", CubeListBuilder.create().texOffs(662, 0).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(13.0F, -15.1F, -4.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("baranda_atras", CubeListBuilder.create().texOffs(494, 0).addBox(14.0F, -12.0F, -7.0F, 1.0F, 3.0F, 14.0F).texOffs(120, 46).addBox(4.0F, -11.0F, -7.0F, 11.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_manometro", CubeListBuilder.create().texOffs(362, 35).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(4.6F, -14.4F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro_aguja", CubeListBuilder.create().texOffs(490, 46).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(4.72F, -14.4F, 0.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(516, 35).addBox(-0.5F, -6.0F, -0.5F, 1.0F, 6.0F, 1.0F).texOffs(890, 35).addBox(-1.0F, -8.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(5.5F, -9.0F, -1.5F));
        g.addOrReplaceChild("cab_palanca_cuadrante", CubeListBuilder.create().texOffs(476, 46).addBox(4.5F, -10.0F, -2.0F, 2.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(878, 35).addBox(8.5F, -13.0F, -4.5F, 3.0F, 1.0F, 3.0F).texOffs(930, 35).addBox(9.5F, -12.0F, -3.5F, 1.0F, 3.0F, 1.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "tapa_radiador_0", 0.0503500508626846F, 1.0F, 0.0503500508626846F);
        escalar(g0, "tapa_radiador_1", 0.0503500508626846F, 1.0F, 0.0503500508626846F);
        escalar(g0, "farol_0", 0.2157727616887107F, 1.0F, 0.2157727616887107F);
        escalar(g0, "farol_1", 0.2157727616887107F, 1.0F, 0.2157727616887107F);
        escalar(g0, "farol_2", 0.2157727616887107F, 1.0F, 0.2157727616887107F);
        escalar(g0, "farol_3", 0.2157727616887107F, 1.0F, 0.2157727616887107F);
        escalar(g0, "farol_vidrio", 0.24444444444444446F, 0.15F, 0.24444444444444446F);
        escalar(g0, "farol_t_0", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "farol_t_1", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "farol_t_2", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "farol_t_3", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "farol_t_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "capo_cantoi_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantoi_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantoi_2", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantoi_3", 1.0F, 1.0F, 0.625737860160923F);
        escalar(g0, "capo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantod_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantod_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantod_2", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantod_3", 1.0F, 1.0F, 0.625737860160923F);
        escalar(g0, "capo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "escape_0", 0.09238795325112868F, 1.0F, 0.09238795325112868F);
        escalar(g0, "escape_1", 0.09238795325112868F, 1.0F, 0.09238795325112868F);
        escalar(g0, "escape_tapa_0", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "escape_tapa_1", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "freno_0", 0.06159196883408579F, 1.0F, 0.06159196883408579F);
        escalar(g0, "freno_1", 0.06159196883408579F, 1.0F, 0.06159196883408579F);
        escalar(g0, "volante_freno", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "cab_manometro", 0.25F, 0.6F, 0.25F);
        escalar(g0, "cab_manometro_aguja", 0.3F, 0.82F, 0.6F);
    }
}
