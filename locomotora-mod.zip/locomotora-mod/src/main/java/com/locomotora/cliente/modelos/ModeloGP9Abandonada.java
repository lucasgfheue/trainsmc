package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "EMD GP9 abandonada" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloGP9Abandonada {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("gp9_abandonada"), "main"),
            LocomotoraMod.id("textures/entity/gp9_abandonada.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -59.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -59.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -59.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -59.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -59.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -59.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -41.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 61.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 61.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 61.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 43.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 61.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 61.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 61.0F, -4.5F, 1.0471975511965976F, "cuerpo")),
            ModeloGP9Abandonada::crearCapa,
            16.0F,
            ModeloGP9Abandonada::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -50.0F, 52.0F)));

    private ModeloGP9Abandonada() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(48, 266).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(876, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(142, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(336, 286).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-59.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(898, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(150, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-59.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(920, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(158, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-59.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(48, 266).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(876, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(142, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(346, 286).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-41.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(898, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(150, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(920, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(158, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(48, 266).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(876, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(142, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(356, 286).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-59.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(898, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(150, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-59.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(920, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(158, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-59.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(48, 266).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(876, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(142, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(366, 286).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-41.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(898, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(150, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(920, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(158, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(160, 244).addBox(-130.0F, -18.0F, 14.0F, 60.0F, 12.0F, 2.0F).texOffs(284, 244).addBox(-130.0F, -18.0F, -16.0F, 60.0F, 12.0F, 2.0F).texOffs(330, 266).addBox(-122.0F, -13.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(350, 266).addBox(-122.0F, -13.0F, -18.0F, 8.0F, 8.0F, 2.0F).texOffs(370, 266).addBox(-86.0F, -13.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(390, 266).addBox(-86.0F, -13.0F, -18.0F, 8.0F, 8.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(48, 266).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(876, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(142, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(376, 286).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(43.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(898, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(150, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(920, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(158, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(48, 266).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(876, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(142, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(386, 286).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(61.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(898, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(150, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(61.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(920, 292).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(158, 266).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(61.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(48, 266).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(876, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(142, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 286).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(43.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(898, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(150, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(920, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(158, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(48, 266).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(876, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(142, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(406, 286).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(61.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(898, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(150, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(61.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(920, 292).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(158, 266).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(61.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(408, 244).addBox(74.0F, -18.0F, 14.0F, 60.0F, 12.0F, 2.0F).texOffs(532, 244).addBox(74.0F, -18.0F, -16.0F, 60.0F, 12.0F, 2.0F).texOffs(410, 266).addBox(82.0F, -13.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(430, 266).addBox(82.0F, -13.0F, -18.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 266).addBox(118.0F, -13.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(470, 266).addBox(118.0F, -13.0F, -18.0F, 8.0F, 8.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(0, 92).addBox(-160.0F, -30.0F, -27.0F, 320.0F, 8.0F, 54.0F).texOffs(0, 154).addBox(-52.0F, -22.0F, -20.0F, 108.0F, 14.0F, 40.0F).texOffs(700, 244).addBox(-170.0F, -22.0F, -3.0F, 10.0F, 6.0F, 6.0F).texOffs(748, 92).addBox(-160.0F, -22.0F, -24.0F, 4.0F, 12.0F, 48.0F).texOffs(732, 244).addBox(160.0F, -22.0F, -3.0F, 10.0F, 6.0F, 6.0F).texOffs(852, 92).addBox(156.0F, -22.0F, -24.0F, 4.0F, 12.0F, 48.0F), PartPose.ZERO);
        g.addOrReplaceChild("barandas", CubeListBuilder.create().texOffs(468, 292).addBox(-152.0F, -50.0F, 25.0F, 28.0F, 2.0F, 2.0F).texOffs(528, 292).addBox(-152.0F, -50.0F, -27.0F, 28.0F, 2.0F, 2.0F).texOffs(416, 286).addBox(-80.0F, -50.0F, 25.0F, 232.0F, 2.0F, 2.0F).texOffs(0, 292).addBox(-80.0F, -50.0F, -27.0F, 232.0F, 2.0F, 2.0F).texOffs(48, 244).addBox(-152.0F, -48.0F, 25.0F, 2.0F, 18.0F, 2.0F).texOffs(56, 244).addBox(-152.0F, -48.0F, -27.0F, 2.0F, 18.0F, 2.0F).texOffs(64, 244).addBox(-126.0F, -48.0F, 25.0F, 2.0F, 18.0F, 2.0F).texOffs(72, 244).addBox(-126.0F, -48.0F, -27.0F, 2.0F, 18.0F, 2.0F).texOffs(80, 244).addBox(-80.0F, -48.0F, 25.0F, 2.0F, 18.0F, 2.0F).texOffs(88, 244).addBox(-80.0F, -48.0F, -27.0F, 2.0F, 18.0F, 2.0F).texOffs(96, 244).addBox(-20.0F, -48.0F, 25.0F, 2.0F, 18.0F, 2.0F).texOffs(104, 244).addBox(-20.0F, -48.0F, -27.0F, 2.0F, 18.0F, 2.0F).texOffs(112, 244).addBox(40.0F, -48.0F, 25.0F, 2.0F, 18.0F, 2.0F).texOffs(120, 244).addBox(40.0F, -48.0F, -27.0F, 2.0F, 18.0F, 2.0F).texOffs(128, 244).addBox(100.0F, -48.0F, 25.0F, 2.0F, 18.0F, 2.0F).texOffs(136, 244).addBox(100.0F, -48.0F, -27.0F, 2.0F, 18.0F, 2.0F).texOffs(144, 244).addBox(150.0F, -48.0F, 25.0F, 2.0F, 18.0F, 2.0F).texOffs(152, 244).addBox(150.0F, -48.0F, -27.0F, 2.0F, 18.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_corto", CubeListBuilder.create().texOffs(732, 0).addBox(-152.0F, -62.0F, -18.0F, 28.0F, 32.0F, 36.0F).texOffs(536, 208).addBox(-152.0F, -66.0F, -14.0F, 28.0F, 4.0F, 28.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_corto_cantoi_0", CubeListBuilder.create().texOffs(476, 300).addBox(-7.0F, -1.0F, -0.5F, 14.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.0F, -31.309016994374943F, -8.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_1", CubeListBuilder.create().texOffs(506, 300).addBox(-7.0F, -1.0F, -0.5F, 14.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.0F, -31.89680224666742F, -8.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_2", CubeListBuilder.create().texOffs(536, 300).addBox(-7.0F, -1.0F, -0.5F, 14.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.0F, -32.39680224666742F, -8.39680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_3", CubeListBuilder.create().texOffs(566, 300).addBox(-7.0F, -1.0F, -0.5F, 14.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.0F, -32.7600735106701F, -7.89680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_4", CubeListBuilder.create().texOffs(596, 300).addBox(-7.0F, -1.0F, -0.5F, 14.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.0F, -32.951056516295154F, -7.3090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_0", CubeListBuilder.create().texOffs(626, 300).addBox(-7.0F, -1.0F, -0.5F, 14.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.0F, -31.309016994374943F, 8.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_1", CubeListBuilder.create().texOffs(656, 300).addBox(-7.0F, -1.0F, -0.5F, 14.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.0F, -31.89680224666742F, 8.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_2", CubeListBuilder.create().texOffs(686, 300).addBox(-7.0F, -1.0F, -0.5F, 14.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.0F, -32.39680224666742F, 8.39680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_3", CubeListBuilder.create().texOffs(716, 300).addBox(-7.0F, -1.0F, -0.5F, 14.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.0F, -32.7600735106701F, 7.89680224666742F, 2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_4", CubeListBuilder.create().texOffs(746, 300).addBox(-7.0F, -1.0F, -0.5F, 14.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-69.0F, -32.951056516295154F, 7.3090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_tapaa", CubeListBuilder.create().texOffs(460, 154).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 36.0F), PartPose.offset(-76.0F, -31.0F, -9.0F));
        g.addOrReplaceChild("capo_corto_tapab", CubeListBuilder.create().texOffs(534, 154).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 36.0F), PartPose.offset(-63.0F, -31.0F, -9.0F));
        g.addOrReplaceChild("faro_a_0", CubeListBuilder.create().texOffs(588, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(764, 244).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -30.5F, -1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_1", CubeListBuilder.create().texOffs(612, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(788, 244).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -30.5F, -1.6F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_2", CubeListBuilder.create().texOffs(636, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(812, 244).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -30.5F, -1.6F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_3", CubeListBuilder.create().texOffs(660, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(836, 244).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -30.5F, -1.6F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_a_vidrio", CubeListBuilder.create().texOffs(166, 266).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-76.82F, -30.5F, -1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_0", CubeListBuilder.create().texOffs(684, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(860, 244).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -30.5F, 1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_1", CubeListBuilder.create().texOffs(708, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(884, 244).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -30.5F, 1.6F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_2", CubeListBuilder.create().texOffs(732, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(908, 244).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -30.5F, 1.6F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_3", CubeListBuilder.create().texOffs(756, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(932, 244).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -30.5F, 1.6F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_b_vidrio", CubeListBuilder.create().texOffs(202, 266).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-76.82F, -30.5F, 1.6F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(0, 0).addBox(-124.0F, -72.0F, -25.0F, 40.0F, 42.0F, 50.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(626, 266).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -34.936752453278835F, -11.975115122850568F, -2.7232683475382204F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(726, 266).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -35.76881284742436F, -9.89368727924366F, -2.7993273122748725F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(826, 266).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -36.44030902741604F, -7.755052376343144F, -2.875386277011519F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(0, 278).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -36.94735828292558F, -5.571576381481981F, -2.951445241748172F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(100, 278).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -37.287028764986445F, -3.355884541161163F, -3.027504206484817F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(200, 278).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -37.45735643846603F, -1.1207883796292368F, -3.103563171221471F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(300, 278).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -37.45735643846603F, 1.1207883796292353F, 3.103563171221471F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(400, 278).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -37.287028764986445F, 3.355884541161161F, 3.027504206484817F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(500, 278).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -36.94735828292558F, 5.5715763814819805F, 2.951445241748172F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(600, 278).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -36.44030902741604F, 7.7550523763431425F, 2.8753862770115184F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(700, 278).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -35.76881284742436F, 9.893687279243657F, 2.799327312274873F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(800, 278).addBox(-22.0F, -2.0F, -3.0F, 44.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(-52.0F, -34.936752453278835F, 11.975115122850568F, 2.7232683475382204F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo", CubeListBuilder.create().texOffs(180, 0).addBox(-84.0F, -62.0F, -20.0F, 236.0F, 32.0F, 40.0F).texOffs(0, 208).addBox(-84.0F, -66.0F, -16.0F, 236.0F, 4.0F, 32.0F).texOffs(274, 266).addBox(-28.0F, -70.0F, -3.0F, 8.0F, 4.0F, 6.0F).texOffs(302, 266).addBox(12.0F, -70.0F, -3.0F, 8.0F, 4.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_largo_cantoi_0", CubeListBuilder.create().texOffs(0, 296).addBox(-59.0F, -1.0F, -0.5F, 118.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(17.0F, -31.309016994374943F, -9.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_1", CubeListBuilder.create().texOffs(238, 296).addBox(-59.0F, -1.0F, -0.5F, 118.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(17.0F, -31.89680224666742F, -9.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_2", CubeListBuilder.create().texOffs(476, 296).addBox(-59.0F, -1.0F, -0.5F, 118.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(17.0F, -32.39680224666742F, -9.39680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_3", CubeListBuilder.create().texOffs(714, 296).addBox(-59.0F, -1.0F, -0.5F, 118.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(17.0F, -32.7600735106701F, -8.89680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_4", CubeListBuilder.create().texOffs(0, 298).addBox(-59.0F, -1.0F, -0.5F, 118.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(17.0F, -32.951056516295154F, -8.309016994374947F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_0", CubeListBuilder.create().texOffs(238, 298).addBox(-59.0F, -1.0F, -0.5F, 118.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(17.0F, -31.309016994374943F, 9.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_1", CubeListBuilder.create().texOffs(476, 298).addBox(-59.0F, -1.0F, -0.5F, 118.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(17.0F, -31.89680224666742F, 9.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_2", CubeListBuilder.create().texOffs(714, 298).addBox(-59.0F, -1.0F, -0.5F, 118.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(17.0F, -32.39680224666742F, 9.39680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_3", CubeListBuilder.create().texOffs(0, 300).addBox(-59.0F, -1.0F, -0.5F, 118.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(17.0F, -32.7600735106701F, 8.89680224666742F, 2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_4", CubeListBuilder.create().texOffs(238, 300).addBox(-59.0F, -1.0F, -0.5F, 118.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(17.0F, -32.951056516295154F, 8.309016994374947F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_tapaa", CubeListBuilder.create().texOffs(296, 154).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 40.0F), PartPose.offset(-42.0F, -31.0F, -10.0F));
        g.addOrReplaceChild("capo_largo_tapab", CubeListBuilder.create().texOffs(378, 154).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 40.0F), PartPose.offset(75.0F, -31.0F, -10.0F));
        g.addOrReplaceChild("ventilador58_0", CubeListBuilder.create().texOffs(956, 278).addBox(-10.0F, -68.0F, -2.0F, 20.0F, 2.0F, 4.0F).texOffs(648, 208).addBox(-2.0F, -68.0F, -10.0F, 4.0F, 2.0F, 20.0F), PartPose.offset(58.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador58_1", CubeListBuilder.create().texOffs(0, 286).addBox(-10.0F, -68.0F, -2.0F, 20.0F, 2.0F, 4.0F).texOffs(696, 208).addBox(-2.0F, -68.0F, -10.0F, 4.0F, 2.0F, 20.0F), PartPose.offsetAndRotation(58.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador58_2", CubeListBuilder.create().texOffs(48, 286).addBox(-10.0F, -68.0F, -2.0F, 20.0F, 2.0F, 4.0F).texOffs(744, 208).addBox(-2.0F, -68.0F, -10.0F, 4.0F, 2.0F, 20.0F), PartPose.offsetAndRotation(58.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador58_3", CubeListBuilder.create().texOffs(96, 286).addBox(-10.0F, -68.0F, -2.0F, 20.0F, 2.0F, 4.0F).texOffs(792, 208).addBox(-2.0F, -68.0F, -10.0F, 4.0F, 2.0F, 20.0F), PartPose.offsetAndRotation(58.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador70_0", CubeListBuilder.create().texOffs(144, 286).addBox(-10.0F, -68.0F, -2.0F, 20.0F, 2.0F, 4.0F).texOffs(840, 208).addBox(-2.0F, -68.0F, -10.0F, 4.0F, 2.0F, 20.0F), PartPose.offset(70.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador70_1", CubeListBuilder.create().texOffs(192, 286).addBox(-10.0F, -68.0F, -2.0F, 20.0F, 2.0F, 4.0F).texOffs(888, 208).addBox(-2.0F, -68.0F, -10.0F, 4.0F, 2.0F, 20.0F), PartPose.offsetAndRotation(70.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador70_2", CubeListBuilder.create().texOffs(240, 286).addBox(-10.0F, -68.0F, -2.0F, 20.0F, 2.0F, 4.0F).texOffs(936, 208).addBox(-2.0F, -68.0F, -10.0F, 4.0F, 2.0F, 20.0F), PartPose.offsetAndRotation(70.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador70_3", CubeListBuilder.create().texOffs(288, 286).addBox(-10.0F, -68.0F, -2.0F, 20.0F, 2.0F, 4.0F).texOffs(0, 244).addBox(-2.0F, -68.0F, -10.0F, 4.0F, 2.0F, 20.0F), PartPose.offsetAndRotation(70.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("faro_t_0", CubeListBuilder.create().texOffs(780, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(956, 244).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.3F, -30.5F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_1", CubeListBuilder.create().texOffs(804, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(980, 244).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.3F, -30.5F, 0.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_2", CubeListBuilder.create().texOffs(828, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(0, 266).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.3F, -30.5F, 0.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_3", CubeListBuilder.create().texOffs(852, 292).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(24, 266).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.3F, -30.5F, 0.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_vidrio", CubeListBuilder.create().texOffs(238, 266).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(76.82F, -30.5F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("pasto0_0", CubeListBuilder.create().texOffs(70, 266).addBox(-4.0F, -10.0F, -0.5F, 8.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-70.0F, -15.0F, 11.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto0_1", CubeListBuilder.create().texOffs(88, 266).addBox(-4.0F, -10.0F, -0.5F, 8.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-70.0F, -15.0F, 11.5F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto1_0", CubeListBuilder.create().texOffs(490, 266).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-30.0F, -15.0F, -11.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto1_1", CubeListBuilder.create().texOffs(508, 266).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-30.0F, -15.0F, -11.5F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto2_0", CubeListBuilder.create().texOffs(656, 244).addBox(-5.0F, -12.0F, -0.5F, 10.0F, 12.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -15.0F, 11.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto2_1", CubeListBuilder.create().texOffs(678, 244).addBox(-5.0F, -12.0F, -0.5F, 10.0F, 12.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -15.0F, 11.5F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto3_0", CubeListBuilder.create().texOffs(598, 266).addBox(-3.0F, -8.0F, -0.5F, 6.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(44.0F, -15.0F, -11.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto3_1", CubeListBuilder.create().texOffs(612, 266).addBox(-3.0F, -8.0F, -0.5F, 6.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(44.0F, -15.0F, -11.5F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto4_0", CubeListBuilder.create().texOffs(106, 266).addBox(-4.0F, -10.0F, -0.5F, 8.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(66.0F, -15.0F, 11.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto4_1", CubeListBuilder.create().texOffs(124, 266).addBox(-4.0F, -10.0F, -0.5F, 8.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(66.0F, -15.0F, 11.5F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto5_0", CubeListBuilder.create().texOffs(900, 278).addBox(-3.0F, -6.0F, -0.5F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(-44.0F, -33.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto5_1", CubeListBuilder.create().texOffs(914, 278).addBox(-3.0F, -6.0F, -0.5F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(-44.0F, -33.0F, 0.0F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto6_0", CubeListBuilder.create().texOffs(526, 266).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(30.0F, -33.0F, -4.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto6_1", CubeListBuilder.create().texOffs(544, 266).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(30.0F, -33.0F, -4.0F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto7_0", CubeListBuilder.create().texOffs(562, 266).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 11.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto7_1", CubeListBuilder.create().texOffs(580, 266).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -9.0F, 11.0F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto8_0", CubeListBuilder.create().texOffs(928, 278).addBox(-3.0F, -6.0F, -0.5F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(-50.0F, -9.0F, -9.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto8_1", CubeListBuilder.create().texOffs(942, 278).addBox(-3.0F, -6.0F, -0.5F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(-50.0F, -9.0F, -9.0F, 0.0F, -0.7853981633974483F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "bogie0", 0.5F, 0.5F, 0.5F);
        escalar(g0, "bogie1", 0.5F, 0.5F, 0.5F);
        escalar(g0, "bastidor", 0.5F, 0.5F, 0.5F);
        escalar(g0, "barandas", 0.5F, 0.5F, 0.5F);
        escalar(g0, "capo_corto", 0.5F, 0.5F, 0.5F);
        escalar(g0, "capo_corto_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_corto_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_corto_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_corto_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_corto_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_corto_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_corto_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_corto_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_corto_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_corto_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_a_0", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_a_1", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_a_2", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_a_3", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_a_vidrio", 0.24444444444444446F, 0.15F, 0.24444444444444446F);
        escalar(g0, "faro_b_0", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_b_1", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_b_2", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_b_3", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_b_vidrio", 0.24444444444444446F, 0.15F, 0.24444444444444446F);
        escalar(g0, "cabina", 0.5F, 0.5F, 0.5F);
        escalar(g0, "cabina_techo_0", 0.5004545454545455F, 0.5F, 0.37719977788453835F);
        escalar(g0, "cabina_techo_1", 0.5004545454545455F, 0.5F, 0.3771997778845375F);
        escalar(g0, "cabina_techo_2", 0.5004545454545455F, 0.5F, 0.3771997778845386F);
        escalar(g0, "cabina_techo_3", 0.5004545454545455F, 0.5F, 0.3771997778845378F);
        escalar(g0, "cabina_techo_4", 0.5004545454545455F, 0.5F, 0.3771997778845381F);
        escalar(g0, "cabina_techo_5", 0.5004545454545455F, 0.5F, 0.3771997778845382F);
        escalar(g0, "cabina_techo_6", 0.5004545454545455F, 0.5F, 0.3771997778845377F);
        escalar(g0, "cabina_techo_7", 0.5004545454545455F, 0.5F, 0.37719977788453835F);
        escalar(g0, "cabina_techo_8", 0.5004545454545455F, 0.5F, 0.3771997778845381F);
        escalar(g0, "cabina_techo_9", 0.5004545454545455F, 0.5F, 0.377199777884538F);
        escalar(g0, "cabina_techo_10", 0.5004545454545455F, 0.5F, 0.37719977788453773F);
        escalar(g0, "cabina_techo_11", 0.5004545454545455F, 0.5F, 0.3771997778845386F);
        escalar(g0, "capo_largo", 0.5F, 0.5F, 0.5F);
        escalar(g0, "capo_largo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_largo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_largo_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_largo_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_largo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_largo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_largo_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_largo_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_largo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_largo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "ventilador58_0", 0.4413533761814537F, 0.5F, 0.4413533761814537F);
        escalar(g0, "ventilador58_1", 0.4413533761814537F, 0.5F, 0.4413533761814537F);
        escalar(g0, "ventilador58_2", 0.4413533761814537F, 0.5F, 0.4413533761814537F);
        escalar(g0, "ventilador58_3", 0.4413533761814537F, 0.5F, 0.4413533761814537F);
        escalar(g0, "ventilador70_0", 0.4413533761814537F, 0.5F, 0.4413533761814537F);
        escalar(g0, "ventilador70_1", 0.4413533761814537F, 0.5F, 0.4413533761814537F);
        escalar(g0, "ventilador70_2", 0.4413533761814537F, 0.5F, 0.4413533761814537F);
        escalar(g0, "ventilador70_3", 0.4413533761814537F, 0.5F, 0.4413533761814537F);
        escalar(g0, "faro_t_0", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t_1", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t_2", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t_3", 0.2157727616887107F, 0.55F, 0.2157727616887107F);
        escalar(g0, "faro_t_vidrio", 0.24444444444444446F, 0.15F, 0.24444444444444446F);
        escalar(g0, "pasto0_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto0_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto1_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto1_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto2_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto2_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto3_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto3_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto4_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto4_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto5_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto5_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto6_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto6_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto7_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto7_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto8_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto8_1", 0.5F, 0.5F, 0.05F);
    }
}
