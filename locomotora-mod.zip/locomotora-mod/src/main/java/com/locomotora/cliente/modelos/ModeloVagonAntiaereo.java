package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Vagón antiaéreo" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonAntiaereo {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_antiaereo"), "main"),
            LocomotoraMod.id("textures/entity/vagon_antiaereo.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -33.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -22.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 22.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 33.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("torreta", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, -18.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon", DatosModelo.CANON, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, -23.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 1.5707963267948966F)),
            ModeloVagonAntiaereo::crearCapa,
            16.0F,
            ModeloVagonAntiaereo::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -28.0F, 28.0F)));

    private ModeloVagonAntiaereo() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(44, 81).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(700, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(62, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(532, 81).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-33.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(718, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(736, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(78, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(44, 81).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(700, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(62, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(542, 81).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-22.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(718, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(736, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(78, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(44, 81).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(700, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(62, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(552, 81).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-33.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(718, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(736, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(78, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(44, 81).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(700, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(62, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(562, 81).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-22.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(718, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(736, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(78, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(572, 81).addBox(-35.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(582, 81).addBox(-24.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(846, 81).addBox(-35.0F, -7.0F, -8.0F, 14.0F, 2.0F, 1.0F).texOffs(292, 90).addBox(-31.0F, -2.0F, -8.0F, 6.0F, 1.0F, 1.0F).texOffs(428, 81).addBox(-30.5F, -5.0F, -8.5F, 5.0F, 3.0F, 2.0F).texOffs(592, 81).addBox(-35.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(602, 81).addBox(-24.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(876, 81).addBox(-35.0F, -7.0F, 7.0F, 14.0F, 2.0F, 1.0F).texOffs(306, 90).addBox(-31.0F, -2.0F, 7.0F, 6.0F, 1.0F, 1.0F).texOffs(442, 81).addBox(-30.5F, -5.0F, 6.5F, 5.0F, 3.0F, 2.0F).texOffs(782, 36).addBox(-30.0F, -7.0F, -7.0F, 4.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_cordonii", CubeListBuilder.create().texOffs(754, 81).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -2.5F, -7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordonid", CubeListBuilder.create().texOffs(762, 81).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.5F, -2.5F, -7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordondi", CubeListBuilder.create().texOffs(770, 81).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -2.5F, 7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie0_cordondd", CubeListBuilder.create().texOffs(778, 81).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.5F, -2.5F, 7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(44, 81).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(700, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(62, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(612, 81).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(22.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(718, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(736, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(78, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(44, 81).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(700, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(62, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(622, 81).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(33.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(718, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(736, 81).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(78, 81).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(44, 81).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(700, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(62, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(632, 81).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(22.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(718, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(736, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(78, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(44, 81).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(700, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(62, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(642, 81).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(33.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(718, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(736, 81).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(78, 81).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(33.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(652, 81).addBox(21.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(662, 81).addBox(32.0F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(906, 81).addBox(21.0F, -7.0F, -8.0F, 14.0F, 2.0F, 1.0F).texOffs(320, 90).addBox(25.0F, -2.0F, -8.0F, 6.0F, 1.0F, 1.0F).texOffs(456, 81).addBox(25.5F, -5.0F, -8.5F, 5.0F, 3.0F, 2.0F).texOffs(672, 81).addBox(21.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(682, 81).addBox(32.0F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(936, 81).addBox(21.0F, -7.0F, 7.0F, 14.0F, 2.0F, 1.0F).texOffs(334, 90).addBox(25.0F, -2.0F, 7.0F, 6.0F, 1.0F, 1.0F).texOffs(470, 81).addBox(25.5F, -5.0F, 6.5F, 5.0F, 3.0F, 2.0F).texOffs(818, 36).addBox(26.0F, -7.0F, -7.0F, 4.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_cordonii", CubeListBuilder.create().texOffs(786, 81).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(23.5F, -2.5F, -7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordonid", CubeListBuilder.create().texOffs(794, 81).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(32.5F, -2.5F, -7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordondi", CubeListBuilder.create().texOffs(802, 81).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(23.5F, -2.5F, 7.5F, 0.0F, 0.0F, -0.982793723247329F));
        g.addOrReplaceChild("bogie1_cordondd", CubeListBuilder.create().texOffs(810, 81).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(32.5F, -2.5F, 7.5F, 0.0F, 0.0F, 0.982793723247329F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(124, 36).addBox(-42.0F, -14.0F, -11.0F, 84.0F, 5.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("faldones", CubeListBuilder.create().texOffs(338, 69).addBox(-38.0F, -14.0F, 12.0F, 76.0F, 10.0F, 1.0F).texOffs(492, 69).addBox(-38.0F, -14.0F, -13.0F, 76.0F, 10.0F, 1.0F).texOffs(0, 90).addBox(-36.0F, -4.0F, 11.0F, 72.0F, 1.0F, 1.0F).texOffs(146, 90).addBox(-36.0F, -4.0F, -12.0F, 72.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("batea", CubeListBuilder.create().texOffs(504, 36).addBox(-34.0F, -15.0F, -12.0F, 68.0F, 1.0F, 24.0F).texOffs(646, 69).addBox(-34.0F, -24.0F, 12.0F, 68.0F, 10.0F, 1.0F).texOffs(784, 69).addBox(-34.0F, -24.0F, -13.0F, 68.0F, 10.0F, 1.0F).texOffs(0, 0).addBox(-35.0F, -24.0F, -13.0F, 1.0F, 10.0F, 26.0F).texOffs(54, 0).addBox(34.0F, -24.0F, -13.0F, 1.0F, 10.0F, 26.0F), PartPose.ZERO);
        g.addOrReplaceChild("frente_0", CubeListBuilder.create().texOffs(336, 36).addBox(-8.0F, -1.0F, -13.0F, 16.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(-38.0F, -17.0F, 0.0F, 3.141592653589793F, 0.0F, -1.1659045405098132F));
        g.addOrReplaceChild("frente_mejillai", CubeListBuilder.create().texOffs(854, 36).addBox(0.0F, -14.0F, -0.5F, 6.0F, 14.0F, 1.0F), PartPose.offset(-41.0F, -10.0F, -12.4F));
        g.addOrReplaceChild("frente_mejillad", CubeListBuilder.create().texOffs(868, 36).addBox(0.0F, -14.0F, -0.5F, 6.0F, 14.0F, 1.0F), PartPose.offset(-41.0F, -10.0F, 12.4F));
        g.addOrReplaceChild("cola_0", CubeListBuilder.create().texOffs(420, 36).addBox(-8.0F, -1.0F, -13.0F, 16.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(38.0F, -17.0F, 0.0F, 0.0F, 0.0F, -1.97568811307998F));
        g.addOrReplaceChild("cola_mejillai", CubeListBuilder.create().texOffs(882, 36).addBox(0.0F, -14.0F, -0.5F, 6.0F, 14.0F, 1.0F), PartPose.offset(35.0F, -10.0F, -12.4F));
        g.addOrReplaceChild("cola_mejillad", CubeListBuilder.create().texOffs(896, 36).addBox(0.0F, -14.0F, -0.5F, 6.0F, 14.0F, 1.0F), PartPose.offset(35.0F, -10.0F, 12.4F));
        g.addOrReplaceChild("cajones", CubeListBuilder.create().texOffs(86, 81).addBox(-30.0F, -19.0F, -12.0F, 6.0F, 4.0F, 4.0F).texOffs(364, 81).addBox(-29.0F, -20.0F, -12.0F, 4.0F, 1.0F, 4.0F).texOffs(106, 81).addBox(-22.0F, -19.0F, -12.0F, 6.0F, 4.0F, 4.0F).texOffs(380, 81).addBox(-21.0F, -20.0F, -12.0F, 4.0F, 1.0F, 4.0F).texOffs(126, 81).addBox(18.0F, -19.0F, -12.0F, 6.0F, 4.0F, 4.0F).texOffs(396, 81).addBox(19.0F, -20.0F, -12.0F, 4.0F, 1.0F, 4.0F).texOffs(146, 81).addBox(26.0F, -19.0F, -12.0F, 6.0F, 4.0F, 4.0F).texOffs(412, 81).addBox(27.0F, -20.0F, -12.0F, 4.0F, 1.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("bolsas", CubeListBuilder.create().texOffs(186, 81).addBox(-32.0F, -18.0F, 8.0F, 5.0F, 3.0F, 4.0F).texOffs(484, 81).addBox(-31.0F, -20.0F, 8.0F, 3.0F, 2.0F, 3.0F).texOffs(204, 81).addBox(-26.0F, -18.0F, 8.0F, 5.0F, 3.0F, 4.0F).texOffs(222, 81).addBox(-20.0F, -18.0F, 8.0F, 5.0F, 3.0F, 4.0F).texOffs(496, 81).addBox(-19.0F, -20.0F, 8.0F, 3.0F, 2.0F, 3.0F).texOffs(240, 81).addBox(-14.0F, -18.0F, 8.0F, 5.0F, 3.0F, 4.0F).texOffs(258, 81).addBox(10.0F, -18.0F, 8.0F, 5.0F, 3.0F, 4.0F).texOffs(276, 81).addBox(16.0F, -18.0F, 8.0F, 5.0F, 3.0F, 4.0F).texOffs(508, 81).addBox(17.0F, -20.0F, 8.0F, 3.0F, 2.0F, 3.0F).texOffs(294, 81).addBox(22.0F, -18.0F, 8.0F, 5.0F, 3.0F, 4.0F).texOffs(312, 81).addBox(28.0F, -18.0F, 8.0F, 5.0F, 3.0F, 4.0F).texOffs(520, 81).addBox(29.0F, -20.0F, 8.0F, 3.0F, 2.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("pedestal", CubeListBuilder.create().texOffs(166, 81).addBox(-3.0F, -18.0F, -2.0F, 6.0F, 3.0F, 4.0F).texOffs(992, 69).addBox(-3.0F, -18.0F, -3.0F, 6.0F, 3.0F, 6.0F, new CubeDeformation(0.0F, 0.04F, 0.0F)).texOffs(24, 81).addBox(-2.0F, -18.0F, -3.0F, 4.0F, 3.0F, 6.0F, new CubeDeformation(0.0F, 0.08F, 0.0F)), PartPose.ZERO);
        g.addOrReplaceChild("luces_cola", CubeListBuilder.create().texOffs(966, 81).addBox(44.0F, -13.0F, -11.0F, 1.0F, 1.0F, 2.0F).texOffs(972, 81).addBox(44.0F, -13.0F, 9.0F, 1.0F, 1.0F, 2.0F).texOffs(20, 36).addBox(-44.0F, -14.0F, -12.0F, 2.0F, 7.0F, 24.0F).texOffs(834, 81).addBox(-46.0F, -12.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(72, 36).addBox(42.0F, -14.0F, -12.0F, 2.0F, 7.0F, 24.0F).texOffs(840, 81).addBox(44.0F, -12.0F, -0.5F, 2.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topefi_0", CubeListBuilder.create().texOffs(804, 0).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(108, 0).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefi_1", CubeListBuilder.create().texOffs(824, 0).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(166, 0).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefi_2", CubeListBuilder.create().texOffs(844, 0).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(224, 0).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_0", CubeListBuilder.create().texOffs(242, 69).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(910, 36).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefic_1", CubeListBuilder.create().texOffs(248, 69).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(932, 36).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_2", CubeListBuilder.create().texOffs(254, 69).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(954, 36).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_3", CubeListBuilder.create().texOffs(260, 69).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(976, 36).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_0", CubeListBuilder.create().texOffs(864, 0).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(282, 0).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefd_1", CubeListBuilder.create().texOffs(884, 0).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(340, 0).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_2", CubeListBuilder.create().texOffs(904, 0).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(398, 0).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_0", CubeListBuilder.create().texOffs(266, 69).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(998, 36).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefdc_1", CubeListBuilder.create().texOffs(272, 69).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(0, 69).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_2", CubeListBuilder.create().texOffs(278, 69).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(22, 69).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_3", CubeListBuilder.create().texOffs(284, 69).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(44, 69).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_0", CubeListBuilder.create().texOffs(924, 0).addBox(44.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(456, 0).addBox(44.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topeti_1", CubeListBuilder.create().texOffs(944, 0).addBox(44.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(514, 0).addBox(44.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_2", CubeListBuilder.create().texOffs(964, 0).addBox(44.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(572, 0).addBox(44.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_0", CubeListBuilder.create().texOffs(290, 69).addBox(47.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(66, 69).addBox(47.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topetic_1", CubeListBuilder.create().texOffs(296, 69).addBox(47.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(88, 69).addBox(47.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_2", CubeListBuilder.create().texOffs(302, 69).addBox(47.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(110, 69).addBox(47.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_3", CubeListBuilder.create().texOffs(308, 69).addBox(47.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(132, 69).addBox(47.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_0", CubeListBuilder.create().texOffs(984, 0).addBox(44.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(630, 0).addBox(44.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetd_1", CubeListBuilder.create().texOffs(1004, 0).addBox(44.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(688, 0).addBox(44.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_2", CubeListBuilder.create().texOffs(0, 36).addBox(44.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(746, 0).addBox(44.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_0", CubeListBuilder.create().texOffs(314, 69).addBox(47.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(154, 69).addBox(47.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetdc_1", CubeListBuilder.create().texOffs(320, 69).addBox(47.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(176, 69).addBox(47.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_2", CubeListBuilder.create().texOffs(326, 69).addBox(47.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(198, 69).addBox(47.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_3", CubeListBuilder.create().texOffs(332, 69).addBox(47.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(220, 69).addBox(47.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("torreta", CubeListBuilder.create().texOffs(922, 69).addBox(-5.0F, -1.0F, -5.0F, 10.0F, 1.0F, 10.0F).texOffs(0, 81).addBox(-3.0F, -4.0F, -3.0F, 6.0F, 3.0F, 6.0F).texOffs(688, 36).addBox(-6.0F, -8.0F, -6.0F, 1.0F, 7.0F, 12.0F).texOffs(348, 81).addBox(-5.0F, -6.0F, -6.0F, 3.0F, 5.0F, 1.0F).texOffs(356, 81).addBox(-5.0F, -6.0F, 5.0F, 3.0F, 5.0F, 1.0F).texOffs(692, 81).addBox(3.0F, -4.0F, -1.0F, 2.0F, 3.0F, 2.0F).texOffs(330, 81).addBox(5.0F, -6.0F, -1.0F, 1.0F, 5.0F, 2.0F), PartPose.offset(0.0F, -18.0F, 0.0F));
        g.addOrReplaceChild("torreta_canon", CubeListBuilder.create().texOffs(962, 69).addBox(-4.0F, -2.0F, -4.0F, 8.0F, 4.0F, 7.0F).texOffs(714, 36).addBox(-3.0F, -0.5F, -20.0F, 1.0F, 1.0F, 16.0F).texOffs(818, 81).addBox(-3.5F, -1.0F, -22.0F, 2.0F, 2.0F, 2.0F).texOffs(748, 36).addBox(2.0F, -0.5F, -20.0F, 1.0F, 1.0F, 16.0F).texOffs(826, 81).addBox(1.5F, -1.0F, -22.0F, 2.0F, 2.0F, 2.0F).texOffs(336, 81).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 2.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -23.0F, 0.0F, 0.0F, 1.5707963267948966F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "bogie0_cordonii", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordonid", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordondi", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie0_cordondd", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordonii", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordonid", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordondi", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "bogie1_cordondd", 0.75F, 0.9013878188659973F, 0.75F);
        escalar(g0, "frente_0", 0.9519716382329886F, 1.0F, 1.0F);
        escalar(g0, "cola_0", 0.9519716382329886F, 1.0F, 1.0F);
        escalar(g0, "topefi_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topeti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
    }
}
