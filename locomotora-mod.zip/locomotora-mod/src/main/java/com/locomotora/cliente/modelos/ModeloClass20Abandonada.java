package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "BR Class 20 abandonada" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloClass20Abandonada {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("class20_abandonada"), "main"),
            LocomotoraMod.id("textures/entity/class20_abandonada.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -62.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -62.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -62.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -42.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -42.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -42.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -62.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -62.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -62.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -42.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -42.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -42.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 24.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 24.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 24.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 24.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 24.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 24.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 44.0F, -5.0F, 1.0471975511965976F, "cuerpo")),
            ModeloClass20Abandonada::crearCapa,
            16.0F,
            ModeloClass20Abandonada::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -52.0F, 34.0F)));

    private ModeloClass20Abandonada() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(334, 211).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(780, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(998, 211).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(756, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-62.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(804, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 211).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(828, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 225).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(334, 211).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(780, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(998, 211).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(766, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-42.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(804, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 211).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(828, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 225).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(334, 211).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(780, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(998, 211).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(776, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-62.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(804, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 211).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(828, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 225).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-62.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(334, 211).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(780, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(998, 211).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(786, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-42.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(804, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 211).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(828, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 225).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(552, 181).addBox(-137.0F, -18.0F, 14.0F, 66.0F, 12.0F, 2.0F).texOffs(688, 181).addBox(-137.0F, -18.0F, -16.0F, 66.0F, 12.0F, 2.0F).texOffs(602, 225).addBox(-128.0F, -14.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(622, 225).addBox(-128.0F, -14.0F, -18.0F, 8.0F, 8.0F, 2.0F).texOffs(642, 225).addBox(-88.0F, -14.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(662, 225).addBox(-88.0F, -14.0F, -18.0F, 8.0F, 8.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(334, 211).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(780, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(998, 211).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(796, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(24.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(804, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 211).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(828, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 225).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(334, 211).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(780, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(998, 211).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(806, 253).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(804, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 211).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(828, 245).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 225).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(334, 211).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(780, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(998, 211).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(816, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(24.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(804, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 211).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(828, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 225).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(334, 211).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(780, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(998, 211).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(826, 253).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(804, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 211).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(828, 245).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 225).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(824, 181).addBox(35.0F, -18.0F, 14.0F, 66.0F, 12.0F, 2.0F).texOffs(0, 211).addBox(35.0F, -18.0F, -16.0F, 66.0F, 12.0F, 2.0F).texOffs(682, 225).addBox(44.0F, -14.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(702, 225).addBox(44.0F, -14.0F, -18.0F, 8.0F, 8.0F, 2.0F).texOffs(722, 225).addBox(84.0F, -14.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(742, 225).addBox(84.0F, -14.0F, -18.0F, 8.0F, 8.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(0, 92).addBox(-160.0F, -26.0F, -25.0F, 280.0F, 6.0F, 50.0F).texOffs(660, 92).addBox(-60.0F, -20.0F, -20.0F, 80.0F, 12.0F, 40.0F).texOffs(716, 0).addBox(-164.0F, -28.0F, -22.0F, 4.0F, 14.0F, 44.0F).texOffs(700, 245).addBox(-168.0F, -24.0F, -1.0F, 4.0F, 6.0F, 2.0F).texOffs(812, 0).addBox(120.0F, -28.0F, -22.0F, 4.0F, 14.0F, 44.0F).texOffs(712, 245).addBox(124.0F, -24.0F, -1.0F, 4.0F, 6.0F, 2.0F).texOffs(0, 278).addBox(-148.0F, -46.0F, 23.0F, 204.0F, 2.0F, 2.0F).texOffs(412, 278).addBox(-148.0F, -46.0F, -25.0F, 204.0F, 2.0F, 2.0F).texOffs(472, 181).addBox(-148.0F, -44.0F, 23.0F, 2.0F, 18.0F, 2.0F).texOffs(480, 181).addBox(-148.0F, -44.0F, -25.0F, 2.0F, 18.0F, 2.0F).texOffs(488, 181).addBox(-92.0F, -44.0F, 23.0F, 2.0F, 18.0F, 2.0F).texOffs(496, 181).addBox(-92.0F, -44.0F, -25.0F, 2.0F, 18.0F, 2.0F).texOffs(504, 181).addBox(-36.0F, -44.0F, 23.0F, 2.0F, 18.0F, 2.0F).texOffs(512, 181).addBox(-36.0F, -44.0F, -25.0F, 2.0F, 18.0F, 2.0F).texOffs(520, 181).addBox(20.0F, -44.0F, 23.0F, 2.0F, 18.0F, 2.0F).texOffs(528, 181).addBox(20.0F, -44.0F, -25.0F, 2.0F, 18.0F, 2.0F).texOffs(536, 181).addBox(54.0F, -44.0F, 23.0F, 2.0F, 18.0F, 2.0F).texOffs(544, 181).addBox(54.0F, -44.0F, -25.0F, 2.0F, 18.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("topefi_0", CubeListBuilder.create().texOffs(580, 148).addBox(-85.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(900, 92).addBox(-85.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefi_1", CubeListBuilder.create().texOffs(600, 148).addBox(-85.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(958, 92).addBox(-85.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefi_2", CubeListBuilder.create().texOffs(620, 148).addBox(-85.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(0, 148).addBox(-85.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_0", CubeListBuilder.create().texOffs(10, 225).addBox(-86.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(646, 211).addBox(-86.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topefic_1", CubeListBuilder.create().texOffs(16, 225).addBox(-86.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(668, 211).addBox(-86.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_2", CubeListBuilder.create().texOffs(22, 225).addBox(-86.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(690, 211).addBox(-86.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_3", CubeListBuilder.create().texOffs(28, 225).addBox(-86.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(712, 211).addBox(-86.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_0", CubeListBuilder.create().texOffs(640, 148).addBox(-85.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(58, 148).addBox(-85.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefd_1", CubeListBuilder.create().texOffs(660, 148).addBox(-85.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(116, 148).addBox(-85.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_2", CubeListBuilder.create().texOffs(680, 148).addBox(-85.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(174, 148).addBox(-85.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_0", CubeListBuilder.create().texOffs(34, 225).addBox(-86.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(734, 211).addBox(-86.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topefdc_1", CubeListBuilder.create().texOffs(40, 225).addBox(-86.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(756, 211).addBox(-86.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_2", CubeListBuilder.create().texOffs(46, 225).addBox(-86.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(778, 211).addBox(-86.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_3", CubeListBuilder.create().texOffs(52, 225).addBox(-86.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(800, 211).addBox(-86.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_0", CubeListBuilder.create().texOffs(700, 148).addBox(62.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(232, 148).addBox(62.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topeti_1", CubeListBuilder.create().texOffs(720, 148).addBox(62.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(290, 148).addBox(62.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_2", CubeListBuilder.create().texOffs(740, 148).addBox(62.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(348, 148).addBox(62.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_0", CubeListBuilder.create().texOffs(58, 225).addBox(65.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(822, 211).addBox(65.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("topetic_1", CubeListBuilder.create().texOffs(64, 225).addBox(65.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(844, 211).addBox(65.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_2", CubeListBuilder.create().texOffs(70, 225).addBox(65.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(866, 211).addBox(65.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_3", CubeListBuilder.create().texOffs(76, 225).addBox(65.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(888, 211).addBox(65.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_0", CubeListBuilder.create().texOffs(760, 148).addBox(62.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(406, 148).addBox(62.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetd_1", CubeListBuilder.create().texOffs(780, 148).addBox(62.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(464, 148).addBox(62.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_2", CubeListBuilder.create().texOffs(800, 148).addBox(62.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(522, 148).addBox(62.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_0", CubeListBuilder.create().texOffs(82, 225).addBox(65.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(910, 211).addBox(65.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("topetdc_1", CubeListBuilder.create().texOffs(88, 225).addBox(65.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(932, 211).addBox(65.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_2", CubeListBuilder.create().texOffs(94, 225).addBox(65.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(954, 211).addBox(65.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_3", CubeListBuilder.create().texOffs(100, 225).addBox(65.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(976, 211).addBox(65.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo", CubeListBuilder.create().texOffs(220, 0).addBox(-152.0F, -52.0F, -18.0F, 212.0F, 26.0F, 36.0F).texOffs(0, 181).addBox(-152.0F, -58.0F, -12.0F, 212.0F, 6.0F, 24.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_cantoi_0", CubeListBuilder.create().texOffs(0, 258).addBox(-106.0F, -2.0F, -1.0F, 212.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.0F, -26.46352549156242F, -8.92658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_1", CubeListBuilder.create().texOffs(428, 258).addBox(-106.0F, -2.0F, -1.0F, 212.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.0F, -27.34520337000113F, -8.640110266005152F, -2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_2", CubeListBuilder.create().texOffs(0, 262).addBox(-106.0F, -2.0F, -1.0F, 212.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.0F, -28.09520337000113F, -8.095203370001132F, -2.3561944901923457F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_3", CubeListBuilder.create().texOffs(428, 262).addBox(-106.0F, -2.0F, -1.0F, 212.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.0F, -28.640110266005152F, -7.345203370001131F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_4", CubeListBuilder.create().texOffs(0, 266).addBox(-106.0F, -2.0F, -1.0F, 212.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.0F, -28.92658477444273F, -6.463525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_0", CubeListBuilder.create().texOffs(428, 266).addBox(-106.0F, -2.0F, -1.0F, 212.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.0F, -26.46352549156242F, 8.92658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_1", CubeListBuilder.create().texOffs(0, 270).addBox(-106.0F, -2.0F, -1.0F, 212.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.0F, -27.34520337000113F, 8.640110266005152F, 2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_2", CubeListBuilder.create().texOffs(428, 270).addBox(-106.0F, -2.0F, -1.0F, 212.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.0F, -28.09520337000113F, 8.095203370001132F, 2.3561944901923457F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_3", CubeListBuilder.create().texOffs(0, 274).addBox(-106.0F, -2.0F, -1.0F, 212.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.0F, -28.640110266005152F, 7.345203370001131F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_4", CubeListBuilder.create().texOffs(428, 274).addBox(-106.0F, -2.0F, -1.0F, 212.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.0F, -28.92658477444273F, 6.463525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_frente_0", CubeListBuilder.create().texOffs(96, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.53252020467512F, -14.833333302768082F, -8.986506067329959F, -1.5961334676284584F, 7.638288719004247e-05F, -1.581916582928432F));
        g.addOrReplaceChild("capo_frente_1", CubeListBuilder.create().texOffs(118, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.57264515206701F, -18.49999990830424F, -8.986850668836667F, -1.5937576200824435F, 0.00011157038529848882F, -1.5815615316894505F));
        g.addOrReplaceChild("capo_frente_2", CubeListBuilder.create().texOffs(140, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.61141618701292F, -22.1666665138404F, -8.987312426129158F, -1.5915473709227856F, 0.00014028320597619207F, -1.5811781706079038F));
        g.addOrReplaceChild("capo_frente_3", CubeListBuilder.create().texOffs(162, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.50681877159971F, -25.749999766550268F, -8.987065082977754F, -1.5963968361709804F, -0.00028759343446016933F, -1.5002669453246995F));
        g.addOrReplaceChild("capo_frente_4", CubeListBuilder.create().texOffs(136, 286).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-76.15029128866993F, -27.5F, -8.888044026590716F, -3.141592653589793F, -0.7270010948763502F, 0.0F));
        g.addOrReplaceChild("capo_frente_5", CubeListBuilder.create().texOffs(148, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.20346046826693F, -14.833333302768082F, -8.93131305056536F, -1.8634718056979125F, -0.0004150793937553274F, -1.5975133826127252F));
        g.addOrReplaceChild("capo_frente_6", CubeListBuilder.create().texOffs(166, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.30067615943645F, -18.49999990830424F, -8.930019443372919F, -1.8449103938264526F, -0.0002902759245099521F, -1.5970935901955265F));
        g.addOrReplaceChild("capo_frente_7", CubeListBuilder.create().texOffs(184, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.39626766841275F, -22.1666665138404F, -8.929159798547737F, -1.8272358153430557F, -0.00017846129379115464F, -1.596628076543317F));
        g.addOrReplaceChild("capo_frente_8", CubeListBuilder.create().texOffs(202, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.1484180977824F, -25.749999766550268F, -8.934384746847007F, -1.8608853645888401F, 0.0031284926595806957F, -1.4036736357193504F));
        g.addOrReplaceChild("capo_frente_9", CubeListBuilder.create().texOffs(592, 286).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-76.77968527994929F, -27.5F, -8.888341887442259F, -3.141592653589793F, -0.6123420545900132F, 0.0F));
        g.addOrReplaceChild("capo_frente_10", CubeListBuilder.create().texOffs(220, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.43271143726805F, -14.833333302768082F, -8.822082931450836F, -2.210385005667194F, -0.001682557836972786F, -1.6041546637995003F));
        g.addOrReplaceChild("capo_frente_11", CubeListBuilder.create().texOffs(238, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.5549593221518F, -18.49999990830424F, -8.816321493553778F, -2.1871204161462345F, -0.0014582966860153886F, -1.6040939648720784F));
        g.addOrReplaceChild("capo_frente_12", CubeListBuilder.create().texOffs(256, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.67693533139237F, -22.1666665138404F, -8.811346280692597F, -2.164600046500231F, -0.0012539535110707369F, -1.6040065322197092F));
        g.addOrReplaceChild("capo_frente_13", CubeListBuilder.create().texOffs(274, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.37107505484522F, -25.749999766550268F, -8.82929112077656F, -2.2190425445365145F, 0.011322104594192119F, -1.3642047538461397F));
        g.addOrReplaceChild("capo_frente_14", CubeListBuilder.create().texOffs(596, 286).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-76.92402937519202F, -27.500083777951886F, -8.726147203743972F, -3.1403975076723984F, -0.4459570930510433F, -0.0008114678900897625F));
        g.addOrReplaceChild("capo_frente_15", CubeListBuilder.create().texOffs(580, 286).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-76.40154672990046F, -27.615461502351287F, -8.558454718896177F, -2.358089450541181F, -0.2867506623065089F, -0.2796030533409755F));
        g.addOrReplaceChild("capo_frente_16", CubeListBuilder.create().texOffs(292, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.60983021514096F, -14.833333302768082F, -8.626481954622834F, -2.5489394839587947F, -0.002450083052513849F, -1.6076620182798984F));
        g.addOrReplaceChild("capo_frente_17", CubeListBuilder.create().texOffs(310, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.74510255637283F, -18.49999990830424F, -8.61797958745334F, -2.523737140917179F, -0.002184410735761909F, -1.6076821021722594F));
        g.addOrReplaceChild("capo_frente_18", CubeListBuilder.create().texOffs(328, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.88042403521524F, -22.1666665138404F, -8.610396476079607F, -2.499313373729905F, -0.0019490119927505537F, -1.607688784176938F));
        g.addOrReplaceChild("capo_frente_19", CubeListBuilder.create().texOffs(346, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.54281935911999F, -25.749999766550268F, -8.636126931502446F, -2.5716151520455406F, 0.016313115619036117F, -1.3432242822255303F));
        g.addOrReplaceChild("capo_frente_20", CubeListBuilder.create().texOffs(600, 286).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.01296849160732F, -27.582305561844834F, -8.520741126851515F, -2.4622037637372594F, -0.28485251969264713F, -0.3206140008346917F));
        g.addOrReplaceChild("capo_frente_21", CubeListBuilder.create().texOffs(60, 286).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-76.4351482562176F, -27.93202812534465F, -8.218066491805372F, -2.3691648682010786F, -0.19990406679736428F, -0.3338372950770474F));
        g.addOrReplaceChild("capo_frente_22", CubeListBuilder.create().texOffs(912, 282).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-77.78704812922516F, -14.833333302768082F, -8.20777090017586F, -2.838626124199539F, 0.00039733342252423444F, -1.6100385929137786F));
        g.addOrReplaceChild("capo_frente_23", CubeListBuilder.create().texOffs(932, 282).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-77.93101033921656F, -18.49999990830424F, -8.20912541130138F, -2.816412417431585F, 0.0003409220007549436F, -1.6100385914080444F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("capo_frente_24", CubeListBuilder.create().texOffs(952, 282).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-78.07497515010384F, -22.1666665138404F, -8.21027397197956F, -2.7945329879877234F, 0.0002850832959293265F, -1.6100400094006213F));
        g.addOrReplaceChild("capo_frente_25", CubeListBuilder.create().texOffs(972, 282).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-77.71503129499375F, -25.749999766550268F, -8.206180828070078F, -2.865054838181316F, -0.0025609709755574496F, -1.3288168363573263F));
        g.addOrReplaceChild("capo_frente_26", CubeListBuilder.create().texOffs(120, 286).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-77.10666875753324F, -27.825628814384228F, -8.017939486077706F, -2.7498359293420647F, -0.1445765302177969F, -0.8065698846793465F));
        g.addOrReplaceChild("capo_frente_27", CubeListBuilder.create().texOffs(70, 286).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-76.47401607258607F, -28.34596117742245F, -7.621952037379485F, -2.6328483093384625F, -0.185717855534318F, -0.40708120012152926F));
        g.addOrReplaceChild("capo_frente_28", CubeListBuilder.create().texOffs(184, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-77.94605620289565F, -14.833333302768082F, -7.350004005419777F, -3.0222131990733248F, 0.008135220392654713F, -1.6124612139134307F));
        g.addOrReplaceChild("capo_frente_29", CubeListBuilder.create().texOffs(206, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-78.09876537642236F, -18.49999990830424F, -7.378958769805505F, -3.0094830504531735F, 0.007644278952357584F, -1.6123792434438324F));
        g.addOrReplaceChild("capo_frente_30", CubeListBuilder.create().texOffs(228, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-78.25119022518268F, -22.1666665138404F, -7.406126785031011F, -2.9964369941583464F, 0.007161578901714895F, -1.6123063957448285F));
        g.addOrReplaceChild("capo_frente_31", CubeListBuilder.create().texOffs(250, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-77.86813188612565F, -25.749999766550268F, -7.326808996773243F, -3.033509360088402F, -0.05105915681189496F, -1.3141794757136773F));
        g.addOrReplaceChild("capo_frente_32", CubeListBuilder.create().texOffs(512, 282).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-77.39705307187995F, -27.623981669404376F, -7.19790644655796F, -3.062531393543039F, 0.03477570195305224F, -1.4493834638537733F));
        g.addOrReplaceChild("capo_frente_33", CubeListBuilder.create().texOffs(472, 282).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-77.19916744784405F, -28.07765694618613F, -7.070649466288071F, -3.008179316934654F, -0.06416816549108954F, -1.0335924353603854F));
        g.addOrReplaceChild("capo_frente_34", CubeListBuilder.create().texOffs(80, 286).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-76.50657838353519F, -28.658467919238916F, -6.798840595274447F, -2.918456653010076F, -0.12370252030532393F, -0.41608499401412147F));
        g.addOrReplaceChild("capo_frente_35", CubeListBuilder.create().texOffs(852, 245).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.0418070158676F, -14.833333302768082F, -6.014161330862261F, -3.105652140408013F, 0.014127985573081836F, -1.614762031968613F));
        g.addOrReplaceChild("capo_frente_36", CubeListBuilder.create().texOffs(876, 245).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.20294888073438F, -18.49999990830424F, -6.065340680573829F, -3.100967707151093F, 0.013759295022684847F, -1.6146696636540212F));
        g.addOrReplaceChild("capo_frente_37", CubeListBuilder.create().texOffs(900, 245).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.36375583286923F, -22.1666665138404F, -6.11511806407593F, -3.0959946019083904F, 0.013364267031933878F, -1.6145797037224F));
        g.addOrReplaceChild("capo_frente_38", CubeListBuilder.create().texOffs(924, 245).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.95960820062206F, -25.749999766550268F, -5.982714535651482F, -3.107936824227552F, -0.08620926802027991F, -1.300721084518637F));
        g.addOrReplaceChild("capo_frente_39", CubeListBuilder.create().texOffs(836, 253).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.4592842848082F, -27.653929381827876F, -5.81722036896915F, -3.1199816167543735F, 0.001354933154663212F, -1.4669283730805207F));
        g.addOrReplaceChild("capo_frente_40", CubeListBuilder.create().texOffs(482, 282).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-77.24415951459939F, -28.177751210719975F, -5.785834093786335F, -3.119957465300802F, -0.02575293650999372F, -1.0760346716355755F));
        g.addOrReplaceChild("capo_frente_41", CubeListBuilder.create().texOffs(448, 282).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.52244508688399F, -28.771502334756857F, -5.657069426037011F, -3.1269916412438814F, -0.09300615387274512F, -0.4034634425101384F));
        g.addOrReplaceChild("capo_frente_42", CubeListBuilder.create().texOffs(948, 245).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.07575993565248F, -14.833333302768082F, -4.391507086526513F, -3.134235704313481F, 0.013474432583392374F, -1.6159192352232472F));
        g.addOrReplaceChild("capo_frente_43", CubeListBuilder.create().texOffs(972, 245).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.24126880429574F, -18.49999990830424F, -4.441061547930419F, -3.133186783429849F, 0.013526138990226382F, -1.615889745607259F));
        g.addOrReplaceChild("capo_frente_44", CubeListBuilder.create().texOffs(996, 245).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.40666679647902F, -22.1666665138404F, -4.490652923399894F, -3.1320471076615175F, 0.013494580123675371F, -1.6158588800431886F));
        g.addOrReplaceChild("capo_frente_45", CubeListBuilder.create().texOffs(0, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.99252002999691F, -25.749999766550268F, -4.36675366323273F, -3.1345463530650837F, -0.08154130534560217F, -1.2941788342622427F));
        g.addOrReplaceChild("capo_frente_46", CubeListBuilder.create().texOffs(846, 253).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.47917698889853F, -27.656672113874645F, -4.221413881521679F, -3.1373234797829093F, -0.00044991305998973814F, -1.4657980881769042F));
        g.addOrReplaceChild("capo_frente_47", CubeListBuilder.create().texOffs(684, 253).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.26012093476194F, -28.187002590050234F, -4.222028566158267F, -3.138370928265456F, -0.004062984094406016F, -1.0740924045398423F));
        g.addOrReplaceChild("capo_frente_48", CubeListBuilder.create().texOffs(600, 253).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.5287952550771F, -28.780330334421624F, -4.1377418714684655F, -3.1409927963312625F, -0.07147556938728376F, -0.3936820344938413F));
        g.addOrReplaceChild("capo_frente_49", CubeListBuilder.create().texOffs(24, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.08267989799415F, -14.833333302768082F, -2.6656754518837094F, -3.1408689508731666F, 0.009173823542782603F, -1.616192476725726F));
        g.addOrReplaceChild("capo_frente_50", CubeListBuilder.create().texOffs(48, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.2492408622451F, -18.49999990830424F, -2.699456534250528F, -3.1407610870016516F, 0.009232720320321738F, -1.6161892001582554F));
        g.addOrReplaceChild("capo_frente_51", CubeListBuilder.create().texOffs(72, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.41578948038288F, -22.1666665138404F, -2.733333778603215F, -3.140642659194061F, 0.009226219879847567F, -1.616185756348484F));
        g.addOrReplaceChild("capo_frente_52", CubeListBuilder.create().texOffs(96, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.99934915979344F, -25.749999766550268F, -2.6486110334102517F, -3.1408954093966748F, -0.055798225753499436F, -1.2926490997631814F));
        g.addOrReplaceChild("capo_frente_53", CubeListBuilder.create().texOffs(856, 253).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.48309426355459F, -27.656672113874645F, -2.5477115283165013F, -3.141182115527172F, -4.334891723013627e-05F, -1.4655956552030869F));
        g.addOrReplaceChild("capo_frente_54", CubeListBuilder.create().texOffs(696, 253).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.26347885554371F, -28.187002590050234F, -2.5441625772300855F, -3.1412851538114244F, -0.005144638977319113F, -1.0729787953019865F));
        g.addOrReplaceChild("capo_frente_55", CubeListBuilder.create().texOffs(614, 253).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.53020343872602F, -28.780330334421624F, -2.4933272457693336F, -3.1415354833165594F, -0.04051873750505499F, -0.39278081475074855F));
        g.addOrReplaceChild("capo_frente_56", CubeListBuilder.create().texOffs(120, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.0833224233287F, -14.833333302768082F, -0.8969529163650569F, -3.1415805025179764F, 0.0033396615935025326F, -1.6162191254917888F));
        g.addOrReplaceChild("capo_frente_57", CubeListBuilder.create().texOffs(144, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.24998722362866F, -18.49999990830424F, -0.9090560200583998F, -3.1415786186438495F, 0.0032551982973005713F, -1.6162190725344374F));
        g.addOrReplaceChild("capo_frente_58", CubeListBuilder.create().texOffs(168, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.41665182369938F, -22.1666665138404F, -0.9209618971363615F, -3.141576563945264F, 0.0016164634561909748F, -1.6162190424976897F));
        g.addOrReplaceChild("capo_frente_59", CubeListBuilder.create().texOffs(192, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.99998918550705F, -25.749999766550268F, -0.8897951928388124F, -3.1415809254231895F, -0.020380696700799426F, -1.292499361571586F));
        g.addOrReplaceChild("capo_frente_60", CubeListBuilder.create().texOffs(866, 253).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.4834476567412F, -27.656672113874645F, -0.8528495668316838F, -3.1415859762089466F, -7.052181839717467e-07F, -1.4655733982936279F));
        g.addOrReplaceChild("capo_frente_61", CubeListBuilder.create().texOffs(708, 253).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.26377834775727F, -28.187002590050234F, -0.8511042922140342F, -3.1415876664396536F, -2.711043459759157e-06F, -1.072875585255168F));
        g.addOrReplaceChild("capo_frente_62", CubeListBuilder.create().texOffs(628, 253).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.53032784039078F, -28.780330334421624F, -0.8365595192573301F, -3.141591740055611F, -0.011015072692540633F, -0.3927001686336701F));
        g.addOrReplaceChild("capo_frente_63", CubeListBuilder.create().texOffs(216, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.0833224233287F, -14.833333302768082F, 0.896828252770276F, 3.1415805042060634F, -0.0033578028777600114F, -1.6162191254917888F));
        g.addOrReplaceChild("capo_frente_64", CubeListBuilder.create().texOffs(240, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.24998722362866F, -18.49999990830424F, 0.9090948598503674F, 3.141578618040924F, -0.003326147721028627F, -1.6162190725344374F));
        g.addOrReplaceChild("capo_frente_65", CubeListBuilder.create().texOffs(264, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.41665182369938F, -22.1666665138404F, 0.9211351797100285F, 3.1415765609179047F, -0.0016176168118838844F, -1.6162190425211398F));
        g.addOrReplaceChild("capo_frente_66", CubeListBuilder.create().texOffs(288, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.99998918550705F, -25.749999766550268F, 0.8897813322217367F, 3.1415809255806955F, 0.020485803125413198F, -1.292499361571586F));
        g.addOrReplaceChild("capo_frente_67", CubeListBuilder.create().texOffs(876, 253).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.4834476567412F, -27.656672113874645F, 0.852684944373151F, 3.141585977497856F, 7.05082046785667e-07F, -1.465573400013459F));
        g.addOrReplaceChild("capo_frente_68", CubeListBuilder.create().texOffs(720, 253).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.26377834775727F, -28.187002590050234F, 0.8511056405472133F, 3.141587666431749F, 2.7110477473083298e-06F, -1.072875586725091F));
        g.addOrReplaceChild("capo_frente_69", CubeListBuilder.create().texOffs(642, 253).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.53032784039078F, -28.780330334421624F, 0.8365911954191931F, 3.1415917400201847F, 0.011097806386045345F, -0.3927001685576461F));
        g.addOrReplaceChild("capo_frente_70", CubeListBuilder.create().texOffs(312, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.08267989799415F, -14.833333302768082F, 2.665675451881924F, 3.1408689508731706F, -0.009173823543441765F, -1.6161924767257243F));
        g.addOrReplaceChild("capo_frente_71", CubeListBuilder.create().texOffs(336, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.2492408622451F, -18.49999990830424F, 2.699456534252022F, 3.1407610870016516F, -0.009232720321449301F, -1.6161892001582554F));
        g.addOrReplaceChild("capo_frente_72", CubeListBuilder.create().texOffs(360, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.41578948038288F, -22.1666665138404F, 2.733333778606745F, 3.1406426591940604F, -0.009226219879829328F, -1.616185756348484F));
        g.addOrReplaceChild("capo_frente_73", CubeListBuilder.create().texOffs(384, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.99934915979344F, -25.749999766550268F, 2.6486110334085513F, 3.1408954093966783F, 0.055798225756346256F, -1.2926490997631832F));
        g.addOrReplaceChild("capo_frente_74", CubeListBuilder.create().texOffs(886, 253).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.4830942635546F, -27.656672113874645F, 2.547711528312293F, 3.141182115527176F, 4.334891722967842e-05F, -1.4655956552030716F));
        g.addOrReplaceChild("capo_frente_75", CubeListBuilder.create().texOffs(732, 253).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.26347885554371F, -28.187002590050234F, 2.5441625772301033F, 3.1412851538114244F, 0.0051446389755137175F, -1.0729787953019871F));
        g.addOrReplaceChild("capo_frente_76", CubeListBuilder.create().texOffs(656, 253).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.53020343872602F, -28.780330334421624F, 2.4933272457700375F, 3.1415354833165594F, 0.04051873750579008F, -0.3927808147507486F));
        g.addOrReplaceChild("capo_frente_77", CubeListBuilder.create().texOffs(408, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.07575993565248F, -14.833333302768082F, 4.391507086524779F, 3.134235704313493F, -0.013474432583201116F, -1.615919235223253F));
        g.addOrReplaceChild("capo_frente_78", CubeListBuilder.create().texOffs(432, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.24126880429576F, -18.49999990830424F, 4.441061547930376F, 3.1331867834298506F, -0.01352613899133901F, -1.6158897456072512F));
        g.addOrReplaceChild("capo_frente_79", CubeListBuilder.create().texOffs(456, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.406666796479F, -22.1666665138404F, 4.490652923402368F, 3.13204710766149F, -0.013494580123933892F, -1.615858880043179F));
        g.addOrReplaceChild("capo_frente_80", CubeListBuilder.create().texOffs(480, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.99252002999691F, -25.749999766550268F, 4.366753663232042F, 3.134546353065075F, 0.08154130534758829F, -1.2941788342622578F));
        g.addOrReplaceChild("capo_frente_81", CubeListBuilder.create().texOffs(896, 253).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.47917698889854F, -27.656672113874645F, 4.221413881518862F, 3.1373234797829226F, 0.0004499130599883456F, -1.4657980881769F));
        g.addOrReplaceChild("capo_frente_82", CubeListBuilder.create().texOffs(744, 253).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.26012093476196F, -28.187002590050234F, 4.222028566157574F, 3.1383709282654606F, 0.00406298409368055F, -1.0740924045398448F));
        g.addOrReplaceChild("capo_frente_83", CubeListBuilder.create().texOffs(670, 253).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.5287952550771F, -28.780330334421624F, 4.137741871468321F, 3.1409927963312634F, 0.07147556938733877F, -0.393682034493839F));
        g.addOrReplaceChild("capo_frente_84", CubeListBuilder.create().texOffs(504, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.04180701586766F, -14.833333302768082F, 6.014161330860809F, 3.1056521404080613F, -0.014127985572176325F, -1.6147620319686498F));
        g.addOrReplaceChild("capo_frente_85", CubeListBuilder.create().texOffs(528, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.20294888073443F, -18.49999990830424F, 6.065340680572565F, 3.100967707151131F, -0.013759295023692601F, -1.6146696636539806F));
        g.addOrReplaceChild("capo_frente_86", CubeListBuilder.create().texOffs(552, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-78.36375583286916F, -22.1666665138404F, 6.115118064077276F, 3.0959946019083335F, -0.01336426703234836F, -1.6145797037223844F));
        g.addOrReplaceChild("capo_frente_87", CubeListBuilder.create().texOffs(576, 253).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.95960820062201F, -25.749999766550268F, 5.982714535651986F, 3.1079368242275396F, 0.08620926802115567F, -1.3007210845186634F));
        g.addOrReplaceChild("capo_frente_88", CubeListBuilder.create().texOffs(906, 253).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-77.45928428480823F, -27.65392938182788F, 5.8172203689682656F, 3.119981616754387F, -0.0013549331546590763F, -1.466928373080529F));
        g.addOrReplaceChild("capo_frente_89", CubeListBuilder.create().texOffs(492, 282).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-77.2441595145994F, -28.177751210719986F, 5.785834093785529F, 3.119957465300822F, 0.025752936510158867F, -1.076034671635589F));
        g.addOrReplaceChild("capo_frente_90", CubeListBuilder.create().texOffs(460, 282).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.522445086884F, -28.77150233475687F, 5.657069426036465F, 3.126991641243903F, 0.09300615387241278F, -0.4034634425101291F));
        g.addOrReplaceChild("capo_frente_91", CubeListBuilder.create().texOffs(272, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-77.9460562028957F, -14.833333302768082F, 7.350004005419116F, 3.0222131990733887F, -0.008135220392263625F, -1.6124612139134558F));
        g.addOrReplaceChild("capo_frente_92", CubeListBuilder.create().texOffs(294, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-78.09876537642242F, -18.49999990830424F, 7.378958769804966F, 3.0094830504532335F, -0.00764427895281523F, -1.6123792434437956F));
        g.addOrReplaceChild("capo_frente_93", CubeListBuilder.create().texOffs(316, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-78.25119022518265F, -22.1666665138404F, 7.406126785031372F, 2.9964369941583127F, -0.007161578901746476F, -1.6123063957448325F));
        g.addOrReplaceChild("capo_frente_94", CubeListBuilder.create().texOffs(338, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-77.86813188612564F, -25.749999766550268F, 7.326808996773453F, 3.033509360088397F, 0.05105915681200951F, -1.3141794757136849F));
        g.addOrReplaceChild("capo_frente_95", CubeListBuilder.create().texOffs(520, 282).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-77.39705307187998F, -27.62398166940439F, 7.197906446557861F, 3.062531393543045F, -0.03477570195304577F, -1.4493834638537522F));
        g.addOrReplaceChild("capo_frente_96", CubeListBuilder.create().texOffs(502, 282).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-77.19916744784406F, -28.077656946186174F, 7.070649466287843F, 3.0081793169346853F, 0.06416816549112589F, -1.0335924353603996F));
        g.addOrReplaceChild("capo_frente_97", CubeListBuilder.create().texOffs(90, 286).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-76.50657838353519F, -28.658467919238962F, 6.798840595274253F, 2.918456653010133F, 0.12370252030528225F, -0.41608499401412397F));
        g.addOrReplaceChild("capo_frente_98", CubeListBuilder.create().texOffs(992, 282).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-77.78704812922517F, -14.833333302768082F, 8.207770900175753F, 2.838626124199571F, -0.00039733342254117754F, -1.6100385929137746F));
        g.addOrReplaceChild("capo_frente_99", CubeListBuilder.create().texOffs(0, 286).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-77.93101033921658F, -18.49999990830424F, 8.209125411301326F, 2.81641241743162F, -0.00034092200076644074F, -1.6100385914080424F));
        g.addOrReplaceChild("capo_frente_100", CubeListBuilder.create().texOffs(20, 286).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-78.07497515010385F, -22.1666665138404F, 8.210273971979479F, 2.7945329879877625F, -0.00028508329590294364F, -1.610040009400629F));
        g.addOrReplaceChild("capo_frente_101", CubeListBuilder.create().texOffs(40, 286).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-77.71503129499378F, -25.749999766550268F, 8.206180828069954F, 2.8650548381813623F, 0.0025609709755531345F, -1.3288168363573207F));
        g.addOrReplaceChild("capo_frente_102", CubeListBuilder.create().texOffs(128, 286).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-77.10666875753326F, -27.825628814384277F, 8.017939486077555F, 2.7498359293421406F, 0.14457653021776423F, -0.8065698846794348F));
        g.addOrReplaceChild("capo_frente_103", CubeListBuilder.create().texOffs(100, 286).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-76.47401607258607F, -28.34596117742254F, 7.621952037379315F, 2.632848309338523F, 0.18571785553433043F, -0.4070812001215566F));
        g.addOrReplaceChild("capo_frente_104", CubeListBuilder.create().texOffs(364, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.60983021514095F, -14.833333302768082F, 8.626481954622829F, 2.5489394839587964F, 0.002450083052509734F, -1.6076620182798984F));
        g.addOrReplaceChild("capo_frente_105", CubeListBuilder.create().texOffs(382, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.74510255637284F, -18.49999990830424F, 8.617979587453334F, 2.523737140917182F, 0.002184410735766024F, -1.6076821021722614F));
        g.addOrReplaceChild("capo_frente_106", CubeListBuilder.create().texOffs(400, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.88042403521524F, -22.1666665138404F, 8.610396476079607F, 2.4993133737298887F, 0.0019490119927432921F, -1.6076887841769323F));
        g.addOrReplaceChild("capo_frente_107", CubeListBuilder.create().texOffs(418, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.54281935911997F, -25.749999766550268F, 8.636126931502458F, 2.571615152045491F, -0.01631311561903539F, -1.3432242822255342F));
        g.addOrReplaceChild("capo_frente_108", CubeListBuilder.create().texOffs(604, 286).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.01296849160732F, -27.582305561844855F, 8.520741126851492F, 2.4622037637372354F, 0.2848525196926998F, -0.32061400083473746F));
        g.addOrReplaceChild("capo_frente_109", CubeListBuilder.create().texOffs(110, 286).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-76.43514825621762F, -27.932028125344765F, 8.21806649180525F, 2.3691648682011386F, 0.1999040667974029F, -0.33383729507711574F));
        g.addOrReplaceChild("capo_frente_110", CubeListBuilder.create().texOffs(436, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.43271143726805F, -14.833333302768082F, 8.822082931450833F, 2.210385005667203F, 0.0016825578369715757F, -1.6041546637995003F));
        g.addOrReplaceChild("capo_frente_111", CubeListBuilder.create().texOffs(454, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.5549593221518F, -18.49999990830424F, 8.816321493553778F, 2.1871204161462314F, 0.0014582966860146622F, -1.6040939648720784F));
        g.addOrReplaceChild("capo_frente_112", CubeListBuilder.create().texOffs(472, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.67693533139236F, -22.1666665138404F, 8.811346280692604F, 2.1646000465002166F, 0.0012539535110671057F, -1.6040065322197015F));
        g.addOrReplaceChild("capo_frente_113", CubeListBuilder.create().texOffs(490, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.3710750548452F, -25.749999766550268F, 8.829291120776569F, 2.219042544536501F, -0.011322104594188163F, -1.3642047538461475F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("capo_frente_114", CubeListBuilder.create().texOffs(608, 286).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-76.92402937519202F, -27.500083777951886F, 8.726147203743972F, 3.1403975076723984F, 0.4459570930510433F, -0.0008114678900897625F));
        g.addOrReplaceChild("capo_frente_115", CubeListBuilder.create().texOffs(586, 286).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-76.40154672990046F, -27.61546150235134F, 8.558454718896133F, 2.358089450541106F, 0.2867506623065967F, -0.279603053341092F));
        g.addOrReplaceChild("capo_frente_116", CubeListBuilder.create().texOffs(508, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.20346046826693F, -14.833333302768082F, 8.931313050565358F, 1.8634718056979243F, 0.0004150793937553274F, -1.5975133826127252F));
        g.addOrReplaceChild("capo_frente_117", CubeListBuilder.create().texOffs(526, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.30067615943646F, -18.49999990830424F, 8.930019443372919F, 1.8449103938264553F, 0.00029027592450970994F, -1.5970935901955265F));
        g.addOrReplaceChild("capo_frente_118", CubeListBuilder.create().texOffs(544, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.39626766841273F, -22.1666665138404F, 8.92915979854774F, 1.8272358153430357F, 0.0001784612937887332F, -1.5966280765433032F));
        g.addOrReplaceChild("capo_frente_119", CubeListBuilder.create().texOffs(562, 286).addBox(-4.0F, -1.0F, -0.5F, 8.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-77.14841809778237F, -25.749999766550268F, 8.934384746847012F, 1.8608853645888122F, -0.0031284926595782007F, -1.4036736357193642F));
        g.addOrReplaceChild("capo_frente_120", CubeListBuilder.create().texOffs(612, 286).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-76.77968527994932F, -27.5F, 8.888341887442248F, 3.141592653589793F, 0.6123420545900766F, 0.0F));
        g.addOrReplaceChild("capo_frente_121", CubeListBuilder.create().texOffs(360, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.53252020467512F, -14.833333302768082F, 8.986506067329959F, 1.5961334676284575F, -7.638288718980026e-05F, -1.581916582928432F));
        g.addOrReplaceChild("capo_frente_122", CubeListBuilder.create().texOffs(382, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.572645152067F, -18.49999990830424F, 8.986850668836667F, 1.5937576200824435F, -0.00011157038529848882F, -1.5815615316894505F));
        g.addOrReplaceChild("capo_frente_123", CubeListBuilder.create().texOffs(404, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.6114161870129F, -22.1666665138404F, 8.987312426129161F, 1.5915473709227832F, -0.00014028320597716097F, -1.5811781706078942F));
        g.addOrReplaceChild("capo_frente_124", CubeListBuilder.create().texOffs(426, 282).addBox(-4.0F, -1.0F, -1.5F, 8.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.5068187715997F, -25.749999766550268F, 8.987065082977754F, 1.596396836170978F, 0.0002875934344611821F, -1.5002669453247097F));
        g.addOrReplaceChild("capo_frente_125", CubeListBuilder.create().texOffs(142, 286).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-76.15029128866995F, -27.5F, 8.888044026590705F, 3.141592653589793F, 0.7270010948763042F, 0.0F));
        g.addOrReplaceChild("faro5_0", CubeListBuilder.create().texOffs(528, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(146, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-77.86561291954665F, -15.984505180438338F, -5.53613769724625F, -0.021974460017439558F, 0.0F, 1.5257947377167282F));
        g.addOrReplaceChild("faro5_1", CubeListBuilder.create().texOffs(552, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(170, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-77.86561291954665F, -15.984505180438338F, -5.53613769724625F, -0.02378432737389255F, 0.3925990807148297F, 1.516693602160553F));
        g.addOrReplaceChild("faro5_2", CubeListBuilder.create().texOffs(576, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(194, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-77.86561291954665F, -15.984505180438338F, -5.53613769724625F, -0.031071579259901467F, 0.7851567638007214F, 1.5038255812582138F));
        g.addOrReplaceChild("faro5_3", CubeListBuilder.create().texOffs(600, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(218, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-77.86561291954665F, -15.984505180438338F, -5.53613769724625F, -0.05736825746363669F, 1.1775147940558892F, 1.4727976410531136F));
        g.addOrReplaceChild("faro5_vidrio", CubeListBuilder.create().texOffs(762, 225).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-78.28508641386914F, -15.96561545342949F, -5.545366227704379F, -0.021974460017439558F, 0.0F, 1.5257947377167282F));
        g.addOrReplaceChild("faro15_0", CubeListBuilder.create().texOffs(624, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(242, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-77.86561291954665F, -15.984505180438338F, 5.536137697246249F, 0.021974460017439558F, 0.0F, 1.5257947377167282F));
        g.addOrReplaceChild("faro15_1", CubeListBuilder.create().texOffs(648, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(266, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-77.86561291954665F, -15.984505180438338F, 5.536137697246249F, 0.02378432737389255F, 0.3925990807148297F, 1.5348958732729034F));
        g.addOrReplaceChild("faro15_2", CubeListBuilder.create().texOffs(672, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(290, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-77.86561291954665F, -15.984505180438338F, 5.536137697246249F, 0.031071579259901467F, 0.7851567638007214F, 1.5477638941752427F));
        g.addOrReplaceChild("faro15_3", CubeListBuilder.create().texOffs(696, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(314, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-77.86561291954665F, -15.984505180438338F, 5.536137697246249F, 0.05736825746363669F, 1.1775147940558892F, 1.578791834380343F));
        g.addOrReplaceChild("faro15_vidrio", CubeListBuilder.create().texOffs(794, 225).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-78.28508641386914F, -15.96561545342949F, 5.5453662277043785F, 0.021974460017439558F, 0.0F, 1.5257947377167282F));
        g.addOrReplaceChild("faro_alto_0", CubeListBuilder.create().texOffs(824, 278).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(358, 211).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-77.97509107371367F, -24.927167505842085F, 0.0F, 0.0F, 0.0F, 1.849095985800209F));
        g.addOrReplaceChild("faro_alto_1", CubeListBuilder.create().texOffs(848, 278).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(382, 211).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-77.97509107371367F, -24.927167505842085F, 0.0F, 0.0F, 0.39269908169872414F, 1.849095985800209F));
        g.addOrReplaceChild("faro_alto_2", CubeListBuilder.create().texOffs(872, 278).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(406, 211).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-77.97509107371367F, -24.927167505842085F, 0.0F, 0.0F, 0.7853981633974482F, 1.8490959858002087F));
        g.addOrReplaceChild("faro_alto_3", CubeListBuilder.create().texOffs(896, 278).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(430, 211).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-77.97509107371367F, -24.927167505842085F, 0.0F, 0.0F, 1.1780972450961724F, 1.849095985800209F));
        g.addOrReplaceChild("faro_alto_vidrio", CubeListBuilder.create().texOffs(106, 225).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-78.47508352648687F, -25.070022492348823F, 0.0F, 0.0F, 0.0F, 1.849095985800209F));
        g.addOrReplaceChild("ventilador60_0", CubeListBuilder.create().texOffs(920, 278).addBox(-5.0F, -30.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(454, 211).addBox(-1.0F, -30.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offset(-60.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador60_1", CubeListBuilder.create().texOffs(944, 278).addBox(-5.0F, -30.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(478, 211).addBox(-1.0F, -30.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-60.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador60_2", CubeListBuilder.create().texOffs(968, 278).addBox(-5.0F, -30.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(502, 211).addBox(-1.0F, -30.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-60.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador60_3", CubeListBuilder.create().texOffs(992, 278).addBox(-5.0F, -30.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(526, 211).addBox(-1.0F, -30.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-60.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador48_0", CubeListBuilder.create().texOffs(0, 282).addBox(-5.0F, -30.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(550, 211).addBox(-1.0F, -30.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offset(-48.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador48_1", CubeListBuilder.create().texOffs(24, 282).addBox(-5.0F, -30.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(574, 211).addBox(-1.0F, -30.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-48.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador48_2", CubeListBuilder.create().texOffs(48, 282).addBox(-5.0F, -30.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(598, 211).addBox(-1.0F, -30.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-48.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador48_3", CubeListBuilder.create().texOffs(72, 282).addBox(-5.0F, -30.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(622, 211).addBox(-1.0F, -30.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-48.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("escape_0", CubeListBuilder.create().texOffs(136, 211).addBox(-13.0F, -33.0F, -3.5F, 26.0F, 5.0F, 7.0F).texOffs(820, 148).addBox(-3.5F, -33.0F, -13.0F, 7.0F, 5.0F, 26.0F), PartPose.offset(-30.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("escape_1", CubeListBuilder.create().texOffs(202, 211).addBox(-13.0F, -33.0F, -3.5F, 26.0F, 5.0F, 7.0F).texOffs(886, 148).addBox(-3.5F, -33.0F, -13.0F, 7.0F, 5.0F, 26.0F), PartPose.offsetAndRotation(-30.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("escape_2", CubeListBuilder.create().texOffs(268, 211).addBox(-13.0F, -33.0F, -3.5F, 26.0F, 5.0F, 7.0F).texOffs(952, 148).addBox(-3.5F, -33.0F, -13.0F, 7.0F, 5.0F, 26.0F), PartPose.offsetAndRotation(-30.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(0, 0).addBox(60.0F, -68.0F, -25.0F, 60.0F, 42.0F, 50.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(0, 237).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -32.38715313722936F, -11.97734774490889F, -2.7154933423630077F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(140, 237).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -33.234993183899554F, -9.899184611017825F, -2.792965944404239F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(280, 237).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -33.91945043392799F, -7.761636242282005F, -2.8704385464454725F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(420, 237).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -34.436418826448914F, -5.577525797058143F, -2.947911148486708F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(560, 237).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -34.78279706669882F, -3.3599557597238032F, -3.025383750527942F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(700, 237).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -34.95650723069198F, -1.1222293388387303F, -3.102856352569176F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(840, 237).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -34.95650723069198F, 1.1222293388387286F, 3.102856352569176F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(0, 245).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -34.78279706669882F, 3.3599557597238006F, 3.025383750527942F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(140, 245).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -34.436418826448914F, 5.577525797058142F, 2.947911148486708F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(280, 245).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -33.91945043392799F, 7.761636242282004F, 2.8704385464454725F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(420, 245).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -33.234993183899554F, 9.899184611017823F, 2.792965944404239F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(560, 245).addBox(-32.0F, -2.0F, -3.0F, 64.0F, 2.0F, 6.0F), PartPose.offsetAndRotation(45.0F, -32.38715313722936F, 11.97734774490889F, 2.7154933423630077F, 0.0F, 0.0F));
        g.addOrReplaceChild("faro_t4_0", CubeListBuilder.create().texOffs(720, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(338, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.1F, -16.0F, -6.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t4_1", CubeListBuilder.create().texOffs(744, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(362, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.1F, -16.0F, -6.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t4_2", CubeListBuilder.create().texOffs(768, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(386, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.1F, -16.0F, -6.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t4_3", CubeListBuilder.create().texOffs(792, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(410, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.1F, -16.0F, -6.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t4_vidrio", CubeListBuilder.create().texOffs(826, 225).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(60.52F, -16.0F, -6.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t16_0", CubeListBuilder.create().texOffs(816, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(434, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.1F, -16.0F, 6.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t16_1", CubeListBuilder.create().texOffs(840, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(458, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.1F, -16.0F, 6.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t16_2", CubeListBuilder.create().texOffs(864, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(482, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.1F, -16.0F, 6.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t16_3", CubeListBuilder.create().texOffs(888, 282).addBox(-5.0F, -0.6F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(506, 225).addBox(-1.0F, -0.6F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(60.1F, -16.0F, 6.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t16_vidrio", CubeListBuilder.create().texOffs(858, 225).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(60.52F, -16.0F, 6.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("pasto0_0", CubeListBuilder.create().texOffs(890, 225).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-72.0F, -13.0F, 10.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto0_1", CubeListBuilder.create().texOffs(908, 225).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-72.0F, -13.0F, 10.5F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto1_0", CubeListBuilder.create().texOffs(530, 225).addBox(-4.0F, -10.0F, -0.5F, 8.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -13.0F, -10.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto1_1", CubeListBuilder.create().texOffs(548, 225).addBox(-4.0F, -10.0F, -0.5F, 8.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -13.0F, -10.5F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto2_0", CubeListBuilder.create().texOffs(926, 225).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(4.0F, -13.0F, 10.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto2_1", CubeListBuilder.create().texOffs(944, 225).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(4.0F, -13.0F, 10.5F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto3_0", CubeListBuilder.create().texOffs(566, 225).addBox(-4.0F, -10.0F, -0.5F, 8.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -13.0F, -10.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto3_1", CubeListBuilder.create().texOffs(584, 225).addBox(-4.0F, -10.0F, -0.5F, 8.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -13.0F, -10.5F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto4_0", CubeListBuilder.create().texOffs(724, 245).addBox(-3.0F, -6.0F, -0.5F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(-10.0F, -29.0F, -3.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto4_1", CubeListBuilder.create().texOffs(738, 245).addBox(-3.0F, -6.0F, -0.5F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(-10.0F, -29.0F, -3.0F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto5_0", CubeListBuilder.create().texOffs(752, 245).addBox(-3.0F, -6.0F, -0.5F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(46.0F, -34.0F, 2.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto5_1", CubeListBuilder.create().texOffs(766, 245).addBox(-3.0F, -6.0F, -0.5F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(46.0F, -34.0F, 2.0F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto6_0", CubeListBuilder.create().texOffs(962, 225).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -9.0F, 10.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto6_1", CubeListBuilder.create().texOffs(980, 225).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -9.0F, 10.0F, 0.0F, -0.7853981633974483F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "bogie0", 0.5F, 0.5F, 0.5F);
        escalar(g0, "bogie1", 0.5F, 0.5F, 0.5F);
        escalar(g0, "bastidor", 0.5F, 0.5F, 0.5F);
        escalar(g0, "topefi_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topeti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "capo", 0.5F, 0.5F, 0.5F);
        escalar(g0, "capo_cantoi_0", 0.5F, 0.5F, 0.4693033951206931F);
        escalar(g0, "capo_cantoi_1", 0.5F, 0.5F, 0.4693033951206923F);
        escalar(g0, "capo_cantoi_2", 0.5F, 0.5F, 0.46930339512069313F);
        escalar(g0, "capo_cantoi_3", 0.5F, 0.5F, 0.4693033951206923F);
        escalar(g0, "capo_cantoi_4", 0.5F, 0.5F, 0.46930339512069263F);
        escalar(g0, "capo_cantod_0", 0.5F, 0.5F, 0.4693033951206931F);
        escalar(g0, "capo_cantod_1", 0.5F, 0.5F, 0.4693033951206923F);
        escalar(g0, "capo_cantod_2", 0.5F, 0.5F, 0.46930339512069313F);
        escalar(g0, "capo_cantod_3", 0.5F, 0.5F, 0.4693033951206923F);
        escalar(g0, "capo_cantod_4", 0.5F, 0.5F, 0.46930339512069263F);
        escalar(g0, "capo_frente_0", 0.4646400026607552F, 1.0F, 0.37178889334612175F);
        escalar(g0, "capo_frente_1", 0.46463644454422165F, 1.0F, 0.398525076308258F);
        escalar(g0, "capo_frente_2", 0.4646327324788036F, 1.0F, 0.4243590921953635F);
        escalar(g0, "capo_frente_3", 0.4459227333183412F, 1.0F, 0.3546599736957439F);
        escalar(g0, "capo_frente_4", 0.39705508423248337F, 1.0F, 0.27516632495652416F);
        escalar(g0, "capo_frente_5", 0.4647516661212923F, 1.0F, 0.3391580253960955F);
        escalar(g0, "capo_frente_6", 0.46474714411026985F, 1.0F, 0.3728483831166279F);
        escalar(g0, "capo_frente_7", 0.4647422342750824F, 1.0F, 0.40862274005614146F);
        escalar(g0, "capo_frente_8", 0.45009425335130904F, 1.0F, 0.3314774714485418F);
        escalar(g0, "capo_frente_9", 0.25213840951704947F, 1.0F, 0.2787998991896875F);
        escalar(g0, "capo_frente_10", 0.46484028965724167F, 1.0F, 0.2763713440279171F);
        escalar(g0, "capo_frente_11", 0.4648392557893838F, 1.0F, 0.29234765564641274F);
        escalar(g0, "capo_frente_12", 0.46483786419652806F, 1.0F, 0.3087129169574595F);
        escalar(g0, "capo_frente_13", 0.4533256994011658F, 1.0F, 0.2695553827557694F);
        escalar(g0, "capo_frente_14", 0.30984484425076414F, 1.0F, 0.2687660887368491F);
        escalar(g0, "capo_frente_15", 0.47305680801407324F, 1.0F, 0.4120871249260504F);
        escalar(g0, "capo_frente_16", 0.4648967501439601F, 1.0F, 0.3588872585626127F);
        escalar(g0, "capo_frente_17", 0.46489681494417273F, 1.0F, 0.36495254836171664F);
        escalar(g0, "capo_frente_18", 0.4648967157226968F, 1.0F, 0.3713045459709336F);
        escalar(g0, "capo_frente_19", 0.455403056371275F, 1.0F, 0.35669542448329633F);
        escalar(g0, "capo_frente_20", 0.42232550719340317F, 1.0F, 0.34812622754999056F);
        escalar(g0, "capo_frente_21", 0.39703359485611206F, 1.0F, 0.327404743023884F);
        escalar(g0, "capo_frente_22", 0.4649386880746084F, 1.0F, 0.329549887706308F);
        escalar(g0, "capo_frente_23", 0.4649382611561028F, 1.0F, 0.3210844135647841F);
        escalar(g0, "capo_frente_24", 0.4649379487238676F, 1.0F, 0.3137794122190219F);
        escalar(g0, "capo_frente_25", 0.45697349629374506F, 1.0F, 0.34048885649483934F);
        escalar(g0, "capo_frente_26", 0.3212261682141234F, 1.0F, 0.4575120555745785F);
        escalar(g0, "capo_frente_27", 0.4357023253995042F, 1.0F, 0.4564429854888781F);
        escalar(g0, "capo_frente_28", 0.465002396601783F, 1.0F, 0.3974729955572218F);
        escalar(g0, "capo_frente_29", 0.4649987683779193F, 1.0F, 0.38632657039486257F);
        escalar(g0, "capo_frente_30", 0.46499540499158F, 1.0F, 0.37553907868143893F);
        escalar(g0, "capo_frente_31", 0.45935883425574753F, 1.0F, 0.40417234626368176F);
        escalar(g0, "capo_frente_32", 0.31301255139601386F, 1.0F, 0.4295593784602423F);
        escalar(g0, "capo_frente_33", 0.417991627153963F, 1.0F, 0.3946137675843158F);
        escalar(g0, "capo_frente_34", 0.41491688091014284F, 1.0F, 0.48396490712789797F);
        escalar(g0, "capo_frente_35", 0.4650729522283029F, 1.0F, 0.39710825694964563F);
        escalar(g0, "capo_frente_36", 0.4650688887980215F, 1.0F, 0.39480699992449136F);
        escalar(g0, "capo_frente_37", 0.4650647970502517F, 1.0F, 0.39208784751009307F);
        escalar(g0, "capo_frente_38", 0.4619123059637961F, 1.0F, 0.39619233860840725F);
        escalar(g0, "capo_frente_39", 0.36125847886142665F, 1.0F, 0.3947327743484596F);
        escalar(g0, "capo_frente_40", 0.4463769449462732F, 1.0F, 0.5020535851358339F);
        escalar(g0, "capo_frente_41", 0.40220366589355083F, 1.0F, 0.48012913142305974F);
        escalar(g0, "capo_frente_42", 0.4650927534263739F, 1.0F, 0.43948030648173647F);
        escalar(g0, "capo_frente_43", 0.4650923208210012F, 1.0F, 0.4426649697531667F);
        escalar(g0, "capo_frente_44", 0.46509139316350595F, 1.0F, 0.44556106407842444F);
        escalar(g0, "capo_frente_45", 0.46258216959342957F, 1.0F, 0.4370671775143773F);
        escalar(g0, "capo_frente_46", 0.36518291505225453F, 1.0F, 0.42826649914178877F);
        escalar(g0, "capo_frente_47", 0.45003108748397447F, 1.0F, 0.43045955332652064F);
        escalar(g0, "capo_frente_48", 0.4023712229305201F, 1.0F, 0.4246200335478469F);
        escalar(g0, "capo_frente_49", 0.46507671464242695F, 1.0F, 0.44844725633749233F);
        escalar(g0, "capo_frente_50", 0.4650771009723037F, 1.0F, 0.45315298053402675F);
        escalar(g0, "capo_frente_51", 0.465077135956438F, 1.0F, 0.4581185532150767F);
        escalar(g0, "capo_frente_52", 0.4619970977314064F, 1.0F, 0.447017387312517F);
        escalar(g0, "capo_frente_53", 0.36509150556944603F, 1.0F, 0.43358854443904193F);
        escalar(g0, "capo_frente_54", 0.4502969830231447F, 1.0F, 0.4334763487466684F);
        escalar(g0, "capo_frente_55", 0.40078470528029997F, 1.0F, 0.42258827445102704F);
        escalar(g0, "capo_frente_56", 0.4650617012698234F, 1.0F, 0.4609141264189655F);
        escalar(g0, "capo_frente_57", 0.4650615238462179F, 1.0F, 0.4670474299698835F);
        escalar(g0, "capo_frente_58", 0.4650613505157819F, 1.0F, 0.47306758991403464F);
        escalar(g0, "capo_frente_59", 0.46144645314108645F, 1.0F, 0.45739066615036483F);
        escalar(g0, "capo_frente_60", 0.3650878753352685F, 1.0F, 0.4388424721973458F);
        escalar(g0, "capo_frente_61", 0.450306858219534F, 1.0F, 0.43805282028065995F);
        escalar(g0, "capo_frente_62", 0.399535711656601F, 1.0F, 0.430795597711741F);
        escalar(g0, "capo_frente_63", 0.4650617012698245F, 1.0F, 0.46097645821540445F);
        escalar(g0, "capo_frente_64", 0.4650615238462197F, 1.0F, 0.46702801007466394F);
        escalar(g0, "capo_frente_65", 0.4650613505157821F, 1.0F, 0.47298094862917756F);
        escalar(g0, "capo_frente_66", 0.46144645314111654F, 1.0F, 0.45739759645806083F);
        escalar(g0, "capo_frente_67", 0.365087875335275F, 1.0F, 0.4389247834242933F);
        escalar(g0, "capo_frente_68", 0.45030685821952665F, 1.0F, 0.4380521461140774F);
        escalar(g0, "capo_frente_69", 0.3995357116566141F, 1.0F, 0.43077975963121623F);
        escalar(g0, "capo_frente_70", 0.4650767146424296F, 1.0F, 0.44844725633754673F);
        escalar(g0, "capo_frente_71", 0.4650771009723084F, 1.0F, 0.45315298053401243F);
        escalar(g0, "capo_frente_72", 0.46507713595643774F, 1.0F, 0.4581185532148767F);
        escalar(g0, "capo_frente_73", 0.46199709773147596F, 1.0F, 0.4470173873125139F);
        escalar(g0, "capo_frente_74", 0.3650915055694712F, 1.0F, 0.4335885444392549F);
        escalar(g0, "capo_frente_75", 0.45029698302312937F, 1.0F, 0.4334763487466699F);
        escalar(g0, "capo_frente_76", 0.40078470528034466F, 1.0F, 0.42258827445097263F);
        escalar(g0, "capo_frente_77", 0.4650927534263722F, 1.0F, 0.43948030648170777F);
        escalar(g0, "capo_frente_78", 0.46509232082100804F, 1.0F, 0.4426649697524128F);
        escalar(g0, "capo_frente_79", 0.46509139316350767F, 1.0F, 0.4455610640780967F);
        escalar(g0, "capo_frente_80", 0.46258216959349935F, 1.0F, 0.4370671775148869F);
        escalar(g0, "capo_frente_81", 0.3651829150522946F, 1.0F, 0.4282664991422713F);
        escalar(g0, "capo_frente_82", 0.4500310874839665F, 1.0F, 0.4304595533261633F);
        escalar(g0, "capo_frente_83", 0.4023712229305167F, 1.0F, 0.42462003354747707F);
        escalar(g0, "capo_frente_84", 0.4650729522282977F, 1.0F, 0.39710825694981433F);
        escalar(g0, "capo_frente_85", 0.4650688887980271F, 1.0F, 0.3948069999246337F);
        escalar(g0, "capo_frente_86", 0.4650647970502542F, 1.0F, 0.39208784750985737F);
        escalar(g0, "capo_frente_87", 0.46191230596382904F, 1.0F, 0.39619233860849473F);
        escalar(g0, "capo_frente_88", 0.3612584788614752F, 1.0F, 0.3947327743489432F);
        escalar(g0, "capo_frente_89", 0.44637694494628477F, 1.0F, 0.5020535851362353F);
        escalar(g0, "capo_frente_90", 0.40220366589350864F, 1.0F, 0.48012913142328534F);
        escalar(g0, "capo_frente_91", 0.4650023966017811F, 1.0F, 0.3974729955575229F);
        escalar(g0, "capo_frente_92", 0.46499876837792115F, 1.0F, 0.3863265703951561F);
        escalar(g0, "capo_frente_93", 0.4649954049915804F, 1.0F, 0.37553907868109476F);
        escalar(g0, "capo_frente_94", 0.45935883425575075F, 1.0F, 0.4041723462633666F);
        escalar(g0, "capo_frente_95", 0.3130125513960769F, 1.0F, 0.42955937846011943F);
        escalar(g0, "capo_frente_96", 0.4179916271539721F, 1.0F, 0.3946137675842963F);
        escalar(g0, "capo_frente_97", 0.41491688091013473F, 1.0F, 0.48396490712790563F);
        escalar(g0, "capo_frente_98", 0.46493868807460836F, 1.0F, 0.3295498877064105F);
        escalar(g0, "capo_frente_99", 0.4649382611561028F, 1.0F, 0.3210844135648263F);
        escalar(g0, "capo_frente_100", 0.46493794872386773F, 1.0F, 0.3137794122190947F);
        escalar(g0, "capo_frente_101", 0.45697349629374573F, 1.0F, 0.34048885649497884F);
        escalar(g0, "capo_frente_102", 0.3212261682141426F, 1.0F, 0.4575120555746797F);
        escalar(g0, "capo_frente_103", 0.43570232539952203F, 1.0F, 0.45644298548887485F);
        escalar(g0, "capo_frente_104", 0.4648967501439601F, 1.0F, 0.35888725856261355F);
        escalar(g0, "capo_frente_105", 0.4648968149441728F, 1.0F, 0.36495254836173013F);
        escalar(g0, "capo_frente_106", 0.4648967157226967F, 1.0F, 0.37130454597096213F);
        escalar(g0, "capo_frente_107", 0.4554030563712746F, 1.0F, 0.35669542448329916F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "capo_frente_108", 0.4223255071934466F, 1.0F, 0.3481262275500516F);
        escalar(g0, "capo_frente_109", 0.39703359485615536F, 1.0F, 0.32740474302391676F);
        escalar(g0, "capo_frente_110", 0.46484028965724167F, 1.0F, 0.2763713440279187F);
        escalar(g0, "capo_frente_111", 0.4648392557893838F, 1.0F, 0.29234765564641224F);
        escalar(g0, "capo_frente_112", 0.46483786419652795F, 1.0F, 0.30871291695745706F);
        escalar(g0, "capo_frente_113", 0.453325699401165F, 1.0F, 0.26955538275576746F);
        escalar(g0, "capo_frente_114", 0.3098448442507639F, 1.0F, 0.2687660887368492F);
        escalar(g0, "capo_frente_115", 0.4730568080141101F, 1.0F, 0.4120871249261841F);
        escalar(g0, "capo_frente_116", 0.4647516661212923F, 1.0F, 0.3391580253960966F);
        escalar(g0, "capo_frente_117", 0.46474714411026985F, 1.0F, 0.3728483831166281F);
        escalar(g0, "capo_frente_118", 0.4647422342750822F, 1.0F, 0.40862274005616167F);
        escalar(g0, "capo_frente_119", 0.45009425335130804F, 1.0F, 0.331477471448562F);
        escalar(g0, "capo_frente_120", 0.25213840951700844F, 1.0F, 0.2787998991896423F);
        escalar(g0, "capo_frente_121", 0.4646400026607552F, 1.0F, 0.37178889334612175F);
        escalar(g0, "capo_frente_122", 0.46463644454422165F, 1.0F, 0.398525076308258F);
        escalar(g0, "capo_frente_123", 0.4646327324788035F, 1.0F, 0.42435909219535156F);
        escalar(g0, "capo_frente_124", 0.4459227333183406F, 1.0F, 0.35465997369573204F);
        escalar(g0, "capo_frente_125", 0.3970550842325096F, 1.0F, 0.2751663249565463F);
        escalar(g0, "faro5_0", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro5_1", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro5_2", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro5_3", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro5_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "faro15_0", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro15_1", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro15_2", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro15_3", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro15_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "faro_alto_0", 0.2353884672967753F, 0.55F, 0.2353884672967753F);
        escalar(g0, "faro_alto_1", 0.2353884672967753F, 0.55F, 0.2353884672967753F);
        escalar(g0, "faro_alto_2", 0.2353884672967753F, 0.55F, 0.2353884672967753F);
        escalar(g0, "faro_alto_3", 0.2353884672967753F, 0.55F, 0.2353884672967753F);
        escalar(g0, "faro_alto_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "ventilador60_0", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador60_1", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador60_2", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador60_3", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador48_0", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador48_1", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador48_2", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "ventilador48_3", 0.6865496962822613F, 1.0F, 0.6865496962822613F);
        escalar(g0, "escape_0", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
        escalar(g0, "escape_1", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
        escalar(g0, "escape_2", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
        escalar(g0, "cabina", 0.5F, 0.5F, 0.5F);
        escalar(g0, "cabina_techo_0", 0.5003125F, 0.5F, 0.3776906062295289F);
        escalar(g0, "cabina_techo_1", 0.5003125F, 0.5F, 0.3776906062295294F);
        escalar(g0, "cabina_techo_2", 0.5003125F, 0.5F, 0.37769060622952955F);
        escalar(g0, "cabina_techo_3", 0.5003125F, 0.5F, 0.37769060622952927F);
        escalar(g0, "cabina_techo_4", 0.5003125F, 0.5F, 0.3776906062295291F);
        escalar(g0, "cabina_techo_5", 0.5003125F, 0.5F, 0.37769060622952955F);
        escalar(g0, "cabina_techo_6", 0.5003125F, 0.5F, 0.37769060622952894F);
        escalar(g0, "cabina_techo_7", 0.5003125F, 0.5F, 0.3776906062295294F);
        escalar(g0, "cabina_techo_8", 0.5003125F, 0.5F, 0.37769060622952955F);
        escalar(g0, "cabina_techo_9", 0.5003125F, 0.5F, 0.37769060622952927F);
        escalar(g0, "cabina_techo_10", 0.5003125F, 0.5F, 0.3776906062295297F);
        escalar(g0, "cabina_techo_11", 0.5003125F, 0.5F, 0.3776906062295289F);
        escalar(g0, "faro_t4_0", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro_t4_1", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro_t4_2", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro_t4_3", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro_t4_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "faro_t16_0", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro_t16_1", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro_t16_2", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro_t16_3", 0.1961570560806461F, 1.0F, 0.1961570560806461F);
        escalar(g0, "faro_t16_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "pasto0_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto0_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto1_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto1_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto2_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto2_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto3_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto3_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto4_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto4_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto5_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto5_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto6_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto6_1", 0.5F, 0.5F, 0.05F);
    }
}
