package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Coche Daylight" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloCocheDaylight {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("coche_daylight"), "main"),
            LocomotoraMod.id("textures/entity/coche_daylight.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -66.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -50.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 50.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 50.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 50.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 66.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 66.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 66.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 50.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 50.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 50.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 66.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 66.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 66.0F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloCocheDaylight::crearCapa,
            16.0F,
            ModeloCocheDaylight::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -58.0F, 58.0F)));

    private ModeloCocheDaylight() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("caja", CubeListBuilder.create().texOffs(0, 52).addBox(-78.0F, -33.0F, 11.5F, 156.0F, 23.0F, 1.0F).texOffs(314, 52).addBox(-78.0F, -33.0F, -12.5F, 156.0F, 23.0F, 1.0F).texOffs(640, 0).addBox(-77.0F, -11.0F, -11.5F, 154.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_techo_0", CubeListBuilder.create().texOffs(70, 116).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.87323500715889F, -11.685937651840831F, -2.3211393658016495F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_1", CubeListBuilder.create().texOffs(388, 116).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.48902060796334F, -9.937072917989997F, -2.470312690854038F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_2", CubeListBuilder.create().texOffs(706, 116).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.82694425906593F, -7.967491422114678F, -2.6194860159064284F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_3", CubeListBuilder.create().texOffs(0, 121).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -37.857288741065695F, -5.820940417948506F, -2.7686593409588185F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_4", CubeListBuilder.create().texOffs(318, 121).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -38.557168612775506F, -3.545097907964653F, -2.917832666011209F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_5", CubeListBuilder.create().texOffs(636, 121).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -38.91103852997129F, -1.190513645981658F, -3.0670059910635965F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_6", CubeListBuilder.create().texOffs(0, 125).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -38.91103852997129F, 1.1905136459816565F, 3.067005991063599F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_7", CubeListBuilder.create().texOffs(318, 125).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -38.55716861277551F, 3.5450979079646503F, 2.9178326660112064F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_8", CubeListBuilder.create().texOffs(636, 125).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -37.857288741065695F, 5.820940417948506F, 2.7686593409588185F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_9", CubeListBuilder.create().texOffs(0, 129).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.82694425906593F, 7.967491422114676F, 2.619486015906428F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_10", CubeListBuilder.create().texOffs(318, 129).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.48902060796334F, 9.937072917989997F, 2.4703126908540387F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_11", CubeListBuilder.create().texOffs(636, 129).addBox(-78.0F, -1.0F, -1.5F, 156.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.87323500715889F, 11.685937651840831F, 2.3211393658016495F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_puntaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -29.0F, 0.0F, 1.0F, 29.0F, 23.0F), PartPose.offset(-78.0F, -10.0F, -11.5F));
        g.addOrReplaceChild("caja_puntab", CubeListBuilder.create().texOffs(48, 0).addBox(0.0F, -29.0F, 0.0F, 1.0F, 29.0F, 23.0F), PartPose.offset(77.0F, -10.0F, -11.5F));
        g.addOrReplaceChild("butacas", CubeListBuilder.create().texOffs(952, 76).addBox(-60.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(784, 52).addBox(-57.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(976, 76).addBox(-60.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(804, 52).addBox(-57.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(1000, 76).addBox(-54.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(824, 52).addBox(-51.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(0, 96).addBox(-54.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(844, 52).addBox(-51.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(24, 96).addBox(-48.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(864, 52).addBox(-45.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(48, 96).addBox(-48.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(884, 52).addBox(-45.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(72, 96).addBox(-42.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(904, 52).addBox(-39.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(96, 96).addBox(-42.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(924, 52).addBox(-39.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(120, 96).addBox(-36.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(944, 52).addBox(-33.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(144, 96).addBox(-36.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(964, 52).addBox(-33.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(168, 96).addBox(-30.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(984, 52).addBox(-27.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(192, 96).addBox(-30.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(1004, 52).addBox(-27.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(216, 96).addBox(-24.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(0, 76).addBox(-21.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(240, 96).addBox(-24.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(20, 76).addBox(-21.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(264, 96).addBox(-18.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(40, 76).addBox(-15.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(288, 96).addBox(-18.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(60, 76).addBox(-15.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(312, 96).addBox(-12.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(80, 76).addBox(-9.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(336, 96).addBox(-12.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(100, 76).addBox(-9.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(360, 96).addBox(-6.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(120, 76).addBox(-3.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(384, 96).addBox(-6.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(140, 76).addBox(-3.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(408, 96).addBox(-0.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(160, 76).addBox(2.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(432, 96).addBox(-0.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(180, 76).addBox(2.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(456, 96).addBox(5.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(200, 76).addBox(8.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(480, 96).addBox(5.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(220, 76).addBox(8.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(504, 96).addBox(11.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(240, 76).addBox(14.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(528, 96).addBox(11.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(260, 76).addBox(14.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(552, 96).addBox(17.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(280, 76).addBox(20.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(576, 96).addBox(17.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(300, 76).addBox(20.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(600, 96).addBox(23.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(320, 76).addBox(26.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(624, 96).addBox(23.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(340, 76).addBox(26.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(648, 96).addBox(29.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(360, 76).addBox(32.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(672, 96).addBox(29.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(380, 76).addBox(32.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(696, 96).addBox(35.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(400, 76).addBox(38.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(720, 96).addBox(35.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(420, 76).addBox(38.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(744, 96).addBox(41.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(440, 76).addBox(44.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(768, 96).addBox(41.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(460, 76).addBox(44.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(792, 96).addBox(47.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(480, 76).addBox(50.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(816, 96).addBox(47.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(500, 76).addBox(50.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(840, 96).addBox(53.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(520, 76).addBox(56.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(864, 96).addBox(53.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(540, 76).addBox(56.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F).texOffs(888, 96).addBox(59.5F, -15.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(560, 76).addBox(62.5F, -22.0F, -11.0F, 1.0F, 11.0F, 9.0F).texOffs(912, 96).addBox(59.5F, -15.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(580, 76).addBox(62.5F, -22.0F, 2.0F, 1.0F, 11.0F, 9.0F), PartPose.ZERO);
        g.addOrReplaceChild("vestibulos", CubeListBuilder.create().texOffs(96, 0).addBox(-67.0F, -33.0F, -11.5F, 1.0F, 22.0F, 23.0F).texOffs(144, 0).addBox(66.0F, -33.0F, -11.5F, 1.0F, 22.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("faldones", CubeListBuilder.create().texOffs(520, 109).addBox(-44.0F, -10.0F, 11.5F, 88.0F, 4.0F, 1.0F).texOffs(698, 109).addBox(-44.0F, -10.0F, -12.5F, 88.0F, 4.0F, 1.0F).texOffs(876, 109).addBox(-78.0F, -10.0F, 11.5F, 6.0F, 4.0F, 1.0F).texOffs(890, 109).addBox(-78.0F, -10.0F, -12.5F, 6.0F, 4.0F, 1.0F).texOffs(904, 109).addBox(72.0F, -10.0F, 11.5F, 6.0F, 4.0F, 1.0F).texOffs(918, 109).addBox(72.0F, -10.0F, -12.5F, 6.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(936, 96).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(954, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(932, 109).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-66.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(972, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(962, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(990, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(970, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(936, 96).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(954, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(942, 109).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-50.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(972, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(962, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(990, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(970, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(936, 96).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(954, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(952, 109).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-66.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(972, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(962, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(990, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(970, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(936, 96).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(954, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(962, 109).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-50.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(972, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(962, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(990, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(970, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(0, 109).addBox(-71.0F, -9.0F, 7.0F, 26.0F, 6.0F, 1.0F).texOffs(54, 109).addBox(-71.0F, -9.0F, -8.0F, 26.0F, 6.0F, 1.0F).texOffs(972, 109).addBox(-68.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(982, 109).addBox(-68.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(992, 109).addBox(-52.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(1002, 109).addBox(-52.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_pivote", CubeListBuilder.create().texOffs(600, 76).addBox(-61.0F, -10.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(936, 96).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(954, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1012, 109).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(50.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(972, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(962, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(990, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(970, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(936, 96).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(954, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 116).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(66.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(972, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(962, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(990, 129).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(970, 96).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(936, 96).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(954, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 116).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(50.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(972, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(962, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(990, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(970, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(936, 96).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(954, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(20, 116).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(66.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(972, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(962, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(990, 129).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(970, 96).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(66.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(108, 109).addBox(45.0F, -9.0F, 7.0F, 26.0F, 6.0F, 1.0F).texOffs(162, 109).addBox(45.0F, -9.0F, -8.0F, 26.0F, 6.0F, 1.0F).texOffs(30, 116).addBox(48.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(40, 116).addBox(48.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(50, 116).addBox(64.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(60, 116).addBox(64.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_pivote", CubeListBuilder.create().texOffs(640, 76).addBox(55.0F, -10.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bajo_piso", CubeListBuilder.create().texOffs(284, 0).addBox(-78.0F, -10.0F, -11.0F, 156.0F, 2.0F, 22.0F).texOffs(628, 52).addBox(-30.0F, -8.0F, -9.0F, 60.0F, 3.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuellei", CubeListBuilder.create().texOffs(192, 0).addBox(-80.0F, -33.0F, -10.5F, 2.0F, 22.0F, 21.0F).texOffs(488, 109).addBox(-85.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuelled", CubeListBuilder.create().texOffs(238, 0).addBox(78.0F, -33.0F, -10.5F, 2.0F, 22.0F, 21.0F).texOffs(504, 109).addBox(80.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("vent0_0", CubeListBuilder.create().texOffs(216, 109).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(680, 76).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-48.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent0_1", CubeListBuilder.create().texOffs(250, 109).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(714, 76).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-48.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent1_0", CubeListBuilder.create().texOffs(284, 109).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(748, 76).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-16.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent1_1", CubeListBuilder.create().texOffs(318, 109).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(782, 76).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-16.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent2_0", CubeListBuilder.create().texOffs(352, 109).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(816, 76).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(16.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent2_1", CubeListBuilder.create().texOffs(386, 109).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(850, 76).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(16.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent3_0", CubeListBuilder.create().texOffs(420, 109).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(884, 76).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(48.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent3_1", CubeListBuilder.create().texOffs(454, 109).addBox(-6.0F, -40.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(918, 76).addBox(-2.5F, -40.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(48.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "caja_techo_0", 1.0001282051282052F, 1.0F, 0.8025552363150691F);
        escalar(g0, "caja_techo_1", 1.0001282051282052F, 1.0F, 0.8025552363150689F);
        escalar(g0, "caja_techo_2", 1.0001282051282052F, 1.0F, 0.8025552363150705F);
        escalar(g0, "caja_techo_3", 1.0001282051282052F, 1.0F, 0.8025552363150693F);
        escalar(g0, "caja_techo_4", 1.0001282051282052F, 1.0F, 0.8025552363150693F);
        escalar(g0, "caja_techo_5", 1.0001282051282052F, 1.0F, 0.8025552363150704F);
        escalar(g0, "caja_techo_6", 1.0001282051282052F, 1.0F, 0.8025552363150691F);
        escalar(g0, "caja_techo_7", 1.0001282051282052F, 1.0F, 0.8025552363150702F);
        escalar(g0, "caja_techo_8", 1.0001282051282052F, 1.0F, 0.8025552363150698F);
        escalar(g0, "caja_techo_9", 1.0001282051282052F, 1.0F, 0.8025552363150693F);
        escalar(g0, "caja_techo_10", 1.0001282051282052F, 1.0F, 0.8025552363150698F);
        escalar(g0, "caja_techo_11", 1.0001282051282052F, 1.0F, 0.8025552363150691F);
        escalar(g0, "vent0_0", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "vent0_1", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "vent1_0", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "vent1_1", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "vent2_0", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "vent2_1", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "vent3_0", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "vent3_1", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
    }
}
