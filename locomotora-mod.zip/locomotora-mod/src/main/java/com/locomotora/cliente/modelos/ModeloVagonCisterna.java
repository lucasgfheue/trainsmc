package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Vagón cisterna" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonCisterna {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_cisterna"), "main"),
            LocomotoraMod.id("textures/entity/vagon_cisterna.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -21.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -21.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -21.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -12.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -12.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -12.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -21.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -21.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -21.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -12.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -12.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -12.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 12.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 12.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 12.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 21.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 21.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 21.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 12.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 12.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 12.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 21.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 21.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 21.5F, -4.0F, 1.0471975511965976F, "cuerpo")),
            ModeloVagonCisterna::crearCapa,
            16.0F,
            ModeloVagonCisterna::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -17.0F, 17.0F)));

    private ModeloVagonCisterna() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(368, 0).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(40, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(388, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(902, 63).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-21.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(60, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-21.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(80, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(404, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-21.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(368, 0).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(40, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(388, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(912, 63).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-12.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(60, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(80, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(404, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(368, 0).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(40, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(388, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(922, 63).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-21.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(60, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-21.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(80, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(404, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-21.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(368, 0).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(40, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(388, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(932, 63).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-12.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(60, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(80, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(404, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(560, 0).addBox(-27.0F, -9.0F, 7.0F, 20.0F, 6.0F, 1.0F).texOffs(602, 0).addBox(-27.0F, -9.0F, -8.0F, 20.0F, 6.0F, 1.0F).texOffs(942, 63).addBox(-23.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(952, 63).addBox(-23.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(962, 63).addBox(-14.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(972, 63).addBox(-14.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(368, 0).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(40, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(388, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(982, 63).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(12.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(60, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(80, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(404, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(368, 0).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(40, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(388, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 63).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(21.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(60, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(21.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(80, 68).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(404, 0).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(21.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(368, 0).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(40, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(388, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1002, 63).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(12.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(60, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(80, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(404, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(368, 0).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(40, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(388, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1012, 63).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(21.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(60, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(21.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(80, 68).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(404, 0).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(21.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(644, 0).addBox(7.0F, -9.0F, 7.0F, 20.0F, 6.0F, 1.0F).texOffs(686, 0).addBox(7.0F, -9.0F, -8.0F, 20.0F, 6.0F, 1.0F).texOffs(0, 68).addBox(10.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(10, 68).addBox(10.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(20, 68).addBox(19.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(30, 68).addBox(19.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(412, 0).addBox(-25.0F, -13.0F, -3.0F, 50.0F, 3.0F, 6.0F).texOffs(104, 0).addBox(-25.0F, -14.0F, -10.0F, 2.0F, 4.0F, 20.0F).texOffs(820, 57).addBox(-30.0F, -12.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(208, 0).addBox(-15.0F, -17.0F, -6.0F, 4.0F, 4.0F, 12.0F).texOffs(148, 0).addBox(23.0F, -14.0F, -10.0F, 2.0F, 4.0F, 20.0F).texOffs(836, 57).addBox(25.0F, -12.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(240, 0).addBox(11.0F, -17.0F, -6.0F, 4.0F, 4.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("tanque_0", CubeListBuilder.create().texOffs(116, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -26.457407282861336F, 0.3235238063781509F, 3.128381604040396F, -0.13023511783475275F, -1.4694118931893136F));
        g.addOrReplaceChild("tanque_1", CubeListBuilder.create().texOffs(852, 57).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -29.84862933320998F, 0.7699866591799992F, 3.0909283212133105F, -0.12074909882027264F, -1.172348214433739F));
        g.addOrReplaceChild("tanque_2", CubeListBuilder.create().texOffs(926, 45).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -32.06029588778518F, 1.061158084920335F, 3.043141602289562F, -0.08640758360293285F, -0.7181186541390191F));
        g.addOrReplaceChild("tanque_3", CubeListBuilder.create().texOffs(946, 45).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -33.09240694658694F, 1.1970380835991583F, 3.014156087049518F, -0.029992105670470382F, -0.22990085926894743F));
        g.addOrReplaceChild("tanque_4", CubeListBuilder.create().texOffs(728, 0).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -33.33814767487307F, 1.2293904642369735F, 3.010692959690218F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_5", CubeListBuilder.create().texOffs(966, 45).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -33.09240694658694F, 1.1970380835991583F, 3.014156087049518F, 0.029992105670470382F, 0.22990085926894743F));
        g.addOrReplaceChild("tanque_6", CubeListBuilder.create().texOffs(986, 45).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -32.06029588778519F, 1.061158084920335F, 3.043141602289562F, 0.08640758360293285F, 0.7181186541390181F));
        g.addOrReplaceChild("tanque_7", CubeListBuilder.create().texOffs(874, 57).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -29.84862933320998F, 0.7699866591799993F, 3.0909283212133105F, 0.12074909882027257F, 1.1723482144337394F));
        g.addOrReplaceChild("tanque_8", CubeListBuilder.create().texOffs(138, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -26.457407282861336F, 0.3235238063781509F, 3.128381604040396F, 0.13023511783475275F, 1.4694118931893136F));
        g.addOrReplaceChild("tanque_9", CubeListBuilder.create().texOffs(160, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -26.289939037591886F, 0.9485238063781508F, 3.1000486975223995F, -0.39060896163264597F, -1.4620537767280715F));
        g.addOrReplaceChild("tanque_10", CubeListBuilder.create().texOffs(896, 57).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -29.450054909468683F, 2.257486659179999F, 2.983386025891107F, -0.36094530821242143F, -1.1464870377503231F));
        g.addOrReplaceChild("tanque_11", CubeListBuilder.create().texOffs(0, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -31.51100004330138F, 3.111158084920335F, 2.840295860942766F, -0.25579961997833306F, -0.6833400320162143F));
        g.addOrReplaceChild("tanque_12", CubeListBuilder.create().texOffs(20, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -32.472774439089974F, 3.509538083599158F, 2.758387644649548F, -0.08803288423750738F, -0.21472721071468923F));
        g.addOrReplaceChild("tanque_13", CubeListBuilder.create().texOffs(0, 27).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -32.701768342849164F, 3.604390464236973F, 2.748893571891071F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_14", CubeListBuilder.create().texOffs(40, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -32.472774439089974F, 3.509538083599158F, 2.758387644649548F, 0.08803288423750738F, 0.21472721071468923F));
        g.addOrReplaceChild("tanque_15", CubeListBuilder.create().texOffs(60, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -31.51100004330138F, 3.1111580849203353F, 2.8402958609427658F, 0.2557996199783331F, 0.6833400320162136F));
        g.addOrReplaceChild("tanque_16", CubeListBuilder.create().texOffs(918, 57).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -29.450054909468683F, 2.2574866591799996F, 2.983386025891107F, 0.3609453082124215F, 1.1464870377503233F));
        g.addOrReplaceChild("tanque_17", CubeListBuilder.create().texOffs(182, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -26.289939037591886F, 0.9485238063781508F, 3.1000486975223995F, 0.39060896163264597F, 1.4620537767280715F));
        g.addOrReplaceChild("tanque_18", CubeListBuilder.create().texOffs(204, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -25.96641523121373F, 1.5088834764831842F, 3.064740196981329F, -0.6506305972925958F, -1.444339834032781F));
        g.addOrReplaceChild("tanque_19", CubeListBuilder.create().texOffs(940, 57).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -28.680068250288684F, 3.591142674029978F, 2.8542268242778954F, -0.5965533718438765F, -1.0865066290763694F));
        g.addOrReplaceChild("tanque_20", CubeListBuilder.create().texOffs(80, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -30.449841958381043F, 4.949137802864845F, 2.6192505542665336F, -0.414241008398636F, -0.6101686061296729F));
        g.addOrReplaceChild("tanque_21", CubeListBuilder.create().texOffs(100, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -31.275736355490814F, 5.582868862987782F, 2.50014151665906F, -0.1403193018930521F, -0.18513313422776795F));
        g.addOrReplaceChild("tanque_22", CubeListBuilder.create().texOffs(166, 27).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -31.472377878612185F, 5.733757210636099F, 2.4870941840919185F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_23", CubeListBuilder.create().texOffs(120, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -31.275736355490814F, 5.582868862987782F, 2.50014151665906F, 0.1403193018930521F, 0.18513313422776795F));
        g.addOrReplaceChild("tanque_24", CubeListBuilder.create().texOffs(140, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -30.449841958381043F, 4.949137802864845F, 2.619250554266534F, 0.41424100839863554F, 0.6101686061296724F));
        g.addOrReplaceChild("tanque_25", CubeListBuilder.create().texOffs(962, 57).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -28.680068250288684F, 3.591142674029979F, 2.854226824277896F, 0.5965533718438765F, 1.0865066290763696F));
        g.addOrReplaceChild("tanque_26", CubeListBuilder.create().texOffs(226, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -25.966415231213734F, 1.5088834764831842F, 3.064740196981329F, 0.6506305972925958F, 1.444339834032781F));
        g.addOrReplaceChild("tanque_27", CubeListBuilder.create().texOffs(248, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -25.508883476483184F, 1.9664152312137326F, 3.0115472310521527F, -0.9097468625059869F, -1.4066025227008243F));
        g.addOrReplaceChild("tanque_28", CubeListBuilder.create().texOffs(984, 57).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -27.591142674029978F, 4.6800682502886835F, 2.6763824713818556F, -0.8214655113051692F, -0.9698038062624856F));
        g.addOrReplaceChild("tanque_29", CubeListBuilder.create().texOffs(160, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -28.949137802864847F, 6.449841958381043F, 2.3674565023599303F, -0.5521771008022145F, -0.49241319423416813F));
        g.addOrReplaceChild("tanque_30", CubeListBuilder.create().texOffs(180, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -29.582868862987784F, 7.27573635549081F, 2.2384339934608657F, -0.1832927713208307F, -0.14272608069086284F));
        g.addOrReplaceChild("tanque_31", CubeListBuilder.create().texOffs(332, 27).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -29.7337572106361F, 7.472377878612184F, 2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_32", CubeListBuilder.create().texOffs(200, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -29.58286886298778F, 7.27573635549081F, 2.2384339934608657F, 0.1832927713208307F, 0.14272608069086284F));
        g.addOrReplaceChild("tanque_33", CubeListBuilder.create().texOffs(220, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -28.949137802864847F, 6.449841958381043F, 2.3674565023599294F, 0.5521771008022143F, 0.4924131942341672F));
        g.addOrReplaceChild("tanque_34", CubeListBuilder.create().texOffs(0, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -27.59114267402998F, 4.680068250288684F, 2.6763824713818556F, 0.8214655113051694F, 0.9698038062624861F));
        g.addOrReplaceChild("tanque_35", CubeListBuilder.create().texOffs(270, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -25.508883476483184F, 1.9664152312137326F, 3.0115472310521527F, 0.9097468625059869F, 1.4066025227008243F));
        g.addOrReplaceChild("tanque_36", CubeListBuilder.create().texOffs(292, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -24.948523806378148F, 2.2899390375918833F, 2.90389738945355F, -1.1660837904330137F, -1.3130896216822108F));
        g.addOrReplaceChild("tanque_37", CubeListBuilder.create().texOffs(22, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -26.25748665918F, 5.450054909468682F, 2.3925194803961634F, -1.0209421492318533F, -0.7420774933931349F));
        g.addOrReplaceChild("tanque_38", CubeListBuilder.create().texOffs(240, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -27.111158084920337F, 7.511000043301378F, 2.075259142045333F, -0.6571237711304426F, -0.3252740146987373F));
        g.addOrReplaceChild("tanque_39", CubeListBuilder.create().texOffs(260, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -27.50953808359916F, 8.472774439089969F, 1.9731732396910275F, -0.21388276048526828F, -0.09009106828805033F));
        g.addOrReplaceChild("tanque_40", CubeListBuilder.create().texOffs(498, 27).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -27.60439046423697F, 8.701768342849157F, 1.963495408493621F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_41", CubeListBuilder.create().texOffs(280, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -27.509538083599157F, 8.472774439089969F, 1.9731732396910275F, 0.21388276048526828F, 0.09009106828805033F));
        g.addOrReplaceChild("tanque_42", CubeListBuilder.create().texOffs(300, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -27.111158084920337F, 7.511000043301378F, 2.075259142045333F, 0.6571237711304422F, 0.325274014698737F));
        g.addOrReplaceChild("tanque_43", CubeListBuilder.create().texOffs(44, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -26.257486659180003F, 5.450054909468684F, 2.3925194803961634F, 1.0209421492318533F, 0.7420774933931349F));
        g.addOrReplaceChild("tanque_44", CubeListBuilder.create().texOffs(314, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -24.94852380637815F, 2.2899390375918833F, 2.90389738945355F, 1.1660837904330137F, 1.3130896216822108F));
        g.addOrReplaceChild("tanque_45", CubeListBuilder.create().texOffs(336, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -24.323523806378148F, 2.457407282861335F, 2.490289816470019F, -1.4059273782934478F, -0.912899338822064F));
        g.addOrReplaceChild("tanque_46", CubeListBuilder.create().texOffs(66, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -24.76998665918F, 5.848629333209978F, 1.900155890214212F, -1.1553921531187912F, -0.3031032091728118F));
        g.addOrReplaceChild("tanque_47", CubeListBuilder.create().texOffs(320, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -25.061158084920336F, 8.06029588778518F, 1.7445092170212935F, -0.7148634989005417F, -0.11452731283949102F));
        g.addOrReplaceChild("tanque_48", CubeListBuilder.create().texOffs(340, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -25.19703808359916F, 9.09240694658694F, 1.7052510418979492F, -0.22979560642048225F, -0.03080204607354003F));
        g.addOrReplaceChild("tanque_49", CubeListBuilder.create().texOffs(664, 27).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -25.229390464236975F, 9.338147674873074F, 1.7016960206944716F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_50", CubeListBuilder.create().texOffs(360, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -25.19703808359916F, 9.09240694658694F, 1.7052510418979492F, 0.22979560642048225F, 0.03080204607354003F));
        g.addOrReplaceChild("tanque_51", CubeListBuilder.create().texOffs(380, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -25.061158084920336F, 8.06029588778518F, 1.7445092170212932F, 0.7148634989005411F, 0.11452731283949107F));
        g.addOrReplaceChild("tanque_52", CubeListBuilder.create().texOffs(88, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -24.76998665918F, 5.848629333209979F, 1.900155890214212F, 1.1553921531187914F, 0.30310320917281175F));
        g.addOrReplaceChild("tanque_53", CubeListBuilder.create().texOffs(358, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -24.32352380637815F, 2.4574072828613356F, 2.490289816470019F, 1.4059273782934478F, 0.912899338822064F));
        g.addOrReplaceChild("tanque_54", CubeListBuilder.create().texOffs(380, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -23.676476193621852F, 2.457407282861335F, 0.6513028371197743F, -1.4059273782934478F, 0.912899338822064F));
        g.addOrReplaceChild("tanque_55", CubeListBuilder.create().texOffs(110, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -23.23001334082F, 5.8486293332099795F, 1.2414367633755827F, -1.1553921531187912F, 0.3031032091728104F));
        g.addOrReplaceChild("tanque_56", CubeListBuilder.create().texOffs(400, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -22.938841915079667F, 8.06029588778518F, 1.397083436568501F, -0.7148634989005417F, 0.1145273128394904F));
        g.addOrReplaceChild("tanque_57", CubeListBuilder.create().texOffs(420, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -22.802961916400843F, 9.09240694658694F, 1.4363416116918444F, -0.2297956064204822F, 0.030802046073539875F));
        g.addOrReplaceChild("tanque_58", CubeListBuilder.create().texOffs(830, 27).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -22.77060953576303F, 9.338147674873074F, 1.4398966328953222F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_59", CubeListBuilder.create().texOffs(440, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -22.802961916400843F, 9.09240694658694F, 1.4363416116918444F, 0.2297956064204822F, -0.030802046073539875F));
        g.addOrReplaceChild("tanque_60", CubeListBuilder.create().texOffs(460, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -22.938841915079664F, 8.06029588778518F, 1.3970834365685008F, 0.7148634989005411F, -0.11452731283949036F));
        g.addOrReplaceChild("tanque_61", CubeListBuilder.create().texOffs(132, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -23.23001334082F, 5.8486293332099795F, 1.2414367633755827F, 1.1553921531187914F, -0.3031032091728104F));
        g.addOrReplaceChild("tanque_62", CubeListBuilder.create().texOffs(402, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -23.67647619362185F, 2.4574072828613356F, 0.6513028371197743F, 1.4059273782934478F, -0.912899338822064F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("tanque_63", CubeListBuilder.create().texOffs(424, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -23.051476193621852F, 2.2899390375918838F, 0.23769526413624306F, -1.1660837904330141F, 1.3130896216822108F));
        g.addOrReplaceChild("tanque_64", CubeListBuilder.create().texOffs(154, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -21.74251334082F, 5.450054909468683F, 0.749073173193631F, -1.020942149231854F, 0.7420774933931333F));
        g.addOrReplaceChild("tanque_65", CubeListBuilder.create().texOffs(480, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -20.888841915079666F, 7.5110000433013795F, 1.0663335115444605F, -0.6571237711304426F, 0.32527401469873696F));
        g.addOrReplaceChild("tanque_66", CubeListBuilder.create().texOffs(500, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -20.490461916400843F, 8.47277443908997F, 1.1684194138987667F, -0.21388276048526847F, 0.09009106828805033F));
        g.addOrReplaceChild("tanque_67", CubeListBuilder.create().texOffs(0, 33).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -20.39560953576303F, 8.70176834284916F, 1.1780972450961733F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_68", CubeListBuilder.create().texOffs(520, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -20.490461916400843F, 8.47277443908997F, 1.1684194138987667F, 0.21388276048526847F, -0.09009106828805033F));
        g.addOrReplaceChild("tanque_69", CubeListBuilder.create().texOffs(540, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -20.888841915079666F, 7.5110000433013795F, 1.0663335115444605F, 0.6571237711304421F, -0.32527401469873696F));
        g.addOrReplaceChild("tanque_70", CubeListBuilder.create().texOffs(176, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -21.742513340820004F, 5.450054909468685F, 0.7490731731936311F, 1.020942149231854F, -0.7420774933931332F));
        g.addOrReplaceChild("tanque_71", CubeListBuilder.create().texOffs(446, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -23.05147619362185F, 2.2899390375918838F, 0.23769526413624306F, 1.1660837904330141F, -1.3130896216822108F));
        g.addOrReplaceChild("tanque_72", CubeListBuilder.create().texOffs(468, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -22.491116523516816F, 1.966415231213733F, 0.13004542253764048F, -0.9097468625059869F, 1.4066025227008243F));
        g.addOrReplaceChild("tanque_73", CubeListBuilder.create().texOffs(198, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -20.408857325970022F, 4.680068250288684F, 0.4652101822079383F, -0.8214655113051695F, 0.9698038062624852F));
        g.addOrReplaceChild("tanque_74", CubeListBuilder.create().texOffs(560, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -19.050862197135153F, 6.449841958381044F, 0.774136151229863F, -0.5521771008022149F, 0.4924131942341684F));
        g.addOrReplaceChild("tanque_75", CubeListBuilder.create().texOffs(580, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -18.41713113701222F, 7.275736355490812F, 0.903158660128927F, -0.1832927713208307F, 0.14272608069086243F));
        g.addOrReplaceChild("tanque_76", CubeListBuilder.create().texOffs(166, 33).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -18.2662427893639F, 7.4723778786121855F, 0.916297857297022F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_77", CubeListBuilder.create().texOffs(600, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -18.41713113701222F, 7.275736355490812F, 0.903158660128927F, 0.1832927713208307F, -0.14272608069086243F));
        g.addOrReplaceChild("tanque_78", CubeListBuilder.create().texOffs(620, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -19.050862197135157F, 6.449841958381045F, 0.7741361512298635F, 0.5521771008022143F, -0.4924131942341682F));
        g.addOrReplaceChild("tanque_79", CubeListBuilder.create().texOffs(220, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -20.408857325970022F, 4.680068250288685F, 0.4652101822079384F, 0.8214655113051701F, -0.9698038062624852F));
        g.addOrReplaceChild("tanque_80", CubeListBuilder.create().texOffs(490, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -22.491116523516816F, 1.966415231213733F, 0.13004542253764048F, 0.9097468625059869F, -1.4066025227008243F));
        g.addOrReplaceChild("tanque_81", CubeListBuilder.create().texOffs(512, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -22.033584768786266F, 1.5088834764831849F, 0.07685245660846411F, -0.6506305972925959F, 1.444339834032781F));
        g.addOrReplaceChild("tanque_82", CubeListBuilder.create().texOffs(242, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -19.319931749711316F, 3.59114267402998F, 0.2873658293118983F, -0.5965533718438766F, 1.0865066290763694F));
        g.addOrReplaceChild("tanque_83", CubeListBuilder.create().texOffs(640, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -17.550158041618957F, 4.949137802864847F, 0.5223420993232601F, -0.41424100839863637F, 0.6101686061296729F));
        g.addOrReplaceChild("tanque_84", CubeListBuilder.create().texOffs(660, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -16.72426364450919F, 5.582868862987784F, 0.6414511369307336F, -0.14031930189305164F, 0.185133134227766F));
        g.addOrReplaceChild("tanque_85", CubeListBuilder.create().texOffs(332, 33).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -16.527622121387818F, 5.733757210636103F, 0.6544984694978746F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_86", CubeListBuilder.create().texOffs(680, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -16.72426364450919F, 5.582868862987785F, 0.6414511369307336F, 0.14031930189305164F, -0.185133134227766F));
        g.addOrReplaceChild("tanque_87", CubeListBuilder.create().texOffs(700, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -17.550158041618957F, 4.949137802864847F, 0.52234209932326F, 0.41424100839863603F, -0.6101686061296727F));
        g.addOrReplaceChild("tanque_88", CubeListBuilder.create().texOffs(264, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -19.319931749711316F, 3.591142674029981F, 0.28736582931189825F, 0.596553371843877F, -1.0865066290763694F));
        g.addOrReplaceChild("tanque_89", CubeListBuilder.create().texOffs(534, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -22.033584768786266F, 1.5088834764831849F, 0.07685245660846411F, 0.6506305972925959F, -1.444339834032781F));
        g.addOrReplaceChild("tanque_90", CubeListBuilder.create().texOffs(556, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -21.710060962408114F, 0.9485238063781517F, 0.041543956067393806F, -0.39060896163264636F, 1.4620537767280715F));
        g.addOrReplaceChild("tanque_91", CubeListBuilder.create().texOffs(286, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -18.549945090531317F, 2.2574866591800014F, 0.1582066276986861F, -0.36094530821242177F, 1.1464870377503231F));
        g.addOrReplaceChild("tanque_92", CubeListBuilder.create().texOffs(720, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -16.488999956698624F, 3.111158084920338F, 0.3012967926470265F, -0.255799619978333F, 0.6833400320162142F));
        g.addOrReplaceChild("tanque_93", CubeListBuilder.create().texOffs(740, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -15.527225560910031F, 3.5095380835991614F, 0.38320500894024606F, -0.08803288423750738F, 0.21472721071468806F));
        g.addOrReplaceChild("tanque_94", CubeListBuilder.create().texOffs(498, 33).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -15.298231657150843F, 3.6043904642369764F, 0.3926990816987246F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_95", CubeListBuilder.create().texOffs(760, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -15.527225560910031F, 3.5095380835991614F, 0.38320500894024606F, 0.08803288423750738F, -0.21472721071468806F));
        g.addOrReplaceChild("tanque_96", CubeListBuilder.create().texOffs(780, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -16.48899995669862F, 3.111158084920338F, 0.3012967926470273F, 0.25579961997833295F, -0.6833400320162134F));
        g.addOrReplaceChild("tanque_97", CubeListBuilder.create().texOffs(308, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -18.549945090531317F, 2.2574866591800014F, 0.1582066276986864F, 0.36094530821242177F, -1.1464870377503233F));
        g.addOrReplaceChild("tanque_98", CubeListBuilder.create().texOffs(578, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -21.710060962408114F, 0.9485238063781516F, 0.041543956067393806F, 0.39060896163264636F, -1.4620537767280715F));
        g.addOrReplaceChild("tanque_99", CubeListBuilder.create().texOffs(600, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -21.542592717138664F, 0.3235238063781514F, 0.013211049549397044F, -0.13023511783475297F, 1.4694118931893136F));
        g.addOrReplaceChild("tanque_100", CubeListBuilder.create().texOffs(330, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -18.151370666790022F, 0.7699866591800004F, 0.05066433237648275F, -0.12074909882027283F, 1.172348214433739F));
        g.addOrReplaceChild("tanque_101", CubeListBuilder.create().texOffs(800, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -15.939704112214821F, 1.0611580849203366F, 0.09845105130023138F, -0.08640758360293302F, 0.7181186541390189F));
        g.addOrReplaceChild("tanque_102", CubeListBuilder.create().texOffs(820, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -14.90759305341306F, 1.1970380835991603F, 0.1274365665402755F, -0.029992105670470462F, 0.2299008592689478F));
        g.addOrReplaceChild("tanque_103", CubeListBuilder.create().texOffs(664, 33).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -14.661852325126926F, 1.2293904642369753F, 0.13089969389957487F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_104", CubeListBuilder.create().texOffs(840, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -14.90759305341306F, 1.1970380835991603F, 0.1274365665402755F, 0.029992105670470462F, -0.2299008592689478F));
        g.addOrReplaceChild("tanque_105", CubeListBuilder.create().texOffs(860, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -15.93970411221482F, 1.0611580849203368F, 0.09845105130023146F, 0.08640758360293294F, -0.7181186541390178F));
        g.addOrReplaceChild("tanque_106", CubeListBuilder.create().texOffs(352, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -18.15137066679002F, 0.7699866591800005F, 0.05066433237648269F, 0.12074909882027278F, -1.1723482144337394F));
        g.addOrReplaceChild("tanque_107", CubeListBuilder.create().texOffs(622, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -21.542592717138664F, 0.3235238063781514F, 0.013211049549397044F, 0.13023511783475297F, -1.4694118931893136F));
        g.addOrReplaceChild("tanque_108", CubeListBuilder.create().texOffs(644, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -21.542592717138664F, -0.32352380637815026F, -0.013211049549397069F, 0.13023511783475253F, 1.4694118931893136F));
        g.addOrReplaceChild("tanque_109", CubeListBuilder.create().texOffs(374, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -18.151370666790022F, -0.7699866591799978F, -0.05066433237648238F, 0.12074909882027236F, 1.1723482144337392F));
        g.addOrReplaceChild("tanque_110", CubeListBuilder.create().texOffs(880, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -15.93970411221482F, -1.0611580849203328F, -0.09845105130023053F, 0.08640758360293246F, 0.7181186541390188F));
        g.addOrReplaceChild("tanque_111", CubeListBuilder.create().texOffs(900, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -14.90759305341306F, -1.197038083599156F, -0.12743656654027496F, 0.029992105670470382F, 0.22990085926894788F));
        g.addOrReplaceChild("tanque_112", CubeListBuilder.create().texOffs(830, 33).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -14.661852325126926F, -1.229390464236971F, -0.13089969389957437F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_113", CubeListBuilder.create().texOffs(920, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -14.90759305341306F, -1.197038083599156F, -0.12743656654027496F, -0.029992105670470382F, -0.22990085926894788F));
        g.addOrReplaceChild("tanque_114", CubeListBuilder.create().texOffs(940, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -15.93970411221482F, -1.0611580849203333F, -0.09845105130023125F, -0.08640758360293278F, -0.718118654139018F));
        g.addOrReplaceChild("tanque_115", CubeListBuilder.create().texOffs(396, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -18.15137066679002F, -0.7699866591799979F, -0.05066433237648277F, -0.12074909882027238F, -1.1723482144337394F));
        g.addOrReplaceChild("tanque_116", CubeListBuilder.create().texOffs(666, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -21.542592717138664F, -0.3235238063781503F, -0.013211049549397069F, -0.13023511783475253F, -1.4694118931893136F));
        g.addOrReplaceChild("tanque_117", CubeListBuilder.create().texOffs(688, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -21.710060962408114F, -0.9485238063781497F, -0.04154395606739384F, 0.3906089616326456F, 1.4620537767280715F));
        g.addOrReplaceChild("tanque_118", CubeListBuilder.create().texOffs(418, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -18.549945090531313F, -2.257486659179996F, -0.15820662769868604F, 0.3609453082124206F, 1.1464870377503236F));
        g.addOrReplaceChild("tanque_119", CubeListBuilder.create().texOffs(960, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -16.488999956698617F, -3.111158084920331F, -0.3012967926470265F, 0.25579961997833267F, 0.6833400320162138F));
        g.addOrReplaceChild("tanque_120", CubeListBuilder.create().texOffs(980, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -15.527225560910027F, -3.5095380835991534F, -0.38320500894024545F, 0.08803288423750708F, 0.2147272107146884F));
        g.addOrReplaceChild("tanque_121", CubeListBuilder.create().texOffs(0, 39).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -15.29823165715084F, -3.6043904642369684F, -0.3926990816987238F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_122", CubeListBuilder.create().texOffs(1000, 51).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -15.52722556091003F, -3.509538083599154F, -0.38320500894024545F, -0.08803288423750708F, -0.2147272107146884F));
        g.addOrReplaceChild("tanque_123", CubeListBuilder.create().texOffs(0, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -16.488999956698617F, -3.1111580849203317F, -0.30129679264702663F, -0.2557996199783326F, -0.6833400320162136F));
        g.addOrReplaceChild("tanque_124", CubeListBuilder.create().texOffs(440, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -18.549945090531313F, -2.257486659179997F, -0.15820662769868604F, -0.3609453082124208F, -1.1464870377503236F));
        g.addOrReplaceChild("tanque_125", CubeListBuilder.create().texOffs(710, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -21.710060962408114F, -0.9485238063781497F, -0.04154395606739384F, -0.3906089616326456F, -1.4620537767280715F));
        g.addOrReplaceChild("tanque_126", CubeListBuilder.create().texOffs(732, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -22.03358476878627F, -1.5088834764831835F, -0.07685245660846393F, 0.6506305972925954F, 1.444339834032781F));
        g.addOrReplaceChild("tanque_127", CubeListBuilder.create().texOffs(462, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -19.319931749711316F, -3.591142674029977F, -0.28736582931189775F, 0.5965533718438759F, 1.0865066290763696F));
        g.addOrReplaceChild("tanque_128", CubeListBuilder.create().texOffs(20, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -17.550158041618957F, -4.9491378028648425F, -0.5223420993232596F, 0.41424100839863603F, 0.610168606129673F));
        g.addOrReplaceChild("tanque_129", CubeListBuilder.create().texOffs(40, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -16.724263644509186F, -5.5828688629877785F, -0.6414511369307324F, 0.14031930189305156F, 0.18513313422776695F));
        g.addOrReplaceChild("tanque_130", CubeListBuilder.create().texOffs(166, 39).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -16.527622121387815F, -5.733757210636098F, -0.6544984694978729F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_131", CubeListBuilder.create().texOffs(60, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -16.724263644509186F, -5.582868862987779F, -0.6414511369307324F, -0.14031930189305156F, -0.18513313422776695F));
        g.addOrReplaceChild("tanque_132", CubeListBuilder.create().texOffs(80, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -17.55015804161895F, -4.9491378028648425F, -0.5223420993232593F, -0.4142410083986354F, -0.6101686061296724F));
        g.addOrReplaceChild("tanque_133", CubeListBuilder.create().texOffs(484, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -19.319931749711316F, -3.591142674029978F, -0.2873658293118972F, -0.5965533718438759F, -1.08650662907637F));
        g.addOrReplaceChild("tanque_134", CubeListBuilder.create().texOffs(754, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -22.033584768786266F, -1.5088834764831838F, -0.07685245660846393F, -0.6506305972925954F, -1.444339834032781F));
        g.addOrReplaceChild("tanque_135", CubeListBuilder.create().texOffs(776, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -22.491116523516816F, -1.9664152312137322F, -0.13004542253764056F, 0.9097468625059869F, 1.4066025227008243F));
        g.addOrReplaceChild("tanque_136", CubeListBuilder.create().texOffs(506, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -20.408857325970022F, -4.680068250288683F, -0.4652101822079381F, 0.8214655113051692F, 0.9698038062624856F));
        g.addOrReplaceChild("tanque_137", CubeListBuilder.create().texOffs(100, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -19.050862197135153F, -6.449841958381042F, -0.774136151229863F, 0.5521771008022147F, 0.4924131942341685F));
        g.addOrReplaceChild("tanque_138", CubeListBuilder.create().texOffs(120, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -18.417131137012216F, -7.27573635549081F, -0.9031586601289273F, 0.1832927713208307F, 0.14272608069086293F));
        g.addOrReplaceChild("tanque_139", CubeListBuilder.create().texOffs(332, 39).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -18.266242789363897F, -7.472377878612183F, -0.9162978572970227F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_140", CubeListBuilder.create().texOffs(140, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -18.417131137012216F, -7.275736355490809F, -0.9031586601289273F, -0.1832927713208307F, -0.14272608069086293F));
        g.addOrReplaceChild("tanque_141", CubeListBuilder.create().texOffs(160, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -19.050862197135153F, -6.449841958381043F, -0.7741361512298633F, -0.5521771008022143F, -0.4924131942341677F));
        g.addOrReplaceChild("tanque_142", CubeListBuilder.create().texOffs(528, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -20.40885732597002F, -4.680068250288684F, -0.465210182207938F, -0.8214655113051691F, -0.9698038062624861F));
        g.addOrReplaceChild("tanque_143", CubeListBuilder.create().texOffs(798, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -22.491116523516816F, -1.9664152312137326F, -0.13004542253764056F, -0.9097468625059869F, -1.4066025227008243F));
        g.addOrReplaceChild("tanque_144", CubeListBuilder.create().texOffs(820, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -23.05147619362185F, -2.289939037591883F, -0.2376952641362427F, 1.1660837904330135F, 1.313089621682211F));
        g.addOrReplaceChild("tanque_145", CubeListBuilder.create().texOffs(550, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -21.742513340819997F, -5.450054909468682F, -0.7490731731936293F, 1.0209421492318533F, 0.7420774933931349F));
        g.addOrReplaceChild("tanque_146", CubeListBuilder.create().texOffs(180, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -20.88884191507966F, -7.511000043301376F, -1.0663335115444588F, 0.6571237711304424F, 0.32527401469873807F));
        g.addOrReplaceChild("tanque_147", CubeListBuilder.create().texOffs(200, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -20.490461916400836F, -8.472774439089967F, -1.1684194138987651F, 0.213882760485268F, 0.0900910682880508F));
        g.addOrReplaceChild("tanque_148", CubeListBuilder.create().texOffs(498, 39).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -20.395609535763022F, -8.701768342849157F, -1.1780972450961718F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_149", CubeListBuilder.create().texOffs(220, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -20.49046191640084F, -8.472774439089967F, -1.1684194138987651F, -0.213882760485268F, -0.0900910682880508F));
        g.addOrReplaceChild("tanque_150", CubeListBuilder.create().texOffs(240, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -20.88884191507966F, -7.511000043301378F, -1.0663335115444592F, -0.6571237711304418F, -0.32527401469873785F));
        g.addOrReplaceChild("tanque_151", CubeListBuilder.create().texOffs(572, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -21.742513340819997F, -5.450054909468683F, -0.7490731731936294F, -1.0209421492318533F, -0.7420774933931348F));
        g.addOrReplaceChild("tanque_152", CubeListBuilder.create().texOffs(842, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -23.05147619362185F, -2.2899390375918833F, -0.2376952641362427F, -1.1660837904330135F, -1.313089621682211F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("tanque_153", CubeListBuilder.create().texOffs(864, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -23.67647619362185F, -2.457407282861335F, -0.6513028371197729F, 1.4059273782934478F, 0.9128993388220656F));
        g.addOrReplaceChild("tanque_154", CubeListBuilder.create().texOffs(594, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -23.230013340819998F, -5.848629333209978F, -1.2414367633755814F, 1.1553921531187912F, 0.3031032091728118F));
        g.addOrReplaceChild("tanque_155", CubeListBuilder.create().texOffs(260, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -22.938841915079664F, -8.06029588778518F, -1.3970834365685003F, 0.7148634989005416F, 0.11452731283949091F));
        g.addOrReplaceChild("tanque_156", CubeListBuilder.create().texOffs(280, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -22.80296191640084F, -9.09240694658694F, -1.4363416116918437F, 0.22979560642048186F, 0.030802046073540437F));
        g.addOrReplaceChild("tanque_157", CubeListBuilder.create().texOffs(664, 39).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -22.770609535763022F, -9.338147674873074F, -1.4398966328953213F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_158", CubeListBuilder.create().texOffs(300, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -22.80296191640084F, -9.09240694658694F, -1.4363416116918437F, -0.22979560642048186F, -0.030802046073540437F));
        g.addOrReplaceChild("tanque_159", CubeListBuilder.create().texOffs(320, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -22.938841915079664F, -8.06029588778518F, -1.3970834365684999F, -0.7148634989005411F, -0.1145273128394909F));
        g.addOrReplaceChild("tanque_160", CubeListBuilder.create().texOffs(616, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -23.230013340819998F, -5.848629333209979F, -1.2414367633755812F, -1.1553921531187914F, -0.3031032091728118F));
        g.addOrReplaceChild("tanque_161", CubeListBuilder.create().texOffs(886, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -23.67647619362185F, -2.4574072828613356F, -0.6513028371197729F, -1.4059273782934478F, -0.9128993388220656F));
        g.addOrReplaceChild("tanque_162", CubeListBuilder.create().texOffs(908, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -24.323523806378148F, -2.457407282861335F, -2.490289816470019F, 1.4059273782934478F, -0.912899338822064F));
        g.addOrReplaceChild("tanque_163", CubeListBuilder.create().texOffs(638, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -24.76998665918F, -5.8486293332099795F, -1.9001558902142093F, 1.1553921531187916F, -0.3031032091728091F));
        g.addOrReplaceChild("tanque_164", CubeListBuilder.create().texOffs(340, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -25.061158084920333F, -8.06029588778518F, -1.7445092170212928F, 0.7148634989005416F, -0.11452731283949096F));
        g.addOrReplaceChild("tanque_165", CubeListBuilder.create().texOffs(360, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -25.197038083599157F, -9.09240694658694F, -1.705251041897949F, 0.2297956064204822F, -0.030802046073539875F));
        g.addOrReplaceChild("tanque_166", CubeListBuilder.create().texOffs(830, 39).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -25.22939046423697F, -9.338147674873074F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_167", CubeListBuilder.create().texOffs(380, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -25.197038083599157F, -9.09240694658694F, -1.705251041897949F, -0.2297956064204822F, 0.030802046073539875F));
        g.addOrReplaceChild("tanque_168", CubeListBuilder.create().texOffs(400, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -25.061158084920336F, -8.06029588778518F, -1.7445092170212924F, -0.7148634989005411F, 0.11452731283949036F));
        g.addOrReplaceChild("tanque_169", CubeListBuilder.create().texOffs(660, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -24.76998665918F, -5.8486293332099795F, -1.9001558902142106F, -1.1553921531187914F, 0.3031032091728104F));
        g.addOrReplaceChild("tanque_170", CubeListBuilder.create().texOffs(930, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -24.32352380637815F, -2.4574072828613356F, -2.490289816470019F, -1.4059273782934478F, 0.912899338822064F));
        g.addOrReplaceChild("tanque_171", CubeListBuilder.create().texOffs(952, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -24.948523806378148F, -2.289939037591884F, -2.90389738945355F, 1.1660837904330144F, -1.3130896216822106F));
        g.addOrReplaceChild("tanque_172", CubeListBuilder.create().texOffs(682, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -26.257486659179996F, -5.450054909468685F, -2.392519480396161F, 1.0209421492318542F, -0.7420774933931324F));
        g.addOrReplaceChild("tanque_173", CubeListBuilder.create().texOffs(420, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -27.111158084920334F, -7.51100004330138F, -2.075259142045332F, 0.6571237711304428F, -0.32527401469873674F));
        g.addOrReplaceChild("tanque_174", CubeListBuilder.create().texOffs(440, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -27.509538083599153F, -8.472774439089973F, -1.9731732396910264F, 0.21388276048526808F, -0.09009106828805023F));
        g.addOrReplaceChild("tanque_175", CubeListBuilder.create().texOffs(0, 45).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -27.60439046423697F, -8.70176834284916F, -1.9634954084936203F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_176", CubeListBuilder.create().texOffs(460, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -27.509538083599153F, -8.47277443908997F, -1.9731732396910264F, -0.21388276048526808F, 0.09009106828805023F));
        g.addOrReplaceChild("tanque_177", CubeListBuilder.create().texOffs(480, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -27.111158084920326F, -7.511000043301381F, -2.075259142045332F, -0.6571237711304422F, 0.32527401469873635F));
        g.addOrReplaceChild("tanque_178", CubeListBuilder.create().texOffs(704, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -26.257486659179996F, -5.450054909468685F, -2.392519480396162F, -1.020942149231854F, 0.7420774933931332F));
        g.addOrReplaceChild("tanque_179", CubeListBuilder.create().texOffs(974, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -24.948523806378148F, -2.289939037591884F, -2.90389738945355F, -1.1660837904330144F, 1.3130896216822106F));
        g.addOrReplaceChild("tanque_180", CubeListBuilder.create().texOffs(996, 68).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -25.508883476483184F, -1.9664152312137335F, -3.0115472310521527F, 0.9097468625059878F, -1.406602522700824F));
        g.addOrReplaceChild("tanque_181", CubeListBuilder.create().texOffs(726, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -27.591142674029975F, -4.680068250288685F, -2.676382471381855F, 0.8214655113051699F, -0.9698038062624852F));
        g.addOrReplaceChild("tanque_182", CubeListBuilder.create().texOffs(500, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -28.94913780286484F, -6.449841958381046F, -2.3674565023599303F, 0.5521771008022147F, -0.4924131942341681F));
        g.addOrReplaceChild("tanque_183", CubeListBuilder.create().texOffs(520, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -29.58286886298778F, -7.275736355490813F, -2.2384339934608652F, 0.18329277132083077F, -0.14272608069086282F));
        g.addOrReplaceChild("tanque_184", CubeListBuilder.create().texOffs(166, 45).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -29.733757210636096F, -7.472377878612186F, -2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_185", CubeListBuilder.create().texOffs(540, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -29.582868862987777F, -7.275736355490814F, -2.2384339934608652F, -0.18329277132083077F, 0.14272608069086282F));
        g.addOrReplaceChild("tanque_186", CubeListBuilder.create().texOffs(560, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -28.94913780286484F, -6.449841958381047F, -2.3674565023599294F, -0.5521771008022144F, 0.49241319423416724F));
        g.addOrReplaceChild("tanque_187", CubeListBuilder.create().texOffs(748, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -27.591142674029978F, -4.680068250288686F, -2.676382471381855F, -0.8214655113051699F, 0.9698038062624856F));
        g.addOrReplaceChild("tanque_188", CubeListBuilder.create().texOffs(0, 73).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -25.508883476483184F, -1.9664152312137335F, -3.0115472310521527F, -0.9097468625059878F, 1.406602522700824F));
        g.addOrReplaceChild("tanque_189", CubeListBuilder.create().texOffs(22, 73).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -25.96641523121373F, -1.508883476483185F, -3.064740196981329F, 0.6506305972925961F, -1.4443398340327809F));
        g.addOrReplaceChild("tanque_190", CubeListBuilder.create().texOffs(770, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -28.68006825028868F, -3.5911426740299808F, -2.8542268242778945F, 0.596553371843877F, -1.0865066290763692F));
        g.addOrReplaceChild("tanque_191", CubeListBuilder.create().texOffs(580, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -30.44984195838104F, -4.949137802864847F, -2.619250554266533F, 0.41424100839863637F, -0.6101686061296729F));
        g.addOrReplaceChild("tanque_192", CubeListBuilder.create().texOffs(600, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -31.275736355490807F, -5.582868862987785F, -2.50014151665906F, 0.1403193018930521F, -0.18513313422776748F));
        g.addOrReplaceChild("tanque_193", CubeListBuilder.create().texOffs(332, 45).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -31.47237787861218F, -5.733757210636104F, -2.487094184091919F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_194", CubeListBuilder.create().texOffs(620, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -31.27573635549081F, -5.582868862987785F, -2.50014151665906F, -0.1403193018930521F, 0.18513313422776748F));
        g.addOrReplaceChild("tanque_195", CubeListBuilder.create().texOffs(640, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -30.449841958381043F, -4.949137802864848F, -2.6192505542665327F, -0.414241008398636F, 0.6101686061296718F));
        g.addOrReplaceChild("tanque_196", CubeListBuilder.create().texOffs(792, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -28.680068250288684F, -3.591142674029981F, -2.854226824277895F, -0.5965533718438767F, 1.0865066290763696F));
        g.addOrReplaceChild("tanque_197", CubeListBuilder.create().texOffs(44, 73).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -25.966415231213734F, -1.508883476483185F, -3.064740196981329F, -0.6506305972925961F, 1.4443398340327809F));
        g.addOrReplaceChild("tanque_198", CubeListBuilder.create().texOffs(66, 73).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -26.289939037591886F, -0.9485238063781525F, -3.1000486975223995F, 0.39060896163264663F, -1.4620537767280715F));
        g.addOrReplaceChild("tanque_199", CubeListBuilder.create().texOffs(814, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -29.450054909468683F, -2.257486659180003F, -2.9833860258911065F, 0.36094530821242227F, -1.146487037750323F));
        g.addOrReplaceChild("tanque_200", CubeListBuilder.create().texOffs(660, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -31.51100004330138F, -3.11115808492034F, -2.840295860942765F, 0.255799619978334F, -0.6833400320162142F));
        g.addOrReplaceChild("tanque_201", CubeListBuilder.create().texOffs(680, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -32.47277443908997F, -3.5095380835991645F, -2.7583876446495452F, 0.0880328842375077F, -0.2147272107146884F));
        g.addOrReplaceChild("tanque_202", CubeListBuilder.create().texOffs(498, 45).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -32.70176834284916F, -3.6043904642369795F, -2.748893571891068F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_203", CubeListBuilder.create().texOffs(700, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -32.47277443908997F, -3.5095380835991645F, -2.7583876446495452F, -0.0880328842375077F, 0.2147272107146884F));
        g.addOrReplaceChild("tanque_204", CubeListBuilder.create().texOffs(720, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -31.511000043301376F, -3.1111580849203406F, -2.8402958609427653F, -0.25579961997833345F, 0.6833400320162137F));
        g.addOrReplaceChild("tanque_205", CubeListBuilder.create().texOffs(836, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -29.450054909468683F, -2.257486659180003F, -2.983386025891107F, -0.3609453082124222F, 1.1464870377503231F));
        g.addOrReplaceChild("tanque_206", CubeListBuilder.create().texOffs(88, 73).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -26.289939037591886F, -0.9485238063781525F, -3.1000486975223995F, -0.39060896163264663F, 1.4620537767280715F));
        g.addOrReplaceChild("tanque_207", CubeListBuilder.create().texOffs(110, 73).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.799999999999997F, -26.457407282861336F, -0.32352380637815226F, -3.128381604040396F, 0.1302351178347533F, -1.4694118931893136F));
        g.addOrReplaceChild("tanque_208", CubeListBuilder.create().texOffs(858, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-24.0F, -29.848629333209978F, -0.7699866591800024F, -3.0909283212133105F, 0.12074909882027315F, -1.172348214433739F));
        g.addOrReplaceChild("tanque_209", CubeListBuilder.create().texOffs(740, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-22.5F, -32.06029588778518F, -1.0611580849203395F, -3.0431416022895625F, 0.08640758360293294F, -0.7181186541390193F));
        g.addOrReplaceChild("tanque_210", CubeListBuilder.create().texOffs(760, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-20.55F, -33.09240694658694F, -1.1970380835991634F, -3.0141560870495185F, 0.02999210567047054F, -0.22990085926894746F));
        g.addOrReplaceChild("tanque_211", CubeListBuilder.create().texOffs(664, 45).addBox(-39.0F, -1.0F, -2.5F, 78.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(0.0F, -33.33814767487307F, -1.2293904642369788F, -3.0106929596902186F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_212", CubeListBuilder.create().texOffs(780, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(20.55F, -33.09240694658694F, -1.1970380835991632F, -3.0141560870495185F, -0.02999210567047054F, 0.22990085926894746F));
        g.addOrReplaceChild("tanque_213", CubeListBuilder.create().texOffs(800, 57).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(22.5F, -32.06029588778518F, -1.0611580849203395F, -3.0431416022895617F, -0.08640758360293317F, 0.7181186541390187F));
        g.addOrReplaceChild("tanque_214", CubeListBuilder.create().texOffs(880, 63).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(24.0F, -29.848629333209978F, -0.7699866591800024F, -3.09092832121331F, -0.12074909882027315F, 1.1723482144337392F));
        g.addOrReplaceChild("tanque_215", CubeListBuilder.create().texOffs(132, 73).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.8F, -26.457407282861336F, -0.3235238063781523F, -3.128381604040396F, -0.1302351178347533F, 1.4694118931893136F));
        g.addOrReplaceChild("domo_0", CubeListBuilder.create().texOffs(830, 45).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(272, 0).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.ZERO);
        g.addOrReplaceChild("domo_1", CubeListBuilder.create().texOffs(854, 45).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(296, 0).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("domo_2", CubeListBuilder.create().texOffs(878, 45).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(320, 0).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("domo_3", CubeListBuilder.create().texOffs(902, 45).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(344, 0).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("domo_tapa", CubeListBuilder.create().texOffs(0, 0).addBox(-13.0F, 0.0F, -13.0F, 26.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -36.05F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("pasarela", CubeListBuilder.create().texOffs(524, 0).addBox(-5.0F, -34.0F, -4.0F, 10.0F, 1.0F, 8.0F), PartPose.ZERO);
        g.addOrReplaceChild("baranda_domo", CubeListBuilder.create().texOffs(154, 73).addBox(-5.0F, -38.0F, 3.5F, 10.0F, 1.0F, 1.0F).texOffs(100, 68).addBox(-5.5F, -37.0F, 3.5F, 1.0F, 3.0F, 1.0F).texOffs(104, 68).addBox(4.5F, -37.0F, 3.5F, 1.0F, 3.0F, 1.0F).texOffs(176, 73).addBox(-5.0F, -38.0F, -4.5F, 10.0F, 1.0F, 1.0F).texOffs(108, 68).addBox(-5.5F, -37.0F, -4.5F, 1.0F, 3.0F, 1.0F).texOffs(112, 68).addBox(4.5F, -37.0F, -4.5F, 1.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("escaleras", CubeListBuilder.create().texOffs(192, 0).addBox(-1.5F, -33.0F, -10.0F, 1.0F, 19.0F, 1.0F).texOffs(196, 0).addBox(0.5F, -33.0F, -10.0F, 1.0F, 19.0F, 1.0F).texOffs(200, 0).addBox(-1.5F, -33.0F, 9.0F, 1.0F, 19.0F, 1.0F).texOffs(204, 0).addBox(0.5F, -33.0F, 9.0F, 1.0F, 19.0F, 1.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "tanque_0", 0.44666113871648405F, 1.0F, 0.326315480550129F);
        escalar(g0, "tanque_1", 0.448352995042149F, 1.0F, 0.3883154218546534F);
        escalar(g0, "tanque_2", 0.48166378315169156F, 1.0F, 0.4281259104817692F);
        escalar(g0, "tanque_3", 0.43174066289845836F, 1.0F, 0.48294691121419087F);
        escalar(g0, "tanque_4", 0.5F, 1.0F, 0.49599953043619605F);
        escalar(g0, "tanque_5", 0.43174066289845836F, 1.0F, 0.48294691121419087F);
        escalar(g0, "tanque_6", 0.48166378315169106F, 1.0F, 0.4281259104817692F);
        escalar(g0, "tanque_7", 0.4483529950421495F, 1.0F, 0.3883154218546535F);
        escalar(g0, "tanque_8", 0.44666113871648405F, 1.0F, 0.326315480550129F);
        escalar(g0, "tanque_9", 0.44666113871648405F, 1.0F, 0.3263154805501287F);
        escalar(g0, "tanque_10", 0.4483529950421491F, 1.0F, 0.3883154218546534F);
        escalar(g0, "tanque_11", 0.4816637831516914F, 1.0F, 0.42812591048176907F);
        escalar(g0, "tanque_12", 0.43174066289845836F, 1.0F, 0.4829469112141906F);
        escalar(g0, "tanque_13", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_14", 0.43174066289845836F, 1.0F, 0.4829469112141906F);
        escalar(g0, "tanque_15", 0.4816637831516911F, 1.0F, 0.4281259104817693F);
        escalar(g0, "tanque_16", 0.4483529950421494F, 1.0F, 0.3883154218546536F);
        escalar(g0, "tanque_17", 0.44666113871648405F, 1.0F, 0.3263154805501287F);
        escalar(g0, "tanque_18", 0.446661138716484F, 1.0F, 0.3263154805501292F);
        escalar(g0, "tanque_19", 0.44835299504214915F, 1.0F, 0.38831542185465345F);
        escalar(g0, "tanque_20", 0.4816637831516914F, 1.0F, 0.4281259104817692F);
        escalar(g0, "tanque_21", 0.43174066289845836F, 1.0F, 0.48294691121419114F);
        escalar(g0, "tanque_22", 0.5F, 1.0F, 0.4959995304361965F);
        escalar(g0, "tanque_23", 0.43174066289845836F, 1.0F, 0.48294691121419114F);
        escalar(g0, "tanque_24", 0.4816637831516911F, 1.0F, 0.42812591048176907F);
        escalar(g0, "tanque_25", 0.4483529950421494F, 1.0F, 0.3883154218546533F);
        escalar(g0, "tanque_26", 0.446661138716484F, 1.0F, 0.3263154805501292F);
        escalar(g0, "tanque_27", 0.44666113871648405F, 1.0F, 0.326315480550129F);
        escalar(g0, "tanque_28", 0.44835299504214926F, 1.0F, 0.3883154218546533F);
        escalar(g0, "tanque_29", 0.4816637831516914F, 1.0F, 0.42812591048176907F);
        escalar(g0, "tanque_30", 0.43174066289845836F, 1.0F, 0.48294691121419114F);
        escalar(g0, "tanque_31", 0.5F, 1.0F, 0.49599953043619627F);
        escalar(g0, "tanque_32", 0.43174066289845836F, 1.0F, 0.48294691121419114F);
        escalar(g0, "tanque_33", 0.48166378315169106F, 1.0F, 0.42812591048176946F);
        escalar(g0, "tanque_34", 0.44835299504214954F, 1.0F, 0.3883154218546537F);
        escalar(g0, "tanque_35", 0.44666113871648405F, 1.0F, 0.326315480550129F);
        escalar(g0, "tanque_36", 0.446661138716484F, 1.0F, 0.32631548055012916F);
        escalar(g0, "tanque_37", 0.4483529950421493F, 1.0F, 0.3883154218546535F);
        escalar(g0, "tanque_38", 0.4816637831516912F, 1.0F, 0.428125910481769F);
        escalar(g0, "tanque_39", 0.43174066289845836F, 1.0F, 0.4829469112141904F);
        escalar(g0, "tanque_40", 0.5F, 1.0F, 0.4959995304361957F);
        escalar(g0, "tanque_41", 0.43174066289845836F, 1.0F, 0.4829469112141904F);
        escalar(g0, "tanque_42", 0.48166378315169106F, 1.0F, 0.428125910481769F);
        escalar(g0, "tanque_43", 0.4483529950421495F, 1.0F, 0.3883154218546535F);
        escalar(g0, "tanque_44", 0.446661138716484F, 1.0F, 0.32631548055012916F);
        escalar(g0, "tanque_45", 0.446661138716484F, 1.0F, 0.3263154805501287F);
        escalar(g0, "tanque_46", 0.44835299504214926F, 1.0F, 0.38831542185465373F);
        escalar(g0, "tanque_47", 0.48166378315169134F, 1.0F, 0.4281259104817698F);
        escalar(g0, "tanque_48", 0.43174066289845836F, 1.0F, 0.4829469112141913F);
        escalar(g0, "tanque_49", 0.5F, 1.0F, 0.49599953043619643F);
        escalar(g0, "tanque_50", 0.43174066289845836F, 1.0F, 0.4829469112141913F);
        escalar(g0, "tanque_51", 0.48166378315169106F, 1.0F, 0.4281259104817698F);
        escalar(g0, "tanque_52", 0.4483529950421495F, 1.0F, 0.38831542185465373F);
        escalar(g0, "tanque_53", 0.446661138716484F, 1.0F, 0.3263154805501287F);
        escalar(g0, "tanque_54", 0.446661138716484F, 1.0F, 0.3263154805501287F);
        escalar(g0, "tanque_55", 0.44835299504214926F, 1.0F, 0.3883154218546533F);
        escalar(g0, "tanque_56", 0.4816637831516912F, 1.0F, 0.4281259104817686F);
        escalar(g0, "tanque_57", 0.43174066289845836F, 1.0F, 0.48294691121418987F);
        escalar(g0, "tanque_58", 0.5F, 1.0F, 0.495999530436195F);
        escalar(g0, "tanque_59", 0.43174066289845836F, 1.0F, 0.48294691121418987F);
        escalar(g0, "tanque_60", 0.48166378315169106F, 1.0F, 0.4281259104817686F);
        escalar(g0, "tanque_61", 0.4483529950421495F, 1.0F, 0.3883154218546533F);
        escalar(g0, "tanque_62", 0.446661138716484F, 1.0F, 0.3263154805501287F);
        escalar(g0, "tanque_63", 0.446661138716484F, 1.0F, 0.3263154805501292F);
        escalar(g0, "tanque_64", 0.44835299504214926F, 1.0F, 0.3883154218546536F);
        escalar(g0, "tanque_65", 0.48166378315169134F, 1.0F, 0.42812591048176973F);
        escalar(g0, "tanque_66", 0.43174066289845836F, 1.0F, 0.48294691121419187F);
        escalar(g0, "tanque_67", 0.5F, 1.0F, 0.49599953043619693F);
        escalar(g0, "tanque_68", 0.43174066289845836F, 1.0F, 0.48294691121419187F);
        escalar(g0, "tanque_69", 0.48166378315169106F, 1.0F, 0.42812591048176973F);
        escalar(g0, "tanque_70", 0.4483529950421494F, 1.0F, 0.3883154218546536F);
        escalar(g0, "tanque_71", 0.446661138716484F, 1.0F, 0.3263154805501292F);
        escalar(g0, "tanque_72", 0.44666113871648405F, 1.0F, 0.326315480550129F);
        escalar(g0, "tanque_73", 0.4483529950421491F, 1.0F, 0.3883154218546537F);
        escalar(g0, "tanque_74", 0.4816637831516915F, 1.0F, 0.42812591048176946F);
        escalar(g0, "tanque_75", 0.43174066289845825F, 1.0F, 0.48294691121419087F);
        escalar(g0, "tanque_76", 0.5F, 1.0F, 0.4959995304361958F);
        escalar(g0, "tanque_77", 0.43174066289845825F, 1.0F, 0.48294691121419087F);
        escalar(g0, "tanque_78", 0.48166378315169134F, 1.0F, 0.42812591048176946F);
        escalar(g0, "tanque_79", 0.44835299504214937F, 1.0F, 0.3883154218546537F);
        escalar(g0, "tanque_80", 0.44666113871648405F, 1.0F, 0.326315480550129F);
        escalar(g0, "tanque_81", 0.44666113871648405F, 1.0F, 0.32631548055012893F);
        escalar(g0, "tanque_82", 0.44835299504214926F, 1.0F, 0.38831542185465306F);
        escalar(g0, "tanque_83", 0.4816637831516914F, 1.0F, 0.42812591048176873F);
        escalar(g0, "tanque_84", 0.4317406628984582F, 1.0F, 0.4829469112141904F);
        escalar(g0, "tanque_85", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_86", 0.4317406628984582F, 1.0F, 0.4829469112141904F);
        escalar(g0, "tanque_87", 0.48166378315169134F, 1.0F, 0.42812591048176885F);
        escalar(g0, "tanque_88", 0.44835299504214937F, 1.0F, 0.3883154218546532F);
        escalar(g0, "tanque_89", 0.44666113871648405F, 1.0F, 0.32631548055012893F);
        escalar(g0, "tanque_90", 0.44666113871648405F, 1.0F, 0.32631548055012877F);
        escalar(g0, "tanque_91", 0.44835299504214926F, 1.0F, 0.3883154218546535F);
        escalar(g0, "tanque_92", 0.48166378315169134F, 1.0F, 0.4281259104817692F);
        escalar(g0, "tanque_93", 0.43174066289845836F, 1.0F, 0.482946911214191F);
        escalar(g0, "tanque_94", 0.5F, 1.0F, 0.4959995304361963F);
        escalar(g0, "tanque_95", 0.43174066289845836F, 1.0F, 0.482946911214191F);
        escalar(g0, "tanque_96", 0.48166378315169106F, 1.0F, 0.42812591048176935F);
        escalar(g0, "tanque_97", 0.4483529950421495F, 1.0F, 0.38831542185465373F);
        escalar(g0, "tanque_98", 0.44666113871648405F, 1.0F, 0.32631548055012877F);
        escalar(g0, "tanque_99", 0.44666113871648405F, 1.0F, 0.3263154805501292F);
        escalar(g0, "tanque_100", 0.44835299504214904F, 1.0F, 0.38831542185465373F);
        escalar(g0, "tanque_101", 0.4816637831516914F, 1.0F, 0.42812591048176946F);
        escalar(g0, "tanque_102", 0.43174066289845836F, 1.0F, 0.48294691121419114F);
        escalar(g0, "tanque_103", 0.5F, 1.0F, 0.49599953043619627F);
        escalar(g0, "tanque_104", 0.43174066289845836F, 1.0F, 0.48294691121419114F);
        escalar(g0, "tanque_105", 0.48166378315169106F, 1.0F, 0.4281259104817695F);
        escalar(g0, "tanque_106", 0.4483529950421495F, 1.0F, 0.38831542185465373F);
        escalar(g0, "tanque_107", 0.44666113871648405F, 1.0F, 0.3263154805501292F);
        escalar(g0, "tanque_108", 0.44666113871648405F, 1.0F, 0.3263154805501286F);
        escalar(g0, "tanque_109", 0.44835299504214926F, 1.0F, 0.38831542185465295F);
        escalar(g0, "tanque_110", 0.48166378315169134F, 1.0F, 0.4281259104817686F);
        escalar(g0, "tanque_111", 0.43174066289845836F, 1.0F, 0.4829469112141903F);
        escalar(g0, "tanque_112", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_113", 0.43174066289845836F, 1.0F, 0.4829469112141903F);
        escalar(g0, "tanque_114", 0.48166378315169106F, 1.0F, 0.42812591048176873F);
        escalar(g0, "tanque_115", 0.4483529950421495F, 1.0F, 0.38831542185465306F);
        escalar(g0, "tanque_116", 0.44666113871648405F, 1.0F, 0.3263154805501286F);
        escalar(g0, "tanque_117", 0.4466611387164839F, 1.0F, 0.3263154805501286F);
        escalar(g0, "tanque_118", 0.4483529950421495F, 1.0F, 0.3883154218546532F);
        escalar(g0, "tanque_119", 0.4816637831516911F, 1.0F, 0.42812591048176885F);
        escalar(g0, "tanque_120", 0.43174066289845836F, 1.0F, 0.4829469112141903F);
        escalar(g0, "tanque_121", 0.5F, 1.0F, 0.49599953043619543F);
        escalar(g0, "tanque_122", 0.43174066289845836F, 1.0F, 0.4829469112141903F);
        escalar(g0, "tanque_123", 0.4816637831516911F, 1.0F, 0.42812591048176885F);
        escalar(g0, "tanque_124", 0.4483529950421495F, 1.0F, 0.38831542185465323F);
        escalar(g0, "tanque_125", 0.4466611387164839F, 1.0F, 0.3263154805501286F);
        escalar(g0, "tanque_126", 0.4466611387164839F, 1.0F, 0.3263154805501297F);
        escalar(g0, "tanque_127", 0.44835299504214937F, 1.0F, 0.38831542185465434F);
        escalar(g0, "tanque_128", 0.4816637831516914F, 1.0F, 0.42812591048177034F);
        escalar(g0, "tanque_129", 0.43174066289845825F, 1.0F, 0.48294691121419203F);
        escalar(g0, "tanque_130", 0.5F, 1.0F, 0.4959995304361972F);
        escalar(g0, "tanque_131", 0.43174066289845825F, 1.0F, 0.48294691121419203F);
        escalar(g0, "tanque_132", 0.4816637831516911F, 1.0F, 0.4281259104817702F);
        escalar(g0, "tanque_133", 0.44835299504214954F, 1.0F, 0.3883154218546542F);
        escalar(g0, "tanque_134", 0.4466611387164839F, 1.0F, 0.3263154805501297F);
        escalar(g0, "tanque_135", 0.446661138716484F, 1.0F, 0.3263154805501288F);
        escalar(g0, "tanque_136", 0.44835299504214915F, 1.0F, 0.3883154218546532F);
        escalar(g0, "tanque_137", 0.4816637831516915F, 1.0F, 0.4281259104817686F);
        escalar(g0, "tanque_138", 0.43174066289845836F, 1.0F, 0.4829469112141903F);
        escalar(g0, "tanque_139", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_140", 0.43174066289845836F, 1.0F, 0.4829469112141903F);
        escalar(g0, "tanque_141", 0.4816637831516911F, 1.0F, 0.4281259104817689F);
        escalar(g0, "tanque_142", 0.4483529950421495F, 1.0F, 0.3883154218546535F);
        escalar(g0, "tanque_143", 0.446661138716484F, 1.0F, 0.3263154805501288F);
        escalar(g0, "tanque_144", 0.446661138716484F, 1.0F, 0.3263154805501285F);
        escalar(g0, "tanque_145", 0.44835299504214926F, 1.0F, 0.38831542185465284F);
        escalar(g0, "tanque_146", 0.4816637831516914F, 1.0F, 0.42812591048176885F);
        escalar(g0, "tanque_147", 0.43174066289845836F, 1.0F, 0.48294691121419026F);
        escalar(g0, "tanque_148", 0.5F, 1.0F, 0.495999530436195F);
        escalar(g0, "tanque_149", 0.43174066289845836F, 1.0F, 0.48294691121419026F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "tanque_150", 0.4816637831516912F, 1.0F, 0.42812591048176873F);
        escalar(g0, "tanque_151", 0.4483529950421494F, 1.0F, 0.38831542185465284F);
        escalar(g0, "tanque_152", 0.446661138716484F, 1.0F, 0.3263154805501285F);
        escalar(g0, "tanque_153", 0.44666113871648405F, 1.0F, 0.32631548055012966F);
        escalar(g0, "tanque_154", 0.44835299504214926F, 1.0F, 0.3883154218546546F);
        escalar(g0, "tanque_155", 0.48166378315169134F, 1.0F, 0.4281259104817705F);
        escalar(g0, "tanque_156", 0.43174066289845836F, 1.0F, 0.4829469112141925F);
        escalar(g0, "tanque_157", 0.5F, 1.0F, 0.49599953043619793F);
        escalar(g0, "tanque_158", 0.43174066289845836F, 1.0F, 0.4829469112141925F);
        escalar(g0, "tanque_159", 0.4816637831516912F, 1.0F, 0.4281259104817705F);
        escalar(g0, "tanque_160", 0.4483529950421494F, 1.0F, 0.3883154218546546F);
        escalar(g0, "tanque_161", 0.44666113871648405F, 1.0F, 0.32631548055012966F);
        escalar(g0, "tanque_162", 0.446661138716484F, 1.0F, 0.3263154805501287F);
        escalar(g0, "tanque_163", 0.44835299504214915F, 1.0F, 0.38831542185465284F);
        escalar(g0, "tanque_164", 0.48166378315169134F, 1.0F, 0.4281259104817683F);
        escalar(g0, "tanque_165", 0.43174066289845836F, 1.0F, 0.48294691121418987F);
        escalar(g0, "tanque_166", 0.5F, 1.0F, 0.495999530436195F);
        escalar(g0, "tanque_167", 0.43174066289845836F, 1.0F, 0.48294691121418987F);
        escalar(g0, "tanque_168", 0.48166378315169106F, 1.0F, 0.4281259104817686F);
        escalar(g0, "tanque_169", 0.4483529950421495F, 1.0F, 0.3883154218546533F);
        escalar(g0, "tanque_170", 0.446661138716484F, 1.0F, 0.3263154805501287F);
        escalar(g0, "tanque_171", 0.446661138716484F, 1.0F, 0.32631548055012827F);
        escalar(g0, "tanque_172", 0.44835299504214926F, 1.0F, 0.388315421854653F);
        escalar(g0, "tanque_173", 0.4816637831516912F, 1.0F, 0.42812591048176885F);
        escalar(g0, "tanque_174", 0.43174066289845836F, 1.0F, 0.48294691121419026F);
        escalar(g0, "tanque_175", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_176", 0.43174066289845836F, 1.0F, 0.48294691121419026F);
        escalar(g0, "tanque_177", 0.48166378315169106F, 1.0F, 0.42812591048176846F);
        escalar(g0, "tanque_178", 0.4483529950421495F, 1.0F, 0.3883154218546526F);
        escalar(g0, "tanque_179", 0.446661138716484F, 1.0F, 0.32631548055012827F);
        escalar(g0, "tanque_180", 0.4466611387164839F, 1.0F, 0.3263154805501292F);
        escalar(g0, "tanque_181", 0.44835299504214926F, 1.0F, 0.38831542185465395F);
        escalar(g0, "tanque_182", 0.4816637831516914F, 1.0F, 0.42812591048176996F);
        escalar(g0, "tanque_183", 0.43174066289845825F, 1.0F, 0.48294691121419187F);
        escalar(g0, "tanque_184", 0.5F, 1.0F, 0.49599953043619693F);
        escalar(g0, "tanque_185", 0.43174066289845825F, 1.0F, 0.48294691121419187F);
        escalar(g0, "tanque_186", 0.48166378315169106F, 1.0F, 0.42812591048177023F);
        escalar(g0, "tanque_187", 0.4483529950421496F, 1.0F, 0.3883154218546543F);
        escalar(g0, "tanque_188", 0.4466611387164839F, 1.0F, 0.3263154805501292F);
        escalar(g0, "tanque_189", 0.4466611387164839F, 1.0F, 0.3263154805501295F);
        escalar(g0, "tanque_190", 0.44835299504214904F, 1.0F, 0.3883154218546534F);
        escalar(g0, "tanque_191", 0.4816637831516915F, 1.0F, 0.42812591048176885F);
        escalar(g0, "tanque_192", 0.43174066289845836F, 1.0F, 0.4829469112141904F);
        escalar(g0, "tanque_193", 0.5F, 1.0F, 0.4959995304361957F);
        escalar(g0, "tanque_194", 0.43174066289845836F, 1.0F, 0.4829469112141904F);
        escalar(g0, "tanque_195", 0.48166378315169095F, 1.0F, 0.4281259104817689F);
        escalar(g0, "tanque_196", 0.4483529950421495F, 1.0F, 0.3883154218546535F);
        escalar(g0, "tanque_197", 0.4466611387164839F, 1.0F, 0.3263154805501295F);
        escalar(g0, "tanque_198", 0.44666113871648405F, 1.0F, 0.32631548055012827F);
        escalar(g0, "tanque_199", 0.448352995042149F, 1.0F, 0.38831542185465306F);
        escalar(g0, "tanque_200", 0.4816637831516915F, 1.0F, 0.42812591048176885F);
        escalar(g0, "tanque_201", 0.43174066289845836F, 1.0F, 0.4829469112141904F);
        escalar(g0, "tanque_202", 0.5F, 1.0F, 0.49599953043619555F);
        escalar(g0, "tanque_203", 0.43174066289845836F, 1.0F, 0.4829469112141904F);
        escalar(g0, "tanque_204", 0.4816637831516912F, 1.0F, 0.42812591048176873F);
        escalar(g0, "tanque_205", 0.44835299504214926F, 1.0F, 0.38831542185465295F);
        escalar(g0, "tanque_206", 0.44666113871648405F, 1.0F, 0.32631548055012827F);
        escalar(g0, "tanque_207", 0.44666113871648405F, 1.0F, 0.3263154805501297F);
        escalar(g0, "tanque_208", 0.44835299504214904F, 1.0F, 0.3883154218546543F);
        escalar(g0, "tanque_209", 0.48166378315169156F, 1.0F, 0.4281259104817702F);
        escalar(g0, "tanque_210", 0.43174066289845836F, 1.0F, 0.48294691121419203F);
        escalar(g0, "tanque_211", 0.5F, 1.0F, 0.4959995304361972F);
        escalar(g0, "tanque_212", 0.43174066289845836F, 1.0F, 0.48294691121419203F);
        escalar(g0, "tanque_213", 0.4816637831516914F, 1.0F, 0.42812591048177023F);
        escalar(g0, "tanque_214", 0.44835299504214937F, 1.0F, 0.3883154218546544F);
        escalar(g0, "tanque_215", 0.44666113871648405F, 1.0F, 0.3263154805501297F);
        escalar(g0, "domo_0", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "domo_1", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "domo_2", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "domo_3", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "domo_tapa", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
    }
}
