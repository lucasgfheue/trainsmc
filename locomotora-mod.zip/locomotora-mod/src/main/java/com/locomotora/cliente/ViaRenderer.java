package com.locomotora.cliente;

import org.joml.Matrix4f;

import com.locomotora.LocomotoraMod;
import com.locomotora.via.DibujoVia;
import com.locomotora.via.ViaBlockEntity;
import com.locomotora.via.ViaDesvioBlock;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Dibuja la parte de una pieza de vía que le toca a cada bloque: durmientes, rieles redondos en las curvas, el
 * terraplén de las subidas y el poste del cambio. Las caras se calculan una sola vez por bloque (DibujoVia).
 */
public class ViaRenderer implements BlockEntityRenderer<ViaBlockEntity> {
    private static final ResourceLocation TEXTURA = LocomotoraMod.id("textures/block/via.png");

    public ViaRenderer(BlockEntityRendererProvider.Context contexto) {
    }

    @Override
    public void render(ViaBlockEntity via, float tickParcial, PoseStack pose, MultiBufferSource buffers, int luz,
                       int overlay) {
        BlockState estado = via.getBlockState();
        boolean desviado = estado.getBlock() instanceof ViaDesvioBlock && estado.getValue(ViaDesvioBlock.DESVIADO);
        float[] q = via.caras(desviado);
        if (q == null || q.length == 0) {
            return;
        }
        VertexConsumer vertices = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURA));
        PoseStack.Pose ultima = pose.last();
        Matrix4f matriz = ultima.pose();
        for (int o = 0; o < q.length; o += DibujoVia.POR_CARA) {
            float nx = q[o + 20];
            float ny = q[o + 21];
            float nz = q[o + 22];
            for (int k = 0; k < 4; k++) {
                int b = o + k * 5;
                vertices.addVertex(matriz, q[b], q[b + 1], q[b + 2])
                        .setColor(255, 255, 255, 255)
                        .setUv(q[b + 3], q[b + 4])
                        .setOverlay(overlay)
                        .setLight(luz)
                        .setNormal(ultima, nx, ny, nz);
            }
        }
    }

    /** Las vías se ven de lejos. */
    @Override
    public int getViewDistance() {
        return 128;
    }

    /** Lo dibujado asoma un poco a los bloques vecinos (y el poste del cambio queda al costado). */
    @Override
    public AABB getRenderBoundingBox(ViaBlockEntity via) {
        return new AABB(via.getBlockPos()).inflate(1.0);
    }
}
