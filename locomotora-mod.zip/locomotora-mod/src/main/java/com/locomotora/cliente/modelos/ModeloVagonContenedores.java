package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Portacontenedores" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonContenedores {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_contenedores"), "main"),
            LocomotoraMod.id("textures/entity/vagon_contenedores.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -54.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -54.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -54.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -54.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -54.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -54.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 54.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 54.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 54.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 54.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 54.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 54.0F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloVagonContenedores::crearCapa,
            16.0F,
            ModeloVagonContenedores::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -48.0F, 48.0F)));

    private ModeloVagonContenedores() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("plataforma", CubeListBuilder.create().texOffs(606, 94).addBox(-61.0F, -11.0F, -3.0F, 122.0F, 3.0F, 6.0F).texOffs(248, 118).addBox(-61.0F, -11.0F, 10.5F, 122.0F, 2.0F, 1.0F).texOffs(494, 118).addBox(-61.0F, -11.0F, -11.5F, 122.0F, 2.0F, 1.0F).texOffs(0, 94).addBox(-61.0F, -12.0F, -11.5F, 122.0F, 1.0F, 23.0F).texOffs(744, 0).addBox(-63.0F, -12.0F, -11.5F, 2.0F, 4.0F, 23.0F).texOffs(794, 0).addBox(61.0F, -12.0F, -11.5F, 2.0F, 4.0F, 23.0F).texOffs(868, 118).addBox(-55.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(872, 118).addBox(-55.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(876, 118).addBox(-47.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(880, 118).addBox(-47.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(884, 118).addBox(-39.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(888, 118).addBox(-39.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(892, 118).addBox(-31.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(896, 118).addBox(-31.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(900, 118).addBox(-23.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(904, 118).addBox(-23.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(908, 118).addBox(-15.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(912, 118).addBox(-15.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(916, 118).addBox(-7.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(920, 118).addBox(-7.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(924, 118).addBox(1.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(928, 118).addBox(1.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(932, 118).addBox(9.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(936, 118).addBox(9.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(940, 118).addBox(17.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(944, 118).addBox(17.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(948, 118).addBox(25.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(952, 118).addBox(25.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(956, 118).addBox(33.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(960, 118).addBox(33.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(964, 118).addBox(41.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(968, 118).addBox(41.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(972, 118).addBox(49.0F, -11.5F, 11.5F, 1.0F, 2.0F, 1.0F).texOffs(976, 118).addBox(49.0F, -11.5F, -12.5F, 1.0F, 2.0F, 1.0F).texOffs(386, 94).addBox(-49.5F, -8.0F, -9.0F, 3.0F, 1.0F, 18.0F).texOffs(428, 94).addBox(46.5F, -8.0F, -9.0F, 3.0F, 1.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("contenedor0", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -48.0F, 0.0F, 78.0F, 48.0F, 46.0F), PartPose.offset(-60.0F, -12.0F, -11.5F));
        g.addOrReplaceChild("contenedor0_marco", CubeListBuilder.create().texOffs(0, 123).addBox(-60.0F, -13.0F, 11.0F, 39.0F, 1.0F, 1.0F).texOffs(80, 123).addBox(-60.0F, -13.0F, -12.0F, 39.0F, 1.0F, 1.0F).texOffs(160, 123).addBox(-60.0F, -36.0F, 11.0F, 39.0F, 1.0F, 1.0F).texOffs(240, 123).addBox(-60.0F, -36.0F, -12.0F, 39.0F, 1.0F, 1.0F).texOffs(290, 94).addBox(-60.0F, -35.0F, 11.0F, 1.0F, 22.0F, 1.0F).texOffs(294, 94).addBox(-60.0F, -35.0F, -12.0F, 1.0F, 22.0F, 1.0F).texOffs(298, 94).addBox(-22.0F, -35.0F, 11.0F, 1.0F, 22.0F, 1.0F).texOffs(302, 94).addBox(-22.0F, -35.0F, -12.0F, 1.0F, 22.0F, 1.0F).texOffs(338, 94).addBox(-21.0F, -34.0F, -8.0F, 1.0F, 20.0F, 1.0F).texOffs(342, 94).addBox(-21.0F, -34.0F, -3.5F, 1.0F, 20.0F, 1.0F).texOffs(346, 94).addBox(-21.0F, -34.0F, 2.5F, 1.0F, 20.0F, 1.0F).texOffs(350, 94).addBox(-21.0F, -34.0F, 7.0F, 1.0F, 20.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("contenedor1", CubeListBuilder.create().texOffs(248, 0).addBox(0.0F, -48.0F, 0.0F, 78.0F, 48.0F, 46.0F), PartPose.offset(-19.5F, -12.0F, -11.5F));
        g.addOrReplaceChild("contenedor1_marco", CubeListBuilder.create().texOffs(320, 123).addBox(-19.5F, -13.0F, 11.0F, 39.0F, 1.0F, 1.0F).texOffs(400, 123).addBox(-19.5F, -13.0F, -12.0F, 39.0F, 1.0F, 1.0F).texOffs(480, 123).addBox(-19.5F, -36.0F, 11.0F, 39.0F, 1.0F, 1.0F).texOffs(560, 123).addBox(-19.5F, -36.0F, -12.0F, 39.0F, 1.0F, 1.0F).texOffs(306, 94).addBox(-19.5F, -35.0F, 11.0F, 1.0F, 22.0F, 1.0F).texOffs(310, 94).addBox(-19.5F, -35.0F, -12.0F, 1.0F, 22.0F, 1.0F).texOffs(314, 94).addBox(18.5F, -35.0F, 11.0F, 1.0F, 22.0F, 1.0F).texOffs(318, 94).addBox(18.5F, -35.0F, -12.0F, 1.0F, 22.0F, 1.0F).texOffs(354, 94).addBox(19.5F, -34.0F, -8.0F, 1.0F, 20.0F, 1.0F).texOffs(358, 94).addBox(19.5F, -34.0F, -3.5F, 1.0F, 20.0F, 1.0F).texOffs(362, 94).addBox(19.5F, -34.0F, 2.5F, 1.0F, 20.0F, 1.0F).texOffs(366, 94).addBox(19.5F, -34.0F, 7.0F, 1.0F, 20.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("contenedor2", CubeListBuilder.create().texOffs(496, 0).addBox(0.0F, -48.0F, 0.0F, 78.0F, 48.0F, 46.0F), PartPose.offset(21.0F, -12.0F, -11.5F));
        g.addOrReplaceChild("contenedor2_marco", CubeListBuilder.create().texOffs(640, 123).addBox(21.0F, -13.0F, 11.0F, 39.0F, 1.0F, 1.0F).texOffs(720, 123).addBox(21.0F, -13.0F, -12.0F, 39.0F, 1.0F, 1.0F).texOffs(800, 123).addBox(21.0F, -36.0F, 11.0F, 39.0F, 1.0F, 1.0F).texOffs(880, 123).addBox(21.0F, -36.0F, -12.0F, 39.0F, 1.0F, 1.0F).texOffs(322, 94).addBox(21.0F, -35.0F, 11.0F, 1.0F, 22.0F, 1.0F).texOffs(326, 94).addBox(21.0F, -35.0F, -12.0F, 1.0F, 22.0F, 1.0F).texOffs(330, 94).addBox(59.0F, -35.0F, 11.0F, 1.0F, 22.0F, 1.0F).texOffs(334, 94).addBox(59.0F, -35.0F, -12.0F, 1.0F, 22.0F, 1.0F).texOffs(370, 94).addBox(60.0F, -34.0F, -8.0F, 1.0F, 20.0F, 1.0F).texOffs(374, 94).addBox(60.0F, -34.0F, -3.5F, 1.0F, 20.0F, 1.0F).texOffs(378, 94).addBox(60.0F, -34.0F, 2.5F, 1.0F, 20.0F, 1.0F).texOffs(382, 94).addBox(60.0F, -34.0F, 7.0F, 1.0F, 20.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(862, 94).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(194, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(880, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 94).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-54.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(212, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(888, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(230, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(896, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(862, 94).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(194, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(880, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1002, 94).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-42.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(212, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(888, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(230, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(896, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(862, 94).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(194, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(880, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1012, 94).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-54.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(212, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(888, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(230, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(896, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(862, 94).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(194, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(880, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 118).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-42.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(212, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(888, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(230, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(896, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(10, 118).addBox(-55.5F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(20, 118).addBox(-43.5F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(740, 118).addBox(-55.5F, -7.0F, -8.0F, 15.0F, 2.0F, 1.0F).texOffs(960, 123).addBox(-51.0F, -2.0F, -8.0F, 6.0F, 1.0F, 1.0F).texOffs(936, 94).addBox(-50.5F, -5.0F, -8.5F, 5.0F, 3.0F, 2.0F).texOffs(30, 118).addBox(-55.5F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(40, 118).addBox(-43.5F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(772, 118).addBox(-55.5F, -7.0F, 7.0F, 15.0F, 2.0F, 1.0F).texOffs(974, 123).addBox(-51.0F, -2.0F, 7.0F, 6.0F, 1.0F, 1.0F).texOffs(950, 94).addBox(-50.5F, -5.0F, 6.5F, 5.0F, 3.0F, 2.0F).texOffs(534, 94).addBox(-50.0F, -7.0F, -7.0F, 4.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_cordonii", CubeListBuilder.create().texOffs(130, 118).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(-53.0F, -2.5F, -7.5F, 0.0F, 0.0F, -1.1071487177940904F));
        g.addOrReplaceChild("bogie0_cordonid", CubeListBuilder.create().texOffs(138, 118).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(-43.0F, -2.5F, -7.5F, 0.0F, 0.0F, 1.1071487177940904F));
        g.addOrReplaceChild("bogie0_cordondi", CubeListBuilder.create().texOffs(146, 118).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(-53.0F, -2.5F, 7.5F, 0.0F, 0.0F, -1.1071487177940904F));
        g.addOrReplaceChild("bogie0_cordondd", CubeListBuilder.create().texOffs(154, 118).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(-43.0F, -2.5F, 7.5F, 0.0F, 0.0F, 1.1071487177940904F));
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(862, 94).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(194, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(880, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 118).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(42.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(212, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(888, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(230, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(896, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(862, 94).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(194, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(880, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 118).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(54.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(212, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(888, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(54.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(230, 118).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(896, 94).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(54.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(862, 94).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(194, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(880, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 118).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(42.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(212, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(888, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(230, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(896, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(862, 94).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(194, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(880, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 118).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(54.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(212, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(888, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(54.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(230, 118).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(896, 94).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(54.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(90, 118).addBox(40.5F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(100, 118).addBox(52.5F, -5.0F, -8.5F, 3.0F, 3.0F, 2.0F).texOffs(804, 118).addBox(40.5F, -7.0F, -8.0F, 15.0F, 2.0F, 1.0F).texOffs(988, 123).addBox(45.0F, -2.0F, -8.0F, 6.0F, 1.0F, 1.0F).texOffs(964, 94).addBox(45.5F, -5.0F, -8.5F, 5.0F, 3.0F, 2.0F).texOffs(110, 118).addBox(40.5F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(120, 118).addBox(52.5F, -5.0F, 6.5F, 3.0F, 3.0F, 2.0F).texOffs(836, 118).addBox(40.5F, -7.0F, 7.0F, 15.0F, 2.0F, 1.0F).texOffs(1002, 123).addBox(45.0F, -2.0F, 7.0F, 6.0F, 1.0F, 1.0F).texOffs(978, 94).addBox(45.5F, -5.0F, 6.5F, 5.0F, 3.0F, 2.0F).texOffs(570, 94).addBox(46.0F, -7.0F, -7.0F, 4.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_cordonii", CubeListBuilder.create().texOffs(162, 118).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(43.0F, -2.5F, -7.5F, 0.0F, 0.0F, -1.1071487177940904F));
        g.addOrReplaceChild("bogie1_cordonid", CubeListBuilder.create().texOffs(170, 118).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(53.0F, -2.5F, -7.5F, 0.0F, 0.0F, 1.1071487177940904F));
        g.addOrReplaceChild("bogie1_cordondi", CubeListBuilder.create().texOffs(178, 118).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(43.0F, -2.5F, 7.5F, 0.0F, 0.0F, -1.1071487177940904F));
        g.addOrReplaceChild("bogie1_cordondd", CubeListBuilder.create().texOffs(186, 118).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F), PartPose.offsetAndRotation(53.0F, -2.5F, 7.5F, 0.0F, 0.0F, 1.1071487177940904F));
        g.addOrReplaceChild("puntai", CubeListBuilder.create().texOffs(904, 94).addBox(-68.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("puntad", CubeListBuilder.create().texOffs(920, 94).addBox(63.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("volante", CubeListBuilder.create().texOffs(470, 94).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(63.6F, -14.0F, 8.0F, 0.0F, 0.0F, -1.5707963267948966F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "contenedor0", 0.5F, 0.5F, 0.5F);
        escalar(g0, "contenedor1", 0.5F, 0.5F, 0.5F);
        escalar(g0, "contenedor2", 0.5F, 0.5F, 0.5F);
        escalar(g0, "bogie0_cordonii", 0.75F, 0.7453559924999299F, 0.75F);
        escalar(g0, "bogie0_cordonid", 0.75F, 0.7453559924999299F, 0.75F);
        escalar(g0, "bogie0_cordondi", 0.75F, 0.7453559924999299F, 0.75F);
        escalar(g0, "bogie0_cordondd", 0.75F, 0.7453559924999299F, 0.75F);
        escalar(g0, "bogie1_cordonii", 0.75F, 0.7453559924999299F, 0.75F);
        escalar(g0, "bogie1_cordonid", 0.75F, 0.7453559924999299F, 0.75F);
        escalar(g0, "bogie1_cordondi", 0.75F, 0.7453559924999299F, 0.75F);
        escalar(g0, "bogie1_cordondd", 0.75F, 0.7453559924999299F, 0.75F);
        escalar(g0, "volante", 0.25F, 0.6F, 0.25F);
    }
}
