package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "John Bull" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloJohnBull {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("john_bull"), "main"),
            LocomotoraMod.id("textures/entity/john_bull.png"),
            List.of(
                new DatosModelo.Animada("rpi0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.0F, -3.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rpi0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.0F, -3.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rpi0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.0F, -3.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rpd0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.0F, -3.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rpd0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.0F, -3.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rpd0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -24.0F, -3.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rli0_0", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, -4.0F, -6.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rli0_1", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, -4.0F, -6.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rli0_2", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, -4.0F, -6.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rld0_0", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, -4.0F, -6.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rld0_1", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, -4.0F, -6.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rld0_2", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, -4.0F, -6.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 9.5F, -6.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 9.5F, -6.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 9.5F, -6.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 9.5F, -6.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 9.5F, -6.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 9.5F, -6.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("cab_manometro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 14.719999999999999F, -21.8F, 0.0F, "locomotora", 4.8F, 0.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.0F, 0.0F, 16.0F, -12.0F, 0.0F, "locomotora", -0.22F, 5.5F, 0.0F),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 1.0471975511965976F, "tender")),
            ModeloJohnBull::crearCapa,
            16.0F,
            ModeloJohnBull::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -24.0F, 9.5F),
                new DatosModelo.Segmento("tender", 30.0F, 42.0F)));

    private ModeloJohnBull() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        piezas5(g1);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
        escalas2(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rpi0_0", CubeListBuilder.create().texOffs(198, 82).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(880, 91).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 82).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(592, 91).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-24.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rpi0_1", CubeListBuilder.create().texOffs(898, 91).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(224, 82).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rpi0_2", CubeListBuilder.create().texOffs(916, 91).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 82).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rpd0_0", CubeListBuilder.create().texOffs(198, 82).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(880, 91).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(216, 82).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(602, 91).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-24.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rpd0_1", CubeListBuilder.create().texOffs(898, 91).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(224, 82).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rpd0_2", CubeListBuilder.create().texOffs(916, 91).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(232, 82).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-24.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rli0_0", CubeListBuilder.create().texOffs(486, 65).addBox(-6.0F, -6.0F, -6.0F, 12.0F, 12.0F, 2.0F).texOffs(236, 91).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(558, 65).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(612, 91).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-4.0F, -6.0F, 0.0F));
        g.addOrReplaceChild("rli0_1", CubeListBuilder.create().texOffs(264, 91).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(568, 65).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rli0_2", CubeListBuilder.create().texOffs(292, 91).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(578, 65).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rld0_0", CubeListBuilder.create().texOffs(486, 65).addBox(-6.0F, -6.0F, 4.0F, 12.0F, 12.0F, 2.0F).texOffs(236, 91).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(558, 65).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(622, 91).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-4.0F, -6.0F, 0.0F));
        g.addOrReplaceChild("rld0_1", CubeListBuilder.create().texOffs(264, 91).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(568, 65).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rld0_2", CubeListBuilder.create().texOffs(292, 91).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(578, 65).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-4.0F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(514, 65).addBox(-6.0F, -6.0F, -6.0F, 12.0F, 12.0F, 2.0F).texOffs(320, 91).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(588, 65).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(632, 91).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(9.5F, -6.0F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(348, 91).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(598, 65).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(9.5F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(376, 91).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(608, 65).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(9.5F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(514, 65).addBox(-6.0F, -6.0F, 4.0F, 12.0F, 12.0F, 2.0F).texOffs(320, 91).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(588, 65).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(642, 91).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(9.5F, -6.0F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(348, 91).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(598, 65).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(9.5F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(376, 91).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(608, 65).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(9.5F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(698, 82).addBox(-19.0F, -12.0F, 2.0F, 34.0F, 5.0F, 1.0F).texOffs(768, 82).addBox(-19.0F, -12.0F, -3.0F, 34.0F, 5.0F, 1.0F).texOffs(38, 43).addBox(-20.0F, -12.0F, -8.0F, 2.0F, 5.0F, 16.0F).texOffs(184, 91).addBox(-6.0F, -8.5F, 3.0F, 4.0F, 5.0F, 1.0F).texOffs(194, 91).addBox(-6.0F, -8.5F, -4.0F, 4.0F, 5.0F, 1.0F).texOffs(168, 110).addBox(-9.0F, -9.5F, 3.0F, 10.0F, 1.0F, 1.0F).texOffs(190, 110).addBox(-9.0F, -9.5F, -4.0F, 10.0F, 1.0F, 1.0F).texOffs(204, 91).addBox(7.5F, -8.5F, 3.0F, 4.0F, 5.0F, 1.0F).texOffs(214, 91).addBox(7.5F, -8.5F, -4.0F, 4.0F, 5.0F, 1.0F).texOffs(212, 110).addBox(4.5F, -9.5F, 3.0F, 10.0F, 1.0F, 1.0F).texOffs(234, 110).addBox(4.5F, -9.5F, -4.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("carrito", CubeListBuilder.create().texOffs(548, 91).addBox(-29.0F, -8.0F, 2.0F, 10.0F, 4.0F, 1.0F).texOffs(570, 91).addBox(-29.0F, -8.0F, -3.0F, 10.0F, 4.0F, 1.0F).texOffs(148, 97).addBox(-25.5F, -5.0F, 3.0F, 3.0F, 3.0F, 1.0F).texOffs(156, 97).addBox(-25.5F, -5.0F, -4.0F, 3.0F, 3.0F, 1.0F).texOffs(408, 65).addBox(-29.0F, -11.0F, -6.0F, 1.0F, 3.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("quitapiedrasi_0", CubeListBuilder.create().texOffs(410, 82).addBox(-5.5F, -1.0F, -3.0F, 11.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-34.426249999999996F, -3.25F, -1.0F, -2.456677207160022F, -0.14901089190131986F, -1.1194056115011917F));
        g.addOrReplaceChild("quitapiedrasi_1", CubeListBuilder.create().texOffs(938, 82).addBox(-5.5F, -1.0F, -2.5F, 11.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.52875F, -7.75F, -1.0F, -2.666864030062905F, 0.0F, -0.9987291454265022F));
        g.addOrReplaceChild("quitapiedrasi_2", CubeListBuilder.create().texOffs(444, 82).addBox(-5.5F, -1.0F, -3.0F, 11.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-32.51875F, -3.25F, -3.0F, -2.427745140522718F, -0.11734308872754741F, -1.214906308154413F));
        g.addOrReplaceChild("quitapiedrasi_3", CubeListBuilder.create().texOffs(970, 82).addBox(-5.5F, -1.0F, -2.5F, 11.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-30.30625F, -7.75F, -3.0F, -2.639875021737545F, 0.0F, -1.1138375812477632F));
        g.addOrReplaceChild("quitapiedrasi_4", CubeListBuilder.create().texOffs(546, 82).addBox(-5.0F, -1.0F, -3.0F, 10.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-30.61125F, -3.25F, -5.0F, -2.403927875550567F, -0.08293164548010526F, -1.3186974297490286F));
        g.addOrReplaceChild("quitapiedrasi_5", CubeListBuilder.create().texOffs(64, 91).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-29.083749999999995F, -7.75F, -5.0F, -2.6168976964670407F, 0.0F, -1.2435558924327361F));
        g.addOrReplaceChild("quitapiedrasi_6", CubeListBuilder.create().texOffs(578, 82).addBox(-5.0F, -1.0F, -3.0F, 10.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-28.70375F, -3.25F, -7.0F, -2.3874495563233498F, -0.0464406365788926F, -1.4292981625614634F));
        g.addOrReplaceChild("quitapiedrasi_7", CubeListBuilder.create().texOffs(94, 91).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-27.86125F, -7.75F, -7.0F, -2.600066963902324F, -0.04119367873853535F, -1.4104828830734597F));
        g.addOrReplaceChild("quitapiedrasd_0", CubeListBuilder.create().texOffs(478, 82).addBox(-5.5F, -1.0F, -3.0F, 11.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-34.426249999999996F, -3.25F, 1.0F, 2.456677207160022F, 0.14901089190131986F, -1.1194056115011917F));
        g.addOrReplaceChild("quitapiedrasd_1", CubeListBuilder.create().texOffs(0, 91).addBox(-5.5F, -1.0F, -2.5F, 11.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-31.52875F, -7.75F, 1.0F, 2.666864030062905F, 0.0F, -0.9987291454265022F));
        g.addOrReplaceChild("quitapiedrasd_2", CubeListBuilder.create().texOffs(512, 82).addBox(-5.5F, -1.0F, -3.0F, 11.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-32.51875F, -3.25F, 3.0F, 2.427745140522718F, 0.11734308872754741F, -1.214906308154413F));
        g.addOrReplaceChild("quitapiedrasd_3", CubeListBuilder.create().texOffs(32, 91).addBox(-5.5F, -1.0F, -2.5F, 11.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-30.30625F, -7.75F, 3.0F, 2.639875021737545F, 0.0F, -1.1138375812477632F));
        g.addOrReplaceChild("quitapiedrasd_4", CubeListBuilder.create().texOffs(610, 82).addBox(-5.0F, -1.0F, -3.0F, 10.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-30.61125F, -3.25F, 5.0F, 2.403927875550567F, 0.08293164548010526F, -1.3186974297490286F));
        g.addOrReplaceChild("quitapiedrasd_5", CubeListBuilder.create().texOffs(124, 91).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-29.083749999999995F, -7.75F, 5.0F, 2.6168976964670407F, 0.0F, -1.2435558924327361F));
        g.addOrReplaceChild("quitapiedrasd_6", CubeListBuilder.create().texOffs(642, 82).addBox(-5.0F, -1.0F, -3.0F, 10.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-28.70375F, -3.25F, 7.0F, 2.3874495563233498F, 0.0464406365788926F, -1.4292981625614634F));
        g.addOrReplaceChild("quitapiedrasd_7", CubeListBuilder.create().texOffs(154, 91).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-27.86125F, -7.75F, 7.0F, 2.600066963902324F, 0.04119367873853535F, -1.4104828830734597F));
        g.addOrReplaceChild("estribo", CubeListBuilder.create().texOffs(236, 43).addBox(14.0F, -12.0F, -8.0F, 7.0F, 1.0F, 16.0F).texOffs(240, 82).addBox(20.0F, -20.0F, 7.0F, 1.0F, 8.0F, 1.0F).texOffs(244, 82).addBox(20.0F, -20.0F, -8.0F, 1.0F, 8.0F, 1.0F).texOffs(378, 65).addBox(20.0F, -20.0F, -7.0F, 1.0F, 1.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_humo", CubeListBuilder.create().texOffs(962, 0).addBox(-18.0F, -23.0F, -5.5F, 5.0F, 12.0F, 11.0F).texOffs(542, 65).addBox(-19.0F, -20.0F, -3.5F, 1.0F, 7.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(468, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -21.923333109150406F, 0.5823428514806717F, 3.0106929596902186F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(482, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -21.923333109150406F, 0.5823428514806717F, 3.0106929596902186F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(496, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -21.923333109150406F, 0.5823428514806717F, 3.0106929596902186F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(510, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -21.923333109150406F, 0.5823428514806717F, 3.0106929596902186F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(524, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -21.621890267665393F, 1.7073428514806714F, 2.748893571891069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(538, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -21.621890267665393F, 1.7073428514806714F, 2.748893571891069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(552, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -21.621890267665393F, 1.7073428514806714F, 2.748893571891069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(566, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -21.621890267665393F, 1.7073428514806714F, 2.748893571891069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(580, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -21.039547416184718F, 2.7159902576697315F, 2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(594, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -21.039547416184718F, 2.7159902576697315F, 2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(608, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -21.039547416184718F, 2.7159902576697315F, 2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(622, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -21.039547416184718F, 2.7159902576697315F, 2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(636, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -20.21599025766973F, 3.5395474161847185F, 2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(650, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -20.21599025766973F, 3.5395474161847185F, 2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(664, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -20.21599025766973F, 3.5395474161847185F, 2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(678, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -20.21599025766973F, 3.5395474161847185F, 2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(692, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -19.20734285148067F, 4.12189026766539F, 1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(706, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -19.20734285148067F, 4.12189026766539F, 1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(720, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -19.20734285148067F, 4.12189026766539F, 1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(734, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -19.20734285148067F, 4.12189026766539F, 1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(748, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -18.08234285148067F, 4.423333109150404F, 1.701696020694472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(762, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -18.08234285148067F, 4.423333109150404F, 1.701696020694472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(776, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -18.08234285148067F, 4.423333109150404F, 1.701696020694472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(790, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -18.08234285148067F, 4.423333109150404F, 1.701696020694472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(804, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -16.91765714851933F, 4.423333109150404F, 1.439896632895322F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(818, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -16.91765714851933F, 4.423333109150404F, 1.439896632895322F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(832, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -16.91765714851933F, 4.423333109150404F, 1.439896632895322F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(846, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -16.91765714851933F, 4.423333109150404F, 1.439896632895322F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(860, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -15.792657148519329F, 4.121890267665391F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(874, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -15.792657148519329F, 4.121890267665391F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(888, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -15.792657148519329F, 4.121890267665391F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(902, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -15.792657148519329F, 4.121890267665391F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(916, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -14.78400974233027F, 3.5395474161847194F, 0.9162978572970236F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(930, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -14.78400974233027F, 3.5395474161847194F, 0.9162978572970236F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(944, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -14.78400974233027F, 3.5395474161847194F, 0.9162978572970236F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(958, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -14.78400974233027F, 3.5395474161847194F, 0.9162978572970236F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(972, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -13.96045258381528F, 2.715990257669733F, 0.6544984694978736F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(986, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -13.96045258381528F, 2.715990257669733F, 0.6544984694978736F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(1000, 101).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -13.96045258381528F, 2.715990257669733F, 0.6544984694978736F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(0, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -13.96045258381528F, 2.715990257669733F, 0.6544984694978736F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(14, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -13.378109732334607F, 1.707342851480673F, 0.39269908169872425F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(28, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -13.378109732334607F, 1.707342851480673F, 0.39269908169872425F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(42, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -13.378109732334607F, 1.707342851480673F, 0.39269908169872425F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(56, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -13.378109732334607F, 1.707342851480673F, 0.39269908169872425F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(70, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -13.076666890849596F, 0.5823428514806726F, 0.1308996938995744F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(84, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -13.076666890849596F, 0.5823428514806726F, 0.1308996938995744F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(98, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -13.076666890849596F, 0.5823428514806726F, 0.1308996938995744F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(112, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -13.076666890849596F, 0.5823428514806726F, 0.1308996938995744F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(126, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -13.076666890849594F, -0.5823428514806706F, -0.13089969389957465F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(140, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -13.076666890849594F, -0.5823428514806706F, -0.13089969389957465F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(154, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -13.076666890849594F, -0.5823428514806706F, -0.13089969389957465F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(168, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -13.076666890849594F, -0.5823428514806706F, -0.13089969389957465F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(182, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -13.378109732334607F, -1.7073428514806694F, -0.3926990816987232F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(196, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -13.378109732334607F, -1.7073428514806694F, -0.3926990816987232F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(210, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -13.378109732334607F, -1.7073428514806694F, -0.3926990816987232F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(224, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -13.378109732334607F, -1.7073428514806694F, -0.3926990816987232F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(238, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -13.960452583815279F, -2.7159902576697306F, -0.6544984694978729F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(252, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -13.960452583815279F, -2.7159902576697306F, -0.6544984694978729F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(266, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -13.960452583815279F, -2.7159902576697306F, -0.6544984694978729F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(280, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -13.960452583815279F, -2.7159902576697306F, -0.6544984694978729F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(294, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -14.784009742330266F, -3.539547416184718F, -0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(308, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -14.784009742330266F, -3.539547416184718F, -0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(322, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -14.784009742330266F, -3.539547416184718F, -0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(336, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -14.784009742330266F, -3.539547416184718F, -0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(350, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -15.792657148519325F, -4.12189026766539F, -1.1780972450961715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(364, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -15.792657148519325F, -4.12189026766539F, -1.1780972450961715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(378, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -15.792657148519325F, -4.12189026766539F, -1.1780972450961715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(392, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -15.792657148519325F, -4.12189026766539F, -1.1780972450961715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(406, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -16.917657148519325F, -4.423333109150404F, -1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(420, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -16.917657148519325F, -4.423333109150404F, -1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(434, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -16.917657148519325F, -4.423333109150404F, -1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(448, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -16.917657148519325F, -4.423333109150404F, -1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(462, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -18.08234285148067F, -4.423333109150404F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(476, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -18.08234285148067F, -4.423333109150404F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(490, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -18.08234285148067F, -4.423333109150404F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(504, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -18.08234285148067F, -4.423333109150404F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(518, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -19.207342851480668F, -4.121890267665392F, -1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(532, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -19.207342851480668F, -4.121890267665392F, -1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(546, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -19.207342851480668F, -4.121890267665392F, -1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(560, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -19.207342851480668F, -4.121890267665392F, -1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(574, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -20.21599025766973F, -3.5395474161847202F, -2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(588, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -20.21599025766973F, -3.5395474161847202F, -2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(602, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -20.21599025766973F, -3.5395474161847202F, -2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(616, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -20.21599025766973F, -3.5395474161847202F, -2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(630, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -21.039547416184718F, -2.7159902576697332F, -2.487094184091917F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(644, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -21.039547416184718F, -2.7159902576697332F, -2.487094184091917F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(658, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -21.039547416184718F, -2.7159902576697332F, -2.487094184091917F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(672, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -21.039547416184718F, -2.7159902576697332F, -2.487094184091917F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(686, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -21.621890267665393F, -1.7073428514806746F, -2.7488935718910685F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(700, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -21.621890267665393F, -1.7073428514806746F, -2.7488935718910685F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(714, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -21.621890267665393F, -1.7073428514806746F, -2.7488935718910685F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(728, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -21.621890267665393F, -1.7073428514806746F, -2.7488935718910685F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(742, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.625F, -21.923333109150406F, -0.5823428514806741F, -3.010692959690219F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(756, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.875F, -21.923333109150406F, -0.5823428514806741F, -3.010692959690219F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(770, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.125F, -21.923333109150406F, -0.5823428514806741F, -3.010692959690219F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(784, 104).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.625F, -21.923333109150406F, -0.5823428514806741F, -3.010692959690219F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar", CubeListBuilder.create().texOffs(0, 43).addBox(6.0F, -20.0F, -5.5F, 8.0F, 11.0F, 11.0F), PartPose.ZERO);
        g.addOrReplaceChild("hogar_techo_0", CubeListBuilder.create().texOffs(552, 0).addBox(6.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(0, 0).addBox(6.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offset(0.0F, -20.0F, 0.0F));
        g.addOrReplaceChild("hogar_techo_1", CubeListBuilder.create().texOffs(578, 0).addBox(6.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(92, 0).addBox(6.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -20.0F, 0.0F, 0.2617993877991494F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_techo_2", CubeListBuilder.create().texOffs(604, 0).addBox(6.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(184, 0).addBox(6.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -20.0F, 0.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_techo_3", CubeListBuilder.create().texOffs(630, 0).addBox(6.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(276, 0).addBox(6.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -20.0F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_techo_4", CubeListBuilder.create().texOffs(656, 0).addBox(6.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(368, 0).addBox(6.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -20.0F, 0.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_techo_5", CubeListBuilder.create().texOffs(682, 0).addBox(6.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(460, 0).addBox(6.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -20.0F, 0.0F, 1.3089969389957472F, 0.0F, 0.0F));
        g.addOrReplaceChild("domo_0", CubeListBuilder.create().texOffs(934, 91).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.923498092462946F, -24.932673587904816F, 0.5743913461694128F, 0.06161837741871146F, 0.0056176218249428585F, -1.6144134946399273F));
        g.addOrReplaceChild("domo_1", CubeListBuilder.create().texOffs(28, 97).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.762404530165227F, -26.512133826025735F, 0.5427406506050932F, 0.06062744970392367F, 0.023695618121345758F, -1.7558191230201037F));
        g.addOrReplaceChild("domo_2", CubeListBuilder.create().texOffs(1002, 104).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.444084492749944F, -27.66357051707272F, 0.48019904153921344F, 0.057405384728823686F, 0.047127514981641146F, -1.945695505861802F));
        g.addOrReplaceChild("domo_3", CubeListBuilder.create().texOffs(390, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.974355768372542F, -28.535188658655052F, 0.3879095630459085F, 0.04950725970421888F, 0.07670230987923679F, -2.210566295052713F));
        g.addOrReplaceChild("domo_4", CubeListBuilder.create().texOffs(398, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.353828427001517F, -29.125856218549494F, 0.2659920780084023F, 0.03325170565720033F, 0.10795943574145579F, -2.5729050388136F));
        g.addOrReplaceChild("domo_5", CubeListBuilder.create().texOffs(798, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.781784818147646F, -24.932673587904816F, 1.4851211093420746F, 0.30570048406414707F, 0.02205740896525325F, -1.6121305967228157F));
        g.addOrReplaceChild("domo_6", CubeListBuilder.create().texOffs(1012, 104).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.62850008467837F, -26.512133826025735F, 1.4032864570246169F, 0.3008584845646508F, 0.07569902691129386F, -1.7517065048377791F));
        g.addOrReplaceChild("domo_7", CubeListBuilder.create().texOffs(0, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.325610252228358F, -27.66357051707272F, 1.2415816116167215F, 0.28516283846667984F, 0.15013248354026582F, -1.9379373362699126F));
        g.addOrReplaceChild("domo_8", CubeListBuilder.create().texOffs(266, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.87865109823073F, -28.535188658655052F, 1.0029619778171668F, 0.24647968184568636F, 0.2428657474549064F, -2.1996336308044273F));
        g.addOrReplaceChild("domo_9", CubeListBuilder.create().texOffs(272, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.288203120200002F, -29.125856218549494F, 0.6877374678474536F, 0.17139549188903067F, 0.41669073855956523F, -2.5482075291525135F));
        g.addOrReplaceChild("domo_10", CubeListBuilder.create().texOffs(810, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.498551889092255F, -24.932673587904816F, 2.071510061440333F, 0.6154734191343038F, 0.030766969388579216F, -1.6079261519263603F));
        g.addOrReplaceChild("domo_11", CubeListBuilder.create().texOffs(10, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.360874144257306F, -26.512133826025735F, 1.9573636092865516F, 0.607253042407703F, 0.12969486379049386F, -1.7287670293598383F));
        g.addOrReplaceChild("domo_12", CubeListBuilder.create().texOffs(20, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.088823639805009F, -27.66357051707272F, 1.7318108162254486F, 0.5800709446602641F, 0.25746003250309535F, -1.8939765132403872F));
        g.addOrReplaceChild("domo_13", CubeListBuilder.create().texOffs(278, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.68737251702856F, -28.535188658655052F, 1.3989740063763398F, 0.5105379024406755F, 0.41754365084356243F, -2.135403261667096F));
        g.addOrReplaceChild("domo_14", CubeListBuilder.create().texOffs(284, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.157042168938682F, -29.125856218549494F, 0.9592854584813193F, 0.3550900927212229F, 0.5854406980720018F, -2.497498804265584F));
        g.addOrReplaceChild("domo_15", CubeListBuilder.create().texOffs(822, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.071510061440334F, -24.932673587904816F, 2.4985518890922522F, 0.9541801910117015F, 0.037112244778645075F, -1.6015845030098779F));
        g.addOrReplaceChild("domo_16", CubeListBuilder.create().texOffs(30, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.957363609286553F, -26.512133826025735F, 2.3608741442573047F, 0.9429439382631463F, 0.1566329651591277F, -1.702107822155373F));
        g.addOrReplaceChild("domo_17", CubeListBuilder.create().texOffs(40, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.731810816225448F, -27.66357051707272F, 2.088823639805007F, 0.9056515184337578F, 0.3121611933388229F, -1.8416515052315F));
        g.addOrReplaceChild("domo_18", CubeListBuilder.create().texOffs(290, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.39897400637634F, -28.535188658655052F, 1.6873725170285596F, 0.8088447057408326F, 0.5110731634524277F, -2.054345478909568F));
        g.addOrReplaceChild("domo_19", CubeListBuilder.create().texOffs(296, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.959285458481318F, -29.125856218549494F, 1.1570421689386832F, 0.5813250234411814F, 0.7294750795710219F, -2.4056207602139263F));
        g.addOrReplaceChild("domo_20", CubeListBuilder.create().texOffs(834, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.485121109342076F, -24.932673587904816F, 2.781784818147645F, 1.2641836704680942F, 0.041324209441002874F, -1.592872585842855F));
        g.addOrReplaceChild("domo_21", CubeListBuilder.create().texOffs(50, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.403286457024617F, -26.512133826025735F, 2.628500084678369F, 1.2561058353230619F, 0.18038638482594815F, -1.647746320261868F));
        g.addOrReplaceChild("domo_22", CubeListBuilder.create().texOffs(60, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.241581611616722F, -27.66357051707272F, 2.325610252228358F, 1.2281758501414388F, 0.36281857830146547F, -1.7314708297566268F));
        g.addOrReplaceChild("domo_23", CubeListBuilder.create().texOffs(302, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.002961977817167F, -28.535188658655052F, 1.8786510982307303F, 1.1511549580175457F, 0.6076536437134648F, -1.8680768328286557F));
        g.addOrReplaceChild("domo_24", CubeListBuilder.create().texOffs(308, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.687737467847453F, -29.125856218549494F, 1.288203120200003F, 0.8589215080426184F, 0.8604150593584396F, -2.240360943844688F));
        g.addOrReplaceChild("domo_25", CubeListBuilder.create().texOffs(948, 91).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.574391346176036F, -24.932673587904816F, 2.9234980924629466F, 1.5089327704145266F, 0.04361647918187938F, -1.5764192963892796F));
        g.addOrReplaceChild("domo_26", CubeListBuilder.create().texOffs(40, 97).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.54274065061135F, -26.512133826025735F, 2.7624045301652265F, 1.5057343678764026F, 0.18497025446223095F, -1.594903245086091F));
        g.addOrReplaceChild("domo_27", CubeListBuilder.create().texOffs(70, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.48019904154475F, -27.66357051707272F, 2.4440844927499423F, 1.4948547744106366F, 0.37446230394649394F, -1.6214356175201035F));
        g.addOrReplaceChild("domo_28", CubeListBuilder.create().texOffs(406, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.387909563050382F, -28.535188658655052F, 1.9743557683725401F, 1.4643259013146364F, 0.637583703056722F, -1.6663038102818797F));
        g.addOrReplaceChild("domo_29", CubeListBuilder.create().texOffs(414, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.265992078011468F, -29.125856218549494F, 1.3538284270015162F, 1.3705238883639164F, 0.9930632371490359F, -1.7693976890763865F));
        g.addOrReplaceChild("domo_30", CubeListBuilder.create().texOffs(962, 91).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(9.425608653837209F, -24.932673587904816F, 2.923498092462947F, 1.6326598831738435F, 0.043616479181871136F, -1.5651733572006439F));
        g.addOrReplaceChild("domo_31", CubeListBuilder.create().texOffs(52, 97).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(9.457259349401165F, -26.512133826025735F, 2.7624045301652265F, 1.6358582857118928F, 0.18497025446219914F, -1.5466894085042595F));
        g.addOrReplaceChild("domo_32", CubeListBuilder.create().texOffs(80, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.519800958466323F, -27.66357051707272F, 2.4440844927499423F, 1.6467378791774059F, 0.3744623039464495F, -1.5201570360708596F));
        g.addOrReplaceChild("domo_33", CubeListBuilder.create().texOffs(422, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.612090436958564F, -28.535188658655052F, 1.9743557683725403F, 1.6772667522727067F, 0.6375837030567315F, -1.475288843310108F));
        g.addOrReplaceChild("domo_34", CubeListBuilder.create().texOffs(430, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.734007921994664F, -29.125856218549494F, 1.3538284270015164F, 1.7710687652213657F, 0.9930632371493598F, -1.3721949645178706F));
        g.addOrReplaceChild("domo_35", CubeListBuilder.create().texOffs(846, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.514878890657926F, -24.932673587904816F, 2.7817848181476457F, 1.8774089831216993F, 0.04132420944100299F, -1.5487200677469384F));
        g.addOrReplaceChild("domo_36", CubeListBuilder.create().texOffs(90, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.596713542975383F, -26.512133826025735F, 2.628500084678369F, 1.885486818266731F, 0.18038638482594788F, -1.4938463333279255F));
        g.addOrReplaceChild("domo_37", CubeListBuilder.create().texOffs(100, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.75841838838328F, -27.66357051707272F, 2.3256102522283584F, 1.913416803448354F, 0.36281857830146563F, -1.4101218238331665F));
        g.addOrReplaceChild("domo_38", CubeListBuilder.create().texOffs(314, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.997038022182833F, -28.535188658655052F, 1.8786510982307305F, 1.9904376955722474F, 0.6076536437134648F, -1.2735158207611381F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("domo_39", CubeListBuilder.create().texOffs(320, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.312262532152547F, -29.125856218549494F, 1.2882031202000033F, 2.2826711455471753F, 0.8604150593584396F, -0.9012317097451051F));
        g.addOrReplaceChild("domo_40", CubeListBuilder.create().texOffs(858, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.928489938559668F, -24.932673587904816F, 2.4985518890922527F, 2.1874124625780906F, 0.03711224477864519F, -1.5400081505799152F));
        g.addOrReplaceChild("domo_41", CubeListBuilder.create().texOffs(110, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.042636390713449F, -26.512133826025735F, 2.360874144257305F, 2.1986487153266463F, 0.15663296515912753F, -1.439484831434421F));
        g.addOrReplaceChild("domo_42", CubeListBuilder.create().texOffs(120, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.268189183774552F, -27.66357051707272F, 2.0888236398050073F, 2.2359411351560357F, 0.31216119333882325F, -1.2999411483582937F));
        g.addOrReplaceChild("domo_43", CubeListBuilder.create().texOffs(326, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.601025993623661F, -28.535188658655052F, 1.6873725170285598F, 2.3327479478489606F, 0.5110731634524278F, -1.087247174680225F));
        g.addOrReplaceChild("domo_44", CubeListBuilder.create().texOffs(332, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.040714541518682F, -29.125856218549494F, 1.1570421689386832F, 2.560267630148612F, 0.7294750795710219F, -0.7359718933758669F));
        g.addOrReplaceChild("domo_45", CubeListBuilder.create().texOffs(870, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.501448110907748F, -24.932673587904816F, 2.0715100614403337F, 2.5261192344554884F, 0.030766969388579216F, -1.5336665016634328F));
        g.addOrReplaceChild("domo_46", CubeListBuilder.create().texOffs(130, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.639125855742695F, -26.512133826025735F, 1.9573636092865525F, 2.534339611182089F, 0.12969486379049386F, -1.4128256242299553F));
        g.addOrReplaceChild("domo_47", CubeListBuilder.create().texOffs(140, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.911176360194993F, -27.66357051707272F, 1.7318108162254493F, 2.561521708929528F, 0.2574600325030955F, -1.2476161403494064F));
        g.addOrReplaceChild("domo_48", CubeListBuilder.create().texOffs(338, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.31262748297144F, -28.535188658655052F, 1.3989740063763405F, 2.6310547511491174F, 0.4175436508435626F, -1.0061893919226972F));
        g.addOrReplaceChild("domo_49", CubeListBuilder.create().texOffs(344, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.842957831061318F, -29.125856218549494F, 0.9592854584813195F, 2.78650256086857F, 0.585440698072002F, -0.6440938493242092F));
        g.addOrReplaceChild("domo_50", CubeListBuilder.create().texOffs(882, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.218215181852354F, -24.932673587904816F, 1.4851211093420758F, 2.835892169525648F, 0.02205740896525325F, -1.5294620568669772F));
        g.addOrReplaceChild("domo_51", CubeListBuilder.create().texOffs(150, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.371499915321632F, -26.512133826025735F, 1.4032864570246175F, 2.840734169025143F, 0.07569902691129347F, -1.389886148752015F));
        g.addOrReplaceChild("domo_52", CubeListBuilder.create().texOffs(160, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.6743897477716425F, -27.66357051707272F, 1.2415816116167222F, 2.8564298151231133F, 0.15013248354026582F, -1.2036553173198805F));
        g.addOrReplaceChild("domo_53", CubeListBuilder.create().texOffs(350, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.12134890176927F, -28.535188658655052F, 1.0029619778171674F, 2.8951129717441084F, 0.24286574745490586F, -0.9419590227853653F));
        g.addOrReplaceChild("domo_54", CubeListBuilder.create().texOffs(356, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.711796879799998F, -29.125856218549494F, 0.6877374678474542F, 2.9701971617007636F, 0.41669073855956595F, -0.5933851244372803F));
        g.addOrReplaceChild("domo_55", CubeListBuilder.create().texOffs(976, 91).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(7.076501907537054F, -24.932673587904816F, 0.5743913461801708F, 3.079974276169929F, 0.005617621825048606F, -1.5271791589498591F));
        g.addOrReplaceChild("domo_56", CubeListBuilder.create().texOffs(64, 97).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(7.237595469834774F, -26.512133826025735F, 0.5427406506152586F, 3.080965203884736F, 0.02369561812179116F, -1.3857735305696623F));
        g.addOrReplaceChild("domo_57", CubeListBuilder.create().texOffs(170, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.555915507250058F, -27.66357051707272F, 0.4801990415482073F, 3.0841872688598984F, 0.047127514982524356F, -1.1958971477279383F));
        g.addOrReplaceChild("domo_58", CubeListBuilder.create().texOffs(438, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.02564423162746F, -28.535188658655052F, 0.3879095630531739F, 3.0920853938846506F, 0.07670230988066704F, -0.9310263585370058F));
        g.addOrReplaceChild("domo_59", CubeListBuilder.create().texOffs(446, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.646171572998483F, -29.125856218549494F, 0.26599207801338426F, 3.108340947931973F, 0.10795943574345257F, -0.5686876147761235F));
        g.addOrReplaceChild("domo_60", CubeListBuilder.create().texOffs(990, 91).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(7.076501907537053F, -24.932673587904816F, -0.5743913461586545F, -3.079974276172232F, -0.00561762182483719F, -1.5271791589498724F));
        g.addOrReplaceChild("domo_61", CubeListBuilder.create().texOffs(76, 97).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(7.237595469834773F, -26.512133826025735F, -0.5427406505949278F, -3.080965203887002F, -0.02369561812090059F, -1.385773530569718F));
        g.addOrReplaceChild("domo_62", CubeListBuilder.create().texOffs(180, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.555915507250058F, -27.66357051707272F, -0.4801990415302194F, -3.0841872688620424F, -0.04712751498075745F, -1.1958971477280433F));
        g.addOrReplaceChild("domo_63", CubeListBuilder.create().texOffs(454, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.02564423162746F, -28.535188658655052F, -0.387909563038643F, -3.0920853938864985F, -0.07670230987780631F, -0.9310263585371541F));
        g.addOrReplaceChild("domo_64", CubeListBuilder.create().texOffs(462, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.646171572998483F, -29.125856218549494F, -0.2659920780034203F, -3.1083409479332116F, -0.10795943573945957F, -0.5686876147762636F));
        g.addOrReplaceChild("domo_65", CubeListBuilder.create().texOffs(894, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.218215181852354F, -24.932673587904816F, -1.4851211093420735F, -2.835892169525647F, -0.02205740896525313F, -1.5294620568669774F));
        g.addOrReplaceChild("domo_66", CubeListBuilder.create().texOffs(190, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.37149991532163F, -26.512133826025735F, -1.4032864570246153F, -2.840734169025142F, -0.07569902691129363F, -1.3898861487520147F));
        g.addOrReplaceChild("domo_67", CubeListBuilder.create().texOffs(200, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.674389747771642F, -27.66357051707272F, -1.2415816116167202F, -2.856429815123112F, -0.15013248354026595F, -1.2036553173198807F));
        g.addOrReplaceChild("domo_68", CubeListBuilder.create().texOffs(362, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.121348901769268F, -28.535188658655052F, -1.0029619778171657F, -2.8951129717441075F, -0.24286574745490597F, -0.9419590227853665F));
        g.addOrReplaceChild("domo_69", CubeListBuilder.create().texOffs(368, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.711796879799996F, -29.125856218549494F, -0.6877374678474528F, -2.970197161700764F, -0.41669073855956457F, -0.593385124437279F));
        g.addOrReplaceChild("domo_70", CubeListBuilder.create().texOffs(906, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.501448110907747F, -24.932673587904816F, -2.071510061440332F, -2.526119234455491F, -0.030766969388579157F, -1.533666501663433F));
        g.addOrReplaceChild("domo_71", CubeListBuilder.create().texOffs(210, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.639125855742694F, -26.512133826025735F, -1.9573636092865507F, -2.5343396111820917F, -0.12969486379049386F, -1.4128256242299548F));
        g.addOrReplaceChild("domo_72", CubeListBuilder.create().texOffs(220, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.911176360194993F, -27.66357051707272F, -1.7318108162254477F, -2.5615217089295306F, -0.25746003250309524F, -1.247616140349406F));
        g.addOrReplaceChild("domo_73", CubeListBuilder.create().texOffs(374, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.31262748297144F, -28.535188658655052F, -1.3989740063763394F, -2.6310547511491174F, -0.41754365084356243F, -1.006189391922698F));
        g.addOrReplaceChild("domo_74", CubeListBuilder.create().texOffs(380, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.842957831061318F, -29.125856218549494F, -0.9592854584813189F, -2.7865025608685703F, -0.5854406980720013F, -0.6440938493242085F));
        g.addOrReplaceChild("domo_75", CubeListBuilder.create().texOffs(918, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.928489938559666F, -24.932673587904816F, -2.4985518890922522F, -2.187412462578091F, -0.037112244778645075F, -1.5400081505799152F));
        g.addOrReplaceChild("domo_76", CubeListBuilder.create().texOffs(230, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.042636390713447F, -26.512133826025735F, -2.3608741442573047F, -2.1986487153266467F, -0.15663296515912753F, -1.4394848314344204F));
        g.addOrReplaceChild("domo_77", CubeListBuilder.create().texOffs(240, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.268189183774552F, -27.66357051707272F, -2.088823639805007F, -2.235941135156035F, -0.31216119333882314F, -1.2999411483582934F));
        g.addOrReplaceChild("domo_78", CubeListBuilder.create().texOffs(386, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.60102599362366F, -28.535188658655052F, -1.6873725170285596F, -2.3327479478489606F, -0.5110731634524278F, -1.0872471746802261F));
        g.addOrReplaceChild("domo_79", CubeListBuilder.create().texOffs(392, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.04071454151868F, -29.125856218549494F, -1.157042168938683F, -2.560267630148613F, -0.7294750795710214F, -0.735971893375866F));
        g.addOrReplaceChild("domo_80", CubeListBuilder.create().texOffs(930, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.514878890657924F, -24.932673587904816F, -2.7817848181476448F, -1.8774089831217005F, -0.041324209441002874F, -1.5487200677469384F));
        g.addOrReplaceChild("domo_81", CubeListBuilder.create().texOffs(250, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.596713542975381F, -26.512133826025735F, -2.6285000846783686F, -1.8854868182667324F, -0.18038638482594796F, -1.493846333327925F));
        g.addOrReplaceChild("domo_82", CubeListBuilder.create().texOffs(260, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.758418388383276F, -27.66357051707272F, -2.325610252228358F, -1.9134168034483559F, -0.3628185783014655F, -1.4101218238331663F));
        g.addOrReplaceChild("domo_83", CubeListBuilder.create().texOffs(398, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.997038022182831F, -28.535188658655052F, -1.8786510982307303F, -1.9904376955722483F, -0.6076536437134648F, -1.273515820761138F));
        g.addOrReplaceChild("domo_84", CubeListBuilder.create().texOffs(404, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.312262532152547F, -29.125856218549494F, -1.288203120200003F, -2.2826711455471766F, -0.8604150593584391F, -0.9012317097451039F));
        g.addOrReplaceChild("domo_85", CubeListBuilder.create().texOffs(1004, 91).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(9.425608653816298F, -24.932673587904816F, -2.9234980924629466F, -1.6326598831760901F, -0.043616479181884125F, -1.5651733572004385F));
        g.addOrReplaceChild("domo_86", CubeListBuilder.create().texOffs(88, 97).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(9.457259349381404F, -26.512133826025735F, -2.7624045301652265F, -1.6358582857142574F, -0.1849702544622494F, -1.546689408503379F));
        g.addOrReplaceChild("domo_87", CubeListBuilder.create().texOffs(270, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.51980095844884F, -27.66357051707272F, -2.4440844927499423F, -1.6467378791801695F, -0.3744623039465197F, -1.520157036069013F));
        g.addOrReplaceChild("domo_88", CubeListBuilder.create().texOffs(470, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.612090436944442F, -28.535188658655052F, -1.9743557683725401F, -1.6772667522765747F, -0.6375837030567165F, -1.4752888433066436F));
        g.addOrReplaceChild("domo_89", CubeListBuilder.create().texOffs(478, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.73400792198498F, -29.125856218549494F, -1.3538284270015162F, -1.771068765228487F, -0.993063237148849F, -1.3721949645108233F));
        g.addOrReplaceChild("domo_90", CubeListBuilder.create().texOffs(0, 97).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.574391346155124F, -24.932673587904816F, -2.923498092462947F, -1.5089327704167734F, -0.04361647918186639F, -1.5764192963890742F));
        g.addOrReplaceChild("domo_91", CubeListBuilder.create().texOffs(100, 97).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.542740650591591F, -26.512133826025735F, -2.7624045301652265F, -1.5057343678787671F, -0.18497025446218063F, -1.5949032450852105F));
        g.addOrReplaceChild("domo_92", CubeListBuilder.create().texOffs(280, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.480199041527268F, -27.66357051707272F, -2.4440844927499423F, -1.4948547744134002F, -0.3744623039464239F, -1.621435617518257F));
        g.addOrReplaceChild("domo_93", CubeListBuilder.create().texOffs(486, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.387909563036258F, -28.535188658655052F, -1.9743557683725403F, -1.4643259013185046F, -0.637583703056737F, -1.6663038102784153F));
        g.addOrReplaceChild("domo_94", CubeListBuilder.create().texOffs(494, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.265992078001785F, -29.125856218549494F, -1.3538284270015164F, -1.3705238883710382F, -0.9930632371495474F, -1.7693976890693393F));
        g.addOrReplaceChild("domo_95", CubeListBuilder.create().texOffs(942, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.485121109342074F, -24.932673587904816F, -2.7817848181476457F, -1.2641836704680949F, -0.041324209441002874F, -1.592872585842855F));
        g.addOrReplaceChild("domo_96", CubeListBuilder.create().texOffs(290, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.403286457024615F, -26.512133826025735F, -2.6285000846783695F, -1.2561058353230625F, -0.18038638482594815F, -1.647746320261868F));
        g.addOrReplaceChild("domo_97", CubeListBuilder.create().texOffs(300, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.24158161161672F, -27.66357051707272F, -2.325610252228359F, -1.228175850141439F, -0.36281857830146563F, -1.7314708297566268F));
        g.addOrReplaceChild("domo_98", CubeListBuilder.create().texOffs(410, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.002961977817167F, -28.535188658655052F, -1.8786510982307312F, -1.1511549580175464F, -0.6076536437134648F, -1.8680768328286543F));
        g.addOrReplaceChild("domo_99", CubeListBuilder.create().texOffs(416, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.687737467847453F, -29.125856218549494F, -1.2882031202000035F, -0.8589215080426171F, -0.8604150593584392F, -2.2403609438446894F));
        g.addOrReplaceChild("domo_100", CubeListBuilder.create().texOffs(954, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.071510061440332F, -24.932673587904816F, -2.498551889092253F, -0.9541801910117019F, -0.03711224477864519F, -1.6015845030098785F));
        g.addOrReplaceChild("domo_101", CubeListBuilder.create().texOffs(310, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.95736360928655F, -26.512133826025735F, -2.3608741442573056F, -0.942943938263146F, -0.15663296515912753F, -1.702107822155373F));
        g.addOrReplaceChild("domo_102", CubeListBuilder.create().texOffs(320, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.731810816225448F, -27.66357051707272F, -2.0888236398050073F, -0.9056515184337589F, -0.31216119333882336F, -1.841651505231499F));
        g.addOrReplaceChild("domo_103", CubeListBuilder.create().texOffs(422, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.398974006376339F, -28.535188658655052F, -1.68737251702856F, -0.8088447057408338F, -0.511073163452428F, -2.054345478909567F));
        g.addOrReplaceChild("domo_104", CubeListBuilder.create().texOffs(428, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.959285458481318F, -29.125856218549494F, -1.1570421689386834F, -0.5813250234411816F, -0.7294750795710214F, -2.4056207602139272F));
        g.addOrReplaceChild("domo_105", CubeListBuilder.create().texOffs(966, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.498551889092251F, -24.932673587904816F, -2.0715100614403337F, -0.6154734191343028F, -0.030766969388579337F, -1.6079261519263608F));
        g.addOrReplaceChild("domo_106", CubeListBuilder.create().texOffs(330, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.360874144257304F, -26.512133826025735F, -1.9573636092865525F, -0.6072530424077043F, -0.1296948637904937F, -1.7287670293598376F));
        g.addOrReplaceChild("domo_107", CubeListBuilder.create().texOffs(340, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.088823639805007F, -27.66357051707272F, -1.7318108162254493F, -0.5800709446602657F, -0.2574600325030956F, -1.8939765132403865F));
        g.addOrReplaceChild("domo_108", CubeListBuilder.create().texOffs(434, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.68737251702856F, -28.535188658655052F, -1.3989740063763405F, -0.5105379024406759F, -0.4175436508435626F, -2.135403261667096F));
        g.addOrReplaceChild("domo_109", CubeListBuilder.create().texOffs(440, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.157042168938682F, -29.125856218549494F, -0.9592854584813195F, -0.3550900927212232F, -0.5854406980720019F, -2.497498804265584F));
        g.addOrReplaceChild("domo_110", CubeListBuilder.create().texOffs(978, 104).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.781784818147644F, -24.932673587904816F, -1.4851211093420766F, -0.30570048406414785F, -0.02205740896525331F, -1.6121305967228157F));
        g.addOrReplaceChild("domo_111", CubeListBuilder.create().texOffs(350, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.62850008467837F, -26.512133826025735F, -1.4032864570246184F, -0.3008584845646516F, -0.07569902691129363F, -1.751706504837778F));
        g.addOrReplaceChild("domo_112", CubeListBuilder.create().texOffs(360, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.325610252228358F, -27.66357051707272F, -1.241581611616723F, -0.28516283846668056F, -0.15013248354026595F, -1.9379373362699128F));
        g.addOrReplaceChild("domo_113", CubeListBuilder.create().texOffs(446, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.87865109823073F, -28.535188658655052F, -1.002961977817168F, -0.24647968184568525F, -0.24286574745490608F, -2.199633630804428F));
        g.addOrReplaceChild("domo_114", CubeListBuilder.create().texOffs(452, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.288203120200002F, -29.125856218549494F, -0.6877374678474545F, -0.17139549188902975F, -0.4166907385595661F, -2.548207529152513F));
        g.addOrReplaceChild("domo_115", CubeListBuilder.create().texOffs(14, 97).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.923498092462946F, -24.932673587904816F, -0.5743913461868899F, -0.06161837742058281F, -0.005617621825114472F, -1.6144134946399382F));
        g.addOrReplaceChild("domo_116", CubeListBuilder.create().texOffs(112, 97).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.762404530165226F, -26.512133826025735F, -0.5427406506216073F, -0.06062744970576395F, -0.02369561812206907F, -1.7558191230201483F));
        g.addOrReplaceChild("domo_117", CubeListBuilder.create().texOffs(370, 107).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.44408449274994F, -27.66357051707272F, -0.48019904155382453F, -0.05740538473056451F, -0.04712751498307607F, -1.9456955058618872F));
        g.addOrReplaceChild("domo_118", CubeListBuilder.create().texOffs(502, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.97435576837254F, -28.535188658655052F, -0.38790956305771146F, -0.04950725970571936F, -0.0767023098815603F, -2.210566295052834F));
        g.addOrReplaceChild("domo_119", CubeListBuilder.create().texOffs(510, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.353828427001517F, -29.125856218549494F, -0.2659920780164957F, -0.03325170565820657F, -0.10795943574469934F, -2.5729050388137136F));
        g.addOrReplaceChild("valvula_0", CubeListBuilder.create().texOffs(248, 82).addBox(-6.0F, -32.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(242, 65).addBox(-2.5F, -32.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(10.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("valvula_1", CubeListBuilder.create().texOffs(282, 82).addBox(-6.0F, -32.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(276, 65).addBox(-2.5F, -32.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(10.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("silbato_0", CubeListBuilder.create().texOffs(316, 82).addBox(-6.0F, -28.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(310, 65).addBox(-2.5F, -28.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(12.5F, 0.0F, -2.0F));
        g.addOrReplaceChild("silbato_1", CubeListBuilder.create().texOffs(350, 82).addBox(-6.0F, -28.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(344, 65).addBox(-2.5F, -28.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(12.5F, 0.0F, -2.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("puerta_fuego", CubeListBuilder.create().texOffs(400, 82).addBox(14.0F, -17.0F, -2.0F, 1.0F, 4.0F, 4.0F).texOffs(172, 97).addBox(14.5F, -16.0F, -1.0F, 1.0F, 2.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("chimenea_base_0", CubeListBuilder.create().texOffs(404, 91).addBox(-5.0F, -25.0F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(666, 65).addBox(-1.0F, -25.0F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offset(-15.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_base_1", CubeListBuilder.create().texOffs(428, 91).addBox(-5.0F, -25.0F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(690, 65).addBox(-1.0F, -25.0F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-15.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_base_2", CubeListBuilder.create().texOffs(452, 91).addBox(-5.0F, -25.0F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(714, 65).addBox(-1.0F, -25.0F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-15.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_base_3", CubeListBuilder.create().texOffs(476, 91).addBox(-5.0F, -25.0F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(738, 65).addBox(-1.0F, -25.0F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-15.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("chimenea_0", CubeListBuilder.create().texOffs(178, 97).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.768508420739842F, -33.65F, 0.3444150891285808F, 0.1963495408493638F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_1", CubeListBuilder.create().texOffs(518, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.699248757569435F, -43.13F, 0.3581916926937241F, -2.949482636790134F, -0.040834417587977574F, -1.3639212054814303F));
        g.addOrReplaceChild("chimenea_2", CubeListBuilder.create().texOffs(526, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.458763816005526F, -43.730000000000004F, 0.4060271217393603F, -2.976084198500039F, -0.10612823932711107F, -1.0056316557413596F));
        g.addOrReplaceChild("chimenea_3", CubeListBuilder.create().texOffs(534, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.576120467488714F, -44.0F, 0.3826834323650897F, 0.0F, 0.19634954084936235F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_4", CubeListBuilder.create().texOffs(256, 97).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.032112317671949F, -33.65F, 0.9808111921964735F, 0.5890486225480845F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_5", CubeListBuilder.create().texOffs(542, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.973396810378826F, -43.13F, 1.0200436398843324F, -2.5628405814003385F, -0.11651773787377111F, -1.394713237389165F));
        g.addOrReplaceChild("chimenea_6", CubeListBuilder.create().texOffs(550, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.769523521166597F, -43.730000000000004F, 1.1562674165782871F, -2.630265552130003F, -0.3064339481718857F, -1.0775064750136576F));
        g.addOrReplaceChild("chimenea_7", CubeListBuilder.create().texOffs(558, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.869013686302166F, -44.0F, 1.089790213551637F, 0.0F, 0.589048622548086F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_8", CubeListBuilder.create().texOffs(334, 97).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.519188807803527F, -33.65F, 1.4678876823280507F, 0.9817477042468115F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_9", CubeListBuilder.create().texOffs(566, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.479956360115667F, -43.13F, 1.526603189621173F, -2.17023008111176F, -0.17487679011997861F, -1.4524655289393316F));
        g.addOrReplaceChild("chimenea_10", CubeListBuilder.create().texOffs(574, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.343732583421714F, -43.730000000000004F, 1.7304764788334022F, -2.24290278597178F, -0.46840879180463657F, -1.2259250998061832F));
        g.addOrReplaceChild("chimenea_11", CubeListBuilder.create().texOffs(582, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.410209786448362F, -44.0F, 1.630986313697834F, 0.0F, 0.9817477042468098F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_12", CubeListBuilder.create().texOffs(412, 97).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.155584910871418F, -33.65F, 1.731491579260158F, 1.3744467859455343F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_13", CubeListBuilder.create().texOffs(590, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.141808307306276F, -43.13F, 1.8007512424305645F, -1.771473988800225F, -0.20670016853174028F, -1.5290732708195367F));
        g.addOrReplaceChild("chimenea_14", CubeListBuilder.create().texOffs(598, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.09397287826064F, -43.730000000000004F, 2.0412361839944753F, -1.8033808353036591F, -0.5616006621776659F, -1.4453152900604622F));
        g.addOrReplaceChild("chimenea_15", CubeListBuilder.create().texOffs(606, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.11731656763491F, -44.0F, 1.9238795325112865F, 0.0F, 1.3744467859455345F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_16", CubeListBuilder.create().texOffs(490, 97).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.844415089128582F, -33.65F, 1.7314915792601582F, 1.7671458676442584F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_17", CubeListBuilder.create().texOffs(614, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.858191692693724F, -43.13F, 1.8007512424305645F, -1.3701186647895682F, -0.2067001685317401F, -1.6125193827702557F));
        g.addOrReplaceChild("chimenea_18", CubeListBuilder.create().texOffs(622, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.90602712173936F, -43.730000000000004F, 2.0412361839944753F, -1.3382118182861344F, -0.5616006621776659F, -1.6962773635293302F));
        g.addOrReplaceChild("chimenea_19", CubeListBuilder.create().texOffs(630, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.88268343236509F, -44.0F, 1.9238795325112865F, 3.141592653589793F, 1.3744467859455345F, 0.0F));
        g.addOrReplaceChild("chimenea_20", CubeListBuilder.create().texOffs(568, 97).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.480811192196477F, -33.65F, 1.467887682328051F, 2.159844949342983F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_21", CubeListBuilder.create().texOffs(638, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.520043639884335F, -43.13F, 1.526603189621173F, -0.9713625724780329F, -0.1748767901199783F, -1.6891271246504607F));
        g.addOrReplaceChild("chimenea_22", CubeListBuilder.create().texOffs(646, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.656267416578288F, -43.730000000000004F, 1.7304764788334022F, -0.8986898676180146F, -0.4684087918046365F, -1.915667553783609F));
        g.addOrReplaceChild("chimenea_23", CubeListBuilder.create().texOffs(654, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.589790213551638F, -44.0F, 1.630986313697834F, 3.141592653589793F, 0.9817477042468118F, 0.0F));
        g.addOrReplaceChild("chimenea_24", CubeListBuilder.create().texOffs(646, 97).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.96788768232805F, -33.65F, 0.9808111921964737F, 2.552544031041709F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_25", CubeListBuilder.create().texOffs(662, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.026603189621174F, -43.13F, 1.0200436398843327F, -0.5787520721894555F, -0.11651773787377143F, -1.7468794162006291F));
        g.addOrReplaceChild("chimenea_26", CubeListBuilder.create().texOffs(670, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.230476478833403F, -43.730000000000004F, 1.1562674165782874F, -0.5113271014597914F, -0.3064339481718858F, -2.0640861785761344F));
        g.addOrReplaceChild("chimenea_27", CubeListBuilder.create().texOffs(678, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.130986313697832F, -44.0F, 1.0897902135516373F, 3.141592653589793F, 0.5890486225480852F, 0.0F));
        g.addOrReplaceChild("chimenea_28", CubeListBuilder.create().texOffs(724, 97).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.231491579260158F, -33.65F, 0.34441508912858104F, 2.9452431127404295F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_29", CubeListBuilder.create().texOffs(686, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.300751242430565F, -43.13F, 0.35819169269372425F, -0.19211001679965686F, -0.040834417587977415F, -1.7776714481083629F));
        g.addOrReplaceChild("chimenea_30", CubeListBuilder.create().texOffs(694, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.541236183994474F, -43.730000000000004F, 0.40602712173936045F, -0.16550845508975254F, -0.10612823932711053F, -2.135960997848434F));
        g.addOrReplaceChild("chimenea_31", CubeListBuilder.create().texOffs(702, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.423879532511286F, -44.0F, 0.38268343236509F, 3.141592653589793F, 0.19634954084936282F, 0.0F));
        g.addOrReplaceChild("chimenea_32", CubeListBuilder.create().texOffs(802, 97).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.231491579260158F, -33.65F, -0.3444150891285806F, -2.9452431127404295F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_33", CubeListBuilder.create().texOffs(710, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.300751242430565F, -43.13F, -0.35819169269372386F, 0.19211001679965686F, 0.040834417587977415F, -1.7776714481083629F));
        g.addOrReplaceChild("chimenea_34", CubeListBuilder.create().texOffs(718, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.541236183994474F, -43.730000000000004F, -0.40602712173936F, 0.16550845508975254F, 0.10612823932711053F, -2.135960997848434F));
        g.addOrReplaceChild("chimenea_35", CubeListBuilder.create().texOffs(726, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.423879532511286F, -44.0F, -0.3826834323650895F, -3.141592653589793F, -0.19634954084936265F, 0.0F));
        g.addOrReplaceChild("chimenea_36", CubeListBuilder.create().texOffs(880, 97).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.96788768232805F, -33.65F, -0.9808111921964735F, -2.552544031041709F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_37", CubeListBuilder.create().texOffs(734, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.026603189621174F, -43.13F, -1.0200436398843324F, 0.5787520721894555F, 0.11651773787377143F, -1.7468794162006291F));
        g.addOrReplaceChild("chimenea_38", CubeListBuilder.create().texOffs(742, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.230476478833403F, -43.730000000000004F, -1.156267416578287F, 0.5113271014597914F, 0.3064339481718857F, -2.0640861785761344F));
        g.addOrReplaceChild("chimenea_39", CubeListBuilder.create().texOffs(750, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.130986313697832F, -44.0F, -1.089790213551637F, -3.141592653589793F, -0.589048622548085F, 0.0F));
        g.addOrReplaceChild("chimenea_40", CubeListBuilder.create().texOffs(0, 101).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.480811192196477F, -33.65F, -1.4678876823280507F, -2.159844949342983F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_41", CubeListBuilder.create().texOffs(758, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.520043639884335F, -43.13F, -1.5266031896211727F, 0.9713625724780328F, 0.17487679011997828F, -1.6891271246504609F));
        g.addOrReplaceChild("chimenea_42", CubeListBuilder.create().texOffs(766, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.656267416578288F, -43.730000000000004F, -1.7304764788334017F, 0.898689867618013F, 0.46840879180463674F, -1.915667553783611F));
        g.addOrReplaceChild("chimenea_43", CubeListBuilder.create().texOffs(774, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.589790213551638F, -44.0F, -1.6309863136978335F, -3.141592653589793F, -0.9817477042468098F, 0.0F));
        g.addOrReplaceChild("chimenea_44", CubeListBuilder.create().texOffs(78, 101).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.844415089128582F, -33.65F, -1.731491579260158F, -1.7671458676442588F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_45", CubeListBuilder.create().texOffs(782, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.858191692693724F, -43.13F, -1.8007512424305643F, 1.370118664789568F, 0.20670016853173995F, -1.6125193827702557F));
        g.addOrReplaceChild("chimenea_46", CubeListBuilder.create().texOffs(790, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.90602712173936F, -43.730000000000004F, -2.0412361839944753F, 1.3382118182861336F, 0.561600662177666F, -1.696277363529332F));
        g.addOrReplaceChild("chimenea_47", CubeListBuilder.create().texOffs(798, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.882683432365091F, -44.0F, -1.923879532511286F, -3.141592653589793F, -1.3744467859455327F, 0.0F));
        g.addOrReplaceChild("chimenea_48", CubeListBuilder.create().texOffs(156, 101).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.155584910871418F, -33.65F, -1.731491579260158F, -1.374446785945534F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_49", CubeListBuilder.create().texOffs(806, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.141808307306276F, -43.13F, -1.8007512424305645F, 1.7714739888002256F, 0.20670016853174028F, -1.5290732708195367F));
        g.addOrReplaceChild("chimenea_50", CubeListBuilder.create().texOffs(814, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.09397287826064F, -43.730000000000004F, -2.0412361839944753F, 1.8033808353036593F, 0.5616006621776661F, -1.4453152900604622F));
        g.addOrReplaceChild("chimenea_51", CubeListBuilder.create().texOffs(822, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.11731656763491F, -44.0F, -1.9238795325112865F, 0.0F, -1.3744467859455345F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_52", CubeListBuilder.create().texOffs(234, 101).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.519188807803527F, -33.65F, -1.467887682328051F, -0.9817477042468108F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_53", CubeListBuilder.create().texOffs(830, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.479956360115668F, -43.13F, -1.526603189621173F, 2.170230081111761F, 0.17487679011997856F, -1.4524655289393316F));
        g.addOrReplaceChild("chimenea_54", CubeListBuilder.create().texOffs(838, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.343732583421714F, -43.730000000000004F, -1.7304764788334022F, 2.24290278597178F, 0.46840879180463696F, -1.2259250998061821F));
        g.addOrReplaceChild("chimenea_55", CubeListBuilder.create().texOffs(846, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.410209786448362F, -44.0F, -1.6309863136978342F, 0.0F, -0.9817477042468102F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_56", CubeListBuilder.create().texOffs(312, 101).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.032112317671949F, -33.65F, -0.9808111921964743F, -0.5890486225480871F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_57", CubeListBuilder.create().texOffs(854, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.973396810378828F, -43.13F, -1.0200436398843333F, 2.562840581400336F, 0.11651773787377126F, -1.394713237389165F));
        g.addOrReplaceChild("chimenea_58", CubeListBuilder.create().texOffs(862, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.769523521166597F, -43.730000000000004F, -1.156267416578288F, 2.6302655521300022F, 0.30643394817188624F, -1.0775064750136567F));
        g.addOrReplaceChild("chimenea_59", CubeListBuilder.create().texOffs(870, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.869013686302166F, -44.0F, -1.089790213551638F, 0.0F, -0.5890486225480865F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_60", CubeListBuilder.create().texOffs(390, 101).addBox(-18.5F, -1.0F, -1.0F, 37.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.768508420739842F, -33.65F, -0.3444150891285816F, -0.1963495408493636F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_61", CubeListBuilder.create().texOffs(878, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.699248757569435F, -43.13F, -0.35819169269372486F, 2.949482636790134F, 0.04083441758797773F, -1.3639212054814303F));
        g.addOrReplaceChild("chimenea_62", CubeListBuilder.create().texOffs(886, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.458763816005526F, -43.730000000000004F, -0.4060271217393612F, 2.976084198500039F, 0.10612823932711116F, -1.0056316557413594F));
        g.addOrReplaceChild("chimenea_63", CubeListBuilder.create().texOffs(894, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.576120467488714F, -44.0F, -0.3826834323650906F, 0.0F, -0.19634954084936235F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_hueco", CubeListBuilder.create().texOffs(434, 65).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(-15.5F, -43.6F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("faro_soporte", CubeListBuilder.create().texOffs(990, 104).addBox(-22.0F, -23.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("faro", CubeListBuilder.create().texOffs(898, 65).addBox(-23.0F, -28.0F, -2.5F, 5.0F, 5.0F, 5.0F).texOffs(674, 82).addBox(-23.5F, -29.0F, -3.0F, 6.0F, 1.0F, 6.0F).texOffs(380, 107).addBox(-22.0F, -30.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("faro_lente_0", CubeListBuilder.create().texOffs(724, 91).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(762, 65).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-23.1F, -25.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_lente_1", CubeListBuilder.create().texOffs(748, 91).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(786, 65).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-23.1F, -25.5F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_lente_2", CubeListBuilder.create().texOffs(772, 91).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(810, 65).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-23.1F, -25.5F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_lente_3", CubeListBuilder.create().texOffs(796, 91).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(834, 65).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-23.1F, -25.5F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_lente_vidrio", CubeListBuilder.create().texOffs(182, 65).addBox(-7.5F, 0.0F, -7.5F, 15.0F, 1.0F, 15.0F), PartPose.offsetAndRotation(-23.62F, -25.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("campana_0", CubeListBuilder.create().texOffs(902, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.4535314466136464F, -24.0F, 0.41437499999999994F, 0.2604926365473338F, 0.026426782057239015F, -1.6696060934341208F));
        g.addOrReplaceChild("campana_1", CubeListBuilder.create().texOffs(910, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.7548945493248334F, -24.785F, 0.33362499999999995F, 0.21571670299117884F, 0.1495110302196826F, -2.1678132281298677F));
        g.addOrReplaceChild("campana_2", CubeListBuilder.create().texOffs(918, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0721188679681877F, -25.572499999999998F, 0.24862499999999998F, 0.2592874361765618F, 0.036593605233335304F, -1.707855221902941F));
        g.addOrReplaceChild("campana_3", CubeListBuilder.create().texOffs(458, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-2.44718997412886F, -26.2375F, 0.14812499999999998F, 0.16503334174876857F, 0.20416434939878F, -2.453908555397913F));
        g.addOrReplaceChild("campana_4", CubeListBuilder.create().texOffs(926, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.8679064466136464F, -24.0F, 1.1320935533863534F, 0.7827787366757535F, 0.07225375951479156F, -1.6432394325527526F));
        g.addOrReplaceChild("campana_5", CubeListBuilder.create().texOffs(934, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0885195493248334F, -24.785F, 0.9114804506751667F, 0.6854948559952926F, 0.4191143675703068F, -2.0325409611133227F));
        g.addOrReplaceChild("campana_6", CubeListBuilder.create().texOffs(942, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.3207438679681873F, -25.572499999999998F, 0.6792561320318121F, 0.7803523386615104F, 0.10012046336546183F, -1.6714224071815509F));
        g.addOrReplaceChild("campana_7", CubeListBuilder.create().texOffs(464, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-2.59531497412886F, -26.2375F, 0.4046850258711399F, 0.5561261686461513F, 0.5870656908514227F, -2.2987109178729663F));
        g.addOrReplaceChild("campana_8", CubeListBuilder.create().texOffs(950, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.5856250000000003F, -24.0F, 1.5464685533863536F, 1.30768424555282F, 0.09877515285793476F, -1.597352582235699F));
        g.addOrReplaceChild("campana_9", CubeListBuilder.create().texOffs(958, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.666375F, -24.785F, 1.2451054506751666F, 1.2541691896662825F, 0.589452822408185F, -1.7509640943331561F));
        g.addOrReplaceChild("campana_10", CubeListBuilder.create().texOffs(966, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.751375F, -25.572499999999998F, 0.9278811320318121F, 1.3064629374106764F, 0.13696655979834188F, -1.6077360374265781F));
        g.addOrReplaceChild("campana_11", CubeListBuilder.create().texOffs(470, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-2.8518749999999997F, -26.2375F, 0.5528100258711399F, 1.1637810700927562F, 0.858203643376F, -1.8861045937967977F));
        g.addOrReplaceChild("campana_12", CubeListBuilder.create().texOffs(974, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.4143749999999997F, -24.0F, 1.5464685533863536F, 1.8339084080369734F, 0.09877515285793455F, -1.5442400713540942F));
        g.addOrReplaceChild("campana_13", CubeListBuilder.create().texOffs(982, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.3336249999999996F, -24.785F, 1.2451054506751669F, 1.8874234639235106F, 0.5894528224081851F, -1.390628559256637F));
        g.addOrReplaceChild("campana_14", CubeListBuilder.create().texOffs(990, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.2486249999999997F, -25.572499999999998F, 0.9278811320318122F, 1.835129716179117F, 0.13696655979834188F, -1.5338566161632152F));
        g.addOrReplaceChild("campana_15", CubeListBuilder.create().texOffs(476, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.148125F, -26.2375F, 0.55281002587114F, 1.9778115834970367F, 0.858203643376F, -1.255488059792996F));
        g.addOrReplaceChild("campana_16", CubeListBuilder.create().texOffs(998, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.132093553386353F, -24.0F, 1.1320935533863539F, 2.358813916914039F, 0.07225375951479147F, -1.4983532210370405F));
        g.addOrReplaceChild("campana_17", CubeListBuilder.create().texOffs(1006, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.911480450675166F, -24.785F, 0.911480450675167F, 2.4560977975945F, 0.4191143675703071F, -1.1090516924764708F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("campana_18", CubeListBuilder.create().texOffs(1014, 107).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.679256132031812F, -25.572499999999998F, 0.6792561320318123F, 2.361240314928282F, 0.10012046336546179F, -1.470170246408242F));
        g.addOrReplaceChild("campana_19", CubeListBuilder.create().texOffs(482, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.40468502587114F, -26.2375F, 0.40468502587114F, 2.5854664849436415F, 0.587065690851423F, -0.8428817357168273F));
        g.addOrReplaceChild("campana_20", CubeListBuilder.create().texOffs(0, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.546468553386354F, -24.0F, 0.4143750000000004F, 2.881100017042459F, 0.026426782057239015F, -1.4719865601556723F));
        g.addOrReplaceChild("campana_21", CubeListBuilder.create().texOffs(8, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.245105450675167F, -24.785F, 0.33362500000000034F, 2.925875950598614F, 0.14951103021968282F, -0.9737794254599257F));
        g.addOrReplaceChild("campana_22", CubeListBuilder.create().texOffs(16, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.927881132031812F, -25.572499999999998F, 0.24862500000000023F, 2.882305217413231F, 0.03659360523333538F, -1.4337374316868519F));
        g.addOrReplaceChild("campana_23", CubeListBuilder.create().texOffs(488, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.55281002587114F, -26.2375F, 0.14812500000000015F, 2.976559311841024F, 0.20416434939878025F, -0.6876840981918803F));
        g.addOrReplaceChild("campana_24", CubeListBuilder.create().texOffs(24, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.5464685533863545F, -24.0F, -0.4143749999999994F, -2.88110001704246F, -0.02642678205723894F, -1.4719865601556723F));
        g.addOrReplaceChild("campana_25", CubeListBuilder.create().texOffs(32, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.245105450675167F, -24.785F, -0.3336249999999995F, -2.9258759505986145F, -0.1495110302196825F, -0.9737794254599256F));
        g.addOrReplaceChild("campana_26", CubeListBuilder.create().texOffs(40, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.9278811320318123F, -25.572499999999998F, -0.24862499999999965F, -2.882305217413232F, -0.03659360523333522F, -1.433737431686852F));
        g.addOrReplaceChild("campana_27", CubeListBuilder.create().texOffs(494, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.5528100258711404F, -26.2375F, -0.14812499999999978F, -2.976559311841025F, -0.2041643493987797F, -0.6876840981918798F));
        g.addOrReplaceChild("campana_28", CubeListBuilder.create().texOffs(48, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.132093553386354F, -24.0F, -1.132093553386353F, -2.35881391691404F, -0.07225375951479152F, -1.4983532210370405F));
        g.addOrReplaceChild("campana_29", CubeListBuilder.create().texOffs(56, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.9114804506751675F, -24.785F, -0.9114804506751661F, -2.456097797594501F, -0.41911436757030657F, -1.1090516924764706F));
        g.addOrReplaceChild("campana_30", CubeListBuilder.create().texOffs(64, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.6792561320318127F, -25.572499999999998F, -0.6792561320318117F, -2.361240314928283F, -0.10012046336546171F, -1.4701702464082422F));
        g.addOrReplaceChild("campana_31", CubeListBuilder.create().texOffs(500, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.40468502587114F, -26.2375F, -0.4046850258711397F, -2.585466484943642F, -0.5870656908514224F, -0.8428817357168266F));
        g.addOrReplaceChild("campana_32", CubeListBuilder.create().texOffs(72, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.4143750000000006F, -24.0F, -1.5464685533863534F, -1.8339084080369739F, -0.09877515285793453F, -1.5442400713540942F));
        g.addOrReplaceChild("campana_33", CubeListBuilder.create().texOffs(80, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.3336250000000005F, -24.785F, -1.2451054506751666F, -1.887423463923511F, -0.589452822408185F, -1.3906285592566368F));
        g.addOrReplaceChild("campana_34", CubeListBuilder.create().texOffs(88, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.2486250000000005F, -25.572499999999998F, -0.927881132031812F, -1.8351297161791174F, -0.13696655979834188F, -1.533856616163215F));
        g.addOrReplaceChild("campana_35", CubeListBuilder.create().texOffs(506, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.1481250000000003F, -26.2375F, -0.5528100258711399F, -1.9778115834970371F, -0.858203643376F, -1.2554880597929956F));
        g.addOrReplaceChild("campana_36", CubeListBuilder.create().texOffs(96, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.5856250000000007F, -24.0F, -1.5464685533863538F, -1.3076842455528204F, -0.09877515285793458F, -1.5973525822356989F));
        g.addOrReplaceChild("campana_37", CubeListBuilder.create().texOffs(104, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.666375000000001F, -24.785F, -1.245105450675167F, -1.2541691896662834F, -0.5894528224081852F, -1.750964094333156F));
        g.addOrReplaceChild("campana_38", CubeListBuilder.create().texOffs(112, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.7513750000000003F, -25.572499999999998F, -0.9278811320318124F, -1.3064629374106769F, -0.136966559798342F, -1.6077360374265781F));
        g.addOrReplaceChild("campana_39", CubeListBuilder.create().texOffs(512, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-2.851875F, -26.2375F, -0.5528100258711401F, -1.163781070092757F, -0.8582036433760003F, -1.8861045937967968F));
        g.addOrReplaceChild("campana_40", CubeListBuilder.create().texOffs(120, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.8679064466136472F, -24.0F, -1.1320935533863543F, -0.7827787366757541F, -0.0722537595147916F, -1.6432394325527526F));
        g.addOrReplaceChild("campana_41", CubeListBuilder.create().texOffs(128, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0885195493248343F, -24.785F, -0.9114804506751673F, -0.6854948559952931F, -0.4191143675703071F, -2.0325409611133223F));
        g.addOrReplaceChild("campana_42", CubeListBuilder.create().texOffs(136, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.320743867968188F, -25.572499999999998F, -0.6792561320318126F, -0.780352338661511F, -0.10012046336546195F, -1.6714224071815509F));
        g.addOrReplaceChild("campana_43", CubeListBuilder.create().texOffs(518, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-2.5953149741288604F, -26.2375F, -0.4046850258711402F, -0.5561261686461517F, -0.5870656908514233F, -2.298710917872966F));
        g.addOrReplaceChild("campana_44", CubeListBuilder.create().texOffs(144, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.4535314466136466F, -24.0F, -0.4143750000000006F, -0.2604926365473341F, -0.026426782057239015F, -1.6696060934341208F));
        g.addOrReplaceChild("campana_45", CubeListBuilder.create().texOffs(152, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.7548945493248334F, -24.785F, -0.33362500000000045F, -0.21571670299117932F, -0.14951103021968282F, -2.1678132281298677F));
        g.addOrReplaceChild("campana_46", CubeListBuilder.create().texOffs(160, 110).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.072118867968188F, -25.572499999999998F, -0.24862500000000032F, -0.2592874361765625F, -0.036593605233335304F, -1.707855221902941F));
        g.addOrReplaceChild("campana_47", CubeListBuilder.create().texOffs(524, 110).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-2.44718997412886F, -26.2375F, -0.1481250000000002F, -0.16503334174876935F, -0.20416434939878025F, -2.453908555397913F));
        g.addOrReplaceChild("campana_horquilla", CubeListBuilder.create().texOffs(224, 91).addBox(-3.5F, -26.5F, -3.5F, 1.0F, 5.0F, 1.0F).texOffs(228, 91).addBox(-3.5F, -26.5F, 2.5F, 1.0F, 5.0F, 1.0F).texOffs(384, 82).addBox(-3.5F, -27.5F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_manometro", CubeListBuilder.create().texOffs(858, 65).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(14.6F, -21.8F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro_aguja", CubeListBuilder.create().texOffs(536, 110).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.719999999999999F, -21.8F, 0.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_grifos", CubeListBuilder.create().texOffs(540, 110).addBox(14.0F, -19.8F, -3.5F, 1.0F, 1.0F, 1.0F).texOffs(544, 110).addBox(14.0F, -18.3F, -3.5F, 1.0F, 1.0F, 1.0F).texOffs(548, 110).addBox(14.0F, -16.8F, -3.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_regulador", CubeListBuilder.create().texOffs(232, 91).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F), PartPose.offsetAndRotation(14.3F, -19.400000000000002F, 0.0F, 0.8059360376985919F, 0.0F, -1.2160906747839564F));
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(962, 65).addBox(-0.5F, -9.0F, -0.5F, 1.0F, 9.0F, 1.0F).texOffs(164, 97).addBox(-1.0F, -11.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(16.0F, -12.0F, 5.5F));
        g.addOrReplaceChild("cab_palanca_cuadrante", CubeListBuilder.create().texOffs(256, 110).addBox(14.0F, -13.0F, 5.0F, 4.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(124, 97).addBox(16.0F, -13.0F, 2.0F, 3.0F, 1.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(136, 97).addBox(16.0F, -13.0F, -5.0F, 3.0F, 1.0F, 3.0F), PartPose.ZERO);
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(918, 65).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(820, 91).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 65).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(652, 91).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(30.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(840, 91).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 65).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(860, 91).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 65).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(918, 65).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(820, 91).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 65).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(662, 91).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(42.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(840, 91).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 65).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(860, 91).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 65).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(918, 65).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(820, 91).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 65).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 91).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(30.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(840, 91).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 65).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(860, 91).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 65).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(918, 65).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(820, 91).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 65).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 91).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(42.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(840, 91).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(946, 65).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(860, 91).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(954, 65).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(838, 82).addBox(24.0F, -10.0F, 2.0F, 24.0F, 5.0F, 1.0F).texOffs(888, 82).addBox(24.0F, -10.0F, -3.0F, 24.0F, 5.0F, 1.0F).texOffs(152, 43).addBox(23.0F, -11.0F, -8.0F, 26.0F, 1.0F, 16.0F).texOffs(692, 91).addBox(28.5F, -6.0F, 3.0F, 3.0F, 4.0F, 1.0F).texOffs(700, 91).addBox(28.5F, -6.0F, -4.0F, 3.0F, 4.0F, 1.0F).texOffs(708, 91).addBox(40.5F, -6.0F, 3.0F, 3.0F, 4.0F, 1.0F).texOffs(716, 91).addBox(40.5F, -6.0F, -4.0F, 3.0F, 4.0F, 1.0F).texOffs(530, 110).addBox(21.0F, -10.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(906, 0).addBox(34.0F, -21.0F, -7.0F, 14.0F, 10.0F, 14.0F).texOffs(618, 65).addBox(35.0F, -22.0F, -6.0F, 12.0F, 1.0F, 12.0F).texOffs(500, 91).addBox(23.0F, -15.0F, 7.0F, 11.0F, 4.0F, 1.0F).texOffs(524, 91).addBox(23.0F, -15.0F, -8.0F, 11.0F, 4.0F, 1.0F).texOffs(122, 43).addBox(23.0F, -15.0F, -7.0F, 1.0F, 4.0F, 14.0F).texOffs(74, 43).addBox(24.0F, -16.0F, -7.0F, 10.0F, 5.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("boca_0", CubeListBuilder.create().texOffs(0, 82).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(708, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offset(44.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("boca_1", CubeListBuilder.create().texOffs(66, 82).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(774, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(44.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("boca_2", CubeListBuilder.create().texOffs(132, 82).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(840, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(44.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("tronco0_0", CubeListBuilder.create().texOffs(842, 43).addBox(24.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(282, 43).addBox(24.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -16.9F, -4.5F));
        g.addOrReplaceChild("tronco0_1", CubeListBuilder.create().texOffs(868, 43).addBox(24.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(322, 43).addBox(24.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -16.9F, -4.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tronco1_0", CubeListBuilder.create().texOffs(894, 43).addBox(25.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(362, 43).addBox(25.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -16.9F, -1.5F));
        g.addOrReplaceChild("tronco1_1", CubeListBuilder.create().texOffs(920, 43).addBox(25.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(402, 43).addBox(25.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -16.9F, -1.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tronco2_0", CubeListBuilder.create().texOffs(946, 43).addBox(24.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(442, 43).addBox(24.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -16.9F, 1.5F));
        g.addOrReplaceChild("tronco2_1", CubeListBuilder.create().texOffs(972, 43).addBox(24.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(482, 43).addBox(24.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -16.9F, 1.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tronco3_0", CubeListBuilder.create().texOffs(998, 43).addBox(25.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(522, 43).addBox(25.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -16.9F, 4.5F));
        g.addOrReplaceChild("tronco3_1", CubeListBuilder.create().texOffs(0, 65).addBox(25.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(562, 43).addBox(25.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -16.9F, 4.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tronco4_0", CubeListBuilder.create().texOffs(26, 65).addBox(24.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(602, 43).addBox(24.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -18.6F, -3.0F));
        g.addOrReplaceChild("tronco4_1", CubeListBuilder.create().texOffs(52, 65).addBox(24.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(642, 43).addBox(24.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -18.6F, -3.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tronco5_0", CubeListBuilder.create().texOffs(78, 65).addBox(25.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(682, 43).addBox(25.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -18.6F, 0.0F));
        g.addOrReplaceChild("tronco5_1", CubeListBuilder.create().texOffs(104, 65).addBox(25.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(722, 43).addBox(25.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -18.6F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tronco6_0", CubeListBuilder.create().texOffs(130, 65).addBox(24.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(762, 43).addBox(24.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -18.6F, 3.0F));
        g.addOrReplaceChild("tronco6_1", CubeListBuilder.create().texOffs(156, 65).addBox(24.5F, -6.0F, -2.5F, 8.0F, 12.0F, 5.0F).texOffs(802, 43).addBox(24.5F, -2.5F, -6.0F, 8.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -18.6F, 3.0F, 0.7853981633974483F, 0.0F, 0.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "quitapiedrasi_0", 0.48908184702013063F, 1.0F, 0.4658275901648837F);
        escalar(g0, "quitapiedrasi_1", 0.4890818470201305F, 1.0F, 0.47645724826801567F);
        escalar(g0, "quitapiedrasi_2", 0.45853763158678085F, 1.0F, 0.4658275901648839F);
        escalar(g0, "quitapiedrasi_3", 0.45853763158678085F, 1.0F, 0.476457248268016F);
        escalar(g0, "quitapiedrasi_4", 0.47832445743480106F, 1.0F, 0.4658275901648839F);
        escalar(g0, "quitapiedrasi_5", 0.478324457434801F, 1.0F, 0.47645724826801594F);
        escalar(g0, "quitapiedrasi_6", 0.4610551304514326F, 1.0F, 0.4658275901648837F);
        escalar(g0, "quitapiedrasi_7", 0.4610551304514326F, 1.0F, 0.47645724826801567F);
        escalar(g0, "quitapiedrasd_0", 0.48908184702013063F, 1.0F, 0.4658275901648837F);
        escalar(g0, "quitapiedrasd_1", 0.4890818470201305F, 1.0F, 0.47645724826801567F);
        escalar(g0, "quitapiedrasd_2", 0.45853763158678085F, 1.0F, 0.4658275901648839F);
        escalar(g0, "quitapiedrasd_3", 0.45853763158678085F, 1.0F, 0.476457248268016F);
        escalar(g0, "quitapiedrasd_4", 0.47832445743480106F, 1.0F, 0.4658275901648839F);
        escalar(g0, "quitapiedrasd_5", 0.478324457434801F, 1.0F, 0.47645724826801594F);
        escalar(g0, "quitapiedrasd_6", 0.4610551304514326F, 1.0F, 0.4658275901648837F);
        escalar(g0, "quitapiedrasd_7", 0.4610551304514326F, 1.0F, 0.47645724826801567F);
        escalar(g0, "caldera_0", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_1", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_2", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_3", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_4", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_5", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_6", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_7", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_8", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_9", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_10", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_11", 0.95F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_12", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_13", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_14", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_15", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_16", 0.95F, 1.0F, 0.5873678649902323F);
        escalar(g0, "caldera_17", 0.95F, 1.0F, 0.5873678649902323F);
        escalar(g0, "caldera_18", 0.95F, 1.0F, 0.5873678649902323F);
        escalar(g0, "caldera_19", 0.95F, 1.0F, 0.5873678649902323F);
        escalar(g0, "caldera_20", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_21", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_22", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_23", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_24", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_25", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_26", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_27", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_28", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_29", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_30", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_31", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_32", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_33", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_34", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_35", 0.95F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_36", 0.95F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_37", 0.95F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_38", 0.95F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_39", 0.95F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_40", 0.95F, 1.0F, 0.5873678649902322F);
        escalar(g0, "caldera_41", 0.95F, 1.0F, 0.5873678649902322F);
        escalar(g0, "caldera_42", 0.95F, 1.0F, 0.5873678649902322F);
        escalar(g0, "caldera_43", 0.95F, 1.0F, 0.5873678649902322F);
        escalar(g0, "caldera_44", 0.95F, 1.0F, 0.5873678649902325F);
        escalar(g0, "caldera_45", 0.95F, 1.0F, 0.5873678649902325F);
        escalar(g0, "caldera_46", 0.95F, 1.0F, 0.5873678649902325F);
        escalar(g0, "caldera_47", 0.95F, 1.0F, 0.5873678649902325F);
        escalar(g0, "caldera_48", 0.95F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_49", 0.95F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_50", 0.95F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_51", 0.95F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_52", 0.95F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_53", 0.95F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_54", 0.95F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_55", 0.95F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_56", 0.95F, 1.0F, 0.5873678649902335F);
        escalar(g0, "caldera_57", 0.95F, 1.0F, 0.5873678649902335F);
        escalar(g0, "caldera_58", 0.95F, 1.0F, 0.5873678649902335F);
        escalar(g0, "caldera_59", 0.95F, 1.0F, 0.5873678649902335F);
        escalar(g0, "caldera_60", 0.95F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_61", 0.95F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_62", 0.95F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_63", 0.95F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_64", 0.95F, 1.0F, 0.5873678649902317F);
        escalar(g0, "caldera_65", 0.95F, 1.0F, 0.5873678649902317F);
        escalar(g0, "caldera_66", 0.95F, 1.0F, 0.5873678649902317F);
        escalar(g0, "caldera_67", 0.95F, 1.0F, 0.5873678649902317F);
        escalar(g0, "caldera_68", 0.95F, 1.0F, 0.5873678649902337F);
        escalar(g0, "caldera_69", 0.95F, 1.0F, 0.5873678649902337F);
        escalar(g0, "caldera_70", 0.95F, 1.0F, 0.5873678649902337F);
        escalar(g0, "caldera_71", 0.95F, 1.0F, 0.5873678649902337F);
        escalar(g0, "caldera_72", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_73", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_74", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_75", 0.95F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_76", 0.95F, 1.0F, 0.5873678649902305F);
        escalar(g0, "caldera_77", 0.95F, 1.0F, 0.5873678649902305F);
        escalar(g0, "caldera_78", 0.95F, 1.0F, 0.5873678649902305F);
        escalar(g0, "caldera_79", 0.95F, 1.0F, 0.5873678649902305F);
        escalar(g0, "caldera_80", 0.95F, 1.0F, 0.5873678649902329F);
        escalar(g0, "caldera_81", 0.95F, 1.0F, 0.5873678649902329F);
        escalar(g0, "caldera_82", 0.95F, 1.0F, 0.5873678649902329F);
        escalar(g0, "caldera_83", 0.95F, 1.0F, 0.5873678649902329F);
        escalar(g0, "caldera_84", 0.95F, 1.0F, 0.5873678649902326F);
        escalar(g0, "caldera_85", 0.95F, 1.0F, 0.5873678649902326F);
        escalar(g0, "caldera_86", 0.95F, 1.0F, 0.5873678649902326F);
        escalar(g0, "caldera_87", 0.95F, 1.0F, 0.5873678649902326F);
        escalar(g0, "caldera_88", 0.95F, 1.0F, 0.5873678649902313F);
        escalar(g0, "caldera_89", 0.95F, 1.0F, 0.5873678649902313F);
        escalar(g0, "caldera_90", 0.95F, 1.0F, 0.5873678649902313F);
        escalar(g0, "caldera_91", 0.95F, 1.0F, 0.5873678649902313F);
        escalar(g0, "caldera_92", 0.95F, 1.0F, 0.5873678649902334F);
        escalar(g0, "caldera_93", 0.95F, 1.0F, 0.5873678649902334F);
        escalar(g0, "caldera_94", 0.95F, 1.0F, 0.5873678649902334F);
        escalar(g0, "caldera_95", 0.95F, 1.0F, 0.5873678649902334F);
        escalar(g0, "hogar_techo_0", 1.0F, 0.28699719671347146F, 0.28699719671347146F);
        escalar(g0, "hogar_techo_1", 1.0F, 0.28699719671347146F, 0.28699719671347146F);
        escalar(g0, "hogar_techo_2", 1.0F, 0.28699719671347146F, 0.28699719671347146F);
        escalar(g0, "hogar_techo_3", 1.0F, 0.28699719671347146F, 0.28699719671347146F);
        escalar(g0, "hogar_techo_4", 1.0F, 0.28699719671347146F, 0.28699719671347146F);
        escalar(g0, "hogar_techo_5", 1.0F, 0.28699719671347146F, 0.28699719671347146F);
        escalar(g0, "domo_0", 0.4718111229162353F, 1.0F, 0.3903237216541286F);
        escalar(g0, "domo_1", 0.4458529668159385F, 1.0F, 0.3691830607972186F);
        escalar(g0, "domo_2", 0.3698649797116049F, 1.0F, 0.4911138381001965F);
        escalar(g0, "domo_3", 0.4729614158009758F, 1.0F, 0.39864854480878203F);
        escalar(g0, "domo_4", 0.43529836029869157F, 1.0F, 0.27649880254794085F);
        escalar(g0, "domo_5", 0.47185541879402326F, 1.0F, 0.36271917452575114F);
        escalar(g0, "domo_6", 0.44659264811520166F, 1.0F, 0.34328328419233367F);
        escalar(g0, "domo_7", 0.3722663995514284F, 1.0F, 0.304878066442547F);
        escalar(g0, "domo_8", 0.48093817473612394F, 1.0F, 0.4964108713707626F);
        escalar(g0, "domo_9", 0.4494574491938162F, 1.0F, 0.3466779933618331F);
        escalar(g0, "domo_10", 0.4718842196208327F, 1.0F, 0.3163514121760599F);
        escalar(g0, "domo_11", 0.4470730474605216F, 1.0F, 0.29947052539538743F);
        escalar(g0, "domo_12", 0.3738206929443837F, 1.0F, 0.26611398131638886F);
        escalar(g0, "domo_13", 0.4860633833405111F, 1.0F, 0.4337828441470368F);
        escalar(g0, "domo_14", 0.45845659837012254F, 1.0F, 0.30373355298248067F);
        escalar(g0, "domo_15", 0.4718842196208327F, 1.0F, 0.3163514121760601F);
        escalar(g0, "domo_16", 0.4470730474605216F, 1.0F, 0.29947052539538777F);
        escalar(g0, "domo_17", 0.37382069294438364F, 1.0F, 0.2661139813163891F);
        escalar(g0, "domo_18", 0.486063383340511F, 1.0F, 0.43378284414703683F);
        escalar(g0, "domo_19", 0.45845659837012254F, 1.0F, 0.30373355298248045F);
        escalar(g0, "domo_20", 0.47185541879402326F, 1.0F, 0.3627191745257511F);
        escalar(g0, "domo_21", 0.44659264811520166F, 1.0F, 0.34328328419233356F);
        escalar(g0, "domo_22", 0.3722663995514283F, 1.0F, 0.3048780664425469F);
        escalar(g0, "domo_23", 0.4809381747361241F, 1.0F, 0.4964108713707621F);
        escalar(g0, "domo_24", 0.4494574491938161F, 1.0F, 0.3466779933618331F);
        escalar(g0, "domo_25", 0.4718111229162353F, 1.0F, 0.39032372164972257F);
        escalar(g0, "domo_26", 0.4458529668159385F, 1.0F, 0.36918306079305524F);
        escalar(g0, "domo_27", 0.3698649797116049F, 1.0F, 0.4911138380946708F);
        escalar(g0, "domo_28", 0.47296141580097584F, 1.0F, 0.3986485448043182F);
        escalar(g0, "domo_29", 0.43529836029869146F, 1.0F, 0.2764988025448797F);
        escalar(g0, "domo_30", 0.4718111229162353F, 1.0F, 0.39032372165853424F);
        escalar(g0, "domo_31", 0.4458529668159385F, 1.0F, 0.36918306080138175F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "domo_32", 0.3698649797116049F, 1.0F, 0.49111383810572173F);
        escalar(g0, "domo_33", 0.4729614158009757F, 1.0F, 0.39864854481324563F);
        escalar(g0, "domo_34", 0.4352983602986915F, 1.0F, 0.2764988025510018F);
        escalar(g0, "domo_35", 0.47185541879402326F, 1.0F, 0.3627191745257511F);
        escalar(g0, "domo_36", 0.4465926481152016F, 1.0F, 0.343283284192334F);
        escalar(g0, "domo_37", 0.3722663995514283F, 1.0F, 0.3048780664425478F);
        escalar(g0, "domo_38", 0.480938174736124F, 1.0F, 0.4964108713707631F);
        escalar(g0, "domo_39", 0.44945744919381614F, 1.0F, 0.34667799336183314F);
        escalar(g0, "domo_40", 0.4718842196208327F, 1.0F, 0.3163514121760604F);
        escalar(g0, "domo_41", 0.44707304746052157F, 1.0F, 0.2994705253953877F);
        escalar(g0, "domo_42", 0.37382069294438364F, 1.0F, 0.26611398131638886F);
        escalar(g0, "domo_43", 0.486063383340511F, 1.0F, 0.4337828441470368F);
        escalar(g0, "domo_44", 0.4584565983701225F, 1.0F, 0.30373355298248045F);
        escalar(g0, "domo_45", 0.4718842196208327F, 1.0F, 0.31635141217605983F);
        escalar(g0, "domo_46", 0.44707304746052157F, 1.0F, 0.29947052539538743F);
        escalar(g0, "domo_47", 0.3738206929443837F, 1.0F, 0.2661139813163888F);
        escalar(g0, "domo_48", 0.4860633833405111F, 1.0F, 0.43378284414703633F);
        escalar(g0, "domo_49", 0.45845659837012254F, 1.0F, 0.30373355298248034F);
        escalar(g0, "domo_50", 0.4718554187940233F, 1.0F, 0.362719174525751F);
        escalar(g0, "domo_51", 0.4465926481152016F, 1.0F, 0.34328328419233367F);
        escalar(g0, "domo_52", 0.3722663995514284F, 1.0F, 0.30487806644254706F);
        escalar(g0, "domo_53", 0.4809381747361242F, 1.0F, 0.4964108713707624F);
        escalar(g0, "domo_54", 0.4494574491938159F, 1.0F, 0.3466779933618329F);
        escalar(g0, "domo_55", 0.4718111229162353F, 1.0F, 0.39032372164697077F);
        escalar(g0, "domo_56", 0.4458529668159385F, 1.0F, 0.3691830607904551F);
        escalar(g0, "domo_57", 0.3698649797116049F, 1.0F, 0.49111383809122044F);
        escalar(g0, "domo_58", 0.4729614158009759F, 1.0F, 0.3986485448015311F);
        escalar(g0, "domo_59", 0.43529836029869123F, 1.0F, 0.2764988025429689F);
        escalar(g0, "domo_60", 0.4718111229162353F, 1.0F, 0.39032372166128626F);
        escalar(g0, "domo_61", 0.4458529668159385F, 1.0F, 0.3691830608039819F);
        escalar(g0, "domo_62", 0.3698649797116049F, 1.0F, 0.4911138381091724F);
        escalar(g0, "domo_63", 0.4729614158009757F, 1.0F, 0.39864854481603285F);
        escalar(g0, "domo_64", 0.4352983602986915F, 1.0F, 0.2764988025529128F);
        escalar(g0, "domo_65", 0.47185541879402326F, 1.0F, 0.36271917452575075F);
        escalar(g0, "domo_66", 0.44659264811520166F, 1.0F, 0.34328328419233345F);
        escalar(g0, "domo_67", 0.3722663995514283F, 1.0F, 0.3048780664425469F);
        escalar(g0, "domo_68", 0.48093817473612377F, 1.0F, 0.49641087137076223F);
        escalar(g0, "domo_69", 0.44945744919381647F, 1.0F, 0.3466779933618327F);
        escalar(g0, "domo_70", 0.4718842196208327F, 1.0F, 0.31635141217606055F);
        escalar(g0, "domo_71", 0.4470730474605216F, 1.0F, 0.2994705253953881F);
        escalar(g0, "domo_72", 0.37382069294438364F, 1.0F, 0.26611398131638947F);
        escalar(g0, "domo_73", 0.4860633833405108F, 1.0F, 0.4337828441470382F);
        escalar(g0, "domo_74", 0.45845659837012276F, 1.0F, 0.3037335529824818F);
        escalar(g0, "domo_75", 0.4718842196208327F, 1.0F, 0.31635141217605994F);
        escalar(g0, "domo_76", 0.44707304746052157F, 1.0F, 0.2994705253953877F);
        escalar(g0, "domo_77", 0.37382069294438364F, 1.0F, 0.26611398131638897F);
        escalar(g0, "domo_78", 0.4860633833405108F, 1.0F, 0.43378284414703594F);
        escalar(g0, "domo_79", 0.4584565983701227F, 1.0F, 0.30373355298247967F);
        escalar(g0, "domo_80", 0.47185541879402326F, 1.0F, 0.3627191745257503F);
        escalar(g0, "domo_81", 0.4465926481152016F, 1.0F, 0.3432832841923328F);
        escalar(g0, "domo_82", 0.3722663995514283F, 1.0F, 0.3048780664425461F);
        escalar(g0, "domo_83", 0.4809381747361239F, 1.0F, 0.49641087137076134F);
        escalar(g0, "domo_84", 0.44945744919381625F, 1.0F, 0.34667799336183225F);
        escalar(g0, "domo_85", 0.4718111229162353F, 1.0F, 0.390323721644622F);
        escalar(g0, "domo_86", 0.4458529668159385F, 1.0F, 0.369183060788236F);
        escalar(g0, "domo_87", 0.3698649797116049F, 1.0F, 0.49111383808827513F);
        escalar(g0, "domo_88", 0.47296141580097584F, 1.0F, 0.3986485447991518F);
        escalar(g0, "domo_89", 0.43529836029869146F, 1.0F, 0.2764988025413373F);
        escalar(g0, "domo_90", 0.4718111229162353F, 1.0F, 0.39032372166363544F);
        escalar(g0, "domo_91", 0.4458529668159385F, 1.0F, 0.3691830608062016F);
        escalar(g0, "domo_92", 0.3698649797116049F, 1.0F, 0.4911138381121182F);
        escalar(g0, "domo_93", 0.4729614158009757F, 1.0F, 0.39864854481841294F);
        escalar(g0, "domo_94", 0.4352983602986915F, 1.0F, 0.27649880255454506F);
        escalar(g0, "domo_95", 0.47185541879402326F, 1.0F, 0.36271917452575103F);
        escalar(g0, "domo_96", 0.44659264811520166F, 1.0F, 0.34328328419233345F);
        escalar(g0, "domo_97", 0.3722663995514283F, 1.0F, 0.3048780664425469F);
        escalar(g0, "domo_98", 0.48093817473612377F, 1.0F, 0.4964108713707621F);
        escalar(g0, "domo_99", 0.44945744919381636F, 1.0F, 0.3466779933618322F);
        escalar(g0, "domo_100", 0.4718842196208327F, 1.0F, 0.3163514121760605F);
        escalar(g0, "domo_101", 0.4470730474605216F, 1.0F, 0.2994705253953878F);
        escalar(g0, "domo_102", 0.37382069294438364F, 1.0F, 0.2661139813163894F);
        escalar(g0, "domo_103", 0.48606338334051086F, 1.0F, 0.4337828441470376F);
        escalar(g0, "domo_104", 0.45845659837012276F, 1.0F, 0.3037335529824813F);
        escalar(g0, "domo_105", 0.4718842196208327F, 1.0F, 0.31635141217605955F);
        escalar(g0, "domo_106", 0.44707304746052157F, 1.0F, 0.29947052539538765F);
        escalar(g0, "domo_107", 0.37382069294438364F, 1.0F, 0.2661139813163891F);
        escalar(g0, "domo_108", 0.4860633833405111F, 1.0F, 0.4337828441470365F);
        escalar(g0, "domo_109", 0.45845659837012254F, 1.0F, 0.30373355298248045F);
        escalar(g0, "domo_110", 0.47185541879402326F, 1.0F, 0.3627191745257503F);
        escalar(g0, "domo_111", 0.4465926481152016F, 1.0F, 0.343283284192333F);
        escalar(g0, "domo_112", 0.3722663995514284F, 1.0F, 0.30487806644254634F);
        escalar(g0, "domo_113", 0.4809381747361242F, 1.0F, 0.49641087137076134F);
        escalar(g0, "domo_114", 0.4494574491938159F, 1.0F, 0.3466779933618322F);
        escalar(g0, "domo_115", 0.4718111229162353F, 1.0F, 0.390323721642501F);
        escalar(g0, "domo_116", 0.4458529668159385F, 1.0F, 0.36918306078623164F);
        escalar(g0, "domo_117", 0.3698649797116049F, 1.0F, 0.49111383808561526F);
        escalar(g0, "domo_118", 0.47296141580097606F, 1.0F, 0.3986485447970032F);
        escalar(g0, "domo_119", 0.4352983602986913F, 1.0F, 0.27649880253986403F);
        escalar(g0, "valvula_0", 0.1077859454596501F, 1.0F, 0.1077859454596501F);
        escalar(g0, "valvula_1", 0.1077859454596501F, 1.0F, 0.1077859454596501F);
        escalar(g0, "silbato_0", 0.07698996104260723F, 1.0F, 0.07698996104260723F);
        escalar(g0, "silbato_1", 0.07698996104260723F, 1.0F, 0.07698996104260723F);
        escalar(g0, "chimenea_base_0", 0.4903926402016152F, 1.0F, 0.4903926402016152F);
        escalar(g0, "chimenea_base_1", 0.4903926402016152F, 1.0F, 0.4903926402016152F);
        escalar(g0, "chimenea_base_2", 0.4903926402016152F, 1.0F, 0.4903926402016152F);
        escalar(g0, "chimenea_base_3", 0.4903926402016152F, 1.0F, 0.4903926402016152F);
        escalar(g0, "chimenea_0", 0.49459459459459454F, 1.0F, 0.351162579629031F);
        escalar(g0, "chimenea_1", 0.33776323068090347F, 1.0F, 0.3652090828141923F);
        escalar(g0, "chimenea_2", 0.323394495933372F, 1.0F, 0.4139816633182244F);
        escalar(g0, "chimenea_3", 0.30000000000000016F, 1.0F, 0.3901806440322566F);
        escalar(g0, "chimenea_4", 0.49459459459459454F, 1.0F, 0.3511625796290304F);
        escalar(g0, "chimenea_5", 0.3377632306809035F, 1.0F, 0.3652090828141916F);
        escalar(g0, "chimenea_6", 0.3233944959333719F, 1.0F, 0.4139816633182237F);
        escalar(g0, "chimenea_7", 0.3F, 1.0F, 0.3901806440322563F);
        escalar(g0, "chimenea_8", 0.49459459459459454F, 1.0F, 0.3511625796290314F);
        escalar(g0, "chimenea_9", 0.3377632306809035F, 1.0F, 0.36520908281419273F);
        escalar(g0, "chimenea_10", 0.3233944959333719F, 1.0F, 0.41398166331822445F);
        escalar(g0, "chimenea_11", 0.30000000000000016F, 1.0F, 0.3901806440322562F);
        escalar(g0, "chimenea_12", 0.49459459459459454F, 1.0F, 0.35116257962903075F);
        escalar(g0, "chimenea_13", 0.33776323068090347F, 1.0F, 0.36520908281419195F);
        escalar(g0, "chimenea_14", 0.323394495933372F, 1.0F, 0.4139816633182243F);
        escalar(g0, "chimenea_15", 0.3F, 1.0F, 0.39018064403225683F);
        escalar(g0, "chimenea_16", 0.49459459459459454F, 1.0F, 0.35116257962903163F);
        escalar(g0, "chimenea_17", 0.3377632306809034F, 1.0F, 0.3652090828141924F);
        escalar(g0, "chimenea_18", 0.3233944959333719F, 1.0F, 0.41398166331822384F);
        escalar(g0, "chimenea_19", 0.2999999999999998F, 1.0F, 0.3901806440322564F);
        escalar(g0, "chimenea_20", 0.49459459459459454F, 1.0F, 0.35116257962903064F);
        escalar(g0, "chimenea_21", 0.33776323068090347F, 1.0F, 0.3652090828141923F);
        escalar(g0, "chimenea_22", 0.3233944959333718F, 1.0F, 0.4139816633182247F);
        escalar(g0, "chimenea_23", 0.29999999999999966F, 1.0F, 0.3901806440322569F);
        escalar(g0, "chimenea_24", 0.49459459459459454F, 1.0F, 0.3511625796290304F);
        escalar(g0, "chimenea_25", 0.3377632306809036F, 1.0F, 0.36520908281419184F);
        escalar(g0, "chimenea_26", 0.32339449593337166F, 1.0F, 0.41398166331822395F);
        escalar(g0, "chimenea_27", 0.3000000000000001F, 1.0F, 0.39018064403225583F);
        escalar(g0, "chimenea_28", 0.49459459459459454F, 1.0F, 0.351162579629031F);
        escalar(g0, "chimenea_29", 0.33776323068090347F, 1.0F, 0.36520908281419207F);
        escalar(g0, "chimenea_30", 0.323394495933372F, 1.0F, 0.41398166331822417F);
        escalar(g0, "chimenea_31", 0.3000000000000006F, 1.0F, 0.3901806440322566F);
        escalar(g0, "chimenea_32", 0.49459459459459454F, 1.0F, 0.351162579629031F);
        escalar(g0, "chimenea_33", 0.33776323068090347F, 1.0F, 0.36520908281419207F);
        escalar(g0, "chimenea_34", 0.323394495933372F, 1.0F, 0.41398166331822417F);
        escalar(g0, "chimenea_35", 0.3000000000000006F, 1.0F, 0.3901806440322567F);
        escalar(g0, "chimenea_36", 0.49459459459459454F, 1.0F, 0.35116257962903047F);
        escalar(g0, "chimenea_37", 0.3377632306809036F, 1.0F, 0.36520908281419195F);
        escalar(g0, "chimenea_38", 0.32339449593337166F, 1.0F, 0.41398166331822406F);
        escalar(g0, "chimenea_39", 0.30000000000000004F, 1.0F, 0.3901806440322559F);
        escalar(g0, "chimenea_40", 0.49459459459459454F, 1.0F, 0.35116257962903064F);
        escalar(g0, "chimenea_41", 0.33776323068090347F, 1.0F, 0.3652090828141923F);
        escalar(g0, "chimenea_42", 0.323394495933372F, 1.0F, 0.41398166331822395F);
        escalar(g0, "chimenea_43", 0.3F, 1.0F, 0.3901806440322561F);
        escalar(g0, "chimenea_44", 0.49459459459459454F, 1.0F, 0.35116257962903163F);
        escalar(g0, "chimenea_45", 0.3377632306809034F, 1.0F, 0.3652090828141924F);
        escalar(g0, "chimenea_46", 0.32339449593337205F, 1.0F, 0.4139816633182247F);
        escalar(g0, "chimenea_47", 0.30000000000000016F, 1.0F, 0.39018064403225733F);
        escalar(g0, "chimenea_48", 0.49459459459459454F, 1.0F, 0.3511625796290308F);
        escalar(g0, "chimenea_49", 0.33776323068090347F, 1.0F, 0.365209082814192F);
        escalar(g0, "chimenea_50", 0.323394495933372F, 1.0F, 0.4139816633182243F);
        escalar(g0, "chimenea_51", 0.30000000000000004F, 1.0F, 0.39018064403225683F);
        escalar(g0, "chimenea_52", 0.49459459459459454F, 1.0F, 0.3511625796290305F);
        escalar(g0, "chimenea_53", 0.3377632306809035F, 1.0F, 0.3652090828141918F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1) {
        escalar(g0, "chimenea_54", 0.3233944959333721F, 1.0F, 0.4139816633182239F);
        escalar(g0, "chimenea_55", 0.30000000000000027F, 1.0F, 0.39018064403225605F);
        escalar(g0, "chimenea_56", 0.49459459459459454F, 1.0F, 0.3511625796290306F);
        escalar(g0, "chimenea_57", 0.3377632306809035F, 1.0F, 0.36520908281419184F);
        escalar(g0, "chimenea_58", 0.32339449593337205F, 1.0F, 0.41398166331822367F);
        escalar(g0, "chimenea_59", 0.30000000000000004F, 1.0F, 0.39018064403225605F);
        escalar(g0, "chimenea_60", 0.49459459459459454F, 1.0F, 0.35116257962903136F);
        escalar(g0, "chimenea_61", 0.33776323068090347F, 1.0F, 0.3652090828141926F);
        escalar(g0, "chimenea_62", 0.323394495933372F, 1.0F, 0.4139816633182247F);
        escalar(g0, "chimenea_63", 0.3000000000000002F, 1.0F, 0.3901806440322569F);
        escalar(g0, "chimenea_hueco", 0.24615384615384614F, 0.6F, 0.24615384615384614F);
        escalar(g0, "faro_lente_0", 0.3530827009451629F, 0.55F, 0.3530827009451629F);
        escalar(g0, "faro_lente_1", 0.3530827009451629F, 0.55F, 0.3530827009451629F);
        escalar(g0, "faro_lente_2", 0.3530827009451629F, 0.55F, 0.3530827009451629F);
        escalar(g0, "faro_lente_3", 0.3530827009451629F, 0.55F, 0.3530827009451629F);
        escalar(g0, "faro_lente_vidrio", 0.23999999999999996F, 0.15F, 0.23999999999999996F);
        escalar(g0, "campana_0", 0.40225147606938483F, 1.0F, 0.42899256725742807F);
        escalar(g0, "campana_1", 0.476345725287843F, 1.0F, 0.3453940156893139F);
        escalar(g0, "campana_2", 0.40687405913869695F, 1.0F, 0.2573955403544569F);
        escalar(g0, "campana_3", 0.4315234640202078F, 1.0F, 0.3067005684464871F);
        escalar(g0, "campana_4", 0.40225147606938483F, 1.0F, 0.4289925672574282F);
        escalar(g0, "campana_5", 0.476345725287843F, 1.0F, 0.34539401568931394F);
        escalar(g0, "campana_6", 0.40687405913869695F, 1.0F, 0.2573955403544569F);
        escalar(g0, "campana_7", 0.43152346402020786F, 1.0F, 0.30670056844648713F);
        escalar(g0, "campana_8", 0.40225147606938483F, 1.0F, 0.4289925672574282F);
        escalar(g0, "campana_9", 0.476345725287843F, 1.0F, 0.34539401568931405F);
        escalar(g0, "campana_10", 0.40687405913869695F, 1.0F, 0.257395540354457F);
        escalar(g0, "campana_11", 0.4315234640202079F, 1.0F, 0.3067005684464872F);
        escalar(g0, "campana_12", 0.40225147606938483F, 1.0F, 0.42899256725742796F);
        escalar(g0, "campana_13", 0.476345725287843F, 1.0F, 0.3453940156893138F);
        escalar(g0, "campana_14", 0.40687405913869695F, 1.0F, 0.2573955403544568F);
        escalar(g0, "campana_15", 0.43152346402020786F, 1.0F, 0.30670056844648697F);
        escalar(g0, "campana_16", 0.40225147606938483F, 1.0F, 0.42899256725742807F);
        escalar(g0, "campana_17", 0.476345725287843F, 1.0F, 0.34539401568931394F);
        escalar(g0, "campana_18", 0.406874059138697F, 1.0F, 0.25739554035445683F);
        escalar(g0, "campana_19", 0.4315234640202078F, 1.0F, 0.306700568446487F);
        escalar(g0, "campana_20", 0.40225147606938483F, 1.0F, 0.42899256725742835F);
        escalar(g0, "campana_21", 0.476345725287843F, 1.0F, 0.34539401568931416F);
        escalar(g0, "campana_22", 0.406874059138697F, 1.0F, 0.25739554035445705F);
        escalar(g0, "campana_23", 0.4315234640202078F, 1.0F, 0.3067005684464873F);
        escalar(g0, "campana_24", 0.40225147606938483F, 1.0F, 0.42899256725742774F);
        escalar(g0, "campana_25", 0.476345725287843F, 1.0F, 0.3453940156893136F);
        escalar(g0, "campana_26", 0.406874059138697F, 1.0F, 0.2573955403544566F);
        escalar(g0, "campana_27", 0.4315234640202079F, 1.0F, 0.30670056844648674F);
        escalar(g0, "campana_28", 0.40225147606938483F, 1.0F, 0.4289925672574285F);
        escalar(g0, "campana_29", 0.476345725287843F, 1.0F, 0.34539401568931416F);
        escalar(g0, "campana_30", 0.40687405913869695F, 1.0F, 0.25739554035445705F);
        escalar(g0, "campana_31", 0.4315234640202079F, 1.0F, 0.3067005684464874F);
        escalar(g0, "campana_32", 0.40225147606938483F, 1.0F, 0.4289925672574283F);
        escalar(g0, "campana_33", 0.476345725287843F, 1.0F, 0.34539401568931416F);
        escalar(g0, "campana_34", 0.40687405913869695F, 1.0F, 0.2573955403544571F);
        escalar(g0, "campana_35", 0.43152346402020786F, 1.0F, 0.30670056844648724F);
        escalar(g0, "campana_36", 0.40225147606938483F, 1.0F, 0.4289925672574277F);
        escalar(g0, "campana_37", 0.476345725287843F, 1.0F, 0.3453940156893135F);
        escalar(g0, "campana_38", 0.40687405913869695F, 1.0F, 0.2573955403544565F);
        escalar(g0, "campana_39", 0.43152346402020786F, 1.0F, 0.30670056844648674F);
        escalar(g0, "campana_40", 0.40225147606938483F, 1.0F, 0.4289925672574284F);
        escalar(g0, "campana_41", 0.476345725287843F, 1.0F, 0.34539401568931416F);
        escalar(g0, "campana_42", 0.40687405913869695F, 1.0F, 0.257395540354457F);
        escalar(g0, "campana_43", 0.43152346402020786F, 1.0F, 0.30670056844648713F);
        escalar(g0, "campana_44", 0.40225147606938483F, 1.0F, 0.4289925672574283F);
        escalar(g0, "campana_45", 0.476345725287843F, 1.0F, 0.3453940156893141F);
        escalar(g0, "campana_46", 0.40687405913869695F, 1.0F, 0.25739554035445705F);
        escalar(g0, "campana_47", 0.43152346402020786F, 1.0F, 0.3067005684464873F);
        escalar(g0, "cab_manometro", 0.24F, 0.6F, 0.24F);
        escalar(g0, "cab_manometro_aguja", 0.3F, 0.9839999999999999F, 0.6F);
        escalar(g0, "cab_regulador", 0.7F, 0.8316249154516715F, 0.7F);
        escalar(g1, "boca_0", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
        escalar(g1, "boca_1", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
        escalar(g1, "boca_2", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
        escalar(g1, "tronco0_0", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco0_1", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco1_0", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco1_1", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco2_0", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco2_1", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco3_0", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco3_1", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco4_0", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco4_1", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco5_0", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco5_1", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco6_0", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
        escalar(g1, "tronco6_1", 1.0F, 0.15397992208521447F, 0.15397992208521447F);
    }
}
