package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Volteo lateral de cantera" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonVolteo {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_volteo"), "main"),
            LocomotoraMod.id("textures/entity/vagon_volteo.png"),
            List.of(
                new DatosModelo.Animada("ri0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("ri1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloVagonVolteo::crearCapa,
            16.0F,
            ModeloVagonVolteo::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -8.0F, 8.0F)));

    private ModeloVagonVolteo() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 64);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("ri0_0", CubeListBuilder.create().texOffs(584, 0).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(528, 36).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(602, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(488, 36).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-8.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("ri0_1", CubeListBuilder.create().texOffs(546, 36).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(610, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri0_2", CubeListBuilder.create().texOffs(564, 36).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(618, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ri1_0", CubeListBuilder.create().texOffs(584, 0).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(528, 36).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(602, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(498, 36).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(8.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("ri1_1", CubeListBuilder.create().texOffs(546, 36).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(610, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri1_2", CubeListBuilder.create().texOffs(564, 36).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(618, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd0_0", CubeListBuilder.create().texOffs(584, 0).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(528, 36).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(602, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 36).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-8.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rd0_1", CubeListBuilder.create().texOffs(546, 36).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(610, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd0_2", CubeListBuilder.create().texOffs(564, 36).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(618, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd1_0", CubeListBuilder.create().texOffs(584, 0).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(528, 36).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(602, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(518, 36).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(8.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rd1_1", CubeListBuilder.create().texOffs(546, 36).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(610, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd1_2", CubeListBuilder.create().texOffs(564, 36).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(618, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(762, 0).addBox(-16.0F, -10.0F, 2.0F, 32.0F, 6.0F, 1.0F).texOffs(828, 0).addBox(-16.0F, -10.0F, -3.0F, 32.0F, 6.0F, 1.0F).texOffs(276, 0).addBox(-16.0F, -10.0F, -9.0F, 32.0F, 1.0F, 18.0F).texOffs(96, 0).addBox(-17.0F, -10.0F, -9.0F, 2.0F, 5.0F, 18.0F).texOffs(456, 36).addBox(-22.0F, -9.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(376, 0).addBox(-10.0F, -12.0F, -8.0F, 2.0F, 2.0F, 16.0F).texOffs(136, 0).addBox(15.0F, -10.0F, -9.0F, 2.0F, 5.0F, 18.0F).texOffs(472, 36).addBox(17.0F, -9.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(412, 0).addBox(8.0F, -12.0F, -8.0F, 2.0F, 2.0F, 16.0F), PartPose.ZERO);
        g.addOrReplaceChild("pistoni_0", CubeListBuilder.create().texOffs(626, 0).addBox(-6.0F, -13.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(448, 0).addBox(-2.5F, -13.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(0.0F, 0.0F, -6.5F));
        g.addOrReplaceChild("pistoni_1", CubeListBuilder.create().texOffs(660, 0).addBox(-6.0F, -13.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(482, 0).addBox(-2.5F, -13.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 0.0F, -6.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pistond_0", CubeListBuilder.create().texOffs(694, 0).addBox(-6.0F, -13.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(516, 0).addBox(-2.5F, -13.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(0.0F, 0.0F, 6.5F));
        g.addOrReplaceChild("pistond_1", CubeListBuilder.create().texOffs(728, 0).addBox(-6.0F, -13.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(550, 0).addBox(-2.5F, -13.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 6.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("caja", CubeListBuilder.create().texOffs(0, 0).addBox(-14.0F, -21.0F, -10.0F, 28.0F, 9.0F, 20.0F).texOffs(176, 0).addBox(-14.5F, -21.0F, -10.5F, 29.0F, 1.0F, 21.0F), PartPose.ZERO);
        g.addOrReplaceChild("carga_0", CubeListBuilder.create().texOffs(894, 0).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-11.8125F, -21.284375F, -8.3125F, -2.9096548540646157F, 0.01883689951082585F, -0.16250117299342093F));
        g.addOrReplaceChild("carga_1", CubeListBuilder.create().texOffs(920, 0).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-8.4375F, -21.656709275215164F, -8.3125F, -2.63697579606697F, 0.011026887027810243F, -0.045986798187769545F));
        g.addOrReplaceChild("carga_2", CubeListBuilder.create().texOffs(946, 0).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-5.0625F, -21.78861665008227F, -8.3125F, -2.5555145804250956F, 0.005999822158184684F, -0.022054253650837383F));
        g.addOrReplaceChild("carga_3", CubeListBuilder.create().texOffs(972, 0).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-1.6875F, -21.846216962915104F, -8.3125F, -2.5224719452645203F, 0.0019117209664943635F, -0.006727766859264725F));
        g.addOrReplaceChild("carga_4", CubeListBuilder.create().texOffs(998, 0).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(1.6875F, -21.846216962915104F, -8.3125F, -2.5224719452645203F, -0.0019117209664943635F, 0.006727766859264725F));
        g.addOrReplaceChild("carga_5", CubeListBuilder.create().texOffs(0, 29).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(5.0625F, -21.78861665008227F, -8.3125F, -2.5555145804250956F, -0.005999822158184684F, 0.022054253650837383F));
        g.addOrReplaceChild("carga_6", CubeListBuilder.create().texOffs(26, 29).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(8.4375F, -21.656709275215164F, -8.3125F, -2.63697579606697F, -0.011026887027810243F, 0.045986798187769545F));
        g.addOrReplaceChild("carga_7", CubeListBuilder.create().texOffs(52, 29).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(11.8125F, -21.284375F, -8.3125F, -2.9096548540646157F, -0.01883689951082585F, 0.16250117299342093F));
        g.addOrReplaceChild("carga_8", CubeListBuilder.create().texOffs(286, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-11.8125F, -21.656709275215164F, -5.9375F, -3.072667672517135F, 0.01336463492754287F, -0.37020508587842166F));
        g.addOrReplaceChild("carga_9", CubeListBuilder.create().texOffs(598, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-8.4375F, -22.516543550430324F, -5.9375F, -2.973362512184162F, 0.009933181603201575F, -0.1181070465791644F));
        g.addOrReplaceChild("carga_10", CubeListBuilder.create().texOffs(622, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-5.0625F, -22.821158219597848F, -5.9375F, -2.9393521081549974F, 0.005916711490981425F, -0.05885649381957145F));
        g.addOrReplaceChild("carga_11", CubeListBuilder.create().texOffs(646, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.6875F, -22.954175044890565F, -5.9375F, -2.924684152746197F, 0.001963250808881076F, -0.018247933733736208F));
        g.addOrReplaceChild("carga_12", CubeListBuilder.create().texOffs(670, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(1.6875F, -22.95417504489056F, -5.9375F, -2.924684152746197F, -0.001963250808881076F, 0.018247933733736208F));
        g.addOrReplaceChild("carga_13", CubeListBuilder.create().texOffs(694, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(5.0625F, -22.821158219597844F, -5.9375F, -2.9393521081549974F, -0.005916711490981425F, 0.05885649381957145F));
        g.addOrReplaceChild("carga_14", CubeListBuilder.create().texOffs(718, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(8.4375F, -22.516543550430324F, -5.9375F, -2.973362512184162F, -0.009933181603201575F, 0.1181070465791644F));
        g.addOrReplaceChild("carga_15", CubeListBuilder.create().texOffs(312, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(11.8125F, -21.656709275215164F, -5.9375F, -3.072667672517135F, -0.01336463492754287F, 0.37020508587842166F));
        g.addOrReplaceChild("carga_16", CubeListBuilder.create().texOffs(338, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-11.8125F, -21.78861665008227F, -3.5625F, -3.108075824495005F, 0.007824939823500446F, -0.43690804130048827F));
        g.addOrReplaceChild("carga_17", CubeListBuilder.create().texOffs(742, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-8.4375F, -22.821158219597848F, -3.5625F, -3.0572060870046336F, 0.006069634418019848F, -0.14304038759488258F));
        g.addOrReplaceChild("carga_18", CubeListBuilder.create().texOffs(766, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-5.0625F, -23.186958139031148F, -3.5625F, -3.0395823281722754F, 0.0036581137094817903F, -0.07172257786977812F));
        g.addOrReplaceChild("carga_19", CubeListBuilder.create().texOffs(790, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.6875F, -23.346692875734163F, -3.5625F, -3.0319341905640504F, 0.0012202746409301086F, -0.022297284031419628F));
        g.addOrReplaceChild("carga_20", CubeListBuilder.create().texOffs(814, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(1.6875F, -23.346692875734163F, -3.5625F, -3.0319341905640504F, -0.0012202746409301086F, 0.022297284031419628F));
        g.addOrReplaceChild("carga_21", CubeListBuilder.create().texOffs(838, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(5.0625F, -23.186958139031148F, -3.5625F, -3.0395823281722754F, -0.0036581137094817903F, 0.07172257786977812F));
        g.addOrReplaceChild("carga_22", CubeListBuilder.create().texOffs(862, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(8.4375F, -22.821158219597844F, -3.5625F, -3.0572060870046336F, -0.006069634418019848F, 0.14304038759488258F));
        g.addOrReplaceChild("carga_23", CubeListBuilder.create().texOffs(364, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(11.8125F, -21.78861665008227F, -3.5625F, -3.108075824495005F, -0.007824939823500446F, 0.43690804130048827F));
        g.addOrReplaceChild("carga_24", CubeListBuilder.create().texOffs(390, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-11.8125F, -21.846216962915104F, -1.1875F, -3.1313161256279565F, 0.0025764308784818855F, -0.46478997046899684F));
        g.addOrReplaceChild("carga_25", CubeListBuilder.create().texOffs(886, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-8.4375F, -22.95417504489056F, -1.1875F, -3.1153631407193636F, 0.002033227143856257F, -0.15382632069696542F));
        g.addOrReplaceChild("carga_26", CubeListBuilder.create().texOffs(910, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-5.0625F, -23.346692875734163F, -1.1875F, -3.1098167546166877F, 0.0012304412902262925F, -0.07730361052621053F));
        g.addOrReplaceChild("carga_27", CubeListBuilder.create().texOffs(934, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.6875F, -23.51809458751741F, -1.1875F, -3.1074053588870143F, 0.00041119303635703887F, -0.024055361835793744F));
        g.addOrReplaceChild("carga_28", CubeListBuilder.create().texOffs(958, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(1.6875F, -23.51809458751741F, -1.1875F, -3.1074053588870143F, -0.00041119303635703887F, 0.024055361835793744F));
        g.addOrReplaceChild("carga_29", CubeListBuilder.create().texOffs(982, 29).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(5.0625F, -23.346692875734163F, -1.1875F, -3.1098167546166877F, -0.0012304412902262925F, 0.07730361052621053F));
        g.addOrReplaceChild("carga_30", CubeListBuilder.create().texOffs(0, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(8.4375F, -22.95417504489056F, -1.1875F, -3.1153631407193636F, -0.002033227143856257F, 0.15382632069696542F));
        g.addOrReplaceChild("carga_31", CubeListBuilder.create().texOffs(416, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(11.8125F, -21.846216962915104F, -1.1875F, -3.1313161256279565F, -0.0025764308784818855F, 0.46478997046899684F));
        g.addOrReplaceChild("carga_32", CubeListBuilder.create().texOffs(442, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-11.8125F, -21.846216962915104F, 1.1875F, 3.1313161256279565F, -0.0025764308784818855F, -0.46478997046899684F));
        g.addOrReplaceChild("carga_33", CubeListBuilder.create().texOffs(24, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-8.4375F, -22.95417504489056F, 1.1875F, 3.1153631407193636F, -0.002033227143856257F, -0.15382632069696542F));
        g.addOrReplaceChild("carga_34", CubeListBuilder.create().texOffs(48, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-5.0625F, -23.346692875734163F, 1.1875F, 3.1098167546166877F, -0.0012304412902262925F, -0.07730361052621053F));
        g.addOrReplaceChild("carga_35", CubeListBuilder.create().texOffs(72, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.6875F, -23.518094587517414F, 1.1875F, 3.1074053588870143F, -0.00041119303635703887F, -0.024055361835793744F));
        g.addOrReplaceChild("carga_36", CubeListBuilder.create().texOffs(96, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(1.6875F, -23.51809458751741F, 1.1875F, 3.1074053588870143F, 0.00041119303635703887F, 0.024055361835793744F));
        g.addOrReplaceChild("carga_37", CubeListBuilder.create().texOffs(120, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(5.0625F, -23.346692875734163F, 1.1875F, 3.1098167546166877F, 0.0012304412902262925F, 0.07730361052621053F));
        g.addOrReplaceChild("carga_38", CubeListBuilder.create().texOffs(144, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(8.4375F, -22.95417504489056F, 1.1875F, 3.1153631407193636F, 0.002033227143856257F, 0.15382632069696542F));
        g.addOrReplaceChild("carga_39", CubeListBuilder.create().texOffs(468, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(11.8125F, -21.846216962915104F, 1.1875F, 3.1313161256279565F, 0.0025764308784818855F, 0.46478997046899684F));
        g.addOrReplaceChild("carga_40", CubeListBuilder.create().texOffs(494, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-11.8125F, -21.78861665008227F, 3.5625F, 3.108075824495005F, -0.007824939823500446F, -0.43690804130048827F));
        g.addOrReplaceChild("carga_41", CubeListBuilder.create().texOffs(168, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-8.4375F, -22.821158219597844F, 3.5625F, 3.0572060870046336F, -0.006069634418019848F, -0.14304038759488258F));
        g.addOrReplaceChild("carga_42", CubeListBuilder.create().texOffs(192, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-5.0625F, -23.186958139031148F, 3.5625F, 3.0395823281722754F, -0.0036581137094817903F, -0.07172257786977812F));
        g.addOrReplaceChild("carga_43", CubeListBuilder.create().texOffs(216, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.6875F, -23.346692875734163F, 3.5625F, 3.0319341905640504F, -0.0012202746409301086F, -0.022297284031419628F));
        g.addOrReplaceChild("carga_44", CubeListBuilder.create().texOffs(240, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(1.6875F, -23.346692875734163F, 3.5625F, 3.0319341905640504F, 0.0012202746409301086F, 0.022297284031419628F));
        g.addOrReplaceChild("carga_45", CubeListBuilder.create().texOffs(264, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(5.0625F, -23.186958139031148F, 3.5625F, 3.0395823281722754F, 0.0036581137094817903F, 0.07172257786977812F));
        g.addOrReplaceChild("carga_46", CubeListBuilder.create().texOffs(288, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(8.4375F, -22.821158219597844F, 3.5625F, 3.0572060870046336F, 0.006069634418019848F, 0.14304038759488258F));
        g.addOrReplaceChild("carga_47", CubeListBuilder.create().texOffs(520, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(11.8125F, -21.78861665008227F, 3.5625F, 3.108075824495005F, 0.007824939823500446F, 0.43690804130048827F));
        g.addOrReplaceChild("carga_48", CubeListBuilder.create().texOffs(546, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-11.8125F, -21.656709275215164F, 5.9375F, 3.072667672517135F, -0.01336463492754287F, -0.37020508587842166F));
        g.addOrReplaceChild("carga_49", CubeListBuilder.create().texOffs(312, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-8.4375F, -22.516543550430324F, 5.9375F, 2.973362512184162F, -0.009933181603201575F, -0.1181070465791644F));
        g.addOrReplaceChild("carga_50", CubeListBuilder.create().texOffs(336, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-5.0625F, -22.821158219597844F, 5.9375F, 2.9393521081549974F, -0.005916711490981425F, -0.05885649381957145F));
        g.addOrReplaceChild("carga_51", CubeListBuilder.create().texOffs(360, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.6875F, -22.95417504489056F, 5.9375F, 2.924684152746197F, -0.001963250808881076F, -0.018247933733736208F));
        g.addOrReplaceChild("carga_52", CubeListBuilder.create().texOffs(384, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(1.6875F, -22.95417504489056F, 5.9375F, 2.924684152746197F, 0.001963250808881076F, 0.018247933733736208F));
        g.addOrReplaceChild("carga_53", CubeListBuilder.create().texOffs(408, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(5.0625F, -22.821158219597844F, 5.9375F, 2.9393521081549974F, 0.005916711490981425F, 0.05885649381957145F));
        g.addOrReplaceChild("carga_54", CubeListBuilder.create().texOffs(432, 36).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(8.4375F, -22.516543550430324F, 5.9375F, 2.973362512184162F, 0.009933181603201575F, 0.1181070465791644F));
        g.addOrReplaceChild("carga_55", CubeListBuilder.create().texOffs(572, 29).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(11.8125F, -21.656709275215164F, 5.9375F, 3.072667672517135F, 0.01336463492754287F, 0.37020508587842166F));
        g.addOrReplaceChild("carga_56", CubeListBuilder.create().texOffs(78, 29).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-11.8125F, -21.284375F, 8.3125F, 2.9096548540646157F, -0.01883689951082585F, -0.16250117299342093F));
        g.addOrReplaceChild("carga_57", CubeListBuilder.create().texOffs(104, 29).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-8.4375F, -21.656709275215164F, 8.3125F, 2.63697579606697F, -0.011026887027810243F, -0.045986798187769545F));
        g.addOrReplaceChild("carga_58", CubeListBuilder.create().texOffs(130, 29).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-5.0625F, -21.78861665008227F, 8.3125F, 2.5555145804250956F, -0.005999822158184684F, -0.022054253650837383F));
        g.addOrReplaceChild("carga_59", CubeListBuilder.create().texOffs(156, 29).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-1.6875F, -21.846216962915104F, 8.3125F, 2.5224719452645203F, -0.0019117209664943635F, -0.006727766859264725F));
        g.addOrReplaceChild("carga_60", CubeListBuilder.create().texOffs(182, 29).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(1.6875F, -21.846216962915104F, 8.3125F, 2.5224719452645203F, 0.0019117209664943635F, 0.006727766859264725F));
        g.addOrReplaceChild("carga_61", CubeListBuilder.create().texOffs(208, 29).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(5.0625F, -21.78861665008227F, 8.3125F, 2.5555145804250956F, 0.005999822158184684F, 0.022054253650837383F));
        g.addOrReplaceChild("carga_62", CubeListBuilder.create().texOffs(234, 29).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(8.4375F, -21.656709275215164F, 8.3125F, 2.63697579606697F, 0.011026887027810243F, 0.045986798187769545F));
        g.addOrReplaceChild("carga_63", CubeListBuilder.create().texOffs(260, 29).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(11.8125F, -21.284375F, 8.3125F, 2.9096548540646157F, 0.01883689951082585F, 0.16250117299342093F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "pistoni_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "pistoni_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "pistond_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "pistond_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "carga_0", 0.5026096397863862F, 1.0F, 0.4256958179457719F);
        escalar(g0, "carga_1", 0.4905921146653908F, 1.0F, 0.4613913358452742F);
        escalar(g0, "carga_2", 0.48961250831447806F, 1.0F, 0.48365932436514697F);
        escalar(g0, "carga_3", 0.4893172691178531F, 1.0F, 0.4944018029197969F);
        escalar(g0, "carga_4", 0.4893172691178531F, 1.0F, 0.4944018029197969F);
        escalar(g0, "carga_5", 0.48961250831447806F, 1.0F, 0.48365932436514697F);
        escalar(g0, "carga_6", 0.4905921146653908F, 1.0F, 0.4613913358452742F);
        escalar(g0, "carga_7", 0.5026096397863862F, 1.0F, 0.4256958179457719F);
        escalar(g0, "carga_8", 0.45940868047573835F, 1.0F, 0.48759194791875105F);
        escalar(g0, "carga_9", 0.492827363601197F, 1.0F, 0.4920182860186667F);
        escalar(g0, "carga_10", 0.49017245605446363F, 1.0F, 0.4949466640667849F);
        escalar(g0, "carga_11", 0.48937136058759206F, 1.0F, 0.49640422180890376F);
        escalar(g0, "carga_12", 0.48937136058759206F, 1.0F, 0.49640422180890376F);
        escalar(g0, "carga_13", 0.49017245605446363F, 1.0F, 0.4949466640667849F);
        escalar(g0, "carga_14", 0.492827363601197F, 1.0F, 0.4920182860186667F);
        escalar(g0, "carga_15", 0.45940868047573835F, 1.0F, 0.48759194791875105F);
        escalar(g0, "carga_16", 0.472026090060481F, 1.0F, 0.48564970013435416F);
        escalar(g0, "carga_17", 0.4943118231063938F, 1.0F, 0.4867623887231433F);
        escalar(g0, "carga_18", 0.49054539406760395F, 1.0F, 0.4875027395420742F);
        escalar(g0, "carga_19", 0.4894074181967503F, 1.0F, 0.48787248449341086F);
        escalar(g0, "carga_20", 0.4894074181967503F, 1.0F, 0.48787248449341086F);
        escalar(g0, "carga_21", 0.49054539406760395F, 1.0F, 0.4875027395420742F);
        escalar(g0, "carga_22", 0.4943118231063938F, 1.0F, 0.4867623887231433F);
        escalar(g0, "carga_23", 0.472026090060481F, 1.0F, 0.48564970013435416F);
        escalar(g0, "carga_24", 0.4782065877676257F, 1.0F, 0.48506277332098524F);
        escalar(g0, "carga_25", 0.4950523566089476F, 1.0F, 0.4851703745749055F);
        escalar(g0, "carga_26", 0.49073175518055895F, 1.0F, 0.4852420952085069F);
        escalar(g0, "carga_27", 0.48942544599035587F, 1.0F, 0.48527795146644265F);
        escalar(g0, "carga_28", 0.48942544599035587F, 1.0F, 0.48527795146644265F);
        escalar(g0, "carga_29", 0.49073175518055895F, 1.0F, 0.4852420952085069F);
        escalar(g0, "carga_30", 0.4950523566089476F, 1.0F, 0.4851703745749055F);
        escalar(g0, "carga_31", 0.4782065877676257F, 1.0F, 0.48506277332098524F);
        escalar(g0, "carga_32", 0.4782065877676257F, 1.0F, 0.48506277332098524F);
        escalar(g0, "carga_33", 0.4950523566089476F, 1.0F, 0.4851703745749055F);
        escalar(g0, "carga_34", 0.49073175518055895F, 1.0F, 0.4852420952085069F);
        escalar(g0, "carga_35", 0.48942544599035587F, 1.0F, 0.48527795146644265F);
        escalar(g0, "carga_36", 0.48942544599035587F, 1.0F, 0.48527795146644265F);
        escalar(g0, "carga_37", 0.49073175518055895F, 1.0F, 0.4852420952085069F);
        escalar(g0, "carga_38", 0.4950523566089476F, 1.0F, 0.4851703745749055F);
        escalar(g0, "carga_39", 0.4782065877676257F, 1.0F, 0.48506277332098524F);
        escalar(g0, "carga_40", 0.472026090060481F, 1.0F, 0.48564970013435416F);
        escalar(g0, "carga_41", 0.4943118231063938F, 1.0F, 0.4867623887231433F);
        escalar(g0, "carga_42", 0.49054539406760395F, 1.0F, 0.4875027395420742F);
        escalar(g0, "carga_43", 0.4894074181967503F, 1.0F, 0.48787248449341086F);
        escalar(g0, "carga_44", 0.4894074181967503F, 1.0F, 0.48787248449341086F);
        escalar(g0, "carga_45", 0.49054539406760395F, 1.0F, 0.4875027395420742F);
        escalar(g0, "carga_46", 0.4943118231063938F, 1.0F, 0.4867623887231433F);
        escalar(g0, "carga_47", 0.472026090060481F, 1.0F, 0.48564970013435416F);
        escalar(g0, "carga_48", 0.45940868047573835F, 1.0F, 0.48759194791875105F);
        escalar(g0, "carga_49", 0.492827363601197F, 1.0F, 0.4920182860186667F);
        escalar(g0, "carga_50", 0.49017245605446363F, 1.0F, 0.4949466640667849F);
        escalar(g0, "carga_51", 0.48937136058759206F, 1.0F, 0.49640422180890376F);
        escalar(g0, "carga_52", 0.48937136058759206F, 1.0F, 0.49640422180890376F);
        escalar(g0, "carga_53", 0.49017245605446363F, 1.0F, 0.4949466640667849F);
        escalar(g0, "carga_54", 0.492827363601197F, 1.0F, 0.4920182860186667F);
        escalar(g0, "carga_55", 0.45940868047573835F, 1.0F, 0.48759194791875105F);
        escalar(g0, "carga_56", 0.5026096397863862F, 1.0F, 0.4256958179457719F);
        escalar(g0, "carga_57", 0.4905921146653908F, 1.0F, 0.4613913358452742F);
        escalar(g0, "carga_58", 0.48961250831447806F, 1.0F, 0.48365932436514697F);
        escalar(g0, "carga_59", 0.4893172691178531F, 1.0F, 0.4944018029197969F);
        escalar(g0, "carga_60", 0.4893172691178531F, 1.0F, 0.4944018029197969F);
        escalar(g0, "carga_61", 0.48961250831447806F, 1.0F, 0.48365932436514697F);
        escalar(g0, "carga_62", 0.4905921146653908F, 1.0F, 0.4613913358452742F);
        escalar(g0, "carga_63", 0.5026096397863862F, 1.0F, 0.4256958179457719F);
    }
}
