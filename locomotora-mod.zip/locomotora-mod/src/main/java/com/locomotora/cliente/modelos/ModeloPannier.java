package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "GWR 5700 Pannier" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloPannier {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("pannier"), "main"),
            LocomotoraMod.id("textures/entity/pannier.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -21.0F, -6.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -21.0F, -6.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -21.0F, -6.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -1.0F, -6.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -1.0F, -6.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -1.0F, -6.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 22.0F, -6.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 22.0F, -6.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 22.0F, -6.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -21.0F, -6.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -21.0F, -6.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -21.0F, -6.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -1.0F, -6.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -1.0F, -6.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -1.0F, -6.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 22.0F, -6.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 22.0F, -6.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 22.0F, -6.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 6.5F, 2.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 6.5F, 2.5F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 11.719999999999999F, -27.6F, 0.0F, "cuerpo", 4.8F, 2.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.0F, 0.0F, 16.0F, -15.0F, 0.0F, "cuerpo", -0.22F, 8.0F, 0.0F)),
            ModeloPannier::crearCapa,
            16.0F,
            ModeloPannier::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -21.0F, 22.0F)));

    private ModeloPannier() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
        escalas2(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(116, 119).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(332, 147).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(250, 119).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(422, 147).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(424, 165).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-21.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(362, 147).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(260, 119).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-21.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(392, 147).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(270, 119).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-21.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(116, 119).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(332, 147).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(250, 119).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(432, 147).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(430, 165).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-1.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(362, 147).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(260, 119).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-1.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(392, 147).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(270, 119).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-1.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(116, 119).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(332, 147).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(250, 119).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 147).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(436, 165).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(22.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(362, 147).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(260, 119).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(392, 147).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(270, 119).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(116, 119).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(332, 147).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(250, 119).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(452, 147).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(442, 165).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-21.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(362, 147).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(260, 119).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-21.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(392, 147).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(270, 119).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-21.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(116, 119).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(332, 147).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(250, 119).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(462, 147).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(448, 165).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-1.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(362, 147).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(260, 119).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-1.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(392, 147).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(270, 119).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-1.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(116, 119).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(332, 147).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(250, 119).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(472, 147).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(454, 165).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(22.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(362, 147).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(260, 119).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(392, 147).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(270, 119).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(22.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(490, 165).addBox(-21.0F, -9.5F, -7.5F, 43.0F, 1.0F, 1.0F).texOffs(292, 152).addBox(-22.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(300, 152).addBox(-2.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(308, 152).addBox(20.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(578, 165).addBox(-21.0F, -9.5F, 6.5F, 43.0F, 1.0F, 1.0F).texOffs(316, 152).addBox(-22.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(324, 152).addBox(-2.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(332, 152).addBox(20.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(84, 135).addBox(-40.0F, -13.0F, 2.0F, 82.0F, 10.0F, 1.0F).texOffs(250, 135).addBox(-40.0F, -13.0F, -3.0F, 82.0F, 10.0F, 1.0F).texOffs(298, 86).addBox(-44.0F, -13.0F, -12.0F, 3.0F, 7.0F, 24.0F).texOffs(352, 86).addBox(42.0F, -13.0F, -12.0F, 3.0F, 7.0F, 24.0F).texOffs(348, 152).addBox(-46.0F, -11.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(502, 86).addBox(-41.0F, -14.0F, -12.0F, 83.0F, 1.0F, 24.0F).texOffs(0, 147).addBox(-40.0F, -13.0F, 11.0F, 82.0F, 4.0F, 1.0F).texOffs(166, 147).addBox(-40.0F, -13.0F, -12.0F, 82.0F, 4.0F, 1.0F).texOffs(478, 165).addBox(-40.0F, -23.0F, -0.5F, 1.0F, 2.0F, 1.0F).texOffs(456, 86).addBox(0.0F, -28.0F, -7.0F, 9.0F, 14.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("tope_i_0", CubeListBuilder.create().texOffs(58, 86).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(346, 43).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, -8.0F));
        g.addOrReplaceChild("tope_i_1", CubeListBuilder.create().texOffs(78, 86).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(404, 43).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_i_2", CubeListBuilder.create().texOffs(98, 86).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(462, 43).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_0", CubeListBuilder.create().texOffs(1008, 119).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(656, 119).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, -8.0F));
        g.addOrReplaceChild("tope_ic_1", CubeListBuilder.create().texOffs(1014, 119).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(678, 119).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_2", CubeListBuilder.create().texOffs(0, 135).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(700, 119).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_3", CubeListBuilder.create().texOffs(6, 135).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(722, 119).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ti_0", CubeListBuilder.create().texOffs(118, 86).addBox(45.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(520, 43).addBox(45.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, -8.0F));
        g.addOrReplaceChild("tope_ti_1", CubeListBuilder.create().texOffs(138, 86).addBox(45.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(578, 43).addBox(45.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ti_2", CubeListBuilder.create().texOffs(158, 86).addBox(45.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(636, 43).addBox(45.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_0", CubeListBuilder.create().texOffs(12, 135).addBox(48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(744, 119).addBox(48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, -8.0F));
        g.addOrReplaceChild("tope_tic_1", CubeListBuilder.create().texOffs(18, 135).addBox(48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(766, 119).addBox(48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_2", CubeListBuilder.create().texOffs(24, 135).addBox(48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(788, 119).addBox(48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_3", CubeListBuilder.create().texOffs(30, 135).addBox(48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(810, 119).addBox(48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, -8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_0", CubeListBuilder.create().texOffs(178, 86).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(694, 43).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, 8.0F));
        g.addOrReplaceChild("tope_d_1", CubeListBuilder.create().texOffs(198, 86).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(752, 43).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_2", CubeListBuilder.create().texOffs(218, 86).addBox(-47.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(810, 43).addBox(-47.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_0", CubeListBuilder.create().texOffs(36, 135).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(832, 119).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, 8.0F));
        g.addOrReplaceChild("tope_dc_1", CubeListBuilder.create().texOffs(42, 135).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(854, 119).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_2", CubeListBuilder.create().texOffs(48, 135).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(876, 119).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_3", CubeListBuilder.create().texOffs(54, 135).addBox(-48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(898, 119).addBox(-48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_0", CubeListBuilder.create().texOffs(238, 86).addBox(45.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(868, 43).addBox(45.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.0F, 8.0F));
        g.addOrReplaceChild("tope_td_1", CubeListBuilder.create().texOffs(258, 86).addBox(45.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(926, 43).addBox(45.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_2", CubeListBuilder.create().texOffs(278, 86).addBox(45.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(0, 86).addBox(45.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_0", CubeListBuilder.create().texOffs(60, 135).addBox(48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(920, 119).addBox(48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.0F, 8.0F));
        g.addOrReplaceChild("tope_tdc_1", CubeListBuilder.create().texOffs(66, 135).addBox(48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(942, 119).addBox(48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_2", CubeListBuilder.create().texOffs(72, 135).addBox(48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(964, 119).addBox(48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_3", CubeListBuilder.create().texOffs(78, 135).addBox(48.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(986, 119).addBox(48.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.0F, 8.0F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_0", CubeListBuilder.create().texOffs(0, 43).addBox(-38.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(0, 0).addBox(-38.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offset(0.0F, -22.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_1", CubeListBuilder.create().texOffs(26, 43).addBox(-38.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(92, 0).addBox(-38.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 0.2617993877991494F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_2", CubeListBuilder.create().texOffs(52, 43).addBox(-38.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(184, 0).addBox(-38.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_3", CubeListBuilder.create().texOffs(78, 43).addBox(-38.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(276, 0).addBox(-38.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_4", CubeListBuilder.create().texOffs(104, 43).addBox(-38.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(368, 0).addBox(-38.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_5", CubeListBuilder.create().texOffs(130, 43).addBox(-38.0F, -19.0F, -2.5F, 8.0F, 38.0F, 5.0F).texOffs(460, 0).addBox(-38.0F, -2.5F, -19.0F, 8.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 1.3089969389957472F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_0", CubeListBuilder.create().texOffs(156, 43).addBox(-39.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(552, 0).addBox(-39.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offset(0.0F, -22.0F, 0.0F));
        g.addOrReplaceChild("puerta_1", CubeListBuilder.create().texOffs(168, 43).addBox(-39.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(630, 0).addBox(-39.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 0.2617993877991494F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_2", CubeListBuilder.create().texOffs(180, 43).addBox(-39.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(708, 0).addBox(-39.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_3", CubeListBuilder.create().texOffs(192, 43).addBox(-39.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(786, 0).addBox(-39.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_4", CubeListBuilder.create().texOffs(204, 43).addBox(-39.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(864, 0).addBox(-39.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta_5", CubeListBuilder.create().texOffs(216, 43).addBox(-39.0F, -19.0F, -2.5F, 1.0F, 38.0F, 5.0F).texOffs(942, 0).addBox(-39.0F, -2.5F, -19.0F, 1.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 1.3089969389957472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(998, 152).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -28.171649725568198F, 0.6953779186134825F, 3.029397898201175F, -0.0010595762434205402F, -0.009404141392202064F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(0, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -28.270396121177292F, 0.7065039653112982F, 3.029397898201176F, -0.0010595762434205509F, -0.009404141392201894F));
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(26, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -28.36914251678638F, 0.7176300120091139F, 3.029397898201176F, -0.0010595762434205402F, -0.009404141392201894F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(52, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -28.46788891239547F, 0.7287560587069296F, 3.029397898201174F, -0.0010595762434205296F, -0.009404141392202064F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(78, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -27.86217743776326F, 2.0512646033558517F, 2.8050074006906396F, -0.0031256016573580733F, -0.008932604220622434F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(104, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -27.955972276767472F, 2.084084837009545F, 2.805007400690639F, -0.0031256016573581263F, -0.008932604220622434F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(130, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -28.049767115771683F, 2.116905070663239F, 2.8050074006906396F, -0.0031256016573580733F, -0.008932604220622265F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(156, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -28.143561954775894F, 2.1497253043169327F, 2.80500740069064F, -0.0031256016573580625F, -0.008932604220622434F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(182, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -27.25875109490765F, 3.304292315550911F, 2.580614138369391F, -0.005034907900589012F, -0.008013163486842063F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(208, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -27.342891112426173F, 3.357160992599726F, 2.5806141383693917F, -0.005034907900589055F, -0.008013163486842063F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(234, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -27.427031129944698F, 3.4100296696485404F, 2.5806141383693912F, -0.005034907900589012F, -0.008013163486841895F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(260, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -27.511171147463223F, 3.4628983466973544F, 2.580614138369391F, -0.005034907900588991F, -0.008013163486842063F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(286, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -26.391629013521136F, 4.391629013521135F, 2.356216880662569F, -0.006691756390478652F, -0.006691906222610063F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(312, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -26.461895077737474F, 4.4618950777374735F, 2.3562168806625685F, -0.006691756390478652F, -0.006691906222610063F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(338, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -26.532161141953814F, 4.532161141953812F, 2.356216880662569F, -0.00669175639047861F, -0.006691906222609894F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(364, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -26.602427206170148F, 4.60242720617015F, 2.3562168806625685F, -0.006691756390478589F, -0.006691906222609894F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(390, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -25.304292315550914F, 5.258751094907653F, 2.131815188248522F, -0.008013061916843188F, -0.005035069549886532F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(416, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -25.357160992599727F, 5.342891112426176F, 2.1318151882485217F, -0.008013061916843273F, -0.005035069549886363F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(442, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -25.410029669648544F, 5.427031129944698F, 2.1318151882485212F, -0.008013061916843147F, -0.005035069549886532F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(468, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -25.462898346697358F, 5.5111711474632195F, 2.131815188248522F, -0.008013061916843147F, -0.005035069549886363F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(494, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -24.051264603355854F, 5.8621774377632585F, 1.9074095001537479F, -0.008932560586469228F, -0.0031257263587861233F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(520, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -24.084084837009545F, 5.955972276767471F, 1.9074095001537479F, -0.008932560586469398F, -0.0031257263587861233F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(546, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -24.11690507066324F, 6.049767115771683F, 1.9074095001537483F, -0.008932560586469228F, -0.0031257263587862925F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(572, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -24.14972530431693F, 6.143561954775894F, 1.907409500153748F, -0.008932560586469272F, -0.0031257263587861233F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(598, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -22.69537791861348F, 6.171649725568199F, 1.6830010468802126F, -0.009404136113023454F, -0.0010596230984477744F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(624, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -22.7065039653113F, 6.27039612117729F, 1.6830010468802126F, -0.00940413611302358F, -0.0010596230984479436F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(650, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -22.717630012009113F, 6.369142516786381F, 1.6830010468802126F, -0.009404136113023454F, -0.0010596230984479436F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(676, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -22.728756058706928F, 6.4678889123954715F, 1.6830010468802126F, -0.009404136113023497F, -0.0010596230984477744F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(702, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -21.30462208138652F, 6.171649725568199F, 1.4585916067095805F, -0.009404136113023454F, 0.0010596230984479436F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(728, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -21.293496034688705F, 6.27039612117729F, 1.4585916067095805F, -0.00940413611302358F, 0.0010596230984479436F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(754, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -21.282369987990887F, 6.369142516786381F, 1.4585916067095805F, -0.009404136113023454F, 0.0010596230984479436F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(780, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -21.271243941293072F, 6.4678889123954715F, 1.4585916067095805F, -0.009404136113023497F, 0.0010596230984477744F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(806, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -19.94873539664415F, 5.8621774377632585F, 1.2341831534360455F, -0.008932560586469228F, 0.0031257263587862925F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(832, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -19.915915162990455F, 5.955972276767471F, 1.2341831534360452F, -0.008932560586469355F, 0.0031257263587862925F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(858, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -19.88309492933676F, 6.049767115771683F, 1.2341831534360452F, -0.008932560586469272F, 0.0031257263587862925F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(884, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -19.85027469568307F, 6.143561954775895F, 1.2341831534360452F, -0.008932560586469272F, 0.003125726358785954F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(910, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -18.69570768444909F, 5.2587510949076535F, 1.0097774653412719F, -0.008013061916843147F, 0.005035069549886532F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(936, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -18.642839007400276F, 5.342891112426176F, 1.0097774653412717F, -0.008013061916843232F, 0.005035069549886532F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(962, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -18.58997033035146F, 5.427031129944699F, 1.0097774653412714F, -0.008013061916843188F, 0.005035069549886532F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(988, 156).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -18.537101653302646F, 5.511171147463221F, 1.009777465341272F, -0.008013061916843188F, 0.005035069549886363F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(0, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -17.608370986478867F, 4.391629013521136F, 0.7853757729272253F, -0.006691756390478589F, 0.006691906222610063F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(26, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -17.538104922262526F, 4.461895077737475F, 0.7853757729272257F, -0.006691756390478673F, 0.006691906222610063F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(52, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -17.46783885804619F, 4.5321611419538135F, 0.7853757729272254F, -0.00669175639047861F, 0.006691906222609894F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(78, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -17.397572793829852F, 4.602427206170152F, 0.7853757729272248F, -0.00669175639047863F, 0.006691906222610063F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(104, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -16.74124890509235F, 3.3042923155509123F, 0.5609785152204023F, -0.005034907900588991F, 0.008013163486842063F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(130, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -16.657108887573827F, 3.3571609925997263F, 0.5609785152204017F, -0.005034907900589055F, 0.008013163486842063F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(156, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -16.572968870055302F, 3.4100296696485417F, 0.5609785152204019F, -0.005034907900589012F, 0.008013163486841895F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(182, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -16.48882885253678F, 3.4628983466973557F, 0.5609785152204012F, -0.005034907900589012F, 0.008013163486841895F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(208, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -16.137822562236742F, 2.0512646033558535F, 0.33658525289915436F, -0.0031256016573580733F, 0.008932604220622434F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(234, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -16.044027723232528F, 2.0840848370095473F, 0.33658525289915436F, -0.003125601657358105F, 0.00893260422062235F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(260, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -15.950232884228317F, 2.116905070663241F, 0.33658525289915375F, -0.0031256016573580733F, 0.00893260422062235F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(286, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -15.856438045224106F, 2.149725304316935F, 0.3365852528991548F, -0.0031256016573580946F, 0.008932604220622265F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(312, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -15.828350274431802F, 0.6953779186134846F, 0.11219475538861778F, -0.001059576243420541F, 0.009404141392202064F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(338, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -15.72960387882271F, 0.7065039653113003F, 0.11219475538861809F, -0.0010595762434205515F, 0.009404141392201894F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(364, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -15.63085748321362F, 0.7176300120091161F, 0.11219475538861842F, -0.001059576243420541F, 0.009404141392201894F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(390, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -15.532111087604529F, 0.7287560587069319F, 0.1121947553886181F, -0.001059576243420541F, 0.009404141392201979F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(416, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -15.828350274431802F, -0.6953779186134819F, -0.112194755388618F, 0.0010595762434205396F, 0.009404141392202064F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(442, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -15.729603878822708F, -0.7065039653112974F, -0.11219475538861767F, 0.0010595762434205502F, 0.009404141392201979F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(468, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -15.630857483213617F, -0.7176300120091131F, -0.112194755388618F, 0.001059576243420529F, 0.009404141392201809F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(494, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -15.532111087604529F, -0.7287560587069288F, -0.11219475538861831F, 0.0010595762434205396F, 0.009404141392201979F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(520, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -16.137822562236742F, -2.0512646033558513F, -0.33658525289915375F, 0.0031256016573580733F, 0.008932604220622434F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(546, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -16.044027723232528F, -2.0840848370095446F, -0.33658525289915425F, 0.003125601657358105F, 0.008932604220622434F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(572, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -15.950232884228317F, -2.1169050706632384F, -0.33658525289915364F, 0.0031256016573580625F, 0.008932604220622265F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(598, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -15.856438045224106F, -2.1497253043169318F, -0.33658525289915303F, 0.0031256016573580733F, 0.008932604220622434F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(624, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -16.74124890509235F, -3.3042923155509096F, -0.5609785152204021F, 0.005034907900588991F, 0.008013163486841895F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(650, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -16.657108887573827F, -3.3571609925997246F, -0.5609785152204024F, 0.005034907900589055F, 0.008013163486842063F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(676, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -16.572968870055302F, -3.410029669648539F, -0.5609785152204017F, 0.005034907900589012F, 0.008013163486842063F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(702, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -16.488828852536777F, -3.462898346697353F, -0.560978515220402F, 0.005034907900588991F, 0.008013163486841895F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(728, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -17.608370986478864F, -4.3916290135211336F, -0.7853757729272239F, 0.006691756390478589F, 0.006691906222609894F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(754, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -17.538104922262526F, -4.461895077737472F, -0.7853757729272235F, 0.006691756390478673F, 0.006691906222610063F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(780, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -17.467838858046186F, -4.53216114195381F, -0.785375772927224F, 0.00669175639047861F, 0.006691906222610063F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(806, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -17.39757279382985F, -4.602427206170148F, -0.7853757729272238F, 0.006691756390478589F, 0.006691906222609894F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(832, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -18.695707684449083F, -5.258751094907651F, -1.0097774653412708F, 0.008013061916843188F, 0.005035069549886532F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(858, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -18.64283900740027F, -5.342891112426174F, -1.0097774653412703F, 0.008013061916843232F, 0.005035069549886532F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(884, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -18.589970330351456F, -5.427031129944696F, -1.0097774653412708F, 0.008013061916843188F, 0.005035069549886363F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(910, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -18.537101653302642F, -5.511171147463218F, -1.0097774653412712F, 0.008013061916843147F, 0.005035069549886532F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(936, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -19.948735396644143F, -5.862177437763256F, -1.2341831534360441F, 0.008932560586469313F, 0.0031257263587862925F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(962, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -19.915915162990448F, -5.9559722767674685F, -1.2341831534360443F, 0.008932560586469313F, 0.0031257263587862925F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(988, 159).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -19.883094929336757F, -6.049767115771681F, -1.234183153436044F, 0.008932560586469313F, 0.0031257263587861233F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(0, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -19.850274695683062F, -6.143561954775892F, -1.2341831534360441F, 0.008932560586469228F, 0.0031257263587861233F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(26, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -21.304622081386515F, -6.171649725568199F, -1.45859160670958F, 0.009404136113023497F, 0.0010596230984479436F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(52, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -21.293496034688697F, -6.2703961211772885F, -1.45859160670958F, 0.009404136113023539F, 0.0010596230984479436F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(78, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -21.282369987990883F, -6.369142516786381F, -1.4585916067095803F, 0.009404136113023497F, 0.0010596230984479436F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(104, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -21.271243941293065F, -6.4678889123954715F, -1.45859160670958F, 0.009404136113023454F, 0.0010596230984477744F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(130, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -22.69537791861348F, -6.171649725568199F, -1.6830010468802128F, 0.009404136113023454F, -0.0010596230984479436F));
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(156, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -22.706503965311295F, -6.27039612117729F, -1.6830010468802126F, 0.00940413611302358F, -0.0010596230984479436F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(182, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -22.717630012009113F, -6.369142516786381F, -1.6830010468802128F, 0.009404136113023454F, -0.0010596230984477744F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(208, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -22.728756058706928F, -6.4678889123954715F, -1.6830010468802128F, 0.009404136113023497F, -0.0010596230984479436F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(234, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -24.05126460335585F, -5.8621774377632585F, -1.9074095001537474F, 0.008932560586469272F, -0.0031257263587862925F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(260, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -24.084084837009545F, -5.955972276767471F, -1.9074095001537474F, 0.008932560586469355F, -0.0031257263587862925F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(286, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -24.116905070663236F, -6.049767115771683F, -1.9074095001537474F, 0.008932560586469272F, -0.003125726358785954F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(312, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -24.14972530431693F, -6.143561954775895F, -1.9074095001537474F, 0.008932560586469272F, -0.0031257263587862925F));
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(338, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -25.30429231555091F, -5.2587510949076535F, -2.131815188248522F, 0.008013061916843188F, -0.005035069549886363F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(364, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -25.357160992599724F, -5.342891112426176F, -2.131815188248523F, 0.008013061916843273F, -0.005035069549886532F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(390, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -25.410029669648537F, -5.427031129944698F, -2.131815188248522F, 0.008013061916843188F, -0.005035069549886363F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(416, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -25.462898346697358F, -5.511171147463221F, -2.1318151882485217F, 0.008013061916843147F, -0.005035069549886532F));
        g.addOrReplaceChild("caldera_96", CubeListBuilder.create().texOffs(442, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -26.391629013521133F, -4.391629013521136F, -2.3562168806625676F, 0.00669175639047861F, -0.006691906222609894F));
        g.addOrReplaceChild("caldera_97", CubeListBuilder.create().texOffs(468, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -26.461895077737474F, -4.461895077737474F, -2.356216880662567F, 0.006691756390478695F, -0.006691906222609894F));
        g.addOrReplaceChild("caldera_98", CubeListBuilder.create().texOffs(494, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -26.53216114195381F, -4.532161141953813F, -2.356216880662568F, 0.006691756390478589F, -0.006691906222610063F));
        g.addOrReplaceChild("caldera_99", CubeListBuilder.create().texOffs(520, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -26.602427206170148F, -4.602427206170151F, -2.3562168806625676F, 0.00669175639047863F, -0.006691906222610063F));
        g.addOrReplaceChild("caldera_100", CubeListBuilder.create().texOffs(546, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -27.25875109490765F, -3.304292315550915F, -2.5806141383693912F, 0.005034907900589033F, -0.008013163486842063F));
        g.addOrReplaceChild("caldera_101", CubeListBuilder.create().texOffs(572, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -27.342891112426173F, -3.35716099259973F, -2.580614138369391F, 0.005034907900589033F, -0.008013163486841895F));
        g.addOrReplaceChild("caldera_102", CubeListBuilder.create().texOffs(598, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -27.427031129944694F, -3.4100296696485444F, -2.5806141383693904F, 0.005034907900588991F, -0.008013163486842063F));
        g.addOrReplaceChild("caldera_103", CubeListBuilder.create().texOffs(624, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -27.511171147463216F, -3.462898346697359F, -2.5806141383693912F, 0.005034907900589055F, -0.008013163486842063F));
        g.addOrReplaceChild("caldera_104", CubeListBuilder.create().texOffs(650, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -27.862177437763254F, -2.0512646033558584F, -2.805007400690637F, 0.0031256016573580946F, -0.008932604220622434F));
        g.addOrReplaceChild("caldera_105", CubeListBuilder.create().texOffs(676, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -27.95597227676747F, -2.0840848370095517F, -2.805007400690638F, 0.0031256016573581154F, -0.008932604220622265F));
        g.addOrReplaceChild("caldera_106", CubeListBuilder.create().texOffs(702, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -28.04976711577168F, -2.1169050706632455F, -2.8050074006906383F, 0.0031256016573580733F, -0.008932604220622434F));
        g.addOrReplaceChild("caldera_107", CubeListBuilder.create().texOffs(728, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -28.143561954775894F, -2.1497253043169393F, -2.805007400690638F, 0.0031256016573580946F, -0.008932604220622434F));
        g.addOrReplaceChild("caldera_108", CubeListBuilder.create().texOffs(754, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.75F, -28.171649725568198F, -0.6953779186134866F, -3.0293978982011756F, 0.0010595762434205415F, -0.009404141392202064F));
        g.addOrReplaceChild("caldera_109", CubeListBuilder.create().texOffs(780, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.25F, -28.270396121177292F, -0.7065039653113026F, -3.0293978982011756F, 0.0010595762434205626F, -0.009404141392201725F));
        g.addOrReplaceChild("caldera_110", CubeListBuilder.create().texOffs(806, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.75F, -28.36914251678638F, -0.7176300120091184F, -3.029397898201175F, 0.0010595762434205415F, -0.009404141392202064F));
        g.addOrReplaceChild("caldera_111", CubeListBuilder.create().texOffs(832, 162).addBox(-5.5F, -1.0F, -1.0F, 11.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.75F, -28.467888912395473F, -0.728756058706934F, -3.0293978982011747F, 0.0010595762434205415F, -0.009404141392202064F));
        g.addOrReplaceChild("chimenea_0", CubeListBuilder.create().texOffs(600, 135).addBox(-5.0F, -33.0F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(968, 86).addBox(-1.0F, -33.0F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offset(-34.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_1", CubeListBuilder.create().texOffs(624, 135).addBox(-5.0F, -33.0F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(992, 86).addBox(-1.0F, -33.0F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(-34.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_2", CubeListBuilder.create().texOffs(648, 135).addBox(-5.0F, -33.0F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(0, 119).addBox(-1.0F, -33.0F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(-34.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_3", CubeListBuilder.create().texOffs(672, 135).addBox(-5.0F, -33.0F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(24, 119).addBox(-1.0F, -33.0F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(-34.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea_copa_0", CubeListBuilder.create().texOffs(108, 152).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(560, 119).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offset(-34.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_copa_1", CubeListBuilder.create().texOffs(132, 152).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(584, 119).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-34.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_copa_2", CubeListBuilder.create().texOffs(156, 152).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(608, 119).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-34.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("chimenea_copa_3", CubeListBuilder.create().texOffs(180, 152).addBox(-5.0F, -34.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(632, 119).addBox(-1.0F, -34.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-34.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("valvulas_0", CubeListBuilder.create().texOffs(858, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.076501907537053F, -27.67830806393077F, 0.47865945514117736F, 0.07383839969171178F, 0.0071086925018682265F, -1.6306860044951013F));
        g.addOrReplaceChild("valvulas_1", CubeListBuilder.create().texOffs(40, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.2375954698347735F, -28.82700641892781F, 0.4522838755042444F, 0.07164089071042838F, 0.02956760240249634F, -1.822478028256912F));
        g.addOrReplaceChild("valvulas_2", CubeListBuilder.create().texOffs(48, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.555915507250058F, -29.664414921507433F, 0.4001658679493445F, 0.06507165474689164F, 0.056414223679443314F, -2.0664114590099207F));
        g.addOrReplaceChild("valvulas_3", CubeListBuilder.create().texOffs(56, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.02564423162746F, -30.298319024476406F, 0.3232579692049238F, 0.051724888206506135F, 0.08467255519348231F, -2.367267807138381F));
        g.addOrReplaceChild("valvulas_4", CubeListBuilder.create().texOffs(680, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.646171572998484F, -30.72789543167236F, 0.22166006500700194F, 0.03120253235737057F, 0.10720927585816555F, -2.706164942055812F));
        g.addOrReplaceChild("valvulas_5", CubeListBuilder.create().texOffs(868, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.218215181852354F, -27.67830806393077F, 1.237600924451729F, 0.3617098866799237F, 0.02525364477806117F, -1.627602156553507F));
        g.addOrReplaceChild("valvulas_6", CubeListBuilder.create().texOffs(64, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.371499915321631F, -28.82700641892781F, 1.1694053808538474F, 0.3513326292783428F, 0.0982071807455218F, -1.8125019454649285F));
        g.addOrReplaceChild("valvulas_7", CubeListBuilder.create().texOffs(72, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.674389747771642F, -29.664414921507433F, 1.0346513430139346F, 0.3201558584089943F, 0.1871965635775204F, -2.048990547950638F));
        g.addOrReplaceChild("valvulas_8", CubeListBuilder.create().texOffs(686, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.12134890176927F, -30.298319024476406F, 0.8358016481809722F, 0.2559597923762852F, 0.2805278539042517F, -2.3462033036777163F));
        g.addOrReplaceChild("valvulas_9", CubeListBuilder.create().texOffs(692, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.711796879799998F, -30.72789543167236F, 0.5731145565395447F, 0.1569443961354991F, 0.3800135012342055F, -2.685555131235589F));
        g.addOrReplaceChild("valvulas_10", CubeListBuilder.create().texOffs(878, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.501448110907747F, -27.67830806393077F, 1.7262583845336108F, 0.7030485786931147F, 0.035228746223619815F, -1.6218289623530795F));
        g.addOrReplaceChild("valvulas_11", CubeListBuilder.create().texOffs(80, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.639125855742694F, -28.82700641892781F, 1.6311363410721265F, 0.6861324479196649F, 0.15666111907995076F, -1.778238032880752F));
        g.addOrReplaceChild("valvulas_12", CubeListBuilder.create().texOffs(698, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.911176360194993F, -29.664414921507433F, 1.4431756801878737F, 0.6337627489118663F, 0.30093139021061877F, -1.9873976725232974F));
        g.addOrReplaceChild("valvulas_13", CubeListBuilder.create().texOffs(704, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.312627482971441F, -30.298319024476406F, 1.1658116719802831F, 0.5114806146709928F, 0.4259711658398801F, -2.2873026971523878F));
        g.addOrReplaceChild("valvulas_14", CubeListBuilder.create().texOffs(710, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.842957831061318F, -30.72789543167236F, 0.7994045487344327F, 0.31685075662718487F, 0.5450896647976443F, -2.6417267282047634F));
        g.addOrReplaceChild("valvulas_15", CubeListBuilder.create().texOffs(888, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.928489938559666F, -27.67830806393077F, 2.082126574243544F, 1.036541747254977F, 0.042500431812122916F, -1.6131181641829326F));
        g.addOrReplaceChild("valvulas_16", CubeListBuilder.create().texOffs(88, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.042636390713448F, -28.82700641892781F, 1.9673951202144204F, 1.019175435463895F, 0.19393284985844658F, -1.72373982518753F));
        g.addOrReplaceChild("valvulas_17", CubeListBuilder.create().texOffs(716, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.268189183774552F, -29.664414921507433F, 1.7406863665041723F, 0.9628651928048216F, 0.3783972887500337F, -1.8840755078965359F));
        g.addOrReplaceChild("valvulas_18", CubeListBuilder.create().texOffs(722, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.60102599362366F, -30.298319024476406F, 1.4061437641904662F, 0.8294056098931636F, 0.5932567961119024F, -2.1200967891319618F));
        g.addOrReplaceChild("valvulas_19", CubeListBuilder.create().texOffs(728, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.04071454151868F, -30.72789543167236F, 0.9642018074489026F, 0.5077328038169606F, 0.6982980708109688F, -2.5591168100964423F));
        g.addOrReplaceChild("valvulas_20", CubeListBuilder.create().texOffs(898, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.514878890657924F, -27.67830806393077F, 2.3181540151230378F, 1.312628316336317F, 0.04953825171609589F, -1.5927886953408337F));
        g.addOrReplaceChild("valvulas_21", CubeListBuilder.create().texOffs(96, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.596713542975383F, -28.82700641892781F, 2.190416737231974F, 1.2994636248153069F, 0.20865252133352535F, -1.6648000373075629F));
        g.addOrReplaceChild("valvulas_22", CubeListBuilder.create().texOffs(104, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.758418388383278F, -29.664414921507433F, 1.9380085435236318F, 1.2563296607682688F, 0.41341831348509844F, -1.7662260106741892F));
        g.addOrReplaceChild("valvulas_23", CubeListBuilder.create().texOffs(734, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.997038022182833F, -30.298319024476406F, 1.565542581858942F, 1.1461613545752425F, 0.6701791937683458F, -1.9281702931285465F));
        g.addOrReplaceChild("valvulas_24", CubeListBuilder.create().texOffs(740, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.3122625321525465F, -30.72789543167236F, 1.0735026001666692F, 0.748582050811587F, 0.8548009932799436F, -2.398487040960979F));
        g.addOrReplaceChild("valvulas_25", CubeListBuilder.create().texOffs(204, 152).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-7.425608653823964F, -27.67830806393077F, 2.4362484103857893F, 1.5190847596969328F, 0.04999592448735926F, -1.5779607730903824F));
        g.addOrReplaceChild("valvulas_26", CubeListBuilder.create().texOffs(252, 152).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-7.457259349388649F, -28.82700641892781F, 2.3020037751376887F, 1.5140734485802259F, 0.21128129666486617F, -1.6015038466146376F));
        g.addOrReplaceChild("valvulas_27", CubeListBuilder.create().texOffs(112, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-7.519800958455251F, -29.664414921507433F, 2.036737077291618F, 1.4974090244409142F, 0.42304128644463684F, -1.6352464667362443F));
        g.addOrReplaceChild("valvulas_28", CubeListBuilder.create().texOffs(120, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-7.612090436949619F, -30.298319024476406F, 1.6452964736437834F, 1.453005293021114F, 0.702721274476594F, -1.692089007936045F));
        g.addOrReplaceChild("valvulas_29", CubeListBuilder.create().texOffs(128, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-7.734007921988531F, -30.72789543167236F, 1.128190355834597F, 1.3274873814047297F, 1.0486665915292284F, -1.8212451228200195F));
        g.addOrReplaceChild("valvulas_30", CubeListBuilder.create().texOffs(216, 152).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.574391346162791F, -27.67830806393077F, 2.4362484103857893F, 1.62250789389167F, 0.04999592448734853F, -1.5636318804995766F));
        g.addOrReplaceChild("valvulas_31", CubeListBuilder.create().texOffs(262, 152).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.542740650598835F, -28.82700641892781F, 2.3020037751376887F, 1.6275192050082596F, 0.21128129666482617F, -1.5400888069758654F));
        g.addOrReplaceChild("valvulas_32", CubeListBuilder.create().texOffs(136, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.480199041533677F, -29.664414921507433F, 2.0367370772916185F, 1.6441836291471856F, 0.42304128644459155F, -1.506346186855033F));
        g.addOrReplaceChild("valvulas_33", CubeListBuilder.create().texOffs(144, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.387909563041436F, -30.298319024476406F, 1.6452964736437834F, 1.6885873605659794F, 0.7027212744766529F, -1.4495036456565162F));
        g.addOrReplaceChild("valvulas_34", CubeListBuilder.create().texOffs(152, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.265992078005336F, -30.72789543167236F, 1.128190355834597F, 1.8141052721796973F, 1.0486665915297435F, -1.3203475307752859F));
        g.addOrReplaceChild("valvulas_35", CubeListBuilder.create().texOffs(908, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.485121109342074F, -27.67830806393077F, 2.318154015123038F, 1.8289643372534763F, 0.049538251716095695F, -1.5488039582489597F));
        g.addOrReplaceChild("valvulas_36", CubeListBuilder.create().texOffs(160, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.403286457024617F, -28.82700641892781F, 2.1904167372319745F, 1.8421290287744858F, 0.2086525213335252F, -1.476792616282231F));
        g.addOrReplaceChild("valvulas_37", CubeListBuilder.create().texOffs(168, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.24158161161672F, -29.664414921507433F, 1.9380085435236318F, 1.8852629928215237F, 0.41341831348509855F, -1.3753666429156042F));
        g.addOrReplaceChild("valvulas_38", CubeListBuilder.create().texOffs(746, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.002961977817167F, -30.298319024476406F, 1.5655425818589421F, 1.9954312990145506F, 0.6701791937683457F, -1.213422360461247F));
        g.addOrReplaceChild("valvulas_39", CubeListBuilder.create().texOffs(752, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.687737467847453F, -30.72789543167236F, 1.0735026001666694F, 2.3930106027782068F, 0.8548009932799436F, -0.7431056126288144F));
        g.addOrReplaceChild("valvulas_40", CubeListBuilder.create().texOffs(918, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.071510061440332F, -27.67830806393077F, 2.082126574243544F, 2.105050906334816F, 0.04250043181212275F, -1.52847448940686F));
        g.addOrReplaceChild("valvulas_41", CubeListBuilder.create().texOffs(176, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.957363609286551F, -28.82700641892781F, 1.9673951202144209F, 2.122417218125899F, 0.19393284985844628F, -1.4178528284022636F));
        g.addOrReplaceChild("valvulas_42", CubeListBuilder.create().texOffs(758, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.731810816225448F, -29.664414921507433F, 1.7406863665041727F, 2.1787274607849727F, 0.37839728875003353F, -1.2575171456932577F));
        g.addOrReplaceChild("valvulas_43", CubeListBuilder.create().texOffs(764, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.398974006376339F, -30.298319024476406F, 1.4061437641904664F, 2.312187043696629F, 0.5932567961119027F, -1.0214958644578314F));
        g.addOrReplaceChild("valvulas_44", CubeListBuilder.create().texOffs(770, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.959285458481318F, -30.72789543167236F, 0.9642018074489026F, 2.633859849772832F, 0.6982980708109693F, -0.5824758434933516F));
        g.addOrReplaceChild("valvulas_45", CubeListBuilder.create().texOffs(928, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.498551889092253F, -27.67830806393077F, 1.7262583845336112F, 2.4385440748966762F, 0.0352287462236199F, -1.5197636912367134F));
        g.addOrReplaceChild("valvulas_46", CubeListBuilder.create().texOffs(184, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.360874144257306F, -28.82700641892781F, 1.6311363410721271F, 2.4554602056701245F, 0.15666111907995128F, -1.363354620709041F));
        g.addOrReplaceChild("valvulas_47", CubeListBuilder.create().texOffs(776, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-10.088823639805007F, -29.664414921507433F, 1.4431756801878743F, 2.5078299046779247F, 0.3009313902106191F, -1.154194981066497F));
        g.addOrReplaceChild("valvulas_48", CubeListBuilder.create().texOffs(782, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.68737251702856F, -30.298319024476406F, 1.1658116719802836F, 2.6301120389188006F, 0.42597116583988F, -0.8542899564374051F));
        g.addOrReplaceChild("valvulas_49", CubeListBuilder.create().texOffs(788, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.157042168938682F, -30.72789543167236F, 0.7994045487344329F, 2.8247418969626086F, 0.5450896647976448F, -0.49986592538503016F));
        g.addOrReplaceChild("valvulas_50", CubeListBuilder.create().texOffs(938, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.781784818147644F, -27.67830806393077F, 1.2376009244517296F, 2.779882766909872F, 0.025253644778061253F, -1.5139904970362865F));
        g.addOrReplaceChild("valvulas_51", CubeListBuilder.create().texOffs(192, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.62850008467837F, -28.82700641892781F, 1.169405380853848F, 2.790260024311452F, 0.09820718074552165F, -1.3290907081248646F));
        g.addOrReplaceChild("valvulas_52", CubeListBuilder.create().texOffs(200, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.325610252228358F, -29.664414921507433F, 1.034651343013935F, 2.8214367951807997F, 0.18719656357752032F, -1.0926021056391544F));
        g.addOrReplaceChild("valvulas_53", CubeListBuilder.create().texOffs(794, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.87865109823073F, -30.298319024476406F, 0.8358016481809727F, 2.885632861213509F, 0.2805278539042516F, -0.7953893499120764F));
        g.addOrReplaceChild("valvulas_54", CubeListBuilder.create().texOffs(800, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.288203120200002F, -30.72789543167236F, 0.573114556539545F, 2.984648257454294F, 0.38001350123420613F, -0.4560375223542047F));
        g.addOrReplaceChild("valvulas_55", CubeListBuilder.create().texOffs(948, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.923498092462946F, -27.67830806393077F, 0.4786594551501424F, 3.0677542538967026F, 0.007108692502002001F, -1.5109066490946848F));
        g.addOrReplaceChild("valvulas_56", CubeListBuilder.create().texOffs(208, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.762404530165226F, -28.82700641892781F, 0.4522838755127154F, 3.069951762878028F, 0.029567602403051844F, -1.319114625332852F));
        g.addOrReplaceChild("valvulas_57", CubeListBuilder.create().texOffs(216, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.444084492749942F, -29.664414921507433F, 0.4001658679568394F, 3.076520998841688F, 0.05641422368050033F, -1.0751811945798213F));
        g.addOrReplaceChild("valvulas_58", CubeListBuilder.create().texOffs(224, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.97435576837254F, -30.298319024476406F, 0.32325796921097816F, 3.0898677653823237F, 0.08467255519506135F, -0.7743248464513502F));
        g.addOrReplaceChild("valvulas_59", CubeListBuilder.create().texOffs(806, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.353828427001517F, -30.72789543167236F, 0.2216600650111535F, 3.110390121231843F, 0.10720927586015364F, -0.4354277115339346F));
        g.addOrReplaceChild("valvulas_60", CubeListBuilder.create().texOffs(958, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.923498092462946F, -27.67830806393077F, -0.4786594551322121F, -3.06775425389946F, -0.007108692501734451F, -1.5109066490946994F));
        g.addOrReplaceChild("valvulas_61", CubeListBuilder.create().texOffs(232, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.762404530165227F, -28.82700641892781F, -0.4522838754957731F, -3.0699517628807023F, -0.029567602401940677F, -1.3191146253329114F));
        g.addOrReplaceChild("valvulas_62", CubeListBuilder.create().texOffs(240, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.444084492749942F, -29.664414921507433F, -0.4001658679418494F, -3.076520998844114F, -0.0564142236783866F, -1.075181194579923F));
        g.addOrReplaceChild("valvulas_63", CubeListBuilder.create().texOffs(248, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.97435576837254F, -30.298319024476406F, -0.3232579691988691F, -3.089867765384249F, -0.0846725551919043F, -0.7743248464514739F));
        g.addOrReplaceChild("valvulas_64", CubeListBuilder.create().texOffs(812, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.353828427001517F, -30.72789543167236F, -0.22166006500285024F, -3.110390121233002F, -0.1072092758561774F, -0.43542771153402826F));
        g.addOrReplaceChild("valvulas_65", CubeListBuilder.create().texOffs(968, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.781784818147646F, -27.67830806393077F, -1.2376009244517279F, -2.7798827669098687F, -0.025253644778061253F, -1.5139904970362865F));
        g.addOrReplaceChild("valvulas_66", CubeListBuilder.create().texOffs(256, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.62850008467837F, -28.82700641892781F, -1.169405380853846F, -2.790260024311449F, -0.09820718074552189F, -1.3290907081248649F));
        g.addOrReplaceChild("valvulas_67", CubeListBuilder.create().texOffs(264, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.325610252228358F, -29.664414921507433F, -1.0346513430139335F, -2.8214367951807984F, -0.1871965635775207F, -1.0926021056391537F));
        g.addOrReplaceChild("valvulas_68", CubeListBuilder.create().texOffs(818, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.878651098230732F, -30.298319024476406F, -0.8358016481809714F, -2.8856328612135083F, -0.2805278539042514F, -0.7953893499120779F));
        g.addOrReplaceChild("valvulas_69", CubeListBuilder.create().texOffs(824, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.288203120200004F, -30.72789543167236F, -0.5731145565395441F, -2.9846482574542943F, -0.38001350123420474F, -0.45603752235420364F));
        g.addOrReplaceChild("valvulas_70", CubeListBuilder.create().texOffs(978, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.498551889092253F, -27.67830806393077F, -1.7262583845336104F, -2.43854407489668F, -0.0352287462236199F, -1.519763691236714F));
        g.addOrReplaceChild("valvulas_71", CubeListBuilder.create().texOffs(272, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.360874144257306F, -28.82700641892781F, -1.6311363410721256F, -2.4554602056701293F, -0.15666111907995076F, -1.3633546207090406F));
        g.addOrReplaceChild("valvulas_72", CubeListBuilder.create().texOffs(830, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-10.088823639805007F, -29.664414921507433F, -1.4431756801878732F, -2.5078299046779287F, -0.3009313902106184F, -1.1541949810664955F));
        g.addOrReplaceChild("valvulas_73", CubeListBuilder.create().texOffs(836, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.68737251702856F, -30.298319024476406F, -1.1658116719802827F, -2.6301120389188006F, -0.42597116583988004F, -0.8542899564374061F));
        g.addOrReplaceChild("valvulas_74", CubeListBuilder.create().texOffs(842, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.157042168938682F, -30.72789543167236F, -0.7994045487344323F, -2.8247418969626086F, -0.5450896647976439F, -0.4998659253850295F));
        g.addOrReplaceChild("valvulas_75", CubeListBuilder.create().texOffs(988, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.071510061440334F, -27.67830806393077F, -2.0821265742435435F, -2.105050906334816F, -0.04250043181212275F, -1.5284744894068607F));
        g.addOrReplaceChild("valvulas_76", CubeListBuilder.create().texOffs(280, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.957363609286553F, -28.82700641892781F, -1.9673951202144204F, -2.1224172181258982F, -0.19393284985844658F, -1.4178528284022631F));
        g.addOrReplaceChild("valvulas_77", CubeListBuilder.create().texOffs(848, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.731810816225448F, -29.664414921507433F, -1.7406863665041723F, -2.1787274607849714F, -0.3783972887500339F, -1.2575171456932572F));
        g.addOrReplaceChild("valvulas_78", CubeListBuilder.create().texOffs(854, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.39897400637634F, -30.298319024476406F, -1.4061437641904662F, -2.312187043696629F, -0.5932567961119024F, -1.021495864457832F));
        g.addOrReplaceChild("valvulas_79", CubeListBuilder.create().texOffs(860, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.95928545848132F, -30.72789543167236F, -0.9642018074489025F, -2.633859849772833F, -0.6982980708109684F, -0.5824758434933507F));
        g.addOrReplaceChild("valvulas_80", CubeListBuilder.create().texOffs(998, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.485121109342076F, -27.67830806393077F, -2.3181540151230378F, -1.828964337253477F, -0.049538251716095674F, -1.5488039582489594F));
        g.addOrReplaceChild("valvulas_81", CubeListBuilder.create().texOffs(288, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.403286457024619F, -28.82700641892781F, -2.190416737231974F, -1.8421290287744871F, -0.2086525213335253F, -1.4767926162822305F));
        g.addOrReplaceChild("valvulas_82", CubeListBuilder.create().texOffs(296, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.241581611616724F, -29.664414921507433F, -1.9380085435236318F, -1.8852629928215257F, -0.4134183134850985F, -1.375366642915604F));
        g.addOrReplaceChild("valvulas_83", CubeListBuilder.create().texOffs(866, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.002961977817169F, -30.298319024476406F, -1.5655425818589417F, -1.9954312990145515F, -0.6701791937683458F, -1.2134223604612466F));
        g.addOrReplaceChild("valvulas_84", CubeListBuilder.create().texOffs(872, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.687737467847453F, -30.72789543167236F, -1.0735026001666692F, -2.3930106027782077F, -0.8548009932799426F, -0.743105612628813F));
        g.addOrReplaceChild("valvulas_85", CubeListBuilder.create().texOffs(228, 152).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.574391346183702F, -27.67830806393077F, -2.4362484103857893F, -1.6225078938935493F, -0.04999592448736548F, -1.563631880499315F));
        g.addOrReplaceChild("valvulas_86", CubeListBuilder.create().texOffs(272, 152).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.542740650618596F, -28.82700641892781F, -2.3020037751376887F, -1.6275192050103242F, -0.2112812966648893F, -1.5400888069747447F));
        g.addOrReplaceChild("valvulas_87", CubeListBuilder.create().texOffs(304, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.48019904155116F, -29.664414921507433F, -2.036737077291618F, -1.644183629149859F, -0.42304128644466316F, -1.50634618685269F));
        g.addOrReplaceChild("valvulas_88", CubeListBuilder.create().texOffs(312, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.387909563055558F, -30.298319024476406F, -1.6452964736437834F, -1.688587360570241F, -0.7027212744765602F, -1.449503645652147F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("valvulas_89", CubeListBuilder.create().texOffs(320, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.26599207801502F, -30.72789543167236F, -1.128190355834597F, -1.8141052721881696F, -1.0486665915289304F, -1.3203475307665828F));
        g.addOrReplaceChild("valvulas_90", CubeListBuilder.create().texOffs(240, 152).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-7.4256086538448765F, -27.67830806393077F, -2.4362484103857893F, -1.5190847596988124F, -0.049995924487342296F, -1.5779607730901208F));
        g.addOrReplaceChild("valvulas_91", CubeListBuilder.create().texOffs(282, 152).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-7.4572593494084085F, -28.82700641892781F, -2.3020037751376887F, -1.5140734485822902F, -0.21128129666480303F, -1.6015038466135172F));
        g.addOrReplaceChild("valvulas_92", CubeListBuilder.create().texOffs(328, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-7.519800958472732F, -29.664414921507433F, -2.0367370772916185F, -1.4974090244435876F, -0.4230412864445652F, -1.635246466733901F));
        g.addOrReplaceChild("valvulas_93", CubeListBuilder.create().texOffs(336, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-7.612090436963742F, -30.298319024476406F, -1.6452964736437834F, -1.4530052930253758F, -0.7027212744766869F, -1.6920890079316764F));
        g.addOrReplaceChild("valvulas_94", CubeListBuilder.create().texOffs(344, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-7.734007921998215F, -30.72789543167236F, -1.128190355834597F, -1.327487381413202F, -1.0486665915300415F, -1.8212451228113162F));
        g.addOrReplaceChild("valvulas_95", CubeListBuilder.create().texOffs(1008, 162).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.5148788906579265F, -27.67830806393077F, -2.318154015123038F, -1.312628316336318F, -0.049538251716095855F, -1.5927886953408337F));
        g.addOrReplaceChild("valvulas_96", CubeListBuilder.create().texOffs(352, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.596713542975385F, -28.82700641892781F, -2.1904167372319745F, -1.2994636248153075F, -0.2086525213335253F, -1.6648000373075627F));
        g.addOrReplaceChild("valvulas_97", CubeListBuilder.create().texOffs(360, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.75841838838328F, -29.664414921507433F, -1.9380085435236323F, -1.2563296607682695F, -0.41341831348509867F, -1.766226010674189F));
        g.addOrReplaceChild("valvulas_98", CubeListBuilder.create().texOffs(878, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.997038022182835F, -30.298319024476406F, -1.5655425818589421F, -1.1461613545752436F, -0.6701791937683458F, -1.9281702931285456F));
        g.addOrReplaceChild("valvulas_99", CubeListBuilder.create().texOffs(884, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.312262532152547F, -30.72789543167236F, -1.0735026001666694F, -0.748582050811587F, -0.8548009932799436F, -2.398487040960979F));
        g.addOrReplaceChild("valvulas_100", CubeListBuilder.create().texOffs(0, 165).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.928489938559668F, -27.67830806393077F, -2.0821265742435444F, -1.036541747254977F, -0.042500431812122916F, -1.6131181641829326F));
        g.addOrReplaceChild("valvulas_101", CubeListBuilder.create().texOffs(368, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.04263639071345F, -28.82700641892781F, -1.967395120214421F, -1.0191754354638953F, -0.19393284985844658F, -1.72373982518753F));
        g.addOrReplaceChild("valvulas_102", CubeListBuilder.create().texOffs(890, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.2681891837745525F, -29.664414921507433F, -1.740686366504173F, -0.9628651928048224F, -0.3783972887500339F, -1.8840755078965354F));
        g.addOrReplaceChild("valvulas_103", CubeListBuilder.create().texOffs(896, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.601025993623661F, -30.298319024476406F, -1.4061437641904668F, -0.8294056098931651F, -0.593256796111903F, -2.120096789131961F));
        g.addOrReplaceChild("valvulas_104", CubeListBuilder.create().texOffs(902, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-7.040714541518681F, -30.72789543167236F, -0.9642018074489029F, -0.5077328038169612F, -0.698298070810969F, -2.5591168100964423F));
        g.addOrReplaceChild("valvulas_105", CubeListBuilder.create().texOffs(10, 165).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.501448110907749F, -27.67830806393077F, -1.7262583845336115F, -0.703048578693115F, -0.0352287462236199F, -1.6218289623530795F));
        g.addOrReplaceChild("valvulas_106", CubeListBuilder.create().texOffs(376, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.639125855742695F, -28.82700641892781F, -1.6311363410721271F, -0.686132447919666F, -0.1566611190799508F, -1.7782380328807519F));
        g.addOrReplaceChild("valvulas_107", CubeListBuilder.create().texOffs(908, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.911176360194993F, -29.664414921507433F, -1.4431756801878743F, -0.6337627489118675F, -0.3009313902106191F, -1.9873976725232967F));
        g.addOrReplaceChild("valvulas_108", CubeListBuilder.create().texOffs(914, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.312627482971441F, -30.298319024476406F, -1.1658116719802838F, -0.511480614670993F, -0.42597116583988015F, -2.2873026971523878F));
        g.addOrReplaceChild("valvulas_109", CubeListBuilder.create().texOffs(920, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.842957831061318F, -30.72789543167236F, -0.799404548734433F, -0.31685075662718487F, -0.5450896647976444F, -2.6417267282047634F));
        g.addOrReplaceChild("valvulas_110", CubeListBuilder.create().texOffs(20, 165).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.218215181852355F, -27.67830806393077F, -1.2376009244517305F, -0.36170988667992443F, -0.025253644778061253F, -1.627602156553507F));
        g.addOrReplaceChild("valvulas_111", CubeListBuilder.create().texOffs(384, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.371499915321632F, -28.82700641892781F, -1.1694053808538487F, -0.3513326292783436F, -0.0982071807455218F, -1.8125019454649278F));
        g.addOrReplaceChild("valvulas_112", CubeListBuilder.create().texOffs(392, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.6743897477716425F, -29.664414921507433F, -1.034651343013936F, -0.32015585840899424F, -0.18719656357752062F, -2.048990547950639F));
        g.addOrReplaceChild("valvulas_113", CubeListBuilder.create().texOffs(926, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.12134890176927F, -30.298319024476406F, -0.8358016481809731F, -0.2559597923762851F, -0.28052785390425183F, -2.3462033036777163F));
        g.addOrReplaceChild("valvulas_114", CubeListBuilder.create().texOffs(932, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.711796879799997F, -30.72789543167236F, -0.5731145565395454F, -0.15694439613549938F, -0.3800135012342059F, -2.685555131235589F));
        g.addOrReplaceChild("valvulas_115", CubeListBuilder.create().texOffs(30, 165).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.076501907537054F, -27.67830806393077F, -0.47865945515574165F, -0.07383839969395088F, -0.007108692502085532F, -1.630686004495113F));
        g.addOrReplaceChild("valvulas_116", CubeListBuilder.create().texOffs(400, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.2375954698347735F, -28.82700641892781F, -0.45228387551800614F, -0.0716408907125996F, -0.029567602403398674F, -1.8224780282569597F));
        g.addOrReplaceChild("valvulas_117", CubeListBuilder.create().texOffs(408, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.555915507250058F, -29.664414921507433F, -0.4001658679615204F, -0.06507165474886167F, -0.05641422368116011F, -2.0664114590100042F));
        g.addOrReplaceChild("valvulas_118", CubeListBuilder.create().texOffs(416, 165).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.02564423162746F, -30.298319024476406F, -0.3232579692147596F, -0.05172488820806935F, -0.08467255519604634F, -2.3672678071384805F));
        g.addOrReplaceChild("valvulas_119", CubeListBuilder.create().texOffs(938, 165).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-6.646171572998484F, -30.72789543167236F, -0.2216600650137464F, -0.03120253235831137F, -0.10720927586139446F, -2.706164942055888F));
        g.addOrReplaceChild("silbato_0", CubeListBuilder.create().texOffs(532, 135).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(48, 119).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(10.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("silbato_1", CubeListBuilder.create().texOffs(566, 135).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(82, 119).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(10.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("tanque_i", CubeListBuilder.create().texOffs(280, 119).addBox(-29.0F, -26.0F, -12.0F, 38.0F, 8.0F, 6.0F).texOffs(710, 135).addBox(-29.0F, -29.0F, -9.0F, 38.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("tanque_cantoi_0", CubeListBuilder.create().texOffs(358, 152).addBox(-19.0F, -1.0F, -1.0F, 38.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.0F, -26.574025148547634F, -11.885819298766929F, -1.7671458676442586F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_1", CubeListBuilder.create().texOffs(438, 152).addBox(-19.0F, -1.0F, -1.0F, 38.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.0F, -27.634685320327456F, -11.446479470546752F, -2.159844949342984F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_2", CubeListBuilder.create().texOffs(518, 152).addBox(-19.0F, -1.0F, -1.0F, 38.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.0F, -28.44647947054675F, -10.634685320327456F, -2.552544031041708F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantoi_3", CubeListBuilder.create().texOffs(598, 152).addBox(-19.0F, -1.0F, -1.0F, 38.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.0F, -28.88581929876693F, -9.574025148547634F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_tapaai", CubeListBuilder.create().texOffs(146, 119).addBox(0.0F, -3.0F, 0.0F, 1.0F, 3.0F, 12.0F), PartPose.offset(-29.0F, -26.0F, -12.0F));
        g.addOrReplaceChild("tanque_tapabi", CubeListBuilder.create().texOffs(172, 119).addBox(0.0F, -3.0F, 0.0F, 1.0F, 3.0F, 12.0F), PartPose.offset(8.0F, -26.0F, -12.0F));
        g.addOrReplaceChild("tanque_d", CubeListBuilder.create().texOffs(368, 119).addBox(-29.0F, -26.0F, 6.0F, 38.0F, 8.0F, 6.0F).texOffs(792, 135).addBox(-29.0F, -29.0F, 6.0F, 38.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("tanque_cantod_0", CubeListBuilder.create().texOffs(678, 152).addBox(-19.0F, -1.0F, -1.0F, 38.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.0F, -26.574025148547634F, 11.885819298766929F, 1.7671458676442586F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_1", CubeListBuilder.create().texOffs(758, 152).addBox(-19.0F, -1.0F, -1.0F, 38.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.0F, -27.634685320327456F, 11.446479470546752F, 2.159844949342984F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_2", CubeListBuilder.create().texOffs(838, 152).addBox(-19.0F, -1.0F, -1.0F, 38.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.0F, -28.44647947054675F, 10.634685320327456F, 2.552544031041708F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_cantod_3", CubeListBuilder.create().texOffs(918, 152).addBox(-19.0F, -1.0F, -1.0F, 38.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.0F, -28.88581929876693F, 9.574025148547634F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("tanque_tapaad", CubeListBuilder.create().texOffs(198, 119).addBox(0.0F, -3.0F, 0.0F, 1.0F, 3.0F, 12.0F), PartPose.offset(-29.0F, -26.0F, 0.0F));
        g.addOrReplaceChild("tanque_tapabd", CubeListBuilder.create().texOffs(224, 119).addBox(0.0F, -3.0F, 0.0F, 1.0F, 3.0F, 12.0F), PartPose.offset(8.0F, -26.0F, 0.0F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(884, 86).addBox(10.0F, -30.0F, 11.0F, 20.0F, 16.0F, 1.0F).texOffs(926, 86).addBox(10.0F, -30.0F, -12.0F, 20.0F, 16.0F, 1.0F).texOffs(716, 86).addBox(10.0F, -15.0F, -11.0F, 20.0F, 1.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_frente", CubeListBuilder.create().texOffs(406, 86).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 24.0F), PartPose.offset(9.0F, -29.0F, -12.0F));
        g.addOrReplaceChild("cabina_fuego", CubeListBuilder.create().texOffs(860, 86).addBox(10.0F, -26.0F, -5.0F, 2.0F, 11.0F, 10.0F).texOffs(696, 135).addBox(12.0F, -20.0F, -2.0F, 1.0F, 3.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(482, 147).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -30.79366097393642F, -11.047046588100546F, -2.7505273604889893F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(536, 147).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -31.510774468973853F, -9.115634636335741F, -2.8216301410527698F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(590, 147).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -32.08886293005848F, -7.138157045224901F, -2.892732921616557F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(644, 147).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -32.52500500112232F, -5.12460694998692F, -2.963835702180333F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(698, 147).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -32.81699664874906F, -3.0851597773685784F, -3.0349384827441206F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(752, 147).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -32.963362300203706F, -1.0301218243713621F, -3.106041263307902F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(806, 147).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -32.963362300203706F, 1.0301218243713608F, 3.106041263307902F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(860, 147).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -32.81699664874906F, 3.0851597773685766F, 3.0349384827441206F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(914, 147).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -32.52500500112232F, 5.12460694998692F, 2.963835702180333F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(968, 147).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -32.08886293005848F, 7.1381570452249F, 2.8927329216165565F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(0, 152).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -31.510774468973853F, 9.115634636335741F, 2.8216301410527698F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(54, 152).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(20.0F, -30.79366097393642F, 11.047046588100546F, 2.7505273604889897F, 0.0F, 0.0F));
        g.addOrReplaceChild("numeroi", CubeListBuilder.create().texOffs(460, 135).addBox(0.0F, -7.0F, -0.5F, 17.0F, 7.0F, 1.0F), PartPose.offset(18.75F, -17.25F, -12.5F));
        g.addOrReplaceChild("numerod", CubeListBuilder.create().texOffs(496, 135).addBox(0.0F, -7.0F, -0.5F, 17.0F, 7.0F, 1.0F), PartPose.offset(18.75F, -17.25F, 12.5F));
        g.addOrReplaceChild("carbonera", CubeListBuilder.create().texOffs(228, 43).addBox(30.0F, -27.0F, -12.0F, 12.0F, 13.0F, 24.0F).texOffs(800, 86).addBox(31.0F, -28.0F, -10.0F, 10.0F, 1.0F, 20.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_fondo_caldera", CubeListBuilder.create().texOffs(300, 43).addBox(9.6F, -29.0F, -11.0F, 1.0F, 14.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_placa", CubeListBuilder.create().texOffs(416, 135).addBox(10.0F, -30.0F, -3.5F, 1.0F, 4.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(456, 119).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(11.6F, -27.6F, 2.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(482, 165).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(11.719999999999999F, -27.6F, 2.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_presion", CubeListBuilder.create().texOffs(508, 119).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(11.6F, -27.6F, -2.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_presion_aguja", CubeListBuilder.create().texOffs(486, 165).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(11.719999999999999F, -27.6F, -2.0F, 0.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_nivel", CubeListBuilder.create().texOffs(874, 135).addBox(12.0F, -24.0F, -4.5F, 1.0F, 5.0F, 1.0F).texOffs(460, 165).addBox(12.0F, -19.0F, -5.0F, 1.0F, 1.0F, 2.0F).texOffs(466, 165).addBox(12.0F, -25.0F, -5.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_regulador", CubeListBuilder.create().texOffs(706, 135).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(11.5F, -26.5F, 0.0F, 1.9495902196202934F, 0.09966865249116204F, 1.5707963267948966F));
        g.addOrReplaceChild("cab_valvulas", CubeListBuilder.create().texOffs(944, 165).addBox(12.0F, -24.0F, -2.0F, 1.0F, 1.0F, 1.0F).texOffs(948, 165).addBox(12.0F, -24.0F, 3.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_tubo", CubeListBuilder.create().texOffs(456, 135).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 8.0F, 1.0F), PartPose.offset(12.5F, -23.5F, 3.5F));
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(432, 135).addBox(-0.5F, -10.0F, -0.5F, 1.0F, 10.0F, 1.0F).texOffs(340, 152).addBox(-1.0F, -12.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(16.0F, -15.0F, 8.0F));
        g.addOrReplaceChild("cab_palanca_cuadrante", CubeListBuilder.create().texOffs(666, 165).addBox(13.0F, -16.0F, 8.5F, 6.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(472, 165).addBox(19.0F, -26.0F, 10.0F, 2.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_freno_manija", CubeListBuilder.create().texOffs(354, 152).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -26.0F, 10.5F, -0.7297276562269664F, 0.0F, -2.0344439357957027F));
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(436, 135).addBox(28.0F, -21.0F, 2.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(446, 135).addBox(28.0F, -21.0F, -6.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "tope_i_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_ic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_ti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_ti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_tic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_d_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_dc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_td_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_td_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_td_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_tdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_tdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "caja_humo_0", 1.0F, 0.3548328977548374F, 0.3548328977548374F);
        escalar(g0, "caja_humo_1", 1.0F, 0.3548328977548374F, 0.3548328977548374F);
        escalar(g0, "caja_humo_2", 1.0F, 0.3548328977548374F, 0.3548328977548374F);
        escalar(g0, "caja_humo_3", 1.0F, 0.3548328977548374F, 0.3548328977548374F);
        escalar(g0, "caja_humo_4", 1.0F, 0.3548328977548374F, 0.3548328977548374F);
        escalar(g0, "caja_humo_5", 1.0F, 0.3548328977548374F, 0.3548328977548374F);
        escalar(g0, "puerta_0", 1.0F, 0.3130878509601506F, 0.3130878509601506F);
        escalar(g0, "puerta_1", 1.0F, 0.3130878509601506F, 0.3130878509601506F);
        escalar(g0, "puerta_2", 1.0F, 0.3130878509601506F, 0.3130878509601506F);
        escalar(g0, "puerta_3", 1.0F, 0.3130878509601506F, 0.3130878509601506F);
        escalar(g0, "puerta_4", 1.0F, 0.3130878509601506F, 0.3130878509601506F);
        escalar(g0, "puerta_5", 1.0F, 0.3130878509601506F, 0.3130878509601506F);
        escalar(g0, "caldera_0", 0.9545887436071555F, 1.0F, 0.7053761994508395F);
        escalar(g0, "caldera_1", 0.9545887436071555F, 1.0F, 0.7165726470611701F);
        escalar(g0, "caldera_2", 0.9545887436071555F, 1.0F, 0.7277690946715012F);
        escalar(g0, "caldera_3", 0.9545887436071555F, 1.0F, 0.7389655422818318F);
        escalar(g0, "caldera_4", 0.9545887436071555F, 1.0F, 0.7053761994508395F);
        escalar(g0, "caldera_5", 0.9545887436071555F, 1.0F, 0.7165726470611706F);
        escalar(g0, "caldera_6", 0.9545887436071555F, 1.0F, 0.7277690946715009F);
        escalar(g0, "caldera_7", 0.9545887436071555F, 1.0F, 0.7389655422818318F);
        escalar(g0, "caldera_8", 0.9545887436071555F, 1.0F, 0.7053761994508395F);
        escalar(g0, "caldera_9", 0.9545887436071555F, 1.0F, 0.7165726470611697F);
        escalar(g0, "caldera_10", 0.9545887436071555F, 1.0F, 0.7277690946715013F);
        escalar(g0, "caldera_11", 0.9545887436071555F, 1.0F, 0.7389655422818318F);
        escalar(g0, "caldera_12", 0.9545887436071555F, 1.0F, 0.7053761994508395F);
        escalar(g0, "caldera_13", 0.9545887436071555F, 1.0F, 0.7165726470611706F);
        escalar(g0, "caldera_14", 0.9545887436071555F, 1.0F, 0.7277690946715002F);
        escalar(g0, "caldera_15", 0.9545887436071555F, 1.0F, 0.7389655422818325F);
        escalar(g0, "caldera_16", 0.9545887436071555F, 1.0F, 0.7053761994508383F);
        escalar(g0, "caldera_17", 0.9545887436071555F, 1.0F, 0.7165726470611705F);
        escalar(g0, "caldera_18", 0.9545887436071555F, 1.0F, 0.727769094671501F);
        escalar(g0, "caldera_19", 0.9545887436071555F, 1.0F, 0.73896554228183F);
        escalar(g0, "caldera_20", 0.9545887436071555F, 1.0F, 0.7053761994508413F);
        escalar(g0, "caldera_21", 0.9545887436071555F, 1.0F, 0.7165726470611704F);
        escalar(g0, "caldera_22", 0.9545887436071555F, 1.0F, 0.7277690946715012F);
        escalar(g0, "caldera_23", 0.9545887436071555F, 1.0F, 0.7389655422818338F);
        escalar(g0, "caldera_24", 0.9545887436071555F, 1.0F, 0.7053761994508392F);
        escalar(g0, "caldera_25", 0.9545887436071555F, 1.0F, 0.7165726470611704F);
        escalar(g0, "caldera_26", 0.9545887436071555F, 1.0F, 0.7277690946715017F);
        escalar(g0, "caldera_27", 0.9545887436071555F, 1.0F, 0.7389655422818313F);
        escalar(g0, "caldera_28", 0.9545887436071555F, 1.0F, 0.7053761994508392F);
        escalar(g0, "caldera_29", 0.9545887436071555F, 1.0F, 0.7165726470611704F);
        escalar(g0, "caldera_30", 0.9545887436071555F, 1.0F, 0.7277690946715017F);
        escalar(g0, "caldera_31", 0.9545887436071555F, 1.0F, 0.7389655422818313F);
        escalar(g0, "caldera_32", 0.9545887436071555F, 1.0F, 0.7053761994508395F);
        escalar(g0, "caldera_33", 0.9545887436071555F, 1.0F, 0.7165726470611704F);
        escalar(g0, "caldera_34", 0.9545887436071555F, 1.0F, 0.7277690946715011F);
        escalar(g0, "caldera_35", 0.9545887436071555F, 1.0F, 0.738965542281832F);
        escalar(g0, "caldera_36", 0.9545887436071555F, 1.0F, 0.7053761994508381F);
        escalar(g0, "caldera_37", 0.9545887436071555F, 1.0F, 0.7165726470611685F);
        escalar(g0, "caldera_38", 0.9545887436071555F, 1.0F, 0.7277690946714992F);
        escalar(g0, "caldera_39", 0.9545887436071555F, 1.0F, 0.7389655422818311F);
        escalar(g0, "caldera_40", 0.9545887436071555F, 1.0F, 0.7053761994508412F);
        escalar(g0, "caldera_41", 0.9545887436071555F, 1.0F, 0.7165726470611722F);
        escalar(g0, "caldera_42", 0.9545887436071555F, 1.0F, 0.7277690946715019F);
        escalar(g0, "caldera_43", 0.9545887436071555F, 1.0F, 0.7389655422818331F);
        escalar(g0, "caldera_44", 0.9545887436071555F, 1.0F, 0.7053761994508393F);
        escalar(g0, "caldera_45", 0.9545887436071555F, 1.0F, 0.7165726470611699F);
        escalar(g0, "caldera_46", 0.9545887436071555F, 1.0F, 0.7277690946715014F);
        escalar(g0, "caldera_47", 0.9545887436071555F, 1.0F, 0.7389655422818308F);
        escalar(g0, "caldera_48", 0.9545887436071555F, 1.0F, 0.7053761994508383F);
        escalar(g0, "caldera_49", 0.9545887436071555F, 1.0F, 0.7165726470611689F);
        escalar(g0, "caldera_50", 0.9545887436071555F, 1.0F, 0.7277690946714994F);
        escalar(g0, "caldera_51", 0.9545887436071555F, 1.0F, 0.7389655422818311F);
        escalar(g0, "caldera_52", 0.9545887436071555F, 1.0F, 0.7053761994508408F);
        escalar(g0, "caldera_53", 0.9545887436071555F, 1.0F, 0.7165726470611716F);
        escalar(g0, "caldera_54", 0.9545887436071555F, 1.0F, 0.7277690946715024F);
        escalar(g0, "caldera_55", 0.9545887436071555F, 1.0F, 0.7389655422818331F);
        escalar(g0, "caldera_56", 0.9545887436071555F, 1.0F, 0.7053761994508395F);
        escalar(g0, "caldera_57", 0.9545887436071555F, 1.0F, 0.7165726470611704F);
        escalar(g0, "caldera_58", 0.9545887436071555F, 1.0F, 0.7277690946715012F);
        escalar(g0, "caldera_59", 0.9545887436071555F, 1.0F, 0.7389655422818319F);
        escalar(g0, "caldera_60", 0.9545887436071555F, 1.0F, 0.7053761994508396F);
        escalar(g0, "caldera_61", 0.9545887436071555F, 1.0F, 0.7165726470611706F);
        escalar(g0, "caldera_62", 0.9545887436071555F, 1.0F, 0.7277690946715009F);
        escalar(g0, "caldera_63", 0.9545887436071555F, 1.0F, 0.7389655422818318F);
        escalar(g0, "caldera_64", 0.9545887436071555F, 1.0F, 0.7053761994508383F);
        escalar(g0, "caldera_65", 0.9545887436071555F, 1.0F, 0.716572647061169F);
        escalar(g0, "caldera_66", 0.9545887436071555F, 1.0F, 0.7277690946714996F);
        escalar(g0, "caldera_67", 0.9545887436071555F, 1.0F, 0.738965542281831F);
        escalar(g0, "caldera_68", 0.9545887436071555F, 1.0F, 0.7053761994508403F);
        escalar(g0, "caldera_69", 0.9545887436071555F, 1.0F, 0.7165726470611713F);
        escalar(g0, "caldera_70", 0.9545887436071555F, 1.0F, 0.7277690946715021F);
        escalar(g0, "caldera_71", 0.9545887436071555F, 1.0F, 0.738965542281832F);
        escalar(g0, "caldera_72", 0.9545887436071555F, 1.0F, 0.7053761994508365F);
        escalar(g0, "caldera_73", 0.9545887436071555F, 1.0F, 0.7165726470611671F);
        escalar(g0, "caldera_74", 0.9545887436071555F, 1.0F, 0.7277690946714992F);
        escalar(g0, "caldera_75", 0.9545887436071555F, 1.0F, 0.7389655422818298F);
        escalar(g0, "caldera_76", 0.9545887436071555F, 1.0F, 0.7053761994508397F);
        escalar(g0, "caldera_77", 0.9545887436071555F, 1.0F, 0.7165726470611706F);
        escalar(g0, "caldera_78", 0.9545887436071555F, 1.0F, 0.7277690946714996F);
        escalar(g0, "caldera_79", 0.9545887436071555F, 1.0F, 0.7389655422818321F);
        escalar(g0, "caldera_80", 0.9545887436071555F, 1.0F, 0.7053761994508427F);
        escalar(g0, "caldera_81", 0.9545887436071555F, 1.0F, 0.7165726470611741F);
        escalar(g0, "caldera_82", 0.9545887436071555F, 1.0F, 0.7277690946715053F);
        escalar(g0, "caldera_83", 0.9545887436071555F, 1.0F, 0.738965542281835F);
        escalar(g0, "caldera_84", 0.9545887436071555F, 1.0F, 0.7053761994508392F);
        escalar(g0, "caldera_85", 0.9545887436071555F, 1.0F, 0.7165726470611704F);
        escalar(g0, "caldera_86", 0.9545887436071555F, 1.0F, 0.7277690946715F);
        escalar(g0, "caldera_87", 0.9545887436071555F, 1.0F, 0.7389655422818313F);
        escalar(g0, "caldera_88", 0.9545887436071555F, 1.0F, 0.7053761994508394F);
        escalar(g0, "caldera_89", 0.9545887436071555F, 1.0F, 0.7165726470611703F);
        escalar(g0, "caldera_90", 0.9545887436071555F, 1.0F, 0.7277690946715009F);
        escalar(g0, "caldera_91", 0.9545887436071555F, 1.0F, 0.7389655422818318F);
        escalar(g0, "caldera_92", 0.9545887436071555F, 1.0F, 0.7053761994508387F);
        escalar(g0, "caldera_93", 0.9545887436071555F, 1.0F, 0.7165726470611691F);
        escalar(g0, "caldera_94", 0.9545887436071555F, 1.0F, 0.7277690946715012F);
        escalar(g0, "caldera_95", 0.9545887436071555F, 1.0F, 0.7389655422818318F);
        escalar(g0, "caldera_96", 0.9545887436071555F, 1.0F, 0.7053761994508403F);
        escalar(g0, "caldera_97", 0.9545887436071555F, 1.0F, 0.7165726470611705F);
        escalar(g0, "caldera_98", 0.9545887436071555F, 1.0F, 0.7277690946715015F);
        escalar(g0, "caldera_99", 0.9545887436071555F, 1.0F, 0.7389655422818322F);
        escalar(g0, "caldera_100", 0.9545887436071555F, 1.0F, 0.7053761994508363F);
        escalar(g0, "caldera_101", 0.9545887436071555F, 1.0F, 0.7165726470611676F);
        escalar(g0, "caldera_102", 0.9545887436071555F, 1.0F, 0.7277690946714981F);
        escalar(g0, "caldera_103", 0.9545887436071555F, 1.0F, 0.7389655422818288F);
        escalar(g0, "caldera_104", 0.9545887436071555F, 1.0F, 0.7053761994508401F);
        escalar(g0, "caldera_105", 0.9545887436071555F, 1.0F, 0.7165726470611703F);
        escalar(g0, "caldera_106", 0.9545887436071555F, 1.0F, 0.7277690946715011F);
        escalar(g0, "caldera_107", 0.9545887436071555F, 1.0F, 0.7389655422818321F);
        escalar(g0, "caldera_108", 0.9545887436071555F, 1.0F, 0.7053761994508421F);
        escalar(g0, "caldera_109", 0.9545887436071555F, 1.0F, 0.7165726470611732F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "caldera_110", 0.9545887436071555F, 1.0F, 0.7277690946715039F);
        escalar(g0, "caldera_111", 0.9545887436071555F, 1.0F, 0.7389655422818348F);
        escalar(g0, "chimenea_0", 0.4315455233774214F, 1.0F, 0.4315455233774214F);
        escalar(g0, "chimenea_1", 0.4315455233774214F, 1.0F, 0.4315455233774214F);
        escalar(g0, "chimenea_2", 0.4315455233774214F, 1.0F, 0.4315455233774214F);
        escalar(g0, "chimenea_3", 0.4315455233774214F, 1.0F, 0.4315455233774214F);
        escalar(g0, "chimenea_copa_0", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "chimenea_copa_1", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "chimenea_copa_2", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "chimenea_copa_3", 0.549239757025809F, 1.0F, 0.549239757025809F);
        escalar(g0, "valvulas_0", 0.4597222382949305F, 1.0F, 0.48997198989676094F);
        escalar(g0, "valvulas_1", 0.4963966689673268F, 1.0F, 0.4635240856361309F);
        escalar(g0, "valvulas_2", 0.4294211401514463F, 1.0F, 0.4112631650026888F);
        escalar(g0, "valvulas_3", 0.3962135698799394F, 1.0F, 0.3341443766811444F);
        escalar(g0, "valvulas_4", 0.403034263845586F, 1.0F, 0.4645357606095002F);
        escalar(g0, "valvulas_5", 0.459755576534197F, 1.0F, 0.309742043752152F);
        escalar(g0, "valvulas_6", 0.4970143632515085F, 1.0F, 0.29322535310579223F);
        escalar(g0, "valvulas_7", 0.43134699569312007F, 1.0F, 0.26058845868533587F);
        escalar(g0, "valvulas_8", 0.40016240399913805F, 1.0F, 0.42485569984228483F);
        escalar(g0, "valvulas_9", 0.4093974073776957F, 1.0F, 0.2976121528147286F);
        escalar(g0, "valvulas_10", 0.45974969623696854F, 1.0F, 0.28339759344259435F);
        escalar(g0, "valvulas_11", 0.4969054442021931F, 1.0F, 0.26833256146434964F);
        escalar(g0, "valvulas_12", 0.4310076824422021F, 1.0F, 0.4771282739748647F);
        escalar(g0, "valvulas_13", 0.3994676364567866F, 1.0F, 0.3892727674864378F);
        escalar(g0, "valvulas_14", 0.4082795413674344F, 1.0F, 0.27321270763311034F);
        escalar(g0, "valvulas_15", 0.459694353673739F, 1.0F, 0.3003091103878645F);
        escalar(g0, "valvulas_16", 0.49587923980790827F, 1.0F, 0.28431220282003256F);
        escalar(g0, "valvulas_17", 0.42780107603122985F, 1.0F, 0.5054047940939463F);
        escalar(g0, "valvulas_18", 0.392867587819976F, 1.0F, 0.41211482174937974F);
        escalar(g0, "valvulas_19", 0.3976002975324099F, 1.0F, 0.2888756509018263F);
        escalar(g0, "valvulas_20", 0.45959905345479585F, 1.0F, 0.3577958069610172F);
        escalar(g0, "valvulas_21", 0.4941075702632125F, 1.0F, 0.3386312090295168F);
        escalar(g0, "valvulas_22", 0.42222469658485146F, 1.0F, 0.300762063648464F);
        escalar(g0, "valvulas_23", 0.38124133102140145F, 1.0F, 0.48976097536001395F);
        escalar(g0, "valvulas_24", 0.37851482116742935F, 1.0F, 0.3421181169706715F);
        escalar(g0, "valvulas_25", 0.4594948608998463F, 1.0F, 0.39010096890731355F);
        escalar(g0, "valvulas_26", 0.49216436336347735F, 1.0F, 0.3689725823985854F);
        escalar(g0, "valvulas_27", 0.4160515022676716F, 1.0F, 0.49083450157406083F);
        escalar(g0, "valvulas_28", 0.3681497876144823F, 1.0F, 0.39842289398397257F);
        escalar(g0, "valvulas_29", 0.35658523564547356F, 1.0F, 0.2763440723285464F);
        escalar(g0, "valvulas_30", 0.4594948608998463F, 1.0F, 0.39010096891613055F);
        escalar(g0, "valvulas_31", 0.49216436336347735F, 1.0F, 0.3689725824069167F);
        escalar(g0, "valvulas_32", 0.4160515022676716F, 1.0F, 0.49083450158511777F);
        escalar(g0, "valvulas_33", 0.36814978761448214F, 1.0F, 0.39842289399290465F);
        escalar(g0, "valvulas_34", 0.3565852356454737F, 1.0F, 0.27634407233467095F);
        escalar(g0, "valvulas_35", 0.45959905345479585F, 1.0F, 0.3577958069610174F);
        escalar(g0, "valvulas_36", 0.49410757026321245F, 1.0F, 0.33863120902951727F);
        escalar(g0, "valvulas_37", 0.42222469658485146F, 1.0F, 0.3007620636484648F);
        escalar(g0, "valvulas_38", 0.3812413310214014F, 1.0F, 0.4897609753600144F);
        escalar(g0, "valvulas_39", 0.3785148211674293F, 1.0F, 0.3421181169706716F);
        escalar(g0, "valvulas_40", 0.459694353673739F, 1.0F, 0.3003091103878649F);
        escalar(g0, "valvulas_41", 0.49587923980790827F, 1.0F, 0.2843122028200322F);
        escalar(g0, "valvulas_42", 0.42780107603122963F, 1.0F, 0.5054047940939457F);
        escalar(g0, "valvulas_43", 0.39286758781997616F, 1.0F, 0.4121148217493801F);
        escalar(g0, "valvulas_44", 0.3976002975324097F, 1.0F, 0.28887565090182665F);
        escalar(g0, "valvulas_45", 0.4597496962369685F, 1.0F, 0.2833975934425945F);
        escalar(g0, "valvulas_46", 0.4969054442021932F, 1.0F, 0.26833256146435014F);
        escalar(g0, "valvulas_47", 0.431007682442202F, 1.0F, 0.47712827397486496F);
        escalar(g0, "valvulas_48", 0.3994676364567868F, 1.0F, 0.38927276748643724F);
        escalar(g0, "valvulas_49", 0.4082795413674342F, 1.0F, 0.2732127076331099F);
        escalar(g0, "valvulas_50", 0.459755576534197F, 1.0F, 0.3097420437521518F);
        escalar(g0, "valvulas_51", 0.4970143632515085F, 1.0F, 0.2932253531057921F);
        escalar(g0, "valvulas_52", 0.4313469956931202F, 1.0F, 0.26058845868533587F);
        escalar(g0, "valvulas_53", 0.40016240399913827F, 1.0F, 0.4248556998422849F);
        escalar(g0, "valvulas_54", 0.40939740737769537F, 1.0F, 0.2976121528147287F);
        escalar(g0, "valvulas_55", 0.4597222382949305F, 1.0F, 0.4899719898878211F);
        escalar(g0, "valvulas_56", 0.4963966689673268F, 1.0F, 0.46352408562768366F);
        escalar(g0, "valvulas_57", 0.4294211401514463F, 1.0F, 0.411263164995215F);
        escalar(g0, "valvulas_58", 0.3962135698799395F, 1.0F, 0.33414437667510694F);
        escalar(g0, "valvulas_59", 0.4030342638455858F, 1.0F, 0.46453576060122037F);
        escalar(g0, "valvulas_60", 0.4597222382949305F, 1.0F, 0.48997198990570057F);
        escalar(g0, "valvulas_61", 0.4963966689673268F, 1.0F, 0.4635240856445779F);
        escalar(g0, "valvulas_62", 0.4294211401514465F, 1.0F, 0.41126316501016247F);
        escalar(g0, "valvulas_63", 0.39621356987993916F, 1.0F, 0.33414437668718167F);
        escalar(g0, "valvulas_64", 0.40303426384558616F, 1.0F, 0.46453576061777985F);
        escalar(g0, "valvulas_65", 0.459755576534197F, 1.0F, 0.3097420437521519F);
        escalar(g0, "valvulas_66", 0.4970143632515085F, 1.0F, 0.29322535310579223F);
        escalar(g0, "valvulas_67", 0.4313469956931204F, 1.0F, 0.2605884586853358F);
        escalar(g0, "valvulas_68", 0.4001624039991376F, 1.0F, 0.4248556998422845F);
        escalar(g0, "valvulas_69", 0.40939740737769603F, 1.0F, 0.2976121528147285F);
        escalar(g0, "valvulas_70", 0.4597496962369685F, 1.0F, 0.2833975934425951F);
        escalar(g0, "valvulas_71", 0.4969054442021932F, 1.0F, 0.26833256146435036F);
        escalar(g0, "valvulas_72", 0.4310076824422021F, 1.0F, 0.4771282739748657F);
        escalar(g0, "valvulas_73", 0.3994676364567865F, 1.0F, 0.3892727674864388F);
        escalar(g0, "valvulas_74", 0.4082795413674345F, 1.0F, 0.2732127076331111F);
        escalar(g0, "valvulas_75", 0.459694353673739F, 1.0F, 0.30030911038786445F);
        escalar(g0, "valvulas_76", 0.49587923980790827F, 1.0F, 0.28431220282003256F);
        escalar(g0, "valvulas_77", 0.42780107603122985F, 1.0F, 0.5054047940939463F);
        escalar(g0, "valvulas_78", 0.39286758781997594F, 1.0F, 0.41211482174937925F);
        escalar(g0, "valvulas_79", 0.39760029753240994F, 1.0F, 0.2888756509018259F);
        escalar(g0, "valvulas_80", 0.45959905345479585F, 1.0F, 0.3577958069610166F);
        escalar(g0, "valvulas_81", 0.4941075702632125F, 1.0F, 0.338631209029516F);
        escalar(g0, "valvulas_82", 0.42222469658485146F, 1.0F, 0.30076206364846314F);
        escalar(g0, "valvulas_83", 0.38124133102140134F, 1.0F, 0.48976097536001273F);
        escalar(g0, "valvulas_84", 0.3785148211674295F, 1.0F, 0.3421181169706707F);
        escalar(g0, "valvulas_85", 0.4594948608998463F, 1.0F, 0.3901009689022101F);
        escalar(g0, "valvulas_86", 0.49216436336347735F, 1.0F, 0.3689725823937633F);
        escalar(g0, "valvulas_87", 0.4160515022676716F, 1.0F, 0.49083450156766134F);
        escalar(g0, "valvulas_88", 0.3681497876144823F, 1.0F, 0.39842289397880293F);
        escalar(g0, "valvulas_89", 0.3565852356454736F, 1.0F, 0.2763440723250013F);
        escalar(g0, "valvulas_90", 0.4594948608998463F, 1.0F, 0.3901009689212345F);
        escalar(g0, "valvulas_91", 0.49216436336347735F, 1.0F, 0.3689725824117393F);
        escalar(g0, "valvulas_92", 0.4160515022676716F, 1.0F, 0.4908345015915182F);
        escalar(g0, "valvulas_93", 0.3681497876144822F, 1.0F, 0.39842289399807507F);
        escalar(g0, "valvulas_94", 0.3565852356454736F, 1.0F, 0.2763440723382165F);
        escalar(g0, "valvulas_95", 0.45959905345479585F, 1.0F, 0.3577958069610173F);
        escalar(g0, "valvulas_96", 0.4941075702632125F, 1.0F, 0.33863120902951677F);
        escalar(g0, "valvulas_97", 0.42222469658485146F, 1.0F, 0.3007620636484639F);
        escalar(g0, "valvulas_98", 0.38124133102140123F, 1.0F, 0.4897609753600139F);
        escalar(g0, "valvulas_99", 0.3785148211674294F, 1.0F, 0.3421181169706715F);
        escalar(g0, "valvulas_100", 0.459694353673739F, 1.0F, 0.300309110387865F);
        escalar(g0, "valvulas_101", 0.49587923980790827F, 1.0F, 0.28431220282003306F);
        escalar(g0, "valvulas_102", 0.42780107603122974F, 1.0F, 0.5054047940939477F);
        escalar(g0, "valvulas_103", 0.392867587819976F, 1.0F, 0.41211482174938097F);
        escalar(g0, "valvulas_104", 0.3976002975324099F, 1.0F, 0.2888756509018271F);
        escalar(g0, "valvulas_105", 0.45974969623696854F, 1.0F, 0.28339759344259424F);
        escalar(g0, "valvulas_106", 0.49690544420219307F, 1.0F, 0.2683325614643497F);
        escalar(g0, "valvulas_107", 0.43100768244220206F, 1.0F, 0.47712827397486485F);
        escalar(g0, "valvulas_108", 0.3994676364567866F, 1.0F, 0.3892727674864377F);
        escalar(g0, "valvulas_109", 0.4082795413674344F, 1.0F, 0.2732127076331103F);
        escalar(g0, "valvulas_110", 0.459755576534197F, 1.0F, 0.3097420437521514F);
        escalar(g0, "valvulas_111", 0.4970143632515084F, 1.0F, 0.2932253531057917F);
        escalar(g0, "valvulas_112", 0.43134699569312024F, 1.0F, 0.2605884586853353F);
        escalar(g0, "valvulas_113", 0.400162403999138F, 1.0F, 0.424855699842284F);
        escalar(g0, "valvulas_114", 0.40939740737769575F, 1.0F, 0.2976121528147281F);
        escalar(g0, "valvulas_115", 0.4597222382949305F, 1.0F, 0.48997198988223856F);
        escalar(g0, "valvulas_116", 0.4963966689673268F, 1.0F, 0.46352408562240877F);
        escalar(g0, "valvulas_117", 0.42942114015144645F, 1.0F, 0.41126316499054794F);
        escalar(g0, "valvulas_118", 0.3962135698799393F, 1.0F, 0.3341443766713368F);
        escalar(g0, "valvulas_119", 0.403034263845586F, 1.0F, 0.46453576059604995F);
        escalar(g0, "silbato_0", 0.09238795325112868F, 1.0F, 0.09238795325112868F);
        escalar(g0, "silbato_1", 0.09238795325112868F, 1.0F, 0.09238795325112868F);
        escalar(g0, "tanque_cantoi_0", 1.0F, 1.0F, 0.5852709660483855F);
        escalar(g0, "tanque_cantoi_1", 1.0F, 1.0F, 0.5852709660483841F);
        escalar(g0, "tanque_cantoi_2", 1.0F, 1.0F, 0.5852709660483844F);
        escalar(g0, "tanque_cantoi_3", 1.0F, 1.0F, 0.5852709660483848F);
        escalar(g0, "tanque_cantod_0", 1.0F, 1.0F, 0.5852709660483855F);
        escalar(g0, "tanque_cantod_1", 1.0F, 1.0F, 0.5852709660483841F);
        escalar(g0, "tanque_cantod_2", 1.0F, 1.0F, 0.5852709660483844F);
        escalar(g0, "tanque_cantod_3", 1.0F, 1.0F, 0.5852709660483848F);
        escalar(g0, "cabina_techo_0", 1.0008333333333332F, 1.0F, 0.6938487690375806F);
        escalar(g0, "cabina_techo_1", 1.0008333333333332F, 1.0F, 0.6938487690375812F);
        escalar(g0, "cabina_techo_2", 1.0008333333333332F, 1.0F, 0.6938487690375802F);
        escalar(g0, "cabina_techo_3", 1.0008333333333332F, 1.0F, 0.6938487690375811F);
        escalar(g0, "cabina_techo_4", 1.0008333333333332F, 1.0F, 0.6938487690375806F);
        escalar(g0, "cabina_techo_5", 1.0008333333333332F, 1.0F, 0.6938487690375809F);
        escalar(g0, "cabina_techo_6", 1.0008333333333332F, 1.0F, 0.69384876903758F);
        escalar(g0, "cabina_techo_7", 1.0008333333333332F, 1.0F, 0.6938487690375811F);
        escalar(g0, "cabina_techo_8", 1.0008333333333332F, 1.0F, 0.6938487690375813F);
        escalar(g0, "cabina_techo_9", 1.0008333333333332F, 1.0F, 0.6938487690375795F);
    }

    private static void escalas2(ModelPart g0) {
        escalar(g0, "cabina_techo_10", 1.0008333333333332F, 1.0F, 0.6938487690375812F);
        escalar(g0, "cabina_techo_11", 1.0008333333333332F, 1.0F, 0.6938487690375811F);
        escalar(g0, "numeroi", 0.5F, 0.5F, 1.0F);
        escalar(g0, "numerod", 0.5F, 0.5F, 1.0F);
        escalar(g0, "cab_velocimetro", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.656F, 0.6F);
        escalar(g0, "cab_presion", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "cab_presion_aguja", 0.3F, 0.656F, 0.6F);
        escalar(g0, "cab_regulador", 0.8F, 0.9013878188659974F, 0.8F);
        escalar(g0, "cab_tubo", 0.6F, 0.9375F, 0.6F);
        escalar(g0, "cab_freno_manija", 0.6F, 1.0F, 0.6F);
    }
}
