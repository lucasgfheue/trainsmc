package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "GE 44 toneladas" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloGE44 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("ge44"), "main"),
            LocomotoraMod.id("textures/entity/ge44.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, -5.28F, -23.5F, 0.0F, "cuerpo", 4.8F, 5.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.15F, 0.0F, -5.0F, -22.0F, 0.15F, "cuerpo", -0.24F, 7.5F, 0.0F)),
            ModeloGE44::crearCapa,
            16.0F,
            ModeloGE44::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -25.0F, 25.0F)));

    private ModeloGE44() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(378, 73).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(902, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 73).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-29.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(922, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(942, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(378, 73).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(902, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 86).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-20.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(922, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(942, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(378, 73).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(902, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 86).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-29.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(922, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(942, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(378, 73).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(902, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(20, 86).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-20.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(922, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(942, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(642, 73).addBox(-35.0F, -9.0F, 7.0F, 20.0F, 6.0F, 1.0F).texOffs(684, 73).addBox(-35.0F, -9.0F, -8.0F, 20.0F, 6.0F, 1.0F).texOffs(30, 86).addBox(-31.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(40, 86).addBox(-31.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(50, 86).addBox(-22.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(60, 86).addBox(-22.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(378, 73).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(902, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 86).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(20.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(922, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(942, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(378, 73).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(902, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 86).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(29.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(922, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(942, 86).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(378, 73).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(902, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(90, 86).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(20.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(922, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(942, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(378, 73).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(902, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(100, 86).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(29.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(922, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(942, 86).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(450, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(726, 73).addBox(15.0F, -9.0F, 7.0F, 20.0F, 6.0F, 1.0F).texOffs(768, 73).addBox(15.0F, -9.0F, -8.0F, 20.0F, 6.0F, 1.0F).texOffs(110, 86).addBox(18.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(120, 86).addBox(18.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(130, 86).addBox(27.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(140, 86).addBox(27.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(0, 48).addBox(-40.0F, -12.0F, -11.0F, 80.0F, 3.0F, 22.0F).texOffs(784, 0).addBox(-42.0F, -12.0F, -11.0F, 2.0F, 6.0F, 22.0F).texOffs(946, 73).addBox(-47.0F, -10.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(420, 93).addBox(-40.5F, -4.0F, -11.0F, 3.0F, 1.0F, 1.0F).texOffs(978, 73).addBox(-40.5F, -9.0F, -11.0F, 1.0F, 5.0F, 1.0F).texOffs(982, 73).addBox(-38.5F, -9.0F, -11.0F, 1.0F, 5.0F, 1.0F).texOffs(428, 93).addBox(-40.5F, -4.0F, 10.0F, 3.0F, 1.0F, 1.0F).texOffs(986, 73).addBox(-40.5F, -9.0F, 10.0F, 1.0F, 5.0F, 1.0F).texOffs(990, 73).addBox(-38.5F, -9.0F, 10.0F, 1.0F, 5.0F, 1.0F).texOffs(832, 0).addBox(40.0F, -12.0F, -11.0F, 2.0F, 6.0F, 22.0F).texOffs(962, 73).addBox(42.0F, -10.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(436, 93).addBox(37.5F, -4.0F, -11.0F, 3.0F, 1.0F, 1.0F).texOffs(994, 73).addBox(37.5F, -9.0F, -11.0F, 1.0F, 5.0F, 1.0F).texOffs(998, 73).addBox(39.5F, -9.0F, -11.0F, 1.0F, 5.0F, 1.0F).texOffs(444, 93).addBox(37.5F, -4.0F, 10.0F, 3.0F, 1.0F, 1.0F).texOffs(1002, 73).addBox(37.5F, -9.0F, 10.0F, 1.0F, 5.0F, 1.0F).texOffs(1006, 73).addBox(39.5F, -9.0F, 10.0F, 1.0F, 5.0F, 1.0F).texOffs(604, 0).addBox(-38.0F, -25.0F, -8.0F, 29.0F, 13.0F, 16.0F).texOffs(680, 48).addBox(-38.0F, -27.0F, -6.0F, 29.0F, 2.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_d_cantoi_0", CubeListBuilder.create().texOffs(0, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -25.309016994374943F, -7.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantoi_1", CubeListBuilder.create().texOffs(60, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -25.89680224666742F, -7.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantoi_2", CubeListBuilder.create().texOffs(120, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.39680224666742F, -7.39680224666742F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantoi_3", CubeListBuilder.create().texOffs(180, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.7600735106701F, -6.89680224666742F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantoi_4", CubeListBuilder.create().texOffs(240, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.951056516295154F, -6.3090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantod_0", CubeListBuilder.create().texOffs(300, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -25.309016994374943F, 7.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantod_1", CubeListBuilder.create().texOffs(360, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -25.89680224666742F, 7.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantod_2", CubeListBuilder.create().texOffs(420, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.39680224666742F, 7.39680224666742F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantod_3", CubeListBuilder.create().texOffs(480, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.7600735106701F, 6.89680224666742F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantod_4", CubeListBuilder.create().texOffs(540, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.951056516295154F, 6.3090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_tapaa", CubeListBuilder.create().texOffs(340, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 32.0F), PartPose.offset(-38.0F, -25.0F, -8.0F));
        g.addOrReplaceChild("capo_d_tapab", CubeListBuilder.create().texOffs(406, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 32.0F), PartPose.offset(-10.0F, -25.0F, -8.0F));
        g.addOrReplaceChild("faro_d_0", CubeListBuilder.create().texOffs(710, 86).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(34, 73).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-38.05F, -24.4F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_1", CubeListBuilder.create().texOffs(734, 86).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(58, 73).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-38.05F, -24.4F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_2", CubeListBuilder.create().texOffs(758, 86).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(82, 73).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-38.05F, -24.4F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_3", CubeListBuilder.create().texOffs(782, 86).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(106, 73).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-38.05F, -24.4F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_vidrio", CubeListBuilder.create().texOffs(226, 73).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-38.669999999999995F, -24.4F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escape_d_0", CubeListBuilder.create().texOffs(458, 73).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 4.0F, 5.0F).texOffs(544, 48).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 4.0F, 12.0F), PartPose.offset(-14.0F, 0.0F, 3.0F));
        g.addOrReplaceChild("escape_d_1", CubeListBuilder.create().texOffs(492, 73).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 4.0F, 5.0F).texOffs(578, 48).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 4.0F, 12.0F), PartPose.offsetAndRotation(-14.0F, 0.0F, 3.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("arenero_d_0", CubeListBuilder.create().texOffs(810, 73).addBox(-6.0F, -28.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(892, 48).addBox(-2.5F, -28.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offset(-33.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("arenero_d_1", CubeListBuilder.create().texOffs(844, 73).addBox(-6.0F, -28.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(926, 48).addBox(-2.5F, -28.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-33.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("baranda_d", CubeListBuilder.create().texOffs(600, 91).addBox(-39.0F, -21.0F, 10.0F, 29.0F, 1.0F, 1.0F).texOffs(594, 73).addBox(-39.5F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(598, 73).addBox(-25.0F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(602, 73).addBox(-10.5F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(660, 91).addBox(-39.0F, -21.0F, -11.0F, 29.0F, 1.0F, 1.0F).texOffs(606, 73).addBox(-39.5F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F).texOffs(610, 73).addBox(-25.0F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F).texOffs(614, 73).addBox(-10.5F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F).texOffs(694, 0).addBox(9.0F, -25.0F, -8.0F, 29.0F, 13.0F, 16.0F).texOffs(762, 48).addBox(9.0F, -27.0F, -6.0F, 29.0F, 2.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_t_cantoi_0", CubeListBuilder.create().texOffs(720, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -25.309016994374943F, -7.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_1", CubeListBuilder.create().texOffs(780, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -25.89680224666742F, -7.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_2", CubeListBuilder.create().texOffs(840, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.39680224666742F, -7.39680224666742F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_3", CubeListBuilder.create().texOffs(900, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.7600735106701F, -6.89680224666742F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_4", CubeListBuilder.create().texOffs(960, 91).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.951056516295154F, -6.3090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_0", CubeListBuilder.create().texOffs(0, 93).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -25.309016994374943F, 7.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_1", CubeListBuilder.create().texOffs(60, 93).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -25.89680224666742F, 7.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_2", CubeListBuilder.create().texOffs(120, 93).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.39680224666742F, 7.39680224666742F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_3", CubeListBuilder.create().texOffs(180, 93).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.7600735106701F, 6.89680224666742F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_4", CubeListBuilder.create().texOffs(240, 93).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.951056516295154F, 6.3090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_tapaa", CubeListBuilder.create().texOffs(472, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 32.0F), PartPose.offset(9.0F, -25.0F, -8.0F));
        g.addOrReplaceChild("capo_t_tapab", CubeListBuilder.create().texOffs(538, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 32.0F), PartPose.offset(37.0F, -25.0F, -8.0F));
        g.addOrReplaceChild("faro_t_0", CubeListBuilder.create().texOffs(806, 86).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(130, 73).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(38.05F, -24.4F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_1", CubeListBuilder.create().texOffs(830, 86).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(154, 73).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(38.05F, -24.4F, 0.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_2", CubeListBuilder.create().texOffs(854, 86).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(178, 73).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(38.05F, -24.4F, 0.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_3", CubeListBuilder.create().texOffs(878, 86).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(202, 73).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(38.05F, -24.4F, 0.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_vidrio", CubeListBuilder.create().texOffs(266, 73).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(38.669999999999995F, -24.4F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escape_t_0", CubeListBuilder.create().texOffs(526, 73).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 4.0F, 5.0F).texOffs(612, 48).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 4.0F, 12.0F), PartPose.offset(14.0F, 0.0F, 3.0F));
        g.addOrReplaceChild("escape_t_1", CubeListBuilder.create().texOffs(560, 73).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 4.0F, 5.0F).texOffs(646, 48).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 4.0F, 12.0F), PartPose.offsetAndRotation(14.0F, 0.0F, 3.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("arenero_t_0", CubeListBuilder.create().texOffs(878, 73).addBox(-6.0F, -28.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(960, 48).addBox(-2.5F, -28.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offset(33.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("arenero_t_1", CubeListBuilder.create().texOffs(912, 73).addBox(-6.0F, -28.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(0, 73).addBox(-2.5F, -28.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(33.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("baranda_t", CubeListBuilder.create().texOffs(300, 93).addBox(10.0F, -21.0F, 10.0F, 29.0F, 1.0F, 1.0F).texOffs(618, 73).addBox(9.5F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(622, 73).addBox(24.0F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(626, 73).addBox(38.5F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(360, 93).addBox(10.0F, -21.0F, -11.0F, 29.0F, 1.0F, 1.0F).texOffs(630, 73).addBox(9.5F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F).texOffs(634, 73).addBox(24.0F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F).texOffs(638, 73).addBox(38.5F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(180, 0).addBox(-9.0F, -33.0F, -11.0F, 18.0F, 21.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_arcom9", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(-9.0F, -33.0F, -11.0F));
        g.addOrReplaceChild("cabina_arco8", CubeListBuilder.create().texOffs(90, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(8.0F, -33.0F, -11.0F));
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(158, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -29.84098181691209F, -10.707444580227126F, -2.4064234406031426F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(204, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -31.16233363049279F, -9.033891366774148F, -2.5400905702370795F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(250, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -32.24886526331285F, -7.199170683838135F, -2.6737576998710155F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(296, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.08119264856592F, -5.236014526710127F, -2.8074248295049515F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(342, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.64446680334788F, -3.179446220023851F, -2.9410919591388915F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(388, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.92863873919237F, -1.066155590604839F, -3.074759088772823F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(434, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.92863873919238F, 1.0661555906048374F, 3.074759088772826F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(480, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.64446680334789F, 3.1794462200238494F, 2.9410919591388884F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(526, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.08119264856592F, 5.236014526710127F, 2.8074248295049515F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(572, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -32.24886526331285F, 7.199170683838135F, 2.6737576998710164F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(618, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -31.162333630492796F, 9.033891366774146F, 2.5400905702370786F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(664, 86).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -29.84098181691209F, 10.707444580227126F, 2.406423440603143F, 0.0F, 0.0F));
        g.addOrReplaceChild("bocina_0", CubeListBuilder.create().texOffs(508, 48).addBox(-4.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(420, 48).addBox(-4.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -35.0F, 0.0F));
        g.addOrReplaceChild("bocina_1", CubeListBuilder.create().texOffs(526, 48).addBox(-4.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(452, 48).addBox(-4.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -35.0F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_forro", CubeListBuilder.create().texOffs(352, 48).addBox(-8.0F, -31.0F, 9.5F, 16.0F, 18.0F, 1.0F).texOffs(386, 48).addBox(-8.0F, -31.0F, -10.5F, 16.0F, 18.0F, 1.0F).texOffs(260, 0).addBox(7.0F, -31.0F, -9.5F, 1.0F, 18.0F, 19.0F).texOffs(204, 48).addBox(-8.0F, -13.0F, -10.5F, 16.0F, 1.0F, 21.0F).texOffs(278, 48).addBox(-8.0F, -32.0F, -10.5F, 16.0F, 1.0F, 21.0F).texOffs(300, 0).addBox(-8.0F, -31.0F, -9.5F, 1.0F, 18.0F, 19.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_pupitre", CubeListBuilder.create().texOffs(484, 48).addBox(-7.0F, -22.0F, 1.0F, 4.0F, 9.0F, 8.0F).texOffs(398, 73).addBox(-7.0F, -25.0F, 1.5F, 1.0F, 3.0F, 7.0F), PartPose.ZERO);
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(844, 48).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-5.4F, -23.5F, 5.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(970, 86).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-5.28F, -23.5F, 5.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro0", CubeListBuilder.create().texOffs(306, 73).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-5.4F, -23.5F, 1.4000000000000004F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro0_aguja", CubeListBuilder.create().texOffs(452, 93).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.28F, -23.5F, 1.4000000000000004F, 0.4F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro1", CubeListBuilder.create().texOffs(342, 73).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-5.4F, -23.5F, 8.6F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro1_aguja", CubeListBuilder.create().texOffs(456, 93).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.28F, -23.5F, 8.6F, 1.1F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_luces", CubeListBuilder.create().texOffs(460, 93).addBox(-5.0F, -23.0F, 1.5F, 1.0F, 1.0F, 1.0F).texOffs(464, 93).addBox(-5.0F, -23.0F, 2.7F, 1.0F, 1.0F, 1.0F).texOffs(468, 93).addBox(-5.0F, -23.0F, 3.9000000000000004F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(150, 86).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F).texOffs(962, 86).addBox(-1.0F, -6.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -22.0F, 7.5F, 0.0F, 0.0F, 0.15F));
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(154, 86).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -22.5F, 2.5F, 0.0F, 0.0F, -2.4668517113662407F));
        g.addOrReplaceChild("cab_freno_perilla", CubeListBuilder.create().texOffs(472, 93).addBox(-3.5F, -25.5F, 2.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(414, 73).addBox(5.0F, -19.0F, 4.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(424, 73).addBox(5.0F, -19.0F, -8.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "capo_d_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_d_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_d_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_d_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_d_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_d_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_d_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_d_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_d_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_d_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_d_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_d_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_d_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "escape_d_0", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "escape_d_1", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "arenero_d_0", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "arenero_d_1", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "capo_t_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_t_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_t_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_t_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_t_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_t_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_t_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_t_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_t_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_t_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_t_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_t_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_t_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "escape_t_0", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "escape_t_1", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "arenero_t_0", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "arenero_t_1", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "cabina_arcom9", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_arco8", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_techo_0", 1.001F, 1.0F, 0.719027428241869F);
        escalar(g0, "cabina_techo_1", 1.001F, 1.0F, 0.719027428241869F);
        escalar(g0, "cabina_techo_2", 1.001F, 1.0F, 0.7190274282418697F);
        escalar(g0, "cabina_techo_3", 1.001F, 1.0F, 0.7190274282418693F);
        escalar(g0, "cabina_techo_4", 1.001F, 1.0F, 0.7190274282418686F);
        escalar(g0, "cabina_techo_5", 1.001F, 1.0F, 0.7190274282418697F);
        escalar(g0, "cabina_techo_6", 1.001F, 1.0F, 0.7190274282418684F);
        escalar(g0, "cabina_techo_7", 1.001F, 1.0F, 0.7190274282418697F);
        escalar(g0, "cabina_techo_8", 1.001F, 1.0F, 0.7190274282418696F);
        escalar(g0, "cabina_techo_9", 1.001F, 1.0F, 0.7190274282418687F);
        escalar(g0, "cabina_techo_10", 1.001F, 1.0F, 0.7190274282418696F);
        escalar(g0, "cabina_techo_11", 1.001F, 1.0F, 0.7190274282418693F);
        escalar(g0, "bocina_0", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
        escalar(g0, "bocina_1", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
        escalar(g0, "cab_velocimetro", 0.2333333333333333F, 0.6F, 0.2333333333333333F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.574F, 0.6F);
        escalar(g0, "cab_manometro0", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro0_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_manometro1", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro1_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_freno", 0.8F, 0.8003905296791061F, 0.8F);
    }
}
