package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "GE 44 toneladas" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloGE44 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("ge44"), "main"),
            LocomotoraMod.id("textures/entity/ge44.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -29.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -20.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 20.5F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 29.5F, -4.0F, 1.0471975511965976F, "cuerpo")),
            ModeloGE44::crearCapa,
            16.0F,
            ModeloGE44::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -25.0F, 25.0F)));

    private ModeloGE44() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(808, 48).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(284, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(828, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(380, 65).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-29.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(304, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(836, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(324, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(844, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(808, 48).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(284, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(828, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(390, 65).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-20.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(304, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(836, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(324, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(844, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(808, 48).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(284, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(828, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 65).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-29.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(304, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(836, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(324, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(844, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(808, 48).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(284, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(828, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(410, 65).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-20.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(304, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(836, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(324, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(844, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(12, 65).addBox(-35.0F, -9.0F, 7.0F, 20.0F, 6.0F, 1.0F).texOffs(54, 65).addBox(-35.0F, -9.0F, -8.0F, 20.0F, 6.0F, 1.0F).texOffs(420, 65).addBox(-31.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(430, 65).addBox(-31.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(440, 65).addBox(-22.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(450, 65).addBox(-22.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(808, 48).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(284, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(828, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(460, 65).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(20.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(304, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(836, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(324, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(844, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(808, 48).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(284, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(828, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(470, 65).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(29.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(304, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(836, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(324, 74).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(844, 48).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(808, 48).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(284, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(828, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(480, 65).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(20.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(304, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(836, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(324, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(844, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(20.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(808, 48).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(284, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(828, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(490, 65).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(29.5F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(304, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(836, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(324, 74).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(844, 48).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(29.5F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(96, 65).addBox(15.0F, -9.0F, 7.0F, 20.0F, 6.0F, 1.0F).texOffs(138, 65).addBox(15.0F, -9.0F, -8.0F, 20.0F, 6.0F, 1.0F).texOffs(500, 65).addBox(18.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(510, 65).addBox(18.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(520, 65).addBox(27.5F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(530, 65).addBox(27.5F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(800, 0).addBox(-40.0F, -12.0F, -11.0F, 80.0F, 3.0F, 22.0F).texOffs(704, 0).addBox(-42.0F, -12.0F, -11.0F, 2.0F, 6.0F, 22.0F).texOffs(316, 65).addBox(-47.0F, -10.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(780, 78).addBox(-40.5F, -4.0F, -11.0F, 3.0F, 1.0F, 1.0F).texOffs(348, 65).addBox(-40.5F, -9.0F, -11.0F, 1.0F, 5.0F, 1.0F).texOffs(352, 65).addBox(-38.5F, -9.0F, -11.0F, 1.0F, 5.0F, 1.0F).texOffs(788, 78).addBox(-40.5F, -4.0F, 10.0F, 3.0F, 1.0F, 1.0F).texOffs(356, 65).addBox(-40.5F, -9.0F, 10.0F, 1.0F, 5.0F, 1.0F).texOffs(360, 65).addBox(-38.5F, -9.0F, 10.0F, 1.0F, 5.0F, 1.0F).texOffs(752, 0).addBox(40.0F, -12.0F, -11.0F, 2.0F, 6.0F, 22.0F).texOffs(332, 65).addBox(42.0F, -10.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(796, 78).addBox(37.5F, -4.0F, -11.0F, 3.0F, 1.0F, 1.0F).texOffs(364, 65).addBox(37.5F, -9.0F, -11.0F, 1.0F, 5.0F, 1.0F).texOffs(368, 65).addBox(39.5F, -9.0F, -11.0F, 1.0F, 5.0F, 1.0F).texOffs(804, 78).addBox(37.5F, -4.0F, 10.0F, 3.0F, 1.0F, 1.0F).texOffs(372, 65).addBox(37.5F, -9.0F, 10.0F, 1.0F, 5.0F, 1.0F).texOffs(376, 65).addBox(39.5F, -9.0F, 10.0F, 1.0F, 5.0F, 1.0F).texOffs(524, 0).addBox(-38.0F, -25.0F, -8.0F, 29.0F, 13.0F, 16.0F).texOffs(236, 48).addBox(-38.0F, -27.0F, -6.0F, 29.0F, 2.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_d_cantoi_0", CubeListBuilder.create().texOffs(344, 74).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -25.309016994374943F, -7.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantoi_1", CubeListBuilder.create().texOffs(404, 74).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -25.89680224666742F, -7.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantoi_2", CubeListBuilder.create().texOffs(464, 74).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.39680224666742F, -7.39680224666742F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantoi_3", CubeListBuilder.create().texOffs(524, 74).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.7600735106701F, -6.89680224666742F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantoi_4", CubeListBuilder.create().texOffs(584, 74).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.951056516295154F, -6.3090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantod_0", CubeListBuilder.create().texOffs(644, 74).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -25.309016994374943F, 7.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantod_1", CubeListBuilder.create().texOffs(704, 74).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -25.89680224666742F, 7.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantod_2", CubeListBuilder.create().texOffs(764, 74).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.39680224666742F, 7.39680224666742F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantod_3", CubeListBuilder.create().texOffs(824, 74).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.7600735106701F, 6.89680224666742F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_cantod_4", CubeListBuilder.create().texOffs(884, 74).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.5F, -26.951056516295154F, 6.3090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_d_tapaa", CubeListBuilder.create().texOffs(260, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 32.0F), PartPose.offset(-38.0F, -25.0F, -8.0F));
        g.addOrReplaceChild("capo_d_tapab", CubeListBuilder.create().texOffs(326, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 32.0F), PartPose.offset(-10.0F, -25.0F, -8.0F));
        g.addOrReplaceChild("faro_d_0", CubeListBuilder.create().texOffs(92, 74).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(536, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-38.05F, -24.4F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_1", CubeListBuilder.create().texOffs(116, 74).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(560, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-38.05F, -24.4F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_2", CubeListBuilder.create().texOffs(140, 74).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(584, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-38.05F, -24.4F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_3", CubeListBuilder.create().texOffs(164, 74).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(608, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-38.05F, -24.4F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_vidrio", CubeListBuilder.create().texOffs(728, 48).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-38.669999999999995F, -24.4F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escape_d_0", CubeListBuilder.create().texOffs(852, 48).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 4.0F, 5.0F).texOffs(100, 48).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 4.0F, 12.0F), PartPose.offset(-14.0F, 0.0F, 3.0F));
        g.addOrReplaceChild("escape_d_1", CubeListBuilder.create().texOffs(886, 48).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 4.0F, 5.0F).texOffs(134, 48).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 4.0F, 12.0F), PartPose.offsetAndRotation(-14.0F, 0.0F, 3.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("arenero_d_0", CubeListBuilder.create().texOffs(180, 65).addBox(-6.0F, -28.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(400, 48).addBox(-2.5F, -28.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offset(-33.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("arenero_d_1", CubeListBuilder.create().texOffs(214, 65).addBox(-6.0F, -28.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(434, 48).addBox(-2.5F, -28.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-33.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("baranda_d", CubeListBuilder.create().texOffs(944, 74).addBox(-39.0F, -21.0F, 10.0F, 29.0F, 1.0F, 1.0F).texOffs(988, 48).addBox(-39.5F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(992, 48).addBox(-25.0F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(996, 48).addBox(-10.5F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(0, 78).addBox(-39.0F, -21.0F, -11.0F, 29.0F, 1.0F, 1.0F).texOffs(1000, 48).addBox(-39.5F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F).texOffs(1004, 48).addBox(-25.0F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F).texOffs(1008, 48).addBox(-10.5F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F).texOffs(614, 0).addBox(9.0F, -25.0F, -8.0F, 29.0F, 13.0F, 16.0F).texOffs(318, 48).addBox(9.0F, -27.0F, -6.0F, 29.0F, 2.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_t_cantoi_0", CubeListBuilder.create().texOffs(60, 78).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -25.309016994374943F, -7.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_1", CubeListBuilder.create().texOffs(120, 78).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -25.89680224666742F, -7.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_2", CubeListBuilder.create().texOffs(180, 78).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.39680224666742F, -7.39680224666742F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_3", CubeListBuilder.create().texOffs(240, 78).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.7600735106701F, -6.89680224666742F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_4", CubeListBuilder.create().texOffs(300, 78).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.951056516295154F, -6.3090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_0", CubeListBuilder.create().texOffs(360, 78).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -25.309016994374943F, 7.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_1", CubeListBuilder.create().texOffs(420, 78).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -25.89680224666742F, 7.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_2", CubeListBuilder.create().texOffs(480, 78).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.39680224666742F, 7.39680224666742F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_3", CubeListBuilder.create().texOffs(540, 78).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.7600735106701F, 6.89680224666742F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_4", CubeListBuilder.create().texOffs(600, 78).addBox(-14.5F, -1.0F, -0.5F, 29.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.5F, -26.951056516295154F, 6.3090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_tapaa", CubeListBuilder.create().texOffs(392, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 32.0F), PartPose.offset(9.0F, -25.0F, -8.0F));
        g.addOrReplaceChild("capo_t_tapab", CubeListBuilder.create().texOffs(458, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 32.0F), PartPose.offset(37.0F, -25.0F, -8.0F));
        g.addOrReplaceChild("faro_t_0", CubeListBuilder.create().texOffs(188, 74).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(632, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(38.05F, -24.4F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_1", CubeListBuilder.create().texOffs(212, 74).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(656, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(38.05F, -24.4F, 0.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_2", CubeListBuilder.create().texOffs(236, 74).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(680, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(38.05F, -24.4F, 0.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_3", CubeListBuilder.create().texOffs(260, 74).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(704, 48).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(38.05F, -24.4F, 0.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_vidrio", CubeListBuilder.create().texOffs(768, 48).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(38.669999999999995F, -24.4F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escape_t_0", CubeListBuilder.create().texOffs(920, 48).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 4.0F, 5.0F).texOffs(168, 48).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 4.0F, 12.0F), PartPose.offset(14.0F, 0.0F, 3.0F));
        g.addOrReplaceChild("escape_t_1", CubeListBuilder.create().texOffs(954, 48).addBox(-6.0F, -31.0F, -2.5F, 12.0F, 4.0F, 5.0F).texOffs(202, 48).addBox(-2.5F, -31.0F, -6.0F, 5.0F, 4.0F, 12.0F), PartPose.offsetAndRotation(14.0F, 0.0F, 3.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("arenero_t_0", CubeListBuilder.create().texOffs(248, 65).addBox(-6.0F, -28.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(468, 48).addBox(-2.5F, -28.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offset(33.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("arenero_t_1", CubeListBuilder.create().texOffs(282, 65).addBox(-6.0F, -28.0F, -2.5F, 12.0F, 1.0F, 5.0F).texOffs(502, 48).addBox(-2.5F, -28.0F, -6.0F, 5.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(33.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("baranda_t", CubeListBuilder.create().texOffs(660, 78).addBox(10.0F, -21.0F, 10.0F, 29.0F, 1.0F, 1.0F).texOffs(1012, 48).addBox(9.5F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(1016, 48).addBox(24.0F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(1020, 48).addBox(38.5F, -20.0F, 10.0F, 1.0F, 8.0F, 1.0F).texOffs(720, 78).addBox(10.0F, -21.0F, -11.0F, 29.0F, 1.0F, 1.0F).texOffs(0, 65).addBox(9.5F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F).texOffs(4, 65).addBox(24.0F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F).texOffs(8, 65).addBox(38.5F, -20.0F, -11.0F, 1.0F, 8.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(180, 0).addBox(-9.0F, -33.0F, -11.0F, 18.0F, 21.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_arcom9", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(-9.0F, -33.0F, -11.0F));
        g.addOrReplaceChild("cabina_arco8", CubeListBuilder.create().texOffs(90, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 44.0F), PartPose.offset(8.0F, -33.0F, -11.0F));
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(540, 65).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -29.84098181691209F, -10.707444580227126F, -2.4064234406031426F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(586, 65).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -31.16233363049279F, -9.033891366774148F, -2.5400905702370795F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(632, 65).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -32.24886526331285F, -7.199170683838135F, -2.6737576998710155F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(678, 65).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.08119264856592F, -5.236014526710127F, -2.8074248295049515F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(724, 65).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.64446680334788F, -3.179446220023851F, -2.9410919591388915F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(770, 65).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.92863873919237F, -1.066155590604839F, -3.074759088772823F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(816, 65).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.92863873919238F, 1.0661555906048374F, 3.074759088772826F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(862, 65).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.64446680334789F, 3.1794462200238494F, 2.9410919591388884F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(908, 65).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.08119264856592F, 5.236014526710127F, 2.8074248295049515F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(954, 65).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -32.24886526331285F, 7.199170683838135F, 2.6737576998710164F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(0, 74).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -31.162333630492796F, 9.033891366774146F, 2.5400905702370786F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(46, 74).addBox(-10.0F, -1.0F, -1.5F, 20.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -29.84098181691209F, 10.707444580227126F, 2.406423440603143F, 0.0F, 0.0F));
        g.addOrReplaceChild("bocina_0", CubeListBuilder.create().texOffs(64, 48).addBox(-4.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(0, 48).addBox(-4.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -35.0F, 0.0F));
        g.addOrReplaceChild("bocina_1", CubeListBuilder.create().texOffs(82, 48).addBox(-4.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(32, 48).addBox(-4.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -35.0F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "capo_d_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_d_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_d_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_d_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_d_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_d_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_d_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_d_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_d_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_d_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_d_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_d_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_d_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_d_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "escape_d_0", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "escape_d_1", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "arenero_d_0", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "arenero_d_1", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "capo_t_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_t_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_t_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_t_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_t_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_t_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_t_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_t_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_t_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_t_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_t_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_t_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_t_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faro_t_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "escape_t_0", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "escape_t_1", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "arenero_t_0", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "arenero_t_1", 0.18477590650225736F, 1.0F, 0.18477590650225736F);
        escalar(g0, "cabina_arcom9", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_arco8", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_techo_0", 1.001F, 1.0F, 0.719027428241869F);
        escalar(g0, "cabina_techo_1", 1.001F, 1.0F, 0.719027428241869F);
        escalar(g0, "cabina_techo_2", 1.001F, 1.0F, 0.7190274282418697F);
        escalar(g0, "cabina_techo_3", 1.001F, 1.0F, 0.7190274282418693F);
        escalar(g0, "cabina_techo_4", 1.001F, 1.0F, 0.7190274282418686F);
        escalar(g0, "cabina_techo_5", 1.001F, 1.0F, 0.7190274282418697F);
        escalar(g0, "cabina_techo_6", 1.001F, 1.0F, 0.7190274282418684F);
        escalar(g0, "cabina_techo_7", 1.001F, 1.0F, 0.7190274282418697F);
        escalar(g0, "cabina_techo_8", 1.001F, 1.0F, 0.7190274282418696F);
        escalar(g0, "cabina_techo_9", 1.001F, 1.0F, 0.7190274282418687F);
        escalar(g0, "cabina_techo_10", 1.001F, 1.0F, 0.7190274282418696F);
        escalar(g0, "cabina_techo_11", 1.001F, 1.0F, 0.7190274282418693F);
        escalar(g0, "bocina_0", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
        escalar(g0, "bocina_1", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
    }
}
