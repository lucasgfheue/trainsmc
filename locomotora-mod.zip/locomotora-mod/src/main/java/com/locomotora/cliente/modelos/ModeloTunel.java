package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Locomotora de túnel" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloTunel {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("tunel"), "main"),
            LocomotoraMod.id("textures/entity/tunel.png"),
            List.of(
                new DatosModelo.Animada("ri0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("ri1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, -23.279999999999998F, -15.5F, 0.0F, "cuerpo", 4.8F, 4.5F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.15F, 0.0F, -23.0F, -14.0F, 0.15F, "cuerpo", -0.24F, 6.5F, 0.0F)),
            ModeloTunel::crearCapa,
            16.0F,
            ModeloTunel::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -12.0F, 12.0F)));

    private ModeloTunel() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("ri0_0", CubeListBuilder.create().texOffs(214, 67).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(16, 77).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(274, 67).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(914, 67).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-12.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("ri0_1", CubeListBuilder.create().texOffs(34, 77).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(282, 67).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri0_2", CubeListBuilder.create().texOffs(52, 77).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(290, 67).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ri1_0", CubeListBuilder.create().texOffs(214, 67).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(16, 77).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(274, 67).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(924, 67).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(12.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("ri1_1", CubeListBuilder.create().texOffs(34, 77).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(282, 67).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri1_2", CubeListBuilder.create().texOffs(52, 77).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(290, 67).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd0_0", CubeListBuilder.create().texOffs(214, 67).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(16, 77).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(274, 67).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(934, 67).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-12.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rd0_1", CubeListBuilder.create().texOffs(34, 77).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(282, 67).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd0_2", CubeListBuilder.create().texOffs(52, 77).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(290, 67).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd1_0", CubeListBuilder.create().texOffs(214, 67).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(16, 77).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(274, 67).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(944, 67).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(12.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rd1_1", CubeListBuilder.create().texOffs(34, 77).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(282, 67).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd1_2", CubeListBuilder.create().texOffs(52, 77).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(290, 67).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(694, 67).addBox(-27.0F, -9.0F, 6.0F, 54.0F, 6.0F, 1.0F).texOffs(804, 67).addBox(-27.0F, -9.0F, -7.0F, 54.0F, 6.0F, 1.0F).texOffs(954, 67).addBox(-14.0F, -5.5F, 7.0F, 4.0F, 4.0F, 1.0F).texOffs(964, 67).addBox(-14.0F, -5.5F, -8.0F, 4.0F, 4.0F, 1.0F).texOffs(974, 67).addBox(10.0F, -5.5F, 7.0F, 4.0F, 4.0F, 1.0F).texOffs(984, 67).addBox(10.0F, -5.5F, -8.0F, 4.0F, 4.0F, 1.0F).texOffs(182, 42).addBox(-27.0F, -10.0F, -9.0F, 54.0F, 1.0F, 18.0F).texOffs(972, 0).addBox(-29.0F, -10.0F, -9.0F, 2.0F, 7.0F, 18.0F).texOffs(232, 67).addBox(-31.0F, -8.5F, -2.5F, 2.0F, 4.0F, 5.0F).texOffs(318, 77).addBox(-32.0F, -7.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(0, 42).addBox(27.0F, -10.0F, -9.0F, 2.0F, 7.0F, 18.0F).texOffs(246, 67).addBox(29.0F, -8.5F, -2.5F, 2.0F, 4.0F, 5.0F).texOffs(324, 77).addBox(31.0F, -7.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(108, 42).addBox(-11.0F, -16.0F, -7.5F, 22.0F, 6.0F, 15.0F).texOffs(886, 42).addBox(-11.0F, -18.0F, -5.5F, 22.0F, 2.0F, 11.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_cantoi_0", CubeListBuilder.create().texOffs(358, 77).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -16.309016994374947F, -7.451056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_1", CubeListBuilder.create().texOffs(404, 77).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -16.89680224666742F, -7.2600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_2", CubeListBuilder.create().texOffs(450, 77).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.39680224666742F, -6.89680224666742F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_3", CubeListBuilder.create().texOffs(496, 77).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.7600735106701F, -6.39680224666742F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_4", CubeListBuilder.create().texOffs(542, 77).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.951056516295154F, -5.8090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_0", CubeListBuilder.create().texOffs(588, 77).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -16.309016994374947F, 7.451056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_1", CubeListBuilder.create().texOffs(634, 77).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -16.89680224666742F, 7.2600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_2", CubeListBuilder.create().texOffs(680, 77).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.39680224666742F, 6.89680224666742F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_3", CubeListBuilder.create().texOffs(726, 77).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.7600735106701F, 6.39680224666742F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_4", CubeListBuilder.create().texOffs(772, 77).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.951056516295154F, 5.8090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_tapaa", CubeListBuilder.create().texOffs(312, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 30.0F), PartPose.offset(-11.0F, -16.0F, -7.5F));
        g.addOrReplaceChild("capo_tapab", CubeListBuilder.create().texOffs(374, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 30.0F), PartPose.offset(10.0F, -16.0F, -7.5F));
        g.addOrReplaceChild("capo_techo", CubeListBuilder.create().texOffs(174, 67).addBox(-6.0F, -19.0F, -4.0F, 12.0F, 1.0F, 8.0F).texOffs(436, 0).addBox(-27.0F, -21.0F, -9.5F, 16.0F, 11.0F, 19.0F).texOffs(454, 42).addBox(-27.0F, -23.0F, -7.5F, 16.0F, 2.0F, 15.0F), PartPose.ZERO);
        g.addOrReplaceChild("escape_0", CubeListBuilder.create().texOffs(774, 42).addBox(4.0F, -6.0F, -2.5F, 5.0F, 12.0F, 5.0F).texOffs(578, 42).addBox(4.0F, -2.5F, -6.0F, 5.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -17.0F, -5.5F));
        g.addOrReplaceChild("escape_1", CubeListBuilder.create().texOffs(794, 42).addBox(4.0F, -6.0F, -2.5F, 5.0F, 12.0F, 5.0F).texOffs(612, 42).addBox(4.0F, -2.5F, -6.0F, 5.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -17.0F, -5.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantoi_0", CubeListBuilder.create().texOffs(818, 77).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -21.309016994374947F, -9.451056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantoi_1", CubeListBuilder.create().texOffs(852, 77).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -21.89680224666742F, -9.2600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantoi_2", CubeListBuilder.create().texOffs(886, 77).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.39680224666742F, -8.89680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantoi_3", CubeListBuilder.create().texOffs(920, 77).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.7600735106701F, -8.39680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantoi_4", CubeListBuilder.create().texOffs(954, 77).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.951056516295154F, -7.8090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantod_0", CubeListBuilder.create().texOffs(988, 77).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -21.309016994374947F, 9.451056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantod_1", CubeListBuilder.create().texOffs(0, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -21.89680224666742F, 9.2600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantod_2", CubeListBuilder.create().texOffs(34, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.39680224666742F, 8.89680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantod_3", CubeListBuilder.create().texOffs(68, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.7600735106701F, 8.39680224666742F, 2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantod_4", CubeListBuilder.create().texOffs(102, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.951056516295154F, 7.8090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(-27.0F, -21.0F, -9.5F));
        g.addOrReplaceChild("cabina_f_tapab", CubeListBuilder.create().texOffs(78, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(-12.0F, -21.0F, -9.5F));
        g.addOrReplaceChild("faro_fi", CubeListBuilder.create().texOffs(994, 67).addBox(-28.0F, -13.5F, -8.5F, 1.0F, 2.0F, 3.0F).texOffs(330, 77).addBox(-28.2F, -13.0F, -8.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("faro_fd", CubeListBuilder.create().texOffs(1002, 67).addBox(-28.0F, -13.5F, 5.5F, 1.0F, 2.0F, 3.0F).texOffs(336, 77).addBox(-28.2F, -13.0F, 6.0F, 1.0F, 1.0F, 2.0F).texOffs(506, 0).addBox(11.0F, -21.0F, -9.5F, 16.0F, 11.0F, 19.0F).texOffs(516, 42).addBox(11.0F, -23.0F, -7.5F, 16.0F, 2.0F, 15.0F), PartPose.ZERO);
        g.addOrReplaceChild("baliza_f_base_0", CubeListBuilder.create().texOffs(298, 67).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(576, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offset(-22.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("baliza_f_base_1", CubeListBuilder.create().texOffs(364, 67).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(642, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(-22.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("baliza_f_base_2", CubeListBuilder.create().texOffs(430, 67).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(708, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(-22.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("baliza_f_0", CubeListBuilder.create().texOffs(78, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.973686027918557F, -24.6F, 0.27499999999999997F, 0.26179938779914863F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_1", CubeListBuilder.create().texOffs(476, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.11363793320239F, -25.5F, 0.2375F, 0.23675754487681036F, 0.11279899977786711F, -2.0072918324001465F));
        g.addOrReplaceChild("baliza_f_2", CubeListBuilder.create().texOffs(482, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.53349364905389F, -25.9F, 0.12499999999999999F, 0.08718721304265128F, 0.24716962264080694F, -2.7984598684324946F));
        g.addOrReplaceChild("baliza_f_3", CubeListBuilder.create().texOffs(88, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.24868602791856F, -24.6F, 0.7513139720814412F, 0.7853981633974496F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_4", CubeListBuilder.create().texOffs(488, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.351137933202395F, -25.5F, 0.6488620667976084F, 0.7330800113291681F, 0.31258511115331183F, -1.8998844739488765F));
        g.addOrReplaceChild("baliza_f_5", CubeListBuilder.create().texOffs(494, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.658493649053888F, -25.9F, 0.3415063509461096F, 0.31532962984145235F, 0.7320894011990566F, -2.68756369117762F));
        g.addOrReplaceChild("baliza_f_6", CubeListBuilder.create().texOffs(98, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.725F, -24.6F, 1.0263139720814414F, 1.3089969389957474F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_7", CubeListBuilder.create().texOffs(500, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.762500000000003F, -25.5F, 0.8863620667976084F, 1.28157703241214F, 0.4335328705826474F, -1.6951513213416587F));
        g.addOrReplaceChild("baliza_f_8", CubeListBuilder.create().texOffs(506, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.875F, -25.9F, 0.46650635094610965F, 0.8831477677945582F, 1.150788455480417F, -2.214297435588178F));
        g.addOrReplaceChild("baliza_f_9", CubeListBuilder.create().texOffs(108, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.275F, -24.6F, 1.0263139720814414F, 1.8325957145940457F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_10", CubeListBuilder.create().texOffs(512, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.237499999999997F, -25.5F, 0.8863620667976085F, 1.860015621177653F, 0.4335328705826474F, -1.4464413322481346F));
        g.addOrReplaceChild("baliza_f_11", CubeListBuilder.create().texOffs(518, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.125F, -25.9F, 0.46650635094610965F, 2.258444885795235F, 1.150788455480417F, -0.9272952180016151F));
        g.addOrReplaceChild("baliza_f_12", CubeListBuilder.create().texOffs(118, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.75131397208144F, -24.6F, 0.7513139720814415F, 2.3561944901923475F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_13", CubeListBuilder.create().texOffs(524, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.648862066797605F, -25.5F, 0.6488620667976086F, 2.4085126422606264F, 0.3125851111533111F, -1.2417081796409186F));
        g.addOrReplaceChild("baliza_f_14", CubeListBuilder.create().texOffs(530, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.34150635094611F, -25.9F, 0.34150635094610976F, 2.8262630237483406F, 0.7320894011990569F, -0.4540289624121731F));
        g.addOrReplaceChild("baliza_f_15", CubeListBuilder.create().texOffs(128, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.02631397208144F, -24.6F, 0.2750000000000003F, 2.8797932657906387F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_16", CubeListBuilder.create().texOffs(536, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.886362066797606F, -25.5F, 0.23750000000000024F, 2.90483510871298F, 0.11279899977786766F, -1.134300821189649F));
        g.addOrReplaceChild("baliza_f_17", CubeListBuilder.create().texOffs(542, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.46650635094611F, -25.9F, 0.1250000000000001F, 3.054405440547142F, 0.24716962264080725F, -0.34313278515729884F));
        g.addOrReplaceChild("baliza_f_18", CubeListBuilder.create().texOffs(138, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.026313972081443F, -24.6F, -0.27499999999999963F, -2.8797932657906444F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_19", CubeListBuilder.create().texOffs(548, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.88636206679761F, -25.5F, -0.23749999999999966F, -2.904835108712983F, -0.11279899977786711F, -1.1343008211896466F));
        g.addOrReplaceChild("baliza_f_20", CubeListBuilder.create().texOffs(554, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.46650635094611F, -25.9F, -0.12499999999999982F, -3.054405440547142F, -0.24716962264080666F, -0.3431327851572989F));
        g.addOrReplaceChild("baliza_f_21", CubeListBuilder.create().texOffs(148, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.75131397208144F, -24.6F, -0.7513139720814408F, -2.356194490192344F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_22", CubeListBuilder.create().texOffs(560, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.648862066797605F, -25.5F, -0.6488620667976079F, -2.4085126422606256F, -0.31258511115331167F, -1.2417081796409166F));
        g.addOrReplaceChild("baliza_f_23", CubeListBuilder.create().texOffs(566, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.341506350946112F, -25.9F, -0.3415063509461094F, -2.826263023748341F, -0.7320894011990563F, -0.45402896241217316F));
        g.addOrReplaceChild("baliza_f_24", CubeListBuilder.create().texOffs(158, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.275F, -24.6F, -1.0263139720814412F, -1.8325957145940461F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_25", CubeListBuilder.create().texOffs(572, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.237499999999997F, -25.5F, -0.8863620667976082F, -1.8600156211776535F, -0.43353287058264733F, -1.4464413322481342F));
        g.addOrReplaceChild("baliza_f_26", CubeListBuilder.create().texOffs(578, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.125F, -25.9F, -0.4665063509461096F, -2.2584448857952353F, -1.150788455480417F, -0.9272952180016151F));
        g.addOrReplaceChild("baliza_f_27", CubeListBuilder.create().texOffs(168, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.725F, -24.6F, -1.0263139720814416F, -1.308996938995748F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_28", CubeListBuilder.create().texOffs(584, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.762500000000003F, -25.5F, -0.8863620667976085F, -1.2815770324121407F, -0.43353287058264744F, -1.6951513213416587F));
        g.addOrReplaceChild("baliza_f_29", CubeListBuilder.create().texOffs(590, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.875F, -25.9F, -0.46650635094610976F, -0.8831477677945585F, -1.150788455480417F, -2.214297435588178F));
        g.addOrReplaceChild("baliza_f_30", CubeListBuilder.create().texOffs(178, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.24868602791856F, -24.6F, -0.7513139720814417F, -0.7853981633974454F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_31", CubeListBuilder.create().texOffs(596, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.351137933202395F, -25.5F, -0.6488620667976087F, -0.7330800113291664F, -0.31258511115331117F, -1.899884473948875F));
        g.addOrReplaceChild("baliza_f_32", CubeListBuilder.create().texOffs(602, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.65849364905389F, -25.9F, -0.3415063509461098F, -0.3153296298414524F, -0.7320894011990569F, -2.68756369117762F));
        g.addOrReplaceChild("baliza_f_33", CubeListBuilder.create().texOffs(188, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.97368602791856F, -24.6F, -0.27500000000000036F, -0.26179938779915446F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_34", CubeListBuilder.create().texOffs(608, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.113637933202394F, -25.5F, -0.23750000000000032F, -0.23675754487681352F, -0.11279899977786774F, -2.0072918324001443F));
        g.addOrReplaceChild("baliza_f_35", CubeListBuilder.create().texOffs(614, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.53349364905389F, -25.9F, -0.12500000000000017F, -0.08718721304265126F, -0.24716962264080733F, -2.7984598684324946F));
        g.addOrReplaceChild("bocina_f_0", CubeListBuilder.create().texOffs(814, 42).addBox(-17.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(646, 42).addBox(-17.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -23.5F, 5.0F));
        g.addOrReplaceChild("bocina_f_1", CubeListBuilder.create().texOffs(832, 42).addBox(-17.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(678, 42).addBox(-17.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -23.5F, 5.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantoi_0", CubeListBuilder.create().texOffs(136, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -21.309016994374947F, -9.451056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantoi_1", CubeListBuilder.create().texOffs(170, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -21.89680224666742F, -9.2600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantoi_2", CubeListBuilder.create().texOffs(204, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.39680224666742F, -8.89680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantoi_3", CubeListBuilder.create().texOffs(238, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.7600735106701F, -8.39680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantoi_4", CubeListBuilder.create().texOffs(272, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.951056516295154F, -7.8090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantod_0", CubeListBuilder.create().texOffs(306, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -21.309016994374947F, 9.451056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantod_1", CubeListBuilder.create().texOffs(340, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -21.89680224666742F, 9.2600735106701F, 2.042035224833364F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("cabina_t_cantod_2", CubeListBuilder.create().texOffs(374, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.39680224666742F, 8.89680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantod_3", CubeListBuilder.create().texOffs(408, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.7600735106701F, 8.39680224666742F, 2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantod_4", CubeListBuilder.create().texOffs(442, 82).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.951056516295154F, 7.8090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_tapaa", CubeListBuilder.create().texOffs(156, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(11.0F, -21.0F, -9.5F));
        g.addOrReplaceChild("cabina_t_tapab", CubeListBuilder.create().texOffs(234, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(26.0F, -21.0F, -9.5F));
        g.addOrReplaceChild("faro_ti", CubeListBuilder.create().texOffs(1010, 67).addBox(27.0F, -13.5F, -8.5F, 1.0F, 2.0F, 3.0F).texOffs(342, 77).addBox(27.2F, -13.0F, -8.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("faro_td", CubeListBuilder.create().texOffs(0, 77).addBox(27.0F, -13.5F, 5.5F, 1.0F, 2.0F, 3.0F).texOffs(348, 77).addBox(27.2F, -13.0F, 6.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("baliza_t_base_0", CubeListBuilder.create().texOffs(496, 67).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(774, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offset(22.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("baliza_t_base_1", CubeListBuilder.create().texOffs(562, 67).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(840, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(22.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("baliza_t_base_2", CubeListBuilder.create().texOffs(628, 67).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(906, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(22.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("baliza_t_0", CubeListBuilder.create().texOffs(198, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(23.026313972081443F, -24.6F, 0.27499999999999997F, 0.26179938779914863F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_1", CubeListBuilder.create().texOffs(620, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.88636206679761F, -25.5F, 0.2375F, 0.23675754487681036F, 0.11279899977786711F, -2.0072918324001465F));
        g.addOrReplaceChild("baliza_t_2", CubeListBuilder.create().texOffs(626, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.46650635094611F, -25.9F, 0.12499999999999999F, 0.08718721304265128F, 0.24716962264080694F, -2.7984598684324946F));
        g.addOrReplaceChild("baliza_t_3", CubeListBuilder.create().texOffs(208, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(22.75131397208144F, -24.6F, 0.7513139720814412F, 0.7853981633974496F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_4", CubeListBuilder.create().texOffs(632, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.648862066797605F, -25.5F, 0.6488620667976084F, 0.7330800113291681F, 0.31258511115331183F, -1.8998844739488765F));
        g.addOrReplaceChild("baliza_t_5", CubeListBuilder.create().texOffs(638, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.341506350946112F, -25.9F, 0.3415063509461096F, 0.31532962984145235F, 0.7320894011990566F, -2.68756369117762F));
        g.addOrReplaceChild("baliza_t_6", CubeListBuilder.create().texOffs(218, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(22.275F, -24.6F, 1.0263139720814414F, 1.3089969389957474F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_7", CubeListBuilder.create().texOffs(644, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.237499999999997F, -25.5F, 0.8863620667976084F, 1.28157703241214F, 0.4335328705826474F, -1.6951513213416587F));
        g.addOrReplaceChild("baliza_t_8", CubeListBuilder.create().texOffs(650, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.125F, -25.9F, 0.46650635094610965F, 0.8831477677945582F, 1.150788455480417F, -2.214297435588178F));
        g.addOrReplaceChild("baliza_t_9", CubeListBuilder.create().texOffs(228, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(21.725F, -24.6F, 1.0263139720814414F, 1.8325957145940457F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_10", CubeListBuilder.create().texOffs(656, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.762500000000003F, -25.5F, 0.8863620667976085F, 1.860015621177653F, 0.4335328705826474F, -1.4464413322481346F));
        g.addOrReplaceChild("baliza_t_11", CubeListBuilder.create().texOffs(662, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.875F, -25.9F, 0.46650635094610965F, 2.258444885795235F, 1.150788455480417F, -0.9272952180016151F));
        g.addOrReplaceChild("baliza_t_12", CubeListBuilder.create().texOffs(238, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(21.24868602791856F, -24.6F, 0.7513139720814415F, 2.3561944901923475F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_13", CubeListBuilder.create().texOffs(668, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.351137933202395F, -25.5F, 0.6488620667976086F, 2.4085126422606264F, 0.3125851111533111F, -1.2417081796409186F));
        g.addOrReplaceChild("baliza_t_14", CubeListBuilder.create().texOffs(674, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.65849364905389F, -25.9F, 0.34150635094610976F, 2.8262630237483406F, 0.7320894011990569F, -0.4540289624121731F));
        g.addOrReplaceChild("baliza_t_15", CubeListBuilder.create().texOffs(248, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.97368602791856F, -24.6F, 0.2750000000000003F, 2.8797932657906387F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_16", CubeListBuilder.create().texOffs(680, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.113637933202394F, -25.5F, 0.23750000000000024F, 2.90483510871298F, 0.11279899977786766F, -1.134300821189649F));
        g.addOrReplaceChild("baliza_t_17", CubeListBuilder.create().texOffs(686, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.53349364905389F, -25.9F, 0.1250000000000001F, 3.054405440547142F, 0.24716962264080725F, -0.34313278515729884F));
        g.addOrReplaceChild("baliza_t_18", CubeListBuilder.create().texOffs(258, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.973686027918557F, -24.6F, -0.27499999999999963F, -2.8797932657906444F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_19", CubeListBuilder.create().texOffs(692, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.11363793320239F, -25.5F, -0.23749999999999966F, -2.904835108712983F, -0.11279899977786711F, -1.1343008211896466F));
        g.addOrReplaceChild("baliza_t_20", CubeListBuilder.create().texOffs(698, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.53349364905389F, -25.9F, -0.12499999999999982F, -3.054405440547142F, -0.24716962264080666F, -0.3431327851572989F));
        g.addOrReplaceChild("baliza_t_21", CubeListBuilder.create().texOffs(268, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(21.24868602791856F, -24.6F, -0.7513139720814408F, -2.356194490192344F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_22", CubeListBuilder.create().texOffs(704, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.351137933202395F, -25.5F, -0.6488620667976079F, -2.4085126422606256F, -0.31258511115331167F, -1.2417081796409166F));
        g.addOrReplaceChild("baliza_t_23", CubeListBuilder.create().texOffs(710, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.658493649053888F, -25.9F, -0.3415063509461094F, -2.826263023748341F, -0.7320894011990563F, -0.45402896241217316F));
        g.addOrReplaceChild("baliza_t_24", CubeListBuilder.create().texOffs(278, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(21.725F, -24.6F, -1.0263139720814412F, -1.8325957145940461F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_25", CubeListBuilder.create().texOffs(716, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.762500000000003F, -25.5F, -0.8863620667976082F, -1.8600156211776535F, -0.43353287058264733F, -1.4464413322481342F));
        g.addOrReplaceChild("baliza_t_26", CubeListBuilder.create().texOffs(722, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.875F, -25.9F, -0.4665063509461096F, -2.2584448857952353F, -1.150788455480417F, -0.9272952180016151F));
        g.addOrReplaceChild("baliza_t_27", CubeListBuilder.create().texOffs(288, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(22.275F, -24.6F, -1.0263139720814416F, -1.308996938995748F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_28", CubeListBuilder.create().texOffs(728, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.237499999999997F, -25.5F, -0.8863620667976085F, -1.2815770324121407F, -0.43353287058264744F, -1.6951513213416587F));
        g.addOrReplaceChild("baliza_t_29", CubeListBuilder.create().texOffs(734, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.125F, -25.9F, -0.46650635094610976F, -0.8831477677945585F, -1.150788455480417F, -2.214297435588178F));
        g.addOrReplaceChild("baliza_t_30", CubeListBuilder.create().texOffs(298, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(22.75131397208144F, -24.6F, -0.7513139720814417F, -0.7853981633974454F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_31", CubeListBuilder.create().texOffs(740, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.648862066797605F, -25.5F, -0.6488620667976087F, -0.7330800113291664F, -0.31258511115331117F, -1.899884473948875F));
        g.addOrReplaceChild("baliza_t_32", CubeListBuilder.create().texOffs(746, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.34150635094611F, -25.9F, -0.3415063509461098F, -0.3153296298414524F, -0.7320894011990569F, -2.68756369117762F));
        g.addOrReplaceChild("baliza_t_33", CubeListBuilder.create().texOffs(308, 77).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(23.02631397208144F, -24.6F, -0.27500000000000036F, -0.26179938779915446F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_34", CubeListBuilder.create().texOffs(752, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.886362066797606F, -25.5F, -0.23750000000000032F, -0.23675754487681352F, -0.11279899977786774F, -2.0072918324001443F));
        g.addOrReplaceChild("baliza_t_35", CubeListBuilder.create().texOffs(758, 82).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.46650635094611F, -25.9F, -0.12500000000000017F, -0.08718721304265126F, -0.24716962264080733F, -2.7984598684324946F));
        g.addOrReplaceChild("bocina_t_0", CubeListBuilder.create().texOffs(850, 42).addBox(13.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(710, 42).addBox(13.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -23.5F, 5.0F));
        g.addOrReplaceChild("bocina_t_1", CubeListBuilder.create().texOffs(868, 42).addBox(13.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(742, 42).addBox(13.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -23.5F, 5.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_forro", CubeListBuilder.create().texOffs(72, 67).addBox(-26.0F, -20.0F, 8.0F, 14.0F, 9.0F, 1.0F).texOffs(102, 67).addBox(-26.0F, -20.0F, -9.0F, 14.0F, 9.0F, 1.0F).texOffs(40, 42).addBox(-13.0F, -20.0F, -8.0F, 1.0F, 9.0F, 16.0F).texOffs(326, 42).addBox(-26.0F, -11.0F, -9.0F, 14.0F, 1.0F, 18.0F).texOffs(390, 42).addBox(-26.0F, -21.0F, -9.0F, 14.0F, 1.0F, 18.0F).texOffs(74, 42).addBox(-26.0F, -20.0F, -8.0F, 1.0F, 9.0F, 16.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_pupitre", CubeListBuilder.create().texOffs(132, 67).addBox(-25.0F, -14.0F, 1.0F, 4.0F, 3.0F, 7.0F).texOffs(260, 67).addBox(-25.0F, -17.0F, 1.5F, 1.0F, 3.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(952, 42).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-23.4F, -15.5F, 4.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(354, 77).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-23.279999999999998F, -15.5F, 4.5F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro0", CubeListBuilder.create().texOffs(0, 67).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-23.4F, -15.5F, 0.9000000000000004F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro0_aguja", CubeListBuilder.create().texOffs(764, 82).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.279999999999998F, -15.5F, 0.9000000000000004F, 0.4F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro1", CubeListBuilder.create().texOffs(36, 67).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-23.4F, -15.5F, 8.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro1_aguja", CubeListBuilder.create().texOffs(768, 82).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-23.279999999999998F, -15.5F, 8.1F, 1.1F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_luces", CubeListBuilder.create().texOffs(772, 82).addBox(-23.0F, -15.0F, 1.5F, 1.0F, 1.0F, 1.0F).texOffs(776, 82).addBox(-23.0F, -15.0F, 2.7F, 1.0F, 1.0F, 1.0F).texOffs(780, 82).addBox(-23.0F, -15.0F, 3.9000000000000004F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(8, 77).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F).texOffs(70, 77).addBox(-1.0F, -6.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-23.0F, -14.0F, 6.5F, 0.0F, 0.0F, 0.15F));
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(12, 77).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(-23.0F, -14.5F, 2.5F, 0.0F, 0.0F, -2.4668517113662407F));
        g.addOrReplaceChild("cab_freno_perilla", CubeListBuilder.create().texOffs(784, 82).addBox(-21.5F, -17.5F, 2.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(154, 67).addBox(-13.0F, -17.0F, 3.0F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(164, 67).addBox(-13.0F, -17.0F, -7.0F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "capo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "escape_0", 1.0F, 0.12318393766817158F, 0.12318393766817158F);
        escalar(g0, "escape_1", 1.0F, 0.12318393766817158F, 0.12318393766817158F);
        escalar(g0, "cabina_f_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "cabina_f_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "cabina_f_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "cabina_f_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "cabina_f_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "cabina_f_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "cabina_f_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "cabina_f_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "cabina_f_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "cabina_f_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "cabina_f_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_f_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "baliza_f_base_0", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_f_base_1", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_f_base_2", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_f_0", 0.39999999999999974F, 1.0F, 0.28470094961277276F);
        escalar(g0, "baliza_f_1", 0.3354101966249694F, 1.0F, 0.49175618569478946F);
        escalar(g0, "baliza_f_2", 0.31622776601683833F, 1.0F, 0.25881904510252085F);
        escalar(g0, "baliza_f_3", 0.39999999999999974F, 1.0F, 0.2847009496127733F);
        escalar(g0, "baliza_f_4", 0.3354101966249694F, 1.0F, 0.49175618569479035F);
        escalar(g0, "baliza_f_5", 0.31622776601683766F, 1.0F, 0.25881904510252035F);
        escalar(g0, "baliza_f_6", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_f_7", 0.33541019662496924F, 1.0F, 0.4917561856947891F);
        escalar(g0, "baliza_f_8", 0.3162277660168375F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_f_9", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_f_10", 0.33541019662496924F, 1.0F, 0.4917561856947891F);
        escalar(g0, "baliza_f_11", 0.31622776601683755F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_f_12", 0.39999999999999974F, 1.0F, 0.2847009496127719F);
        escalar(g0, "baliza_f_13", 0.33541019662496907F, 1.0F, 0.4917561856947889F);
        escalar(g0, "baliza_f_14", 0.31622776601683766F, 1.0F, 0.2588190451025203F);
        escalar(g0, "baliza_f_15", 0.39999999999999974F, 1.0F, 0.28470094961277337F);
        escalar(g0, "baliza_f_16", 0.33541019662496907F, 1.0F, 0.4917561856947902F);
        escalar(g0, "baliza_f_17", 0.31622776601683833F, 1.0F, 0.258819045102521F);
        escalar(g0, "baliza_f_18", 0.39999999999999974F, 1.0F, 0.28470094961277254F);
        escalar(g0, "baliza_f_19", 0.3354101966249694F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_f_20", 0.3162277660168383F, 1.0F, 0.2588190451025207F);
        escalar(g0, "baliza_f_21", 0.39999999999999974F, 1.0F, 0.2847009496127734F);
        escalar(g0, "baliza_f_22", 0.3354101966249694F, 1.0F, 0.4917561856947905F);
        escalar(g0, "baliza_f_23", 0.31622776601683755F, 1.0F, 0.25881904510252046F);
        escalar(g0, "baliza_f_24", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_f_25", 0.33541019662496924F, 1.0F, 0.4917561856947892F);
        escalar(g0, "baliza_f_26", 0.31622776601683744F, 1.0F, 0.2588190451025208F);
        escalar(g0, "baliza_f_27", 0.39999999999999974F, 1.0F, 0.28470094961277315F);
        escalar(g0, "baliza_f_28", 0.33541019662496924F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_f_29", 0.31622776601683755F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_f_30", 0.39999999999999974F, 1.0F, 0.28470094961277204F);
        escalar(g0, "baliza_f_31", 0.33541019662496907F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_f_32", 0.3162277660168377F, 1.0F, 0.25881904510252035F);
        escalar(g0, "baliza_f_33", 0.39999999999999974F, 1.0F, 0.28470094961277337F);
        escalar(g0, "baliza_f_34", 0.33541019662496907F, 1.0F, 0.4917561856947902F);
        escalar(g0, "baliza_f_35", 0.31622776601683833F, 1.0F, 0.25881904510252096F);
        escalar(g0, "bocina_f_0", 1.0F, 0.07698996104260723F, 0.07698996104260723F);
        escalar(g0, "bocina_f_1", 1.0F, 0.07698996104260723F, 0.07698996104260723F);
        escalar(g0, "cabina_t_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "cabina_t_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "cabina_t_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "cabina_t_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "cabina_t_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "cabina_t_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "cabina_t_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "cabina_t_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "cabina_t_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "cabina_t_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "cabina_t_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_t_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "baliza_t_base_0", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_t_base_1", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_t_base_2", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_t_0", 0.39999999999999974F, 1.0F, 0.28470094961277276F);
        escalar(g0, "baliza_t_1", 0.3354101966249694F, 1.0F, 0.49175618569478946F);
        escalar(g0, "baliza_t_2", 0.31622776601683833F, 1.0F, 0.25881904510252085F);
        escalar(g0, "baliza_t_3", 0.39999999999999974F, 1.0F, 0.2847009496127733F);
        escalar(g0, "baliza_t_4", 0.3354101966249694F, 1.0F, 0.49175618569479035F);
        escalar(g0, "baliza_t_5", 0.31622776601683766F, 1.0F, 0.25881904510252035F);
        escalar(g0, "baliza_t_6", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_t_7", 0.33541019662496924F, 1.0F, 0.4917561856947891F);
        escalar(g0, "baliza_t_8", 0.3162277660168375F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_t_9", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_t_10", 0.33541019662496924F, 1.0F, 0.4917561856947891F);
        escalar(g0, "baliza_t_11", 0.31622776601683755F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_t_12", 0.39999999999999974F, 1.0F, 0.2847009496127719F);
        escalar(g0, "baliza_t_13", 0.33541019662496907F, 1.0F, 0.4917561856947889F);
        escalar(g0, "baliza_t_14", 0.31622776601683766F, 1.0F, 0.2588190451025203F);
        escalar(g0, "baliza_t_15", 0.39999999999999974F, 1.0F, 0.28470094961277337F);
        escalar(g0, "baliza_t_16", 0.33541019662496907F, 1.0F, 0.4917561856947902F);
        escalar(g0, "baliza_t_17", 0.31622776601683833F, 1.0F, 0.258819045102521F);
        escalar(g0, "baliza_t_18", 0.39999999999999974F, 1.0F, 0.28470094961277254F);
        escalar(g0, "baliza_t_19", 0.3354101966249694F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_t_20", 0.3162277660168383F, 1.0F, 0.2588190451025207F);
        escalar(g0, "baliza_t_21", 0.39999999999999974F, 1.0F, 0.2847009496127734F);
        escalar(g0, "baliza_t_22", 0.3354101966249694F, 1.0F, 0.4917561856947905F);
        escalar(g0, "baliza_t_23", 0.31622776601683755F, 1.0F, 0.25881904510252046F);
        escalar(g0, "baliza_t_24", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_t_25", 0.33541019662496924F, 1.0F, 0.4917561856947892F);
        escalar(g0, "baliza_t_26", 0.31622776601683744F, 1.0F, 0.2588190451025208F);
        escalar(g0, "baliza_t_27", 0.39999999999999974F, 1.0F, 0.28470094961277315F);
        escalar(g0, "baliza_t_28", 0.33541019662496924F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_t_29", 0.31622776601683755F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_t_30", 0.39999999999999974F, 1.0F, 0.28470094961277204F);
        escalar(g0, "baliza_t_31", 0.33541019662496907F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_t_32", 0.3162277660168377F, 1.0F, 0.25881904510252035F);
        escalar(g0, "baliza_t_33", 0.39999999999999974F, 1.0F, 0.28470094961277337F);
        escalar(g0, "baliza_t_34", 0.33541019662496907F, 1.0F, 0.4917561856947902F);
        escalar(g0, "baliza_t_35", 0.31622776601683833F, 1.0F, 0.25881904510252096F);
        escalar(g0, "bocina_t_0", 1.0F, 0.07698996104260723F, 0.07698996104260723F);
        escalar(g0, "bocina_t_1", 1.0F, 0.07698996104260723F, 0.07698996104260723F);
        escalar(g0, "cab_velocimetro", 0.2333333333333333F, 0.6F, 0.2333333333333333F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.574F, 0.6F);
        escalar(g0, "cab_manometro0", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro0_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_manometro1", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro1_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_freno", 0.8F, 0.8003905296791061F, 0.8F);
    }
}
