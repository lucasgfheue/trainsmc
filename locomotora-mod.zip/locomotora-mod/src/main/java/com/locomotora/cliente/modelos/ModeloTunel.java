package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Locomotora de túnel" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloTunel {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("tunel"), "main"),
            LocomotoraMod.id("textures/entity/tunel.png"),
            List.of(
                new DatosModelo.Animada("ri0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("ri1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -12.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 12.0F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloTunel::crearCapa,
            16.0F,
            ModeloTunel::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -12.0F, 12.0F)));

    private ModeloTunel() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("ri0_0", CubeListBuilder.create().texOffs(796, 42).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(596, 67).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(842, 42).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 67).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-12.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("ri0_1", CubeListBuilder.create().texOffs(614, 67).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(850, 42).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri0_2", CubeListBuilder.create().texOffs(632, 67).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(858, 42).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ri1_0", CubeListBuilder.create().texOffs(796, 42).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(596, 67).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(842, 42).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(494, 67).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(12.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("ri1_1", CubeListBuilder.create().texOffs(614, 67).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(850, 42).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri1_2", CubeListBuilder.create().texOffs(632, 67).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(858, 42).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd0_0", CubeListBuilder.create().texOffs(796, 42).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(596, 67).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(842, 42).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 67).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-12.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rd0_1", CubeListBuilder.create().texOffs(614, 67).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(850, 42).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd0_2", CubeListBuilder.create().texOffs(632, 67).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(858, 42).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd1_0", CubeListBuilder.create().texOffs(796, 42).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(596, 67).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(842, 42).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(514, 67).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(12.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rd1_1", CubeListBuilder.create().texOffs(614, 67).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(850, 42).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd1_2", CubeListBuilder.create().texOffs(632, 67).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(858, 42).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(264, 67).addBox(-27.0F, -9.0F, 6.0F, 54.0F, 6.0F, 1.0F).texOffs(374, 67).addBox(-27.0F, -9.0F, -7.0F, 54.0F, 6.0F, 1.0F).texOffs(524, 67).addBox(-14.0F, -5.5F, 7.0F, 4.0F, 4.0F, 1.0F).texOffs(534, 67).addBox(-14.0F, -5.5F, -8.0F, 4.0F, 4.0F, 1.0F).texOffs(544, 67).addBox(10.0F, -5.5F, 7.0F, 4.0F, 4.0F, 1.0F).texOffs(554, 67).addBox(10.0F, -5.5F, -8.0F, 4.0F, 4.0F, 1.0F).texOffs(114, 42).addBox(-27.0F, -10.0F, -9.0F, 54.0F, 1.0F, 18.0F).texOffs(972, 0).addBox(-29.0F, -10.0F, -9.0F, 2.0F, 7.0F, 18.0F).texOffs(814, 42).addBox(-31.0F, -8.5F, -2.5F, 2.0F, 4.0F, 5.0F).texOffs(890, 67).addBox(-32.0F, -7.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(0, 42).addBox(27.0F, -10.0F, -9.0F, 2.0F, 7.0F, 18.0F).texOffs(828, 42).addBox(29.0F, -8.5F, -2.5F, 2.0F, 4.0F, 5.0F).texOffs(896, 67).addBox(31.0F, -7.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(40, 42).addBox(-11.0F, -16.0F, -7.5F, 22.0F, 6.0F, 15.0F).texOffs(690, 42).addBox(-11.0F, -18.0F, -5.5F, 22.0F, 2.0F, 11.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_cantoi_0", CubeListBuilder.create().texOffs(926, 67).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -16.309016994374947F, -7.451056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_1", CubeListBuilder.create().texOffs(972, 67).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -16.89680224666742F, -7.2600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_2", CubeListBuilder.create().texOffs(0, 75).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.39680224666742F, -6.89680224666742F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_3", CubeListBuilder.create().texOffs(46, 75).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.7600735106701F, -6.39680224666742F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantoi_4", CubeListBuilder.create().texOffs(92, 75).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.951056516295154F, -5.8090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_0", CubeListBuilder.create().texOffs(138, 75).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -16.309016994374947F, 7.451056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_1", CubeListBuilder.create().texOffs(184, 75).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -16.89680224666742F, 7.2600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_2", CubeListBuilder.create().texOffs(230, 75).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.39680224666742F, 6.89680224666742F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_3", CubeListBuilder.create().texOffs(276, 75).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.7600735106701F, 6.39680224666742F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_cantod_4", CubeListBuilder.create().texOffs(322, 75).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -17.951056516295154F, 5.8090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_tapaa", CubeListBuilder.create().texOffs(312, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 30.0F), PartPose.offset(-11.0F, -16.0F, -7.5F));
        g.addOrReplaceChild("capo_tapab", CubeListBuilder.create().texOffs(374, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 30.0F), PartPose.offset(10.0F, -16.0F, -7.5F));
        g.addOrReplaceChild("capo_techo", CubeListBuilder.create().texOffs(756, 42).addBox(-6.0F, -19.0F, -4.0F, 12.0F, 1.0F, 8.0F).texOffs(436, 0).addBox(-27.0F, -21.0F, -9.5F, 16.0F, 11.0F, 19.0F).texOffs(258, 42).addBox(-27.0F, -23.0F, -7.5F, 16.0F, 2.0F, 15.0F), PartPose.ZERO);
        g.addOrReplaceChild("escape_0", CubeListBuilder.create().texOffs(578, 42).addBox(4.0F, -6.0F, -2.5F, 5.0F, 12.0F, 5.0F).texOffs(382, 42).addBox(4.0F, -2.5F, -6.0F, 5.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -17.0F, -5.5F));
        g.addOrReplaceChild("escape_1", CubeListBuilder.create().texOffs(598, 42).addBox(4.0F, -6.0F, -2.5F, 5.0F, 12.0F, 5.0F).texOffs(416, 42).addBox(4.0F, -2.5F, -6.0F, 5.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -17.0F, -5.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantoi_0", CubeListBuilder.create().texOffs(368, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -21.309016994374947F, -9.451056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantoi_1", CubeListBuilder.create().texOffs(402, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -21.89680224666742F, -9.2600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantoi_2", CubeListBuilder.create().texOffs(436, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.39680224666742F, -8.89680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantoi_3", CubeListBuilder.create().texOffs(470, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.7600735106701F, -8.39680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantoi_4", CubeListBuilder.create().texOffs(504, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.951056516295154F, -7.8090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantod_0", CubeListBuilder.create().texOffs(538, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -21.309016994374947F, 9.451056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantod_1", CubeListBuilder.create().texOffs(572, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -21.89680224666742F, 9.2600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantod_2", CubeListBuilder.create().texOffs(606, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.39680224666742F, 8.89680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantod_3", CubeListBuilder.create().texOffs(640, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.7600735106701F, 8.39680224666742F, 2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_cantod_4", CubeListBuilder.create().texOffs(674, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.0F, -22.951056516295154F, 7.8090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_f_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(-27.0F, -21.0F, -9.5F));
        g.addOrReplaceChild("cabina_f_tapab", CubeListBuilder.create().texOffs(78, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(-12.0F, -21.0F, -9.5F));
        g.addOrReplaceChild("faro_fi", CubeListBuilder.create().texOffs(564, 67).addBox(-28.0F, -13.5F, -8.5F, 1.0F, 2.0F, 3.0F).texOffs(902, 67).addBox(-28.2F, -13.0F, -8.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("faro_fd", CubeListBuilder.create().texOffs(572, 67).addBox(-28.0F, -13.5F, 5.5F, 1.0F, 2.0F, 3.0F).texOffs(908, 67).addBox(-28.2F, -13.0F, 6.0F, 1.0F, 1.0F, 2.0F).texOffs(506, 0).addBox(11.0F, -21.0F, -9.5F, 16.0F, 11.0F, 19.0F).texOffs(320, 42).addBox(11.0F, -23.0F, -7.5F, 16.0F, 2.0F, 15.0F), PartPose.ZERO);
        g.addOrReplaceChild("baliza_f_base_0", CubeListBuilder.create().texOffs(866, 42).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(576, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offset(-22.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("baliza_f_base_1", CubeListBuilder.create().texOffs(932, 42).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(642, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(-22.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("baliza_f_base_2", CubeListBuilder.create().texOffs(0, 67).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(708, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(-22.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("baliza_f_0", CubeListBuilder.create().texOffs(650, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.973686027918557F, -24.6F, 0.27499999999999997F, 0.26179938779914863F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_1", CubeListBuilder.create().texOffs(34, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.11363793320239F, -25.5F, 0.2375F, 0.23675754487681036F, 0.11279899977786711F, -2.0072918324001465F));
        g.addOrReplaceChild("baliza_f_2", CubeListBuilder.create().texOffs(40, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.53349364905389F, -25.9F, 0.12499999999999999F, 0.08718721304265128F, 0.24716962264080694F, -2.7984598684324946F));
        g.addOrReplaceChild("baliza_f_3", CubeListBuilder.create().texOffs(660, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.24868602791856F, -24.6F, 0.7513139720814412F, 0.7853981633974496F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_4", CubeListBuilder.create().texOffs(46, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.351137933202395F, -25.5F, 0.6488620667976084F, 0.7330800113291681F, 0.31258511115331183F, -1.8998844739488765F));
        g.addOrReplaceChild("baliza_f_5", CubeListBuilder.create().texOffs(52, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.658493649053888F, -25.9F, 0.3415063509461096F, 0.31532962984145235F, 0.7320894011990566F, -2.68756369117762F));
        g.addOrReplaceChild("baliza_f_6", CubeListBuilder.create().texOffs(670, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.725F, -24.6F, 1.0263139720814414F, 1.3089969389957474F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_7", CubeListBuilder.create().texOffs(58, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.762500000000003F, -25.5F, 0.8863620667976084F, 1.28157703241214F, 0.4335328705826474F, -1.6951513213416587F));
        g.addOrReplaceChild("baliza_f_8", CubeListBuilder.create().texOffs(64, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.875F, -25.9F, 0.46650635094610965F, 0.8831477677945582F, 1.150788455480417F, -2.214297435588178F));
        g.addOrReplaceChild("baliza_f_9", CubeListBuilder.create().texOffs(680, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.275F, -24.6F, 1.0263139720814414F, 1.8325957145940457F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_10", CubeListBuilder.create().texOffs(70, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.237499999999997F, -25.5F, 0.8863620667976085F, 1.860015621177653F, 0.4335328705826474F, -1.4464413322481346F));
        g.addOrReplaceChild("baliza_f_11", CubeListBuilder.create().texOffs(76, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.125F, -25.9F, 0.46650635094610965F, 2.258444885795235F, 1.150788455480417F, -0.9272952180016151F));
        g.addOrReplaceChild("baliza_f_12", CubeListBuilder.create().texOffs(690, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.75131397208144F, -24.6F, 0.7513139720814415F, 2.3561944901923475F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_13", CubeListBuilder.create().texOffs(82, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.648862066797605F, -25.5F, 0.6488620667976086F, 2.4085126422606264F, 0.3125851111533111F, -1.2417081796409186F));
        g.addOrReplaceChild("baliza_f_14", CubeListBuilder.create().texOffs(88, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.34150635094611F, -25.9F, 0.34150635094610976F, 2.8262630237483406F, 0.7320894011990569F, -0.4540289624121731F));
        g.addOrReplaceChild("baliza_f_15", CubeListBuilder.create().texOffs(700, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.02631397208144F, -24.6F, 0.2750000000000003F, 2.8797932657906387F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_16", CubeListBuilder.create().texOffs(94, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.886362066797606F, -25.5F, 0.23750000000000024F, 2.90483510871298F, 0.11279899977786766F, -1.134300821189649F));
        g.addOrReplaceChild("baliza_f_17", CubeListBuilder.create().texOffs(100, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.46650635094611F, -25.9F, 0.1250000000000001F, 3.054405440547142F, 0.24716962264080725F, -0.34313278515729884F));
        g.addOrReplaceChild("baliza_f_18", CubeListBuilder.create().texOffs(710, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.026313972081443F, -24.6F, -0.27499999999999963F, -2.8797932657906444F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_19", CubeListBuilder.create().texOffs(106, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.88636206679761F, -25.5F, -0.23749999999999966F, -2.904835108712983F, -0.11279899977786711F, -1.1343008211896466F));
        g.addOrReplaceChild("baliza_f_20", CubeListBuilder.create().texOffs(112, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.46650635094611F, -25.9F, -0.12499999999999982F, -3.054405440547142F, -0.24716962264080666F, -0.3431327851572989F));
        g.addOrReplaceChild("baliza_f_21", CubeListBuilder.create().texOffs(720, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.75131397208144F, -24.6F, -0.7513139720814408F, -2.356194490192344F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_22", CubeListBuilder.create().texOffs(118, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.648862066797605F, -25.5F, -0.6488620667976079F, -2.4085126422606256F, -0.31258511115331167F, -1.2417081796409166F));
        g.addOrReplaceChild("baliza_f_23", CubeListBuilder.create().texOffs(124, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.341506350946112F, -25.9F, -0.3415063509461094F, -2.826263023748341F, -0.7320894011990563F, -0.45402896241217316F));
        g.addOrReplaceChild("baliza_f_24", CubeListBuilder.create().texOffs(730, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.275F, -24.6F, -1.0263139720814412F, -1.8325957145940461F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_25", CubeListBuilder.create().texOffs(130, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.237499999999997F, -25.5F, -0.8863620667976082F, -1.8600156211776535F, -0.43353287058264733F, -1.4464413322481342F));
        g.addOrReplaceChild("baliza_f_26", CubeListBuilder.create().texOffs(136, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-22.125F, -25.9F, -0.4665063509461096F, -2.2584448857952353F, -1.150788455480417F, -0.9272952180016151F));
        g.addOrReplaceChild("baliza_f_27", CubeListBuilder.create().texOffs(740, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.725F, -24.6F, -1.0263139720814416F, -1.308996938995748F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_28", CubeListBuilder.create().texOffs(142, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.762500000000003F, -25.5F, -0.8863620667976085F, -1.2815770324121407F, -0.43353287058264744F, -1.6951513213416587F));
        g.addOrReplaceChild("baliza_f_29", CubeListBuilder.create().texOffs(148, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.875F, -25.9F, -0.46650635094610976F, -0.8831477677945585F, -1.150788455480417F, -2.214297435588178F));
        g.addOrReplaceChild("baliza_f_30", CubeListBuilder.create().texOffs(750, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.24868602791856F, -24.6F, -0.7513139720814417F, -0.7853981633974454F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_31", CubeListBuilder.create().texOffs(154, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.351137933202395F, -25.5F, -0.6488620667976087F, -0.7330800113291664F, -0.31258511115331117F, -1.899884473948875F));
        g.addOrReplaceChild("baliza_f_32", CubeListBuilder.create().texOffs(160, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.65849364905389F, -25.9F, -0.3415063509461098F, -0.3153296298414524F, -0.7320894011990569F, -2.68756369117762F));
        g.addOrReplaceChild("baliza_f_33", CubeListBuilder.create().texOffs(760, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.97368602791856F, -24.6F, -0.27500000000000036F, -0.26179938779915446F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_f_34", CubeListBuilder.create().texOffs(166, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.113637933202394F, -25.5F, -0.23750000000000032F, -0.23675754487681352F, -0.11279899977786774F, -2.0072918324001443F));
        g.addOrReplaceChild("baliza_f_35", CubeListBuilder.create().texOffs(172, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.53349364905389F, -25.9F, -0.12500000000000017F, -0.08718721304265126F, -0.24716962264080733F, -2.7984598684324946F));
        g.addOrReplaceChild("bocina_f_0", CubeListBuilder.create().texOffs(618, 42).addBox(-17.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(450, 42).addBox(-17.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -23.5F, 5.0F));
        g.addOrReplaceChild("bocina_f_1", CubeListBuilder.create().texOffs(636, 42).addBox(-17.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(482, 42).addBox(-17.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -23.5F, 5.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantoi_0", CubeListBuilder.create().texOffs(708, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -21.309016994374947F, -9.451056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantoi_1", CubeListBuilder.create().texOffs(742, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -21.89680224666742F, -9.2600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantoi_2", CubeListBuilder.create().texOffs(776, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.39680224666742F, -8.89680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantoi_3", CubeListBuilder.create().texOffs(810, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.7600735106701F, -8.39680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantoi_4", CubeListBuilder.create().texOffs(844, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.951056516295154F, -7.8090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantod_0", CubeListBuilder.create().texOffs(878, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -21.309016994374947F, 9.451056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantod_1", CubeListBuilder.create().texOffs(912, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -21.89680224666742F, 9.2600735106701F, 2.042035224833364F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("cabina_t_cantod_2", CubeListBuilder.create().texOffs(946, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.39680224666742F, 8.89680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantod_3", CubeListBuilder.create().texOffs(980, 75).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.7600735106701F, 8.39680224666742F, 2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_cantod_4", CubeListBuilder.create().texOffs(0, 77).addBox(-8.0F, -1.0F, -0.5F, 16.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -22.951056516295154F, 7.8090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_t_tapaa", CubeListBuilder.create().texOffs(156, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(11.0F, -21.0F, -9.5F));
        g.addOrReplaceChild("cabina_t_tapab", CubeListBuilder.create().texOffs(234, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(26.0F, -21.0F, -9.5F));
        g.addOrReplaceChild("faro_ti", CubeListBuilder.create().texOffs(580, 67).addBox(27.0F, -13.5F, -8.5F, 1.0F, 2.0F, 3.0F).texOffs(914, 67).addBox(27.2F, -13.0F, -8.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("faro_td", CubeListBuilder.create().texOffs(588, 67).addBox(27.0F, -13.5F, 5.5F, 1.0F, 2.0F, 3.0F).texOffs(920, 67).addBox(27.2F, -13.0F, 6.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("baliza_t_base_0", CubeListBuilder.create().texOffs(66, 67).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(774, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offset(22.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("baliza_t_base_1", CubeListBuilder.create().texOffs(132, 67).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(840, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(22.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("baliza_t_base_2", CubeListBuilder.create().texOffs(198, 67).addBox(-13.0F, -24.0F, -3.5F, 26.0F, 1.0F, 7.0F).texOffs(906, 0).addBox(-3.5F, -24.0F, -13.0F, 7.0F, 1.0F, 26.0F), PartPose.offsetAndRotation(22.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("baliza_t_0", CubeListBuilder.create().texOffs(770, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(23.026313972081443F, -24.6F, 0.27499999999999997F, 0.26179938779914863F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_1", CubeListBuilder.create().texOffs(178, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.88636206679761F, -25.5F, 0.2375F, 0.23675754487681036F, 0.11279899977786711F, -2.0072918324001465F));
        g.addOrReplaceChild("baliza_t_2", CubeListBuilder.create().texOffs(184, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.46650635094611F, -25.9F, 0.12499999999999999F, 0.08718721304265128F, 0.24716962264080694F, -2.7984598684324946F));
        g.addOrReplaceChild("baliza_t_3", CubeListBuilder.create().texOffs(780, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(22.75131397208144F, -24.6F, 0.7513139720814412F, 0.7853981633974496F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_4", CubeListBuilder.create().texOffs(190, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.648862066797605F, -25.5F, 0.6488620667976084F, 0.7330800113291681F, 0.31258511115331183F, -1.8998844739488765F));
        g.addOrReplaceChild("baliza_t_5", CubeListBuilder.create().texOffs(196, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.341506350946112F, -25.9F, 0.3415063509461096F, 0.31532962984145235F, 0.7320894011990566F, -2.68756369117762F));
        g.addOrReplaceChild("baliza_t_6", CubeListBuilder.create().texOffs(790, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(22.275F, -24.6F, 1.0263139720814414F, 1.3089969389957474F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_7", CubeListBuilder.create().texOffs(202, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.237499999999997F, -25.5F, 0.8863620667976084F, 1.28157703241214F, 0.4335328705826474F, -1.6951513213416587F));
        g.addOrReplaceChild("baliza_t_8", CubeListBuilder.create().texOffs(208, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.125F, -25.9F, 0.46650635094610965F, 0.8831477677945582F, 1.150788455480417F, -2.214297435588178F));
        g.addOrReplaceChild("baliza_t_9", CubeListBuilder.create().texOffs(800, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(21.725F, -24.6F, 1.0263139720814414F, 1.8325957145940457F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_10", CubeListBuilder.create().texOffs(214, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.762500000000003F, -25.5F, 0.8863620667976085F, 1.860015621177653F, 0.4335328705826474F, -1.4464413322481346F));
        g.addOrReplaceChild("baliza_t_11", CubeListBuilder.create().texOffs(220, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.875F, -25.9F, 0.46650635094610965F, 2.258444885795235F, 1.150788455480417F, -0.9272952180016151F));
        g.addOrReplaceChild("baliza_t_12", CubeListBuilder.create().texOffs(810, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(21.24868602791856F, -24.6F, 0.7513139720814415F, 2.3561944901923475F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_13", CubeListBuilder.create().texOffs(226, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.351137933202395F, -25.5F, 0.6488620667976086F, 2.4085126422606264F, 0.3125851111533111F, -1.2417081796409186F));
        g.addOrReplaceChild("baliza_t_14", CubeListBuilder.create().texOffs(232, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.65849364905389F, -25.9F, 0.34150635094610976F, 2.8262630237483406F, 0.7320894011990569F, -0.4540289624121731F));
        g.addOrReplaceChild("baliza_t_15", CubeListBuilder.create().texOffs(820, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.97368602791856F, -24.6F, 0.2750000000000003F, 2.8797932657906387F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_16", CubeListBuilder.create().texOffs(238, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.113637933202394F, -25.5F, 0.23750000000000024F, 2.90483510871298F, 0.11279899977786766F, -1.134300821189649F));
        g.addOrReplaceChild("baliza_t_17", CubeListBuilder.create().texOffs(244, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.53349364905389F, -25.9F, 0.1250000000000001F, 3.054405440547142F, 0.24716962264080725F, -0.34313278515729884F));
        g.addOrReplaceChild("baliza_t_18", CubeListBuilder.create().texOffs(830, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.973686027918557F, -24.6F, -0.27499999999999963F, -2.8797932657906444F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_19", CubeListBuilder.create().texOffs(250, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.11363793320239F, -25.5F, -0.23749999999999966F, -2.904835108712983F, -0.11279899977786711F, -1.1343008211896466F));
        g.addOrReplaceChild("baliza_t_20", CubeListBuilder.create().texOffs(256, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.53349364905389F, -25.9F, -0.12499999999999982F, -3.054405440547142F, -0.24716962264080666F, -0.3431327851572989F));
        g.addOrReplaceChild("baliza_t_21", CubeListBuilder.create().texOffs(840, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(21.24868602791856F, -24.6F, -0.7513139720814408F, -2.356194490192344F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_22", CubeListBuilder.create().texOffs(262, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.351137933202395F, -25.5F, -0.6488620667976079F, -2.4085126422606256F, -0.31258511115331167F, -1.2417081796409166F));
        g.addOrReplaceChild("baliza_t_23", CubeListBuilder.create().texOffs(268, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.658493649053888F, -25.9F, -0.3415063509461094F, -2.826263023748341F, -0.7320894011990563F, -0.45402896241217316F));
        g.addOrReplaceChild("baliza_t_24", CubeListBuilder.create().texOffs(850, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(21.725F, -24.6F, -1.0263139720814412F, -1.8325957145940461F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_25", CubeListBuilder.create().texOffs(274, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.762500000000003F, -25.5F, -0.8863620667976082F, -1.8600156211776535F, -0.43353287058264733F, -1.4464413322481342F));
        g.addOrReplaceChild("baliza_t_26", CubeListBuilder.create().texOffs(280, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(21.875F, -25.9F, -0.4665063509461096F, -2.2584448857952353F, -1.150788455480417F, -0.9272952180016151F));
        g.addOrReplaceChild("baliza_t_27", CubeListBuilder.create().texOffs(860, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(22.275F, -24.6F, -1.0263139720814416F, -1.308996938995748F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_28", CubeListBuilder.create().texOffs(286, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.237499999999997F, -25.5F, -0.8863620667976085F, -1.2815770324121407F, -0.43353287058264744F, -1.6951513213416587F));
        g.addOrReplaceChild("baliza_t_29", CubeListBuilder.create().texOffs(292, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.125F, -25.9F, -0.46650635094610976F, -0.8831477677945585F, -1.150788455480417F, -2.214297435588178F));
        g.addOrReplaceChild("baliza_t_30", CubeListBuilder.create().texOffs(870, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(22.75131397208144F, -24.6F, -0.7513139720814417F, -0.7853981633974454F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_31", CubeListBuilder.create().texOffs(298, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.648862066797605F, -25.5F, -0.6488620667976087F, -0.7330800113291664F, -0.31258511115331117F, -1.899884473948875F));
        g.addOrReplaceChild("baliza_t_32", CubeListBuilder.create().texOffs(304, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.34150635094611F, -25.9F, -0.3415063509461098F, -0.3153296298414524F, -0.7320894011990569F, -2.68756369117762F));
        g.addOrReplaceChild("baliza_t_33", CubeListBuilder.create().texOffs(880, 67).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(23.02631397208144F, -24.6F, -0.27500000000000036F, -0.26179938779915446F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("baliza_t_34", CubeListBuilder.create().texOffs(310, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.886362066797606F, -25.5F, -0.23750000000000032F, -0.23675754487681352F, -0.11279899977786774F, -2.0072918324001443F));
        g.addOrReplaceChild("baliza_t_35", CubeListBuilder.create().texOffs(316, 77).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(22.46650635094611F, -25.9F, -0.12500000000000017F, -0.08718721304265126F, -0.24716962264080733F, -2.7984598684324946F));
        g.addOrReplaceChild("bocina_t_0", CubeListBuilder.create().texOffs(654, 42).addBox(13.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(514, 42).addBox(13.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -23.5F, 5.0F));
        g.addOrReplaceChild("bocina_t_1", CubeListBuilder.create().texOffs(672, 42).addBox(13.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(546, 42).addBox(13.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -23.5F, 5.0F, 0.7853981633974483F, 0.0F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "capo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g0, "capo_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "escape_0", 1.0F, 0.12318393766817158F, 0.12318393766817158F);
        escalar(g0, "escape_1", 1.0F, 0.12318393766817158F, 0.12318393766817158F);
        escalar(g0, "cabina_f_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "cabina_f_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "cabina_f_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "cabina_f_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "cabina_f_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "cabina_f_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "cabina_f_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "cabina_f_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "cabina_f_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "cabina_f_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "cabina_f_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_f_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "baliza_f_base_0", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_f_base_1", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_f_base_2", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_f_0", 0.39999999999999974F, 1.0F, 0.28470094961277276F);
        escalar(g0, "baliza_f_1", 0.3354101966249694F, 1.0F, 0.49175618569478946F);
        escalar(g0, "baliza_f_2", 0.31622776601683833F, 1.0F, 0.25881904510252085F);
        escalar(g0, "baliza_f_3", 0.39999999999999974F, 1.0F, 0.2847009496127733F);
        escalar(g0, "baliza_f_4", 0.3354101966249694F, 1.0F, 0.49175618569479035F);
        escalar(g0, "baliza_f_5", 0.31622776601683766F, 1.0F, 0.25881904510252035F);
        escalar(g0, "baliza_f_6", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_f_7", 0.33541019662496924F, 1.0F, 0.4917561856947891F);
        escalar(g0, "baliza_f_8", 0.3162277660168375F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_f_9", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_f_10", 0.33541019662496924F, 1.0F, 0.4917561856947891F);
        escalar(g0, "baliza_f_11", 0.31622776601683755F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_f_12", 0.39999999999999974F, 1.0F, 0.2847009496127719F);
        escalar(g0, "baliza_f_13", 0.33541019662496907F, 1.0F, 0.4917561856947889F);
        escalar(g0, "baliza_f_14", 0.31622776601683766F, 1.0F, 0.2588190451025203F);
        escalar(g0, "baliza_f_15", 0.39999999999999974F, 1.0F, 0.28470094961277337F);
        escalar(g0, "baliza_f_16", 0.33541019662496907F, 1.0F, 0.4917561856947902F);
        escalar(g0, "baliza_f_17", 0.31622776601683833F, 1.0F, 0.258819045102521F);
        escalar(g0, "baliza_f_18", 0.39999999999999974F, 1.0F, 0.28470094961277254F);
        escalar(g0, "baliza_f_19", 0.3354101966249694F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_f_20", 0.3162277660168383F, 1.0F, 0.2588190451025207F);
        escalar(g0, "baliza_f_21", 0.39999999999999974F, 1.0F, 0.2847009496127734F);
        escalar(g0, "baliza_f_22", 0.3354101966249694F, 1.0F, 0.4917561856947905F);
        escalar(g0, "baliza_f_23", 0.31622776601683755F, 1.0F, 0.25881904510252046F);
        escalar(g0, "baliza_f_24", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_f_25", 0.33541019662496924F, 1.0F, 0.4917561856947892F);
        escalar(g0, "baliza_f_26", 0.31622776601683744F, 1.0F, 0.2588190451025208F);
        escalar(g0, "baliza_f_27", 0.39999999999999974F, 1.0F, 0.28470094961277315F);
        escalar(g0, "baliza_f_28", 0.33541019662496924F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_f_29", 0.31622776601683755F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_f_30", 0.39999999999999974F, 1.0F, 0.28470094961277204F);
        escalar(g0, "baliza_f_31", 0.33541019662496907F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_f_32", 0.3162277660168377F, 1.0F, 0.25881904510252035F);
        escalar(g0, "baliza_f_33", 0.39999999999999974F, 1.0F, 0.28470094961277337F);
        escalar(g0, "baliza_f_34", 0.33541019662496907F, 1.0F, 0.4917561856947902F);
        escalar(g0, "baliza_f_35", 0.31622776601683833F, 1.0F, 0.25881904510252096F);
        escalar(g0, "bocina_f_0", 1.0F, 0.07698996104260723F, 0.07698996104260723F);
        escalar(g0, "bocina_f_1", 1.0F, 0.07698996104260723F, 0.07698996104260723F);
        escalar(g0, "cabina_t_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "cabina_t_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "cabina_t_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "cabina_t_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "cabina_t_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "cabina_t_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "cabina_t_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "cabina_t_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "cabina_t_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "cabina_t_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "cabina_t_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "cabina_t_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "baliza_t_base_0", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_t_base_1", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_t_base_2", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "baliza_t_0", 0.39999999999999974F, 1.0F, 0.28470094961277276F);
        escalar(g0, "baliza_t_1", 0.3354101966249694F, 1.0F, 0.49175618569478946F);
        escalar(g0, "baliza_t_2", 0.31622776601683833F, 1.0F, 0.25881904510252085F);
        escalar(g0, "baliza_t_3", 0.39999999999999974F, 1.0F, 0.2847009496127733F);
        escalar(g0, "baliza_t_4", 0.3354101966249694F, 1.0F, 0.49175618569479035F);
        escalar(g0, "baliza_t_5", 0.31622776601683766F, 1.0F, 0.25881904510252035F);
        escalar(g0, "baliza_t_6", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_t_7", 0.33541019662496924F, 1.0F, 0.4917561856947891F);
        escalar(g0, "baliza_t_8", 0.3162277660168375F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_t_9", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_t_10", 0.33541019662496924F, 1.0F, 0.4917561856947891F);
        escalar(g0, "baliza_t_11", 0.31622776601683755F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_t_12", 0.39999999999999974F, 1.0F, 0.2847009496127719F);
        escalar(g0, "baliza_t_13", 0.33541019662496907F, 1.0F, 0.4917561856947889F);
        escalar(g0, "baliza_t_14", 0.31622776601683766F, 1.0F, 0.2588190451025203F);
        escalar(g0, "baliza_t_15", 0.39999999999999974F, 1.0F, 0.28470094961277337F);
        escalar(g0, "baliza_t_16", 0.33541019662496907F, 1.0F, 0.4917561856947902F);
        escalar(g0, "baliza_t_17", 0.31622776601683833F, 1.0F, 0.258819045102521F);
        escalar(g0, "baliza_t_18", 0.39999999999999974F, 1.0F, 0.28470094961277254F);
        escalar(g0, "baliza_t_19", 0.3354101966249694F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_t_20", 0.3162277660168383F, 1.0F, 0.2588190451025207F);
        escalar(g0, "baliza_t_21", 0.39999999999999974F, 1.0F, 0.2847009496127734F);
        escalar(g0, "baliza_t_22", 0.3354101966249694F, 1.0F, 0.4917561856947905F);
        escalar(g0, "baliza_t_23", 0.31622776601683755F, 1.0F, 0.25881904510252046F);
        escalar(g0, "baliza_t_24", 0.39999999999999974F, 1.0F, 0.2847009496127732F);
        escalar(g0, "baliza_t_25", 0.33541019662496924F, 1.0F, 0.4917561856947892F);
        escalar(g0, "baliza_t_26", 0.31622776601683744F, 1.0F, 0.2588190451025208F);
        escalar(g0, "baliza_t_27", 0.39999999999999974F, 1.0F, 0.28470094961277315F);
        escalar(g0, "baliza_t_28", 0.33541019662496924F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_t_29", 0.31622776601683755F, 1.0F, 0.25881904510252074F);
        escalar(g0, "baliza_t_30", 0.39999999999999974F, 1.0F, 0.28470094961277204F);
        escalar(g0, "baliza_t_31", 0.33541019662496907F, 1.0F, 0.49175618569478907F);
        escalar(g0, "baliza_t_32", 0.3162277660168377F, 1.0F, 0.25881904510252035F);
        escalar(g0, "baliza_t_33", 0.39999999999999974F, 1.0F, 0.28470094961277337F);
        escalar(g0, "baliza_t_34", 0.33541019662496907F, 1.0F, 0.4917561856947902F);
        escalar(g0, "baliza_t_35", 0.31622776601683833F, 1.0F, 0.25881904510252096F);
        escalar(g0, "bocina_t_0", 1.0F, 0.07698996104260723F, 0.07698996104260723F);
        escalar(g0, "bocina_t_1", 1.0F, 0.07698996104260723F, 0.07698996104260723F);
    }
}
