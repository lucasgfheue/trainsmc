package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "ALCO RS-3 abandonada" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloRS3Abandonada {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("rs3_abandonada"), "main"),
            LocomotoraMod.id("textures/entity/rs3_abandonada.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -57.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -57.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -57.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -39.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -39.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -39.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -57.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -57.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -57.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -39.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -39.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -39.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 41.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 41.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 41.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 59.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 59.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 59.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 41.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 41.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 41.0F, -4.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 59.0F, -4.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 59.0F, -4.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 59.0F, -4.5F, 1.0471975511965976F, "cuerpo")),
            ModeloRS3Abandonada::crearCapa,
            16.0F,
            ModeloRS3Abandonada::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -48.0F, 50.0F)));

    private ModeloRS3Abandonada() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(112, 258).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(0, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(170, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(878, 258).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-57.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(22, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(178, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-57.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(44, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-57.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(112, 258).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(0, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(170, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(888, 258).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-39.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(22, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(178, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-39.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(44, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-39.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(112, 258).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(0, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(170, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(898, 258).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-57.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(22, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(178, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-57.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(44, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-57.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(112, 258).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(0, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(170, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(908, 258).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-39.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(22, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(178, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-39.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(44, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-39.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(72, 238).addBox(-126.0F, -18.0F, 14.0F, 60.0F, 12.0F, 2.0F).texOffs(196, 238).addBox(-126.0F, -18.0F, -16.0F, 60.0F, 12.0F, 2.0F).texOffs(590, 258).addBox(-118.0F, -13.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(610, 258).addBox(-118.0F, -13.0F, -18.0F, 8.0F, 8.0F, 2.0F).texOffs(630, 258).addBox(-82.0F, -13.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(650, 258).addBox(-82.0F, -13.0F, -18.0F, 8.0F, 8.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(112, 258).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(0, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(170, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(918, 258).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(41.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(22, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(178, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(44, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(112, 258).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(0, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(170, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(928, 258).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(59.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(22, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(178, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(59.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(44, 278).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 258).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(59.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(112, 258).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(0, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(170, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 258).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(41.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(22, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(178, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(44, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(41.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(112, 258).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(0, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(170, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(948, 258).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(59.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(22, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(178, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(59.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(44, 278).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 258).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(59.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(320, 238).addBox(70.0F, -18.0F, 14.0F, 60.0F, 12.0F, 2.0F).texOffs(444, 238).addBox(70.0F, -18.0F, -16.0F, 60.0F, 12.0F, 2.0F).texOffs(670, 258).addBox(78.0F, -13.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(690, 258).addBox(78.0F, -13.0F, -18.0F, 8.0F, 8.0F, 2.0F).texOffs(710, 258).addBox(114.0F, -13.0F, 16.0F, 8.0F, 8.0F, 2.0F).texOffs(730, 258).addBox(114.0F, -13.0F, -18.0F, 8.0F, 8.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(0, 88).addBox(-156.0F, -30.0F, -26.0F, 312.0F, 8.0F, 52.0F).texOffs(104, 148).addBox(-48.0F, -22.0F, -20.0F, 100.0F, 14.0F, 40.0F).texOffs(700, 238).addBox(-166.0F, -22.0F, -3.0F, 10.0F, 6.0F, 6.0F).texOffs(848, 88).addBox(-156.0F, -22.0F, -24.0F, 4.0F, 12.0F, 48.0F).texOffs(732, 238).addBox(156.0F, -22.0F, -3.0F, 10.0F, 6.0F, 6.0F).texOffs(0, 148).addBox(152.0F, -22.0F, -24.0F, 4.0F, 12.0F, 48.0F), PartPose.ZERO);
        g.addOrReplaceChild("barandas", CubeListBuilder.create().texOffs(648, 274).addBox(-148.0F, -50.0F, 24.0F, 20.0F, 2.0F, 2.0F).texOffs(692, 274).addBox(-148.0F, -50.0F, -26.0F, 20.0F, 2.0F, 2.0F).texOffs(0, 270).addBox(-76.0F, -50.0F, 24.0F, 224.0F, 2.0F, 2.0F).texOffs(452, 270).addBox(-76.0F, -50.0F, -26.0F, 224.0F, 2.0F, 2.0F).texOffs(984, 208).addBox(-148.0F, -48.0F, 24.0F, 2.0F, 18.0F, 2.0F).texOffs(992, 208).addBox(-148.0F, -48.0F, -26.0F, 2.0F, 18.0F, 2.0F).texOffs(1000, 208).addBox(-130.0F, -48.0F, 24.0F, 2.0F, 18.0F, 2.0F).texOffs(1008, 208).addBox(-130.0F, -48.0F, -26.0F, 2.0F, 18.0F, 2.0F).texOffs(1016, 208).addBox(-76.0F, -48.0F, 24.0F, 2.0F, 18.0F, 2.0F).texOffs(0, 238).addBox(-76.0F, -48.0F, -26.0F, 2.0F, 18.0F, 2.0F).texOffs(8, 238).addBox(-12.0F, -48.0F, 24.0F, 2.0F, 18.0F, 2.0F).texOffs(16, 238).addBox(-12.0F, -48.0F, -26.0F, 2.0F, 18.0F, 2.0F).texOffs(24, 238).addBox(52.0F, -48.0F, 24.0F, 2.0F, 18.0F, 2.0F).texOffs(32, 238).addBox(52.0F, -48.0F, -26.0F, 2.0F, 18.0F, 2.0F).texOffs(40, 238).addBox(112.0F, -48.0F, 24.0F, 2.0F, 18.0F, 2.0F).texOffs(48, 238).addBox(112.0F, -48.0F, -26.0F, 2.0F, 18.0F, 2.0F).texOffs(56, 238).addBox(146.0F, -48.0F, 24.0F, 2.0F, 18.0F, 2.0F).texOffs(64, 238).addBox(146.0F, -48.0F, -26.0F, 2.0F, 18.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("baranda_caida", CubeListBuilder.create().texOffs(904, 270).addBox(40.0F, -28.0F, 26.0F, 48.0F, 2.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_corto", CubeListBuilder.create().texOffs(728, 88).addBox(-148.0F, -54.0F, -18.0F, 24.0F, 24.0F, 36.0F).texOffs(896, 208).addBox(-148.0F, -62.0F, -10.0F, 24.0F, 8.0F, 20.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_corto_cantoi_0", CubeListBuilder.create().texOffs(464, 285).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-68.0F, -27.618033988749893F, -8.902113032590307F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_1", CubeListBuilder.create().texOffs(492, 285).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-68.0F, -28.79360449333484F, -8.520147021340202F, -2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_2", CubeListBuilder.create().texOffs(520, 285).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-68.0F, -29.79360449333484F, -7.793604493334842F, -2.356194490192346F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_3", CubeListBuilder.create().texOffs(548, 285).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-68.0F, -30.5201470213402F, -6.793604493334841F, -2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_4", CubeListBuilder.create().texOffs(576, 285).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-68.0F, -30.902113032590307F, -5.618033988749895F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_0", CubeListBuilder.create().texOffs(604, 285).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-68.0F, -27.618033988749893F, 8.902113032590307F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_1", CubeListBuilder.create().texOffs(632, 285).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-68.0F, -28.79360449333484F, 8.520147021340202F, 2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_2", CubeListBuilder.create().texOffs(660, 285).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-68.0F, -29.79360449333484F, 7.793604493334842F, 2.356194490192346F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_3", CubeListBuilder.create().texOffs(688, 285).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-68.0F, -30.5201470213402F, 6.793604493334841F, 2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_4", CubeListBuilder.create().texOffs(716, 285).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-68.0F, -30.902113032590307F, 5.618033988749895F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_tapaa", CubeListBuilder.create().texOffs(540, 148).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 36.0F), PartPose.offset(-74.0F, -27.0F, -9.0F));
        g.addOrReplaceChild("capo_corto_tapab", CubeListBuilder.create().texOffs(614, 148).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 36.0F), PartPose.offset(-63.0F, -27.0F, -9.0F));
        g.addOrReplaceChild("faro_0", CubeListBuilder.create().texOffs(736, 274).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(796, 238).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-68.0F, -31.4F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("faro_1", CubeListBuilder.create().texOffs(760, 274).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(820, 238).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-68.0F, -31.4F, 0.0F, 0.0F, 0.39269908169872414F, 3.141592653589793F));
        g.addOrReplaceChild("faro_2", CubeListBuilder.create().texOffs(784, 274).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(844, 238).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-68.0F, -31.4F, 0.0F, 0.0F, 0.7853981633974482F, 3.141592653589793F));
        g.addOrReplaceChild("faro_3", CubeListBuilder.create().texOffs(808, 274).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(868, 238).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-68.0F, -31.4F, 0.0F, 0.0F, 1.1780972450961724F, 3.141592653589793F));
        g.addOrReplaceChild("faro_vidrio", CubeListBuilder.create().texOffs(612, 238).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-68.0F, -32.22F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("faro_caja", CubeListBuilder.create().texOffs(764, 238).addBox(-140.0F, -64.0F, -4.0F, 8.0F, 4.0F, 8.0F), PartPose.ZERO);
        g.addOrReplaceChild("faro_frente_0", CubeListBuilder.create().texOffs(832, 274).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(892, 238).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.3F, -26.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_frente_1", CubeListBuilder.create().texOffs(856, 274).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(916, 238).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.3F, -26.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_frente_2", CubeListBuilder.create().texOffs(880, 274).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(940, 238).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.3F, -26.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_frente_3", CubeListBuilder.create().texOffs(904, 274).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(964, 238).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-74.3F, -26.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_frente_vidrio", CubeListBuilder.create().texOffs(656, 238).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-74.92F, -26.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(0, 0).addBox(-124.0F, -70.0F, -24.0F, 44.0F, 40.0F, 48.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(0, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -34.49927091301129F, -11.51615384404144F, -2.7173867122803745F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(54, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -35.31080529218622F, -9.517149853366792F, -2.7945150652457276F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(108, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -35.965899979783764F, -7.461558465566805F, -2.8716434182110686F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(162, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -36.46065989126571F, -5.361601886657044F, -2.9487717711764225F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(216, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -36.79214326612349F, -3.2297661107331788F, -3.0259001241417716F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(270, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -36.95837915909906F, -1.0787266803175881F, -3.1030284771071184F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(324, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -36.95837915909906F, 1.0787266803175866F, 3.1030284771071184F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(378, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -36.79214326612349F, 3.229766110733176F, 3.0259001241417716F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(432, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -36.46065989126571F, 5.361601886657043F, 2.9487717711764225F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(486, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -35.965899979783764F, 7.461558465566805F, 2.8716434182110686F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(540, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -35.31080529218622F, 9.517149853366792F, 2.7945150652457276F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(594, 274).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-51.0F, -34.49927091301129F, 11.51615384404144F, 2.7173867122803745F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo", CubeListBuilder.create().texOffs(184, 0).addBox(-80.0F, -54.0F, -19.0F, 228.0F, 24.0F, 38.0F).texOffs(0, 208).addBox(-80.0F, -62.0F, -11.0F, 228.0F, 8.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_largo_cantoi_0", CubeListBuilder.create().texOffs(66, 278).addBox(-57.0F, -1.0F, -1.0F, 114.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.0F, -27.618033988749893F, -9.402113032590307F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_1", CubeListBuilder.create().texOffs(298, 278).addBox(-57.0F, -1.0F, -1.0F, 114.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.0F, -28.79360449333484F, -9.020147021340202F, -2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_2", CubeListBuilder.create().texOffs(530, 278).addBox(-57.0F, -1.0F, -1.0F, 114.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.0F, -29.79360449333484F, -8.29360449333484F, -2.356194490192346F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_3", CubeListBuilder.create().texOffs(762, 278).addBox(-57.0F, -1.0F, -1.0F, 114.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.0F, -30.5201470213402F, -7.293604493334841F, -2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_4", CubeListBuilder.create().texOffs(0, 282).addBox(-57.0F, -1.0F, -1.0F, 114.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.0F, -30.902113032590307F, -6.118033988749895F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_0", CubeListBuilder.create().texOffs(232, 282).addBox(-57.0F, -1.0F, -1.0F, 114.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.0F, -27.618033988749893F, 9.402113032590307F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_1", CubeListBuilder.create().texOffs(464, 282).addBox(-57.0F, -1.0F, -1.0F, 114.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.0F, -28.79360449333484F, 9.020147021340202F, 2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_2", CubeListBuilder.create().texOffs(696, 282).addBox(-57.0F, -1.0F, -1.0F, 114.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.0F, -29.79360449333484F, 8.29360449333484F, 2.356194490192346F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_3", CubeListBuilder.create().texOffs(0, 285).addBox(-57.0F, -1.0F, -1.0F, 114.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.0F, -30.5201470213402F, 7.293604493334841F, 2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_4", CubeListBuilder.create().texOffs(232, 285).addBox(-57.0F, -1.0F, -1.0F, 114.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.0F, -30.902113032590307F, 6.118033988749895F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_tapaa", CubeListBuilder.create().texOffs(384, 148).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 38.0F), PartPose.offset(-40.0F, -27.0F, -9.5F));
        g.addOrReplaceChild("capo_largo_tapab", CubeListBuilder.create().texOffs(462, 148).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 38.0F), PartPose.offset(73.0F, -27.0F, -9.5F));
        g.addOrReplaceChild("escape24_0", CubeListBuilder.create().texOffs(194, 258).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(500, 208).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offset(-24.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("escape24_1", CubeListBuilder.create().texOffs(260, 258).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(566, 208).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offsetAndRotation(-24.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("escape24_2", CubeListBuilder.create().texOffs(326, 258).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(632, 208).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offsetAndRotation(-24.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("escape14_0", CubeListBuilder.create().texOffs(392, 258).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(698, 208).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offset(-14.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("escape14_1", CubeListBuilder.create().texOffs(458, 258).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(764, 208).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offsetAndRotation(-14.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("escape14_2", CubeListBuilder.create().texOffs(524, 258).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(830, 208).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offsetAndRotation(-14.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("faro_t_0", CubeListBuilder.create().texOffs(928, 274).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(988, 238).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.3F, -26.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_1", CubeListBuilder.create().texOffs(952, 274).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(0, 258).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.3F, -26.0F, 0.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_2", CubeListBuilder.create().texOffs(976, 274).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(24, 258).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.3F, -26.0F, 0.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_3", CubeListBuilder.create().texOffs(1000, 274).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(48, 258).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(74.3F, -26.0F, 0.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_vidrio", CubeListBuilder.create().texOffs(72, 258).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(74.82F, -26.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("pasto0_0", CubeListBuilder.create().texOffs(134, 258).addBox(-4.0F, -10.0F, -0.5F, 8.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-70.0F, -15.0F, 11.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto0_1", CubeListBuilder.create().texOffs(152, 258).addBox(-4.0F, -10.0F, -0.5F, 8.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-70.0F, -15.0F, 11.5F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto1_0", CubeListBuilder.create().texOffs(750, 258).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-30.0F, -15.0F, -11.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto1_1", CubeListBuilder.create().texOffs(768, 258).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-30.0F, -15.0F, -11.0F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto2_0", CubeListBuilder.create().texOffs(568, 238).addBox(-5.0F, -12.0F, -0.5F, 10.0F, 12.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -15.0F, 11.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto2_1", CubeListBuilder.create().texOffs(590, 238).addBox(-5.0F, -12.0F, -0.5F, 10.0F, 12.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -15.0F, 11.0F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto3_0", CubeListBuilder.create().texOffs(822, 258).addBox(-3.0F, -8.0F, -0.5F, 6.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(64.0F, -15.0F, -11.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto3_1", CubeListBuilder.create().texOffs(836, 258).addBox(-3.0F, -8.0F, -0.5F, 6.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(64.0F, -15.0F, -11.0F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto4_0", CubeListBuilder.create().texOffs(850, 258).addBox(-3.0F, -6.0F, -0.5F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(-52.0F, -35.0F, 3.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto4_1", CubeListBuilder.create().texOffs(864, 258).addBox(-3.0F, -6.0F, -0.5F, 6.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(-52.0F, -35.0F, 3.0F, 0.0F, -0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto5_0", CubeListBuilder.create().texOffs(786, 258).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-10.0F, -9.0F, 10.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasto5_1", CubeListBuilder.create().texOffs(804, 258).addBox(-4.0F, -8.0F, -0.5F, 8.0F, 8.0F, 1.0F), PartPose.offsetAndRotation(-10.0F, -9.0F, 10.0F, 0.0F, -0.7853981633974483F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "bogie0", 0.5F, 0.5F, 0.5F);
        escalar(g0, "bogie1", 0.5F, 0.5F, 0.5F);
        escalar(g0, "bastidor", 0.5F, 0.5F, 0.5F);
        escalar(g0, "barandas", 0.5F, 0.5F, 0.5F);
        escalar(g0, "baranda_caida", 0.5F, 0.5F, 0.5F);
        escalar(g0, "capo_corto", 0.5F, 0.5F, 0.5F);
        escalar(g0, "capo_corto_cantoi_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_cantoi_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_corto_cantoi_2", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_cantoi_3", 1.0F, 1.0F, 0.625737860160923F);
        escalar(g0, "capo_corto_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_cantod_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_cantod_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_corto_cantod_2", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_cantod_3", 1.0F, 1.0F, 0.625737860160923F);
        escalar(g0, "capo_corto_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_corto_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_0", 0.2550041729048399F, 0.7F, 0.2550041729048399F);
        escalar(g0, "faro_1", 0.2550041729048399F, 0.7F, 0.2550041729048399F);
        escalar(g0, "faro_2", 0.2550041729048399F, 0.7F, 0.2550041729048399F);
        escalar(g0, "faro_3", 0.2550041729048399F, 0.7F, 0.2550041729048399F);
        escalar(g0, "faro_vidrio", 0.23636363636363636F, 0.15F, 0.23636363636363636F);
        escalar(g0, "faro_caja", 0.5F, 0.5F, 0.5F);
        escalar(g0, "faro_frente_0", 0.2550041729048399F, 0.6F, 0.2550041729048399F);
        escalar(g0, "faro_frente_1", 0.2550041729048399F, 0.6F, 0.2550041729048399F);
        escalar(g0, "faro_frente_2", 0.2550041729048399F, 0.6F, 0.2550041729048399F);
        escalar(g0, "faro_frente_3", 0.2550041729048399F, 0.6F, 0.2550041729048399F);
        escalar(g0, "faro_frente_vidrio", 0.23636363636363636F, 0.15F, 0.23636363636363636F);
        escalar(g0, "cabina", 0.5F, 0.5F, 0.5F);
        escalar(g0, "cabina_techo_0", 1.0008333333333332F, 1.0F, 0.7263528776800517F);
        escalar(g0, "cabina_techo_1", 1.0008333333333332F, 1.0F, 0.7263528776800502F);
        escalar(g0, "cabina_techo_2", 1.0008333333333332F, 1.0F, 0.7263528776800522F);
        escalar(g0, "cabina_techo_3", 1.0008333333333332F, 1.0F, 0.7263528776800509F);
        escalar(g0, "cabina_techo_4", 1.0008333333333332F, 1.0F, 0.7263528776800512F);
        escalar(g0, "cabina_techo_5", 1.0008333333333332F, 1.0F, 0.7263528776800515F);
        escalar(g0, "cabina_techo_6", 1.0008333333333332F, 1.0F, 0.7263528776800504F);
        escalar(g0, "cabina_techo_7", 1.0008333333333332F, 1.0F, 0.7263528776800516F);
        escalar(g0, "cabina_techo_8", 1.0008333333333332F, 1.0F, 0.7263528776800515F);
        escalar(g0, "cabina_techo_9", 1.0008333333333332F, 1.0F, 0.7263528776800516F);
        escalar(g0, "cabina_techo_10", 1.0008333333333332F, 1.0F, 0.7263528776800507F);
        escalar(g0, "cabina_techo_11", 1.0008333333333332F, 1.0F, 0.7263528776800517F);
        escalar(g0, "capo_largo", 0.5F, 0.5F, 0.5F);
        escalar(g0, "capo_largo_cantoi_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_cantoi_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_largo_cantoi_2", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_cantoi_3", 1.0F, 1.0F, 0.625737860160923F);
        escalar(g0, "capo_largo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_cantod_0", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_cantod_1", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g0, "capo_largo_cantod_2", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_cantod_3", 1.0F, 1.0F, 0.625737860160923F);
        escalar(g0, "capo_largo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_largo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "escape24_0", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "escape24_1", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "escape24_2", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "escape14_0", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "escape14_1", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "escape14_2", 0.1040227812926689F, 1.0F, 0.1040227812926689F);
        escalar(g0, "faro_t_0", 0.2353884672967753F, 0.55F, 0.2353884672967753F);
        escalar(g0, "faro_t_1", 0.2353884672967753F, 0.55F, 0.2353884672967753F);
        escalar(g0, "faro_t_2", 0.2353884672967753F, 0.55F, 0.2353884672967753F);
        escalar(g0, "faro_t_3", 0.2353884672967753F, 0.55F, 0.2353884672967753F);
        escalar(g0, "faro_t_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "pasto0_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto0_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto1_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto1_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto2_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto2_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto3_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto3_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto4_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto4_1", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto5_0", 0.5F, 0.5F, 0.05F);
        escalar(g0, "pasto5_1", 0.5F, 0.5F, 0.05F);
    }
}
