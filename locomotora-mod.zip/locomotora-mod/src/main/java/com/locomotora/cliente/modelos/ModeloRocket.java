package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Stephenson's Rocket" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloRocket {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("rocket"), "main"),
            LocomotoraMod.id("textures/entity/rocket.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -10.0F, -6.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -10.0F, -6.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -10.0F, -6.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -10.0F, -6.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -10.0F, -6.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -10.0F, -6.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 11.0F, -3.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 11.0F, -3.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 11.0F, -3.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 11.0F, -3.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 11.0F, -3.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 11.0F, -3.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("cruceta_i", DatosModelo.CRUCETA_INCLINADA, 6.5F, 2.5F, 0.0F, 11.0F, 0.0F, 0.0F, 0.0F, "locomotora", 0.5645693936681F),
                new DatosModelo.Animada("vastago_i", DatosModelo.CRUCETA_INCLINADA, 6.5F, 2.5F, 0.0F, 11.0F, 0.2501603211925225F, -12.991768203421932F, -2.1353657204629966F, "locomotora", 0.5645693936681F),
                new DatosModelo.Animada("biela_i", DatosModelo.MOTRIZ_INCLINADA, 6.5F, 2.5F, 0.0F, 11.0F, -10.0F, -9.0F, -1.9421616455020583F, "locomotora", 0.5645693936681F),
                new DatosModelo.Animada("cruceta_d", DatosModelo.CRUCETA_INCLINADA, 6.5F, 2.5F, 1.5707963267948966F, 11.0F, 0.0F, 0.0F, 0.0F, "locomotora", 0.5645693936681F),
                new DatosModelo.Animada("vastago_d", DatosModelo.CRUCETA_INCLINADA, 6.5F, 2.5F, 1.5707963267948966F, 11.0F, 0.2501603211925225F, -12.991768203421932F, -2.1353657204629966F, "locomotora", 0.5645693936681F),
                new DatosModelo.Animada("biela_d", DatosModelo.MOTRIZ_INCLINADA, 6.5F, 2.5F, 1.5707963267948966F, 11.0F, -10.0F, -9.0F, -1.9421616455020583F, "locomotora", 0.5645693936681F),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 1.0471975511965976F, "tender")),
            ModeloRocket::crearCapa,
            16.0F,
            ModeloRocket::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -10.0F, 11.0F),
                new DatosModelo.Segmento("tender", 30.0F, 44.0F)));

    private ModeloRocket() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g1);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(164, 85).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(226, 100).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 85).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(360, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(476, 112).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-10.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(256, 100).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(328, 85).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(286, 100).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 85).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(164, 85).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(226, 100).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(318, 85).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(482, 112).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-10.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(256, 100).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(328, 85).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(286, 100).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(338, 85).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(680, 85).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(624, 100).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(698, 85).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(380, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(11.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(642, 100).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(706, 85).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(11.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(660, 100).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 85).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(11.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(680, 85).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(624, 100).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(698, 85).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(390, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(11.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(642, 100).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(706, 85).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(11.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(660, 100).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 85).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(11.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(922, 85).addBox(-18.0F, -9.0F, 2.0F, 34.0F, 5.0F, 1.0F).texOffs(0, 100).addBox(-18.0F, -9.0F, -3.0F, 34.0F, 5.0F, 1.0F).texOffs(194, 85).addBox(-19.0F, -8.0F, -6.0F, 2.0F, 3.0F, 12.0F).texOffs(128, 85).addBox(14.0F, -7.0F, -7.0F, 4.0F, 1.0F, 14.0F).texOffs(186, 100).addBox(-12.0F, -9.0F, 3.0F, 4.0F, 5.0F, 1.0F).texOffs(196, 100).addBox(-12.0F, -9.0F, -4.0F, 4.0F, 5.0F, 1.0F).texOffs(708, 112).addBox(-14.0F, -10.0F, 3.0F, 8.0F, 1.0F, 1.0F).texOffs(726, 112).addBox(-14.0F, -10.0F, -4.0F, 8.0F, 1.0F, 1.0F).texOffs(206, 100).addBox(9.0F, -9.0F, 3.0F, 4.0F, 5.0F, 1.0F).texOffs(216, 100).addBox(9.0F, -9.0F, -4.0F, 4.0F, 5.0F, 1.0F).texOffs(744, 112).addBox(7.0F, -10.0F, 3.0F, 8.0F, 1.0F, 1.0F).texOffs(762, 112).addBox(7.0F, -10.0F, -4.0F, 8.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(132, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -19.914814565722672F, 0.6470476127563018F, 3.0106929596902177F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(146, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -19.914814565722672F, 0.6470476127563018F, 3.0106929596902177F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(160, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -19.914814565722672F, 0.6470476127563018F, 3.0106929596902177F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(174, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -19.914814565722672F, 0.6470476127563018F, 3.0106929596902177F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(188, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -19.579878075183768F, 1.8970476127563018F, 2.7488935718910708F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(202, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -19.579878075183768F, 1.8970476127563018F, 2.7488935718910708F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(216, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -19.579878075183768F, 1.8970476127563018F, 2.7488935718910708F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(230, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -19.579878075183768F, 1.8970476127563018F, 2.7488935718910708F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(244, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -18.932830462427468F, 3.0177669529663684F, 2.487094184091919F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(258, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -18.932830462427468F, 3.0177669529663684F, 2.487094184091919F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(272, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -18.932830462427468F, 3.0177669529663684F, 2.487094184091919F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(286, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -18.932830462427468F, 3.0177669529663684F, 2.487094184091919F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(300, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -18.01776695296637F, 3.9328304624274653F, 2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(314, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -18.01776695296637F, 3.9328304624274653F, 2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(328, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -18.01776695296637F, 3.9328304624274653F, 2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(342, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -18.01776695296637F, 3.9328304624274653F, 2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(356, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -16.897047612756303F, 4.579878075183767F, 1.9634954084936211F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(370, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -16.897047612756303F, 4.579878075183767F, 1.9634954084936211F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(384, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -16.897047612756303F, 4.579878075183767F, 1.9634954084936211F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(398, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -16.897047612756303F, 4.579878075183767F, 1.9634954084936211F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(412, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -15.647047612756303F, 4.91481456572267F, 1.7016960206944718F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(426, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -15.647047612756303F, 4.91481456572267F, 1.7016960206944718F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(440, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -15.647047612756303F, 4.91481456572267F, 1.7016960206944718F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(454, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -15.647047612756303F, 4.91481456572267F, 1.7016960206944718F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(468, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -14.352952387243697F, 4.914814565722671F, 1.4398966328953224F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(482, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -14.352952387243697F, 4.914814565722671F, 1.4398966328953224F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(496, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -14.352952387243697F, 4.914814565722671F, 1.4398966328953224F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(510, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -14.352952387243697F, 4.914814565722671F, 1.4398966328953224F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(524, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -13.102952387243699F, 4.5798780751837675F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(538, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -13.102952387243699F, 4.5798780751837675F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(552, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -13.102952387243699F, 4.5798780751837675F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(566, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -13.102952387243699F, 4.5798780751837675F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(580, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -11.982233047033631F, 3.9328304624274657F, 0.9162978572970228F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(594, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -11.982233047033631F, 3.9328304624274657F, 0.9162978572970228F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(608, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -11.982233047033631F, 3.9328304624274657F, 0.9162978572970228F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(622, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -11.982233047033631F, 3.9328304624274657F, 0.9162978572970228F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(636, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -11.067169537572536F, 3.0177669529663698F, 0.654498469497874F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(650, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -11.067169537572536F, 3.0177669529663698F, 0.654498469497874F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(664, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -11.067169537572536F, 3.0177669529663698F, 0.654498469497874F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(678, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -11.067169537572536F, 3.0177669529663698F, 0.654498469497874F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(692, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -10.420121924816232F, 1.8970476127563032F, 0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(706, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -10.420121924816232F, 1.8970476127563032F, 0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(720, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -10.420121924816232F, 1.8970476127563032F, 0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(734, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -10.420121924816232F, 1.8970476127563032F, 0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(748, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -10.08518543427733F, 0.6470476127563028F, 0.13089969389957534F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(762, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -10.08518543427733F, 0.6470476127563028F, 0.13089969389957534F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(776, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -10.08518543427733F, 0.6470476127563028F, 0.13089969389957534F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(790, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -10.08518543427733F, 0.6470476127563028F, 0.13089969389957534F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(804, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -10.085185434277328F, -0.6470476127563005F, -0.13089969389957418F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(818, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -10.085185434277328F, -0.6470476127563005F, -0.13089969389957418F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(832, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -10.085185434277328F, -0.6470476127563005F, -0.13089969389957418F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(846, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -10.085185434277328F, -0.6470476127563005F, -0.13089969389957418F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(860, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -10.420121924816232F, -1.8970476127562992F, -0.3926990816987242F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(874, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -10.420121924816232F, -1.8970476127562992F, -0.3926990816987242F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(888, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -10.420121924816232F, -1.8970476127562992F, -0.3926990816987242F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(902, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -10.420121924816232F, -1.8970476127562992F, -0.3926990816987242F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(916, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -11.067169537572534F, -3.017766952966367F, -0.654498469497873F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(930, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -11.067169537572534F, -3.017766952966367F, -0.654498469497873F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(944, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -11.067169537572534F, -3.017766952966367F, -0.654498469497873F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(958, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -11.067169537572534F, -3.017766952966367F, -0.654498469497873F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(972, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -11.982233047033631F, -3.9328304624274644F, -0.9162978572970228F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(986, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -11.982233047033631F, -3.9328304624274644F, -0.9162978572970228F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(1000, 109).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -11.982233047033631F, -3.9328304624274644F, -0.9162978572970228F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(0, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -11.982233047033631F, -3.9328304624274644F, -0.9162978572970228F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(14, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -13.102952387243695F, -4.579878075183766F, -1.1780972450961713F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(28, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -13.102952387243695F, -4.579878075183766F, -1.1780972450961713F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(42, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -13.102952387243695F, -4.579878075183766F, -1.1780972450961713F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(56, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -13.102952387243695F, -4.579878075183766F, -1.1780972450961713F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(70, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -14.352952387243695F, -4.91481456572267F, -1.4398966328953215F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(84, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -14.352952387243695F, -4.91481456572267F, -1.4398966328953215F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(98, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -14.352952387243695F, -4.91481456572267F, -1.4398966328953215F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(112, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -14.352952387243695F, -4.91481456572267F, -1.4398966328953215F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(126, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -15.6470476127563F, -4.914814565722671F, -1.7016960206944705F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(140, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -15.6470476127563F, -4.914814565722671F, -1.7016960206944705F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(154, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -15.6470476127563F, -4.914814565722671F, -1.7016960206944705F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(168, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -15.6470476127563F, -4.914814565722671F, -1.7016960206944705F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(182, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -16.8970476127563F, -4.579878075183769F, -1.9634954084936207F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(196, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -16.8970476127563F, -4.579878075183769F, -1.9634954084936207F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(210, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -16.8970476127563F, -4.579878075183769F, -1.9634954084936207F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(224, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -16.8970476127563F, -4.579878075183769F, -1.9634954084936207F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(238, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -18.01776695296637F, -3.932830462427467F, -2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(252, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -18.01776695296637F, -3.932830462427467F, -2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(266, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -18.01776695296637F, -3.932830462427467F, -2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(280, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -18.01776695296637F, -3.932830462427467F, -2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(294, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -18.932830462427464F, -3.01776695296637F, -2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(308, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -18.932830462427464F, -3.01776695296637F, -2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(322, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -18.932830462427464F, -3.01776695296637F, -2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(336, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -18.932830462427464F, -3.01776695296637F, -2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(350, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -19.579878075183764F, -1.897047612756305F, -2.7488935718910676F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(364, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -19.579878075183764F, -1.897047612756305F, -2.7488935718910676F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(378, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -19.579878075183764F, -1.897047612756305F, -2.7488935718910676F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(392, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -19.579878075183764F, -1.897047612756305F, -2.7488935718910676F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(406, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.5F, -19.914814565722672F, -0.6470476127563046F, -3.010692959690218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(420, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.5F, -19.914814565722672F, -0.6470476127563046F, -3.010692959690218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(434, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5F, -19.914814565722672F, -0.6470476127563046F, -3.010692959690218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(448, 112).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5F, -19.914814565722672F, -0.6470476127563046F, -3.010692959690218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_frente", CubeListBuilder.create().texOffs(820, 0).addBox(-20.0F, 0.0F, -20.0F, 40.0F, 1.0F, 40.0F), PartPose.offsetAndRotation(-16.05F, -15.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("chimenea_base_0", CubeListBuilder.create().texOffs(826, 85).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(222, 85).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offset(-13.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_base_1", CubeListBuilder.create().texOffs(850, 85).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(246, 85).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offsetAndRotation(-13.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_base_2", CubeListBuilder.create().texOffs(874, 85).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(270, 85).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offsetAndRotation(-13.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_base_3", CubeListBuilder.create().texOffs(898, 85).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 5.0F, 2.0F).texOffs(294, 85).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 5.0F, 10.0F), PartPose.offsetAndRotation(-13.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea_0", CubeListBuilder.create().texOffs(540, 44).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 17.0F, 2.0F).texOffs(320, 44).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 17.0F, 10.0F), PartPose.offset(-13.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_1", CubeListBuilder.create().texOffs(564, 44).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 17.0F, 2.0F).texOffs(344, 44).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 17.0F, 10.0F), PartPose.offsetAndRotation(-13.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_2", CubeListBuilder.create().texOffs(588, 44).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 17.0F, 2.0F).texOffs(368, 44).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 17.0F, 10.0F), PartPose.offsetAndRotation(-13.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_3", CubeListBuilder.create().texOffs(612, 44).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 17.0F, 2.0F).texOffs(392, 44).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 17.0F, 10.0F), PartPose.offsetAndRotation(-13.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea_borde_0", CubeListBuilder.create().texOffs(36, 109).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(456, 85).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(-13.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_borde_1", CubeListBuilder.create().texOffs(60, 109).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(480, 85).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-13.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_borde_2", CubeListBuilder.create().texOffs(84, 109).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(504, 85).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-13.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_borde_3", CubeListBuilder.create().texOffs(108, 109).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(528, 85).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-13.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("hogar", CubeListBuilder.create().texOffs(500, 44).addBox(4.0F, -18.0F, -5.0F, 10.0F, 11.0F, 10.0F).texOffs(798, 85).addBox(4.0F, -21.0F, -2.0F, 10.0F, 3.0F, 4.0F).texOffs(424, 85).addBox(5.0F, -7.0F, -4.0F, 8.0F, 3.0F, 8.0F), PartPose.ZERO);
        g.addOrReplaceChild("hogar_cantoi_0", CubeListBuilder.create().texOffs(488, 112).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.0F, -18.46352549156242F, -4.9265847744427305F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_cantoi_1", CubeListBuilder.create().texOffs(510, 112).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.0F, -19.34520337000113F, -4.640110266005152F, -2.042035224833366F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_cantoi_2", CubeListBuilder.create().texOffs(532, 112).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.0F, -20.09520337000113F, -4.095203370001131F, -2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_cantoi_3", CubeListBuilder.create().texOffs(554, 112).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.0F, -20.640110266005152F, -3.3452033700011308F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_cantoi_4", CubeListBuilder.create().texOffs(576, 112).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.0F, -20.92658477444273F, -2.463525491562421F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_cantod_0", CubeListBuilder.create().texOffs(598, 112).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.0F, -18.46352549156242F, 4.9265847744427305F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_cantod_1", CubeListBuilder.create().texOffs(620, 112).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.0F, -19.34520337000113F, 4.640110266005152F, 2.042035224833366F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_cantod_2", CubeListBuilder.create().texOffs(642, 112).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.0F, -20.09520337000113F, 4.095203370001131F, 2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_cantod_3", CubeListBuilder.create().texOffs(664, 112).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.0F, -20.640110266005152F, 3.3452033700011308F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_cantod_4", CubeListBuilder.create().texOffs(686, 112).addBox(-5.0F, -1.0F, -0.5F, 10.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(9.0F, -20.92658477444273F, 2.463525491562421F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("hogar_tapaa", CubeListBuilder.create().texOffs(416, 44).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 20.0F), PartPose.offset(4.0F, -18.0F, -5.0F));
        g.addOrReplaceChild("hogar_tapab", CubeListBuilder.create().texOffs(458, 44).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 20.0F), PartPose.offset(13.0F, -18.0F, -5.0F));
        g.addOrReplaceChild("valvula_0", CubeListBuilder.create().texOffs(612, 85).addBox(-6.0F, -23.0F, -2.5F, 12.0F, 4.0F, 5.0F).texOffs(892, 44).addBox(-2.5F, -23.0F, -6.0F, 5.0F, 4.0F, 12.0F), PartPose.offset(-1.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("valvula_1", CubeListBuilder.create().texOffs(646, 85).addBox(-6.0F, -23.0F, -2.5F, 12.0F, 4.0F, 5.0F).texOffs(926, 44).addBox(-2.5F, -23.0F, -6.0F, 5.0F, 4.0F, 12.0F), PartPose.offsetAndRotation(-1.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("valvula2_0", CubeListBuilder.create().texOffs(730, 85).addBox(-6.0F, -23.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(348, 85).addBox(-2.5F, -23.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(8.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("valvula2_1", CubeListBuilder.create().texOffs(764, 85).addBox(-6.0F, -23.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(382, 85).addBox(-2.5F, -23.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(8.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("cil_i_0", CubeListBuilder.create().texOffs(694, 100).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.892868865310433F, -18.035155664882815F, -5.672314444114278F, 1.3744467859455338F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_i_1", CubeListBuilder.create().texOffs(734, 100).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.252290872459188F, -17.467647232542678F, -5.9505630019870575F, 0.9817477042468102F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_i_2", CubeListBuilder.create().texOffs(774, 100).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.527380567185658F, -17.03329508297457F, -6.464699297125945F, 0.5890486225480873F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_i_3", CubeListBuilder.create().texOffs(814, 100).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.67625803716203F, -16.79822539353819F, -7.136450739253165F, 0.1963495408493614F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_i_4", CubeListBuilder.create().texOffs(854, 100).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.67625803716203F, -16.79822539353819F, -7.8635492607468365F, -0.19634954084936118F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_i_5", CubeListBuilder.create().texOffs(894, 100).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.527380567185658F, -17.03329508297457F, -8.535300702874055F, -0.5890486225480885F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_i_6", CubeListBuilder.create().texOffs(934, 100).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.252290872459188F, -17.467647232542678F, -9.049436998012943F, -0.9817477042468077F, 0.0F, -0.5645693936681002F));
        g.addOrReplaceChild("cil_i_7", CubeListBuilder.create().texOffs(974, 100).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.892868865310433F, -18.035155664882815F, -9.327685555885722F, -1.3744467859455352F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_i_8", CubeListBuilder.create().texOffs(0, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.503833288159186F, -18.649422365647943F, -9.327685555885722F, -1.7671458676442582F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_i_9", CubeListBuilder.create().texOffs(40, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.14441128101043F, -19.216930797988084F, -9.049436998012943F, -2.1598449493429834F, 0.0F, -0.5645693936680999F));
        g.addOrReplaceChild("cil_i_10", CubeListBuilder.create().texOffs(80, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.869321586283961F, -19.651282947556194F, -8.535300702874057F, -2.5525440310417067F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_i_11", CubeListBuilder.create().texOffs(120, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.720444116307587F, -19.886352636992573F, -7.863549260746836F, -2.9452431127404313F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_i_12", CubeListBuilder.create().texOffs(160, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.720444116307588F, -19.886352636992573F, -7.1364507392531635F, 2.9452431127404313F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_i_13", CubeListBuilder.create().texOffs(200, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.869321586283961F, -19.651282947556194F, -6.464699297125945F, 2.5525440310417054F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_i_14", CubeListBuilder.create().texOffs(240, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.14441128101043F, -19.216930797988084F, -5.950563001987058F, 2.159844949342984F, 0.0F, -0.5645693936680999F));
        g.addOrReplaceChild("cil_i_15", CubeListBuilder.create().texOffs(280, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.503833288159186F, -18.649422365647943F, -5.672314444114278F, 1.7671458676442602F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_i_ta", CubeListBuilder.create().texOffs(636, 44).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(4.854424282963069F, -15.907802045876611F, -7.5F, 0.0F, 0.0F, 1.0062269331267966F));
        g.addOrReplaceChild("cil_i_tb", CubeListBuilder.create().texOffs(700, 44).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(12.542277870506549F, -20.77677598465415F, -7.5F, 0.0F, 0.0F, -2.1353657204629966F));
        g.addOrReplaceChild("guiaa_i", CubeListBuilder.create().texOffs(552, 85).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-2.5940638998400463F, -10.006740803130324F, -7.5F, 0.0F, 0.0F, -2.135365720462997F));
        g.addOrReplaceChild("guiab_i", CubeListBuilder.create().texOffs(556, 85).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-3.664168062208736F, -11.696378954238781F, -7.5F, 0.0F, 0.0F, -2.135365720462997F));
        g.addOrReplaceChild("soporte_i", CubeListBuilder.create().texOffs(440, 100).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(8.69835107673481F, -18.34228901526538F, -7.5F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cruceta_i", CubeListBuilder.create().texOffs(678, 100).addBox(-0.7498396788074775F, -13.991768203421932F, -8.5F, 2.0F, 2.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("vastago_i", CubeListBuilder.create().texOffs(722, 85).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 7.0F, 1.0F), PartPose.offsetAndRotation(0.2501603211925225F, -12.991768203421932F, -7.5F, 0.0F, 0.0F, -2.1353657204629966F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(416, 85).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 11.0F, 1.0F), PartPose.offsetAndRotation(-10.0F, -9.0F, -7.5F, 0.0F, 0.0F, -1.9421616455020583F));
        g.addOrReplaceChild("cil_d_0", CubeListBuilder.create().texOffs(320, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.892868865310433F, -18.035155664882815F, 9.327685555885722F, 1.3744467859455352F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_d_1", CubeListBuilder.create().texOffs(360, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.252290872459188F, -17.467647232542678F, 9.049436998012943F, 0.9817477042468102F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_d_2", CubeListBuilder.create().texOffs(400, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.527380567185658F, -17.03329508297457F, 8.535300702874057F, 0.5890486225480873F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_d_3", CubeListBuilder.create().texOffs(440, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.67625803716203F, -16.79822539353819F, 7.863549260746836F, 0.19634954084936118F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_d_4", CubeListBuilder.create().texOffs(480, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.67625803716203F, -16.79822539353819F, 7.136450739253165F, -0.1963495408493614F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_d_5", CubeListBuilder.create().texOffs(520, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.527380567185658F, -17.03329508297457F, 6.464699297125945F, -0.5890486225480873F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_d_6", CubeListBuilder.create().texOffs(560, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.252290872459188F, -17.467647232542678F, 5.9505630019870575F, -0.9817477042468098F, 0.0F, -0.5645693936681002F));
        g.addOrReplaceChild("cil_d_7", CubeListBuilder.create().texOffs(600, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.892868865310433F, -18.035155664882815F, 5.672314444114278F, -1.374446785945534F, 0.0F, -0.5645693936681001F));
        g.addOrReplaceChild("cil_d_8", CubeListBuilder.create().texOffs(640, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.503833288159186F, -18.649422365647943F, 5.672314444114278F, -1.7671458676442593F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_d_9", CubeListBuilder.create().texOffs(680, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.14441128101043F, -19.216930797988084F, 5.9505630019870575F, -2.1598449493429834F, 0.0F, -0.5645693936680999F));
        g.addOrReplaceChild("cil_d_10", CubeListBuilder.create().texOffs(720, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.869321586283961F, -19.651282947556194F, 6.464699297125945F, -2.5525440310417062F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_d_11", CubeListBuilder.create().texOffs(760, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.720444116307587F, -19.886352636992573F, 7.136450739253164F, -2.9452431127404313F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_d_12", CubeListBuilder.create().texOffs(800, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.720444116307588F, -19.886352636992573F, 7.8635492607468365F, 2.9452431127404313F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_d_13", CubeListBuilder.create().texOffs(840, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(7.869321586283961F, -19.651282947556194F, 8.535300702874055F, 2.5525440310417054F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_d_14", CubeListBuilder.create().texOffs(880, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.14441128101043F, -19.216930797988084F, 9.049436998012942F, 2.159844949342984F, 0.0F, -0.5645693936680999F));
        g.addOrReplaceChild("cil_d_15", CubeListBuilder.create().texOffs(920, 106).addBox(-9.0F, -1.0F, -1.0F, 18.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.503833288159186F, -18.649422365647943F, 9.327685555885722F, 1.7671458676442602F, 0.0F, -0.5645693936681F));
        g.addOrReplaceChild("cil_d_ta", CubeListBuilder.create().texOffs(764, 44).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(4.854424282963069F, -15.907802045876611F, 7.5F, 0.0F, 0.0F, 1.0062269331267966F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("cil_d_tb", CubeListBuilder.create().texOffs(828, 44).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(12.542277870506549F, -20.77677598465415F, 7.5F, 0.0F, 0.0F, -2.1353657204629966F));
        g.addOrReplaceChild("guiaa_d", CubeListBuilder.create().texOffs(560, 85).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-2.5940638998400463F, -10.006740803130324F, 7.5F, 0.0F, 0.0F, -2.135365720462997F));
        g.addOrReplaceChild("guiab_d", CubeListBuilder.create().texOffs(564, 85).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 10.0F, 1.0F), PartPose.offsetAndRotation(-3.664168062208736F, -11.696378954238781F, 7.5F, 0.0F, 0.0F, -2.135365720462997F));
        g.addOrReplaceChild("soporte_d", CubeListBuilder.create().texOffs(444, 100).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(8.69835107673481F, -18.34228901526538F, 7.5F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cruceta_d", CubeListBuilder.create().texOffs(686, 100).addBox(-0.7498396788074775F, -13.991768203421932F, 6.5F, 2.0F, 2.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("vastago_d", CubeListBuilder.create().texOffs(726, 85).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 7.0F, 1.0F), PartPose.offsetAndRotation(0.2501603211925225F, -12.991768203421932F, 7.5F, 0.0F, 0.0F, -2.1353657204629966F));
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(420, 85).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 11.0F, 1.0F), PartPose.offsetAndRotation(-10.0F, -9.0F, 7.5F, 0.0F, 0.0F, -1.9421616455020583F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(568, 85).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(564, 100).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(588, 85).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(30.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(584, 100).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(596, 85).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(604, 100).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(604, 85).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(568, 85).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(564, 100).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(588, 85).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(410, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(584, 100).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(596, 85).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(604, 100).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(604, 85).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(568, 85).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(564, 100).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(588, 85).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(420, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(30.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(584, 100).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(596, 85).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(604, 100).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(604, 85).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(568, 85).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(564, 100).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(588, 85).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(430, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(584, 100).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(596, 85).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(604, 100).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(604, 85).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(70, 100).addBox(23.0F, -10.0F, 2.0F, 28.0F, 5.0F, 1.0F).texOffs(128, 100).addBox(23.0F, -10.0F, -3.0F, 28.0F, 5.0F, 1.0F).texOffs(448, 100).addBox(23.0F, -10.0F, 6.0F, 28.0F, 3.0F, 1.0F).texOffs(506, 100).addBox(23.0F, -10.0F, -7.0F, 28.0F, 3.0F, 1.0F).texOffs(0, 85).addBox(22.0F, -11.0F, -7.0F, 30.0F, 1.0F, 14.0F).texOffs(462, 112).addBox(18.0F, -9.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(316, 100).addBox(22.0F, -15.0F, 6.0F, 10.0F, 4.0F, 1.0F).texOffs(338, 100).addBox(22.0F, -15.0F, -7.0F, 10.0F, 4.0F, 1.0F).texOffs(960, 44).addBox(22.0F, -15.0F, -6.0F, 1.0F, 4.0F, 12.0F).texOffs(88, 85).addBox(23.0F, -14.0F, -6.0F, 8.0F, 3.0F, 12.0F).texOffs(960, 106).addBox(33.0F, -13.0F, 3.0F, 17.0F, 2.0F, 1.0F).texOffs(0, 109).addBox(33.0F, -13.0F, -4.0F, 17.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tonel_0", CubeListBuilder.create().texOffs(570, 0).addBox(32.0F, -19.0F, -3.0F, 19.0F, 38.0F, 6.0F).texOffs(0, 0).addBox(32.0F, -3.0F, -19.0F, 19.0F, 6.0F, 38.0F), PartPose.offset(0.0F, -17.0F, 0.0F));
        g.addOrReplaceChild("tonel_1", CubeListBuilder.create().texOffs(620, 0).addBox(32.0F, -19.0F, -3.0F, 19.0F, 38.0F, 6.0F).texOffs(114, 0).addBox(32.0F, -3.0F, -19.0F, 19.0F, 6.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -17.0F, 0.0F, 0.3141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("tonel_2", CubeListBuilder.create().texOffs(670, 0).addBox(32.0F, -19.0F, -3.0F, 19.0F, 38.0F, 6.0F).texOffs(228, 0).addBox(32.0F, -3.0F, -19.0F, 19.0F, 6.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -17.0F, 0.0F, 0.6283185307179586F, 0.0F, 0.0F));
        g.addOrReplaceChild("tonel_3", CubeListBuilder.create().texOffs(720, 0).addBox(32.0F, -19.0F, -3.0F, 19.0F, 38.0F, 6.0F).texOffs(342, 0).addBox(32.0F, -3.0F, -19.0F, 19.0F, 6.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -17.0F, 0.0F, 0.9424777960769379F, 0.0F, 0.0F));
        g.addOrReplaceChild("tonel_4", CubeListBuilder.create().texOffs(770, 0).addBox(32.0F, -19.0F, -3.0F, 19.0F, 38.0F, 6.0F).texOffs(456, 0).addBox(32.0F, -3.0F, -19.0F, 19.0F, 6.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -17.0F, 0.0F, 1.2566370614359172F, 0.0F, 0.0F));
        g.addOrReplaceChild("tonel_tapa32", CubeListBuilder.create().texOffs(0, 44).addBox(-20.0F, 0.0F, -20.0F, 40.0F, 1.0F, 40.0F), PartPose.offsetAndRotation(31.95F, -17.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("tonel_tapa51", CubeListBuilder.create().texOffs(160, 44).addBox(-20.0F, 0.0F, -20.0F, 40.0F, 1.0F, 40.0F), PartPose.offsetAndRotation(51.05F, -17.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "caldera_0", 1.0F, 1.0F, 0.652630961100258F);
        escalar(g0, "caldera_1", 1.0F, 1.0F, 0.652630961100258F);
        escalar(g0, "caldera_2", 1.0F, 1.0F, 0.652630961100258F);
        escalar(g0, "caldera_3", 1.0F, 1.0F, 0.652630961100258F);
        escalar(g0, "caldera_4", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_5", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_6", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_7", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_8", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_9", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_10", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_11", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_12", 1.0F, 1.0F, 0.652630961100258F);
        escalar(g0, "caldera_13", 1.0F, 1.0F, 0.652630961100258F);
        escalar(g0, "caldera_14", 1.0F, 1.0F, 0.652630961100258F);
        escalar(g0, "caldera_15", 1.0F, 1.0F, 0.652630961100258F);
        escalar(g0, "caldera_16", 1.0F, 1.0F, 0.6526309611002566F);
        escalar(g0, "caldera_17", 1.0F, 1.0F, 0.6526309611002566F);
        escalar(g0, "caldera_18", 1.0F, 1.0F, 0.6526309611002566F);
        escalar(g0, "caldera_19", 1.0F, 1.0F, 0.6526309611002566F);
        escalar(g0, "caldera_20", 1.0F, 1.0F, 0.6526309611002592F);
        escalar(g0, "caldera_21", 1.0F, 1.0F, 0.6526309611002592F);
        escalar(g0, "caldera_22", 1.0F, 1.0F, 0.6526309611002592F);
        escalar(g0, "caldera_23", 1.0F, 1.0F, 0.6526309611002592F);
        escalar(g0, "caldera_24", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_25", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_26", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_27", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_28", 1.0F, 1.0F, 0.6526309611002585F);
        escalar(g0, "caldera_29", 1.0F, 1.0F, 0.6526309611002585F);
        escalar(g0, "caldera_30", 1.0F, 1.0F, 0.6526309611002585F);
        escalar(g0, "caldera_31", 1.0F, 1.0F, 0.6526309611002585F);
        escalar(g0, "caldera_32", 1.0F, 1.0F, 0.6526309611002581F);
        escalar(g0, "caldera_33", 1.0F, 1.0F, 0.6526309611002581F);
        escalar(g0, "caldera_34", 1.0F, 1.0F, 0.6526309611002581F);
        escalar(g0, "caldera_35", 1.0F, 1.0F, 0.6526309611002581F);
        escalar(g0, "caldera_36", 1.0F, 1.0F, 0.6526309611002571F);
        escalar(g0, "caldera_37", 1.0F, 1.0F, 0.6526309611002571F);
        escalar(g0, "caldera_38", 1.0F, 1.0F, 0.6526309611002571F);
        escalar(g0, "caldera_39", 1.0F, 1.0F, 0.6526309611002571F);
        escalar(g0, "caldera_40", 1.0F, 1.0F, 0.6526309611002581F);
        escalar(g0, "caldera_41", 1.0F, 1.0F, 0.6526309611002581F);
        escalar(g0, "caldera_42", 1.0F, 1.0F, 0.6526309611002581F);
        escalar(g0, "caldera_43", 1.0F, 1.0F, 0.6526309611002581F);
        escalar(g0, "caldera_44", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_45", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_46", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_47", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_48", 1.0F, 1.0F, 0.6526309611002572F);
        escalar(g0, "caldera_49", 1.0F, 1.0F, 0.6526309611002572F);
        escalar(g0, "caldera_50", 1.0F, 1.0F, 0.6526309611002572F);
        escalar(g0, "caldera_51", 1.0F, 1.0F, 0.6526309611002572F);
        escalar(g0, "caldera_52", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_53", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_54", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_55", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_56", 1.0F, 1.0F, 0.6526309611002594F);
        escalar(g0, "caldera_57", 1.0F, 1.0F, 0.6526309611002594F);
        escalar(g0, "caldera_58", 1.0F, 1.0F, 0.6526309611002594F);
        escalar(g0, "caldera_59", 1.0F, 1.0F, 0.6526309611002594F);
        escalar(g0, "caldera_60", 1.0F, 1.0F, 0.652630961100257F);
        escalar(g0, "caldera_61", 1.0F, 1.0F, 0.652630961100257F);
        escalar(g0, "caldera_62", 1.0F, 1.0F, 0.652630961100257F);
        escalar(g0, "caldera_63", 1.0F, 1.0F, 0.652630961100257F);
        escalar(g0, "caldera_64", 1.0F, 1.0F, 0.6526309611002569F);
        escalar(g0, "caldera_65", 1.0F, 1.0F, 0.6526309611002569F);
        escalar(g0, "caldera_66", 1.0F, 1.0F, 0.6526309611002569F);
        escalar(g0, "caldera_67", 1.0F, 1.0F, 0.6526309611002569F);
        escalar(g0, "caldera_68", 1.0F, 1.0F, 0.6526309611002592F);
        escalar(g0, "caldera_69", 1.0F, 1.0F, 0.6526309611002592F);
        escalar(g0, "caldera_70", 1.0F, 1.0F, 0.6526309611002592F);
        escalar(g0, "caldera_71", 1.0F, 1.0F, 0.6526309611002592F);
        escalar(g0, "caldera_72", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_73", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_74", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_75", 1.0F, 1.0F, 0.6526309611002583F);
        escalar(g0, "caldera_76", 1.0F, 1.0F, 0.6526309611002565F);
        escalar(g0, "caldera_77", 1.0F, 1.0F, 0.6526309611002565F);
        escalar(g0, "caldera_78", 1.0F, 1.0F, 0.6526309611002565F);
        escalar(g0, "caldera_79", 1.0F, 1.0F, 0.6526309611002565F);
        escalar(g0, "caldera_80", 1.0F, 1.0F, 0.6526309611002598F);
        escalar(g0, "caldera_81", 1.0F, 1.0F, 0.6526309611002598F);
        escalar(g0, "caldera_82", 1.0F, 1.0F, 0.6526309611002598F);
        escalar(g0, "caldera_83", 1.0F, 1.0F, 0.6526309611002598F);
        escalar(g0, "caldera_84", 1.0F, 1.0F, 0.6526309611002568F);
        escalar(g0, "caldera_85", 1.0F, 1.0F, 0.6526309611002568F);
        escalar(g0, "caldera_86", 1.0F, 1.0F, 0.6526309611002568F);
        escalar(g0, "caldera_87", 1.0F, 1.0F, 0.6526309611002568F);
        escalar(g0, "caldera_88", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_89", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_90", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_91", 1.0F, 1.0F, 0.6526309611002574F);
        escalar(g0, "caldera_92", 1.0F, 1.0F, 0.6526309611002594F);
        escalar(g0, "caldera_93", 1.0F, 1.0F, 0.6526309611002594F);
        escalar(g0, "caldera_94", 1.0F, 1.0F, 0.6526309611002594F);
        escalar(g0, "caldera_95", 1.0F, 1.0F, 0.6526309611002594F);
        escalar(g0, "caldera_frente", 0.25F, 0.6F, 0.25F);
        escalar(g0, "chimenea_base_0", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "chimenea_base_1", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "chimenea_base_2", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "chimenea_base_3", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "chimenea_0", 0.353082700945163F, 1.0F, 0.353082700945163F);
        escalar(g0, "chimenea_1", 0.353082700945163F, 1.0F, 0.353082700945163F);
        escalar(g0, "chimenea_2", 0.353082700945163F, 1.0F, 0.353082700945163F);
        escalar(g0, "chimenea_3", 0.353082700945163F, 1.0F, 0.353082700945163F);
        escalar(g0, "chimenea_borde_0", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "chimenea_borde_1", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "chimenea_borde_2", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "chimenea_borde_3", 0.45116122898548594F, 1.0F, 0.45116122898548594F);
        escalar(g0, "hogar_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "hogar_cantoi_1", 1.0F, 1.0F, 0.938606790241385F);
        escalar(g0, "hogar_cantoi_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "hogar_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "hogar_cantoi_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "hogar_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "hogar_cantod_1", 1.0F, 1.0F, 0.938606790241385F);
        escalar(g0, "hogar_cantod_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "hogar_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "hogar_cantod_4", 1.0F, 1.0F, 0.9386067902413853F);
        escalar(g0, "hogar_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "hogar_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "valvula_0", 0.12318393766817158F, 1.0F, 0.12318393766817158F);
        escalar(g0, "valvula_1", 0.12318393766817158F, 1.0F, 0.12318393766817158F);
        escalar(g0, "valvula2_0", 0.09238795325112868F, 1.0F, 0.09238795325112868F);
        escalar(g0, "valvula2_1", 0.09238795325112868F, 1.0F, 0.09238795325112868F);
        escalar(g0, "cil_i_0", 0.5000000000000001F, 1.0F, 0.3706716118306435F);
        escalar(g0, "cil_i_1", 0.5000000000000001F, 1.0F, 0.37067161183064357F);
        escalar(g0, "cil_i_2", 0.5000000000000001F, 1.0F, 0.3706716118306442F);
        escalar(g0, "cil_i_3", 0.5000000000000002F, 1.0F, 0.3706716118306435F);
        escalar(g0, "cil_i_4", 0.5000000000000002F, 1.0F, 0.37067161183064395F);
        escalar(g0, "cil_i_5", 0.5000000000000001F, 1.0F, 0.37067161183064345F);
        escalar(g0, "cil_i_6", 0.5000000000000002F, 1.0F, 0.3706716118306438F);
        escalar(g0, "cil_i_7", 0.5000000000000002F, 1.0F, 0.3706716118306438F);
        escalar(g0, "cil_i_8", 0.5000000000000001F, 1.0F, 0.37067161183064357F);
        escalar(g0, "cil_i_9", 0.5F, 1.0F, 0.37067161183064345F);
        escalar(g0, "cil_i_10", 0.5F, 1.0F, 0.37067161183064395F);
        escalar(g0, "cil_i_11", 0.5F, 1.0F, 0.370671611830644F);
        escalar(g0, "cil_i_12", 0.5F, 1.0F, 0.370671611830644F);
        escalar(g0, "cil_i_13", 0.5F, 1.0F, 0.37067161183064323F);
        escalar(g0, "cil_i_14", 0.5F, 1.0F, 0.3706716118306431F);
        escalar(g0, "cil_i_15", 0.5F, 1.0F, 0.370671611830644F);
        escalar(g0, "cil_i_ta", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "cil_i_tb", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "guiaa_i", 0.5F, 0.93F, 0.5F);
        escalar(g0, "guiab_i", 0.5F, 0.93F, 0.5F);
        escalar(g0, "vastago_i", 0.8F, 0.9285714285714287F, 0.8F);
        escalar(g0, "biela_i", 1.0F, 0.9999999999999999F, 1.0F);
        escalar(g0, "cil_d_0", 0.5000000000000001F, 1.0F, 0.37067161183064345F);
        escalar(g0, "cil_d_1", 0.5000000000000001F, 1.0F, 0.37067161183064357F);
        escalar(g0, "cil_d_2", 0.5000000000000001F, 1.0F, 0.3706716118306442F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "cil_d_3", 0.5000000000000002F, 1.0F, 0.37067161183064395F);
        escalar(g0, "cil_d_4", 0.5000000000000002F, 1.0F, 0.3706716118306435F);
        escalar(g0, "cil_d_5", 0.5000000000000001F, 1.0F, 0.3706716118306442F);
        escalar(g0, "cil_d_6", 0.5000000000000002F, 1.0F, 0.37067161183064323F);
        escalar(g0, "cil_d_7", 0.5000000000000002F, 1.0F, 0.3706716118306439F);
        escalar(g0, "cil_d_8", 0.5000000000000001F, 1.0F, 0.3706716118306436F);
        escalar(g0, "cil_d_9", 0.5F, 1.0F, 0.37067161183064345F);
        escalar(g0, "cil_d_10", 0.5F, 1.0F, 0.37067161183064357F);
        escalar(g0, "cil_d_11", 0.5F, 1.0F, 0.370671611830644F);
        escalar(g0, "cil_d_12", 0.5F, 1.0F, 0.370671611830644F);
        escalar(g0, "cil_d_13", 0.5F, 1.0F, 0.37067161183064323F);
        escalar(g0, "cil_d_14", 0.5F, 1.0F, 0.3706716118306431F);
        escalar(g0, "cil_d_15", 0.5F, 1.0F, 0.370671611830644F);
        escalar(g0, "cil_d_ta", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "cil_d_tb", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "guiaa_d", 0.5F, 0.93F, 0.5F);
        escalar(g0, "guiab_d", 0.5F, 0.93F, 0.5F);
        escalar(g0, "vastago_d", 0.8F, 0.9285714285714287F, 0.8F);
        escalar(g0, "biela_d", 1.0F, 0.9999999999999999F, 1.0F);
        escalar(g1, "tonel_0", 1.0F, 0.25991798436714153F, 0.25991798436714153F);
        escalar(g1, "tonel_1", 1.0F, 0.25991798436714153F, 0.25991798436714153F);
        escalar(g1, "tonel_2", 1.0F, 0.25991798436714153F, 0.25991798436714153F);
        escalar(g1, "tonel_3", 1.0F, 0.25991798436714153F, 0.25991798436714153F);
        escalar(g1, "tonel_4", 1.0F, 0.25991798436714153F, 0.25991798436714153F);
        escalar(g1, "tonel_tapa32", 0.25F, 0.6F, 0.25F);
        escalar(g1, "tonel_tapa51", 0.25F, 0.6F, 0.25F);
    }
}
