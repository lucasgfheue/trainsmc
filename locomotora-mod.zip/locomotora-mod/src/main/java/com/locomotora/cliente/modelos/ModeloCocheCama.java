package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Coche cama" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloCocheCama {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("coche_cama"), "main"),
            LocomotoraMod.id("textures/entity/coche_cama.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -65.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -65.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -65.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -47.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -47.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -47.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -65.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -65.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -65.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -56.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -47.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -47.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -47.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 47.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 47.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 47.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 65.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 65.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 65.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 47.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 47.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 47.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 56.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 65.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 65.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 65.0F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloCocheCama::crearCapa,
            16.0F,
            ModeloCocheCama::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -56.0F, 56.0F)));

    private ModeloCocheCama() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("caja", CubeListBuilder.create().texOffs(694, 82).addBox(-76.0F, -31.0F, 11.5F, 152.0F, 20.0F, 1.0F).texOffs(0, 106).addBox(-76.0F, -31.0F, -12.5F, 152.0F, 20.0F, 1.0F).texOffs(348, 82).addBox(-75.0F, -12.0F, -11.5F, 150.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_techo_0", CubeListBuilder.create().texOffs(40, 167).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -31.87323500715889F, -11.685937651840831F, -2.3211393658016495F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_1", CubeListBuilder.create().texOffs(350, 167).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.48902060796334F, -9.937072917989997F, -2.470312690854038F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_2", CubeListBuilder.create().texOffs(660, 167).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.82694425906593F, -7.967491422114678F, -2.6194860159064284F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_3", CubeListBuilder.create().texOffs(0, 172).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.857288741065695F, -5.820940417948506F, -2.7686593409588185F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_4", CubeListBuilder.create().texOffs(310, 172).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.557168612775506F, -3.545097907964653F, -2.917832666011209F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_5", CubeListBuilder.create().texOffs(620, 172).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.91103852997129F, -1.190513645981658F, -3.0670059910635965F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_6", CubeListBuilder.create().texOffs(0, 176).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.91103852997129F, 1.1905136459816565F, 3.067005991063599F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_7", CubeListBuilder.create().texOffs(310, 176).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.55716861277551F, 3.5450979079646503F, 2.9178326660112064F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_8", CubeListBuilder.create().texOffs(620, 176).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.857288741065695F, 5.820940417948506F, 2.7686593409588185F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_9", CubeListBuilder.create().texOffs(0, 180).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.82694425906593F, 7.967491422114676F, 2.619486015906428F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_10", CubeListBuilder.create().texOffs(310, 180).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.48902060796334F, 9.937072917989997F, 2.4703126908540387F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_11", CubeListBuilder.create().texOffs(620, 180).addBox(-76.0F, -1.0F, -1.5F, 152.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -31.87323500715889F, 11.685937651840831F, 2.3211393658016495F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_puntaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -26.0F, 0.0F, 1.0F, 26.0F, 23.0F), PartPose.offset(-76.0F, -11.0F, -11.5F));
        g.addOrReplaceChild("caja_puntab", CubeListBuilder.create().texOffs(48, 0).addBox(0.0F, -26.0F, 0.0F, 1.0F, 26.0F, 23.0F), PartPose.offset(75.0F, -11.0F, -11.5F));
        g.addOrReplaceChild("tabiques", CubeListBuilder.create().texOffs(96, 0).addBox(-60.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(144, 0).addBox(-48.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(192, 0).addBox(-36.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(240, 0).addBox(-24.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(288, 0).addBox(-12.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(336, 0).addBox(-0.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(384, 0).addBox(11.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(432, 0).addBox(23.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(480, 0).addBox(35.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(528, 0).addBox(47.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F).texOffs(576, 0).addBox(59.5F, -30.0F, -11.5F, 1.0F, 18.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("camas", CubeListBuilder.create().texOffs(686, 127).addBox(-59.0F, -16.0F, -10.5F, 10.0F, 4.0F, 7.0F).texOffs(416, 141).addBox(-59.0F, -17.0F, -10.5F, 10.0F, 1.0F, 7.0F).texOffs(102, 152).addBox(-56.0F, -18.0F, -10.5F, 7.0F, 1.0F, 7.0F).texOffs(578, 160).addBox(-58.5F, -18.0F, -9.5F, 2.0F, 1.0F, 4.0F).texOffs(720, 127).addBox(-59.0F, -16.0F, 3.5F, 10.0F, 4.0F, 7.0F).texOffs(450, 141).addBox(-59.0F, -17.0F, 3.5F, 10.0F, 1.0F, 7.0F).texOffs(130, 152).addBox(-56.0F, -18.0F, 3.5F, 7.0F, 1.0F, 7.0F).texOffs(590, 160).addBox(-58.5F, -18.0F, 5.5F, 2.0F, 1.0F, 4.0F).texOffs(754, 127).addBox(-47.0F, -16.0F, -10.5F, 10.0F, 4.0F, 7.0F).texOffs(484, 141).addBox(-47.0F, -17.0F, -10.5F, 10.0F, 1.0F, 7.0F).texOffs(158, 152).addBox(-44.0F, -18.0F, -10.5F, 7.0F, 1.0F, 7.0F).texOffs(602, 160).addBox(-46.5F, -18.0F, -9.5F, 2.0F, 1.0F, 4.0F).texOffs(788, 127).addBox(-47.0F, -16.0F, 3.5F, 10.0F, 4.0F, 7.0F).texOffs(518, 141).addBox(-47.0F, -17.0F, 3.5F, 10.0F, 1.0F, 7.0F).texOffs(186, 152).addBox(-44.0F, -18.0F, 3.5F, 7.0F, 1.0F, 7.0F).texOffs(614, 160).addBox(-46.5F, -18.0F, 5.5F, 2.0F, 1.0F, 4.0F).texOffs(822, 127).addBox(-35.0F, -16.0F, -10.5F, 10.0F, 4.0F, 7.0F).texOffs(552, 141).addBox(-35.0F, -17.0F, -10.5F, 10.0F, 1.0F, 7.0F).texOffs(214, 152).addBox(-32.0F, -18.0F, -10.5F, 7.0F, 1.0F, 7.0F).texOffs(626, 160).addBox(-34.5F, -18.0F, -9.5F, 2.0F, 1.0F, 4.0F).texOffs(856, 127).addBox(-35.0F, -16.0F, 3.5F, 10.0F, 4.0F, 7.0F).texOffs(586, 141).addBox(-35.0F, -17.0F, 3.5F, 10.0F, 1.0F, 7.0F).texOffs(242, 152).addBox(-32.0F, -18.0F, 3.5F, 7.0F, 1.0F, 7.0F).texOffs(638, 160).addBox(-34.5F, -18.0F, 5.5F, 2.0F, 1.0F, 4.0F).texOffs(890, 127).addBox(-23.0F, -16.0F, -10.5F, 10.0F, 4.0F, 7.0F).texOffs(620, 141).addBox(-23.0F, -17.0F, -10.5F, 10.0F, 1.0F, 7.0F).texOffs(270, 152).addBox(-20.0F, -18.0F, -10.5F, 7.0F, 1.0F, 7.0F).texOffs(650, 160).addBox(-22.5F, -18.0F, -9.5F, 2.0F, 1.0F, 4.0F).texOffs(924, 127).addBox(-23.0F, -16.0F, 3.5F, 10.0F, 4.0F, 7.0F).texOffs(654, 141).addBox(-23.0F, -17.0F, 3.5F, 10.0F, 1.0F, 7.0F).texOffs(298, 152).addBox(-20.0F, -18.0F, 3.5F, 7.0F, 1.0F, 7.0F).texOffs(662, 160).addBox(-22.5F, -18.0F, 5.5F, 2.0F, 1.0F, 4.0F).texOffs(958, 127).addBox(-11.0F, -16.0F, -10.5F, 10.0F, 4.0F, 7.0F).texOffs(688, 141).addBox(-11.0F, -17.0F, -10.5F, 10.0F, 1.0F, 7.0F).texOffs(326, 152).addBox(-8.0F, -18.0F, -10.5F, 7.0F, 1.0F, 7.0F).texOffs(674, 160).addBox(-10.5F, -18.0F, -9.5F, 2.0F, 1.0F, 4.0F).texOffs(0, 141).addBox(-11.0F, -16.0F, 3.5F, 10.0F, 4.0F, 7.0F).texOffs(722, 141).addBox(-11.0F, -17.0F, 3.5F, 10.0F, 1.0F, 7.0F).texOffs(354, 152).addBox(-8.0F, -18.0F, 3.5F, 7.0F, 1.0F, 7.0F).texOffs(686, 160).addBox(-10.5F, -18.0F, 5.5F, 2.0F, 1.0F, 4.0F).texOffs(34, 141).addBox(1.0F, -16.0F, -10.5F, 10.0F, 4.0F, 7.0F).texOffs(756, 141).addBox(1.0F, -17.0F, -10.5F, 10.0F, 1.0F, 7.0F).texOffs(382, 152).addBox(4.0F, -18.0F, -10.5F, 7.0F, 1.0F, 7.0F).texOffs(698, 160).addBox(1.5F, -18.0F, -9.5F, 2.0F, 1.0F, 4.0F).texOffs(68, 141).addBox(1.0F, -16.0F, 3.5F, 10.0F, 4.0F, 7.0F).texOffs(790, 141).addBox(1.0F, -17.0F, 3.5F, 10.0F, 1.0F, 7.0F).texOffs(410, 152).addBox(4.0F, -18.0F, 3.5F, 7.0F, 1.0F, 7.0F).texOffs(710, 160).addBox(1.5F, -18.0F, 5.5F, 2.0F, 1.0F, 4.0F).texOffs(102, 141).addBox(13.0F, -16.0F, -10.5F, 10.0F, 4.0F, 7.0F).texOffs(824, 141).addBox(13.0F, -17.0F, -10.5F, 10.0F, 1.0F, 7.0F).texOffs(438, 152).addBox(16.0F, -18.0F, -10.5F, 7.0F, 1.0F, 7.0F).texOffs(722, 160).addBox(13.5F, -18.0F, -9.5F, 2.0F, 1.0F, 4.0F).texOffs(136, 141).addBox(13.0F, -16.0F, 3.5F, 10.0F, 4.0F, 7.0F).texOffs(858, 141).addBox(13.0F, -17.0F, 3.5F, 10.0F, 1.0F, 7.0F).texOffs(466, 152).addBox(16.0F, -18.0F, 3.5F, 7.0F, 1.0F, 7.0F).texOffs(734, 160).addBox(13.5F, -18.0F, 5.5F, 2.0F, 1.0F, 4.0F).texOffs(170, 141).addBox(25.0F, -16.0F, -10.5F, 10.0F, 4.0F, 7.0F).texOffs(892, 141).addBox(25.0F, -17.0F, -10.5F, 10.0F, 1.0F, 7.0F).texOffs(494, 152).addBox(28.0F, -18.0F, -10.5F, 7.0F, 1.0F, 7.0F).texOffs(746, 160).addBox(25.5F, -18.0F, -9.5F, 2.0F, 1.0F, 4.0F).texOffs(204, 141).addBox(25.0F, -16.0F, 3.5F, 10.0F, 4.0F, 7.0F).texOffs(926, 141).addBox(25.0F, -17.0F, 3.5F, 10.0F, 1.0F, 7.0F).texOffs(522, 152).addBox(28.0F, -18.0F, 3.5F, 7.0F, 1.0F, 7.0F).texOffs(758, 160).addBox(25.5F, -18.0F, 5.5F, 2.0F, 1.0F, 4.0F).texOffs(238, 141).addBox(37.0F, -16.0F, -10.5F, 10.0F, 4.0F, 7.0F).texOffs(960, 141).addBox(37.0F, -17.0F, -10.5F, 10.0F, 1.0F, 7.0F).texOffs(550, 152).addBox(40.0F, -18.0F, -10.5F, 7.0F, 1.0F, 7.0F).texOffs(770, 160).addBox(37.5F, -18.0F, -9.5F, 2.0F, 1.0F, 4.0F).texOffs(272, 141).addBox(37.0F, -16.0F, 3.5F, 10.0F, 4.0F, 7.0F).texOffs(0, 152).addBox(37.0F, -17.0F, 3.5F, 10.0F, 1.0F, 7.0F).texOffs(578, 152).addBox(40.0F, -18.0F, 3.5F, 7.0F, 1.0F, 7.0F).texOffs(782, 160).addBox(37.5F, -18.0F, 5.5F, 2.0F, 1.0F, 4.0F).texOffs(306, 141).addBox(49.0F, -16.0F, -10.5F, 10.0F, 4.0F, 7.0F).texOffs(34, 152).addBox(49.0F, -17.0F, -10.5F, 10.0F, 1.0F, 7.0F).texOffs(606, 152).addBox(52.0F, -18.0F, -10.5F, 7.0F, 1.0F, 7.0F).texOffs(794, 160).addBox(49.5F, -18.0F, -9.5F, 2.0F, 1.0F, 4.0F).texOffs(340, 141).addBox(49.0F, -16.0F, 3.5F, 10.0F, 4.0F, 7.0F).texOffs(68, 152).addBox(49.0F, -17.0F, 3.5F, 10.0F, 1.0F, 7.0F).texOffs(634, 152).addBox(52.0F, -18.0F, 3.5F, 7.0F, 1.0F, 7.0F).texOffs(806, 160).addBox(49.5F, -18.0F, 5.5F, 2.0F, 1.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(818, 160).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-65.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-65.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-65.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(828, 160).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-56.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i2_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(838, 160).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-47.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i2_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-47.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i2_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-47.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(848, 160).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-65.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-65.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-65.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(858, 160).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-56.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d2_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(868, 160).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-47.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d2_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-47.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d2_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-47.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(662, 152).addBox(-70.0F, -9.0F, 7.0F, 28.0F, 6.0F, 1.0F).texOffs(720, 152).addBox(-70.0F, -9.0F, -8.0F, 28.0F, 6.0F, 1.0F).texOffs(878, 160).addBox(-67.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(888, 160).addBox(-67.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(898, 160).addBox(-58.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(908, 160).addBox(-58.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(918, 160).addBox(-49.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(928, 160).addBox(-49.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_pivote", CubeListBuilder.create().texOffs(466, 106).addBox(-59.0F, -11.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 160).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(47.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(47.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(47.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(948, 160).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(56.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i2_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(958, 160).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(65.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i2_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(65.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i2_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(65.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(968, 160).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(47.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(47.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(47.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(978, 160).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(56.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(56.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d2_0", CubeListBuilder.create().texOffs(374, 141).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(930, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(988, 160).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(65.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d2_1", CubeListBuilder.create().texOffs(948, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(400, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(65.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d2_2", CubeListBuilder.create().texOffs(966, 180).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(408, 141).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(65.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(778, 152).addBox(42.0F, -9.0F, 7.0F, 28.0F, 6.0F, 1.0F).texOffs(836, 152).addBox(42.0F, -9.0F, -8.0F, 28.0F, 6.0F, 1.0F).texOffs(998, 160).addBox(45.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(1008, 160).addBox(45.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(0, 167).addBox(54.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(10, 167).addBox(54.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(20, 167).addBox(63.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(30, 167).addBox(63.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_pivote", CubeListBuilder.create().texOffs(506, 106).addBox(53.0F, -11.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bajo_piso", CubeListBuilder.create().texOffs(0, 82).addBox(-76.0F, -11.0F, -11.0F, 152.0F, 2.0F, 22.0F).texOffs(306, 106).addBox(-34.0F, -9.0F, -8.0F, 24.0F, 4.0F, 16.0F).texOffs(386, 106).addBox(10.0F, -9.0F, -8.0F, 24.0F, 4.0F, 16.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuellei", CubeListBuilder.create().texOffs(588, 49).addBox(-78.0F, -31.0F, -6.0F, 2.0F, 19.0F, 12.0F).texOffs(644, 49).addBox(-78.0F, -13.0F, -11.0F, 2.0F, 4.0F, 22.0F).texOffs(984, 180).addBox(-80.0F, -13.0F, -0.5F, 2.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topefi_0", CubeListBuilder.create().texOffs(348, 49).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(624, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("topefi_1", CubeListBuilder.create().texOffs(368, 49).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(682, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefi_2", CubeListBuilder.create().texOffs(388, 49).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(740, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_0", CubeListBuilder.create().texOffs(590, 127).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(238, 127).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("topefic_1", CubeListBuilder.create().texOffs(596, 127).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(260, 127).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_2", CubeListBuilder.create().texOffs(602, 127).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(282, 127).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefic_3", CubeListBuilder.create().texOffs(608, 127).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(304, 127).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_0", CubeListBuilder.create().texOffs(408, 49).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(798, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("topefd_1", CubeListBuilder.create().texOffs(428, 49).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(856, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefd_2", CubeListBuilder.create().texOffs(448, 49).addBox(-81.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(914, 0).addBox(-81.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_0", CubeListBuilder.create().texOffs(614, 127).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(326, 127).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("topefdc_1", CubeListBuilder.create().texOffs(620, 127).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(348, 127).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_2", CubeListBuilder.create().texOffs(626, 127).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(370, 127).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topefdc_3", CubeListBuilder.create().texOffs(632, 127).addBox(-82.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(392, 127).addBox(-82.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("estriboi", CubeListBuilder.create().texOffs(996, 180).addBox(-73.0F, -8.0F, -12.5F, 6.0F, 1.0F, 2.0F).texOffs(0, 184).addBox(-73.0F, -8.0F, 10.5F, 6.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("pasamanosia", CubeListBuilder.create().texOffs(546, 106).addBox(-74.0F, -28.0F, -13.5F, 1.0F, 15.0F, 1.0F).texOffs(550, 106).addBox(-74.0F, -28.0F, 12.5F, 1.0F, 15.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("pasamanosib", CubeListBuilder.create().texOffs(554, 106).addBox(-67.0F, -28.0F, -13.5F, 1.0F, 15.0F, 1.0F).texOffs(558, 106).addBox(-67.0F, -28.0F, 12.5F, 1.0F, 15.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuelled", CubeListBuilder.create().texOffs(616, 49).addBox(76.0F, -31.0F, -6.0F, 2.0F, 19.0F, 12.0F).texOffs(692, 49).addBox(76.0F, -13.0F, -11.0F, 2.0F, 4.0F, 22.0F).texOffs(990, 180).addBox(78.0F, -13.0F, -0.5F, 2.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topeti_0", CubeListBuilder.create().texOffs(468, 49).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(0, 49).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("topeti_1", CubeListBuilder.create().texOffs(488, 49).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(58, 49).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topeti_2", CubeListBuilder.create().texOffs(508, 49).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(116, 49).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_0", CubeListBuilder.create().texOffs(638, 127).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(414, 127).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("topetic_1", CubeListBuilder.create().texOffs(644, 127).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(436, 127).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_2", CubeListBuilder.create().texOffs(650, 127).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(458, 127).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetic_3", CubeListBuilder.create().texOffs(656, 127).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(480, 127).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_0", CubeListBuilder.create().texOffs(528, 49).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(174, 49).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("topetd_1", CubeListBuilder.create().texOffs(548, 49).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(232, 49).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetd_2", CubeListBuilder.create().texOffs(568, 49).addBox(78.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(290, 49).addBox(78.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_0", CubeListBuilder.create().texOffs(662, 127).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(502, 127).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("topetdc_1", CubeListBuilder.create().texOffs(668, 127).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(524, 127).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("topetdc_2", CubeListBuilder.create().texOffs(674, 127).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(546, 127).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("topetdc_3", CubeListBuilder.create().texOffs(680, 127).addBox(81.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(568, 127).addBox(81.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("estribod", CubeListBuilder.create().texOffs(16, 184).addBox(67.0F, -8.0F, -12.5F, 6.0F, 1.0F, 2.0F).texOffs(32, 184).addBox(67.0F, -8.0F, 10.5F, 6.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("pasamanosda", CubeListBuilder.create().texOffs(562, 106).addBox(66.0F, -28.0F, -13.5F, 1.0F, 15.0F, 1.0F).texOffs(566, 106).addBox(66.0F, -28.0F, 12.5F, 1.0F, 15.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("pasamanosdb", CubeListBuilder.create().texOffs(570, 106).addBox(73.0F, -28.0F, -13.5F, 1.0F, 15.0F, 1.0F).texOffs(574, 106).addBox(73.0F, -28.0F, 12.5F, 1.0F, 15.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("vent0_0", CubeListBuilder.create().texOffs(894, 152).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(578, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-54.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent0_1", CubeListBuilder.create().texOffs(928, 152).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(612, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-54.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent1_0", CubeListBuilder.create().texOffs(962, 152).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(646, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-42.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent1_1", CubeListBuilder.create().texOffs(0, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(680, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-42.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent2_0", CubeListBuilder.create().texOffs(34, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(714, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-30.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent2_1", CubeListBuilder.create().texOffs(68, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(748, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-30.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent3_0", CubeListBuilder.create().texOffs(102, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(782, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-18.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent3_1", CubeListBuilder.create().texOffs(136, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(816, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-18.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent4_0", CubeListBuilder.create().texOffs(170, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(850, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(-6.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent4_1", CubeListBuilder.create().texOffs(204, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(884, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(-6.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent5_0", CubeListBuilder.create().texOffs(238, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(918, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(6.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent5_1", CubeListBuilder.create().texOffs(272, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(952, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(6.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent6_0", CubeListBuilder.create().texOffs(306, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(986, 106).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(18.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent6_1", CubeListBuilder.create().texOffs(340, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(0, 127).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(18.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent7_0", CubeListBuilder.create().texOffs(374, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(34, 127).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(30.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent7_1", CubeListBuilder.create().texOffs(408, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(68, 127).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(30.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent8_0", CubeListBuilder.create().texOffs(442, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(102, 127).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(42.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent8_1", CubeListBuilder.create().texOffs(476, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(136, 127).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(42.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("vent9_0", CubeListBuilder.create().texOffs(510, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(170, 127).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offset(54.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("vent9_1", CubeListBuilder.create().texOffs(544, 160).addBox(-6.0F, -38.0F, -2.5F, 12.0F, 2.0F, 5.0F).texOffs(204, 127).addBox(-2.5F, -38.0F, -6.0F, 5.0F, 2.0F, 12.0F), PartPose.offsetAndRotation(54.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "caja_techo_0", 1.0001315789473686F, 1.0F, 0.8025552363150691F);
        escalar(g0, "caja_techo_1", 1.0001315789473686F, 1.0F, 0.8025552363150689F);
        escalar(g0, "caja_techo_2", 1.0001315789473686F, 1.0F, 0.8025552363150705F);
        escalar(g0, "caja_techo_3", 1.0001315789473686F, 1.0F, 0.8025552363150693F);
        escalar(g0, "caja_techo_4", 1.0001315789473686F, 1.0F, 0.8025552363150693F);
        escalar(g0, "caja_techo_5", 1.0001315789473686F, 1.0F, 0.8025552363150704F);
        escalar(g0, "caja_techo_6", 1.0001315789473686F, 1.0F, 0.8025552363150691F);
        escalar(g0, "caja_techo_7", 1.0001315789473686F, 1.0F, 0.8025552363150702F);
        escalar(g0, "caja_techo_8", 1.0001315789473686F, 1.0F, 0.8025552363150698F);
        escalar(g0, "caja_techo_9", 1.0001315789473686F, 1.0F, 0.8025552363150693F);
        escalar(g0, "caja_techo_10", 1.0001315789473686F, 1.0F, 0.8025552363150698F);
        escalar(g0, "caja_techo_11", 1.0001315789473686F, 1.0F, 0.8025552363150691F);
        escalar(g0, "topefi_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefi_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topefdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topefdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topeti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topeti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetd_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetd_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "topetdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "topetdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "vent0_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent0_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent1_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent1_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent2_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent2_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent3_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent3_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent4_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent4_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent5_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent5_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent6_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent6_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent7_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent7_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent8_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent8_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent9_0", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
        escalar(g0, "vent9_1", 0.15397992208521447F, 1.0F, 0.15397992208521447F);
    }
}
