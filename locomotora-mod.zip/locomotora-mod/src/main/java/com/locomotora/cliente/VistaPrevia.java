package com.locomotora.cliente;

import com.locomotora.via.ConfigVia;
import com.locomotora.via.DatosVia;
import com.locomotora.via.Pieza;
import com.locomotora.via.ViaItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * Con una vía en la mano y mirando el piso, muestra dónde va a quedar la pieza: el contorno de cada bloque (verde si
 * está libre, rojo si hay algo en el camino) y el trazo de los rieles.
 */
public final class VistaPrevia {
    private static String ultimaClave = "";
    private static Pieza ultima;

    private VistaPrevia() {
    }

    public static void dibujar(RenderLevelStageEvent evento) {
        if (evento.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
            return;
        }
        Minecraft mc = Minecraft.getInstance();
        Player jugador = mc.player;
        Level level = mc.level;
        if (jugador == null || level == null || !(mc.hitResult instanceof BlockHitResult golpe)
                || golpe.getType() != HitResult.Type.BLOCK) {
            return;
        }
        ItemStack stack = jugador.getMainHandItem();
        if (!(stack.getItem() instanceof ViaItem)) {
            stack = jugador.getOffhandItem();
            if (!(stack.getItem() instanceof ViaItem)) {
                return;
            }
        }
        ConfigVia config = ViaItem.config(stack);
        String clave = golpe.getBlockPos() + "|" + golpe.getDirection() + "|" + jugador.getDirection() + "|"
                + DatosVia.guardarConfig(config) + "|" + level.getBlockState(golpe.getBlockPos());
        if (!clave.equals(ultimaClave) || ultima == null) {
            ultima = ViaItem.piezaAPoner(level, golpe.getBlockPos(), golpe.getDirection(), jugador.getDirection(), config);
            ultimaClave = clave;
        }
        Pieza p = ultima;

        PoseStack pose = evento.getPoseStack();
        Vec3 camara = evento.getCamera().getPosition();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer lineas = buffers.getBuffer(RenderType.lines());
        // todo relativo a la cámara (en double), así no tiembla lejos del centro del mundo
        double cx = camara.x;
        double cy = camara.y;
        double cz = camara.z;
        for (Pieza.Celda c : p.celdas()) {
            BlockPos pos = new BlockPos(c.x, c.y, c.z);
            boolean libre = ViaItem.validarCelda(level, jugador, pos) == null;
            float r = libre ? 0.3F : 1.0F;
            float g = libre ? 1.0F : 0.25F;
            float b = libre ? 0.4F : 0.25F;
            LevelRenderer.renderLineBox(pose, lineas,
                    new AABB(c.x - cx, c.y - cy, c.z - cz, c.x + 1 - cx, c.y + 0.125 - cy, c.z + 1 - cz), r, g, b, 0.8F);
        }
        // el trazo de los rieles (por el centro de la vía)
        PoseStack.Pose ultimaPose = pose.last();
        for (int ruta = 0; ruta < p.cantidadRutas(); ruta++) {
            Pieza.Trazo tr = p.ruta(ruta).trazo;
            int n = Math.max(2, (int) Math.ceil(tr.largo() / 0.25));
            double[] previo = null;
            for (int k = 0; k <= n; k++) {
                double[] l = tr.punto(tr.largo() * k / n);
                double[] m = p.aMundo(l[0], l[1], l[2] + Pieza.ALTO_PROPIO + 0.02);
                m[0] -= cx;
                m[1] -= cy;
                m[2] -= cz;
                if (previo != null) {
                    float dx = (float) (m[0] - previo[0]);
                    float dy = (float) (m[1] - previo[1]);
                    float dz = (float) (m[2] - previo[2]);
                    float largo = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
                    if (largo > 1.0E-4F) {
                        dx /= largo;
                        dy /= largo;
                        dz /= largo;
                        lineas.addVertex(ultimaPose, (float) previo[0], (float) previo[1], (float) previo[2])
                                .setColor(255, 230, 120, 230).setNormal(ultimaPose, dx, dy, dz);
                        lineas.addVertex(ultimaPose, (float) m[0], (float) m[1], (float) m[2])
                                .setColor(255, 230, 120, 230).setNormal(ultimaPose, dx, dy, dz);
                    }
                }
                previo = m;
            }
        }
        buffers.endBatch(RenderType.lines());
    }
}
