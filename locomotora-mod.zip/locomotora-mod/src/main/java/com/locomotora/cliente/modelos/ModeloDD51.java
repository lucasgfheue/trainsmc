package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "JNR DD51" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloDD51 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("dd51"), "main"),
            LocomotoraMod.id("textures/entity/dd51.png"),
            List.of(
                new DatosModelo.Animada("bogiefi0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -64.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -64.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -64.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -44.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -44.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefi1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -44.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -64.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -64.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -64.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -44.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -44.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiefd1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -44.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieci0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -10.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieci0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -10.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieci0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -10.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieci1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 10.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieci1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 10.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieci1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 10.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiecd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -10.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiecd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -10.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiecd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -10.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogiecd1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 10.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogiecd1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 10.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogiecd1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 10.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 64.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 64.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogieti1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 64.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 44.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 64.0F, -4.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 64.0F, -4.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogietd1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 64.0F, -4.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, -10.280000000000001F, -26.5F, 0.0F, "cuerpo", 4.8F, -7.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.15F, 0.0F, -10.0F, -25.0F, 0.15F, "cuerpo", -0.24F, -4.0F, 0.0F)),
            ModeloDD51::crearCapa,
            16.0F,
            ModeloDD51::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -54.0F, 54.0F)));

    private ModeloDD51() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
        escalas2(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogiefi0_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(984, 131).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-64.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogiefi0_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-64.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi0_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-64.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefi1_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(994, 131).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-44.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogiefi1_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefi1_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd0_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1004, 131).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-64.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogiefd0_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-64.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd0_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-64.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiefd1_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1014, 131).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-44.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogiefd1_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiefd1_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogief", CubeListBuilder.create().texOffs(800, 107).addBox(-69.5F, -9.0F, 7.0F, 31.0F, 6.0F, 1.0F).texOffs(864, 107).addBox(-69.5F, -9.0F, -8.0F, 31.0F, 6.0F, 1.0F).texOffs(0, 137).addBox(-66.0F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(10, 137).addBox(-66.0F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(20, 137).addBox(-46.0F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(30, 137).addBox(-46.0F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogieci0_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 137).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-10.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogieci0_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieci0_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogieci1_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 137).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(10.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogieci1_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(10.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieci1_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(10.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiecd0_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 137).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-10.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogiecd0_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiecd0_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiecd1_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 137).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(10.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogiecd1_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(10.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogiecd1_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(10.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiec", CubeListBuilder.create().texOffs(928, 107).addBox(-15.5F, -9.0F, 7.0F, 31.0F, 6.0F, 1.0F).texOffs(0, 118).addBox(-15.5F, -9.0F, -8.0F, 31.0F, 6.0F, 1.0F).texOffs(80, 137).addBox(-12.0F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(90, 137).addBox(-12.0F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(100, 137).addBox(8.0F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(110, 137).addBox(8.0F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogieti0_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(120, 137).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogieti0_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti0_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogieti1_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(130, 137).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(64.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogieti1_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogieti1_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd0_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(140, 137).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogietd0_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd0_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogietd1_0", CubeListBuilder.create().texOffs(646, 107).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(450, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(150, 137).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(64.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("bogietd1_1", CubeListBuilder.create().texOffs(470, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(704, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogietd1_2", CubeListBuilder.create().texOffs(490, 142).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(712, 107).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogiet", CubeListBuilder.create().texOffs(64, 118).addBox(38.5F, -9.0F, 7.0F, 31.0F, 6.0F, 1.0F).texOffs(128, 118).addBox(38.5F, -9.0F, -8.0F, 31.0F, 6.0F, 1.0F).texOffs(160, 137).addBox(42.0F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(170, 137).addBox(42.0F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(180, 137).addBox(62.0F, -6.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(190, 137).addBox(62.0F, -6.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(0, 50).addBox(-80.0F, -15.0F, -13.5F, 160.0F, 4.0F, 27.0F).texOffs(0, 81).addBox(-26.0F, -11.0F, -10.0F, 14.0F, 6.0F, 20.0F).texOffs(68, 81).addBox(12.0F, -11.0F, -10.0F, 14.0F, 6.0F, 20.0F).texOffs(108, 150).addBox(-76.0F, -25.0F, 12.5F, 60.0F, 1.0F, 1.0F).texOffs(230, 150).addBox(-76.0F, -25.0F, -13.5F, 60.0F, 1.0F, 1.0F).texOffs(720, 107).addBox(-76.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(724, 107).addBox(-76.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(728, 107).addBox(-61.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(732, 107).addBox(-61.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(736, 107).addBox(-46.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(740, 107).addBox(-46.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(744, 107).addBox(-32.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(748, 107).addBox(-32.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(752, 107).addBox(-17.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(756, 107).addBox(-17.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(884, 0).addBox(-82.0F, -15.0F, -12.0F, 2.0F, 8.0F, 24.0F).texOffs(856, 125).addBox(-86.0F, -12.0F, -1.5F, 4.0F, 3.0F, 3.0F).texOffs(352, 150).addBox(16.0F, -25.0F, 12.5F, 60.0F, 1.0F, 1.0F).texOffs(474, 150).addBox(16.0F, -25.0F, -13.5F, 60.0F, 1.0F, 1.0F).texOffs(760, 107).addBox(16.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(764, 107).addBox(16.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(768, 107).addBox(31.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(772, 107).addBox(31.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(776, 107).addBox(46.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(780, 107).addBox(46.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(784, 107).addBox(60.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(788, 107).addBox(60.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(792, 107).addBox(75.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(796, 107).addBox(75.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(936, 0).addBox(80.0F, -15.0F, -12.0F, 2.0F, 8.0F, 24.0F).texOffs(870, 125).addBox(82.0F, -12.0F, -1.5F, 4.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_f", CubeListBuilder.create().texOffs(564, 0).addBox(-72.0F, -28.0F, -11.0F, 58.0F, 13.0F, 22.0F).texOffs(136, 81).addBox(-72.0F, -31.0F, -8.0F, 58.0F, 3.0F, 16.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_f_cantoi_0", CubeListBuilder.create().texOffs(596, 150).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.0F, -28.46352549156242F, -10.92658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_f_cantoi_1", CubeListBuilder.create().texOffs(714, 150).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.0F, -29.34520337000113F, -10.640110266005152F, -2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_f_cantoi_2", CubeListBuilder.create().texOffs(832, 150).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.0F, -30.09520337000113F, -10.095203370001132F, -2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_f_cantoi_3", CubeListBuilder.create().texOffs(0, 153).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.0F, -30.640110266005152F, -9.345203370001132F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_f_cantoi_4", CubeListBuilder.create().texOffs(118, 153).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.0F, -30.92658477444273F, -8.463525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_f_cantod_0", CubeListBuilder.create().texOffs(236, 153).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.0F, -28.46352549156242F, 10.92658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_f_cantod_1", CubeListBuilder.create().texOffs(354, 153).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.0F, -29.34520337000113F, 10.640110266005152F, 2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_f_cantod_2", CubeListBuilder.create().texOffs(472, 153).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.0F, -30.09520337000113F, 10.095203370001132F, 2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_f_cantod_3", CubeListBuilder.create().texOffs(590, 153).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.0F, -30.640110266005152F, 9.345203370001132F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_f_cantod_4", CubeListBuilder.create().texOffs(708, 153).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.0F, -30.92658477444273F, 8.463525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_f_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 44.0F), PartPose.offset(-72.0F, -28.0F, -11.0F));
        g.addOrReplaceChild("capo_f_tapab", CubeListBuilder.create().texOffs(90, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 44.0F), PartPose.offset(-15.0F, -28.0F, -11.0F));
        g.addOrReplaceChild("capo_f_punta_0", CubeListBuilder.create().texOffs(120, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.95374908821194F, -16.749999858280106F, -10.970639851927483F, -1.6015705424892326F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_1", CubeListBuilder.create().texOffs(142, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.95374908821194F, -20.249999574840324F, -10.970639851927483F, -1.6015705424892326F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_2", CubeListBuilder.create().texOffs(164, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.95374908821194F, -23.74999929140054F, -10.970639851927483F, -1.6015705424892326F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_3", CubeListBuilder.create().texOffs(186, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.82882910424499F, -27.049999709775754F, -10.96909832151049F, -1.608193122663506F, -0.0024945560459829637F, -1.5305118789165786F));
        g.addOrReplaceChild("capo_f_punta_4", CubeListBuilder.create().texOffs(974, 142).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.57113529824511F, -29.000000094577018F, -10.969147254459108F, -1.6262951111667632F, -0.005135373762930682F, -1.4101676413868922F));
        g.addOrReplaceChild("capo_f_punta_5", CubeListBuilder.create().texOffs(976, 146).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.30017668798287F, -29.79999974398934F, -10.977762674559377F, -1.645045530594016F, 0.0043662999505738095F, -1.404196166337959F));
        g.addOrReplaceChild("capo_f_punta_6", CubeListBuilder.create().texOffs(80, 150).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.07982683688981F, -30.2F, -10.751550099731164F, -3.141592653589793F, -0.7711669425231393F, 0.0F));
        g.addOrReplaceChild("capo_f_punta_7", CubeListBuilder.create().texOffs(32, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.35925248650527F, -16.749999858280106F, -10.827808537994116F, -1.816884245870526F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_8", CubeListBuilder.create().texOffs(50, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.35925248650527F, -20.249999574840324F, -10.827808537994116F, -1.816884245870526F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_9", CubeListBuilder.create().texOffs(68, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.35925248650527F, -23.74999929140054F, -10.827808537994116F, -1.816884245870526F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_10", CubeListBuilder.create().texOffs(86, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.02778647643402F, -27.049999709775754F, -10.831828974767909F, -1.8561271547243074F, 0.0025364737979882155F, -1.3601206092079305F));
        g.addOrReplaceChild("capo_f_punta_11", CubeListBuilder.create().texOffs(118, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.36688131162188F, -29.000000094577018F, -10.851200260509442F, -2.016469792901454F, 0.029614812646366027F, -0.8818309222153989F));
        g.addOrReplaceChild("capo_f_punta_12", CubeListBuilder.create().texOffs(126, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.70906298754352F, -29.79999974398934F, -10.900155818878705F, -2.1144478971920955F, 0.06484239483564995F, -0.8834119212928013F));
        g.addOrReplaceChild("capo_f_punta_13", CubeListBuilder.create().texOffs(104, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.1209024329633F, -16.749999858280106F, -10.52316489081791F, -2.1235447695502305F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_14", CubeListBuilder.create().texOffs(122, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.1209024329633F, -20.249999574840324F, -10.52316489081791F, -2.1235447695502305F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_15", CubeListBuilder.create().texOffs(140, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.1209024329633F, -23.74999929140054F, -10.52316489081791F, -2.1235447695502305F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_16", CubeListBuilder.create().texOffs(158, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.66124132268348F, -27.049999709775754F, -10.54355666825774F, -2.19266473952565F, 0.01261236996282697F, -1.2825026601346003F));
        g.addOrReplaceChild("capo_f_punta_17", CubeListBuilder.create().texOffs(134, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.76985368749358F, -29.000000094577018F, -10.604268623941067F, -2.463600686278053F, 0.06840111621512528F, -0.7472710495067858F));
        g.addOrReplaceChild("capo_f_punta_18", CubeListBuilder.create().texOffs(142, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.91972614050907F, -29.79999974398934F, -10.72372982427828F, -2.571761616140123F, 0.13588026951089463F, -0.7629176179512536F));
        g.addOrReplaceChild("capo_f_punta_19", CubeListBuilder.create().texOffs(246, 157).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.53160670570338F, -30.19999978434775F, -10.617779654467055F, -3.141588406084092F, -1.0370481327870713F, -9.743754240167072e-06F));
        g.addOrReplaceChild("capo_f_punta_20", CubeListBuilder.create().texOffs(984, 146).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.28094414648606F, -30.286658908160025F, -10.124118820628043F, -2.8324269091165086F, -0.4875527940637917F, -0.1504582534348681F));
        g.addOrReplaceChild("capo_f_punta_21", CubeListBuilder.create().texOffs(176, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.69189092324552F, -16.749999858280106F, -10.025301847096227F, -2.43633071209467F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_22", CubeListBuilder.create().texOffs(194, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.69189092324552F, -20.249999574840324F, -10.025301847096227F, -2.43633071209467F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_23", CubeListBuilder.create().texOffs(212, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.69189092324552F, -23.74999929140054F, -10.025301847096227F, -2.43633071209467F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_24", CubeListBuilder.create().texOffs(230, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.15678897050779F, -27.049999709775754F, -10.051479331782625F, -2.523814982936082F, 0.015962792950132827F, -1.2383799873227097F));
        g.addOrReplaceChild("capo_f_punta_25", CubeListBuilder.create().texOffs(896, 146).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.12602901406555F, -29.000000094577018F, -10.122053590364448F, -2.7950572145422F, -0.1426939426629324F, -0.7551921932539748F));
        g.addOrReplaceChild("capo_f_punta_26", CubeListBuilder.create().texOffs(906, 146).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-73.14469264822199F, -29.79999974398934F, -10.25640859655899F, -2.9105197287827798F, -0.05252887035221482F, -0.7349085491946771F));
        g.addOrReplaceChild("capo_f_punta_27", CubeListBuilder.create().texOffs(992, 146).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.67525516781167F, -30.236697736121396F, -10.091778957161655F, -2.9028097411323706F, -0.8860708659323833F, -0.3184232813209676F));
        g.addOrReplaceChild("capo_f_punta_28", CubeListBuilder.create().texOffs(1000, 146).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.3457480247702F, -30.484827681468037F, -9.548205729140497F, -2.734348022252183F, -0.29007791380485703F, -0.37474690788010867F));
        g.addOrReplaceChild("capo_f_punta_29", CubeListBuilder.create().texOffs(510, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.18338659569062F, -16.749999858280106F, -9.21334320398993F, -2.713759465827498F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_30", CubeListBuilder.create().texOffs(530, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.18338659569062F, -20.249999574840324F, -9.21334320398993F, -2.713759465827498F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_31", CubeListBuilder.create().texOffs(550, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.18338659569062F, -23.74999929140054F, -9.21334320398993F, -2.713759465827498F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_32", CubeListBuilder.create().texOffs(570, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-75.59695483804062F, -27.049999709775754F, -9.205112460095195F, -2.7938426431885013F, -0.004966532831385154F, -1.2090980920817802F));
        g.addOrReplaceChild("capo_f_punta_33", CubeListBuilder.create().texOffs(830, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-74.46545960133771F, -29.000000094577018F, -9.185647589582038F, -2.9866899617916136F, -0.11061434917723063F, -0.6477481404224675F));
        g.addOrReplaceChild("capo_f_punta_34", CubeListBuilder.create().texOffs(842, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.37422798176394F, -29.79999974398934F, -9.17412165370163F, -3.0561472964435152F, -0.057914687476759104F, -0.6370462240721322F));
        g.addOrReplaceChild("capo_f_punta_35", CubeListBuilder.create().texOffs(1014, 142).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.79697686631357F, -30.323653517039247F, -9.068614030890457F, -3.0410311091270477F, 0.037923081881116344F, -1.2374006755040419F));
        g.addOrReplaceChild("capo_f_punta_36", CubeListBuilder.create().texOffs(854, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.38294694569203F, -30.686775414615084F, -8.752141615914116F, -2.971748051641747F, -0.20097140011284556F, -0.5144210897123142F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("capo_f_punta_37", CubeListBuilder.create().texOffs(208, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.58670444926881F, -16.749999858280106F, -7.930885643540469F, -2.922670768683278F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_38", CubeListBuilder.create().texOffs(230, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.58670444926881F, -20.249999574840324F, -7.930885643540469F, -2.922670768683278F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_39", CubeListBuilder.create().texOffs(252, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.58670444926881F, -23.74999929140054F, -7.930885643540469F, -2.922670768683278F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_40", CubeListBuilder.create().texOffs(274, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-75.95478403295567F, -27.049999709775754F, -7.853407443887145F, -2.9733692898465223F, -0.04625398305122669F, -1.1836778877002294F));
        g.addOrReplaceChild("capo_f_punta_41", CubeListBuilder.create().texOffs(824, 131).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-74.73060389716838F, -29.000000094577018F, -7.6811296212184965F, -3.0770153846794357F, -0.11403661038634015F, -0.5928463813176901F));
        g.addOrReplaceChild("capo_f_punta_42", CubeListBuilder.create().texOffs(838, 131).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.53761216312395F, -29.79999974398934F, -7.479103772701189F, -3.108822931422617F, -0.09845548168927623F, -0.5858153137603659F));
        g.addOrReplaceChild("capo_f_punta_43", CubeListBuilder.create().texOffs(200, 137).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.88861604357804F, -30.37575880483536F, -7.366935990718417F, -3.1102629300477784F, -0.006656807027733626F, -1.3021577138144231F));
        g.addOrReplaceChild("capo_f_punta_44", CubeListBuilder.create().texOffs(936, 131).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.42017596930118F, -30.774595665540897F, -7.309680444391649F, -3.131518713010363F, -0.06080512022994683F, -0.4875788582181625F));
        g.addOrReplaceChild("capo_f_punta_45", CubeListBuilder.create().texOffs(608, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.85068248599012F, -16.749999858280106F, -6.1211483227654F, -3.0536277561494365F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_46", CubeListBuilder.create().texOffs(632, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.85068248599012F, -20.249999574840324F, -6.1211483227654F, -3.0536277561494365F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_47", CubeListBuilder.create().texOffs(656, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.85068248599012F, -23.74999929140054F, -6.1211483227654F, -3.0536277561494365F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_48", CubeListBuilder.create().texOffs(680, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.17940461615116F, -27.049999709775754F, -5.994470178625199F, -3.076012729238877F, -0.05175671482292106F, -1.1605786406201184F));
        g.addOrReplaceChild("capo_f_punta_49", CubeListBuilder.create().texOffs(360, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-74.87946002876215F, -29.000000094577018F, -5.735173003385473F, -3.1185602628802918F, -0.10621458349451321F, -0.5650256309915753F));
        g.addOrReplaceChild("capo_f_punta_50", CubeListBuilder.create().texOffs(378, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-73.61653580425119F, -29.79999974398934F, -5.469601093481492F, -3.1303732153922175F, -0.09663140672807122F, -0.5617603790201063F));
        g.addOrReplaceChild("capo_f_punta_51", CubeListBuilder.create().texOffs(996, 125).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.93108282580448F, -30.377606263487273F, -5.344688864996221F, -3.131185059233408F, -0.002994667498045711F, -1.2906360492574371F));
        g.addOrReplaceChild("capo_f_punta_52", CubeListBuilder.create().texOffs(884, 125).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.43994367715935F, -30.77760647913952F, -5.321295748293098F, -3.1392733124228958F, -0.004589759708803408F, -0.467904281280961F));
        g.addOrReplaceChild("capo_f_punta_53", CubeListBuilder.create().texOffs(704, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.96875637983183F, -16.749999858280106F, -3.870629639099711F, -3.119419294850827F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_54", CubeListBuilder.create().texOffs(728, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.96875637983183F, -20.249999574840324F, -3.870629639099711F, -3.119419294850827F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_55", CubeListBuilder.create().texOffs(752, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.96875637983183F, -23.74999929140054F, -3.870629639099711F, -3.119419294850827F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_56", CubeListBuilder.create().texOffs(776, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.27544147513734F, -27.049999709775754F, -3.7556678327676107F, -3.125324543195846F, -0.037446487272951266F, -1.1496985225955771F));
        g.addOrReplaceChild("capo_f_punta_57", CubeListBuilder.create().texOffs(396, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-74.93654694207478F, -29.000000094577018F, -3.532762539924556F, -3.1361846798822453F, -0.07495263087424558F, -0.5543437391243827F));
        g.addOrReplaceChild("capo_f_punta_58", CubeListBuilder.create().texOffs(414, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-73.64392977486595F, -29.79999974398934F, -3.324794961212104F, -3.139026003159332F, -0.06744286853954251F, -0.5535320872192898F));
        g.addOrReplaceChild("capo_f_punta_59", CubeListBuilder.create().texOffs(1008, 125).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.94505722327231F, -30.377606263487273F, -3.2255837974931825F, -3.139256058363877F, -0.0006819131015166267F, -1.2868425374557608F));
        g.addOrReplaceChild("capo_f_punta_60", CubeListBuilder.create().texOffs(898, 125).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.44661110525973F, -30.77760647913952F, -3.2003714448266094F, -3.141076220857531F, -0.0010371701344001278F, -0.4619861787322016F));
        g.addOrReplaceChild("capo_f_punta_61", CubeListBuilder.create().texOffs(192, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-76.99788365555821F, -16.749999858280106F, -1.3263297685815625F, -3.139997014347045F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_62", CubeListBuilder.create().texOffs(218, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-76.99788365555821F, -20.249999574840324F, -1.3263297685815625F, -3.139997014347045F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_63", CubeListBuilder.create().texOffs(244, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-76.99788365555821F, -23.74999929140054F, -1.3263297685815625F, -3.139997014347045F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_64", CubeListBuilder.create().texOffs(270, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-76.29837098110353F, -27.049999709775754F, -1.2801463354600768F, -3.140432835811588F, -0.013837459820126201F, -1.1468477805329051F));
        g.addOrReplaceChild("capo_f_punta_65", CubeListBuilder.create().texOffs(432, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-74.94915248379024F, -29.000000094577018F, -1.1929100650719546F, -3.14122012236484F, -0.027179970189994535F, -0.551846950067666F));
        g.addOrReplaceChild("capo_f_punta_66", CubeListBuilder.create().texOffs(450, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-73.6496311737127F, -29.79999974398934F, -1.1152489077016214F, -3.141419048639251F, -0.024110446594065624F, -0.5517773759337867F));
        g.addOrReplaceChild("capo_f_punta_67", CubeListBuilder.create().texOffs(0, 131).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.947834568204F, -30.377606263487273F, -1.0782600604054529F, -3.1414367451605534F, -4.5630622226574466e-05F, -1.2860724670366284F));
        g.addOrReplaceChild("capo_f_punta_68", CubeListBuilder.create().texOffs(792, 125).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.44792672495711F, -30.77760647913952F, -1.068107702198393F, -3.1415582409061416F, -6.931131165133446e-05F, -0.46083926314202284F));
        g.addOrReplaceChild("capo_f_punta_69", CubeListBuilder.create().texOffs(296, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-76.99788365555821F, -16.749999858280106F, 1.3263290278775173F, 3.1399970152381504F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_70", CubeListBuilder.create().texOffs(322, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-76.99788365555821F, -20.249999574840324F, 1.3263290278775173F, 3.1399970152381504F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_71", CubeListBuilder.create().texOffs(348, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-76.99788365555821F, -23.74999929140054F, 1.3263290278775173F, 3.1399970152381504F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_72", CubeListBuilder.create().texOffs(374, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-76.29837098110353F, -27.049999709775754F, 1.280145573972644F, 3.1404328365014016F, 0.01383746577078155F, -1.1468477805348205F));
        g.addOrReplaceChild("capo_f_punta_73", CubeListBuilder.create().texOffs(468, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-74.94915248379024F, -29.000000094577018F, 1.1929090162252578F, 3.1412201226906897F, 0.02718014411679911F, -0.5518469500110913F));
        g.addOrReplaceChild("capo_f_punta_74", CubeListBuilder.create().texOffs(486, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-73.6496311737127F, -29.79999974398934F, 1.1152468989535518F, 3.1414190489500875F, 0.02411089960310057F, -0.5517773758622203F));
        g.addOrReplaceChild("capo_f_punta_75", CubeListBuilder.create().texOffs(12, 131).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.947834568204F, -30.377606263487273F, 1.0782577485360192F, 3.141436745494822F, 4.563052433848194e-05F, -1.2860724673660269F));
        g.addOrReplaceChild("capo_f_punta_76", CubeListBuilder.create().texOffs(808, 125).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.44792672495711F, -30.77760647913952F, 1.0681067413657461F, 3.1415582409370946F, 6.931124929629509e-05F, -0.46083926320873686F));
        g.addOrReplaceChild("capo_f_punta_77", CubeListBuilder.create().texOffs(800, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.96875637983182F, -16.749999858280106F, 3.8706296390994392F, 3.1194192948508235F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_78", CubeListBuilder.create().texOffs(824, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.96875637983182F, -20.249999574840324F, 3.8706296390994392F, 3.1194192948508235F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_79", CubeListBuilder.create().texOffs(848, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.96875637983182F, -23.74999929140054F, 3.8706296390994392F, 3.1194192948508235F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_80", CubeListBuilder.create().texOffs(872, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.27544147513731F, -27.049999709775754F, 3.7556678327673225F, 3.125324543195845F, 0.03744648727295645F, -1.149698522595575F));
        g.addOrReplaceChild("capo_f_punta_81", CubeListBuilder.create().texOffs(504, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-74.93654694207478F, -29.000000094577018F, 3.5327625399227114F, 3.1361846798822484F, 0.07495263087523768F, -0.5543437391243922F));
        g.addOrReplaceChild("capo_f_punta_82", CubeListBuilder.create().texOffs(522, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-73.64392977486598F, -29.79999974398934F, 3.3247949612045096F, 3.1390260031593433F, 0.06744286854225316F, -0.5535320872192808F));
        g.addOrReplaceChild("capo_f_punta_83", CubeListBuilder.create().texOffs(24, 131).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.94505722327234F, -30.377606263487273F, 3.225583797483F, 3.139256058363893F, 0.0006819131015119767F, -1.2868425374557997F));
        g.addOrReplaceChild("capo_f_punta_84", CubeListBuilder.create().texOffs(912, 125).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.44661110525975F, -30.77760647913952F, 3.200371444822337F, 3.141076220857534F, 0.0010371701343940738F, -0.46198617873219355F));
        g.addOrReplaceChild("capo_f_punta_85", CubeListBuilder.create().texOffs(896, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.85068248599005F, -16.749999858280106F, 6.121148322766056F, 3.0536277561494027F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_86", CubeListBuilder.create().texOffs(920, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.85068248599005F, -20.249999574840324F, 6.121148322766056F, 3.0536277561494027F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_87", CubeListBuilder.create().texOffs(944, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.85068248599005F, -23.74999929140054F, 6.121148322766056F, 3.0536277561494027F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_88", CubeListBuilder.create().texOffs(968, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-76.1794046161511F, -27.049999709775754F, 5.994470178625906F, 3.0760127292388493F, 0.051756714822912026F, -1.1605786406201268F));
        g.addOrReplaceChild("capo_f_punta_89", CubeListBuilder.create().texOffs(540, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-74.87946002876214F, -29.000000094577018F, 5.735173003385068F, 3.1185602628802958F, 0.10621458349526906F, -0.5650256309915855F));
        g.addOrReplaceChild("capo_f_punta_90", CubeListBuilder.create().texOffs(558, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-73.61653580425121F, -29.79999974398934F, 5.469601093478818F, 3.1303732153922352F, 0.09663140672877137F, -0.5617603790200992F));
        g.addOrReplaceChild("capo_f_punta_91", CubeListBuilder.create().texOffs(36, 131).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.93108282580451F, -30.377606263487273F, 5.344688864992187F, 3.1311850592334314F, 0.0029946674980392243F, -1.2906360492574032F));
        g.addOrReplaceChild("capo_f_punta_92", CubeListBuilder.create().texOffs(926, 125).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-72.43994367715936F, -30.77760647913952F, 5.321295748290962F, 3.1392733124228958F, 0.004589759708803478F, -0.46790428128096134F));
        g.addOrReplaceChild("capo_f_punta_93", CubeListBuilder.create().texOffs(296, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.58670444926872F, -16.749999858280106F, 7.930885643540909F, 2.922670768683235F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_94", CubeListBuilder.create().texOffs(318, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.58670444926872F, -20.249999574840324F, 7.930885643540909F, 2.922670768683235F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_95", CubeListBuilder.create().texOffs(340, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-76.58670444926872F, -23.74999929140054F, 7.930885643540909F, 2.922670768683235F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_96", CubeListBuilder.create().texOffs(362, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-75.95478403295563F, -27.049999709775754F, 7.853407443887498F, 2.9733692898464965F, 0.04625398305127905F, -1.1836778877002472F));
        g.addOrReplaceChild("capo_f_punta_97", CubeListBuilder.create().texOffs(852, 131).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-74.73060389716835F, -29.000000094577018F, 7.681129621218698F, 3.0770153846794375F, 0.11403661038638346F, -0.5928463813176845F));
        g.addOrReplaceChild("capo_f_punta_98", CubeListBuilder.create().texOffs(866, 131).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-73.53761216312395F, -29.79999974398934F, 7.47910377270067F, 3.1088229314226137F, 0.09845548168972534F, -0.5858153137603753F));
        g.addOrReplaceChild("capo_f_punta_99", CubeListBuilder.create().texOffs(210, 137).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.88861604357805F, -30.37575880483536F, 7.366935990717858F, 3.110262930047784F, 0.006656807027729462F, -1.302157713814392F));
        g.addOrReplaceChild("capo_f_punta_100", CubeListBuilder.create().texOffs(948, 131).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.42017596930118F, -30.774595665540893F, 7.309680444391677F, 3.131518713010359F, 0.060805120229974516F, -0.48757885821817204F));
        g.addOrReplaceChild("capo_f_punta_101", CubeListBuilder.create().texOffs(590, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.18338659569059F, -16.749999858280106F, 9.213343203989979F, 2.7137594658274886F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_102", CubeListBuilder.create().texOffs(610, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.18338659569059F, -20.249999574840324F, 9.213343203989979F, 2.7137594658274886F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_103", CubeListBuilder.create().texOffs(630, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-76.18338659569059F, -23.74999929140054F, 9.213343203989979F, 2.7137594658274886F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_104", CubeListBuilder.create().texOffs(650, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-75.59695483804063F, -27.049999709775754F, 9.205112460095146F, 2.7938426431885115F, 0.004966532831443879F, -1.2090980920818022F));
        g.addOrReplaceChild("capo_f_punta_105", CubeListBuilder.create().texOffs(866, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-74.4654596013377F, -29.000000094577018F, 9.185647589582144F, 2.9866899617916065F, 0.11061434917704834F, -0.6477481404224451F));
        g.addOrReplaceChild("capo_f_punta_106", CubeListBuilder.create().texOffs(878, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-73.37422798176391F, -29.79999974398934F, 9.174121653701546F, 3.0561472964435286F, 0.05791468747707876F, -0.63704622407214F));
        g.addOrReplaceChild("capo_f_punta_107", CubeListBuilder.create().texOffs(0, 146).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.79697686631357F, -30.32365351703923F, 9.068614030890311F, 3.0410311091270663F, -0.037923081881120084F, -1.2374006755042115F));
        g.addOrReplaceChild("capo_f_punta_108", CubeListBuilder.create().texOffs(890, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.38294694569203F, -30.686775414615067F, 8.75214161591424F, 2.9717480516417174F, 0.20097140011294273F, -0.5144210897123177F));
        g.addOrReplaceChild("capo_f_punta_109", CubeListBuilder.create().texOffs(248, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.6918909232455F, -16.749999858280106F, 10.025301847096268F, 2.4363307120946653F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_110", CubeListBuilder.create().texOffs(266, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.6918909232455F, -20.249999574840324F, 10.025301847096268F, 2.4363307120946653F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_111", CubeListBuilder.create().texOffs(284, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.6918909232455F, -23.74999929140054F, 10.025301847096268F, 2.4363307120946653F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_112", CubeListBuilder.create().texOffs(302, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.1567889705078F, -27.049999709775754F, 10.051479331782605F, 2.5238149829361003F, -0.01596279295009587F, -1.2383799873227344F));
        g.addOrReplaceChild("capo_f_punta_113", CubeListBuilder.create().texOffs(916, 146).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.12602901406555F, -29.000000094577018F, 10.122053590364484F, 2.7950572145421715F, 0.14269394266285054F, -0.7551921932539644F));
        g.addOrReplaceChild("capo_f_punta_114", CubeListBuilder.create().texOffs(926, 146).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-73.14469264822195F, -29.79999974398934F, 10.25640859655911F, 2.9105197287827425F, 0.05252887035225381F, -0.7349085491947F));
        g.addOrReplaceChild("capo_f_punta_115", CubeListBuilder.create().texOffs(1008, 146).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.67525516781166F, -30.236697736121382F, 10.091778957161747F, 2.9028097411324363F, 0.8860708659324649F, -0.31842328132065983F));
        g.addOrReplaceChild("capo_f_punta_116", CubeListBuilder.create().texOffs(1016, 146).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.3457480247702F, -30.484827681468015F, 9.548205729140564F, 2.7343480222521537F, 0.29007791380488496F, -0.37474690788009096F));
        g.addOrReplaceChild("capo_f_punta_117", CubeListBuilder.create().texOffs(320, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.12090243296325F, -16.749999858280106F, 10.523164890817945F, 2.1235447695501892F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_118", CubeListBuilder.create().texOffs(338, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.12090243296325F, -20.249999574840324F, 10.523164890817945F, 2.1235447695501892F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_119", CubeListBuilder.create().texOffs(356, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-75.12090243296325F, -23.74999929140054F, 10.523164890817945F, 2.1235447695501892F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_120", CubeListBuilder.create().texOffs(374, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.66124132268348F, -27.049999709775754F, 10.543556668257738F, 2.1926647395256453F, -0.012612369962804843F, -1.2825026601346319F));
        g.addOrReplaceChild("capo_f_punta_121", CubeListBuilder.create().texOffs(150, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.7698536874936F, -29.000000094577018F, 10.60426862394106F, 2.463600686278081F, -0.06840111621516731F, -0.7472710495067448F));
        g.addOrReplaceChild("capo_f_punta_122", CubeListBuilder.create().texOffs(158, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.91972614050906F, -29.79999974398934F, 10.723729824278292F, 2.5717616161401335F, -0.13588026951088605F, -0.762917617951262F));
        g.addOrReplaceChild("capo_f_punta_123", CubeListBuilder.create().texOffs(250, 157).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.53160670570338F, -30.19999978434775F, 10.61777965446706F, 3.141588406084092F, 1.0370481327870795F, -9.743754240169569e-06F));
        g.addOrReplaceChild("capo_f_punta_124", CubeListBuilder.create().texOffs(0, 150).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.28094414648606F, -30.286658908160014F, 10.124118820628052F, 2.8324269091165193F, 0.4875527940637817F, -0.15045825343485594F));
        g.addOrReplaceChild("capo_f_punta_125", CubeListBuilder.create().texOffs(392, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.3592524865052F, -16.749999858280106F, 10.827808537994136F, 1.8168842458705077F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_126", CubeListBuilder.create().texOffs(410, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.3592524865052F, -20.249999574840324F, 10.827808537994136F, 1.8168842458705077F, 0.0F, -1.5707963267948966F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("capo_f_punta_127", CubeListBuilder.create().texOffs(428, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.3592524865052F, -23.74999929140054F, 10.827808537994136F, 1.8168842458705077F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_128", CubeListBuilder.create().texOffs(446, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-74.02778647643402F, -27.049999709775754F, 10.831828974767909F, 1.8561271547243072F, -0.0025364737979756313F, -1.3601206092079743F));
        g.addOrReplaceChild("capo_f_punta_129", CubeListBuilder.create().texOffs(166, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-73.36688131162191F, -29.000000094577018F, 10.851200260509435F, 2.0164697929014666F, -0.02961481264639103F, -0.8818309222153355F));
        g.addOrReplaceChild("capo_f_punta_130", CubeListBuilder.create().texOffs(174, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-72.7090629875435F, -29.79999974398934F, 10.900155818878709F, 2.114447897192069F, -0.06484239483564452F, -0.883411921292812F));
        g.addOrReplaceChild("capo_f_punta_131", CubeListBuilder.create().texOffs(384, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.9537490882119F, -16.749999858280106F, 10.97063985192749F, 1.6015705424892281F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_132", CubeListBuilder.create().texOffs(406, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.9537490882119F, -20.249999574840324F, 10.97063985192749F, 1.6015705424892281F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_133", CubeListBuilder.create().texOffs(428, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.9537490882119F, -23.74999929140054F, 10.97063985192749F, 1.6015705424892281F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_f_punta_134", CubeListBuilder.create().texOffs(450, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-72.82882910424497F, -27.049999709775754F, 10.96909832151049F, 1.6081931226635076F, 0.0024945560459868447F, -1.530511878916591F));
        g.addOrReplaceChild("capo_f_punta_135", CubeListBuilder.create().texOffs(984, 142).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-72.57113529824514F, -29.000000094577018F, 10.969147254459104F, 1.6262951111667667F, 0.0051353737629222474F, -1.4101676413868642F));
        g.addOrReplaceChild("capo_f_punta_136", CubeListBuilder.create().texOffs(8, 150).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.30017668798286F, -29.79999974398934F, 10.977762674559377F, 1.6450455305940153F, -0.004366299950573157F, -1.404196166337963F));
        g.addOrReplaceChild("capo_f_punta_137", CubeListBuilder.create().texOffs(86, 150).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-72.07982683688981F, -30.2F, 10.751550099731162F, 3.141592653589793F, 0.7711669425231379F, 0.0F));
        g.addOrReplaceChild("farofi_0", CubeListBuilder.create().texOffs(66, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(614, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.9F, -27.0F, -4.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farofi_1", CubeListBuilder.create().texOffs(90, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(638, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.9F, -27.0F, -4.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farofi_2", CubeListBuilder.create().texOffs(114, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(662, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.9F, -27.0F, -4.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farofi_3", CubeListBuilder.create().texOffs(138, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(686, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.9F, -27.0F, -4.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farofi_vidrio", CubeListBuilder.create().texOffs(0, 107).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-77.52000000000001F, -27.0F, -4.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farofd_0", CubeListBuilder.create().texOffs(162, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(710, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.9F, -27.0F, 4.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farofd_1", CubeListBuilder.create().texOffs(186, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(734, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.9F, -27.0F, 4.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farofd_2", CubeListBuilder.create().texOffs(210, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(758, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.9F, -27.0F, 4.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farofd_3", CubeListBuilder.create().texOffs(234, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(782, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.9F, -27.0F, 4.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farofd_vidrio", CubeListBuilder.create().texOffs(40, 107).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-77.52000000000001F, -27.0F, 4.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escapef_0", CubeListBuilder.create().texOffs(178, 107).addBox(-13.0F, -33.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(374, 50).addBox(-3.5F, -33.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offset(-40.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("escapef_1", CubeListBuilder.create().texOffs(244, 107).addBox(-13.0F, -33.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(440, 50).addBox(-3.5F, -33.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offsetAndRotation(-40.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("escapef_2", CubeListBuilder.create().texOffs(310, 107).addBox(-13.0F, -33.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(506, 50).addBox(-3.5F, -33.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offsetAndRotation(-40.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("capo_t", CubeListBuilder.create().texOffs(724, 0).addBox(14.0F, -28.0F, -11.0F, 58.0F, 13.0F, 22.0F).texOffs(284, 81).addBox(14.0F, -31.0F, -8.0F, 58.0F, 3.0F, 16.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_t_cantoi_0", CubeListBuilder.create().texOffs(826, 153).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(43.0F, -28.46352549156242F, -10.92658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_1", CubeListBuilder.create().texOffs(0, 155).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(43.0F, -29.34520337000113F, -10.640110266005152F, -2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_2", CubeListBuilder.create().texOffs(118, 155).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(43.0F, -30.09520337000113F, -10.095203370001132F, -2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_3", CubeListBuilder.create().texOffs(236, 155).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(43.0F, -30.640110266005152F, -9.345203370001132F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantoi_4", CubeListBuilder.create().texOffs(354, 155).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(43.0F, -30.92658477444273F, -8.463525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_0", CubeListBuilder.create().texOffs(472, 155).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(43.0F, -28.46352549156242F, 10.92658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_1", CubeListBuilder.create().texOffs(590, 155).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(43.0F, -29.34520337000113F, 10.640110266005152F, 2.042035224833365F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_2", CubeListBuilder.create().texOffs(708, 155).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(43.0F, -30.09520337000113F, 10.095203370001132F, 2.356194490192345F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_3", CubeListBuilder.create().texOffs(826, 155).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(43.0F, -30.640110266005152F, 9.345203370001132F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_cantod_4", CubeListBuilder.create().texOffs(0, 157).addBox(-29.0F, -1.0F, -0.5F, 58.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(43.0F, -30.92658477444273F, 8.463525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_t_tapaa", CubeListBuilder.create().texOffs(180, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 44.0F), PartPose.offset(14.0F, -28.0F, -11.0F));
        g.addOrReplaceChild("capo_t_tapab", CubeListBuilder.create().texOffs(270, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 44.0F), PartPose.offset(71.0F, -28.0F, -11.0F));
        g.addOrReplaceChild("capo_t_punta_0", CubeListBuilder.create().texOffs(472, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.95374908821194F, -16.749999858280106F, -10.970639851927483F, -1.5400221111005605F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_1", CubeListBuilder.create().texOffs(494, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.95374908821194F, -20.249999574840324F, -10.970639851927483F, -1.5400221111005605F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_2", CubeListBuilder.create().texOffs(516, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.95374908821194F, -23.74999929140054F, -10.970639851927483F, -1.5400221111005605F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_3", CubeListBuilder.create().texOffs(538, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.82882910424499F, -27.049999709775754F, -10.96909832151049F, -1.5333995309262873F, -0.0024945560459829637F, -1.6110807746732148F));
        g.addOrReplaceChild("capo_t_punta_4", CubeListBuilder.create().texOffs(994, 142).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(72.57113529824511F, -29.000000094577018F, -10.969147254459108F, -1.51529754242303F, -0.005135373762930682F, -1.7314250122029011F));
        g.addOrReplaceChild("capo_t_punta_5", CubeListBuilder.create().texOffs(16, 150).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(72.30017668798287F, -29.79999974398934F, -10.977762674559377F, -1.4965471229957774F, 0.0043662999505738095F, -1.7373964872518344F));
        g.addOrReplaceChild("capo_t_punta_6", CubeListBuilder.create().texOffs(92, 150).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(72.07982683688981F, -30.2F, -10.751550099731164F, 0.0F, -0.7711669425231393F, -3.141592653589793F));
        g.addOrReplaceChild("capo_t_punta_7", CubeListBuilder.create().texOffs(464, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.35925248650527F, -16.749999858280106F, -10.827808537994116F, -1.324708407719267F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_8", CubeListBuilder.create().texOffs(482, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.35925248650527F, -20.249999574840324F, -10.827808537994116F, -1.324708407719267F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_9", CubeListBuilder.create().texOffs(500, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.35925248650527F, -23.74999929140054F, -10.827808537994116F, -1.324708407719267F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_10", CubeListBuilder.create().texOffs(518, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.02778647643402F, -27.049999709775754F, -10.831828974767909F, -1.2854654988654857F, 0.0025364737979882155F, -1.7814720443818628F));
        g.addOrReplaceChild("capo_t_punta_11", CubeListBuilder.create().texOffs(182, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(73.36688131162188F, -29.000000094577018F, -10.851200260509442F, -1.1251228606883392F, 0.029614812646366027F, -2.259761731374394F));
        g.addOrReplaceChild("capo_t_punta_12", CubeListBuilder.create().texOffs(190, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(72.70906298754352F, -29.79999974398934F, -10.900155818878705F, -1.0271447563976976F, 0.06484239483564995F, -2.258180732296992F));
        g.addOrReplaceChild("capo_t_punta_13", CubeListBuilder.create().texOffs(536, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.1209024329633F, -16.749999858280106F, -10.52316489081791F, -1.0180478840395626F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_14", CubeListBuilder.create().texOffs(554, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.1209024329633F, -20.249999574840324F, -10.52316489081791F, -1.0180478840395626F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_15", CubeListBuilder.create().texOffs(572, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.1209024329633F, -23.74999929140054F, -10.52316489081791F, -1.0180478840395626F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_16", CubeListBuilder.create().texOffs(590, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.66124132268348F, -27.049999709775754F, -10.54355666825774F, -0.9489279140641428F, 0.01261236996282697F, -1.859089993455193F));
        g.addOrReplaceChild("capo_t_punta_17", CubeListBuilder.create().texOffs(198, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(73.76985368749358F, -29.000000094577018F, -10.604268623941067F, -0.67799196731174F, 0.06840111621512528F, -2.3943216040830073F));
        g.addOrReplaceChild("capo_t_punta_18", CubeListBuilder.create().texOffs(206, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(72.91972614050907F, -29.79999974398934F, -10.72372982427828F, -0.5698310374496702F, 0.13588026951089463F, -2.3786750356385395F));
        g.addOrReplaceChild("capo_t_punta_19", CubeListBuilder.create().texOffs(254, 157).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(72.53160670570338F, -30.19999978434775F, -10.617779654467055F, -4.247505701140005e-06F, -1.0370481327870713F, -3.141582909835553F));
        g.addOrReplaceChild("capo_t_punta_20", CubeListBuilder.create().texOffs(24, 150).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(72.28094414648606F, -30.286658908160025F, -10.124118820628043F, -0.3091657444732847F, -0.4875527940637917F, -2.991134400154925F));
        g.addOrReplaceChild("capo_t_punta_21", CubeListBuilder.create().texOffs(608, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.69189092324552F, -16.749999858280106F, -10.025301847096227F, -0.7052619414951232F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_22", CubeListBuilder.create().texOffs(626, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.69189092324552F, -20.249999574840324F, -10.025301847096227F, -0.7052619414951232F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_23", CubeListBuilder.create().texOffs(644, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.69189092324552F, -23.74999929140054F, -10.025301847096227F, -0.7052619414951232F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_24", CubeListBuilder.create().texOffs(662, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.15678897050779F, -27.049999709775754F, -10.051479331782625F, -0.6177776706537111F, 0.015962792950132827F, -1.9032126662670834F));
        g.addOrReplaceChild("capo_t_punta_25", CubeListBuilder.create().texOffs(936, 146).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.12602901406555F, -29.000000094577018F, -10.122053590364448F, -0.3465354390475932F, -0.1426939426629324F, -2.3864004603358184F));
        g.addOrReplaceChild("capo_t_punta_26", CubeListBuilder.create().texOffs(946, 146).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(73.14469264822199F, -29.79999974398934F, -10.25640859655899F, -0.2310729248070133F, -0.05252887035221482F, -2.406684104395116F));
        g.addOrReplaceChild("capo_t_punta_27", CubeListBuilder.create().texOffs(32, 150).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(72.67525516781167F, -30.236697736121396F, -10.091778957161655F, -0.23878291245742286F, -0.8860708659323833F, -2.8231693722688256F));
        g.addOrReplaceChild("capo_t_punta_28", CubeListBuilder.create().texOffs(40, 150).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(72.3457480247702F, -30.484827681468037F, -9.548205729140497F, -0.4072446313376104F, -0.29007791380485703F, -2.7668457457096847F));
        g.addOrReplaceChild("capo_t_punta_29", CubeListBuilder.create().texOffs(670, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(76.18338659569062F, -16.749999858280106F, -9.21334320398993F, -0.42783318776229545F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_30", CubeListBuilder.create().texOffs(690, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(76.18338659569062F, -20.249999574840324F, -9.21334320398993F, -0.42783318776229545F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_31", CubeListBuilder.create().texOffs(710, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(76.18338659569062F, -23.74999929140054F, -9.21334320398993F, -0.42783318776229545F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_32", CubeListBuilder.create().texOffs(730, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(75.59695483804062F, -27.049999709775754F, -9.205112460095195F, -0.347750010401292F, -0.004966532831385154F, -1.9324945615080131F));
        g.addOrReplaceChild("capo_t_punta_33", CubeListBuilder.create().texOffs(902, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(74.46545960133771F, -29.000000094577018F, -9.185647589582038F, -0.15490269179817975F, -0.11061434917723063F, -2.4938445131673257F));
        g.addOrReplaceChild("capo_t_punta_34", CubeListBuilder.create().texOffs(914, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(73.37422798176394F, -29.79999974398934F, -9.17412165370163F, -0.08544535714627813F, -0.057914687476759104F, -2.504546429517661F));
        g.addOrReplaceChild("capo_t_punta_35", CubeListBuilder.create().texOffs(8, 146).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(72.79697686631357F, -30.323653517039247F, -9.068614030890457F, -0.10056154446274551F, 0.037923081881116344F, -1.9041919780857515F));
        g.addOrReplaceChild("capo_t_punta_36", CubeListBuilder.create().texOffs(926, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(72.38294694569203F, -30.686775414615084F, -8.752141615914116F, -0.16984460194804607F, -0.20097140011284556F, -2.627171563877479F));
        g.addOrReplaceChild("capo_t_punta_37", CubeListBuilder.create().texOffs(560, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(76.58670444926881F, -16.749999858280106F, -7.930885643540469F, -0.21892188490651524F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_38", CubeListBuilder.create().texOffs(582, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(76.58670444926881F, -20.249999574840324F, -7.930885643540469F, -0.21892188490651524F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_39", CubeListBuilder.create().texOffs(604, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(76.58670444926881F, -23.74999929140054F, -7.930885643540469F, -0.21892188490651524F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_40", CubeListBuilder.create().texOffs(626, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(75.95478403295567F, -27.049999709775754F, -7.853407443887145F, -0.16822336374327104F, -0.04625398305122669F, -1.9579147658895637F));
        g.addOrReplaceChild("capo_t_punta_41", CubeListBuilder.create().texOffs(880, 131).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(74.73060389716838F, -29.000000094577018F, -7.6811296212184965F, -0.06457726891035759F, -0.11403661038634015F, -2.548746272272103F));
        g.addOrReplaceChild("capo_t_punta_42", CubeListBuilder.create().texOffs(894, 131).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(73.53761216312395F, -29.79999974398934F, -7.479103772701189F, -0.03276972216717657F, -0.09845548168927623F, -2.5557773398294272F));
        g.addOrReplaceChild("capo_t_punta_43", CubeListBuilder.create().texOffs(220, 137).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.88861604357804F, -30.37575880483536F, -7.366935990718417F, -0.031329723542015F, -0.006656807027733626F, -1.83943493977537F));
        g.addOrReplaceChild("capo_t_punta_44", CubeListBuilder.create().texOffs(960, 131).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.42017596930118F, -30.774595665540897F, -7.309680444391649F, -0.010073940579430167F, -0.06080512022994683F, -2.6540137953716307F));
        g.addOrReplaceChild("capo_t_punta_45", CubeListBuilder.create().texOffs(992, 118).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.85068248599012F, -16.749999858280106F, -6.1211483227654F, -0.08796489744035674F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_46", CubeListBuilder.create().texOffs(0, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.85068248599012F, -20.249999574840324F, -6.1211483227654F, -0.08796489744035674F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_47", CubeListBuilder.create().texOffs(24, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.85068248599012F, -23.74999929140054F, -6.1211483227654F, -0.08796489744035674F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_48", CubeListBuilder.create().texOffs(48, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.17940461615116F, -27.049999709775754F, -5.994470178625199F, -0.06557992435091646F, -0.05175671482292106F, -1.981014012969675F));
        g.addOrReplaceChild("capo_t_punta_49", CubeListBuilder.create().texOffs(576, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(74.87946002876215F, -29.000000094577018F, -5.735173003385473F, -0.02303239070950161F, -0.10621458349451321F, -2.576567022598218F));
        g.addOrReplaceChild("capo_t_punta_50", CubeListBuilder.create().texOffs(594, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(73.61653580425119F, -29.79999974398934F, -5.469601093481492F, -0.011219438197575569F, -0.09663140672807122F, -2.579832274569687F));
        g.addOrReplaceChild("capo_t_punta_51", CubeListBuilder.create().texOffs(48, 131).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.93108282580448F, -30.377606263487273F, -5.344688864996221F, -0.010407594356385564F, -0.002994667498045711F, -1.850956604332356F));
        g.addOrReplaceChild("capo_t_punta_52", CubeListBuilder.create().texOffs(940, 125).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.43994367715935F, -30.77760647913952F, -5.321295748293098F, -0.002319341166897353F, -0.004589759708803408F, -2.673688372308832F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("capo_t_punta_53", CubeListBuilder.create().texOffs(72, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.96875637983183F, -16.749999858280106F, -3.870629639099711F, -0.022173358738966302F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_54", CubeListBuilder.create().texOffs(96, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.96875637983183F, -20.249999574840324F, -3.870629639099711F, -0.022173358738966302F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_55", CubeListBuilder.create().texOffs(120, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.96875637983183F, -23.74999929140054F, -3.870629639099711F, -0.022173358738966302F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_56", CubeListBuilder.create().texOffs(144, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.27544147513734F, -27.049999709775754F, -3.7556678327676107F, -0.016268110393947266F, -0.037446487272951266F, -1.9918941309942162F));
        g.addOrReplaceChild("capo_t_punta_57", CubeListBuilder.create().texOffs(612, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(74.93654694207478F, -29.000000094577018F, -3.532762539924556F, -0.0054079737075479585F, -0.07495263087424558F, -2.5872489144654107F));
        g.addOrReplaceChild("capo_t_punta_58", CubeListBuilder.create().texOffs(630, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(73.64392977486595F, -29.79999974398934F, -3.324794961212104F, -0.0025666504304613703F, -0.06744286853954251F, -2.5880605663705034F));
        g.addOrReplaceChild("capo_t_punta_59", CubeListBuilder.create().texOffs(60, 131).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.94505722327231F, -30.377606263487273F, -3.2255837974931825F, -0.002336595225916129F, -0.0006819131015166267F, -1.8547501161340323F));
        g.addOrReplaceChild("capo_t_punta_60", CubeListBuilder.create().texOffs(954, 125).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.44661110525973F, -30.77760647913952F, -3.2003714448266094F, -0.000516432732262171F, -0.0010371701344001278F, -2.6796064748575916F));
        g.addOrReplaceChild("capo_t_punta_61", CubeListBuilder.create().texOffs(400, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(76.99788365555821F, -16.749999858280106F, -1.3263297685815625F, -0.0015956392427481792F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_62", CubeListBuilder.create().texOffs(426, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(76.99788365555821F, -20.249999574840324F, -1.3263297685815625F, -0.0015956392427481792F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_63", CubeListBuilder.create().texOffs(452, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(76.99788365555821F, -23.74999929140054F, -1.3263297685815625F, -0.0015956392427481792F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_64", CubeListBuilder.create().texOffs(478, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(76.29837098110353F, -27.049999709775754F, -1.2801463354600768F, -0.0011598177782052477F, -0.013837459820126201F, -1.9947448730568882F));
        g.addOrReplaceChild("capo_t_punta_65", CubeListBuilder.create().texOffs(648, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(74.94915248379024F, -29.000000094577018F, -1.1929100650719546F, -0.0003725312249529735F, -0.027179970189994535F, -2.589745703522127F));
        g.addOrReplaceChild("capo_t_punta_66", CubeListBuilder.create().texOffs(666, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(73.6496311737127F, -29.79999974398934F, -1.1152489077016214F, -0.0001736049505424907F, -0.024110446594065624F, -2.5898152776560064F));
        g.addOrReplaceChild("capo_t_punta_67", CubeListBuilder.create().texOffs(72, 131).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.947834568204F, -30.377606263487273F, -1.0782600604054529F, -0.00015590842923976454F, -4.5630622226574466e-05F, -1.8555201865531648F));
        g.addOrReplaceChild("capo_t_punta_68", CubeListBuilder.create().texOffs(824, 125).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.44792672495711F, -30.77760647913952F, -1.068107702198393F, -3.4412683651859396e-05F, -6.931131165133446e-05F, -2.6807533904477703F));
        g.addOrReplaceChild("capo_t_punta_69", CubeListBuilder.create().texOffs(504, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(76.99788365555821F, -16.749999858280106F, 1.3263290278775173F, 0.0015956383516425774F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_70", CubeListBuilder.create().texOffs(530, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(76.99788365555821F, -20.249999574840324F, 1.3263290278775173F, 0.0015956383516425774F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_71", CubeListBuilder.create().texOffs(556, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(76.99788365555821F, -23.74999929140054F, 1.3263290278775173F, 0.0015956383516425774F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_72", CubeListBuilder.create().texOffs(582, 118).addBox(-3.5F, -1.0F, -3.0F, 7.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(76.29837098110353F, -27.049999709775754F, 1.280145573972644F, 0.0011598170883916365F, 0.01383746577078155F, -1.9947448730549728F));
        g.addOrReplaceChild("capo_t_punta_73", CubeListBuilder.create().texOffs(684, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(74.94915248379024F, -29.000000094577018F, 1.1929090162252578F, 0.00037253089910369496F, 0.02718014411679911F, -2.5897457035787017F));
        g.addOrReplaceChild("capo_t_punta_74", CubeListBuilder.create().texOffs(702, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(73.6496311737127F, -29.79999974398934F, 1.1152468989535518F, 0.0001736046397057537F, 0.02411089960310057F, -2.589815277727573F));
        g.addOrReplaceChild("capo_t_punta_75", CubeListBuilder.create().texOffs(84, 131).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.947834568204F, -30.377606263487273F, 1.0782577485360192F, 0.00015590809497112952F, 4.563052433848194e-05F, -1.8555201862237665F));
        g.addOrReplaceChild("capo_t_punta_76", CubeListBuilder.create().texOffs(840, 125).addBox(-1.5F, -1.0F, -2.5F, 3.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.44792672495711F, -30.77760647913952F, 1.0681067413657461F, 3.4412652698687905e-05F, 6.931124929629509e-05F, -2.6807533903810565F));
        g.addOrReplaceChild("capo_t_punta_77", CubeListBuilder.create().texOffs(168, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.96875637983182F, -16.749999858280106F, 3.8706296390994392F, 0.022173358738969886F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_78", CubeListBuilder.create().texOffs(192, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.96875637983182F, -20.249999574840324F, 3.8706296390994392F, 0.022173358738969886F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_79", CubeListBuilder.create().texOffs(216, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.96875637983182F, -23.74999929140054F, 3.8706296390994392F, 0.022173358738969886F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_80", CubeListBuilder.create().texOffs(240, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.27544147513731F, -27.049999709775754F, 3.7556678327673225F, 0.016268110393948106F, 0.03744648727295645F, -1.9918941309942182F));
        g.addOrReplaceChild("capo_t_punta_81", CubeListBuilder.create().texOffs(720, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(74.93654694207478F, -29.000000094577018F, 3.5327625399227114F, 0.00540797370754485F, 0.07495263087523768F, -2.587248914465401F));
        g.addOrReplaceChild("capo_t_punta_82", CubeListBuilder.create().texOffs(738, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(73.64392977486598F, -29.79999974398934F, 3.3247949612045096F, 0.0025666504304499233F, 0.06744286854225316F, -2.5880605663705123F));
        g.addOrReplaceChild("capo_t_punta_83", CubeListBuilder.create().texOffs(96, 131).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.94505722327234F, -30.377606263487273F, 3.225583797483F, 0.0023365952259005326F, 0.0006819131015119767F, -1.8547501161339937F));
        g.addOrReplaceChild("capo_t_punta_84", CubeListBuilder.create().texOffs(968, 125).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.44661110525975F, -30.77760647913952F, 3.200371444822337F, 0.0005164327322591477F, 0.0010371701343940738F, -2.6796064748575996F));
        g.addOrReplaceChild("capo_t_punta_85", CubeListBuilder.create().texOffs(264, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.85068248599005F, -16.749999858280106F, 6.121148322766056F, 0.08796489744039053F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_86", CubeListBuilder.create().texOffs(288, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.85068248599005F, -20.249999574840324F, 6.121148322766056F, 0.08796489744039053F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_87", CubeListBuilder.create().texOffs(312, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.85068248599005F, -23.74999929140054F, 6.121148322766056F, 0.08796489744039053F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_88", CubeListBuilder.create().texOffs(336, 125).addBox(-3.5F, -1.0F, -2.5F, 7.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(76.1794046161511F, -27.049999709775754F, 5.994470178625906F, 0.06557992435094406F, 0.051756714822912026F, -1.9810140129696665F));
        g.addOrReplaceChild("capo_t_punta_89", CubeListBuilder.create().texOffs(756, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(74.87946002876214F, -29.000000094577018F, 5.735173003385068F, 0.023032390709497412F, 0.10621458349526906F, -2.5765670225982076F));
        g.addOrReplaceChild("capo_t_punta_90", CubeListBuilder.create().texOffs(774, 125).addBox(-2.0F, -1.0F, -2.5F, 4.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(73.61653580425121F, -29.79999974398934F, 5.469601093478818F, 0.011219438197557996F, 0.09663140672877137F, -2.5798322745696938F));
        g.addOrReplaceChild("capo_t_punta_91", CubeListBuilder.create().texOffs(108, 131).addBox(-0.5F, -1.0F, -2.5F, 1.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.93108282580451F, -30.377606263487273F, 5.344688864992187F, 0.010407594356361728F, 0.0029946674980392243F, -1.8509566043323902F));
        g.addOrReplaceChild("capo_t_punta_92", CubeListBuilder.create().texOffs(982, 125).addBox(-1.0F, -1.0F, -2.5F, 2.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(72.43994367715936F, -30.77760647913952F, 5.321295748290962F, 0.002319341166897391F, 0.004589759708803478F, -2.673688372308832F));
        g.addOrReplaceChild("capo_t_punta_93", CubeListBuilder.create().texOffs(648, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(76.58670444926872F, -16.749999858280106F, 7.930885643540909F, 0.21892188490655817F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_94", CubeListBuilder.create().texOffs(670, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(76.58670444926872F, -20.249999574840324F, 7.930885643540909F, 0.21892188490655817F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_95", CubeListBuilder.create().texOffs(692, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(76.58670444926872F, -23.74999929140054F, 7.930885643540909F, 0.21892188490655817F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_96", CubeListBuilder.create().texOffs(714, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(75.95478403295563F, -27.049999709775754F, 7.853407443887498F, 0.16822336374329672F, 0.04625398305127905F, -1.9579147658895462F));
        g.addOrReplaceChild("capo_t_punta_97", CubeListBuilder.create().texOffs(908, 131).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(74.73060389716835F, -29.000000094577018F, 7.681129621218698F, 0.0645772689103559F, 0.11403661038638346F, -2.548746272272109F));
        g.addOrReplaceChild("capo_t_punta_98", CubeListBuilder.create().texOffs(922, 131).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(73.53761216312395F, -29.79999974398934F, 7.47910377270067F, 0.03276972216717963F, 0.09845548168972534F, -2.555777339829418F));
        g.addOrReplaceChild("capo_t_punta_99", CubeListBuilder.create().texOffs(230, 137).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.88861604357805F, -30.37575880483536F, 7.366935990717858F, 0.0313297235420092F, 0.006656807027729462F, -1.839434939775401F));
        g.addOrReplaceChild("capo_t_punta_100", CubeListBuilder.create().texOffs(972, 131).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.42017596930118F, -30.774595665540893F, 7.309680444391677F, 0.010073940579434332F, 0.060805120229974516F, -2.654013795371621F));
        g.addOrReplaceChild("capo_t_punta_101", CubeListBuilder.create().texOffs(750, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(76.18338659569059F, -16.749999858280106F, 9.213343203989979F, 0.4278331877623047F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_102", CubeListBuilder.create().texOffs(770, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(76.18338659569059F, -20.249999574840324F, 9.213343203989979F, 0.4278331877623047F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_103", CubeListBuilder.create().texOffs(790, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(76.18338659569059F, -23.74999929140054F, 9.213343203989979F, 0.4278331877623047F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_104", CubeListBuilder.create().texOffs(810, 142).addBox(-3.5F, -1.0F, -1.5F, 7.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(75.59695483804063F, -27.049999709775754F, 9.205112460095146F, 0.34775001040128173F, 0.004966532831443879F, -1.9324945615079911F));
        g.addOrReplaceChild("capo_t_punta_105", CubeListBuilder.create().texOffs(938, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(74.4654596013377F, -29.000000094577018F, 9.185647589582144F, 0.15490269179818666F, 0.11061434917704834F, -2.4938445131673483F));
        g.addOrReplaceChild("capo_t_punta_106", CubeListBuilder.create().texOffs(950, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(73.37422798176391F, -29.79999974398934F, 9.174121653701546F, 0.08544535714626467F, 0.05791468747707876F, -2.5045464295176534F));
        g.addOrReplaceChild("capo_t_punta_107", CubeListBuilder.create().texOffs(16, 146).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(72.79697686631357F, -30.32365351703923F, 9.068614030890311F, 0.10056154446272705F, -0.037923081881120084F, -1.9041919780855816F));
        g.addOrReplaceChild("capo_t_punta_108", CubeListBuilder.create().texOffs(962, 142).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(72.38294694569203F, -30.686775414615067F, 8.75214161591424F, 0.16984460194807563F, 0.20097140011294273F, -2.6271715638774755F));
        g.addOrReplaceChild("capo_t_punta_109", CubeListBuilder.create().texOffs(680, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.6918909232455F, -16.749999858280106F, 10.025301847096268F, 0.7052619414951281F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_110", CubeListBuilder.create().texOffs(698, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.6918909232455F, -20.249999574840324F, 10.025301847096268F, 0.7052619414951281F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_111", CubeListBuilder.create().texOffs(716, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.6918909232455F, -23.74999929140054F, 10.025301847096268F, 0.7052619414951281F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_112", CubeListBuilder.create().texOffs(734, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.1567889705078F, -27.049999709775754F, 10.051479331782605F, 0.6177776706536932F, -0.01596279295009587F, -1.9032126662670588F));
        g.addOrReplaceChild("capo_t_punta_113", CubeListBuilder.create().texOffs(956, 146).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.12602901406555F, -29.000000094577018F, 10.122053590364484F, 0.34653543904762163F, 0.14269394266285054F, -2.386400460335829F));
        g.addOrReplaceChild("capo_t_punta_114", CubeListBuilder.create().texOffs(966, 146).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(73.14469264822195F, -29.79999974398934F, 10.25640859655911F, 0.23107292480705072F, 0.05252887035225381F, -2.4066841043950933F));
        g.addOrReplaceChild("capo_t_punta_115", CubeListBuilder.create().texOffs(48, 150).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(72.67525516781166F, -30.236697736121382F, 10.091778957161747F, 0.23878291245735694F, 0.8860708659324649F, -2.8231693722691333F));
        g.addOrReplaceChild("capo_t_punta_116", CubeListBuilder.create().texOffs(56, 150).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(72.3457480247702F, -30.484827681468015F, 9.548205729140564F, 0.4072446313376397F, 0.29007791380488496F, -2.7668457457097024F));
        g.addOrReplaceChild("capo_t_punta_117", CubeListBuilder.create().texOffs(752, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.12090243296325F, -16.749999858280106F, 10.523164890817945F, 1.018047884039604F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_118", CubeListBuilder.create().texOffs(770, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.12090243296325F, -20.249999574840324F, 10.523164890817945F, 1.018047884039604F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_119", CubeListBuilder.create().texOffs(788, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(75.12090243296325F, -23.74999929140054F, 10.523164890817945F, 1.018047884039604F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_120", CubeListBuilder.create().texOffs(806, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.66124132268348F, -27.049999709775754F, 10.543556668257738F, 0.9489279140641479F, -0.012612369962804843F, -1.8590899934551612F));
        g.addOrReplaceChild("capo_t_punta_121", CubeListBuilder.create().texOffs(214, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(73.7698536874936F, -29.000000094577018F, 10.60426862394106F, 0.6779919673117124F, -0.06840111621516731F, -2.3943216040830486F));
        g.addOrReplaceChild("capo_t_punta_122", CubeListBuilder.create().texOffs(222, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(72.91972614050906F, -29.79999974398934F, 10.723729824278292F, 0.5698310374496598F, -0.13588026951088605F, -2.378675035638531F));
        g.addOrReplaceChild("capo_t_punta_123", CubeListBuilder.create().texOffs(258, 157).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(72.53160670570338F, -30.19999978434775F, 10.61777965446706F, 4.247505701140986e-06F, 1.0370481327870795F, -3.141582909835553F));
        g.addOrReplaceChild("capo_t_punta_124", CubeListBuilder.create().texOffs(64, 150).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(72.28094414648606F, -30.286658908160014F, 10.124118820628052F, 0.30916574447327416F, 0.4875527940637817F, -2.9911344001549374F));
        g.addOrReplaceChild("capo_t_punta_125", CubeListBuilder.create().texOffs(824, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.3592524865052F, -16.749999858280106F, 10.827808537994136F, 1.3247084077192857F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_126", CubeListBuilder.create().texOffs(842, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.3592524865052F, -20.249999574840324F, 10.827808537994136F, 1.3247084077192857F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_127", CubeListBuilder.create().texOffs(860, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.3592524865052F, -23.74999929140054F, 10.827808537994136F, 1.3247084077192857F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_128", CubeListBuilder.create().texOffs(878, 146).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(74.02778647643402F, -27.049999709775754F, 10.831828974767909F, 1.2854654988654861F, -0.0025364737979756313F, -1.7814720443818188F));
        g.addOrReplaceChild("capo_t_punta_129", CubeListBuilder.create().texOffs(230, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(73.36688131162191F, -29.000000094577018F, 10.851200260509435F, 1.1251228606883268F, -0.02961481264639103F, -2.2597617313744576F));
        g.addOrReplaceChild("capo_t_punta_130", CubeListBuilder.create().texOffs(238, 157).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(72.7090629875435F, -29.79999974398934F, 10.900155818878709F, 1.0271447563977245F, -0.06484239483564452F, -2.258180732296981F));
        g.addOrReplaceChild("capo_t_punta_131", CubeListBuilder.create().texOffs(736, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.9537490882119F, -16.749999858280106F, 10.97063985192749F, 1.540022111100565F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_132", CubeListBuilder.create().texOffs(758, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.9537490882119F, -20.249999574840324F, 10.97063985192749F, 1.540022111100565F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_133", CubeListBuilder.create().texOffs(780, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.9537490882119F, -23.74999929140054F, 10.97063985192749F, 1.540022111100565F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("capo_t_punta_134", CubeListBuilder.create().texOffs(802, 131).addBox(-3.5F, -1.0F, -2.0F, 7.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(72.82882910424497F, -27.049999709775754F, 10.96909832151049F, 1.5333995309262858F, 0.0024945560459868447F, -1.611080774673202F));
        g.addOrReplaceChild("capo_t_punta_135", CubeListBuilder.create().texOffs(1004, 142).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(72.57113529824514F, -29.000000094577018F, 10.969147254459104F, 1.5152975424230264F, 0.0051353737629222474F, -1.7314250122029289F));
        g.addOrReplaceChild("capo_t_punta_136", CubeListBuilder.create().texOffs(72, 150).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(72.30017668798286F, -29.79999974398934F, 10.977762674559377F, 1.4965471229957779F, -0.004366299950573157F, -1.7373964872518304F));
        g.addOrReplaceChild("capo_t_punta_137", CubeListBuilder.create().texOffs(98, 150).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(72.07982683688981F, -30.2F, 10.751550099731162F, 0.0F, 0.7711669425231379F, -3.141592653589793F));
        g.addOrReplaceChild("faroti_0", CubeListBuilder.create().texOffs(258, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(806, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.9F, -27.0F, -4.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faroti_1", CubeListBuilder.create().texOffs(282, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(830, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.9F, -27.0F, -4.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faroti_2", CubeListBuilder.create().texOffs(306, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(854, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.9F, -27.0F, -4.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faroti_3", CubeListBuilder.create().texOffs(330, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(878, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.9F, -27.0F, -4.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faroti_vidrio", CubeListBuilder.create().texOffs(80, 107).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(77.52000000000001F, -27.0F, -4.0F, 0.0F, 0.0F, -1.5707963267948966F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("farotd_0", CubeListBuilder.create().texOffs(354, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(902, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.9F, -27.0F, 4.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("farotd_1", CubeListBuilder.create().texOffs(378, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(926, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.9F, -27.0F, 4.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("farotd_2", CubeListBuilder.create().texOffs(402, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(950, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.9F, -27.0F, 4.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("farotd_3", CubeListBuilder.create().texOffs(426, 142).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(974, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(76.9F, -27.0F, 4.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("farotd_vidrio", CubeListBuilder.create().texOffs(120, 107).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(77.52000000000001F, -27.0F, 4.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escapet_0", CubeListBuilder.create().texOffs(376, 107).addBox(-13.0F, -33.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(572, 50).addBox(-3.5F, -33.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offset(40.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("escapet_1", CubeListBuilder.create().texOffs(442, 107).addBox(-13.0F, -33.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(638, 50).addBox(-3.5F, -33.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offsetAndRotation(40.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("escapet_2", CubeListBuilder.create().texOffs(508, 107).addBox(-13.0F, -33.0F, -3.5F, 26.0F, 3.0F, 7.0F).texOffs(704, 50).addBox(-3.5F, -33.0F, -13.0F, 7.0F, 3.0F, 26.0F), PartPose.offsetAndRotation(40.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(360, 0).addBox(-14.0F, -33.0F, -13.0F, 28.0F, 18.0F, 26.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(248, 137).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.90144285687109F, -12.001239789140254F, -2.640312615451845F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(314, 137).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.902841173670865F, -9.958053116088472F, -2.7314544405678354F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(380, 137).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.7141210914645F, -7.832203811737248F, -2.822596265683827F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(446, 137).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.328548107840376F, -5.641338728859422F, -2.9137380907998165F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(512, 137).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.74102181277628F, -3.403644421639985F, -3.0048799159158044F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(578, 137).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.948118227569324F, -1.137696177569591F, -3.096021741031799F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(644, 137).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.948118227569324F, 1.1376961775695895F, 3.0960217410317985F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(710, 137).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.74102181277628F, 3.4036444216399833F, 3.0048799159158044F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(776, 137).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -36.328548107840376F, 5.641338728859421F, 2.913738090799817F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(842, 137).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.7141210914645F, 7.832203811737246F, 2.8225962656838264F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(908, 137).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.902841173670865F, 9.958053116088472F, 2.7314544405678354F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(0, 142).addBox(-15.0F, -1.0F, -1.5F, 30.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.90144285687109F, 12.001239789140252F, 2.640312615451845F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_forro", CubeListBuilder.create().texOffs(458, 81).addBox(-13.0F, -32.0F, 11.5F, 26.0F, 16.0F, 1.0F).texOffs(512, 81).addBox(-13.0F, -32.0F, -12.5F, 26.0F, 16.0F, 1.0F).texOffs(468, 0).addBox(12.0F, -32.0F, -11.5F, 1.0F, 16.0F, 23.0F).texOffs(770, 50).addBox(-13.0F, -16.0F, -12.5F, 26.0F, 1.0F, 25.0F).texOffs(872, 50).addBox(-13.0F, -33.0F, -12.5F, 26.0F, 1.0F, 25.0F).texOffs(516, 0).addBox(-13.0F, -32.0F, -11.5F, 1.0F, 16.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_pupitre", CubeListBuilder.create().texOffs(432, 81).addBox(-12.0F, -25.0F, -11.5F, 4.0F, 9.0F, 9.0F).texOffs(160, 107).addBox(-12.0F, -28.0F, -11.0F, 1.0F, 3.0F, 8.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(566, 81).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-10.4F, -26.5F, -7.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(104, 150).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-10.280000000000001F, -26.5F, -7.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro0", CubeListBuilder.create().texOffs(574, 107).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-10.4F, -26.5F, -10.6F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro0_aguja", CubeListBuilder.create().texOffs(262, 157).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-10.280000000000001F, -26.5F, -10.6F, 0.4F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro1", CubeListBuilder.create().texOffs(610, 107).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-10.4F, -26.5F, -3.4000000000000004F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro1_aguja", CubeListBuilder.create().texOffs(266, 157).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-10.280000000000001F, -26.5F, -3.4000000000000004F, 1.1F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_luces", CubeListBuilder.create().texOffs(270, 157).addBox(-10.0F, -26.0F, -11.0F, 1.0F, 1.0F, 1.0F).texOffs(274, 157).addBox(-10.0F, -26.0F, -9.8F, 1.0F, 1.0F, 1.0F).texOffs(278, 157).addBox(-10.0F, -26.0F, -8.6F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(240, 137).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F).texOffs(24, 146).addBox(-1.0F, -6.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-10.0F, -25.0F, -4.0F, 0.0F, 0.0F, 0.15F));
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(244, 137).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(-10.0F, -25.5F, -10.0F, 0.0F, 0.0F, -2.4668517113662407F));
        g.addOrReplaceChild("cab_freno_perilla", CubeListBuilder.create().texOffs(282, 157).addBox(-8.5F, -28.5F, -10.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(666, 107).addBox(0.0F, -22.0F, -8.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(676, 107).addBox(0.0F, -22.0F, 4.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento2", CubeListBuilder.create().texOffs(686, 107).addBox(7.0F, -22.0F, -2.0F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "capo_f_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_f_cantoi_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_f_cantoi_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "capo_f_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_f_cantoi_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_f_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_f_cantod_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_f_cantod_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "capo_f_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_f_cantod_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_f_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_f_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_f_punta_0", 0.5071428166514592F, 1.0F, 0.4896004262542653F);
        escalar(g0, "capo_f_punta_1", 0.5071428166514592F, 1.0F, 0.4896004262542653F);
        escalar(g0, "capo_f_punta_2", 0.5071428166514597F, 1.0F, 0.4896004262542653F);
        escalar(g0, "capo_f_punta_3", 0.4528586445404467F, 1.0F, 0.4272143006556245F);
        escalar(g0, "capo_f_punta_4", 0.46506528190240454F, 1.0F, 0.39799780220159137F);
        escalar(g0, "capo_f_punta_5", 0.46819602653564407F, 1.0F, 0.32602083185782654F);
        escalar(g0, "capo_f_punta_6", 0.5296301015457558F, 1.0F, 0.3428970600493042F);
        escalar(g0, "capo_f_punta_7", 0.5071428166514592F, 1.0F, 0.4907871804904355F);
        escalar(g0, "capo_f_punta_8", 0.5071428166514592F, 1.0F, 0.4907871804904355F);
        escalar(g0, "capo_f_punta_9", 0.5071428166514597F, 1.0F, 0.4907871804904355F);
        escalar(g0, "capo_f_punta_10", 0.460593090099613F, 1.0F, 0.41044434091836657F);
        escalar(g0, "capo_f_punta_11", 0.3639315263088956F, 1.0F, 0.5324269736245367F);
        escalar(g0, "capo_f_punta_12", 0.3636461184825766F, 1.0F, 0.294389532708336F);
        escalar(g0, "capo_f_punta_13", 0.5071428166514592F, 1.0F, 0.389118385704248F);
        escalar(g0, "capo_f_punta_14", 0.5071428166514592F, 1.0F, 0.389118385704248F);
        escalar(g0, "capo_f_punta_15", 0.5071428166514597F, 1.0F, 0.389118385704248F);
        escalar(g0, "capo_f_punta_16", 0.46928359199488223F, 1.0F, 0.3456117762115788F);
        escalar(g0, "capo_f_punta_17", 0.41040310656971185F, 1.0F, 0.5301090789280435F);
        escalar(g0, "capo_f_punta_18", 0.4068237311071974F, 1.0F, 0.36758022801732887F);
        escalar(g0, "capo_f_punta_19", 0.4252789956775301F, 1.0F, 0.5476671434560805F);
        escalar(g0, "capo_f_punta_20", 0.46877676912061794F, 1.0F, 0.3499093168126286F);
        escalar(g0, "capo_f_punta_21", 0.5071428166514592F, 1.0F, 0.4277761162984762F);
        escalar(g0, "capo_f_punta_22", 0.5071428166514592F, 1.0F, 0.4277761162984762F);
        escalar(g0, "capo_f_punta_23", 0.5071428166514597F, 1.0F, 0.4277761162984762F);
        escalar(g0, "capo_f_punta_24", 0.4757734392846599F, 1.0F, 0.4132906384757566F);
        escalar(g0, "capo_f_punta_25", 0.4425028215507016F, 1.0F, 0.3941223113059457F);
        escalar(g0, "capo_f_punta_26", 0.4407495750245874F, 1.0F, 0.39391442841177293F);
        escalar(g0, "capo_f_punta_27", 0.28870597678318005F, 1.0F, 0.331343725245009F);
        escalar(g0, "capo_f_punta_28", 0.5244549262478841F, 1.0F, 0.3347470159281233F);
        escalar(g0, "capo_f_punta_29", 0.5071428166514592F, 1.0F, 0.38688058328839886F);
        escalar(g0, "capo_f_punta_30", 0.5071428166514592F, 1.0F, 0.38688058328839886F);
        escalar(g0, "capo_f_punta_31", 0.5071428166514597F, 1.0F, 0.38688058328839886F);
        escalar(g0, "capo_f_punta_32", 0.4807626036739886F, 1.0F, 0.4006679940814972F);
        escalar(g0, "capo_f_punta_33", 0.46862125785954095F, 1.0F, 0.4406070144612804F);
        escalar(g0, "capo_f_punta_34", 0.47092278724338327F, 1.0F, 0.5132444701254584F);
        escalar(g0, "capo_f_punta_35", 0.43280447067811983F, 1.0F, 0.5072587718706119F);
        escalar(g0, "capo_f_punta_36", 0.36050514694334274F, 1.0F, 0.36245639498426335F);
        escalar(g0, "capo_f_punta_37", 0.5071428166514592F, 1.0F, 0.4105964425571099F);
        escalar(g0, "capo_f_punta_38", 0.5071428166514592F, 1.0F, 0.4105964425571099F);
        escalar(g0, "capo_f_punta_39", 0.5071428166514597F, 1.0F, 0.4105964425571099F);
        escalar(g0, "capo_f_punta_40", 0.4860632143072809F, 1.0F, 0.4273492463568454F);
        escalar(g0, "capo_f_punta_41", 0.4979023698565492F, 1.0F, 0.4609533674906638F);
        escalar(g0, "capo_f_punta_42", 0.5035457828013676F, 1.0F, 0.4930051665085994F);
        escalar(g0, "capo_f_punta_43", 0.4165958626073995F, 1.0F, 0.4988552386138588F);
        escalar(g0, "capo_f_punta_44", 0.5042066949721725F, 1.0F, 0.47841892766316985F);
        escalar(g0, "capo_f_punta_45", 0.5071428166514592F, 1.0F, 0.42462223908637686F);
        escalar(g0, "capo_f_punta_46", 0.5071428166514592F, 1.0F, 0.42462223908637686F);
        escalar(g0, "capo_f_punta_47", 0.5071428166514597F, 1.0F, 0.42462223908637686F);
        escalar(g0, "capo_f_punta_48", 0.49113096007230606F, 1.0F, 0.42849546487424084F);
        escalar(g0, "capo_f_punta_49", 0.39093739589483706F, 1.0F, 0.4326085442465609F);
        escalar(g0, "capo_f_punta_50", 0.3933034863295893F, 1.0F, 0.43031469184460003F);
        escalar(g0, "capo_f_punta_51", 0.4201998246656699F, 1.0F, 0.43004032439805684F);
        escalar(g0, "capo_f_punta_52", 0.518967603172467F, 1.0F, 0.43271811072566113F);
        escalar(g0, "capo_f_punta_53", 0.5071428166514592F, 1.0F, 0.49730812657788964F);
        escalar(g0, "capo_f_punta_54", 0.5071428166514592F, 1.0F, 0.49730812657788964F);
        escalar(g0, "capo_f_punta_55", 0.5071428166514597F, 1.0F, 0.49730812657788964F);
        escalar(g0, "capo_f_punta_56", 0.49344049066465967F, 1.0F, 0.48823098854120256F);
        escalar(g0, "capo_f_punta_57", 0.3962664685503172F, 1.0F, 0.4688037111803542F);
        escalar(g0, "capo_f_punta_58", 0.3963573556601509F, 1.0F, 0.4477259675933462F);
        escalar(g0, "capo_f_punta_59", 0.42004951677479635F, 1.0F, 0.43762766586747637F);
        escalar(g0, "capo_f_punta_60", 0.5246405031611397F, 1.0F, 0.43566336846419684F);
        escalar(g0, "capo_f_punta_61", 0.5071428166514592F, 1.0F, 0.45044357211317165F);
        escalar(g0, "capo_f_punta_62", 0.5071428166514592F, 1.0F, 0.45044357211317165F);
        escalar(g0, "capo_f_punta_63", 0.5071428166514597F, 1.0F, 0.45044357211317165F);
        escalar(g0, "capo_f_punta_64", 0.4933681906413702F, 1.0F, 0.4350488940273621F);
        escalar(g0, "capo_f_punta_65", 0.3950847882599107F, 1.0F, 0.4871637386362691F);
        escalar(g0, "capo_f_punta_66", 0.3949061661217343F, 1.0F, 0.45609878935140413F);
        escalar(g0, "capo_f_punta_67", 0.4201160039323992F, 1.0F, 0.4413031051257358F);
        escalar(g0, "capo_f_punta_68", 0.3501920652104695F, 1.0F, 0.4372426990824302F);
        escalar(g0, "capo_f_punta_69", 0.5071428166514592F, 1.0F, 0.4504438190138602F);
        escalar(g0, "capo_f_punta_70", 0.5071428166514592F, 1.0F, 0.4504438190138602F);
        escalar(g0, "capo_f_punta_71", 0.5071428166514597F, 1.0F, 0.4504438190138602F);
        escalar(g0, "capo_f_punta_72", 0.49336819064137216F, 1.0F, 0.43504914785588444F);
        escalar(g0, "capo_f_punta_73", 0.3950847882599409F, 1.0F, 0.48716415817380926F);
        escalar(g0, "capo_f_punta_74", 0.3949061661218943F, 1.0F, 0.4560995928463992F);
        escalar(g0, "capo_f_punta_75", 0.4201160039323818F, 1.0F, 0.4413040298683161F);
        escalar(g0, "capo_f_punta_76", 0.35019206521041485F, 1.0F, 0.4372430834137434F);
        escalar(g0, "capo_f_punta_77", 0.5071428166514592F, 1.0F, 0.49730812657819545F);
        escalar(g0, "capo_f_punta_78", 0.5071428166514592F, 1.0F, 0.49730812657819545F);
        escalar(g0, "capo_f_punta_79", 0.5071428166514597F, 1.0F, 0.49730812657819545F);
        escalar(g0, "capo_f_punta_80", 0.49344049066465967F, 1.0F, 0.4882309885415779F);
        escalar(g0, "capo_f_punta_81", 0.39626646855042247F, 1.0F, 0.4688037111806575F);
        escalar(g0, "capo_f_punta_82", 0.3963573556603835F, 1.0F, 0.4477259675945027F);
        escalar(g0, "capo_f_punta_83", 0.4200495167747642F, 1.0F, 0.4376276658685841F);
        escalar(g0, "capo_f_punta_84", 0.52464050316093F, 1.0F, 0.4356633684642288F);
        escalar(g0, "capo_f_punta_85", 0.5071428166514592F, 1.0F, 0.42462223908644436F);
        escalar(g0, "capo_f_punta_86", 0.5071428166514592F, 1.0F, 0.42462223908644436F);
        escalar(g0, "capo_f_punta_87", 0.5071428166514597F, 1.0F, 0.42462223908644436F);
        escalar(g0, "capo_f_punta_88", 0.4911309600723032F, 1.0F, 0.42849546487426515F);
        escalar(g0, "capo_f_punta_89", 0.39093739589492243F, 1.0F, 0.43260854424683365F);
        escalar(g0, "capo_f_punta_90", 0.39330348632968287F, 1.0F, 0.4303146918454118F);
        escalar(g0, "capo_f_punta_91", 0.4201998246656942F, 1.0F, 0.4300403243994085F);
        escalar(g0, "capo_f_punta_92", 0.5189676031723364F, 1.0F, 0.43271811072648364F);
        escalar(g0, "capo_f_punta_93", 0.5071428166514592F, 1.0F, 0.4105964425569185F);
        escalar(g0, "capo_f_punta_94", 0.5071428166514592F, 1.0F, 0.4105964425569185F);
        escalar(g0, "capo_f_punta_95", 0.5071428166514597F, 1.0F, 0.4105964425569185F);
        escalar(g0, "capo_f_punta_96", 0.4860632143072784F, 1.0F, 0.4273492463566381F);
        escalar(g0, "capo_f_punta_97", 0.49790236985656794F, 1.0F, 0.4609533674906265F);
        escalar(g0, "capo_f_punta_98", 0.5035457828014095F, 1.0F, 0.4930051665086626F);
        escalar(g0, "capo_f_punta_99", 0.41659586260734277F, 1.0F, 0.49885523861390607F);
        escalar(g0, "capo_f_punta_100", 0.5042066949721801F, 1.0F, 0.47841892766322397F);
        escalar(g0, "capo_f_punta_101", 0.5071428166514592F, 1.0F, 0.3868805832883913F);
        escalar(g0, "capo_f_punta_102", 0.5071428166514592F, 1.0F, 0.3868805832883913F);
        escalar(g0, "capo_f_punta_103", 0.5071428166514597F, 1.0F, 0.3868805832883913F);
        escalar(g0, "capo_f_punta_104", 0.480762603673985F, 1.0F, 0.40066799408150194F);
        escalar(g0, "capo_f_punta_105", 0.4686212578595684F, 1.0F, 0.44060701446126554F);
        escalar(g0, "capo_f_punta_106", 0.47092278724338743F, 1.0F, 0.5132444701256657F);
        escalar(g0, "capo_f_punta_107", 0.4328044706780047F, 1.0F, 0.5072587718708264F);
        escalar(g0, "capo_f_punta_108", 0.36050514694336644F, 1.0F, 0.36245639498425647F);
        escalar(g0, "capo_f_punta_109", 0.5071428166514592F, 1.0F, 0.42777611629848483F);
        escalar(g0, "capo_f_punta_110", 0.5071428166514592F, 1.0F, 0.42777611629848483F);
        escalar(g0, "capo_f_punta_111", 0.5071428166514597F, 1.0F, 0.42777611629848483F);
        escalar(g0, "capo_f_punta_112", 0.47577343928465565F, 1.0F, 0.4132906384757781F);
        escalar(g0, "capo_f_punta_113", 0.4425028215507339F, 1.0F, 0.3941223113058981F);
        escalar(g0, "capo_f_punta_114", 0.4407495750245755F, 1.0F, 0.3939144284116706F);
        escalar(g0, "capo_f_punta_115", 0.28870597678317134F, 1.0F, 0.33134372524492633F);
        escalar(g0, "capo_f_punta_116", 0.5244549262479031F, 1.0F, 0.3347470159280792F);
        escalar(g0, "capo_f_punta_117", 0.5071428166514592F, 1.0F, 0.38911838570425544F);
        escalar(g0, "capo_f_punta_118", 0.5071428166514592F, 1.0F, 0.38911838570425544F);
        escalar(g0, "capo_f_punta_119", 0.5071428166514597F, 1.0F, 0.38911838570425544F);
        escalar(g0, "capo_f_punta_120", 0.46928359199487785F, 1.0F, 0.3456117762115828F);
        escalar(g0, "capo_f_punta_121", 0.4104031065697305F, 1.0F, 0.5301090789280347F);
        escalar(g0, "capo_f_punta_122", 0.4068237311071934F, 1.0F, 0.36758022801731105F);
        escalar(g0, "capo_f_punta_123", 0.42527899567753885F, 1.0F, 0.5476671434560608F);
        escalar(g0, "capo_f_punta_124", 0.46877676912061195F, 1.0F, 0.3499093168126117F);
        escalar(g0, "capo_f_punta_125", 0.5071428166514592F, 1.0F, 0.49078718049043335F);
        escalar(g0, "capo_f_punta_126", 0.5071428166514592F, 1.0F, 0.49078718049043335F);
        escalar(g0, "capo_f_punta_127", 0.5071428166514597F, 1.0F, 0.49078718049043335F);
        escalar(g0, "capo_f_punta_128", 0.4605930900996089F, 1.0F, 0.4104443409183595F);
        escalar(g0, "capo_f_punta_129", 0.36393152630891334F, 1.0F, 0.5324269736245225F);
        escalar(g0, "capo_f_punta_130", 0.3636461184825735F, 1.0F, 0.2943895327083333F);
        escalar(g0, "capo_f_punta_131", 0.5071428166514592F, 1.0F, 0.4896004262542475F);
        escalar(g0, "capo_f_punta_132", 0.5071428166514592F, 1.0F, 0.4896004262542475F);
        escalar(g0, "capo_f_punta_133", 0.5071428166514597F, 1.0F, 0.4896004262542475F);
        escalar(g0, "capo_f_punta_134", 0.45285864454044494F, 1.0F, 0.4272143006556263F);
        escalar(g0, "capo_f_punta_135", 0.4650652819024183F, 1.0F, 0.3979978022016033F);
        escalar(g0, "capo_f_punta_136", 0.4681960265356421F, 1.0F, 0.32602083185782293F);
        escalar(g0, "capo_f_punta_137", 0.5296301015457534F, 1.0F, 0.3428970600493044F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "farofi_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farofi_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farofi_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farofi_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farofi_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "farofd_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farofd_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farofd_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farofd_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farofd_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "escapef_0", 0.11888317862019303F, 1.0F, 0.11888317862019303F);
        escalar(g0, "escapef_1", 0.11888317862019303F, 1.0F, 0.11888317862019303F);
        escalar(g0, "escapef_2", 0.11888317862019303F, 1.0F, 0.11888317862019303F);
        escalar(g0, "capo_t_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_t_cantoi_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_t_cantoi_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "capo_t_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_t_cantoi_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_t_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_t_cantod_1", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_t_cantod_2", 1.0F, 1.0F, 0.9386067902413856F);
        escalar(g0, "capo_t_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "capo_t_cantod_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "capo_t_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_t_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_t_punta_0", 0.5071428166514592F, 1.0F, 0.4896004262542653F);
        escalar(g0, "capo_t_punta_1", 0.5071428166514592F, 1.0F, 0.4896004262542653F);
        escalar(g0, "capo_t_punta_2", 0.5071428166514597F, 1.0F, 0.4896004262542653F);
        escalar(g0, "capo_t_punta_3", 0.4528586445404467F, 1.0F, 0.4272143006556245F);
        escalar(g0, "capo_t_punta_4", 0.46506528190240454F, 1.0F, 0.39799780220159137F);
        escalar(g0, "capo_t_punta_5", 0.46819602653564407F, 1.0F, 0.32602083185782654F);
        escalar(g0, "capo_t_punta_6", 0.5296301015457558F, 1.0F, 0.3428970600493042F);
        escalar(g0, "capo_t_punta_7", 0.5071428166514592F, 1.0F, 0.4907871804904355F);
        escalar(g0, "capo_t_punta_8", 0.5071428166514592F, 1.0F, 0.4907871804904355F);
        escalar(g0, "capo_t_punta_9", 0.5071428166514597F, 1.0F, 0.4907871804904355F);
        escalar(g0, "capo_t_punta_10", 0.460593090099613F, 1.0F, 0.41044434091836657F);
        escalar(g0, "capo_t_punta_11", 0.3639315263088956F, 1.0F, 0.5324269736245367F);
        escalar(g0, "capo_t_punta_12", 0.3636461184825766F, 1.0F, 0.294389532708336F);
        escalar(g0, "capo_t_punta_13", 0.5071428166514592F, 1.0F, 0.389118385704248F);
        escalar(g0, "capo_t_punta_14", 0.5071428166514592F, 1.0F, 0.389118385704248F);
        escalar(g0, "capo_t_punta_15", 0.5071428166514597F, 1.0F, 0.389118385704248F);
        escalar(g0, "capo_t_punta_16", 0.46928359199488223F, 1.0F, 0.3456117762115788F);
        escalar(g0, "capo_t_punta_17", 0.41040310656971185F, 1.0F, 0.5301090789280435F);
        escalar(g0, "capo_t_punta_18", 0.4068237311071974F, 1.0F, 0.36758022801732887F);
        escalar(g0, "capo_t_punta_19", 0.4252789956775301F, 1.0F, 0.5476671434560805F);
        escalar(g0, "capo_t_punta_20", 0.46877676912061794F, 1.0F, 0.3499093168126286F);
        escalar(g0, "capo_t_punta_21", 0.5071428166514592F, 1.0F, 0.4277761162984762F);
        escalar(g0, "capo_t_punta_22", 0.5071428166514592F, 1.0F, 0.4277761162984762F);
        escalar(g0, "capo_t_punta_23", 0.5071428166514597F, 1.0F, 0.4277761162984762F);
        escalar(g0, "capo_t_punta_24", 0.4757734392846599F, 1.0F, 0.4132906384757566F);
        escalar(g0, "capo_t_punta_25", 0.4425028215507016F, 1.0F, 0.3941223113059457F);
        escalar(g0, "capo_t_punta_26", 0.4407495750245874F, 1.0F, 0.39391442841177293F);
        escalar(g0, "capo_t_punta_27", 0.28870597678318005F, 1.0F, 0.331343725245009F);
        escalar(g0, "capo_t_punta_28", 0.5244549262478841F, 1.0F, 0.3347470159281233F);
        escalar(g0, "capo_t_punta_29", 0.5071428166514592F, 1.0F, 0.38688058328839886F);
        escalar(g0, "capo_t_punta_30", 0.5071428166514592F, 1.0F, 0.38688058328839886F);
        escalar(g0, "capo_t_punta_31", 0.5071428166514597F, 1.0F, 0.38688058328839886F);
        escalar(g0, "capo_t_punta_32", 0.4807626036739886F, 1.0F, 0.4006679940814972F);
        escalar(g0, "capo_t_punta_33", 0.46862125785954095F, 1.0F, 0.4406070144612804F);
        escalar(g0, "capo_t_punta_34", 0.47092278724338327F, 1.0F, 0.5132444701254584F);
        escalar(g0, "capo_t_punta_35", 0.43280447067811983F, 1.0F, 0.5072587718706119F);
        escalar(g0, "capo_t_punta_36", 0.36050514694334274F, 1.0F, 0.36245639498426335F);
        escalar(g0, "capo_t_punta_37", 0.5071428166514592F, 1.0F, 0.4105964425571099F);
        escalar(g0, "capo_t_punta_38", 0.5071428166514592F, 1.0F, 0.4105964425571099F);
        escalar(g0, "capo_t_punta_39", 0.5071428166514597F, 1.0F, 0.4105964425571099F);
        escalar(g0, "capo_t_punta_40", 0.4860632143072809F, 1.0F, 0.4273492463568454F);
        escalar(g0, "capo_t_punta_41", 0.4979023698565492F, 1.0F, 0.4609533674906638F);
        escalar(g0, "capo_t_punta_42", 0.5035457828013676F, 1.0F, 0.4930051665085994F);
        escalar(g0, "capo_t_punta_43", 0.4165958626073995F, 1.0F, 0.4988552386138588F);
        escalar(g0, "capo_t_punta_44", 0.5042066949721725F, 1.0F, 0.47841892766316985F);
        escalar(g0, "capo_t_punta_45", 0.5071428166514592F, 1.0F, 0.42462223908637686F);
        escalar(g0, "capo_t_punta_46", 0.5071428166514592F, 1.0F, 0.42462223908637686F);
        escalar(g0, "capo_t_punta_47", 0.5071428166514597F, 1.0F, 0.42462223908637686F);
        escalar(g0, "capo_t_punta_48", 0.49113096007230606F, 1.0F, 0.42849546487424084F);
        escalar(g0, "capo_t_punta_49", 0.39093739589483706F, 1.0F, 0.4326085442465609F);
        escalar(g0, "capo_t_punta_50", 0.3933034863295893F, 1.0F, 0.43031469184460003F);
        escalar(g0, "capo_t_punta_51", 0.4201998246656699F, 1.0F, 0.43004032439805684F);
        escalar(g0, "capo_t_punta_52", 0.518967603172467F, 1.0F, 0.43271811072566113F);
        escalar(g0, "capo_t_punta_53", 0.5071428166514592F, 1.0F, 0.49730812657788964F);
        escalar(g0, "capo_t_punta_54", 0.5071428166514592F, 1.0F, 0.49730812657788964F);
        escalar(g0, "capo_t_punta_55", 0.5071428166514597F, 1.0F, 0.49730812657788964F);
        escalar(g0, "capo_t_punta_56", 0.49344049066465967F, 1.0F, 0.48823098854120256F);
        escalar(g0, "capo_t_punta_57", 0.3962664685503172F, 1.0F, 0.4688037111803542F);
        escalar(g0, "capo_t_punta_58", 0.3963573556601509F, 1.0F, 0.4477259675933462F);
        escalar(g0, "capo_t_punta_59", 0.42004951677479635F, 1.0F, 0.43762766586747637F);
        escalar(g0, "capo_t_punta_60", 0.5246405031611397F, 1.0F, 0.43566336846419684F);
        escalar(g0, "capo_t_punta_61", 0.5071428166514592F, 1.0F, 0.45044357211317165F);
        escalar(g0, "capo_t_punta_62", 0.5071428166514592F, 1.0F, 0.45044357211317165F);
        escalar(g0, "capo_t_punta_63", 0.5071428166514597F, 1.0F, 0.45044357211317165F);
        escalar(g0, "capo_t_punta_64", 0.4933681906413702F, 1.0F, 0.4350488940273621F);
        escalar(g0, "capo_t_punta_65", 0.3950847882599107F, 1.0F, 0.4871637386362691F);
        escalar(g0, "capo_t_punta_66", 0.3949061661217343F, 1.0F, 0.45609878935140413F);
        escalar(g0, "capo_t_punta_67", 0.4201160039323992F, 1.0F, 0.4413031051257358F);
        escalar(g0, "capo_t_punta_68", 0.3501920652104695F, 1.0F, 0.4372426990824302F);
        escalar(g0, "capo_t_punta_69", 0.5071428166514592F, 1.0F, 0.4504438190138602F);
        escalar(g0, "capo_t_punta_70", 0.5071428166514592F, 1.0F, 0.4504438190138602F);
        escalar(g0, "capo_t_punta_71", 0.5071428166514597F, 1.0F, 0.4504438190138602F);
        escalar(g0, "capo_t_punta_72", 0.49336819064137216F, 1.0F, 0.43504914785588444F);
        escalar(g0, "capo_t_punta_73", 0.3950847882599409F, 1.0F, 0.48716415817380926F);
        escalar(g0, "capo_t_punta_74", 0.3949061661218943F, 1.0F, 0.4560995928463992F);
        escalar(g0, "capo_t_punta_75", 0.4201160039323818F, 1.0F, 0.4413040298683161F);
        escalar(g0, "capo_t_punta_76", 0.35019206521041485F, 1.0F, 0.4372430834137434F);
        escalar(g0, "capo_t_punta_77", 0.5071428166514592F, 1.0F, 0.49730812657819545F);
        escalar(g0, "capo_t_punta_78", 0.5071428166514592F, 1.0F, 0.49730812657819545F);
        escalar(g0, "capo_t_punta_79", 0.5071428166514597F, 1.0F, 0.49730812657819545F);
        escalar(g0, "capo_t_punta_80", 0.49344049066465967F, 1.0F, 0.4882309885415779F);
        escalar(g0, "capo_t_punta_81", 0.39626646855042247F, 1.0F, 0.4688037111806575F);
        escalar(g0, "capo_t_punta_82", 0.3963573556603835F, 1.0F, 0.4477259675945027F);
        escalar(g0, "capo_t_punta_83", 0.4200495167747642F, 1.0F, 0.4376276658685841F);
        escalar(g0, "capo_t_punta_84", 0.52464050316093F, 1.0F, 0.4356633684642288F);
        escalar(g0, "capo_t_punta_85", 0.5071428166514592F, 1.0F, 0.42462223908644436F);
        escalar(g0, "capo_t_punta_86", 0.5071428166514592F, 1.0F, 0.42462223908644436F);
        escalar(g0, "capo_t_punta_87", 0.5071428166514597F, 1.0F, 0.42462223908644436F);
        escalar(g0, "capo_t_punta_88", 0.4911309600723032F, 1.0F, 0.42849546487426515F);
        escalar(g0, "capo_t_punta_89", 0.39093739589492243F, 1.0F, 0.43260854424683365F);
        escalar(g0, "capo_t_punta_90", 0.39330348632968287F, 1.0F, 0.4303146918454118F);
        escalar(g0, "capo_t_punta_91", 0.4201998246656942F, 1.0F, 0.4300403243994085F);
        escalar(g0, "capo_t_punta_92", 0.5189676031723364F, 1.0F, 0.43271811072648364F);
        escalar(g0, "capo_t_punta_93", 0.5071428166514592F, 1.0F, 0.4105964425569185F);
        escalar(g0, "capo_t_punta_94", 0.5071428166514592F, 1.0F, 0.4105964425569185F);
        escalar(g0, "capo_t_punta_95", 0.5071428166514597F, 1.0F, 0.4105964425569185F);
        escalar(g0, "capo_t_punta_96", 0.4860632143072784F, 1.0F, 0.4273492463566381F);
        escalar(g0, "capo_t_punta_97", 0.49790236985656794F, 1.0F, 0.4609533674906265F);
        escalar(g0, "capo_t_punta_98", 0.5035457828014095F, 1.0F, 0.4930051665086626F);
        escalar(g0, "capo_t_punta_99", 0.41659586260734277F, 1.0F, 0.49885523861390607F);
        escalar(g0, "capo_t_punta_100", 0.5042066949721801F, 1.0F, 0.47841892766322397F);
        escalar(g0, "capo_t_punta_101", 0.5071428166514592F, 1.0F, 0.3868805832883913F);
        escalar(g0, "capo_t_punta_102", 0.5071428166514592F, 1.0F, 0.3868805832883913F);
        escalar(g0, "capo_t_punta_103", 0.5071428166514597F, 1.0F, 0.3868805832883913F);
        escalar(g0, "capo_t_punta_104", 0.480762603673985F, 1.0F, 0.40066799408150194F);
        escalar(g0, "capo_t_punta_105", 0.4686212578595684F, 1.0F, 0.44060701446126554F);
        escalar(g0, "capo_t_punta_106", 0.47092278724338743F, 1.0F, 0.5132444701256657F);
        escalar(g0, "capo_t_punta_107", 0.4328044706780047F, 1.0F, 0.5072587718708264F);
        escalar(g0, "capo_t_punta_108", 0.36050514694336644F, 1.0F, 0.36245639498425647F);
        escalar(g0, "capo_t_punta_109", 0.5071428166514592F, 1.0F, 0.42777611629848483F);
        escalar(g0, "capo_t_punta_110", 0.5071428166514592F, 1.0F, 0.42777611629848483F);
        escalar(g0, "capo_t_punta_111", 0.5071428166514597F, 1.0F, 0.42777611629848483F);
        escalar(g0, "capo_t_punta_112", 0.47577343928465565F, 1.0F, 0.4132906384757781F);
        escalar(g0, "capo_t_punta_113", 0.4425028215507339F, 1.0F, 0.3941223113058981F);
        escalar(g0, "capo_t_punta_114", 0.4407495750245755F, 1.0F, 0.3939144284116706F);
        escalar(g0, "capo_t_punta_115", 0.28870597678317134F, 1.0F, 0.33134372524492633F);
        escalar(g0, "capo_t_punta_116", 0.5244549262479031F, 1.0F, 0.3347470159280792F);
        escalar(g0, "capo_t_punta_117", 0.5071428166514592F, 1.0F, 0.38911838570425544F);
        escalar(g0, "capo_t_punta_118", 0.5071428166514592F, 1.0F, 0.38911838570425544F);
        escalar(g0, "capo_t_punta_119", 0.5071428166514597F, 1.0F, 0.38911838570425544F);
        escalar(g0, "capo_t_punta_120", 0.46928359199487785F, 1.0F, 0.3456117762115828F);
        escalar(g0, "capo_t_punta_121", 0.4104031065697305F, 1.0F, 0.5301090789280347F);
        escalar(g0, "capo_t_punta_122", 0.4068237311071934F, 1.0F, 0.36758022801731105F);
        escalar(g0, "capo_t_punta_123", 0.42527899567753885F, 1.0F, 0.5476671434560608F);
        escalar(g0, "capo_t_punta_124", 0.46877676912061195F, 1.0F, 0.3499093168126117F);
    }

    private static void escalas2(ModelPart g0) {
        escalar(g0, "capo_t_punta_125", 0.5071428166514592F, 1.0F, 0.49078718049043335F);
        escalar(g0, "capo_t_punta_126", 0.5071428166514592F, 1.0F, 0.49078718049043335F);
        escalar(g0, "capo_t_punta_127", 0.5071428166514597F, 1.0F, 0.49078718049043335F);
        escalar(g0, "capo_t_punta_128", 0.4605930900996089F, 1.0F, 0.4104443409183595F);
        escalar(g0, "capo_t_punta_129", 0.36393152630891334F, 1.0F, 0.5324269736245225F);
        escalar(g0, "capo_t_punta_130", 0.3636461184825735F, 1.0F, 0.2943895327083333F);
        escalar(g0, "capo_t_punta_131", 0.5071428166514592F, 1.0F, 0.4896004262542475F);
        escalar(g0, "capo_t_punta_132", 0.5071428166514592F, 1.0F, 0.4896004262542475F);
        escalar(g0, "capo_t_punta_133", 0.5071428166514597F, 1.0F, 0.4896004262542475F);
        escalar(g0, "capo_t_punta_134", 0.45285864454044494F, 1.0F, 0.4272143006556263F);
        escalar(g0, "capo_t_punta_135", 0.4650652819024183F, 1.0F, 0.3979978022016033F);
        escalar(g0, "capo_t_punta_136", 0.4681960265356421F, 1.0F, 0.32602083185782293F);
        escalar(g0, "capo_t_punta_137", 0.5296301015457534F, 1.0F, 0.3428970600493044F);
        escalar(g0, "faroti_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faroti_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faroti_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faroti_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "faroti_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "farotd_0", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farotd_1", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farotd_2", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farotd_3", 0.2353884672967753F, 0.6F, 0.2353884672967753F);
        escalar(g0, "farotd_vidrio", 0.24F, 0.15F, 0.24F);
        escalar(g0, "escapet_0", 0.11888317862019303F, 1.0F, 0.11888317862019303F);
        escalar(g0, "escapet_1", 0.11888317862019303F, 1.0F, 0.11888317862019303F);
        escalar(g0, "escapet_2", 0.11888317862019303F, 1.0F, 0.11888317862019303F);
        escalar(g0, "cabina_techo_0", 1.0006666666666666F, 1.0F, 0.7659190213674397F);
        escalar(g0, "cabina_techo_1", 1.0006666666666666F, 1.0F, 0.7659190213674404F);
        escalar(g0, "cabina_techo_2", 1.0006666666666666F, 1.0F, 0.7659190213674401F);
        escalar(g0, "cabina_techo_3", 1.0006666666666666F, 1.0F, 0.7659190213674402F);
        escalar(g0, "cabina_techo_4", 1.0006666666666666F, 1.0F, 0.7659190213674404F);
        escalar(g0, "cabina_techo_5", 1.0006666666666666F, 1.0F, 0.7659190213674406F);
        escalar(g0, "cabina_techo_6", 1.0006666666666666F, 1.0F, 0.7659190213674396F);
        escalar(g0, "cabina_techo_7", 1.0006666666666666F, 1.0F, 0.765919021367441F);
        escalar(g0, "cabina_techo_8", 1.0006666666666666F, 1.0F, 0.7659190213674404F);
        escalar(g0, "cabina_techo_9", 1.0006666666666666F, 1.0F, 0.7659190213674395F);
        escalar(g0, "cabina_techo_10", 1.0006666666666666F, 1.0F, 0.7659190213674404F);
        escalar(g0, "cabina_techo_11", 1.0006666666666666F, 1.0F, 0.7659190213674402F);
        escalar(g0, "cab_velocimetro", 0.2333333333333333F, 0.6F, 0.2333333333333333F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.574F, 0.6F);
        escalar(g0, "cab_manometro0", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro0_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_manometro1", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro1_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_freno", 0.8F, 0.8003905296791061F, 0.8F);
    }
}
