package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Locomotion No. 1" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloLocomotion {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("locomotion"), "main"),
            LocomotoraMod.id("textures/entity/locomotion.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -8.0F, -5.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -8.0F, -5.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -8.0F, -5.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("contrai0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -8.0F, -5.5F, -2.2255716556094165F, "locomotora"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 5.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -5.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 5.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -5.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 5.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -5.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("contrai1", DatosModelo.RUEDA, 5.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -5.5F, -2.794884846710078F, "locomotora"),
                new DatosModelo.Animada("acople_i", DatosModelo.BIELA, 5.5F, 2.0F, -0.7853981633974483F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -8.0F, -5.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -8.0F, -5.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -8.0F, -5.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("contrad0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -8.0F, -5.5F, -2.2255716556094165F, "locomotora"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 5.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -5.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 5.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -5.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 5.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -5.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("contrad1", DatosModelo.RUEDA, 5.5F, 0.0F, 1.5707963267948966F, 0.0F, 8.0F, -5.5F, -2.794884846710078F, "locomotora"),
                new DatosModelo.Animada("acople_d", DatosModelo.BIELA, 5.5F, 2.0F, -0.7853981633974483F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta0", DatosModelo.CRUCETA_INCLINADA, 5.5F, 2.5F, 0.0F, 24.0F, 0.0F, 0.0F, 0.0F, "locomotora", 1.5707963267948966F),
                new DatosModelo.Animada("vastago0", DatosModelo.CRUCETA_INCLINADA, 5.5F, 2.5F, 0.0F, 24.0F, -8.0F, -32.0F, 0.0F, "locomotora", 1.5707963267948966F),
                new DatosModelo.Animada("biela0i", DatosModelo.MOTRIZ_INCLINADA, 5.5F, 2.5F, 0.0F, 24.0F, -8.0F, -8.0F, 3.141592653589793F, "locomotora", 1.5707963267948966F),
                new DatosModelo.Animada("biela0d", DatosModelo.MOTRIZ_INCLINADA, 5.5F, 2.5F, 0.0F, 24.0F, -8.0F, -8.0F, 3.141592653589793F, "locomotora", 1.5707963267948966F),
                new DatosModelo.Animada("cruceta1", DatosModelo.CRUCETA_INCLINADA, 5.5F, 2.5F, 1.5707963267948966F, 24.0F, 0.0F, 0.0F, 0.0F, "locomotora", 1.5707963267948966F),
                new DatosModelo.Animada("vastago1", DatosModelo.CRUCETA_INCLINADA, 5.5F, 2.5F, 1.5707963267948966F, 24.0F, 8.0F, -32.0F, 0.0F, "locomotora", 1.5707963267948966F),
                new DatosModelo.Animada("biela1i", DatosModelo.MOTRIZ_INCLINADA, 5.5F, 2.5F, 1.5707963267948966F, 24.0F, 8.0F, -8.0F, 3.141592653589793F, "locomotora", 1.5707963267948966F),
                new DatosModelo.Animada("biela1d", DatosModelo.MOTRIZ_INCLINADA, 5.5F, 2.5F, 1.5707963267948966F, 24.0F, 8.0F, -8.0F, 3.141592653589793F, "locomotora", 1.5707963267948966F),
                new DatosModelo.Animada("cab_manometro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 14.819999999999999F, -20.4F, 0.0F, "locomotora", 4.8F, 0.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.0F, 0.0F, 16.5F, -11.0F, 0.0F, "locomotora", -0.22F, 5.5F, 0.0F),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 30.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 42.0F, -4.0F, 1.0471975511965976F, "tender")),
            ModeloLocomotion::crearCapa,
            16.0F,
            ModeloLocomotion::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -8.0F, 8.0F),
                new DatosModelo.Segmento("tender", 30.0F, 42.0F)));

    private ModeloLocomotion() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g1);
        piezas4(g1);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
        escalas2(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(906, 45).addBox(-5.5F, -5.5F, -6.0F, 11.0F, 11.0F, 2.0F).texOffs(322, 86).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 73).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(32, 104).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(952, 115).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-8.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(348, 86).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(34, 73).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(374, 86).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(44, 73).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("contrai0", CubeListBuilder.create().texOffs(24, 118).addBox(1.482961921536142F, -0.29221516319278384F, -9.0F, 1.0F, 2.0F, 1.0F).texOffs(958, 115).addBox(0.982961921536142F, 0.7077848368072162F, -9.0F, 2.0F, 2.0F, 1.0F).texOffs(964, 115).addBox(0.9829619215361425F, -1.2922151631927838F, -9.0F, 2.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -5.5F, 0.0F, 0.0F, 0.0F, -2.2255716556094165F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(906, 45).addBox(-5.5F, -5.5F, -6.0F, 11.0F, 11.0F, 2.0F).texOffs(322, 86).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 73).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(42, 104).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(970, 115).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(8.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(348, 86).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(34, 73).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(374, 86).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(44, 73).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("contrai1", CubeListBuilder.create().texOffs(176, 104).addBox(0.3495083960150164F, -1.7402007746359982F, -9.0F, 1.0F, 4.0F, 1.0F).texOffs(976, 115).addBox(-0.15049160398498362F, 1.2597992253640018F, -9.0F, 2.0F, 2.0F, 1.0F).texOffs(982, 115).addBox(-0.15049160398498374F, -2.7402007746359978F, -9.0F, 2.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -5.5F, 0.0F, 0.0F, 0.0F, -2.794884846710078F));
        g.addOrReplaceChild("acople_i", CubeListBuilder.create().texOffs(36, 118).addBox(-8.0F, -8.0F, -10.0F, 16.0F, 1.0F, 1.0F).texOffs(268, 104).addBox(-9.5F, -9.0F, -10.0F, 3.0F, 3.0F, 1.0F).texOffs(276, 104).addBox(6.5F, -9.0F, -10.0F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(906, 45).addBox(-5.5F, -5.5F, 4.0F, 11.0F, 11.0F, 2.0F).texOffs(322, 86).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 73).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(52, 104).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(988, 115).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-8.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(348, 86).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(34, 73).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(374, 86).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(44, 73).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("contrad0", CubeListBuilder.create().texOffs(28, 118).addBox(1.482961921536142F, -0.29221516319278384F, 8.0F, 1.0F, 2.0F, 1.0F).texOffs(994, 115).addBox(0.982961921536142F, 0.7077848368072162F, 8.0F, 2.0F, 2.0F, 1.0F).texOffs(1000, 115).addBox(0.9829619215361425F, -1.2922151631927838F, 8.0F, 2.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -5.5F, 0.0F, 0.0F, 0.0F, -2.2255716556094165F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(906, 45).addBox(-5.5F, -5.5F, 4.0F, 11.0F, 11.0F, 2.0F).texOffs(322, 86).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(24, 73).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(62, 104).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(1006, 115).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(8.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(348, 86).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(34, 73).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(374, 86).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(44, 73).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("contrad1", CubeListBuilder.create().texOffs(180, 104).addBox(0.3495083960150164F, -1.7402007746359982F, 8.0F, 1.0F, 4.0F, 1.0F).texOffs(1012, 115).addBox(-0.15049160398498362F, 1.2597992253640018F, 8.0F, 2.0F, 2.0F, 1.0F).texOffs(1018, 115).addBox(-0.15049160398498374F, -2.7402007746359978F, 8.0F, 2.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -5.5F, 0.0F, 0.0F, 0.0F, -2.794884846710078F));
        g.addOrReplaceChild("acople_d", CubeListBuilder.create().texOffs(70, 118).addBox(-8.0F, -8.0F, 9.0F, 16.0F, 1.0F, 1.0F).texOffs(284, 104).addBox(-9.5F, -9.0F, 9.0F, 3.0F, 3.0F, 1.0F).texOffs(292, 104).addBox(6.5F, -9.0F, 9.0F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(70, 86).addBox(-17.0F, -11.0F, 1.5F, 34.0F, 4.0F, 2.0F).texOffs(142, 86).addBox(-17.0F, -11.0F, -3.5F, 34.0F, 4.0F, 2.0F).texOffs(82, 45).addBox(-18.0F, -11.0F, -8.0F, 2.0F, 6.0F, 16.0F).texOffs(118, 45).addBox(16.0F, -11.0F, -8.0F, 2.0F, 6.0F, 16.0F).texOffs(112, 104).addBox(-9.5F, -7.5F, 2.5F, 3.0F, 4.0F, 1.0F).texOffs(120, 104).addBox(-9.5F, -7.5F, -3.5F, 3.0F, 4.0F, 1.0F).texOffs(128, 104).addBox(6.5F, -7.5F, 2.5F, 3.0F, 4.0F, 1.0F).texOffs(136, 104).addBox(6.5F, -7.5F, -3.5F, 3.0F, 4.0F, 1.0F).texOffs(18, 86).addBox(-20.0F, -10.5F, 4.0F, 2.0F, 4.0F, 3.0F).texOffs(28, 86).addBox(-20.0F, -10.5F, -7.0F, 2.0F, 4.0F, 3.0F).texOffs(38, 86).addBox(18.0F, -10.5F, 4.0F, 2.0F, 4.0F, 3.0F).texOffs(48, 86).addBox(18.0F, -10.5F, -7.0F, 2.0F, 4.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("estribo", CubeListBuilder.create().texOffs(836, 45).addBox(14.0F, -11.0F, -7.0F, 6.0F, 1.0F, 14.0F).texOffs(58, 86).addBox(18.0F, -17.0F, 6.0F, 1.0F, 6.0F, 1.0F).texOffs(62, 86).addBox(18.0F, -17.0F, -7.0F, 1.0F, 6.0F, 1.0F).texOffs(876, 45).addBox(18.0F, -17.0F, -7.0F, 1.0F, 1.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(588, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -21.90629602229494F, 0.711752374031932F, 3.0106929596902194F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(608, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -21.90629602229494F, 0.711752374031932F, 3.0106929596902194F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(628, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -21.90629602229494F, 0.711752374031932F, 3.0106929596902194F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(648, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -21.90629602229494F, 0.711752374031932F, 3.0106929596902194F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(668, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -21.53786588270215F, 2.086752374031932F, 2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(688, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -21.53786588270215F, 2.086752374031932F, 2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(708, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -21.53786588270215F, 2.086752374031932F, 2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(728, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -21.53786588270215F, 2.086752374031932F, 2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(748, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -20.82611350867021F, 3.3195436482630054F, 2.487094184091918F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(768, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -20.82611350867021F, 3.3195436482630054F, 2.487094184091918F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(788, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -20.82611350867021F, 3.3195436482630054F, 2.487094184091918F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(808, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -20.82611350867021F, 3.3195436482630054F, 2.487094184091918F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(828, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -19.819543648263007F, 4.326113508670211F, 2.2252947962927707F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(848, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -19.819543648263007F, 4.326113508670211F, 2.2252947962927707F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(868, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -19.819543648263007F, 4.326113508670211F, 2.2252947962927707F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(888, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -19.819543648263007F, 4.326113508670211F, 2.2252947962927707F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(908, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -18.58675237403193F, 5.037865882702144F, 1.9634954084936214F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(928, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -18.58675237403193F, 5.037865882702144F, 1.9634954084936214F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(948, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -18.58675237403193F, 5.037865882702144F, 1.9634954084936214F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(968, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -18.58675237403193F, 5.037865882702144F, 1.9634954084936214F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(988, 109).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -17.21175237403193F, 5.406296022294938F, 1.7016960206944713F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(0, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -17.21175237403193F, 5.406296022294938F, 1.7016960206944713F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(20, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -17.21175237403193F, 5.406296022294938F, 1.7016960206944713F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(40, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -17.21175237403193F, 5.406296022294938F, 1.7016960206944713F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(60, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -15.788247625968069F, 5.4062960222949386F, 1.4398966328953222F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(80, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -15.788247625968069F, 5.4062960222949386F, 1.4398966328953222F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(100, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -15.788247625968069F, 5.4062960222949386F, 1.4398966328953222F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(120, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -15.788247625968069F, 5.4062960222949386F, 1.4398966328953222F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(140, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -14.413247625968069F, 5.037865882702144F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(160, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -14.413247625968069F, 5.037865882702144F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(180, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -14.413247625968069F, 5.037865882702144F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(200, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -14.413247625968069F, 5.037865882702144F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(220, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -13.180456351736996F, 4.326113508670213F, 0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(240, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -13.180456351736996F, 4.326113508670213F, 0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(260, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -13.180456351736996F, 4.326113508670213F, 0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(280, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -13.180456351736996F, 4.326113508670213F, 0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(300, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -12.173886491329789F, 3.3195436482630067F, 0.654498469497874F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(320, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -12.173886491329789F, 3.3195436482630067F, 0.654498469497874F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(340, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -12.173886491329789F, 3.3195436482630067F, 0.654498469497874F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(360, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -12.173886491329789F, 3.3195436482630067F, 0.654498469497874F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(380, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -11.462134117297857F, 2.0867523740319336F, 0.39269908169872464F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(400, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -11.462134117297857F, 2.0867523740319336F, 0.39269908169872464F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(420, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -11.462134117297857F, 2.0867523740319336F, 0.39269908169872464F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(440, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -11.462134117297857F, 2.0867523740319336F, 0.39269908169872464F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(460, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -11.093703977705061F, 0.7117523740319331F, 0.13089969389957481F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(480, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -11.093703977705061F, 0.7117523740319331F, 0.13089969389957481F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(500, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -11.093703977705061F, 0.7117523740319331F, 0.13089969389957481F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(520, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -11.093703977705061F, 0.7117523740319331F, 0.13089969389957481F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(540, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -11.093703977705061F, -0.7117523740319306F, -0.13089969389957382F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(560, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -11.093703977705061F, -0.7117523740319306F, -0.13089969389957382F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(580, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -11.093703977705061F, -0.7117523740319306F, -0.13089969389957382F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(600, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -11.093703977705061F, -0.7117523740319306F, -0.13089969389957382F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(620, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -11.462134117297854F, -2.086752374031929F, -0.39269908169872386F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(640, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -11.462134117297854F, -2.086752374031929F, -0.39269908169872386F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(660, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -11.462134117297854F, -2.086752374031929F, -0.39269908169872386F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(680, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -11.462134117297854F, -2.086752374031929F, -0.39269908169872386F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(700, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -12.173886491329785F, -3.3195436482630036F, -0.654498469497873F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(720, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -12.173886491329785F, -3.3195436482630036F, -0.654498469497873F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(740, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -12.173886491329785F, -3.3195436482630036F, -0.654498469497873F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(760, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -12.173886491329785F, -3.3195436482630036F, -0.654498469497873F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(780, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -13.180456351736993F, -4.326113508670211F, -0.9162978572970223F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(800, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -13.180456351736993F, -4.326113508670211F, -0.9162978572970223F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(820, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -13.180456351736993F, -4.326113508670211F, -0.9162978572970223F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(840, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -13.180456351736993F, -4.326113508670211F, -0.9162978572970223F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(860, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -14.413247625968063F, -5.0378658827021425F, -1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(880, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -14.413247625968063F, -5.0378658827021425F, -1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(900, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -14.413247625968063F, -5.0378658827021425F, -1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(920, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -14.413247625968063F, -5.0378658827021425F, -1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(940, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -15.788247625968065F, -5.406296022294937F, -1.4398966328953215F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(960, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -15.788247625968065F, -5.406296022294937F, -1.4398966328953215F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(980, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -15.788247625968065F, -5.406296022294937F, -1.4398966328953215F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(1000, 112).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -15.788247625968065F, -5.406296022294937F, -1.4398966328953215F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(0, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -17.21175237403193F, -5.4062960222949386F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(20, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -17.21175237403193F, -5.4062960222949386F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(40, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -17.21175237403193F, -5.4062960222949386F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(60, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -17.21175237403193F, -5.4062960222949386F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(80, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -18.58675237403193F, -5.037865882702146F, -1.96349540849362F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(100, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -18.58675237403193F, -5.037865882702146F, -1.96349540849362F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(120, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -18.58675237403193F, -5.037865882702146F, -1.96349540849362F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(140, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -18.58675237403193F, -5.037865882702146F, -1.96349540849362F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(160, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -19.819543648263004F, -4.326113508670214F, -2.22529479629277F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(180, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -19.819543648263004F, -4.326113508670214F, -2.22529479629277F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(200, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -19.819543648263004F, -4.326113508670214F, -2.22529479629277F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(220, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -19.819543648263004F, -4.326113508670214F, -2.22529479629277F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(240, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -20.82611350867021F, -3.319543648263007F, -2.487094184091919F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(260, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -20.82611350867021F, -3.319543648263007F, -2.487094184091919F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(280, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -20.82611350867021F, -3.319543648263007F, -2.487094184091919F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(300, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -20.82611350867021F, -3.319543648263007F, -2.487094184091919F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(320, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -21.537865882702143F, -2.086752374031936F, -2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(340, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -21.537865882702143F, -2.086752374031936F, -2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(360, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -21.537865882702143F, -2.086752374031936F, -2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(380, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -21.537865882702143F, -2.086752374031936F, -2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(400, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.375F, -21.90629602229494F, -0.711752374031935F, -3.010692959690217F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(420, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.125F, -21.90629602229494F, -0.711752374031935F, -3.010692959690217F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(440, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.125F, -21.90629602229494F, -0.711752374031935F, -3.010692959690217F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(460, 115).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.375F, -21.90629602229494F, -0.711752374031935F, -3.010692959690217F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_frente", CubeListBuilder.create().texOffs(0, 0).addBox(-22.0F, 0.0F, -22.0F, 44.0F, 1.0F, 44.0F), PartPose.offsetAndRotation(-15.05F, -16.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("caldera_atras", CubeListBuilder.create().texOffs(176, 0).addBox(-22.0F, 0.0F, -22.0F, 44.0F, 1.0F, 44.0F), PartPose.offsetAndRotation(14.05F, -16.5F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("puerta_fuego", CubeListBuilder.create().texOffs(0, 86).addBox(14.0F, -16.0F, -2.0F, 1.0F, 4.0F, 4.0F).texOffs(308, 104).addBox(14.5F, -15.0F, -1.0F, 1.0F, 2.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("chimenea_base_0", CubeListBuilder.create().texOffs(400, 86).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(932, 45).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offset(-12.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_base_1", CubeListBuilder.create().texOffs(424, 86).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(956, 45).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-12.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_base_2", CubeListBuilder.create().texOffs(448, 86).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(980, 45).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-12.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_base_3", CubeListBuilder.create().texOffs(472, 86).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 3.0F, 2.0F).texOffs(0, 73).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 3.0F, 10.0F), PartPose.offsetAndRotation(-12.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea_0", CubeListBuilder.create().texOffs(314, 104).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.576120467488714F, -30.25F, 0.3826834323650898F, 0.19634954084936157F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_1", CubeListBuilder.create().texOffs(504, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.499165286188262F, -38.55F, 0.3979907696596934F, 0.19443096327871295F, -0.027556049892673316F, -1.4317803082789426F));
        g.addOrReplaceChild("chimenea_2", CubeListBuilder.create().texOffs(514, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.114389379686004F, -39.55F, 0.4745274561327113F, -2.979866777385223F, -0.11183562681409295F, -0.9708581479848687F));
        g.addOrReplaceChild("chimenea_3", CubeListBuilder.create().texOffs(824, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.095150584360892F, -40.0F, 0.4783542904563622F, 0.0F, 0.1963495408493625F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_4", CubeListBuilder.create().texOffs(380, 104).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.869013686302164F, -30.25F, 1.0897902135516373F, 0.589048622548086F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_5", CubeListBuilder.create().texOffs(524, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.803774233754252F, -38.55F, 1.1333818220937029F, 0.5844041925304128F, -0.07854379289971365F, -1.4527308066645306F));
        g.addOrReplaceChild("chimenea_6", CubeListBuilder.create().texOffs(534, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.477576971014686F, -39.55F, 1.35133986480403F, -2.640248017550726F, -0.3234266981138618F, -1.0452826910886517F));
        g.addOrReplaceChild("chimenea_7", CubeListBuilder.create().texOffs(832, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.461267107877706F, -40.0F, 1.3622377669395465F, 0.0F, 0.5890486225480863F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_8", CubeListBuilder.create().texOffs(446, 104).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.410209786448362F, -30.25F, 1.6309863136978344F, 0.981747704246811F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_9", CubeListBuilder.create().texOffs(544, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.366618177906297F, -38.55F, 1.6962257662457476F, 0.9770853355603131F, -0.1176998338448247F, -1.4917041924527952F));
        g.addOrReplaceChild("chimenea_10", CubeListBuilder.create().texOffs(554, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.148660135195971F, -39.55F, 2.0224230289853145F, -2.2543999913761685F, -0.4956999035060444F, -1.2011285881889406F));
        g.addOrReplaceChild("chimenea_11", CubeListBuilder.create().texOffs(840, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.137762233060455F, -40.0F, 2.0387328921222925F, 0.0F, 0.981747704246811F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_12", CubeListBuilder.create().texOffs(512, 104).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.11731656763491F, -30.25F, 1.9238795325112867F, 1.3744467859455345F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_13", CubeListBuilder.create().texOffs(564, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.102009230340308F, -38.55F, 2.0008347138117384F, 1.3725102690624473F, -0.13896289950132285F, -1.5429719871431986F));
        g.addOrReplaceChild("chimenea_14", CubeListBuilder.create().texOffs(574, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.025472543867288F, -39.55F, 2.3856106203139955F, -1.8087157643464358F, -0.5956710971501548F, -1.4355615927167895F));
        g.addOrReplaceChild("chimenea_15", CubeListBuilder.create().texOffs(848, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.021645709543638F, -40.0F, 2.404849415639108F, 0.0F, 1.3744467859455345F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_16", CubeListBuilder.create().texOffs(578, 104).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.882683432365091F, -30.25F, 1.923879532511287F, 1.7671458676442588F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_17", CubeListBuilder.create().texOffs(584, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.897990769659694F, -38.55F, 2.0008347138117384F, 1.769082384527346F, -0.13896289950132285F, -1.5986206664465945F));
        g.addOrReplaceChild("chimenea_18", CubeListBuilder.create().texOffs(594, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.974527456132712F, -39.55F, 2.3856106203139955F, -1.3328768892433576F, -0.5956710971501548F, -1.7060310608730036F));
        g.addOrReplaceChild("chimenea_19", CubeListBuilder.create().texOffs(856, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.97835429045636F, -40.0F, 2.404849415639108F, 3.141592653589793F, 1.3744467859455345F, 0.0F));
        g.addOrReplaceChild("chimenea_20", CubeListBuilder.create().texOffs(644, 104).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.589790213551638F, -30.25F, 1.6309863136978342F, 2.159844949342982F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_21", CubeListBuilder.create().texOffs(604, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.633381822093703F, -38.55F, 1.6962257662457478F, 2.16450731802948F, -0.11769983384482466F, -1.649888461136998F));
        g.addOrReplaceChild("chimenea_22", CubeListBuilder.create().texOffs(614, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.851339864804029F, -39.55F, 2.0224230289853145F, -0.8871926622136247F, -0.4956999035060444F, -1.9404640654008525F));
        g.addOrReplaceChild("chimenea_23", CubeListBuilder.create().texOffs(864, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.862237766939547F, -40.0F, 2.038732892122293F, 3.141592653589793F, 0.981747704246811F, 0.0F));
        g.addOrReplaceChild("chimenea_24", CubeListBuilder.create().texOffs(710, 104).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.130986313697836F, -30.25F, 1.0897902135516375F, 2.552544031041707F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_25", CubeListBuilder.create().texOffs(624, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.19622576624575F, -38.55F, 1.133381822093703F, 2.5571884610593805F, -0.07854379289971365F, -1.6888618469252628F));
        g.addOrReplaceChild("chimenea_26", CubeListBuilder.create().texOffs(634, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.522423028985312F, -39.55F, 1.3513398648040305F, -0.5013446360390674F, -0.32342669811386193F, -2.0963099625011417F));
        g.addOrReplaceChild("chimenea_27", CubeListBuilder.create().texOffs(872, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.538732892122292F, -40.0F, 1.3622377669395467F, 3.141592653589793F, 0.5890486225480862F, 0.0F));
        g.addOrReplaceChild("chimenea_28", CubeListBuilder.create().texOffs(776, 104).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.423879532511286F, -30.25F, 0.38268343236509F, 2.9452431127404317F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_29", CubeListBuilder.create().texOffs(644, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.500834713811738F, -38.55F, 0.3979907696596936F, 2.94716169031108F, -0.027556049892673316F, -1.7098123453108505F));
        g.addOrReplaceChild("chimenea_30", CubeListBuilder.create().texOffs(654, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.885610620313994F, -39.55F, 0.47452745613271163F, -0.16172587620457005F, -0.11183562681409304F, -2.1707345056049245F));
        g.addOrReplaceChild("chimenea_31", CubeListBuilder.create().texOffs(880, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.90484941563911F, -40.0F, 0.4783542904563625F, 3.141592653589793F, 0.1963495408493625F, 0.0F));
        g.addOrReplaceChild("chimenea_32", CubeListBuilder.create().texOffs(842, 104).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.423879532511286F, -30.25F, -0.38268343236508956F, -2.9452431127404317F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_33", CubeListBuilder.create().texOffs(664, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.500834713811738F, -38.55F, -0.39799076965969316F, -2.94716169031108F, 0.027556049892673316F, -1.7098123453108505F));
        g.addOrReplaceChild("chimenea_34", CubeListBuilder.create().texOffs(674, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.885610620313996F, -39.55F, -0.474527456132711F, 0.16172587620456927F, 0.11183562681409265F, -2.1707345056049254F));
        g.addOrReplaceChild("chimenea_35", CubeListBuilder.create().texOffs(888, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.904849415639108F, -40.0F, -0.47835429045636185F, -3.141592653589793F, -0.19634954084936176F, 0.0F));
        g.addOrReplaceChild("chimenea_36", CubeListBuilder.create().texOffs(908, 104).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.130986313697836F, -30.25F, -1.089790213551637F, -2.5525440310417076F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_37", CubeListBuilder.create().texOffs(684, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.196225766245748F, -38.55F, -1.1333818220937026F, -2.557188461059382F, 0.07854379289971374F, -1.6888618469252634F));
        g.addOrReplaceChild("chimenea_38", CubeListBuilder.create().texOffs(694, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.522423028985315F, -39.55F, -1.35133986480403F, 0.5013446360390673F, 0.32342669811386165F, -2.096309962501141F));
        g.addOrReplaceChild("chimenea_39", CubeListBuilder.create().texOffs(896, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.538732892122294F, -40.0F, -1.3622377669395462F, -3.141592653589793F, -0.589048622548086F, 0.0F));
        g.addOrReplaceChild("chimenea_40", CubeListBuilder.create().texOffs(0, 109).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.589790213551638F, -30.25F, -1.630986313697834F, -2.159844949342983F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_41", CubeListBuilder.create().texOffs(704, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.633381822093703F, -38.55F, -1.6962257662457474F, -2.1645073180294796F, 0.1176998338448247F, -1.6498884611369982F));
        g.addOrReplaceChild("chimenea_42", CubeListBuilder.create().texOffs(714, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.85133986480403F, -39.55F, -2.022423028985314F, 0.8871926622136249F, 0.49569990350604454F, -1.9404640654008525F));
        g.addOrReplaceChild("chimenea_43", CubeListBuilder.create().texOffs(904, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.862237766939547F, -40.0F, -2.038732892122292F, -3.141592653589793F, -0.9817477042468103F, 0.0F));
        g.addOrReplaceChild("chimenea_44", CubeListBuilder.create().texOffs(66, 109).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.882683432365091F, -30.25F, -1.9238795325112865F, -1.7671458676442588F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_45", CubeListBuilder.create().texOffs(724, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.897990769659694F, -38.55F, -2.000834713811738F, -1.7690823845273462F, 0.1389628995013228F, -1.598620666446594F));
        g.addOrReplaceChild("chimenea_46", CubeListBuilder.create().texOffs(734, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.974527456132712F, -39.55F, -2.3856106203139955F, 1.3328768892433571F, 0.5956710971501548F, -1.7060310608730043F));
        g.addOrReplaceChild("chimenea_47", CubeListBuilder.create().texOffs(912, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.978354290456362F, -40.0F, -2.404849415639108F, -3.141592653589793F, -1.3744467859455345F, 0.0F));
        g.addOrReplaceChild("chimenea_48", CubeListBuilder.create().texOffs(132, 109).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.117316567634909F, -30.25F, -1.9238795325112865F, -1.374446785945534F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_49", CubeListBuilder.create().texOffs(744, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.102009230340306F, -38.55F, -2.000834713811738F, -1.372510269062447F, 0.13896289950132285F, -1.5429719871431986F));
        g.addOrReplaceChild("chimenea_50", CubeListBuilder.create().texOffs(754, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.025472543867288F, -39.55F, -2.3856106203139955F, 1.8087157643464358F, 0.5956710971501551F, -1.435561592716789F));
        g.addOrReplaceChild("chimenea_51", CubeListBuilder.create().texOffs(920, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.021645709543638F, -40.0F, -2.404849415639108F, 0.0F, -1.3744467859455327F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_52", CubeListBuilder.create().texOffs(198, 109).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.410209786448362F, -30.25F, -1.6309863136978344F, -0.9817477042468105F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_53", CubeListBuilder.create().texOffs(764, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.366618177906297F, -38.55F, -1.6962257662457478F, -0.9770853355603131F, 0.1176998338448249F, -1.4917041924527945F));
        g.addOrReplaceChild("chimenea_54", CubeListBuilder.create().texOffs(774, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.148660135195968F, -39.55F, -2.0224230289853145F, 2.254399991376169F, 0.4956999035060446F, -1.2011285881889402F));
        g.addOrReplaceChild("chimenea_55", CubeListBuilder.create().texOffs(928, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.137762233060455F, -40.0F, -2.038732892122293F, 0.0F, -0.981747704246809F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_56", CubeListBuilder.create().texOffs(264, 109).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.869013686302168F, -30.25F, -1.089790213551638F, -0.5890486225480865F, 0.0F, -1.5707963267948966F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("chimenea_57", CubeListBuilder.create().texOffs(784, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.803774233754254F, -38.55F, -1.1333818220937035F, -0.5844041925304131F, 0.07854379289971404F, -1.4527308066645293F));
        g.addOrReplaceChild("chimenea_58", CubeListBuilder.create().texOffs(794, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.477576971014686F, -39.55F, -1.3513398648040311F, 2.6402480175507255F, 0.32342669811386204F, -1.0452826910886517F));
        g.addOrReplaceChild("chimenea_59", CubeListBuilder.create().texOffs(936, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.461267107877708F, -40.0F, -1.3622377669395476F, 0.0F, -0.5890486225480865F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_60", CubeListBuilder.create().texOffs(330, 109).addBox(-15.5F, -1.0F, -1.0F, 31.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.576120467488714F, -30.25F, -0.3826834323650906F, -0.1963495408493636F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_61", CubeListBuilder.create().texOffs(804, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.499165286188262F, -38.55F, -0.39799076965969427F, -0.1944309632787138F, 0.027556049892673552F, -1.431780308278942F));
        g.addOrReplaceChild("chimenea_62", CubeListBuilder.create().texOffs(814, 115).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.114389379686004F, -39.55F, -0.47452745613271236F, 2.979866777385223F, 0.11183562681409304F, -0.9708581479848687F));
        g.addOrReplaceChild("chimenea_63", CubeListBuilder.create().texOffs(944, 115).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.09515058436089F, -40.0F, -0.4783542904563632F, 0.0F, -0.19634954084936257F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_hueco", CubeListBuilder.create().texOffs(350, 45).addBox(-8.5F, 0.0F, -8.5F, 17.0F, 1.0F, 17.0F), PartPose.offsetAndRotation(-12.5F, -39.6F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("valvula_0", CubeListBuilder.create().texOffs(102, 73).addBox(-13.0F, -25.5F, -3.5F, 26.0F, 4.0F, 7.0F).texOffs(672, 0).addBox(-3.5F, -25.5F, -13.0F, 7.0F, 4.0F, 26.0F), PartPose.ZERO);
        g.addOrReplaceChild("valvula_1", CubeListBuilder.create().texOffs(168, 73).addBox(-13.0F, -25.5F, -3.5F, 26.0F, 4.0F, 7.0F).texOffs(738, 0).addBox(-3.5F, -25.5F, -13.0F, 7.0F, 4.0F, 26.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("valvula_2", CubeListBuilder.create().texOffs(234, 73).addBox(-13.0F, -25.5F, -3.5F, 26.0F, 4.0F, 7.0F).texOffs(804, 0).addBox(-3.5F, -25.5F, -13.0F, 7.0F, 4.0F, 26.0F), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("valvula_palanca", CubeListBuilder.create().texOffs(66, 86).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.8F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("valvula_peso", CubeListBuilder.create().texOffs(32, 118).addBox(-6.0F, -26.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil0_brida_0", CubeListBuilder.create().texOffs(396, 109).addBox(-5.0F, -22.3F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(370, 73).addBox(-1.0F, -22.3F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(-8.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil0_brida_1", CubeListBuilder.create().texOffs(420, 109).addBox(-5.0F, -22.3F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(394, 73).addBox(-1.0F, -22.3F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-8.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("cil0_brida_2", CubeListBuilder.create().texOffs(444, 109).addBox(-5.0F, -22.3F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(418, 73).addBox(-1.0F, -22.3F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-8.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("cil0_brida_3", CubeListBuilder.create().texOffs(468, 109).addBox(-5.0F, -22.3F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(442, 73).addBox(-1.0F, -22.3F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-8.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("cil0_0", CubeListBuilder.create().texOffs(824, 73).addBox(-5.0F, -25.5F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(644, 45).addBox(-1.0F, -25.5F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offset(-8.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil0_1", CubeListBuilder.create().texOffs(848, 73).addBox(-5.0F, -25.5F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(668, 45).addBox(-1.0F, -25.5F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(-8.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("cil0_2", CubeListBuilder.create().texOffs(872, 73).addBox(-5.0F, -25.5F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(692, 45).addBox(-1.0F, -25.5F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(-8.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("cil0_3", CubeListBuilder.create().texOffs(896, 73).addBox(-5.0F, -25.5F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(716, 45).addBox(-1.0F, -25.5F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(-8.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("cil0_tapa", CubeListBuilder.create().texOffs(154, 45).addBox(-10.0F, 0.0F, -10.0F, 20.0F, 1.0F, 20.0F), PartPose.offsetAndRotation(-8.0F, -25.55F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("guias0", CubeListBuilder.create().texOffs(562, 73).addBox(-10.0F, -35.5F, -0.5F, 1.0F, 10.0F, 1.0F).texOffs(566, 73).addBox(-7.0F, -35.5F, -0.5F, 1.0F, 10.0F, 1.0F).texOffs(480, 115).addBox(-10.0F, -36.5F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("cruceta0", CubeListBuilder.create().texOffs(532, 45).addBox(-8.5F, -32.5F, -8.0F, 1.0F, 1.0F, 16.0F).texOffs(0, 118).addBox(-9.0F, -33.0F, -8.0F, 2.0F, 2.0F, 1.0F).texOffs(6, 118).addBox(-9.0F, -33.0F, 7.0F, 2.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("vastago0", CubeListBuilder.create().texOffs(10, 86).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 7.0F, 1.0F), PartPose.offset(-8.0F, -32.0F, 0.0F));
        g.addOrReplaceChild("biela0i", CubeListBuilder.create().texOffs(66, 45).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 24.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -8.0F, -7.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("biela0d", CubeListBuilder.create().texOffs(70, 45).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 24.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -8.0F, 7.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("cil1_brida_0", CubeListBuilder.create().texOffs(492, 109).addBox(-5.0F, -22.3F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(466, 73).addBox(-1.0F, -22.3F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(8.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil1_brida_1", CubeListBuilder.create().texOffs(516, 109).addBox(-5.0F, -22.3F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(490, 73).addBox(-1.0F, -22.3F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(8.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("cil1_brida_2", CubeListBuilder.create().texOffs(540, 109).addBox(-5.0F, -22.3F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(514, 73).addBox(-1.0F, -22.3F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(8.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("cil1_brida_3", CubeListBuilder.create().texOffs(564, 109).addBox(-5.0F, -22.3F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(538, 73).addBox(-1.0F, -22.3F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(8.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("cil1_0", CubeListBuilder.create().texOffs(920, 73).addBox(-5.0F, -25.5F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(740, 45).addBox(-1.0F, -25.5F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offset(8.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil1_1", CubeListBuilder.create().texOffs(944, 73).addBox(-5.0F, -25.5F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(764, 45).addBox(-1.0F, -25.5F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(8.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("cil1_2", CubeListBuilder.create().texOffs(968, 73).addBox(-5.0F, -25.5F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(788, 45).addBox(-1.0F, -25.5F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(8.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("cil1_3", CubeListBuilder.create().texOffs(992, 73).addBox(-5.0F, -25.5F, -1.0F, 10.0F, 6.0F, 2.0F).texOffs(812, 45).addBox(-1.0F, -25.5F, -5.0F, 2.0F, 6.0F, 10.0F), PartPose.offsetAndRotation(8.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("cil1_tapa", CubeListBuilder.create().texOffs(234, 45).addBox(-10.0F, 0.0F, -10.0F, 20.0F, 1.0F, 20.0F), PartPose.offsetAndRotation(8.0F, -25.55F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("guias1", CubeListBuilder.create().texOffs(570, 73).addBox(6.0F, -35.5F, -0.5F, 1.0F, 10.0F, 1.0F).texOffs(574, 73).addBox(9.0F, -35.5F, -0.5F, 1.0F, 10.0F, 1.0F).texOffs(492, 115).addBox(6.0F, -36.5F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("cruceta1", CubeListBuilder.create().texOffs(566, 45).addBox(7.5F, -32.5F, -8.0F, 1.0F, 1.0F, 16.0F).texOffs(12, 118).addBox(7.0F, -33.0F, -8.0F, 2.0F, 2.0F, 1.0F).texOffs(18, 118).addBox(7.0F, -33.0F, 7.0F, 2.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("vastago1", CubeListBuilder.create().texOffs(14, 86).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 7.0F, 1.0F), PartPose.offset(8.0F, -32.0F, 0.0F));
        g.addOrReplaceChild("biela1i", CubeListBuilder.create().texOffs(74, 45).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 24.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -8.0F, -7.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("biela1d", CubeListBuilder.create().texOffs(78, 45).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 24.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -8.0F, 7.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("cab_manometro", CubeListBuilder.create().texOffs(300, 73).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(14.7F, -20.4F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro_aguja", CubeListBuilder.create().texOffs(126, 118).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.819999999999999F, -20.4F, 0.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_grifos", CubeListBuilder.create().texOffs(130, 118).addBox(14.1F, -18.4F, -3.5F, 1.0F, 1.0F, 1.0F).texOffs(134, 118).addBox(14.1F, -16.9F, -3.5F, 1.0F, 1.0F, 1.0F).texOffs(138, 118).addBox(14.1F, -15.399999999999999F, -3.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_regulador", CubeListBuilder.create().texOffs(318, 86).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F), PartPose.offsetAndRotation(14.4F, -18.0F, 0.0F, 0.8059360376985916F, 0.0F, -1.2160906747839564F));
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(622, 73).addBox(-0.5F, -9.0F, -0.5F, 1.0F, 9.0F, 1.0F).texOffs(300, 104).addBox(-1.0F, -11.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(16.5F, -11.0F, 5.5F));
        g.addOrReplaceChild("cab_palanca_cuadrante", CubeListBuilder.create().texOffs(116, 118).addBox(14.5F, -12.0F, 5.0F, 4.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(244, 104).addBox(15.0F, -12.0F, 2.0F, 3.0F, 1.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(256, 104).addBox(15.0F, -12.0F, -5.0F, 3.0F, 1.0F, 3.0F), PartPose.ZERO);
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(578, 73).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(184, 104).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(598, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(72, 104).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(30.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(204, 104).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(606, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(224, 104).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(614, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(578, 73).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(184, 104).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(598, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(82, 104).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(42.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(204, 104).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(606, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(224, 104).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(614, 73).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(578, 73).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(184, 104).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(598, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(92, 104).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(30.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(204, 104).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(606, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(224, 104).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(614, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(30.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(578, 73).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(184, 104).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(598, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(102, 104).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(42.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(204, 104).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(606, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(224, 104).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(614, 73).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(214, 86).addBox(24.0F, -10.0F, 1.5F, 24.0F, 4.0F, 2.0F).texOffs(266, 86).addBox(24.0F, -10.0F, -3.5F, 24.0F, 4.0F, 2.0F).texOffs(448, 45).addBox(23.0F, -11.0F, -8.0F, 26.0F, 1.0F, 16.0F).texOffs(314, 45).addBox(47.0F, -10.0F, -8.0F, 2.0F, 4.0F, 16.0F).texOffs(104, 118).addBox(19.0F, -9.0F, -0.5F, 5.0F, 1.0F, 1.0F).texOffs(144, 104).addBox(28.5F, -6.0F, 2.5F, 3.0F, 4.0F, 1.0F).texOffs(152, 104).addBox(28.5F, -6.0F, -3.5F, 3.0F, 4.0F, 1.0F).texOffs(160, 104).addBox(40.5F, -6.0F, 2.5F, 3.0F, 4.0F, 1.0F).texOffs(168, 104).addBox(40.5F, -6.0F, -3.5F, 3.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(496, 86).addBox(24.0F, -15.0F, 7.0F, 9.0F, 4.0F, 1.0F).texOffs(516, 86).addBox(24.0F, -15.0F, -8.0F, 9.0F, 4.0F, 1.0F).texOffs(418, 45).addBox(24.0F, -15.0F, -7.0F, 1.0F, 4.0F, 14.0F).texOffs(600, 45).addBox(25.0F, -13.0F, -7.0F, 8.0F, 2.0F, 14.0F).texOffs(340, 73).addBox(26.0F, -14.0F, -5.0F, 5.0F, 1.0F, 10.0F).texOffs(54, 73).addBox(34.0F, -13.0F, -5.0F, 2.0F, 2.0F, 10.0F).texOffs(78, 73).addBox(43.0F, -13.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.ZERO);
        g.addOrReplaceChild("tonel_0", CubeListBuilder.create().texOffs(536, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -22.54835873591371F, 0.7995814729451765F, 2.9874434710087105F, -0.030320525211280355F, -0.19268505683159534F));
        g.addOrReplaceChild("tonel_1", CubeListBuilder.create().texOffs(552, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -22.84101721335798F, 0.8459340221014184F, 2.9860288275608293F, -0.021857890914122987F, -0.13846934652282733F));
        g.addOrReplaceChild("tonel_2", CubeListBuilder.create().texOffs(568, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -23.036122864987497F, 0.8768357215389133F, 2.9850638027757586F, -0.013196762754969366F, -0.08342264548232661F));
        g.addOrReplaceChild("tonel_3", CubeListBuilder.create().texOffs(584, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -23.133675690802256F, 0.8922865712576606F, 2.9845745061787983F, -0.004412786107667665F, -0.027865021686780452F));
        g.addOrReplaceChild("tonel_4", CubeListBuilder.create().texOffs(600, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -23.133675690802256F, 0.8922865712576606F, 2.9845745061787983F, 0.004412786107667665F, 0.027865021686780452F));
        g.addOrReplaceChild("tonel_5", CubeListBuilder.create().texOffs(616, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -23.036122864987497F, 0.8768357215389133F, 2.9850638027757586F, 0.013196762754969366F, 0.08342264548232661F));
        g.addOrReplaceChild("tonel_6", CubeListBuilder.create().texOffs(632, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -22.841017213357986F, 0.8459340221014184F, 2.9860288275608293F, 0.021857890914122987F, 0.13846934652282733F));
        g.addOrReplaceChild("tonel_7", CubeListBuilder.create().texOffs(648, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -22.54835873591371F, 0.7995814729451765F, 2.9874434710087105F, 0.030320525211280355F, 0.19268505683159534F));
        g.addOrReplaceChild("tonel_8", CubeListBuilder.create().texOffs(664, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -22.054190208858884F, 2.3204758132519507F, 2.678052164625234F, -0.08809400825405699F, -0.17422291663587286F));
        g.addOrReplaceChild("tonel_9", CubeListBuilder.create().texOffs(680, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -22.318201235459398F, 2.4549961502520636F, 2.674329255113161F, -0.06347162797185323F, -0.1250633983776763F));
        g.addOrReplaceChild("tonel_10", CubeListBuilder.create().texOffs(696, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -22.494208586526412F, 2.5446763749188057F, 2.6717966545931553F, -0.038306753460617696F, -0.07528914089579732F));
        g.addOrReplaceChild("tonel_11", CubeListBuilder.create().texOffs(712, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -22.582212262059915F, 2.589516487252177F, 2.670514737708699F, -0.012806712583277986F, -0.025138610510250164F));
        g.addOrReplaceChild("tonel_12", CubeListBuilder.create().texOffs(728, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -22.58221226205992F, 2.589516487252177F, 2.670514737708699F, 0.012806712583277986F, 0.025138610510250164F));
        g.addOrReplaceChild("tonel_13", CubeListBuilder.create().texOffs(744, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -22.494208586526412F, 2.5446763749188057F, 2.6717966545931553F, 0.038306753460617696F, 0.07528914089579732F));
        g.addOrReplaceChild("tonel_14", CubeListBuilder.create().texOffs(760, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -22.3182012354594F, 2.4549961502520636F, 2.674329255113161F, 0.06347162797185323F, 0.1250633983776763F));
        g.addOrReplaceChild("tonel_15", CubeListBuilder.create().texOffs(776, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -22.054190208858884F, 2.3204758132519507F, 2.678052164625234F, 0.08809400825405699F, 0.17422291663587286F));
        g.addOrReplaceChild("tonel_16", CubeListBuilder.create().texOffs(792, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -21.11422581325195F, 3.6142258132519505F, 2.36576366824931F, -0.13746475937810118F, -0.13878229950083582F));
        g.addOrReplaceChild("tonel_17", CubeListBuilder.create().texOffs(808, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -21.32374615025206F, 3.8237461502520635F, 2.361122698562397F, -0.09895442761645021F, -0.09944249792279458F));
        g.addOrReplaceChild("tonel_18", CubeListBuilder.create().texOffs(824, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -21.463426374918807F, 3.9634263749188055F, 2.357979882512587F, -0.059685006120162996F, -0.05979159902972052F));
        g.addOrReplaceChild("tonel_19", CubeListBuilder.create().texOffs(840, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -21.533266487252178F, 4.033266487252177F, 2.3563934983571873F, -0.019947700119697452F, -0.01995167000658268F));
        g.addOrReplaceChild("tonel_20", CubeListBuilder.create().texOffs(856, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -21.533266487252174F, 4.033266487252177F, 2.3563934983571873F, 0.019947700119697452F, 0.01995167000658268F));
        g.addOrReplaceChild("tonel_21", CubeListBuilder.create().texOffs(872, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -21.463426374918807F, 3.9634263749188055F, 2.357979882512587F, 0.059685006120162996F, 0.05979159902972052F));
        g.addOrReplaceChild("tonel_22", CubeListBuilder.create().texOffs(888, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -21.323746150252063F, 3.823746150252064F, 2.361122698562397F, 0.09895442761645021F, 0.09944249792279458F));
        g.addOrReplaceChild("tonel_23", CubeListBuilder.create().texOffs(904, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -21.11422581325195F, 3.6142258132519505F, 2.36576366824931F, 0.13746475937810118F, 0.13878229950083582F));
        g.addOrReplaceChild("tonel_24", CubeListBuilder.create().texOffs(920, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -19.82047581325195F, 4.554190208858886F, 2.0498207242137565F, -0.1735404418338349F, -0.08944095917962402F));
        g.addOrReplaceChild("tonel_25", CubeListBuilder.create().texOffs(936, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -19.95499615025206F, 4.818201235459401F, 2.0460338231315536F, -0.12481024755801695F, -0.06396990215663115F));
        g.addOrReplaceChild("tonel_26", CubeListBuilder.create().texOffs(952, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -20.044676374918808F, 4.994208586526411F, 2.043481155490881F, -0.07523380324671879F, -0.03841547364434995F));
        g.addOrReplaceChild("tonel_27", CubeListBuilder.create().texOffs(968, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -20.089516487252176F, 5.082212262059917F, 2.0421962446566195F, -0.025136548588642095F, -0.012810759805632529F));
        g.addOrReplaceChild("tonel_28", CubeListBuilder.create().texOffs(984, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -20.089516487252176F, 5.082212262059916F, 2.0421962446566195F, 0.025136548588642095F, 0.012810759805632529F));
        g.addOrReplaceChild("tonel_29", CubeListBuilder.create().texOffs(1000, 86).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -20.044676374918804F, 4.994208586526411F, 2.043481155490881F, 0.07523380324671879F, 0.03841547364434995F));
        g.addOrReplaceChild("tonel_30", CubeListBuilder.create().texOffs(0, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -19.954996150252065F, 4.818201235459401F, 2.0460338231315536F, 0.12481024755801695F, 0.06396990215663115F));
        g.addOrReplaceChild("tonel_31", CubeListBuilder.create().texOffs(16, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -19.82047581325195F, 4.554190208858886F, 2.0498207242137565F, 0.1735404418338349F, 0.08944095917962402F));
        g.addOrReplaceChild("tonel_32", CubeListBuilder.create().texOffs(32, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -18.299581472945178F, 5.048358735913709F, 1.7308602398535617F, -0.1925953808326678F, -0.030891868903546057F));
        g.addOrReplaceChild("tonel_33", CubeListBuilder.create().texOffs(48, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -18.345934022101417F, 5.341017213357983F, 1.729406042316737F, -0.13843605681155313F, -0.022069058894342932F));
        g.addOrReplaceChild("tonel_34", CubeListBuilder.create().texOffs(64, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -18.37683572153891F, 5.536122864987498F, 1.7284286149880541F, -0.08341536447526557F, -0.013242811279246916F));
        g.addOrReplaceChild("tonel_35", CubeListBuilder.create().texOffs(80, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -18.39228657125766F, 5.633675690802256F, 1.7279374680216772F, -0.027864750313639407F, -0.004414499814537841F));
        g.addOrReplaceChild("tonel_36", CubeListBuilder.create().texOffs(96, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -18.39228657125766F, 5.633675690802256F, 1.7279374680216772F, 0.027864750313639407F, 0.004414499814537841F));
        g.addOrReplaceChild("tonel_37", CubeListBuilder.create().texOffs(112, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -18.376835721538914F, 5.536122864987497F, 1.7284286149880541F, 0.08341536447526557F, 0.013242811279246916F));
        g.addOrReplaceChild("tonel_38", CubeListBuilder.create().texOffs(128, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -18.345934022101417F, 5.341017213357983F, 1.729406042316737F, 0.13843605681155313F, 0.022069058894342932F));
        g.addOrReplaceChild("tonel_39", CubeListBuilder.create().texOffs(144, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -18.299581472945178F, 5.04835873591371F, 1.7308602398535617F, 0.1925953808326678F, 0.030891868903546057F));
        g.addOrReplaceChild("tonel_40", CubeListBuilder.create().texOffs(160, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -16.700418527054822F, 5.04835873591371F, 1.4107324137362316F, -0.1925953808326678F, 0.030891868903545817F));
        g.addOrReplaceChild("tonel_41", CubeListBuilder.create().texOffs(176, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -16.654065977898583F, 5.341017213357982F, 1.4121866112730563F, -0.13843605681155316F, 0.022069058894343168F));
        g.addOrReplaceChild("tonel_42", CubeListBuilder.create().texOffs(192, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -16.623164278461086F, 5.536122864987498F, 1.4131640386017394F, -0.08341536447526557F, 0.013242811279246916F));
        g.addOrReplaceChild("tonel_43", CubeListBuilder.create().texOffs(208, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -16.60771342874234F, 5.6336756908022565F, 1.4136551855681163F, -0.027864750313639417F, 0.004414499814537841F));
        g.addOrReplaceChild("tonel_44", CubeListBuilder.create().texOffs(224, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -16.60771342874234F, 5.633675690802256F, 1.4136551855681163F, 0.027864750313639417F, -0.004414499814537841F));
        g.addOrReplaceChild("tonel_45", CubeListBuilder.create().texOffs(240, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -16.623164278461086F, 5.536122864987498F, 1.4131640386017394F, 0.08341536447526557F, -0.013242811279246916F));
        g.addOrReplaceChild("tonel_46", CubeListBuilder.create().texOffs(256, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -16.654065977898583F, 5.341017213357982F, 1.4121866112730563F, 0.13843605681155316F, -0.022069058894343168F));
        g.addOrReplaceChild("tonel_47", CubeListBuilder.create().texOffs(272, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -16.700418527054822F, 5.04835873591371F, 1.4107324137362316F, 0.1925953808326678F, -0.030891868903545817F));
        g.addOrReplaceChild("tonel_48", CubeListBuilder.create().texOffs(288, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -15.17952418674805F, 4.554190208858886F, 1.0917719293760366F, -0.17354044183383466F, 0.08944095917962348F));
        g.addOrReplaceChild("tonel_49", CubeListBuilder.create().texOffs(304, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -15.045003849747935F, 4.818201235459401F, 1.0955588304582395F, -0.12481024755801712F, 0.06396990215663147F));
        g.addOrReplaceChild("tonel_50", CubeListBuilder.create().texOffs(320, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -14.955323625081196F, 4.994208586526411F, 1.0981114980989117F, -0.07523380324671879F, 0.03841547364434995F));
        g.addOrReplaceChild("tonel_51", CubeListBuilder.create().texOffs(336, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -14.910483512747824F, 5.082212262059916F, 1.0993964089331731F, -0.025136548588642095F, 0.012810759805632451F));
        g.addOrReplaceChild("tonel_52", CubeListBuilder.create().texOffs(352, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -14.910483512747824F, 5.082212262059916F, 1.0993964089331731F, 0.025136548588642095F, -0.012810759805632451F));
        g.addOrReplaceChild("tonel_53", CubeListBuilder.create().texOffs(368, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -14.955323625081192F, 4.994208586526411F, 1.0981114980989117F, 0.07523380324671879F, -0.03841547364434995F));
        g.addOrReplaceChild("tonel_54", CubeListBuilder.create().texOffs(384, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -15.045003849747937F, 4.818201235459401F, 1.0955588304582395F, 0.12481024755801712F, -0.06396990215663147F));
        g.addOrReplaceChild("tonel_55", CubeListBuilder.create().texOffs(400, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -15.17952418674805F, 4.554190208858886F, 1.0917719293760366F, 0.17354044183383466F, -0.08944095917962348F));
        g.addOrReplaceChild("tonel_56", CubeListBuilder.create().texOffs(416, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -13.885774186748051F, 3.614225813251951F, 0.775828985340483F, -0.137464759378101F, 0.13878229950083548F));
        g.addOrReplaceChild("tonel_57", CubeListBuilder.create().texOffs(432, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -13.676253849747937F, 3.823746150252064F, 0.7804699550273964F, -0.09895442761645017F, 0.09944249792279458F));
        g.addOrReplaceChild("tonel_58", CubeListBuilder.create().texOffs(448, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -13.536573625081195F, 3.9634263749188063F, 0.7836127710772067F, -0.059685006120163114F, 0.05979159902972055F));
        g.addOrReplaceChild("tonel_59", CubeListBuilder.create().texOffs(464, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -13.466733512747822F, 4.0332664872521775F, 0.7851991552326065F, -0.019947700119697414F, 0.019951670006582718F));
        g.addOrReplaceChild("tonel_60", CubeListBuilder.create().texOffs(480, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -13.466733512747824F, 4.0332664872521775F, 0.7851991552326065F, 0.019947700119697414F, -0.019951670006582718F));
        g.addOrReplaceChild("tonel_61", CubeListBuilder.create().texOffs(496, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -13.536573625081195F, 3.9634263749188063F, 0.7836127710772067F, 0.059685006120163114F, -0.05979159902972055F));
        g.addOrReplaceChild("tonel_62", CubeListBuilder.create().texOffs(512, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -13.676253849747937F, 3.8237461502520635F, 0.7804699550273964F, 0.09895442761645017F, -0.09944249792279458F));
        g.addOrReplaceChild("tonel_63", CubeListBuilder.create().texOffs(528, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -13.88577418674805F, 3.6142258132519514F, 0.775828985340483F, 0.137464759378101F, -0.13878229950083548F));
        g.addOrReplaceChild("tonel_64", CubeListBuilder.create().texOffs(544, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -12.945809791141112F, 2.320475813251951F, 0.4635404889645594F, -0.08809400825405699F, 0.17422291663587286F));
        g.addOrReplaceChild("tonel_65", CubeListBuilder.create().texOffs(560, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -12.681798764540599F, 2.454996150252064F, 0.4672633984766323F, -0.06347162797185323F, 0.1250633983776763F));
        g.addOrReplaceChild("tonel_66", CubeListBuilder.create().texOffs(576, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -12.50579141347359F, 2.544676374918806F, 0.469795998996638F, -0.03830675346061777F, 0.07528914089579732F));
        g.addOrReplaceChild("tonel_67", CubeListBuilder.create().texOffs(592, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -12.417787737940085F, 2.5895164872521774F, 0.4710779158810947F, -0.012806712583278064F, 0.025138610510250597F));
        g.addOrReplaceChild("tonel_68", CubeListBuilder.create().texOffs(608, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -12.417787737940083F, 2.589516487252177F, 0.4710779158810947F, 0.012806712583278064F, -0.025138610510250597F));
        g.addOrReplaceChild("tonel_69", CubeListBuilder.create().texOffs(624, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -12.505791413473588F, 2.5446763749188066F, 0.469795998996638F, 0.03830675346061777F, -0.07528914089579732F));
        g.addOrReplaceChild("tonel_70", CubeListBuilder.create().texOffs(640, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -12.681798764540599F, 2.454996150252064F, 0.4672633984766323F, 0.06347162797185323F, -0.1250633983776763F));
        g.addOrReplaceChild("tonel_71", CubeListBuilder.create().texOffs(656, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -12.945809791141114F, 2.320475813251951F, 0.4635404889645594F, 0.08809400825405699F, -0.17422291663587286F));
        g.addOrReplaceChild("tonel_72", CubeListBuilder.create().texOffs(672, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -12.45164126408629F, 0.7995814729451769F, 0.15414918258108218F, -0.03032052521128028F, 0.19268505683159493F));
        g.addOrReplaceChild("tonel_73", CubeListBuilder.create().texOffs(688, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -12.158982786642019F, 0.8459340221014191F, 0.155563826028963F, -0.021857890914122987F, 0.13846934652282736F));
        g.addOrReplaceChild("tonel_74", CubeListBuilder.create().texOffs(704, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -11.963877135012503F, 0.8768357215389139F, 0.15652885081403423F, -0.013196762754969366F, 0.08342264548232711F));
        g.addOrReplaceChild("tonel_75", CubeListBuilder.create().texOffs(720, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -11.866324309197744F, 0.8922865712576613F, 0.15701814741099462F, -0.004412786107667743F, 0.027865021686780962F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("tonel_76", CubeListBuilder.create().texOffs(736, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -11.866324309197744F, 0.8922865712576613F, 0.15701814741099462F, 0.004412786107667743F, -0.027865021686780962F));
        g.addOrReplaceChild("tonel_77", CubeListBuilder.create().texOffs(752, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -11.9638771350125F, 0.8768357215389139F, 0.15652885081403423F, 0.013196762754969366F, -0.08342264548232711F));
        g.addOrReplaceChild("tonel_78", CubeListBuilder.create().texOffs(768, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -12.158982786642019F, 0.845934022101419F, 0.155563826028963F, 0.021857890914122987F, -0.13846934652282736F));
        g.addOrReplaceChild("tonel_79", CubeListBuilder.create().texOffs(784, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -12.451641264086291F, 0.7995814729451769F, 0.15414918258108218F, 0.03032052521128028F, -0.19268505683159493F));
        g.addOrReplaceChild("tonel_80", CubeListBuilder.create().texOffs(800, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -12.451641264086291F, -0.7995814729451769F, -0.15414918258108193F, 0.03032052521128028F, 0.19268505683159493F));
        g.addOrReplaceChild("tonel_81", CubeListBuilder.create().texOffs(816, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -12.158982786642017F, -0.8459340221014191F, -0.1555638260289628F, 0.021857890914122987F, 0.13846934652282733F));
        g.addOrReplaceChild("tonel_82", CubeListBuilder.create().texOffs(832, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -11.963877135012503F, -0.8768357215389138F, -0.15652885081403395F, 0.013196762754969288F, 0.08342264548232711F));
        g.addOrReplaceChild("tonel_83", CubeListBuilder.create().texOffs(848, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -11.866324309197744F, -0.8922865712576612F, -0.15701814741099437F, 0.004412786107667665F, 0.027865021686780952F));
        g.addOrReplaceChild("tonel_84", CubeListBuilder.create().texOffs(864, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -11.866324309197744F, -0.8922865712576612F, -0.15701814741099437F, -0.004412786107667665F, -0.027865021686780952F));
        g.addOrReplaceChild("tonel_85", CubeListBuilder.create().texOffs(880, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -11.963877135012503F, -0.8768357215389138F, -0.15652885081403395F, -0.013196762754969288F, -0.08342264548232711F));
        g.addOrReplaceChild("tonel_86", CubeListBuilder.create().texOffs(896, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -12.158982786642017F, -0.8459340221014191F, -0.1555638260289628F, -0.021857890914122987F, -0.13846934652282733F));
        g.addOrReplaceChild("tonel_87", CubeListBuilder.create().texOffs(912, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -12.451641264086291F, -0.7995814729451769F, -0.15414918258108193F, -0.03032052521128028F, -0.19268505683159493F));
        g.addOrReplaceChild("tonel_88", CubeListBuilder.create().texOffs(928, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -12.945809791141116F, -2.320475813251952F, -0.46354048896456007F, 0.08809400825405714F, 0.1742229166358723F));
        g.addOrReplaceChild("tonel_89", CubeListBuilder.create().texOffs(944, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -12.6817987645406F, -2.454996150252065F, -0.46726339847663295F, 0.06347162797185338F, 0.1250633983776767F));
        g.addOrReplaceChild("tonel_90", CubeListBuilder.create().texOffs(960, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -12.50579141347359F, -2.544676374918807F, -0.4697959989966381F, 0.038306753460617696F, 0.07528914089579734F));
        g.addOrReplaceChild("tonel_91", CubeListBuilder.create().texOffs(976, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -12.417787737940085F, -2.5895164872521788F, -0.4710779158810954F, 0.012806712583277986F, 0.025138610510250126F));
        g.addOrReplaceChild("tonel_92", CubeListBuilder.create().texOffs(992, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -12.417787737940083F, -2.589516487252178F, -0.4710779158810954F, -0.012806712583277986F, -0.025138610510250126F));
        g.addOrReplaceChild("tonel_93", CubeListBuilder.create().texOffs(1008, 94).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -12.50579141347359F, -2.544676374918807F, -0.4697959989966381F, -0.038306753460617696F, -0.07528914089579734F));
        g.addOrReplaceChild("tonel_94", CubeListBuilder.create().texOffs(0, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -12.6817987645406F, -2.454996150252065F, -0.46726339847663295F, -0.06347162797185338F, -0.1250633983776767F));
        g.addOrReplaceChild("tonel_95", CubeListBuilder.create().texOffs(16, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -12.945809791141114F, -2.320475813251952F, -0.46354048896456007F, -0.08809400825405714F, -0.1742229166358723F));
        g.addOrReplaceChild("tonel_96", CubeListBuilder.create().texOffs(32, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -13.88577418674805F, -3.6142258132519514F, -0.7758289853404824F, 0.13746475937810107F, 0.1387822995008351F));
        g.addOrReplaceChild("tonel_97", CubeListBuilder.create().texOffs(48, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -13.676253849747935F, -3.823746150252064F, -0.7804699550273955F, 0.09895442761645012F, 0.09944249792279508F));
        g.addOrReplaceChild("tonel_98", CubeListBuilder.create().texOffs(64, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -13.536573625081193F, -3.9634263749188063F, -0.7836127710772067F, 0.05968500612016284F, 0.059791599029720116F));
        g.addOrReplaceChild("tonel_99", CubeListBuilder.create().texOffs(80, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -13.466733512747822F, -4.0332664872521775F, -0.7851991552326061F, 0.01994770011969757F, 0.01995167000658272F));
        g.addOrReplaceChild("tonel_100", CubeListBuilder.create().texOffs(96, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -13.466733512747822F, -4.0332664872521775F, -0.7851991552326061F, -0.01994770011969757F, -0.01995167000658272F));
        g.addOrReplaceChild("tonel_101", CubeListBuilder.create().texOffs(112, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -13.536573625081195F, -3.963426374918806F, -0.7836127710772067F, -0.05968500612016284F, -0.059791599029720116F));
        g.addOrReplaceChild("tonel_102", CubeListBuilder.create().texOffs(128, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -13.676253849747937F, -3.823746150252064F, -0.7804699550273955F, -0.09895442761645012F, -0.09944249792279508F));
        g.addOrReplaceChild("tonel_103", CubeListBuilder.create().texOffs(144, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -13.885774186748048F, -3.614225813251951F, -0.7758289853404824F, -0.13746475937810107F, -0.1387822995008351F));
        g.addOrReplaceChild("tonel_104", CubeListBuilder.create().texOffs(160, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -15.179524186748049F, -4.554190208858886F, -1.091771929376037F, 0.17354044183383494F, 0.08944095917962355F));
        g.addOrReplaceChild("tonel_105", CubeListBuilder.create().texOffs(176, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -15.045003849747935F, -4.818201235459401F, -1.09555883045824F, 0.12481024755801708F, 0.06396990215663138F));
        g.addOrReplaceChild("tonel_106", CubeListBuilder.create().texOffs(192, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -14.955323625081194F, -4.994208586526411F, -1.0981114980989117F, 0.07523380324671847F, 0.03841547364434955F));
        g.addOrReplaceChild("tonel_107", CubeListBuilder.create().texOffs(208, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -14.910483512747822F, -5.082212262059917F, -1.0993964089331734F, 0.025136548588642445F, 0.012810759805632765F));
        g.addOrReplaceChild("tonel_108", CubeListBuilder.create().texOffs(224, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -14.910483512747822F, -5.082212262059916F, -1.0993964089331734F, -0.025136548588642445F, -0.012810759805632765F));
        g.addOrReplaceChild("tonel_109", CubeListBuilder.create().texOffs(240, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -14.955323625081192F, -4.994208586526411F, -1.0981114980989117F, -0.07523380324671847F, -0.03841547364434955F));
        g.addOrReplaceChild("tonel_110", CubeListBuilder.create().texOffs(256, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -15.045003849747935F, -4.818201235459401F, -1.09555883045824F, -0.12481024755801708F, -0.06396990215663138F));
        g.addOrReplaceChild("tonel_111", CubeListBuilder.create().texOffs(272, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -15.179524186748049F, -4.554190208858886F, -1.091771929376037F, -0.17354044183383494F, -0.08944095917962355F));
        g.addOrReplaceChild("tonel_112", CubeListBuilder.create().texOffs(288, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -16.700418527054822F, -5.048358735913709F, -1.4107324137362316F, 0.1925953808326678F, 0.030891868903545817F));
        g.addOrReplaceChild("tonel_113", CubeListBuilder.create().texOffs(304, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -16.654065977898583F, -5.341017213357983F, -1.4121866112730563F, 0.13843605681155316F, 0.022069058894343168F));
        g.addOrReplaceChild("tonel_114", CubeListBuilder.create().texOffs(320, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -16.623164278461086F, -5.536122864987498F, -1.4131640386017394F, 0.08341536447526557F, 0.013242811279246916F));
        g.addOrReplaceChild("tonel_115", CubeListBuilder.create().texOffs(336, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -16.60771342874234F, -5.633675690802256F, -1.4136551855681163F, 0.027864750313639417F, 0.004414499814537841F));
        g.addOrReplaceChild("tonel_116", CubeListBuilder.create().texOffs(352, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -16.60771342874234F, -5.633675690802256F, -1.4136551855681163F, -0.027864750313639417F, -0.004414499814537841F));
        g.addOrReplaceChild("tonel_117", CubeListBuilder.create().texOffs(368, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -16.623164278461086F, -5.536122864987497F, -1.4131640386017394F, -0.08341536447526557F, -0.013242811279246916F));
        g.addOrReplaceChild("tonel_118", CubeListBuilder.create().texOffs(384, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -16.654065977898583F, -5.341017213357983F, -1.4121866112730563F, -0.13843605681155316F, -0.022069058894343168F));
        g.addOrReplaceChild("tonel_119", CubeListBuilder.create().texOffs(400, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -16.700418527054822F, -5.04835873591371F, -1.4107324137362316F, -0.1925953808326678F, -0.030891868903545817F));
        g.addOrReplaceChild("tonel_120", CubeListBuilder.create().texOffs(416, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -18.299581472945178F, -5.04835873591371F, -1.7308602398535613F, 0.1925953808326678F, -0.030891868903546057F));
        g.addOrReplaceChild("tonel_121", CubeListBuilder.create().texOffs(432, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -18.345934022101417F, -5.341017213357983F, -1.7294060423167363F, 0.1384360568115531F, -0.022069058894342856F));
        g.addOrReplaceChild("tonel_122", CubeListBuilder.create().texOffs(448, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -18.37683572153891F, -5.536122864987498F, -1.7284286149880534F, 0.08341536447526558F, -0.013242811279246834F));
        g.addOrReplaceChild("tonel_123", CubeListBuilder.create().texOffs(464, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -18.39228657125766F, -5.6336756908022565F, -1.7279374680216766F, 0.027864750313639407F, -0.004414499814537841F));
        g.addOrReplaceChild("tonel_124", CubeListBuilder.create().texOffs(480, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -18.39228657125766F, -5.6336756908022565F, -1.7279374680216766F, -0.027864750313639407F, 0.004414499814537841F));
        g.addOrReplaceChild("tonel_125", CubeListBuilder.create().texOffs(496, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -18.376835721538914F, -5.536122864987499F, -1.7284286149880534F, -0.08341536447526558F, 0.013242811279246834F));
        g.addOrReplaceChild("tonel_126", CubeListBuilder.create().texOffs(512, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -18.345934022101417F, -5.341017213357983F, -1.7294060423167363F, -0.1384360568115531F, 0.022069058894342856F));
        g.addOrReplaceChild("tonel_127", CubeListBuilder.create().texOffs(528, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -18.299581472945178F, -5.04835873591371F, -1.7308602398535613F, -0.1925953808326678F, 0.030891868903546057F));
        g.addOrReplaceChild("tonel_128", CubeListBuilder.create().texOffs(544, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -19.820475813251953F, -4.554190208858885F, -2.0498207242137565F, 0.17354044183383488F, -0.08944095917962355F));
        g.addOrReplaceChild("tonel_129", CubeListBuilder.create().texOffs(560, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -19.954996150252065F, -4.818201235459401F, -2.046033823131554F, 0.12481024755801698F, -0.06396990215663108F));
        g.addOrReplaceChild("tonel_130", CubeListBuilder.create().texOffs(576, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -20.044676374918808F, -4.99420858652641F, -2.043481155490882F, 0.07523380324671855F, -0.03841547364434995F));
        g.addOrReplaceChild("tonel_131", CubeListBuilder.create().texOffs(592, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -20.089516487252176F, -5.082212262059915F, -2.0421962446566204F, 0.025136548588642095F, -0.012810759805632529F));
        g.addOrReplaceChild("tonel_132", CubeListBuilder.create().texOffs(608, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -20.089516487252176F, -5.082212262059915F, -2.0421962446566204F, -0.025136548588642095F, 0.012810759805632529F));
        g.addOrReplaceChild("tonel_133", CubeListBuilder.create().texOffs(624, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -20.044676374918808F, -4.99420858652641F, -2.043481155490882F, -0.07523380324671855F, 0.03841547364434995F));
        g.addOrReplaceChild("tonel_134", CubeListBuilder.create().texOffs(640, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -19.954996150252065F, -4.818201235459401F, -2.046033823131554F, -0.12481024755801698F, 0.06396990215663108F));
        g.addOrReplaceChild("tonel_135", CubeListBuilder.create().texOffs(656, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -19.820475813251953F, -4.554190208858886F, -2.0498207242137565F, -0.17354044183383488F, 0.08944095917962355F));
        g.addOrReplaceChild("tonel_136", CubeListBuilder.create().texOffs(672, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -21.114225813251952F, -3.6142258132519505F, -2.365763668249311F, 0.13746475937810115F, -0.13878229950083518F));
        g.addOrReplaceChild("tonel_137", CubeListBuilder.create().texOffs(688, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -21.323746150252063F, -3.823746150252063F, -2.3611226985623976F, 0.09895442761645012F, -0.09944249792279465F));
        g.addOrReplaceChild("tonel_138", CubeListBuilder.create().texOffs(704, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -21.463426374918807F, -3.9634263749188055F, -2.357979882512587F, 0.059685006120162955F, -0.05979159902972043F));
        g.addOrReplaceChild("tonel_139", CubeListBuilder.create().texOffs(720, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -21.533266487252178F, -4.033266487252177F, -2.356393498357187F, 0.019947700119697452F, -0.019951670006582718F));
        g.addOrReplaceChild("tonel_140", CubeListBuilder.create().texOffs(736, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -21.533266487252178F, -4.033266487252177F, -2.356393498357187F, -0.019947700119697452F, 0.019951670006582718F));
        g.addOrReplaceChild("tonel_141", CubeListBuilder.create().texOffs(752, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -21.463426374918807F, -3.9634263749188055F, -2.357979882512587F, -0.059685006120162955F, 0.05979159902972043F));
        g.addOrReplaceChild("tonel_142", CubeListBuilder.create().texOffs(768, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -21.323746150252063F, -3.823746150252063F, -2.3611226985623976F, -0.09895442761645012F, 0.09944249792279465F));
        g.addOrReplaceChild("tonel_143", CubeListBuilder.create().texOffs(784, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -21.114225813251952F, -3.61422581325195F, -2.365763668249311F, -0.13746475937810115F, 0.13878229950083518F));
        g.addOrReplaceChild("tonel_144", CubeListBuilder.create().texOffs(800, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -22.054190208858888F, -2.3204758132519516F, -2.678052164625234F, 0.08809400825405699F, -0.17422291663587286F));
        g.addOrReplaceChild("tonel_145", CubeListBuilder.create().texOffs(816, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -22.318201235459398F, -2.4549961502520645F, -2.674329255113161F, 0.06347162797185323F, -0.12506339837767633F));
        g.addOrReplaceChild("tonel_146", CubeListBuilder.create().texOffs(832, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -22.494208586526412F, -2.5446763749188066F, -2.6717966545931553F, 0.03830675346061777F, -0.07528914089579732F));
        g.addOrReplaceChild("tonel_147", CubeListBuilder.create().texOffs(848, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -22.582212262059915F, -2.589516487252178F, -2.670514737708699F, 0.012806712583277986F, -0.025138610510250126F));
        g.addOrReplaceChild("tonel_148", CubeListBuilder.create().texOffs(864, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -22.58221226205992F, -2.5895164872521783F, -2.670514737708699F, -0.012806712583277986F, 0.025138610510250126F));
        g.addOrReplaceChild("tonel_149", CubeListBuilder.create().texOffs(880, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -22.494208586526412F, -2.5446763749188066F, -2.6717966545931553F, -0.03830675346061777F, 0.07528914089579732F));
        g.addOrReplaceChild("tonel_150", CubeListBuilder.create().texOffs(896, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -22.3182012354594F, -2.454996150252065F, -2.674329255113161F, -0.06347162797185323F, 0.12506339837767633F));
        g.addOrReplaceChild("tonel_151", CubeListBuilder.create().texOffs(912, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -22.054190208858884F, -2.3204758132519516F, -2.678052164625234F, -0.08809400825405699F, 0.17422291663587286F));
        g.addOrReplaceChild("tonel_152", CubeListBuilder.create().texOffs(928, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(34.375F, -22.54835873591371F, -0.7995814729451777F, -2.9874434710087105F, 0.030320525211280435F, -0.19268505683159534F));
        g.addOrReplaceChild("tonel_153", CubeListBuilder.create().texOffs(944, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(36.125F, -22.84101721335798F, -0.8459340221014197F, -2.9860288275608293F, 0.021857890914122987F, -0.13846934652282733F));
        g.addOrReplaceChild("tonel_154", CubeListBuilder.create().texOffs(960, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.875F, -23.036122864987497F, -0.8768357215389145F, -2.9850638027757586F, 0.013196762754969366F, -0.08342264548232661F));
        g.addOrReplaceChild("tonel_155", CubeListBuilder.create().texOffs(976, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.625F, -23.133675690802253F, -0.8922865712576619F, -2.9845745061787983F, 0.004412786107667665F, -0.027865021686780452F));
        g.addOrReplaceChild("tonel_156", CubeListBuilder.create().texOffs(992, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.375F, -23.133675690802256F, -0.8922865712576619F, -2.9845745061787983F, -0.004412786107667665F, 0.027865021686780452F));
        g.addOrReplaceChild("tonel_157", CubeListBuilder.create().texOffs(1008, 99).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(43.125F, -23.036122864987497F, -0.8768357215389145F, -2.9850638027757586F, -0.013196762754969366F, 0.08342264548232661F));
        g.addOrReplaceChild("tonel_158", CubeListBuilder.create().texOffs(0, 104).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(44.875F, -22.841017213357986F, -0.8459340221014197F, -2.9860288275608293F, -0.021857890914122987F, 0.13846934652282733F));
        g.addOrReplaceChild("tonel_159", CubeListBuilder.create().texOffs(16, 104).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(46.625F, -22.54835873591371F, -0.7995814729451777F, -2.9874434710087105F, -0.030320525211280435F, 0.19268505683159534F));
        g.addOrReplaceChild("tonel_tapaa", CubeListBuilder.create().texOffs(352, 0).addBox(-20.0F, 0.0F, -20.0F, 40.0F, 1.0F, 40.0F), PartPose.offsetAndRotation(33.45F, -17.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("tonel_tapab", CubeListBuilder.create().texOffs(512, 0).addBox(-20.0F, 0.0F, -20.0F, 40.0F, 1.0F, 40.0F), PartPose.offsetAndRotation(47.55F, -17.5F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("tonel_boca_0", CubeListBuilder.create().texOffs(626, 73).addBox(-13.0F, -24.5F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(870, 0).addBox(-3.5F, -24.5F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offset(40.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("tonel_boca_1", CubeListBuilder.create().texOffs(692, 73).addBox(-13.0F, -24.5F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(936, 0).addBox(-3.5F, -24.5F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(40.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("tonel_boca_2", CubeListBuilder.create().texOffs(758, 73).addBox(-13.0F, -24.5F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(0, 45).addBox(-3.5F, -24.5F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(40.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "contrai0", 1.0F, 0.8914780126473288F, 1.0F);
        escalar(g0, "contrai1", 1.0F, 1.0404646741920613F, 1.0F);
        escalar(g0, "contrad0", 1.0F, 0.8914780126473288F, 1.0F);
        escalar(g0, "contrad1", 1.0F, 1.0404646741920613F, 1.0F);
        escalar(g0, "caldera_0", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_1", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_2", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_3", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_4", 0.90625F, 1.0F, 0.7178940572102834F);
        escalar(g0, "caldera_5", 0.90625F, 1.0F, 0.7178940572102834F);
        escalar(g0, "caldera_6", 0.90625F, 1.0F, 0.7178940572102834F);
        escalar(g0, "caldera_7", 0.90625F, 1.0F, 0.7178940572102834F);
        escalar(g0, "caldera_8", 0.90625F, 1.0F, 0.7178940572102847F);
        escalar(g0, "caldera_9", 0.90625F, 1.0F, 0.7178940572102847F);
        escalar(g0, "caldera_10", 0.90625F, 1.0F, 0.7178940572102847F);
        escalar(g0, "caldera_11", 0.90625F, 1.0F, 0.7178940572102847F);
        escalar(g0, "caldera_12", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_13", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_14", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_15", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_16", 0.90625F, 1.0F, 0.7178940572102828F);
        escalar(g0, "caldera_17", 0.90625F, 1.0F, 0.7178940572102828F);
        escalar(g0, "caldera_18", 0.90625F, 1.0F, 0.7178940572102828F);
        escalar(g0, "caldera_19", 0.90625F, 1.0F, 0.7178940572102828F);
        escalar(g0, "caldera_20", 0.90625F, 1.0F, 0.7178940572102849F);
        escalar(g0, "caldera_21", 0.90625F, 1.0F, 0.7178940572102849F);
        escalar(g0, "caldera_22", 0.90625F, 1.0F, 0.7178940572102849F);
        escalar(g0, "caldera_23", 0.90625F, 1.0F, 0.7178940572102849F);
        escalar(g0, "caldera_24", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_25", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_26", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_27", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_28", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_29", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_30", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_31", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_32", 0.90625F, 1.0F, 0.7178940572102843F);
        escalar(g0, "caldera_33", 0.90625F, 1.0F, 0.7178940572102843F);
        escalar(g0, "caldera_34", 0.90625F, 1.0F, 0.7178940572102843F);
        escalar(g0, "caldera_35", 0.90625F, 1.0F, 0.7178940572102843F);
        escalar(g0, "caldera_36", 0.90625F, 1.0F, 0.7178940572102831F);
        escalar(g0, "caldera_37", 0.90625F, 1.0F, 0.7178940572102831F);
        escalar(g0, "caldera_38", 0.90625F, 1.0F, 0.7178940572102831F);
        escalar(g0, "caldera_39", 0.90625F, 1.0F, 0.7178940572102831F);
        escalar(g0, "caldera_40", 0.90625F, 1.0F, 0.7178940572102841F);
        escalar(g0, "caldera_41", 0.90625F, 1.0F, 0.7178940572102841F);
        escalar(g0, "caldera_42", 0.90625F, 1.0F, 0.7178940572102841F);
        escalar(g0, "caldera_43", 0.90625F, 1.0F, 0.7178940572102841F);
        escalar(g0, "caldera_44", 0.90625F, 1.0F, 0.7178940572102841F);
        escalar(g0, "caldera_45", 0.90625F, 1.0F, 0.7178940572102841F);
        escalar(g0, "caldera_46", 0.90625F, 1.0F, 0.7178940572102841F);
        escalar(g0, "caldera_47", 0.90625F, 1.0F, 0.7178940572102841F);
        escalar(g0, "caldera_48", 0.90625F, 1.0F, 0.7178940572102829F);
        escalar(g0, "caldera_49", 0.90625F, 1.0F, 0.7178940572102829F);
        escalar(g0, "caldera_50", 0.90625F, 1.0F, 0.7178940572102829F);
        escalar(g0, "caldera_51", 0.90625F, 1.0F, 0.7178940572102829F);
        escalar(g0, "caldera_52", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_53", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_54", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_55", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_56", 0.90625F, 1.0F, 0.7178940572102853F);
        escalar(g0, "caldera_57", 0.90625F, 1.0F, 0.7178940572102853F);
        escalar(g0, "caldera_58", 0.90625F, 1.0F, 0.7178940572102853F);
        escalar(g0, "caldera_59", 0.90625F, 1.0F, 0.7178940572102853F);
        escalar(g0, "caldera_60", 0.90625F, 1.0F, 0.7178940572102827F);
        escalar(g0, "caldera_61", 0.90625F, 1.0F, 0.7178940572102827F);
        escalar(g0, "caldera_62", 0.90625F, 1.0F, 0.7178940572102827F);
        escalar(g0, "caldera_63", 0.90625F, 1.0F, 0.7178940572102827F);
        escalar(g0, "caldera_64", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_65", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_66", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_67", 0.90625F, 1.0F, 0.7178940572102837F);
        escalar(g0, "caldera_68", 0.90625F, 1.0F, 0.7178940572102857F);
        escalar(g0, "caldera_69", 0.90625F, 1.0F, 0.7178940572102857F);
        escalar(g0, "caldera_70", 0.90625F, 1.0F, 0.7178940572102857F);
        escalar(g0, "caldera_71", 0.90625F, 1.0F, 0.7178940572102857F);
        escalar(g0, "caldera_72", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_73", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_74", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_75", 0.90625F, 1.0F, 0.717894057210283F);
        escalar(g0, "caldera_76", 0.90625F, 1.0F, 0.7178940572102824F);
        escalar(g0, "caldera_77", 0.90625F, 1.0F, 0.7178940572102824F);
        escalar(g0, "caldera_78", 0.90625F, 1.0F, 0.7178940572102824F);
        escalar(g0, "caldera_79", 0.90625F, 1.0F, 0.7178940572102824F);
        escalar(g0, "caldera_80", 0.90625F, 1.0F, 0.7178940572102854F);
        escalar(g0, "caldera_81", 0.90625F, 1.0F, 0.7178940572102854F);
        escalar(g0, "caldera_82", 0.90625F, 1.0F, 0.7178940572102854F);
        escalar(g0, "caldera_83", 0.90625F, 1.0F, 0.7178940572102854F);
        escalar(g0, "caldera_84", 0.90625F, 1.0F, 0.7178940572102829F);
        escalar(g0, "caldera_85", 0.90625F, 1.0F, 0.7178940572102829F);
        escalar(g0, "caldera_86", 0.90625F, 1.0F, 0.7178940572102829F);
        escalar(g0, "caldera_87", 0.90625F, 1.0F, 0.7178940572102829F);
        escalar(g0, "caldera_88", 0.90625F, 1.0F, 0.7178940572102827F);
        escalar(g0, "caldera_89", 0.90625F, 1.0F, 0.7178940572102827F);
        escalar(g0, "caldera_90", 0.90625F, 1.0F, 0.7178940572102827F);
        escalar(g0, "caldera_91", 0.90625F, 1.0F, 0.7178940572102827F);
        escalar(g0, "caldera_92", 0.90625F, 1.0F, 0.7178940572102854F);
        escalar(g0, "caldera_93", 0.90625F, 1.0F, 0.7178940572102854F);
        escalar(g0, "caldera_94", 0.90625F, 1.0F, 0.7178940572102854F);
        escalar(g0, "caldera_95", 0.90625F, 1.0F, 0.7178940572102854F);
        escalar(g0, "caldera_frente", 0.25F, 0.6F, 0.25F);
        escalar(g0, "caldera_atras", 0.25F, 0.6F, 0.25F);
        escalar(g0, "chimenea_base_0", 0.5100083458096798F, 1.0F, 0.5100083458096798F);
        escalar(g0, "chimenea_base_1", 0.5100083458096798F, 1.0F, 0.5100083458096798F);
        escalar(g0, "chimenea_base_2", 0.5100083458096798F, 1.0F, 0.5100083458096798F);
        escalar(g0, "chimenea_base_3", 0.5100083458096798F, 1.0F, 0.5100083458096798F);
        escalar(g0, "chimenea_0", 0.5F, 1.0F, 0.3901806440322565F);
        escalar(g0, "chimenea_1", 0.3705251528424072F, 1.0F, 0.4057878697935468F);
        escalar(g0, "chimenea_2", 0.3681183384607601F, 1.0F, 0.48382399859999825F);
        escalar(g0, "chimenea_3", 0.30000000000000016F, 1.0F, 0.4877258050403207F);
        escalar(g0, "chimenea_4", 0.5F, 1.0F, 0.3901806440322564F);
        escalar(g0, "chimenea_5", 0.37052515284240717F, 1.0F, 0.40578786979354675F);
        escalar(g0, "chimenea_6", 0.3681183384607601F, 1.0F, 0.4838239985999979F);
        escalar(g0, "chimenea_7", 0.2999999999999997F, 1.0F, 0.48772580504032026F);
        escalar(g0, "chimenea_8", 0.5F, 1.0F, 0.390180644032257F);
        escalar(g0, "chimenea_9", 0.3705251528424072F, 1.0F, 0.40578786979354686F);
        escalar(g0, "chimenea_10", 0.3681183384607601F, 1.0F, 0.4838239985999979F);
        escalar(g0, "chimenea_11", 0.2999999999999999F, 1.0F, 0.4877258050403208F);
        escalar(g0, "chimenea_12", 0.5F, 1.0F, 0.3901806440322564F);
        escalar(g0, "chimenea_13", 0.3705251528424072F, 1.0F, 0.4057878697935468F);
        escalar(g0, "chimenea_14", 0.3681183384607601F, 1.0F, 0.4838239985999981F);
        escalar(g0, "chimenea_15", 0.30000000000000004F, 1.0F, 0.4877258050403205F);
        escalar(g0, "chimenea_16", 0.5F, 1.0F, 0.3901806440322564F);
        escalar(g0, "chimenea_17", 0.3705251528424072F, 1.0F, 0.4057878697935468F);
        escalar(g0, "chimenea_18", 0.3681183384607601F, 1.0F, 0.4838239985999981F);
        escalar(g0, "chimenea_19", 0.30000000000000004F, 1.0F, 0.4877258050403205F);
        escalar(g0, "chimenea_20", 0.5F, 1.0F, 0.39018064403225694F);
        escalar(g0, "chimenea_21", 0.3705251528424072F, 1.0F, 0.4057878697935468F);
        escalar(g0, "chimenea_22", 0.3681183384607602F, 1.0F, 0.48382399859999786F);
        escalar(g0, "chimenea_23", 0.29999999999999993F, 1.0F, 0.48772580504032076F);
        escalar(g0, "chimenea_24", 0.5F, 1.0F, 0.3901806440322564F);
        escalar(g0, "chimenea_25", 0.37052515284240717F, 1.0F, 0.40578786979354675F);
        escalar(g0, "chimenea_26", 0.3681183384607601F, 1.0F, 0.48382399859999803F);
        escalar(g0, "chimenea_27", 0.2999999999999997F, 1.0F, 0.4877258050403203F);
        escalar(g0, "chimenea_28", 0.5F, 1.0F, 0.3901806440322565F);
        escalar(g0, "chimenea_29", 0.3705251528424072F, 1.0F, 0.4057878697935468F);
        escalar(g0, "chimenea_30", 0.3681183384607601F, 1.0F, 0.4838239985999982F);
        escalar(g0, "chimenea_31", 0.30000000000000016F, 1.0F, 0.4877258050403207F);
        escalar(g0, "chimenea_32", 0.5F, 1.0F, 0.3901806440322565F);
        escalar(g0, "chimenea_33", 0.3705251528424072F, 1.0F, 0.4057878697935468F);
        escalar(g0, "chimenea_34", 0.36811833846076025F, 1.0F, 0.48382399859999814F);
        escalar(g0, "chimenea_35", 0.3000000000000006F, 1.0F, 0.4877258050403206F);
        escalar(g0, "chimenea_36", 0.5F, 1.0F, 0.3901806440322565F);
        escalar(g0, "chimenea_37", 0.3705251528424072F, 1.0F, 0.40578786979354664F);
        escalar(g0, "chimenea_38", 0.3681183384607601F, 1.0F, 0.48382399859999814F);
        escalar(g0, "chimenea_39", 0.30000000000000004F, 1.0F, 0.4877258050403207F);
        escalar(g0, "chimenea_40", 0.5F, 1.0F, 0.39018064403225616F);
        escalar(g0, "chimenea_41", 0.3705251528424072F, 1.0F, 0.40578786979354675F);
        escalar(g0, "chimenea_42", 0.3681183384607601F, 1.0F, 0.48382399859999786F);
        escalar(g0, "chimenea_43", 0.2999999999999999F, 1.0F, 0.48772580504032004F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "chimenea_44", 0.5F, 1.0F, 0.3901806440322573F);
        escalar(g0, "chimenea_45", 0.3705251528424072F, 1.0F, 0.4057878697935473F);
        escalar(g0, "chimenea_46", 0.36811833846076025F, 1.0F, 0.4838239985999986F);
        escalar(g0, "chimenea_47", 0.30000000000000004F, 1.0F, 0.48772580504032137F);
        escalar(g0, "chimenea_48", 0.5F, 1.0F, 0.39018064403225644F);
        escalar(g0, "chimenea_49", 0.3705251528424072F, 1.0F, 0.40578786979354686F);
        escalar(g0, "chimenea_50", 0.36811833846076025F, 1.0F, 0.4838239985999986F);
        escalar(g0, "chimenea_51", 0.3000000000000002F, 1.0F, 0.4877258050403209F);
        escalar(g0, "chimenea_52", 0.5F, 1.0F, 0.3901806440322561F);
        escalar(g0, "chimenea_53", 0.3705251528424072F, 1.0F, 0.4057878697935463F);
        escalar(g0, "chimenea_54", 0.36811833846076025F, 1.0F, 0.4838239985999974F);
        escalar(g0, "chimenea_55", 0.3000000000000004F, 1.0F, 0.4877258050403199F);
        escalar(g0, "chimenea_56", 0.5F, 1.0F, 0.39018064403225605F);
        escalar(g0, "chimenea_57", 0.3705251528424072F, 1.0F, 0.4057878697935464F);
        escalar(g0, "chimenea_58", 0.3681183384607601F, 1.0F, 0.4838239985999976F);
        escalar(g0, "chimenea_59", 0.30000000000000004F, 1.0F, 0.4877258050403202F);
        escalar(g0, "chimenea_60", 0.5F, 1.0F, 0.39018064403225705F);
        escalar(g0, "chimenea_61", 0.3705251528424072F, 1.0F, 0.40578786979354725F);
        escalar(g0, "chimenea_62", 0.3681183384607602F, 1.0F, 0.4838239985999986F);
        escalar(g0, "chimenea_63", 0.3000000000000002F, 1.0F, 0.4877258050403211F);
        escalar(g0, "chimenea_hueco", 0.24705882352941172F, 0.6F, 0.24705882352941172F);
        escalar(g0, "valvula_0", 0.06687178797385858F, 1.0F, 0.06687178797385858F);
        escalar(g0, "valvula_1", 0.06687178797385858F, 1.0F, 0.06687178797385858F);
        escalar(g0, "valvula_2", 0.06687178797385858F, 1.0F, 0.06687178797385858F);
        escalar(g0, "valvula_palanca", 0.6F, 0.9166666666666666F, 0.6F);
        escalar(g0, "cil0_brida_0", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "cil0_brida_1", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "cil0_brida_2", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "cil0_brida_3", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "cil0_0", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "cil0_1", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "cil0_2", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "cil0_3", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "cil0_tapa", 0.25F, 0.6F, 0.25F);
        escalar(g0, "vastago0", 0.7F, 0.914285714285714F, 0.7F);
        escalar(g0, "cil1_brida_0", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "cil1_brida_1", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "cil1_brida_2", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "cil1_brida_3", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g0, "cil1_0", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "cil1_1", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "cil1_2", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "cil1_3", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "cil1_tapa", 0.25F, 0.6F, 0.25F);
        escalar(g0, "vastago1", 0.7F, 0.914285714285714F, 0.7F);
        escalar(g0, "cab_manometro", 0.24F, 0.6F, 0.24F);
        escalar(g0, "cab_manometro_aguja", 0.3F, 0.9839999999999999F, 0.6F);
        escalar(g0, "cab_regulador", 0.7F, 0.8316249154516718F, 0.7F);
        escalar(g1, "tonel_0", 0.4461642074393687F, 1.0F, 0.4047741782915974F);
        escalar(g1, "tonel_1", 0.4419417382415922F, 1.0F, 0.4282393480476321F);
        escalar(g1, "tonel_2", 0.4391042017562574F, 1.0F, 0.44388279455165514F);
        escalar(g1, "tonel_3", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_4", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_5", 0.4391042017562574F, 1.0F, 0.44388279455165514F);
        escalar(g1, "tonel_6", 0.4419417382415922F, 1.0F, 0.4282393480476321F);
        escalar(g1, "tonel_7", 0.4461642074393687F, 1.0F, 0.4047741782915974F);
        escalar(g1, "tonel_8", 0.44616420743936863F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_9", 0.4419417382415922F, 1.0F, 0.42823934804763186F);
        escalar(g1, "tonel_10", 0.4391042017562574F, 1.0F, 0.44388279455165514F);
        escalar(g1, "tonel_11", 0.43767853500028986F, 1.0F, 0.4517045178036665F);
        escalar(g1, "tonel_12", 0.43767853500028986F, 1.0F, 0.4517045178036665F);
        escalar(g1, "tonel_13", 0.4391042017562574F, 1.0F, 0.44388279455165514F);
        escalar(g1, "tonel_14", 0.4419417382415922F, 1.0F, 0.42823934804763186F);
        escalar(g1, "tonel_15", 0.44616420743936863F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_16", 0.4461642074393687F, 1.0F, 0.4047741782915977F);
        escalar(g1, "tonel_17", 0.4419417382415922F, 1.0F, 0.4282393480476322F);
        escalar(g1, "tonel_18", 0.4391042017562574F, 1.0F, 0.443882794551655F);
        escalar(g1, "tonel_19", 0.43767853500028986F, 1.0F, 0.4517045178036667F);
        escalar(g1, "tonel_20", 0.43767853500028986F, 1.0F, 0.4517045178036667F);
        escalar(g1, "tonel_21", 0.4391042017562574F, 1.0F, 0.443882794551655F);
        escalar(g1, "tonel_22", 0.4419417382415922F, 1.0F, 0.4282393480476322F);
        escalar(g1, "tonel_23", 0.4461642074393687F, 1.0F, 0.4047741782915977F);
        escalar(g1, "tonel_24", 0.4461642074393687F, 1.0F, 0.4047741782915969F);
        escalar(g1, "tonel_25", 0.4419417382415922F, 1.0F, 0.42823934804763186F);
        escalar(g1, "tonel_26", 0.4391042017562574F, 1.0F, 0.4438827945516552F);
        escalar(g1, "tonel_27", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_28", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_29", 0.4391042017562574F, 1.0F, 0.4438827945516552F);
        escalar(g1, "tonel_30", 0.4419417382415922F, 1.0F, 0.42823934804763186F);
        escalar(g1, "tonel_31", 0.4461642074393687F, 1.0F, 0.4047741782915969F);
        escalar(g1, "tonel_32", 0.44616420743936863F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_33", 0.4419417382415922F, 1.0F, 0.42823934804763186F);
        escalar(g1, "tonel_34", 0.4391042017562574F, 1.0F, 0.4438827945516549F);
        escalar(g1, "tonel_35", 0.4376785350002899F, 1.0F, 0.4517045178036664F);
        escalar(g1, "tonel_36", 0.4376785350002899F, 1.0F, 0.4517045178036664F);
        escalar(g1, "tonel_37", 0.4391042017562574F, 1.0F, 0.4438827945516549F);
        escalar(g1, "tonel_38", 0.4419417382415922F, 1.0F, 0.42823934804763186F);
        escalar(g1, "tonel_39", 0.44616420743936863F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_40", 0.44616420743936863F, 1.0F, 0.4047741782915975F);
        escalar(g1, "tonel_41", 0.4419417382415922F, 1.0F, 0.4282393480476321F);
        escalar(g1, "tonel_42", 0.4391042017562574F, 1.0F, 0.44388279455165536F);
        escalar(g1, "tonel_43", 0.4376785350002899F, 1.0F, 0.4517045178036668F);
        escalar(g1, "tonel_44", 0.4376785350002899F, 1.0F, 0.4517045178036668F);
        escalar(g1, "tonel_45", 0.4391042017562574F, 1.0F, 0.44388279455165536F);
        escalar(g1, "tonel_46", 0.4419417382415922F, 1.0F, 0.4282393480476321F);
        escalar(g1, "tonel_47", 0.44616420743936863F, 1.0F, 0.4047741782915975F);
        escalar(g1, "tonel_48", 0.44616420743936863F, 1.0F, 0.4047741782915969F);
        escalar(g1, "tonel_49", 0.4419417382415922F, 1.0F, 0.42823934804763164F);
        escalar(g1, "tonel_50", 0.4391042017562574F, 1.0F, 0.4438827945516548F);
        escalar(g1, "tonel_51", 0.43767853500028986F, 1.0F, 0.4517045178036663F);
        escalar(g1, "tonel_52", 0.43767853500028986F, 1.0F, 0.4517045178036663F);
        escalar(g1, "tonel_53", 0.4391042017562574F, 1.0F, 0.4438827945516548F);
        escalar(g1, "tonel_54", 0.4419417382415922F, 1.0F, 0.42823934804763164F);
        escalar(g1, "tonel_55", 0.44616420743936863F, 1.0F, 0.4047741782915969F);
        escalar(g1, "tonel_56", 0.4461642074393687F, 1.0F, 0.40477417829159745F);
        escalar(g1, "tonel_57", 0.4419417382415922F, 1.0F, 0.4282393480476321F);
        escalar(g1, "tonel_58", 0.4391042017562574F, 1.0F, 0.4438827945516549F);
        escalar(g1, "tonel_59", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_60", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_61", 0.4391042017562574F, 1.0F, 0.4438827945516549F);
        escalar(g1, "tonel_62", 0.4419417382415922F, 1.0F, 0.4282393480476321F);
        escalar(g1, "tonel_63", 0.4461642074393687F, 1.0F, 0.40477417829159745F);
        escalar(g1, "tonel_64", 0.44616420743936863F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_65", 0.4419417382415922F, 1.0F, 0.42823934804763186F);
        escalar(g1, "tonel_66", 0.4391042017562574F, 1.0F, 0.44388279455165514F);
        escalar(g1, "tonel_67", 0.43767853500028986F, 1.0F, 0.4517045178036667F);
        escalar(g1, "tonel_68", 0.43767853500028986F, 1.0F, 0.4517045178036667F);
        escalar(g1, "tonel_69", 0.4391042017562574F, 1.0F, 0.44388279455165514F);
        escalar(g1, "tonel_70", 0.4419417382415922F, 1.0F, 0.42823934804763186F);
        escalar(g1, "tonel_71", 0.44616420743936863F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_72", 0.4461642074393686F, 1.0F, 0.4047741782915973F);
        escalar(g1, "tonel_73", 0.4419417382415922F, 1.0F, 0.428239348047632F);
        escalar(g1, "tonel_74", 0.4391042017562574F, 1.0F, 0.443882794551655F);
        escalar(g1, "tonel_75", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_76", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_77", 0.4391042017562574F, 1.0F, 0.443882794551655F);
        escalar(g1, "tonel_78", 0.4419417382415922F, 1.0F, 0.428239348047632F);
        escalar(g1, "tonel_79", 0.4461642074393686F, 1.0F, 0.4047741782915973F);
        escalar(g1, "tonel_80", 0.4461642074393686F, 1.0F, 0.4047741782915979F);
        escalar(g1, "tonel_81", 0.4419417382415922F, 1.0F, 0.42823934804763264F);
        escalar(g1, "tonel_82", 0.4391042017562574F, 1.0F, 0.4438827945516557F);
        escalar(g1, "tonel_83", 0.43767853500028986F, 1.0F, 0.45170451780366727F);
        escalar(g1, "tonel_84", 0.43767853500028986F, 1.0F, 0.45170451780366727F);
        escalar(g1, "tonel_85", 0.4391042017562574F, 1.0F, 0.4438827945516557F);
        escalar(g1, "tonel_86", 0.4419417382415922F, 1.0F, 0.42823934804763264F);
        escalar(g1, "tonel_87", 0.4461642074393686F, 1.0F, 0.4047741782915979F);
        escalar(g1, "tonel_88", 0.4461642074393686F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_89", 0.4419417382415922F, 1.0F, 0.42823934804763175F);
        escalar(g1, "tonel_90", 0.4391042017562574F, 1.0F, 0.44388279455165497F);
        escalar(g1, "tonel_91", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_92", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_93", 0.4391042017562574F, 1.0F, 0.44388279455165497F);
        escalar(g1, "tonel_94", 0.4419417382415922F, 1.0F, 0.42823934804763175F);
        escalar(g1, "tonel_95", 0.4461642074393686F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_96", 0.4461642074393687F, 1.0F, 0.4047741782915968F);
        escalar(g1, "tonel_97", 0.4419417382415922F, 1.0F, 0.42823934804763153F);
        escalar(g1, "tonel_98", 0.4391042017562574F, 1.0F, 0.4438827945516546F);
        escalar(g1, "tonel_99", 0.4376785350002899F, 1.0F, 0.45170451780366616F);
        escalar(g1, "tonel_100", 0.4376785350002899F, 1.0F, 0.45170451780366616F);
        escalar(g1, "tonel_101", 0.4391042017562574F, 1.0F, 0.4438827945516546F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1) {
        escalar(g1, "tonel_102", 0.4419417382415922F, 1.0F, 0.42823934804763153F);
        escalar(g1, "tonel_103", 0.4461642074393687F, 1.0F, 0.4047741782915968F);
        escalar(g1, "tonel_104", 0.4461642074393687F, 1.0F, 0.40477417829159745F);
        escalar(g1, "tonel_105", 0.4419417382415922F, 1.0F, 0.4282393480476321F);
        escalar(g1, "tonel_106", 0.4391042017562574F, 1.0F, 0.443882794551655F);
        escalar(g1, "tonel_107", 0.4376785350002899F, 1.0F, 0.4517045178036665F);
        escalar(g1, "tonel_108", 0.4376785350002899F, 1.0F, 0.4517045178036665F);
        escalar(g1, "tonel_109", 0.4391042017562574F, 1.0F, 0.443882794551655F);
        escalar(g1, "tonel_110", 0.4419417382415922F, 1.0F, 0.4282393480476321F);
        escalar(g1, "tonel_111", 0.4461642074393687F, 1.0F, 0.40477417829159745F);
        escalar(g1, "tonel_112", 0.44616420743936863F, 1.0F, 0.4047741782915975F);
        escalar(g1, "tonel_113", 0.4419417382415922F, 1.0F, 0.4282393480476321F);
        escalar(g1, "tonel_114", 0.4391042017562574F, 1.0F, 0.44388279455165536F);
        escalar(g1, "tonel_115", 0.4376785350002899F, 1.0F, 0.4517045178036668F);
        escalar(g1, "tonel_116", 0.4376785350002899F, 1.0F, 0.4517045178036668F);
        escalar(g1, "tonel_117", 0.4391042017562574F, 1.0F, 0.44388279455165536F);
        escalar(g1, "tonel_118", 0.4419417382415922F, 1.0F, 0.4282393480476321F);
        escalar(g1, "tonel_119", 0.44616420743936863F, 1.0F, 0.4047741782915975F);
        escalar(g1, "tonel_120", 0.44616420743936863F, 1.0F, 0.40477417829159723F);
        escalar(g1, "tonel_121", 0.4419417382415922F, 1.0F, 0.4282393480476318F);
        escalar(g1, "tonel_122", 0.4391042017562574F, 1.0F, 0.44388279455165486F);
        escalar(g1, "tonel_123", 0.4376785350002899F, 1.0F, 0.4517045178036664F);
        escalar(g1, "tonel_124", 0.4376785350002899F, 1.0F, 0.4517045178036664F);
        escalar(g1, "tonel_125", 0.4391042017562574F, 1.0F, 0.44388279455165486F);
        escalar(g1, "tonel_126", 0.4419417382415922F, 1.0F, 0.4282393480476318F);
        escalar(g1, "tonel_127", 0.44616420743936863F, 1.0F, 0.40477417829159723F);
        escalar(g1, "tonel_128", 0.44616420743936863F, 1.0F, 0.40477417829159845F);
        escalar(g1, "tonel_129", 0.4419417382415922F, 1.0F, 0.4282393480476329F);
        escalar(g1, "tonel_130", 0.4391042017562574F, 1.0F, 0.4438827945516563F);
        escalar(g1, "tonel_131", 0.43767853500028986F, 1.0F, 0.4517045178036678F);
        escalar(g1, "tonel_132", 0.43767853500028986F, 1.0F, 0.4517045178036678F);
        escalar(g1, "tonel_133", 0.4391042017562574F, 1.0F, 0.4438827945516563F);
        escalar(g1, "tonel_134", 0.4419417382415922F, 1.0F, 0.4282393480476329F);
        escalar(g1, "tonel_135", 0.44616420743936863F, 1.0F, 0.40477417829159845F);
        escalar(g1, "tonel_136", 0.4461642074393687F, 1.0F, 0.40477417829159623F);
        escalar(g1, "tonel_137", 0.4419417382415922F, 1.0F, 0.42823934804763103F);
        escalar(g1, "tonel_138", 0.4391042017562574F, 1.0F, 0.4438827945516538F);
        escalar(g1, "tonel_139", 0.43767853500028986F, 1.0F, 0.45170451780366544F);
        escalar(g1, "tonel_140", 0.43767853500028986F, 1.0F, 0.45170451780366544F);
        escalar(g1, "tonel_141", 0.4391042017562574F, 1.0F, 0.4438827945516538F);
        escalar(g1, "tonel_142", 0.4419417382415922F, 1.0F, 0.42823934804763103F);
        escalar(g1, "tonel_143", 0.4461642074393687F, 1.0F, 0.40477417829159623F);
        escalar(g1, "tonel_144", 0.44616420743936863F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_145", 0.4419417382415922F, 1.0F, 0.4282393480476318F);
        escalar(g1, "tonel_146", 0.4391042017562574F, 1.0F, 0.44388279455165514F);
        escalar(g1, "tonel_147", 0.43767853500028986F, 1.0F, 0.45170451780366655F);
        escalar(g1, "tonel_148", 0.43767853500028986F, 1.0F, 0.45170451780366655F);
        escalar(g1, "tonel_149", 0.4391042017562574F, 1.0F, 0.44388279455165514F);
        escalar(g1, "tonel_150", 0.4419417382415922F, 1.0F, 0.4282393480476318F);
        escalar(g1, "tonel_151", 0.44616420743936863F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_152", 0.4461642074393687F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_153", 0.4419417382415922F, 1.0F, 0.428239348047632F);
        escalar(g1, "tonel_154", 0.4391042017562574F, 1.0F, 0.443882794551655F);
        escalar(g1, "tonel_155", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_156", 0.43767853500028986F, 1.0F, 0.4517045178036666F);
        escalar(g1, "tonel_157", 0.4391042017562574F, 1.0F, 0.443882794551655F);
        escalar(g1, "tonel_158", 0.4419417382415922F, 1.0F, 0.428239348047632F);
        escalar(g1, "tonel_159", 0.4461642074393687F, 1.0F, 0.40477417829159734F);
        escalar(g1, "tonel_tapaa", 0.25F, 0.6F, 0.25F);
        escalar(g1, "tonel_tapab", 0.25F, 0.6F, 0.25F);
        escalar(g1, "tonel_boca_0", 0.08916238396514477F, 1.0F, 0.08916238396514477F);
        escalar(g1, "tonel_boca_1", 0.08916238396514477F, 1.0F, 0.08916238396514477F);
        escalar(g1, "tonel_boca_2", 0.08916238396514477F, 1.0F, 0.08916238396514477F);
    }
}
