package com.locomotora.cliente;

import java.util.List;

import com.locomotora.cliente.modelos.DatosModelo;
import com.locomotora.entidad.VehiculoDeVia;
import com.locomotora.entidad.Via;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.phys.Vec3;

import org.jetbrains.annotations.Nullable;

/**
 * Dibuja una locomotora (o un vagón) y anima ruedas y bielas según la distancia recorrida. Las luces (faros,
 * faroles, luces de cola, la boca del hogar) brillan en la oscuridad: si el modelo tiene una textura
 * {@code <nombre>_luces.png} (lo que es luz, con su color; lo demás transparente), se dibuja encima sin sombra.
 * <ul>
 *   <li>Modelos cortos: el modelo entero sigue la inclinación del riel en el centro (igual que una vagoneta).</li>
 *   <li>Trenes largos (por ejemplo, locomotora con ténder): cada cuerpo se apoya en la vía por sus dos bogies,
 *       así acompaña las curvas y las subidas como un tren de verdad.</li>
 * </ul>
 */
public class LocomotoraRenderer<T extends AbstractMinecart & VehiculoDeVia> extends EntityRenderer<T> {
    private static final double DOS_PI = Math.PI * 2.0;
    /** Luz de bloque y de cielo al máximo (LightTexture.FULL_BRIGHT). */
    private static final int BRILLO_TOTAL = 0xF000F0;

    private final DatosModelo datos;
    private final ModelPart raiz;
    private final ModelPart[] piezasAnimadas;
    private final ModelPart[] cuerpos;
    /** Escala para pasar de las unidades del modelo a bloques (ModelPart ya divide por 16). */
    private final float escala;
    /** Cuánta vía hace falta recorrer hacia adelante y hacia atrás para apoyar todos los bogies. */
    private final double viaAdelante;
    private final double viaAtras;
    /** Lo que brilla en la oscuridad, o null si el modelo no tiene luces. */
    @Nullable
    private final ResourceLocation texturaLuces;

    /** @param sombra radio de la sombra en el piso, en bloques */
    public LocomotoraRenderer(EntityRendererProvider.Context contexto, DatosModelo datos, float sombra) {
        super(contexto);
        this.datos = datos;
        this.shadowRadius = sombra;
        this.raiz = contexto.bakeLayer(datos.capa());
        datos.preparar().accept(this.raiz);
        this.escala = 16.0F / datos.unidades();

        List<DatosModelo.Animada> animadas = datos.animadas();
        this.piezasAnimadas = new ModelPart[animadas.size()];
        for (int i = 0; i < animadas.size(); i++) {
            DatosModelo.Animada a = animadas.get(i);
            this.piezasAnimadas[i] = a.grupo().isEmpty()
                    ? this.raiz.getChild(a.parte())
                    : this.raiz.getChild(a.grupo()).getChild(a.parte());
        }

        List<DatosModelo.Segmento> segmentos = datos.segmentos();
        this.cuerpos = new ModelPart[segmentos.size()];
        double adelante = 0.0;
        double atras = 0.0;
        for (int i = 0; i < segmentos.size(); i++) {
            DatosModelo.Segmento s = segmentos.get(i);
            this.cuerpos[i] = this.raiz.getChild(s.grupo());
            double delantero = -s.bogieDelantero() / datos.unidades();
            double espacio = (s.bogieTrasero() - s.bogieDelantero()) / datos.unidades();
            adelante = Math.max(adelante, delantero);
            // en una curva cerrada el bogie de atrás puede quedar bastante más lejos sobre la vía que en recta
            atras = Math.max(atras, espacio * 1.6 - delantero);
        }
        this.viaAdelante = adelante + 2.0;
        this.viaAtras = atras + 2.0;

        ResourceLocation t = datos.textura();
        ResourceLocation luces = ResourceLocation.fromNamespaceAndPath(t.getNamespace(),
                t.getPath().replace(".png", "_luces.png"));
        this.texturaLuces = contexto.getResourceManager().getResource(luces).isPresent() ? luces : null;
    }

    /** Primero el modelo con la luz del lugar; después, encima, sus luces sin sombra (brillan de noche). */
    private void pintar(ModelPart pieza, PoseStack pose, MultiBufferSource buffers, int luz, boolean luces) {
        if (luces) {
            pieza.render(pose, buffers.getBuffer(RenderType.entityTranslucentEmissive(this.texturaLuces)), BRILLO_TOTAL,
                    OverlayTexture.NO_OVERLAY);
        } else {
            pieza.render(pose, buffers.getBuffer(RenderType.entityCutout(this.datos.textura())), luz,
                    OverlayTexture.NO_OVERLAY);
        }
    }

    @Override
    public void render(T loco, float yawEntidad, float tickParcial, PoseStack pose,
                       MultiBufferSource buffers, int luz) {
        super.render(loco, yawEntidad, tickParcial, pose, buffers, luz);
        pose.pushPose();

        // Pequeño desplazamiento por entidad para que dos locomotoras juntas no parpadeen (como en vanilla)
        long semilla = (long) loco.getId() * 493286711L;
        semilla = semilla * semilla * 4392167121L + semilla * 98761L;
        float jx = (((float) (semilla >> 16 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
        float jy = (((float) (semilla >> 20 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
        float jz = (((float) (semilla >> 24 & 7L) + 0.5F) / 8.0F - 0.5F) * 0.004F;
        pose.translate(jx, jy, jz);

        double x = Mth.lerp(tickParcial, loco.xOld, loco.getX());
        double y = Mth.lerp(tickParcial, loco.yOld, loco.getY());
        double z = Mth.lerp(tickParcial, loco.zOld, loco.getZ());

        animar(loco.getRecorrido(tickParcial), loco.marchaCabina(), loco.velocidadCabina(tickParcial),
                loco.giroTorreta(tickParcial), loco.alzaTorreta(tickParcial));

        if (this.cuerpos.length == 0) {
            dibujarEntero(loco, tickParcial, pose, buffers, luz, x, y, z);
        } else {
            dibujarPorCuerpos(loco, tickParcial, pose, buffers, luz, x, y, z);
        }
        pose.popPose();
    }

    /** Modelo corto: gira entero alrededor del centro siguiendo el riel, como una vagoneta. */
    private void dibujarEntero(T loco, float tickParcial, PoseStack pose, MultiBufferSource buffers, int luz,
                               double x, double y, double z) {
        float rumbo = loco.getRumbo();
        double frenteX = Math.cos(Math.toRadians(rumbo));
        double frenteZ = Math.sin(Math.toRadians(rumbo));

        // Con este "yaw" el frente del modelo apunta hacia (-cos, -sin)
        float yaw = rumbo + 180.0F;
        float inclinacion = 0.0F;

        // Apoyado en el camino de la vía (en las vías del mod, el trazo dibujado: curvas redondas y rieles más altos)
        Via via = Via.alrededor(loco.level(), x, y, z, frenteX, frenteZ, 1.0, 1.0, loco);
        if (via.enVia()) {
            Vec3 centro = via.punto(0.0);
            Vec3 adelante = via.punto(0.3);
            Vec3 atras = via.punto(-0.3);
            pose.translate(centro.x - x, (adelante.y + atras.y) / 2.0 - y, centro.z - z);
            Vec3 direccion = atras.subtract(adelante);
            if (direccion.length() != 0.0) {
                direccion = direccion.normalize();
                // Si el riel nos dejaría mirando para atrás, se da vuelta el modelo
                if (-direccion.x * frenteX - direccion.z * frenteZ < 0.0) {
                    direccion = direccion.scale(-1.0);
                }
                yaw = (float) (Math.atan2(direccion.z, direccion.x) * 180.0 / Math.PI);
                inclinacion = (float) (Math.atan(direccion.y) * 73.0);
            }
        }

        pose.mulPose(Axis.YP.rotationDegrees(180.0F - yaw));
        pose.mulPose(Axis.ZP.rotationDegrees(-inclinacion));
        sacudir(loco, tickParcial, pose);
        pose.scale(-this.escala, -this.escala, this.escala);
        pintar(this.raiz, pose, buffers, luz, false);
        if (this.texturaLuces != null) {
            pintar(this.raiz, pose, buffers, luz, true);
        }
    }

    /**
     * Tren largo: cada cuerpo rígido se apoya en la vía por sus dos bogies. Los cuerpos articulados (la unidad
     * delantera de la Big Boy) cuelgan de una bisagra del cuerpo principal y giran hacia su bogie delantero.
     */
    private void dibujarPorCuerpos(T loco, float tickParcial, PoseStack pose, MultiBufferSource buffers,
                                   int luz, double x, double y, double z) {
        double fx = loco.frenteX();
        double fz = loco.frenteZ();
        Via via = Via.alrededor(loco.level(), x, y, z, fx, fz, this.viaAtras, this.viaAdelante, loco);
        double unidades = this.datos.unidades();
        List<DatosModelo.Segmento> segmentos = this.datos.segmentos();
        int n = this.cuerpos.length;
        Vec3[] origenes = new Vec3[n];
        Vec3[] direcciones = new Vec3[n];

        // Primero los cuerpos apoyados en sus dos bogies
        for (int i = 0; i < n; i++) {
            DatosModelo.Segmento s = segmentos.get(i);
            if (s.articuladoA() >= 0) {
                continue;
            }
            double delantero = -s.bogieDelantero() / unidades;
            double espacio = (s.bogieTrasero() - s.bogieDelantero()) / unidades;
            Vec3 bogieA = via.punto(delantero);
            Vec3 bogieB = via.punto(via.atrasPorCuerda(delantero, espacio));
            Vec3 d = bogieA.subtract(bogieB);
            d = d.lengthSqr() < 1.0E-8 ? new Vec3(fx, 0.0, fz) : d.normalize();
            direcciones[i] = d;
            // Dónde queda el X = 0 del modelo
            origenes[i] = bogieA.add(d.scale(s.bogieDelantero() / unidades));
        }
        // Después los articulados: cuelgan de la bisagra y apuntan a su bogie delantero (con el giro limitado)
        for (int i = 0; i < n; i++) {
            DatosModelo.Segmento s = segmentos.get(i);
            int p = s.articuladoA();
            if (p < 0 || direcciones[p] == null) {
                continue;
            }
            Vec3 dp = direcciones[p];
            Vec3 bisagra = origenes[p].subtract(dp.scale(s.bisagra() / unidades));
            Vec3 objetivo = via.punto(-s.bogieDelantero() / unidades).subtract(bisagra);
            if (objetivo.lengthSqr() < 1.0E-8) {
                objetivo = dp;
            }
            double rumboPadre = Math.toDegrees(Math.atan2(dp.z, dp.x));
            double giro = Mth.wrapDegrees(Math.toDegrees(Math.atan2(objetivo.z, objetivo.x)) - rumboPadre);
            giro = Mth.clamp(giro, -s.giroMaximo(), s.giroMaximo());
            double rumbo = Math.toRadians(rumboPadre + giro);
            double pendiente = Math.atan2(objetivo.y, Math.sqrt(objetivo.x * objetivo.x + objetivo.z * objetivo.z));
            Vec3 d = new Vec3(Math.cos(rumbo) * Math.cos(pendiente), Math.sin(pendiente),
                    Math.sin(rumbo) * Math.cos(pendiente));
            direcciones[i] = d;
            origenes[i] = bisagra.add(d.scale(s.bisagra() / unidades));
        }

        // primero todos los cuerpos y después sus luces (cada pasada usa su propio buffer)
        for (int pasada = 0; pasada < (this.texturaLuces != null ? 2 : 1); pasada++) {
            for (int i = 0; i < n; i++) {
                if (direcciones[i] == null) {
                    continue;
                }
                Vec3 d = direcciones[i];
                Vec3 origen = origenes[i];
                float rumbo = (float) Math.toDegrees(Math.atan2(d.z, d.x));
                float pendiente = (float) Math.toDegrees(Math.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)));
                pose.pushPose();
                pose.translate(origen.x - x, origen.y - y, origen.z - z);
                pose.mulPose(Axis.YP.rotationDegrees(-rumbo));
                pose.mulPose(Axis.ZP.rotationDegrees(pendiente));
                sacudir(loco, tickParcial, pose);
                pose.scale(-this.escala, -this.escala, this.escala);
                pintar(this.cuerpos[i], pose, buffers, luz, pasada == 1);
                pose.popPose();
            }
        }
    }

    /** Sacudón cuando le pegan. */
    private static void sacudir(AbstractMinecart loco, float tickParcial, PoseStack pose) {
        float golpe = (float) loco.getHurtTime() - tickParcial;
        float dano = loco.getDamage() - tickParcial;
        if (dano < 0.0F) {
            dano = 0.0F;
        }
        if (golpe > 0.0F) {
            pose.mulPose(Axis.XP.rotationDegrees(Mth.sin(golpe) * golpe * dano / 10.0F * (float) loco.getHurtDir()));
        }
    }

    /**
     * Gira las ruedas y mueve las bielas (misma matemática que el estudio de diseño); en la cabina, la palanca sigue a
     * la marcha y la aguja del velocímetro a la velocidad. Las torretas del tren artillero giran hacia el blanco
     * ({@code giro}, positivo hacia la derecha) y sus cañones suben ({@code alza}).
     */
    private void animar(double recorrido, int marcha, float velocidad, float giro, float alza) {
        List<DatosModelo.Animada> animadas = this.datos.animadas();
        double unidades = this.datos.unidades();
        for (int i = 0; i < animadas.size(); i++) {
            DatosModelo.Animada a = animadas.get(i);
            ModelPart pieza = this.piezasAnimadas[i];
            double vueltas = (recorrido * unidades / a.radio()) % DOS_PI;
            float theta = (float) -vueltas + a.fase();
            float m = a.manivela();
            switch (a.tipo()) {
                case DatosModelo.RUEDA -> pieza.zRot = a.rotZ() + theta;
                case DatosModelo.BIELA, DatosModelo.BIELA_MOTRIZ -> {
                    float dx = m * Mth.sin(theta);
                    float dy = m * (1.0F - Mth.cos(theta));
                    pieza.x = a.x() + dx;
                    pieza.y = a.y() + dy;
                    if (a.tipo() == DatosModelo.BIELA_MOTRIZ) {
                        pieza.zRot = (float) Math.asin(Mth.clamp(dy / a.largo(), -1.0F, 1.0F));
                    }
                }
                case DatosModelo.MOTRIZ -> {
                    // Del perno de la manivela a la cruceta, que corre derecha a la altura del eje
                    float largo = Math.abs(a.largo());
                    float signo = a.largo() < 0.0F ? -1.0F : 1.0F;
                    float h = m * Mth.cos(theta);
                    pieza.x = a.x() + m * Mth.sin(theta);
                    pieza.y = a.y() + m * (1.0F - Mth.cos(theta));
                    pieza.zRot = a.rotZ() + signo * (float) Math.asin(Mth.clamp(h / largo, -1.0F, 1.0F));
                }
                case DatosModelo.CRUCETA -> {
                    float largo = Math.abs(a.largo());
                    float signo = a.largo() < 0.0F ? -1.0F : 1.0F;
                    float h = m * Mth.cos(theta);
                    pieza.x = a.x() + m * Mth.sin(theta)
                            + signo * (Mth.sqrt(largo * largo - h * h) - Mth.sqrt(largo * largo - m * m));
                    pieza.y = a.y();
                }
                case DatosModelo.CRUCETA_INCLINADA -> {
                    // corre por la línea del cilindro (en el modelo la Y va hacia abajo)
                    double ds = distanciaCruceta(m, a.largo(), a.angulo(), theta) - distanciaCruceta(m, a.largo(), a.angulo(), 0.0);
                    pieza.x = a.x() + (float) (ds * Math.cos(a.angulo()));
                    pieza.y = a.y() - (float) (ds * Math.sin(a.angulo()));
                }
                case DatosModelo.MOTRIZ_INCLINADA -> {
                    // el perno sigue a la manivela y la biela gira para apuntar a la cruceta
                    pieza.x = a.x() + m * Mth.sin(theta);
                    pieza.y = a.y() + m * (1.0F - Mth.cos(theta));
                    pieza.zRot = a.rotZ() - (float) (anguloBiela(m, a.largo(), a.angulo(), theta)
                            - anguloBiela(m, a.largo(), a.angulo(), 0.0));
                }
                // Shay: árboles y cigüeñal giran a lo largo de su propio eje (en los tramos inclinados el giro en X
                // va antes que la inclinación, así que siguen girando sobre sí mismos)
                case DatosModelo.EJE_X -> pieza.xRot = a.rotX() + theta;
                case DatosModelo.MOTRIZ_X -> {
                    // el muñón da vueltas alrededor de X y la biela se inclina para llegar a la cruceta vertical
                    float lateral = m * Mth.sin(theta);
                    pieza.y = a.y() + m * (1.0F - Mth.cos(theta));
                    pieza.z = a.z() - lateral;
                    pieza.xRot = a.rotX() - (float) Math.asin(Mth.clamp(lateral / a.largo(), -1.0F, 1.0F));
                }
                case DatosModelo.PALANCA -> pieza.zRot = a.rotZ() + a.angulo() * marcha;
                case DatosModelo.AGUJA -> pieza.xRot = a.rotX() + a.angulo() * velocidad;
                // la torreta gira alrededor de su eje vertical; el cañón gira con ella y sube (girando en X antes que
                // en Y, porque el caño está armado a lo largo de -Z)
                case DatosModelo.TORRETA -> pieza.yRot = a.rotY() + giro;
                case DatosModelo.CANON -> {
                    pieza.yRot = a.rotY() + giro;
                    pieza.xRot = a.rotX() - alza;
                }
                default -> {
                }
            }
        }
    }

    /** Distancia del eje motriz a la cruceta, sobre la línea de un cilindro inclinado (unidades del modelo). */
    private static double distanciaCruceta(double manivela, double largo, double angulo, double theta) {
        double px = manivela * Math.sin(theta);
        double py = manivela * Math.cos(theta);
        double up = px * Math.cos(angulo) + py * Math.sin(angulo);
        return up + Math.sqrt(Math.max(0.0, up * up - manivela * manivela + largo * largo));
    }

    /** Ángulo (en el diseño, Y hacia arriba) de la biela que va del perno de la manivela a la cruceta inclinada. */
    private static double anguloBiela(double manivela, double largo, double angulo, double theta) {
        double s = distanciaCruceta(manivela, largo, angulo, theta);
        double px = manivela * Math.sin(theta);
        double py = manivela * Math.cos(theta);
        return Math.atan2(s * Math.sin(angulo) - py, s * Math.cos(angulo) - px);
    }

    @Override
    public ResourceLocation getTextureLocation(T loco) {
        return this.datos.textura();
    }
}
