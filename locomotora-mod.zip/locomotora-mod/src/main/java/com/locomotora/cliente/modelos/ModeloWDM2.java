package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Indian WDM-2" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloWDM2 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("wdm2"), "main"),
            LocomotoraMod.id("textures/entity/wdm2.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 1.0471975511965976F, "cuerpo")),
            ModeloWDM2::crearCapa,
            16.0F,
            ModeloWDM2::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -46.0F, 50.0F)));

    private ModeloWDM2() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(466, 98).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-60.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(476, 98).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i2_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(486, 98).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-32.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i2_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i2_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 98).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-60.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 98).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d2_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(516, 98).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-32.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d2_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d2_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(26, 98).addBox(-66.5F, -9.0F, 7.0F, 41.0F, 6.0F, 1.0F).texOffs(110, 98).addBox(-66.5F, -9.0F, -8.0F, 41.0F, 6.0F, 1.0F).texOffs(526, 98).addBox(-62.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(536, 98).addBox(-62.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(546, 98).addBox(-48.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(556, 98).addBox(-48.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(566, 98).addBox(-34.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(576, 98).addBox(-34.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(586, 98).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(36.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(596, 98).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(50.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i2_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(606, 98).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(64.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i2_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i2_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(616, 98).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(36.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(626, 98).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(50.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d2_0", CubeListBuilder.create().texOffs(264, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(394, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(636, 98).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(64.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d2_1", CubeListBuilder.create().texOffs(418, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(682, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d2_2", CubeListBuilder.create().texOffs(442, 98).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(692, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(194, 98).addBox(29.5F, -9.0F, 7.0F, 41.0F, 6.0F, 1.0F).texOffs(278, 98).addBox(29.5F, -9.0F, -8.0F, 41.0F, 6.0F, 1.0F).texOffs(646, 98).addBox(34.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(656, 98).addBox(34.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(666, 98).addBox(48.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(676, 98).addBox(48.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(686, 98).addBox(62.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(696, 98).addBox(62.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(0, 50).addBox(-82.0F, -15.0F, -13.5F, 164.0F, 4.0F, 27.0F).texOffs(558, 50).addBox(-26.0F, -11.0F, -10.0F, 54.0F, 7.0F, 20.0F).texOffs(362, 98).addBox(-87.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(454, 50).addBox(-82.0F, -11.0F, -12.0F, 2.0F, 6.0F, 24.0F).texOffs(378, 98).addBox(82.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(506, 50).addBox(80.0F, -11.0F, -12.0F, 2.0F, 6.0F, 24.0F).texOffs(0, 110).addBox(-74.0F, -25.0F, 12.5F, 150.0F, 1.0F, 1.0F).texOffs(302, 110).addBox(-74.0F, -25.0F, -13.5F, 150.0F, 1.0F, 1.0F).texOffs(894, 81).addBox(-74.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(898, 81).addBox(-74.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(902, 81).addBox(-58.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(906, 81).addBox(-58.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(910, 81).addBox(-36.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(914, 81).addBox(-36.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(918, 81).addBox(-6.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(922, 81).addBox(-6.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(926, 81).addBox(24.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(930, 81).addBox(24.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(934, 81).addBox(54.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(938, 81).addBox(54.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(942, 81).addBox(75.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(946, 81).addBox(75.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_corto", CubeListBuilder.create().texOffs(382, 50).addBox(-76.0F, -28.0F, -9.0F, 18.0F, 13.0F, 18.0F).texOffs(100, 81).addBox(-76.0F, -30.0F, -7.0F, 18.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_corto_cantoi_0", CubeListBuilder.create().texOffs(0, 116).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -28.309016994374943F, -8.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_1", CubeListBuilder.create().texOffs(38, 116).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -28.89680224666742F, -8.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_2", CubeListBuilder.create().texOffs(76, 116).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.39680224666742F, -8.39680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_3", CubeListBuilder.create().texOffs(114, 116).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.7600735106701F, -7.89680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_4", CubeListBuilder.create().texOffs(152, 116).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.951056516295154F, -7.3090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_0", CubeListBuilder.create().texOffs(190, 116).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -28.309016994374943F, 8.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_1", CubeListBuilder.create().texOffs(228, 116).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -28.89680224666742F, 8.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_2", CubeListBuilder.create().texOffs(266, 116).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.39680224666742F, 8.39680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_3", CubeListBuilder.create().texOffs(304, 116).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.7600735106701F, 7.89680224666742F, 2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_4", CubeListBuilder.create().texOffs(342, 116).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.951056516295154F, 7.3090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_tapaa", CubeListBuilder.create().texOffs(430, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 36.0F), PartPose.offset(-76.0F, -28.0F, -9.0F));
        g.addOrReplaceChild("capo_corto_tapab", CubeListBuilder.create().texOffs(504, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 36.0F), PartPose.offset(-59.0F, -28.0F, -9.0F));
        g.addOrReplaceChild("faro_0", CubeListBuilder.create().texOffs(378, 106).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(288, 81).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -27.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_1", CubeListBuilder.create().texOffs(402, 106).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(312, 81).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -27.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_2", CubeListBuilder.create().texOffs(426, 106).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(336, 81).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -27.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_3", CubeListBuilder.create().texOffs(450, 106).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(360, 81).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -27.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_vidrio", CubeListBuilder.create().texOffs(164, 81).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(-77.11999999999999F, -27.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol4_0", CubeListBuilder.create().texOffs(474, 106).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(384, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, -6.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol4_1", CubeListBuilder.create().texOffs(498, 106).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(408, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, -6.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol4_2", CubeListBuilder.create().texOffs(522, 106).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(432, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, -6.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol4_3", CubeListBuilder.create().texOffs(546, 106).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(456, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, -6.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol4_vidrio", CubeListBuilder.create().texOffs(950, 81).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-82.82F, -13.0F, -6.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol16_0", CubeListBuilder.create().texOffs(570, 106).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(480, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, 6.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol16_1", CubeListBuilder.create().texOffs(594, 106).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(504, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, 6.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol16_2", CubeListBuilder.create().texOffs(618, 106).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(528, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, 6.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol16_3", CubeListBuilder.create().texOffs(642, 106).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(552, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, 6.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol16_vidrio", CubeListBuilder.create().texOffs(982, 81).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-82.82F, -13.0F, 6.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(180, 0).addBox(-58.0F, -36.0F, -12.5F, 22.0F, 21.0F, 25.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(706, 98).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -36.474303044731364F, -11.969129132661568F, -2.7449193305117365F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(760, 98).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -37.26251298128502F, -9.878951265713418F, -2.8170417528895673F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(814, 98).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -37.898055777842494F, -7.737408883852685F, -2.889164175267397F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(868, 98).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.3776269998972F, -5.555636699929993F, -2.961286597645222F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(922, 98).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.69873316990032F, -3.344978597204074F, -3.0334090200230497F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(0, 106).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.85970473182168F, -1.1169286480749165F, -3.10553144240088F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(54, 106).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.85970473182168F, 1.116928648074915F, 3.1055314424008795F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(108, 106).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.69873316990032F, 3.3449785972040713F, 3.0334090200230497F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(162, 106).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.3776269998972F, 5.555636699929992F, 2.961286597645222F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(216, 106).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -37.898055777842494F, 7.737408883852684F, 2.8891641752673967F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(270, 106).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -37.26251298128502F, 9.878951265713415F, 2.8170417528895673F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(324, 106).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -36.474303044731364F, 11.969129132661568F, 2.744919330511737F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo", CubeListBuilder.create().texOffs(666, 0).addBox(-36.0F, -31.0F, -9.5F, 92.0F, 16.0F, 19.0F).texOffs(782, 50).addBox(-36.0F, -33.0F, -7.5F, 92.0F, 2.0F, 15.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_largo_cantoi_0", CubeListBuilder.create().texOffs(604, 110).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -31.309016994374943F, -9.451056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_1", CubeListBuilder.create().texOffs(790, 110).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -31.89680224666742F, -9.2600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_2", CubeListBuilder.create().texOffs(0, 112).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.39680224666742F, -8.89680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_3", CubeListBuilder.create().texOffs(186, 112).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.7600735106701F, -8.39680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_4", CubeListBuilder.create().texOffs(372, 112).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.951056516295154F, -7.8090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_0", CubeListBuilder.create().texOffs(558, 112).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -31.309016994374943F, 9.451056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_1", CubeListBuilder.create().texOffs(744, 112).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -31.89680224666742F, 9.2600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_2", CubeListBuilder.create().texOffs(0, 114).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.39680224666742F, 8.89680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_3", CubeListBuilder.create().texOffs(186, 114).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.7600735106701F, 8.39680224666742F, 2.670353755551322F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("capo_largo_cantod_4", CubeListBuilder.create().texOffs(372, 114).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.951056516295154F, 7.8090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_tapaa", CubeListBuilder.create().texOffs(274, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(-36.0F, -31.0F, -9.5F));
        g.addOrReplaceChild("capo_largo_tapab", CubeListBuilder.create().texOffs(352, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(55.0F, -31.0F, -9.5F));
        g.addOrReplaceChild("radiador", CubeListBuilder.create().texOffs(578, 0).addBox(56.0F, -32.0F, -11.0F, 22.0F, 17.0F, 22.0F).texOffs(706, 50).addBox(56.0F, -35.0F, -8.0F, 22.0F, 3.0F, 16.0F), PartPose.ZERO);
        g.addOrReplaceChild("radiador_cantoi_0", CubeListBuilder.create().texOffs(558, 114).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -32.46352549156242F, -10.92658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_1", CubeListBuilder.create().texOffs(604, 114).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -33.34520337000113F, -10.640110266005152F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_2", CubeListBuilder.create().texOffs(650, 114).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.09520337000113F, -10.095203370001132F, -2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_3", CubeListBuilder.create().texOffs(696, 114).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.64011026600515F, -9.345203370001132F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_4", CubeListBuilder.create().texOffs(742, 114).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.92658477444273F, -8.463525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_0", CubeListBuilder.create().texOffs(788, 114).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -32.46352549156242F, 10.92658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_1", CubeListBuilder.create().texOffs(834, 114).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -33.34520337000113F, 10.640110266005152F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_2", CubeListBuilder.create().texOffs(880, 114).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.09520337000113F, 10.095203370001132F, 2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_3", CubeListBuilder.create().texOffs(926, 114).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.64011026600515F, 9.345203370001132F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_4", CubeListBuilder.create().texOffs(972, 114).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.92658477444273F, 8.463525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 44.0F), PartPose.offset(56.0F, -32.0F, -11.0F));
        g.addOrReplaceChild("radiador_tapab", CubeListBuilder.create().texOffs(90, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 44.0F), PartPose.offset(77.0F, -32.0F, -11.0F));
        g.addOrReplaceChild("ventilador61_0", CubeListBuilder.create().texOffs(762, 106).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(702, 81).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(61.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador61_1", CubeListBuilder.create().texOffs(786, 106).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(726, 81).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(61.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador61_2", CubeListBuilder.create().texOffs(810, 106).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(750, 81).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(61.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador61_3", CubeListBuilder.create().texOffs(834, 106).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(774, 81).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(61.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador73_0", CubeListBuilder.create().texOffs(858, 106).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(798, 81).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(73.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador73_1", CubeListBuilder.create().texOffs(882, 106).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(822, 81).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(73.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador73_2", CubeListBuilder.create().texOffs(906, 106).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(846, 81).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(73.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador73_3", CubeListBuilder.create().texOffs(930, 106).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(870, 81).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(73.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("faro_t_0", CubeListBuilder.create().texOffs(666, 106).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(576, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(78.3F, -30.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_1", CubeListBuilder.create().texOffs(690, 106).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(600, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(78.3F, -30.0F, 0.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_2", CubeListBuilder.create().texOffs(714, 106).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(624, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(78.3F, -30.0F, 0.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_3", CubeListBuilder.create().texOffs(738, 106).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(648, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(78.3F, -30.0F, 0.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_vidrio", CubeListBuilder.create().texOffs(216, 81).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(78.92F, -30.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escape", CubeListBuilder.create().texOffs(0, 98).addBox(-8.0F, -36.0F, -2.5F, 8.0F, 3.0F, 5.0F), PartPose.ZERO);
        g.addOrReplaceChild("bocina_0", CubeListBuilder.create().texOffs(64, 81).addBox(-54.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(0, 81).addBox(-54.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -38.5F, 0.0F));
        g.addOrReplaceChild("bocina_1", CubeListBuilder.create().texOffs(82, 81).addBox(-54.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(32, 81).addBox(-54.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -38.5F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "capo_corto_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_corto_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_corto_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_corto_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_corto_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_corto_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_corto_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_corto_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_corto_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_corto_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_0", 0.31385128972903376F, 0.7F, 0.31385128972903376F);
        escalar(g0, "faro_1", 0.31385128972903376F, 0.7F, 0.31385128972903376F);
        escalar(g0, "faro_2", 0.31385128972903376F, 0.7F, 0.31385128972903376F);
        escalar(g0, "faro_3", 0.31385128972903376F, 0.7F, 0.31385128972903376F);
        escalar(g0, "faro_vidrio", 0.24615384615384617F, 0.15F, 0.24615384615384617F);
        escalar(g0, "farol4_0", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol4_1", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol4_2", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol4_3", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol4_vidrio", 0.225F, 0.15F, 0.225F);
        escalar(g0, "farol16_0", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol16_1", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol16_2", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol16_3", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol16_vidrio", 0.225F, 0.15F, 0.225F);
        escalar(g0, "cabina_techo_0", 1.0008333333333332F, 1.0F, 0.751770183271507F);
        escalar(g0, "cabina_techo_1", 1.0008333333333332F, 1.0F, 0.7517701832715061F);
        escalar(g0, "cabina_techo_2", 1.0008333333333332F, 1.0F, 0.7517701832715066F);
        escalar(g0, "cabina_techo_3", 1.0008333333333332F, 1.0F, 0.7517701832715064F);
        escalar(g0, "cabina_techo_4", 1.0008333333333332F, 1.0F, 0.7517701832715066F);
        escalar(g0, "cabina_techo_5", 1.0008333333333332F, 1.0F, 0.7517701832715069F);
        escalar(g0, "cabina_techo_6", 1.0008333333333332F, 1.0F, 0.7517701832715059F);
        escalar(g0, "cabina_techo_7", 1.0008333333333332F, 1.0F, 0.7517701832715069F);
        escalar(g0, "cabina_techo_8", 1.0008333333333332F, 1.0F, 0.7517701832715069F);
        escalar(g0, "cabina_techo_9", 1.0008333333333332F, 1.0F, 0.7517701832715056F);
        escalar(g0, "cabina_techo_10", 1.0008333333333332F, 1.0F, 0.7517701832715068F);
        escalar(g0, "cabina_techo_11", 1.0008333333333332F, 1.0F, 0.7517701832715075F);
        escalar(g0, "capo_largo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_largo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_largo_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_largo_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_largo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_largo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_largo_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_largo_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_largo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_largo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "radiador_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_cantoi_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g0, "radiador_cantoi_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "radiador_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "radiador_cantoi_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_cantod_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g0, "radiador_cantod_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "radiador_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "radiador_cantod_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "radiador_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "ventilador61_0", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador61_1", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador61_2", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador61_3", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador73_0", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador73_1", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador73_2", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador73_3", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "faro_t_0", 0.2746198785129045F, 0.6F, 0.2746198785129045F);
        escalar(g0, "faro_t_1", 0.2746198785129045F, 0.6F, 0.2746198785129045F);
        escalar(g0, "faro_t_2", 0.2746198785129045F, 0.6F, 0.2746198785129045F);
        escalar(g0, "faro_t_3", 0.2746198785129045F, 0.6F, 0.2746198785129045F);
        escalar(g0, "faro_t_vidrio", 0.2333333333333333F, 0.15F, 0.2333333333333333F);
        escalar(g0, "bocina_0", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
        escalar(g0, "bocina_1", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
    }
}
