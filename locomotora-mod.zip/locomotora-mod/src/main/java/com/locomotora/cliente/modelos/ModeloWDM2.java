package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Indian WDM-2" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloWDM2 {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("wdm2"), "main"),
            LocomotoraMod.id("textures/entity/wdm2.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -60.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -46.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, -32.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 36.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 50.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 64.0F, -5.0F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, -54.28F, -28.5F, 0.0F, "cuerpo", 4.8F, -6.5F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.15F, 0.0F, -54.0F, -27.0F, 0.15F, "cuerpo", -0.24F, -3.5F, 0.0F)),
            ModeloWDM2::crearCapa,
            16.0F,
            ModeloWDM2::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -46.0F, 50.0F)));

    private ModeloWDM2() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(908, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-60.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(918, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i2_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(928, 100).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-32.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0i2_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i2_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-60.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-60.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(948, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d2_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(958, 100).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-32.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie0d2_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d2_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-32.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(468, 100).addBox(-66.5F, -9.0F, 7.0F, 41.0F, 6.0F, 1.0F).texOffs(552, 100).addBox(-66.5F, -9.0F, -8.0F, 41.0F, 6.0F, 1.0F).texOffs(968, 100).addBox(-62.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(978, 100).addBox(-62.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(988, 100).addBox(-48.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(998, 100).addBox(-48.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(1008, 100).addBox(-34.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(0, 112).addBox(-34.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 112).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(36.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(20, 112).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(50.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i2_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 112).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(64.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1i2_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i2_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 112).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(36.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(36.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 112).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(50.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(50.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d2_0", CubeListBuilder.create().texOffs(602, 81).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(836, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 81).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 112).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(64.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("bogie1d2_1", CubeListBuilder.create().texOffs(860, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d2_2", CubeListBuilder.create().texOffs(884, 100).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 100).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(64.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(636, 100).addBox(29.5F, -9.0F, 7.0F, 41.0F, 6.0F, 1.0F).texOffs(720, 100).addBox(29.5F, -9.0F, -8.0F, 41.0F, 6.0F, 1.0F).texOffs(70, 112).addBox(34.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(80, 112).addBox(34.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(90, 112).addBox(48.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(100, 112).addBox(48.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(110, 112).addBox(62.0F, -7.0F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(120, 112).addBox(62.0F, -7.0F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(0, 50).addBox(-82.0F, -15.0F, -13.5F, 164.0F, 4.0F, 27.0F).texOffs(558, 50).addBox(-26.0F, -11.0F, -10.0F, 54.0F, 7.0F, 20.0F).texOffs(804, 100).addBox(-87.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(454, 50).addBox(-82.0F, -11.0F, -12.0F, 2.0F, 6.0F, 24.0F).texOffs(820, 100).addBox(82.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(506, 50).addBox(80.0F, -11.0F, -12.0F, 2.0F, 6.0F, 24.0F).texOffs(372, 117).addBox(-74.0F, -25.0F, 12.5F, 150.0F, 1.0F, 1.0F).texOffs(674, 117).addBox(-74.0F, -25.0F, -13.5F, 150.0F, 1.0F, 1.0F).texOffs(322, 100).addBox(-74.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(326, 100).addBox(-74.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(330, 100).addBox(-58.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(334, 100).addBox(-58.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(338, 100).addBox(-36.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(342, 100).addBox(-36.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(346, 100).addBox(-6.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(350, 100).addBox(-6.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(354, 100).addBox(24.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(358, 100).addBox(24.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(362, 100).addBox(54.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(366, 100).addBox(54.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F).texOffs(370, 100).addBox(75.0F, -24.0F, 12.5F, 1.0F, 9.0F, 1.0F).texOffs(374, 100).addBox(75.0F, -24.0F, -13.5F, 1.0F, 9.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_corto", CubeListBuilder.create().texOffs(382, 50).addBox(-76.0F, -28.0F, -9.0F, 18.0F, 13.0F, 18.0F).texOffs(390, 81).addBox(-76.0F, -30.0F, -7.0F, 18.0F, 2.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_corto_cantoi_0", CubeListBuilder.create().texOffs(368, 125).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -28.309016994374943F, -8.951056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_1", CubeListBuilder.create().texOffs(406, 125).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -28.89680224666742F, -8.7600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_2", CubeListBuilder.create().texOffs(444, 125).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.39680224666742F, -8.39680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_3", CubeListBuilder.create().texOffs(482, 125).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.7600735106701F, -7.89680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantoi_4", CubeListBuilder.create().texOffs(520, 125).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.951056516295154F, -7.3090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_0", CubeListBuilder.create().texOffs(558, 125).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -28.309016994374943F, 8.951056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_1", CubeListBuilder.create().texOffs(596, 125).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -28.89680224666742F, 8.7600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_2", CubeListBuilder.create().texOffs(634, 125).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.39680224666742F, 8.39680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_3", CubeListBuilder.create().texOffs(672, 125).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.7600735106701F, 7.89680224666742F, 2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_cantod_4", CubeListBuilder.create().texOffs(710, 125).addBox(-9.0F, -1.0F, -0.5F, 18.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-67.0F, -29.951056516295154F, 7.3090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_corto_tapaa", CubeListBuilder.create().texOffs(522, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 36.0F), PartPose.offset(-76.0F, -28.0F, -9.0F));
        g.addOrReplaceChild("capo_corto_tapab", CubeListBuilder.create().texOffs(596, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 36.0F), PartPose.offset(-59.0F, -28.0F, -9.0F));
        g.addOrReplaceChild("faro_0", CubeListBuilder.create().texOffs(786, 112).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(626, 81).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -27.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_1", CubeListBuilder.create().texOffs(810, 112).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(650, 81).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -27.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_2", CubeListBuilder.create().texOffs(834, 112).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(674, 81).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -27.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_3", CubeListBuilder.create().texOffs(858, 112).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(698, 81).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-76.3F, -27.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_vidrio", CubeListBuilder.create().texOffs(454, 81).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(-77.11999999999999F, -27.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol4_0", CubeListBuilder.create().texOffs(882, 112).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(722, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, -6.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol4_1", CubeListBuilder.create().texOffs(906, 112).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(746, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, -6.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol4_2", CubeListBuilder.create().texOffs(930, 112).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(770, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, -6.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol4_3", CubeListBuilder.create().texOffs(954, 112).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(794, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, -6.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol4_vidrio", CubeListBuilder.create().texOffs(378, 100).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-82.82F, -13.0F, -6.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol16_0", CubeListBuilder.create().texOffs(978, 112).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(818, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, 6.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol16_1", CubeListBuilder.create().texOffs(0, 117).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(842, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, 6.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol16_2", CubeListBuilder.create().texOffs(24, 117).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(866, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, 6.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol16_3", CubeListBuilder.create().texOffs(48, 117).addBox(-5.0F, -1.0909090909090908F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(890, 81).addBox(-1.0F, -1.0909090909090908F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-82.3F, -13.0F, 6.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol16_vidrio", CubeListBuilder.create().texOffs(410, 100).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-82.82F, -13.0F, 6.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(180, 0).addBox(-58.0F, -36.0F, -12.5F, 22.0F, 21.0F, 25.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(138, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -36.474303044731364F, -11.969129132661568F, -2.7449193305117365F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(192, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -37.26251298128502F, -9.878951265713418F, -2.8170417528895673F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(246, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -37.898055777842494F, -7.737408883852685F, -2.889164175267397F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(300, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.3776269998972F, -5.555636699929993F, -2.961286597645222F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(354, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.69873316990032F, -3.344978597204074F, -3.0334090200230497F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(408, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.85970473182168F, -1.1169286480749165F, -3.10553144240088F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(462, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.85970473182168F, 1.116928648074915F, 3.1055314424008795F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(516, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.69873316990032F, 3.3449785972040713F, 3.0334090200230497F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(570, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -38.3776269998972F, 5.555636699929992F, 2.961286597645222F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(624, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -37.898055777842494F, 7.737408883852684F, 2.8891641752673967F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(678, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -37.26251298128502F, 9.878951265713415F, 2.8170417528895673F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(732, 112).addBox(-12.0F, -1.0F, -1.5F, 24.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-47.0F, -36.474303044731364F, 11.969129132661568F, 2.744919330511737F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo", CubeListBuilder.create().texOffs(758, 0).addBox(-36.0F, -31.0F, -9.5F, 92.0F, 16.0F, 19.0F).texOffs(76, 81).addBox(-36.0F, -33.0F, -7.5F, 92.0F, 2.0F, 15.0F), PartPose.ZERO);
        g.addOrReplaceChild("capo_largo_cantoi_0", CubeListBuilder.create().texOffs(0, 121).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -31.309016994374943F, -9.451056516295154F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_1", CubeListBuilder.create().texOffs(186, 121).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -31.89680224666742F, -9.2600735106701F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_2", CubeListBuilder.create().texOffs(372, 121).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.39680224666742F, -8.89680224666742F, -2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_3", CubeListBuilder.create().texOffs(558, 121).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.7600735106701F, -8.39680224666742F, -2.670353755551322F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantoi_4", CubeListBuilder.create().texOffs(744, 121).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.951056516295154F, -7.8090169943749475F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_0", CubeListBuilder.create().texOffs(0, 123).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -31.309016994374943F, 9.451056516295154F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_1", CubeListBuilder.create().texOffs(186, 123).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -31.89680224666742F, 9.2600735106701F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_2", CubeListBuilder.create().texOffs(372, 123).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.39680224666742F, 8.89680224666742F, 2.356194490192347F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_cantod_3", CubeListBuilder.create().texOffs(558, 123).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.7600735106701F, 8.39680224666742F, 2.670353755551322F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("capo_largo_cantod_4", CubeListBuilder.create().texOffs(744, 123).addBox(-46.0F, -1.0F, -0.5F, 92.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.0F, -32.951056516295154F, 7.8090169943749475F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capo_largo_tapaa", CubeListBuilder.create().texOffs(274, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(-36.0F, -31.0F, -9.5F));
        g.addOrReplaceChild("capo_largo_tapab", CubeListBuilder.create().texOffs(352, 0).addBox(0.0F, -4.0F, 0.0F, 1.0F, 4.0F, 38.0F), PartPose.offset(55.0F, -31.0F, -9.5F));
        g.addOrReplaceChild("radiador", CubeListBuilder.create().texOffs(670, 0).addBox(56.0F, -32.0F, -11.0F, 22.0F, 17.0F, 22.0F).texOffs(0, 81).addBox(56.0F, -35.0F, -8.0F, 22.0F, 3.0F, 16.0F), PartPose.ZERO);
        g.addOrReplaceChild("radiador_cantoi_0", CubeListBuilder.create().texOffs(930, 123).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -32.46352549156242F, -10.92658477444273F, -1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_1", CubeListBuilder.create().texOffs(976, 123).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -33.34520337000113F, -10.640110266005152F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_2", CubeListBuilder.create().texOffs(0, 125).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.09520337000113F, -10.095203370001132F, -2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_3", CubeListBuilder.create().texOffs(46, 125).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.64011026600515F, -9.345203370001132F, -2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantoi_4", CubeListBuilder.create().texOffs(92, 125).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.92658477444273F, -8.463525491562422F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_0", CubeListBuilder.create().texOffs(138, 125).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -32.46352549156242F, 10.92658477444273F, 1.727875959474386F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_1", CubeListBuilder.create().texOffs(184, 125).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -33.34520337000113F, 10.640110266005152F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_2", CubeListBuilder.create().texOffs(230, 125).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.09520337000113F, 10.095203370001132F, 2.356194490192342F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_3", CubeListBuilder.create().texOffs(276, 125).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.64011026600515F, 9.345203370001132F, 2.6703537555513246F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_cantod_4", CubeListBuilder.create().texOffs(322, 125).addBox(-11.0F, -1.0F, -0.5F, 22.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(67.0F, -34.92658477444273F, 8.463525491562422F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("radiador_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 44.0F), PartPose.offset(56.0F, -32.0F, -11.0F));
        g.addOrReplaceChild("radiador_tapab", CubeListBuilder.create().texOffs(90, 0).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 44.0F), PartPose.offset(77.0F, -32.0F, -11.0F));
        g.addOrReplaceChild("ventilador61_0", CubeListBuilder.create().texOffs(176, 117).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(20, 100).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(61.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador61_1", CubeListBuilder.create().texOffs(200, 117).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(44, 100).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(61.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador61_2", CubeListBuilder.create().texOffs(224, 117).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(68, 100).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(61.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador61_3", CubeListBuilder.create().texOffs(248, 117).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(92, 100).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(61.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("ventilador73_0", CubeListBuilder.create().texOffs(272, 117).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(116, 100).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(73.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ventilador73_1", CubeListBuilder.create().texOffs(296, 117).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(140, 100).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(73.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("ventilador73_2", CubeListBuilder.create().texOffs(320, 117).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(164, 100).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(73.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("ventilador73_3", CubeListBuilder.create().texOffs(344, 117).addBox(-5.0F, -36.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(188, 100).addBox(-1.0F, -36.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(73.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("faro_t_0", CubeListBuilder.create().texOffs(72, 117).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(914, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(78.3F, -30.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_1", CubeListBuilder.create().texOffs(96, 117).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(938, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(78.3F, -30.0F, 0.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_2", CubeListBuilder.create().texOffs(120, 117).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(962, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(78.3F, -30.0F, 0.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_3", CubeListBuilder.create().texOffs(144, 117).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(986, 81).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(78.3F, -30.0F, 0.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("faro_t_vidrio", CubeListBuilder.create().texOffs(506, 81).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(78.92F, -30.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escape", CubeListBuilder.create().texOffs(442, 100).addBox(-8.0F, -36.0F, -2.5F, 8.0F, 3.0F, 5.0F), PartPose.ZERO);
        g.addOrReplaceChild("bocina_0", CubeListBuilder.create().texOffs(354, 81).addBox(-54.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(290, 81).addBox(-54.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offset(0.0F, -38.5F, 0.0F));
        g.addOrReplaceChild("bocina_1", CubeListBuilder.create().texOffs(372, 81).addBox(-54.0F, -6.0F, -2.5F, 4.0F, 12.0F, 5.0F).texOffs(322, 81).addBox(-54.0F, -2.5F, -6.0F, 4.0F, 5.0F, 12.0F), PartPose.offsetAndRotation(0.0F, -38.5F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_forro", CubeListBuilder.create().texOffs(882, 50).addBox(-57.0F, -35.0F, 11.0F, 20.0F, 19.0F, 1.0F).texOffs(924, 50).addBox(-57.0F, -35.0F, -12.0F, 20.0F, 19.0F, 1.0F).texOffs(430, 0).addBox(-38.0F, -35.0F, -11.0F, 1.0F, 19.0F, 22.0F).texOffs(706, 50).addBox(-57.0F, -16.0F, -12.0F, 20.0F, 1.0F, 24.0F).texOffs(794, 50).addBox(-57.0F, -36.0F, -12.0F, 20.0F, 1.0F, 24.0F).texOffs(476, 0).addBox(-57.0F, -35.0F, -11.0F, 1.0F, 19.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_pupitre", CubeListBuilder.create().texOffs(966, 50).addBox(-56.0F, -27.0F, -11.0F, 4.0F, 11.0F, 9.0F).texOffs(212, 100).addBox(-56.0F, -30.0F, -10.5F, 1.0F, 3.0F, 8.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(554, 81).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-54.4F, -28.5F, -6.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(368, 117).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(-54.28F, -28.5F, -6.5F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro0", CubeListBuilder.create().texOffs(230, 100).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-54.4F, -28.5F, -10.1F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro0_aguja", CubeListBuilder.create().texOffs(748, 125).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-54.28F, -28.5F, -10.1F, 0.4F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_manometro1", CubeListBuilder.create().texOffs(266, 100).addBox(-4.5F, 0.0F, -4.5F, 9.0F, 1.0F, 9.0F), PartPose.offsetAndRotation(-54.4F, -28.5F, -2.9000000000000004F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro1_aguja", CubeListBuilder.create().texOffs(752, 125).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-54.28F, -28.5F, -2.9000000000000004F, 1.1F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_luces", CubeListBuilder.create().texOffs(756, 125).addBox(-54.0F, -28.0F, -10.5F, 1.0F, 1.0F, 1.0F).texOffs(760, 125).addBox(-54.0F, -28.0F, -9.3F, 1.0F, 1.0F, 1.0F).texOffs(764, 125).addBox(-54.0F, -28.0F, -8.1F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(130, 112).addBox(-0.5F, -4.0F, -0.5F, 1.0F, 4.0F, 1.0F).texOffs(168, 117).addBox(-1.0F, -6.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offsetAndRotation(-54.0F, -27.0F, -3.5F, 0.0F, 0.0F, 0.15F));
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(134, 112).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 4.0F, 1.0F), PartPose.offsetAndRotation(-54.0F, -27.5F, -9.5F, 0.0F, 0.0F, -2.4668517113662407F));
        g.addOrReplaceChild("cab_freno_perilla", CubeListBuilder.create().texOffs(768, 125).addBox(-52.5F, -30.5F, -10.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(302, 100).addBox(-44.0F, -22.400000000000002F, -8.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(312, 100).addBox(-44.0F, -22.400000000000002F, 4.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "capo_corto_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_corto_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_corto_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_corto_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_corto_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_corto_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_corto_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_corto_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_corto_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_corto_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_corto_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "faro_0", 0.31385128972903376F, 0.7F, 0.31385128972903376F);
        escalar(g0, "faro_1", 0.31385128972903376F, 0.7F, 0.31385128972903376F);
        escalar(g0, "faro_2", 0.31385128972903376F, 0.7F, 0.31385128972903376F);
        escalar(g0, "faro_3", 0.31385128972903376F, 0.7F, 0.31385128972903376F);
        escalar(g0, "faro_vidrio", 0.24615384615384617F, 0.15F, 0.24615384615384617F);
        escalar(g0, "farol4_0", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol4_1", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol4_2", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol4_3", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol4_vidrio", 0.225F, 0.15F, 0.225F);
        escalar(g0, "farol16_0", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol16_1", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol16_2", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol16_3", 0.1765413504725815F, 0.55F, 0.1765413504725815F);
        escalar(g0, "farol16_vidrio", 0.225F, 0.15F, 0.225F);
        escalar(g0, "cabina_techo_0", 1.0008333333333332F, 1.0F, 0.751770183271507F);
        escalar(g0, "cabina_techo_1", 1.0008333333333332F, 1.0F, 0.7517701832715061F);
        escalar(g0, "cabina_techo_2", 1.0008333333333332F, 1.0F, 0.7517701832715066F);
        escalar(g0, "cabina_techo_3", 1.0008333333333332F, 1.0F, 0.7517701832715064F);
        escalar(g0, "cabina_techo_4", 1.0008333333333332F, 1.0F, 0.7517701832715066F);
        escalar(g0, "cabina_techo_5", 1.0008333333333332F, 1.0F, 0.7517701832715069F);
        escalar(g0, "cabina_techo_6", 1.0008333333333332F, 1.0F, 0.7517701832715059F);
        escalar(g0, "cabina_techo_7", 1.0008333333333332F, 1.0F, 0.7517701832715069F);
        escalar(g0, "cabina_techo_8", 1.0008333333333332F, 1.0F, 0.7517701832715069F);
        escalar(g0, "cabina_techo_9", 1.0008333333333332F, 1.0F, 0.7517701832715056F);
        escalar(g0, "cabina_techo_10", 1.0008333333333332F, 1.0F, 0.7517701832715068F);
        escalar(g0, "cabina_techo_11", 1.0008333333333332F, 1.0F, 0.7517701832715075F);
        escalar(g0, "capo_largo_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_largo_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_largo_cantoi_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_largo_cantoi_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_largo_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g0, "capo_largo_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g0, "capo_largo_cantod_2", 1.0F, 1.0F, 0.6257378601609217F);
        escalar(g0, "capo_largo_cantod_3", 1.0F, 1.0F, 0.6257378601609247F);
        escalar(g0, "capo_largo_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g0, "capo_largo_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capo_largo_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "radiador_cantoi_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_cantoi_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g0, "radiador_cantoi_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "radiador_cantoi_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "radiador_cantoi_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_cantod_0", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_cantod_1", 1.0F, 1.0F, 0.9386067902413815F);
        escalar(g0, "radiador_cantod_2", 1.0F, 1.0F, 0.9386067902413882F);
        escalar(g0, "radiador_cantod_3", 1.0F, 1.0F, 0.9386067902413846F);
        escalar(g0, "radiador_cantod_4", 1.0F, 1.0F, 0.9386067902413862F);
        escalar(g0, "radiador_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "radiador_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "ventilador61_0", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador61_1", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador61_2", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador61_3", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador73_0", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador73_1", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador73_2", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "ventilador73_3", 0.7846282243225844F, 1.0F, 0.7846282243225844F);
        escalar(g0, "faro_t_0", 0.2746198785129045F, 0.6F, 0.2746198785129045F);
        escalar(g0, "faro_t_1", 0.2746198785129045F, 0.6F, 0.2746198785129045F);
        escalar(g0, "faro_t_2", 0.2746198785129045F, 0.6F, 0.2746198785129045F);
        escalar(g0, "faro_t_3", 0.2746198785129045F, 0.6F, 0.2746198785129045F);
        escalar(g0, "faro_t_vidrio", 0.2333333333333333F, 0.15F, 0.2333333333333333F);
        escalar(g0, "bocina_0", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
        escalar(g0, "bocina_1", 1.0F, 0.09238795325112868F, 0.09238795325112868F);
        escalar(g0, "cab_velocimetro", 0.2333333333333333F, 0.6F, 0.2333333333333333F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.574F, 0.6F);
        escalar(g0, "cab_manometro0", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro0_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_manometro1", 0.23333333333333328F, 0.6F, 0.23333333333333328F);
        escalar(g0, "cab_manometro1_aguja", 0.3F, 0.8609999999999998F, 0.6F);
        escalar(g0, "cab_freno", 0.8F, 0.8003905296791061F, 0.8F);
    }
}
