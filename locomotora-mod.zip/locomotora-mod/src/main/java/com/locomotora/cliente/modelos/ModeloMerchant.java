package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "SR Merchant Navy" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloMerchant {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("merchant"), "main"),
            LocomotoraMod.id("textures/entity/merchant.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -16.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -16.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -16.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 4.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 4.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 4.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 24.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 24.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 24.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 8.5F, 3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_i", DatosModelo.MOTRIZ, 8.5F, 3.0F, 0.0F, -32.0F, 4.0F, -11.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_i", DatosModelo.CRUCETA, 8.5F, 3.0F, 0.0F, -32.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 4.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 4.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 4.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 24.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 24.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 24.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 8.5F, 3.0F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_d", DatosModelo.MOTRIZ, 8.5F, 3.0F, 1.5707963267948966F, -32.0F, 4.0F, -11.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_d", DatosModelo.CRUCETA, 8.5F, 3.0F, 1.5707963267948966F, -32.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 1.0471975511965976F, "tender")),
            ModeloMerchant::crearCapa,
            16.0F,
            ModeloMerchant::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -48.0F, 46.0F),
                new DatosModelo.Segmento("tender", 76.0F, 116.0F)));

    private ModeloMerchant() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g1);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, -6.0F, 17.0F, 17.0F, 2.0F).texOffs(734, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 175).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(640, 202).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-16.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(770, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(806, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, -6.0F, 17.0F, 17.0F, 2.0F).texOffs(734, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1002, 175).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(646, 202).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(4.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(770, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(4.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(806, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(4.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, -6.0F, 17.0F, 17.0F, 2.0F).texOffs(734, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1012, 175).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(652, 202).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(24.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(770, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(806, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(676, 202).addBox(-16.0F, -12.0F, -7.5F, 40.0F, 1.0F, 1.0F).texOffs(186, 192).addBox(-17.5F, -13.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(194, 192).addBox(2.5F, -13.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(202, 192).addBox(22.5F, -13.0F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_i", CubeListBuilder.create().texOffs(840, 202).addBox(-32.0F, -0.5F, -0.5F, 32.0F, 1.0F, 1.0F).texOffs(210, 192).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(4.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("cruceta_i", CubeListBuilder.create().texOffs(0, 187).addBox(-29.35906464414798F, -10.0F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(90, 205).addBox(-37.85906464414798F, -9.0F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_i", CubeListBuilder.create().texOffs(972, 202).addBox(-34.85906464414798F, -7.0F, -9.0F, 14.0F, 1.0F, 1.0F).texOffs(0, 205).addBox(-34.85906464414798F, -11.0F, -9.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_i_0", CubeListBuilder.create().texOffs(650, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(298, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, -8.5F));
        g.addOrReplaceChild("cil_i_1", CubeListBuilder.create().texOffs(678, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(342, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_2", CubeListBuilder.create().texOffs(706, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(386, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_3", CubeListBuilder.create().texOffs(734, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(430, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_0", CubeListBuilder.create().texOffs(902, 163).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(168, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, -8.5F));
        g.addOrReplaceChild("cil_i_a_1", CubeListBuilder.create().texOffs(908, 163).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(190, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_2", CubeListBuilder.create().texOffs(914, 163).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(212, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_3", CubeListBuilder.create().texOffs(920, 163).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(234, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_0", CubeListBuilder.create().texOffs(926, 163).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(256, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, -8.5F));
        g.addOrReplaceChild("cil_i_b_1", CubeListBuilder.create().texOffs(932, 163).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(278, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_2", CubeListBuilder.create().texOffs(938, 163).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(300, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_3", CubeListBuilder.create().texOffs(944, 163).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(322, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, 4.0F, 17.0F, 17.0F, 2.0F).texOffs(734, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(658, 202).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-16.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(770, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(806, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, 4.0F, 17.0F, 17.0F, 2.0F).texOffs(734, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(20, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(664, 202).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(4.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(770, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(4.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(806, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(4.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, 4.0F, 17.0F, 17.0F, 2.0F).texOffs(734, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(670, 202).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(24.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(770, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(806, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(758, 202).addBox(-16.0F, -12.0F, 6.5F, 40.0F, 1.0F, 1.0F).texOffs(218, 192).addBox(-17.5F, -13.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(226, 192).addBox(2.5F, -13.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(234, 192).addBox(22.5F, -13.0F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_d", CubeListBuilder.create().texOffs(906, 202).addBox(-32.0F, -0.5F, -0.5F, 32.0F, 1.0F, 1.0F).texOffs(242, 192).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(4.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("cruceta_d", CubeListBuilder.create().texOffs(40, 187).addBox(-29.35906464414798F, -10.0F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(112, 205).addBox(-37.85906464414798F, -9.0F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_d", CubeListBuilder.create().texOffs(30, 205).addBox(-34.85906464414798F, -7.0F, 8.0F, 14.0F, 1.0F, 1.0F).texOffs(60, 205).addBox(-34.85906464414798F, -11.0F, 8.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_d_0", CubeListBuilder.create().texOffs(762, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(474, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, 8.5F));
        g.addOrReplaceChild("cil_d_1", CubeListBuilder.create().texOffs(790, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(518, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_2", CubeListBuilder.create().texOffs(818, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(562, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_3", CubeListBuilder.create().texOffs(846, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(606, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_0", CubeListBuilder.create().texOffs(950, 163).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(344, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, 8.5F));
        g.addOrReplaceChild("cil_d_a_1", CubeListBuilder.create().texOffs(956, 163).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(366, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_2", CubeListBuilder.create().texOffs(962, 163).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(388, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_3", CubeListBuilder.create().texOffs(968, 163).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(410, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_0", CubeListBuilder.create().texOffs(974, 163).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(432, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, 8.5F));
        g.addOrReplaceChild("cil_d_b_1", CubeListBuilder.create().texOffs(980, 163).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(454, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_2", CubeListBuilder.create().texOffs(986, 163).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(476, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_3", CubeListBuilder.create().texOffs(992, 163).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(498, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rbi0_0", CubeListBuilder.create().texOffs(332, 175).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(120, 192).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(354, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-54.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi0_1", CubeListBuilder.create().texOffs(142, 192).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(362, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi0_2", CubeListBuilder.create().texOffs(164, 192).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbi1_0", CubeListBuilder.create().texOffs(332, 175).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(120, 192).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(354, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-42.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi1_1", CubeListBuilder.create().texOffs(142, 192).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(362, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi1_2", CubeListBuilder.create().texOffs(164, 192).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd0_0", CubeListBuilder.create().texOffs(332, 175).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(120, 192).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(354, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-54.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd0_1", CubeListBuilder.create().texOffs(142, 192).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(362, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd0_2", CubeListBuilder.create().texOffs(164, 192).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd1_0", CubeListBuilder.create().texOffs(332, 175).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(120, 192).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(354, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-42.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd1_1", CubeListBuilder.create().texOffs(142, 192).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(362, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd1_2", CubeListBuilder.create().texOffs(164, 192).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(242, 149).addBox(-5.5F, -5.5F, -6.0F, 11.0F, 11.0F, 2.0F).texOffs(842, 175).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(268, 149).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(90, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(46.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(868, 175).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(278, 149).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(894, 175).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 149).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(242, 149).addBox(-5.5F, -5.5F, 4.0F, 11.0F, 11.0F, 2.0F).texOffs(842, 175).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(268, 149).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(100, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(46.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(868, 175).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(278, 149).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(894, 175).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 149).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(544, 129).addBox(-60.0F, -17.0F, 2.0F, 120.0F, 13.0F, 1.0F).texOffs(0, 149).addBox(-60.0F, -17.0F, -3.0F, 120.0F, 13.0F, 1.0F).texOffs(0, 98).addBox(-60.0F, -15.0F, -12.0F, 3.0F, 7.0F, 24.0F).texOffs(250, 192).addBox(-62.0F, -13.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(154, 98).addBox(-57.0F, -18.0F, -12.5F, 93.0F, 1.0F, 25.0F), PartPose.ZERO);
        g.addOrReplaceChild("tope_i_0", CubeListBuilder.create().texOffs(744, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(48, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("tope_i_1", CubeListBuilder.create().texOffs(764, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(106, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_i_2", CubeListBuilder.create().texOffs(784, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(164, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_0", CubeListBuilder.create().texOffs(998, 163).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(520, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("tope_ic_1", CubeListBuilder.create().texOffs(1004, 163).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(542, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_2", CubeListBuilder.create().texOffs(1010, 163).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(564, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_3", CubeListBuilder.create().texOffs(1016, 163).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(586, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_0", CubeListBuilder.create().texOffs(804, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(222, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("tope_d_1", CubeListBuilder.create().texOffs(824, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(280, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_2", CubeListBuilder.create().texOffs(844, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(338, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_0", CubeListBuilder.create().texOffs(0, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(608, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("tope_dc_1", CubeListBuilder.create().texOffs(6, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(630, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_2", CubeListBuilder.create().texOffs(12, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(652, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_3", CubeListBuilder.create().texOffs(18, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(674, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa", CubeListBuilder.create().texOffs(802, 0).addBox(-46.0F, -33.0F, -12.5F, 82.0F, 15.0F, 25.0F).texOffs(0, 129).addBox(-46.0F, -38.0F, -7.5F, 82.0F, 5.0F, 15.0F).texOffs(504, 129).addBox(-55.0F, -32.0F, 11.5F, 9.0F, 14.0F, 1.0F).texOffs(524, 129).addBox(-55.0F, -32.0F, -12.5F, 9.0F, 14.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("carcasa_cantoi_0", CubeListBuilder.create().texOffs(256, 192).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -33.772542485937365F, -12.377641290737884F, -1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_1", CubeListBuilder.create().texOffs(424, 192).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -35.24200561666855F, -11.900183776675252F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_2", CubeListBuilder.create().texOffs(592, 192).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -36.49200561666855F, -10.99200561666855F, -2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_3", CubeListBuilder.create().texOffs(760, 192).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -37.40018377667525F, -9.74200561666855F, -2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_4", CubeListBuilder.create().texOffs(0, 196).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -37.877641290737884F, -8.272542485937368F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_0", CubeListBuilder.create().texOffs(168, 196).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -33.772542485937365F, 12.377641290737884F, 1.7278759594743862F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("carcasa_cantod_1", CubeListBuilder.create().texOffs(336, 196).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -35.24200561666855F, 11.900183776675252F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_2", CubeListBuilder.create().texOffs(504, 196).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -36.49200561666855F, 10.99200561666855F, 2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_3", CubeListBuilder.create().texOffs(672, 196).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -37.40018377667525F, 9.74200561666855F, 2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_4", CubeListBuilder.create().texOffs(840, 196).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -37.877641290737884F, 8.272542485937368F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha", CubeListBuilder.create().texOffs(390, 98).addBox(-55.0F, -33.0F, -12.5F, 9.0F, 1.0F, 25.0F).texOffs(194, 129).addBox(-55.0F, -38.0F, -7.5F, 9.0F, 5.0F, 15.0F).texOffs(458, 98).addBox(-55.0F, -21.0F, -11.5F, 1.0F, 3.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("capucha_cantoi_0", CubeListBuilder.create().texOffs(420, 202).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -33.772542485937365F, -12.377641290737884F, -1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantoi_1", CubeListBuilder.create().texOffs(442, 202).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -35.24200561666855F, -11.900183776675252F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantoi_2", CubeListBuilder.create().texOffs(464, 202).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -36.49200561666855F, -10.99200561666855F, -2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantoi_3", CubeListBuilder.create().texOffs(486, 202).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -37.40018377667525F, -9.74200561666855F, -2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantoi_4", CubeListBuilder.create().texOffs(508, 202).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -37.877641290737884F, -8.272542485937368F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantod_0", CubeListBuilder.create().texOffs(530, 202).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -33.772542485937365F, 12.377641290737884F, 1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantod_1", CubeListBuilder.create().texOffs(552, 202).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -35.24200561666855F, 11.900183776675252F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantod_2", CubeListBuilder.create().texOffs(574, 202).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -36.49200561666855F, 10.99200561666855F, 2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantod_3", CubeListBuilder.create().texOffs(596, 202).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -37.40018377667525F, 9.74200561666855F, 2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantod_4", CubeListBuilder.create().texOffs(618, 202).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -37.877641290737884F, 8.272542485937368F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 50.0F), PartPose.offset(-55.0F, -33.0F, -12.5F));
        g.addOrReplaceChild("capucha_tapab", CubeListBuilder.create().texOffs(102, 0).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 50.0F), PartPose.offset(-47.0F, -33.0F, -12.5F));
        g.addOrReplaceChild("frente", CubeListBuilder.create().texOffs(702, 175).addBox(-50.0F, -38.5F, -3.0F, 10.0F, 1.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("frente_caja", CubeListBuilder.create().texOffs(0, 60).addBox(0.0F, -15.0F, 0.0F, 1.0F, 15.0F, 23.0F), PartPose.offset(-47.0F, -18.0F, -11.5F));
        g.addOrReplaceChild("puerta", CubeListBuilder.create().texOffs(408, 0).addBox(-26.0F, 0.0F, -26.0F, 52.0F, 1.0F, 52.0F), PartPose.offsetAndRotation(-47.1F, -25.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("placa", CubeListBuilder.create().texOffs(596, 98).addBox(-10.5F, 0.0F, -10.5F, 21.0F, 1.0F, 21.0F), PartPose.offsetAndRotation(-47.7F, -25.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_0", CubeListBuilder.create().texOffs(842, 187).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(874, 149).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, -7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_1", CubeListBuilder.create().texOffs(866, 187).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(898, 149).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, -7.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_2", CubeListBuilder.create().texOffs(890, 187).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(922, 149).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, -7.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_3", CubeListBuilder.create().texOffs(914, 187).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(946, 149).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, -7.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_vidrio", CubeListBuilder.create().texOffs(606, 175).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-57.82F, -19.0F, -7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_0", CubeListBuilder.create().texOffs(938, 187).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(970, 149).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_1", CubeListBuilder.create().texOffs(962, 187).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(994, 149).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_2", CubeListBuilder.create().texOffs(986, 187).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(0, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_3", CubeListBuilder.create().texOffs(0, 192).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(24, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_vidrio", CubeListBuilder.create().texOffs(638, 175).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-57.82F, -19.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_0", CubeListBuilder.create().texOffs(24, 192).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(48, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_1", CubeListBuilder.create().texOffs(48, 192).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(72, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 7.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_2", CubeListBuilder.create().texOffs(72, 192).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(96, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 7.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_3", CubeListBuilder.create().texOffs(96, 192).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(120, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 7.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_vidrio", CubeListBuilder.create().texOffs(670, 175).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-57.82F, -19.0F, 7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(280, 129).addBox(36.0F, -35.0F, 11.5F, 22.0F, 17.0F, 1.0F).texOffs(326, 129).addBox(36.0F, -35.0F, -12.5F, 22.0F, 17.0F, 1.0F).texOffs(506, 98).addBox(36.0F, -19.0F, -11.5F, 22.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(170, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -35.49927091301129F, -11.51615384404144F, -2.7173867122803745F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(226, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -36.31080529218622F, -9.517149853366792F, -2.7945150652457276F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(282, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -36.965899979783764F, -7.461558465566805F, -2.8716434182110686F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(338, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.46065989126571F, -5.361601886657044F, -2.9487717711764225F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(394, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.79214326612349F, -3.2297661107331788F, -3.0259001241417716F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(450, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.95837915909906F, -1.0787266803175881F, -3.1030284771071184F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(506, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.95837915909906F, 1.0787266803175866F, 3.1030284771071184F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(562, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.79214326612349F, 3.229766110733176F, 3.0259001241417716F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(618, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.46065989126571F, 5.361601886657043F, 2.9487717711764225F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(674, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -36.965899979783764F, 7.461558465566805F, 2.8716434182110686F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(730, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -36.31080529218622F, 9.517149853366792F, 2.7945150652457276F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(786, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -35.49927091301129F, 11.51615384404144F, 2.7173867122803745F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_atras", CubeListBuilder.create().texOffs(54, 98).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 25.0F), PartPose.offset(57.0F, -33.0F, -12.5F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(144, 163).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(920, 175).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(110, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(76.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(944, 175).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(76.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(968, 175).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(76.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(144, 163).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(920, 175).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(120, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(96.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(944, 175).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(968, 175).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri2_0", CubeListBuilder.create().texOffs(144, 163).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(920, 175).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(130, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(116.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri2_1", CubeListBuilder.create().texOffs(944, 175).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri2_2", CubeListBuilder.create().texOffs(968, 175).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(144, 163).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(920, 175).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(140, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(76.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(944, 175).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(76.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(968, 175).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(76.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(144, 163).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(920, 175).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(150, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(96.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(944, 175).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(968, 175).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd2_0", CubeListBuilder.create().texOffs(144, 163).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(920, 175).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(872, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(160, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(116.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd2_1", CubeListBuilder.create().texOffs(944, 175).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(882, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd2_2", CubeListBuilder.create().texOffs(968, 175).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(892, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(72, 175).addBox(64.0F, -14.0F, 2.0F, 64.0F, 10.0F, 1.0F).texOffs(202, 175).addBox(64.0F, -14.0F, -3.0F, 64.0F, 10.0F, 1.0F).texOffs(378, 175).addBox(68.0F, -13.0F, 7.0F, 56.0F, 8.0F, 1.0F).texOffs(492, 175).addBox(68.0F, -13.0F, -8.0F, 56.0F, 8.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(616, 0).addBox(62.0F, -32.0F, -12.5F, 68.0F, 18.0F, 25.0F).texOffs(680, 98).addBox(62.0F, -36.0F, -8.5F, 68.0F, 4.0F, 17.0F).texOffs(408, 129).addBox(64.0F, -37.0F, -8.0F, 32.0F, 1.0F, 16.0F).texOffs(106, 98).addBox(130.0F, -14.0F, -11.0F, 2.0F, 7.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender_caja_cantoi_0", CubeListBuilder.create().texOffs(0, 199).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -32.61803398874989F, -12.402113032590307F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_1", CubeListBuilder.create().texOffs(140, 199).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -33.79360449333484F, -12.0201470213402F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_2", CubeListBuilder.create().texOffs(280, 199).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -34.79360449333484F, -11.29360449333484F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_3", CubeListBuilder.create().texOffs(420, 199).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -35.5201470213402F, -10.29360449333484F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_4", CubeListBuilder.create().texOffs(560, 199).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -35.90211303259031F, -9.118033988749895F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_0", CubeListBuilder.create().texOffs(700, 199).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -32.61803398874989F, 12.402113032590307F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_1", CubeListBuilder.create().texOffs(840, 199).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -33.79360449333484F, 12.0201470213402F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_2", CubeListBuilder.create().texOffs(0, 202).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -34.79360449333484F, 11.29360449333484F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_3", CubeListBuilder.create().texOffs(140, 202).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -35.5201470213402F, 10.29360449333484F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_4", CubeListBuilder.create().texOffs(280, 202).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -35.90211303259031F, 9.118033988749895F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_tapaa", CubeListBuilder.create().texOffs(204, 0).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 50.0F), PartPose.offset(62.0F, -32.0F, -12.5F));
        g.addOrReplaceChild("tender_caja_tapab", CubeListBuilder.create().texOffs(306, 0).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 50.0F), PartPose.offset(129.0F, -32.0F, -12.5F));
        g.addOrReplaceChild("tope_ti_0", CubeListBuilder.create().texOffs(864, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(396, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("tope_ti_1", CubeListBuilder.create().texOffs(884, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(454, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ti_2", CubeListBuilder.create().texOffs(904, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(512, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_0", CubeListBuilder.create().texOffs(24, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(696, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("tope_tic_1", CubeListBuilder.create().texOffs(30, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(718, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_2", CubeListBuilder.create().texOffs(36, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(740, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_3", CubeListBuilder.create().texOffs(42, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(762, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_0", CubeListBuilder.create().texOffs(924, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(570, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("tope_td_1", CubeListBuilder.create().texOffs(944, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(628, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_2", CubeListBuilder.create().texOffs(964, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(686, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_0", CubeListBuilder.create().texOffs(48, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(784, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("tope_tdc_1", CubeListBuilder.create().texOffs(54, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(806, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_2", CubeListBuilder.create().texOffs(60, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(828, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_3", CubeListBuilder.create().texOffs(66, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(850, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "cil_i_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "tope_i_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_ic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_d_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_dc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "carcasa_cantoi_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g0, "carcasa_cantoi_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "carcasa_cantoi_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g0, "carcasa_cantoi_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g0, "carcasa_cantoi_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "carcasa_cantod_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g0, "carcasa_cantod_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "carcasa_cantod_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g0, "carcasa_cantod_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g0, "carcasa_cantod_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "capucha_cantoi_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g0, "capucha_cantoi_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "capucha_cantoi_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g0, "capucha_cantoi_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g0, "capucha_cantoi_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "capucha_cantod_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g0, "capucha_cantod_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "capucha_cantod_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g0, "capucha_cantod_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g0, "capucha_cantod_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "capucha_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capucha_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "puerta", 0.25F, 0.6F, 0.25F);
        escalar(g0, "placa", 0.24761904761904763F, 0.6F, 0.24761904761904763F);
        escalar(g0, "farol3_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "farol10_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "farol17_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "cabina_techo_0", 1.0008F, 1.0F, 0.7263528776800517F);
        escalar(g0, "cabina_techo_1", 1.0008F, 1.0F, 0.7263528776800502F);
        escalar(g0, "cabina_techo_2", 1.0008F, 1.0F, 0.7263528776800522F);
        escalar(g0, "cabina_techo_3", 1.0008F, 1.0F, 0.7263528776800509F);
        escalar(g0, "cabina_techo_4", 1.0008F, 1.0F, 0.7263528776800512F);
        escalar(g0, "cabina_techo_5", 1.0008F, 1.0F, 0.7263528776800515F);
        escalar(g0, "cabina_techo_6", 1.0008F, 1.0F, 0.7263528776800504F);
        escalar(g0, "cabina_techo_7", 1.0008F, 1.0F, 0.7263528776800516F);
        escalar(g0, "cabina_techo_8", 1.0008F, 1.0F, 0.7263528776800515F);
        escalar(g0, "cabina_techo_9", 1.0008F, 1.0F, 0.7263528776800516F);
        escalar(g0, "cabina_techo_10", 1.0008F, 1.0F, 0.7263528776800507F);
        escalar(g0, "cabina_techo_11", 1.0008F, 1.0F, 0.7263528776800517F);
        escalar(g1, "tender_caja_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g1, "tender_caja_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g1, "tender_caja_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g1, "tender_caja_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g1, "tender_caja_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g1, "tender_caja_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g1, "tender_caja_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g1, "tender_caja_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g1, "tender_caja_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g1, "tender_caja_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g1, "tender_caja_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tender_caja_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tope_ti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_td_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
    }
}
