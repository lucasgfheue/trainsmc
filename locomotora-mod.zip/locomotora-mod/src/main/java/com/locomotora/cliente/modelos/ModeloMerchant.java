package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "SR Merchant Navy" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloMerchant {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("merchant"), "main"),
            LocomotoraMod.id("textures/entity/merchant.png"),
            List.of(
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -16.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -16.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, -16.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi1_0", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 4.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi1_1", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 4.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi1_2", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 4.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi2_0", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 24.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi2_1", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 24.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi2_2", DatosModelo.RUEDA, 8.5F, 0.0F, 0.0F, 0.0F, 24.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_i", DatosModelo.BIELA, 8.5F, 3.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_i", DatosModelo.MOTRIZ, 8.5F, 3.0F, 0.0F, -32.0F, 4.0F, -11.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_i", DatosModelo.CRUCETA, 8.5F, 3.0F, 0.0F, -32.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, -16.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd1_0", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 4.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd1_1", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 4.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd1_2", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 4.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd2_0", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 24.0F, -8.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd2_1", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 24.0F, -8.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd2_2", DatosModelo.RUEDA, 8.5F, 0.0F, 1.5707963267948966F, 0.0F, 24.0F, -8.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("biela_d", DatosModelo.BIELA, 8.5F, 3.0F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("motriz_d", DatosModelo.MOTRIZ, 8.5F, 3.0F, 1.5707963267948966F, -32.0F, 4.0F, -11.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("cruceta_d", DatosModelo.CRUCETA, 8.5F, 3.0F, 1.5707963267948966F, -32.0F, 0.0F, 0.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbi1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbi1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbi1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -54.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rbd1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rbd1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rbd1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -42.0F, -4.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, 46.0F, -5.5F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("cab_velocimetro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 37.72F, -31.6F, 0.0F, "locomotora", 4.8F, -2.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.0F, 0.0F, 42.0F, -19.0F, 0.0F, "locomotora", -0.22F, -8.0F, 0.0F),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 76.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 96.0F, -5.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd2_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd2_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd2_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 116.0F, -5.0F, 1.0471975511965976F, "tender")),
            ModeloMerchant::crearCapa,
            16.0F,
            ModeloMerchant::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -48.0F, 46.0F),
                new DatosModelo.Segmento("tender", 76.0F, 116.0F)));

    private ModeloMerchant() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g1);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, -6.0F, 17.0F, 17.0F, 2.0F).texOffs(928, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(190, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(780, 203).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-16.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(964, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(0, 187).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi1_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, -6.0F, 17.0F, 17.0F, 2.0F).texOffs(928, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(200, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(786, 203).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(4.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmi1_1", CubeListBuilder.create().texOffs(964, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(4.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi1_2", CubeListBuilder.create().texOffs(0, 187).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(4.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi2_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, -6.0F, 17.0F, 17.0F, 2.0F).texOffs(928, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(210, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(792, 203).addBox(-1.0F, -4.0F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(24.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmi2_1", CubeListBuilder.create().texOffs(964, 175).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi2_2", CubeListBuilder.create().texOffs(0, 187).addBox(-8.0F, -2.0F, -6.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, -6.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_i", CubeListBuilder.create().texOffs(842, 203).addBox(-16.0F, -12.0F, -7.5F, 40.0F, 1.0F, 1.0F).texOffs(410, 193).addBox(-17.5F, -13.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(418, 193).addBox(2.5F, -13.0F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(426, 193).addBox(22.5F, -13.0F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_i", CubeListBuilder.create().texOffs(0, 206).addBox(-32.0F, -0.5F, -0.5F, 32.0F, 1.0F, 1.0F).texOffs(434, 193).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(4.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("cruceta_i", CubeListBuilder.create().texOffs(220, 187).addBox(-29.35906464414798F, -10.0F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(252, 206).addBox(-37.85906464414798F, -9.0F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_i", CubeListBuilder.create().texOffs(132, 206).addBox(-34.85906464414798F, -7.0F, -9.0F, 14.0F, 1.0F, 1.0F).texOffs(162, 206).addBox(-34.85906464414798F, -11.0F, -9.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_i_0", CubeListBuilder.create().texOffs(754, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(402, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, -8.5F));
        g.addOrReplaceChild("cil_i_1", CubeListBuilder.create().texOffs(782, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(446, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_2", CubeListBuilder.create().texOffs(810, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(490, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_3", CubeListBuilder.create().texOffs(838, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(534, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_0", CubeListBuilder.create().texOffs(20, 175).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(288, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, -8.5F));
        g.addOrReplaceChild("cil_i_a_1", CubeListBuilder.create().texOffs(26, 175).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(310, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_2", CubeListBuilder.create().texOffs(32, 175).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(332, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_a_3", CubeListBuilder.create().texOffs(38, 175).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(354, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_0", CubeListBuilder.create().texOffs(44, 175).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(376, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, -8.5F));
        g.addOrReplaceChild("cil_i_b_1", CubeListBuilder.create().texOffs(50, 175).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(398, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_2", CubeListBuilder.create().texOffs(56, 175).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(420, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_i_b_3", CubeListBuilder.create().texOffs(62, 175).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(442, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, 4.0F, 17.0F, 17.0F, 2.0F).texOffs(928, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(230, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(798, 203).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-16.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(964, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(0, 187).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd1_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, 4.0F, 17.0F, 17.0F, 2.0F).texOffs(928, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(240, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(804, 203).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(4.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmd1_1", CubeListBuilder.create().texOffs(964, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(4.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd1_2", CubeListBuilder.create().texOffs(0, 187).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(4.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd2_0", CubeListBuilder.create().texOffs(242, 129).addBox(-8.5F, -8.5F, 4.0F, 17.0F, 17.0F, 2.0F).texOffs(928, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(250, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(810, 203).addBox(-1.0F, -4.0F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(24.0F, -8.5F, 0.0F));
        g.addOrReplaceChild("rmd2_1", CubeListBuilder.create().texOffs(964, 175).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -8.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd2_2", CubeListBuilder.create().texOffs(0, 187).addBox(-8.0F, -2.0F, 4.0F, 16.0F, 4.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(396, 129).addBox(-2.0F, -8.0F, 4.0F, 4.0F, 16.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(24.0F, -8.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("biela_d", CubeListBuilder.create().texOffs(924, 203).addBox(-16.0F, -12.0F, 6.5F, 40.0F, 1.0F, 1.0F).texOffs(442, 193).addBox(-17.5F, -13.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(450, 193).addBox(2.5F, -13.0F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(458, 193).addBox(22.5F, -13.0F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("motriz_d", CubeListBuilder.create().texOffs(66, 206).addBox(-32.0F, -0.5F, -0.5F, 32.0F, 1.0F, 1.0F).texOffs(466, 193).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(4.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("cruceta_d", CubeListBuilder.create().texOffs(260, 187).addBox(-29.35906464414798F, -10.0F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(274, 206).addBox(-37.85906464414798F, -9.0F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("guias_d", CubeListBuilder.create().texOffs(192, 206).addBox(-34.85906464414798F, -7.0F, 8.0F, 14.0F, 1.0F, 1.0F).texOffs(222, 206).addBox(-34.85906464414798F, -11.0F, 8.0F, 14.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cil_d_0", CubeListBuilder.create().texOffs(866, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(578, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, 8.5F));
        g.addOrReplaceChild("cil_d_1", CubeListBuilder.create().texOffs(894, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(622, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_2", CubeListBuilder.create().texOffs(922, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(666, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_3", CubeListBuilder.create().texOffs(950, 149).addBox(-46.85906464414798F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(710, 149).addBox(-46.85906464414798F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_0", CubeListBuilder.create().texOffs(68, 175).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(464, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, 8.5F));
        g.addOrReplaceChild("cil_d_a_1", CubeListBuilder.create().texOffs(74, 175).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(486, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_2", CubeListBuilder.create().texOffs(80, 175).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(508, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_a_3", CubeListBuilder.create().texOffs(86, 175).addBox(-47.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(530, 163).addBox(-47.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_0", CubeListBuilder.create().texOffs(92, 175).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(552, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -8.5F, 8.5F));
        g.addOrReplaceChild("cil_d_b_1", CubeListBuilder.create().texOffs(98, 175).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(574, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_2", CubeListBuilder.create().texOffs(104, 175).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(596, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("cil_d_b_3", CubeListBuilder.create().texOffs(110, 175).addBox(-35.35906464414798F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(618, 163).addBox(-35.35906464414798F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rbi0_0", CubeListBuilder.create().texOffs(472, 175).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(344, 193).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(494, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(270, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-54.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi0_1", CubeListBuilder.create().texOffs(366, 193).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(502, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi0_2", CubeListBuilder.create().texOffs(388, 193).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbi1_0", CubeListBuilder.create().texOffs(472, 175).addBox(-4.5F, -4.5F, -6.0F, 9.0F, 9.0F, 2.0F).texOffs(344, 193).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(494, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(280, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-42.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbi1_1", CubeListBuilder.create().texOffs(366, 193).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(502, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbi1_2", CubeListBuilder.create().texOffs(388, 193).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 175).addBox(-1.0F, -4.5F, -6.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd0_0", CubeListBuilder.create().texOffs(472, 175).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(344, 193).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(494, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(290, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-54.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd0_1", CubeListBuilder.create().texOffs(366, 193).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(502, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd0_2", CubeListBuilder.create().texOffs(388, 193).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-54.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rbd1_0", CubeListBuilder.create().texOffs(472, 175).addBox(-4.5F, -4.5F, 4.0F, 9.0F, 9.0F, 2.0F).texOffs(344, 193).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(494, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-42.0F, -4.5F, 0.0F));
        g.addOrReplaceChild("rbd1_1", CubeListBuilder.create().texOffs(366, 193).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(502, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -4.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rbd1_2", CubeListBuilder.create().texOffs(388, 193).addBox(-4.5F, -1.0F, 4.0F, 9.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(510, 175).addBox(-1.0F, -4.5F, 4.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -4.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(346, 149).addBox(-5.5F, -5.5F, -6.0F, 11.0F, 11.0F, 2.0F).texOffs(40, 187).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 149).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(310, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(46.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(66, 187).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(382, 149).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(92, 187).addBox(-5.5F, -1.5F, -6.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 149).addBox(-1.5F, -5.5F, -6.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(346, 149).addBox(-5.5F, -5.5F, 4.0F, 11.0F, 11.0F, 2.0F).texOffs(40, 187).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(372, 149).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(320, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(46.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(66, 187).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(382, 149).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(92, 187).addBox(-5.5F, -1.5F, 4.0F, 11.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(392, 149).addBox(-1.5F, -5.5F, 4.0F, 3.0F, 11.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(544, 129).addBox(-60.0F, -17.0F, 2.0F, 120.0F, 13.0F, 1.0F).texOffs(0, 149).addBox(-60.0F, -17.0F, -3.0F, 120.0F, 13.0F, 1.0F).texOffs(0, 98).addBox(-60.0F, -15.0F, -12.0F, 3.0F, 7.0F, 24.0F).texOffs(482, 193).addBox(-62.0F, -13.0F, -0.5F, 2.0F, 3.0F, 1.0F).texOffs(154, 98).addBox(-57.0F, -18.0F, -12.5F, 93.0F, 1.0F, 25.0F), PartPose.ZERO);
        g.addOrReplaceChild("tope_i_0", CubeListBuilder.create().texOffs(744, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(48, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("tope_i_1", CubeListBuilder.create().texOffs(764, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(106, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_i_2", CubeListBuilder.create().texOffs(784, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(164, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_0", CubeListBuilder.create().texOffs(116, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(640, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, -8.5F));
        g.addOrReplaceChild("tope_ic_1", CubeListBuilder.create().texOffs(122, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(662, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_2", CubeListBuilder.create().texOffs(128, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(684, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ic_3", CubeListBuilder.create().texOffs(134, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(706, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_0", CubeListBuilder.create().texOffs(804, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(222, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("tope_d_1", CubeListBuilder.create().texOffs(824, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(280, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_2", CubeListBuilder.create().texOffs(844, 60).addBox(-63.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(338, 60).addBox(-63.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_0", CubeListBuilder.create().texOffs(140, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(728, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -11.5F, 8.5F));
        g.addOrReplaceChild("tope_dc_1", CubeListBuilder.create().texOffs(146, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(750, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_2", CubeListBuilder.create().texOffs(152, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(772, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_dc_3", CubeListBuilder.create().texOffs(158, 175).addBox(-64.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(794, 163).addBox(-64.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -11.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa", CubeListBuilder.create().texOffs(802, 0).addBox(-46.0F, -33.0F, -12.5F, 82.0F, 15.0F, 25.0F).texOffs(0, 129).addBox(-46.0F, -38.0F, -7.5F, 82.0F, 5.0F, 15.0F).texOffs(504, 129).addBox(-55.0F, -32.0F, 11.5F, 9.0F, 14.0F, 1.0F).texOffs(524, 129).addBox(-55.0F, -32.0F, -12.5F, 9.0F, 14.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("carcasa_cantoi_0", CubeListBuilder.create().texOffs(492, 193).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -33.772542485937365F, -12.377641290737884F, -1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_1", CubeListBuilder.create().texOffs(660, 193).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -35.24200561666855F, -11.900183776675252F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_2", CubeListBuilder.create().texOffs(828, 193).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -36.49200561666855F, -10.99200561666855F, -2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_3", CubeListBuilder.create().texOffs(0, 197).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -37.40018377667525F, -9.74200561666855F, -2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantoi_4", CubeListBuilder.create().texOffs(168, 197).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -37.877641290737884F, -8.272542485937368F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_0", CubeListBuilder.create().texOffs(336, 197).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -33.772542485937365F, 12.377641290737884F, 1.7278759594743862F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("carcasa_cantod_1", CubeListBuilder.create().texOffs(504, 197).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -35.24200561666855F, 11.900183776675252F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_2", CubeListBuilder.create().texOffs(672, 197).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -36.49200561666855F, 10.99200561666855F, 2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_3", CubeListBuilder.create().texOffs(840, 197).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -37.40018377667525F, 9.74200561666855F, 2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("carcasa_cantod_4", CubeListBuilder.create().texOffs(0, 200).addBox(-41.0F, -1.0F, -1.0F, 82.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.0F, -37.877641290737884F, 8.272542485937368F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha", CubeListBuilder.create().texOffs(390, 98).addBox(-55.0F, -33.0F, -12.5F, 9.0F, 1.0F, 25.0F).texOffs(194, 129).addBox(-55.0F, -38.0F, -7.5F, 9.0F, 5.0F, 15.0F).texOffs(458, 98).addBox(-55.0F, -21.0F, -11.5F, 1.0F, 3.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("capucha_cantoi_0", CubeListBuilder.create().texOffs(560, 203).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -33.772542485937365F, -12.377641290737884F, -1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantoi_1", CubeListBuilder.create().texOffs(582, 203).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -35.24200561666855F, -11.900183776675252F, -2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantoi_2", CubeListBuilder.create().texOffs(604, 203).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -36.49200561666855F, -10.99200561666855F, -2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantoi_3", CubeListBuilder.create().texOffs(626, 203).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -37.40018377667525F, -9.74200561666855F, -2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantoi_4", CubeListBuilder.create().texOffs(648, 203).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -37.877641290737884F, -8.272542485937368F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantod_0", CubeListBuilder.create().texOffs(670, 203).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -33.772542485937365F, 12.377641290737884F, 1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantod_1", CubeListBuilder.create().texOffs(692, 203).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -35.24200561666855F, 11.900183776675252F, 2.042035224833367F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantod_2", CubeListBuilder.create().texOffs(714, 203).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -36.49200561666855F, 10.99200561666855F, 2.356194490192344F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantod_3", CubeListBuilder.create().texOffs(736, 203).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -37.40018377667525F, 9.74200561666855F, 2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_cantod_4", CubeListBuilder.create().texOffs(758, 203).addBox(-4.5F, -1.0F, -1.0F, 9.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-50.5F, -37.877641290737884F, 8.272542485937368F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("capucha_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 50.0F), PartPose.offset(-55.0F, -33.0F, -12.5F));
        g.addOrReplaceChild("capucha_tapab", CubeListBuilder.create().texOffs(102, 0).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 50.0F), PartPose.offset(-47.0F, -33.0F, -12.5F));
        g.addOrReplaceChild("frente", CubeListBuilder.create().texOffs(892, 175).addBox(-50.0F, -38.5F, -3.0F, 10.0F, 1.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("frente_caja", CubeListBuilder.create().texOffs(0, 60).addBox(0.0F, -15.0F, 0.0F, 1.0F, 15.0F, 23.0F), PartPose.offset(-47.0F, -18.0F, -11.5F));
        g.addOrReplaceChild("puerta", CubeListBuilder.create().texOffs(408, 0).addBox(-26.0F, 0.0F, -26.0F, 52.0F, 1.0F, 52.0F), PartPose.offsetAndRotation(-47.1F, -25.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("placa", CubeListBuilder.create().texOffs(596, 98).addBox(-10.5F, 0.0F, -10.5F, 21.0F, 1.0F, 21.0F), PartPose.offsetAndRotation(-47.7F, -25.5F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_0", CubeListBuilder.create().texOffs(56, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(978, 149).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, -7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_1", CubeListBuilder.create().texOffs(80, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(0, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, -7.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_2", CubeListBuilder.create().texOffs(104, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(24, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, -7.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_3", CubeListBuilder.create().texOffs(128, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(48, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, -7.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol3_vidrio", CubeListBuilder.create().texOffs(780, 175).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-57.82F, -19.0F, -7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_0", CubeListBuilder.create().texOffs(152, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(72, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_1", CubeListBuilder.create().texOffs(176, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(96, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_2", CubeListBuilder.create().texOffs(200, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(120, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_3", CubeListBuilder.create().texOffs(224, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(144, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol10_vidrio", CubeListBuilder.create().texOffs(812, 175).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-57.82F, -19.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_0", CubeListBuilder.create().texOffs(248, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(168, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_1", CubeListBuilder.create().texOffs(272, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(192, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 7.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_2", CubeListBuilder.create().texOffs(296, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(216, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 7.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_3", CubeListBuilder.create().texOffs(320, 193).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(240, 163).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-57.2F, -19.0F, 7.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("farol17_vidrio", CubeListBuilder.create().texOffs(844, 175).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-57.82F, -19.0F, 7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(280, 129).addBox(36.0F, -35.0F, 11.5F, 22.0F, 17.0F, 1.0F).texOffs(326, 129).addBox(36.0F, -35.0F, -12.5F, 22.0F, 17.0F, 1.0F).texOffs(506, 98).addBox(36.0F, -19.0F, -11.5F, 22.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(398, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -35.49927091301129F, -11.51615384404144F, -2.7173867122803745F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(454, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -36.31080529218622F, -9.517149853366792F, -2.7945150652457276F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(510, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -36.965899979783764F, -7.461558465566805F, -2.8716434182110686F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(566, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.46065989126571F, -5.361601886657044F, -2.9487717711764225F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(622, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.79214326612349F, -3.2297661107331788F, -3.0259001241417716F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(678, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.95837915909906F, -1.0787266803175881F, -3.1030284771071184F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(734, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.95837915909906F, 1.0787266803175866F, 3.1030284771071184F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(790, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.79214326612349F, 3.229766110733176F, 3.0259001241417716F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(846, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -37.46065989126571F, 5.361601886657043F, 2.9487717711764225F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(902, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -36.965899979783764F, 7.461558465566805F, 2.8716434182110686F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(958, 187).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -36.31080529218622F, 9.517149853366792F, 2.7945150652457276F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(0, 193).addBox(-12.5F, -1.0F, -1.5F, 25.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(47.5F, -35.49927091301129F, 11.51615384404144F, 2.7173867122803745F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_atras", CubeListBuilder.create().texOffs(54, 98).addBox(0.0F, -6.0F, 0.0F, 1.0F, 6.0F, 25.0F), PartPose.offset(57.0F, -33.0F, -12.5F));
        g.addOrReplaceChild("cab_hogar_caja", CubeListBuilder.create().texOffs(850, 98).addBox(36.0F, -30.0F, -5.0F, 2.0F, 11.0F, 10.0F).texOffs(876, 175).addBox(38.0F, -25.0F, -2.5F, 1.0F, 4.0F, 5.0F).texOffs(390, 187).addBox(38.5F, -24.0F, -1.5F, 1.0F, 2.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_placa", CubeListBuilder.create().texOffs(992, 163).addBox(36.0F, -35.0F, -3.5F, 1.0F, 5.0F, 7.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_velocimetro", CubeListBuilder.create().texOffs(242, 149).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(37.6F, -31.6F, -2.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_velocimetro_aguja", CubeListBuilder.create().texOffs(834, 203).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(37.72F, -31.6F, -2.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_presion", CubeListBuilder.create().texOffs(294, 149).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(37.6F, -31.6F, 2.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_presion_aguja", CubeListBuilder.create().texOffs(838, 203).addBox(0.0F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F), PartPose.offsetAndRotation(37.72F, -31.6F, 2.0F, 0.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_nivel", CubeListBuilder.create().texOffs(36, 187).addBox(38.0F, -28.0F, 3.5F, 1.0F, 5.0F, 1.0F).texOffs(816, 203).addBox(38.0F, -23.0F, 3.0F, 1.0F, 1.0F, 2.0F).texOffs(822, 203).addBox(38.0F, -29.0F, 3.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_regulador", CubeListBuilder.create().texOffs(924, 175).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 6.0F, 1.0F), PartPose.offsetAndRotation(37.5F, -30.5F, 0.0F, -1.1920024339695F, 0.09966865249116204F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_valvulas", CubeListBuilder.create().texOffs(310, 206).addBox(38.0F, -28.0F, 1.0F, 1.0F, 1.0F, 1.0F).texOffs(314, 206).addBox(38.0F, -28.0F, -4.0F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_tubo", CubeListBuilder.create().texOffs(888, 175).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 8.0F, 1.0F), PartPose.offset(38.5F, -27.5F, -3.5F));
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(518, 175).addBox(-0.5F, -10.0F, -0.5F, 1.0F, 10.0F, 1.0F).texOffs(474, 193).addBox(-1.0F, -12.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(42.0F, -19.0F, -8.0F));
        g.addOrReplaceChild("cab_palanca_cuadrante", CubeListBuilder.create().texOffs(296, 206).addBox(39.0F, -20.0F, -9.5F, 6.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_freno", CubeListBuilder.create().texOffs(828, 203).addBox(45.0F, -30.0F, -11.5F, 2.0F, 2.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_freno_manija", CubeListBuilder.create().texOffs(488, 193).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F), PartPose.offsetAndRotation(46.0F, -30.0F, -11.0F, 0.7297276562269664F, 0.0F, -2.0344439357957027F));
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(522, 175).addBox(51.0F, -25.0F, -6.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(532, 175).addBox(57.0F, -25.0F, -2.0F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento2", CubeListBuilder.create().texOffs(542, 175).addBox(51.0F, -25.0F, 2.5F, 1.0F, 6.0F, 4.0F), PartPose.ZERO);
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(264, 163).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(118, 187).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(76.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(142, 187).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 175).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(76.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(166, 187).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 175).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(76.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(264, 163).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(118, 187).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(340, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(96.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(142, 187).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 175).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(166, 187).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 175).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri2_0", CubeListBuilder.create().texOffs(264, 163).addBox(-5.0F, -5.0F, -6.0F, 10.0F, 10.0F, 2.0F).texOffs(118, 187).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 163).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(350, 187).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(116.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("tri2_1", CubeListBuilder.create().texOffs(142, 187).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 175).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri2_2", CubeListBuilder.create().texOffs(166, 187).addBox(-5.0F, -1.5F, -6.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 175).addBox(-1.5F, -5.0F, -6.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(264, 163).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(118, 187).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(360, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(76.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(142, 187).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 175).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(76.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(166, 187).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 175).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(76.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(264, 163).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(118, 187).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(370, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(96.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(142, 187).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 175).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(166, 187).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 175).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(96.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd2_0", CubeListBuilder.create().texOffs(264, 163).addBox(-5.0F, -5.0F, 4.0F, 10.0F, 10.0F, 2.0F).texOffs(118, 187).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1008, 163).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(380, 187).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(116.0F, -5.0F, 0.0F));
        g.addOrReplaceChild("trd2_1", CubeListBuilder.create().texOffs(142, 187).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 175).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -5.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd2_2", CubeListBuilder.create().texOffs(166, 187).addBox(-5.0F, -1.5F, 4.0F, 10.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 175).addBox(-1.5F, -5.0F, 4.0F, 3.0F, 10.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(116.0F, -5.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(212, 175).addBox(64.0F, -14.0F, 2.0F, 64.0F, 10.0F, 1.0F).texOffs(342, 175).addBox(64.0F, -14.0F, -3.0F, 64.0F, 10.0F, 1.0F).texOffs(552, 175).addBox(68.0F, -13.0F, 7.0F, 56.0F, 8.0F, 1.0F).texOffs(666, 175).addBox(68.0F, -13.0F, -8.0F, 56.0F, 8.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(616, 0).addBox(62.0F, -32.0F, -12.5F, 68.0F, 18.0F, 25.0F).texOffs(680, 98).addBox(62.0F, -36.0F, -8.5F, 68.0F, 4.0F, 17.0F).texOffs(408, 129).addBox(64.0F, -37.0F, -8.0F, 32.0F, 1.0F, 16.0F).texOffs(106, 98).addBox(130.0F, -14.0F, -11.0F, 2.0F, 7.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender_caja_cantoi_0", CubeListBuilder.create().texOffs(168, 200).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -32.61803398874989F, -12.402113032590307F, -1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_1", CubeListBuilder.create().texOffs(308, 200).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -33.79360449333484F, -12.0201470213402F, -2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_2", CubeListBuilder.create().texOffs(448, 200).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -34.79360449333484F, -11.29360449333484F, -2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_3", CubeListBuilder.create().texOffs(588, 200).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -35.5201470213402F, -10.29360449333484F, -2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantoi_4", CubeListBuilder.create().texOffs(728, 200).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -35.90211303259031F, -9.118033988749895F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_0", CubeListBuilder.create().texOffs(868, 200).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -32.61803398874989F, 12.402113032590307F, 1.7278759594743864F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_1", CubeListBuilder.create().texOffs(0, 203).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -33.79360449333484F, 12.0201470213402F, 2.042035224833364F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_2", CubeListBuilder.create().texOffs(140, 203).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -34.79360449333484F, 11.29360449333484F, 2.356194490192348F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_3", CubeListBuilder.create().texOffs(280, 203).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -35.5201470213402F, 10.29360449333484F, 2.670353755551321F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_cantod_4", CubeListBuilder.create().texOffs(420, 203).addBox(-34.0F, -1.0F, -1.0F, 68.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(96.0F, -35.90211303259031F, 9.118033988749895F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("tender_caja_tapaa", CubeListBuilder.create().texOffs(204, 0).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 50.0F), PartPose.offset(62.0F, -32.0F, -12.5F));
        g.addOrReplaceChild("tender_caja_tapab", CubeListBuilder.create().texOffs(306, 0).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 50.0F), PartPose.offset(129.0F, -32.0F, -12.5F));
        g.addOrReplaceChild("tope_ti_0", CubeListBuilder.create().texOffs(864, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(396, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("tope_ti_1", CubeListBuilder.create().texOffs(884, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(454, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_ti_2", CubeListBuilder.create().texOffs(904, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(512, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_0", CubeListBuilder.create().texOffs(164, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(816, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, -8.5F));
        g.addOrReplaceChild("tope_tic_1", CubeListBuilder.create().texOffs(170, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(838, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_2", CubeListBuilder.create().texOffs(176, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(860, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tic_3", CubeListBuilder.create().texOffs(182, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(882, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_0", CubeListBuilder.create().texOffs(924, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(570, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("tope_td_1", CubeListBuilder.create().texOffs(944, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(628, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_td_2", CubeListBuilder.create().texOffs(964, 60).addBox(132.0F, -13.0F, -3.5F, 3.0F, 26.0F, 7.0F).texOffs(686, 60).addBox(132.0F, -3.5F, -13.0F, 3.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_0", CubeListBuilder.create().texOffs(188, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(904, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -10.5F, 8.5F));
        g.addOrReplaceChild("tope_tdc_1", CubeListBuilder.create().texOffs(194, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(926, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_2", CubeListBuilder.create().texOffs(200, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(948, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_tdc_3", CubeListBuilder.create().texOffs(206, 175).addBox(135.0F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(970, 163).addBox(135.0F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -10.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "cil_i_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_i_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_i_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_0", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_1", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_2", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_3", 1.0F, 0.6865496962822613F, 0.6865496962822613F);
        escalar(g0, "cil_d_a_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_a_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_0", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_1", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_2", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "cil_d_b_3", 1.0F, 0.7846282243225844F, 0.7846282243225844F);
        escalar(g0, "tope_i_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_i_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_ic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_ic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_d_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_d_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g0, "tope_dc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "tope_dc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g0, "carcasa_cantoi_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g0, "carcasa_cantoi_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "carcasa_cantoi_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g0, "carcasa_cantoi_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g0, "carcasa_cantoi_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "carcasa_cantod_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g0, "carcasa_cantod_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "carcasa_cantod_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g0, "carcasa_cantod_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g0, "carcasa_cantod_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "capucha_cantoi_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g0, "capucha_cantoi_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "capucha_cantoi_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g0, "capucha_cantoi_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g0, "capucha_cantoi_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "capucha_cantod_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g0, "capucha_cantod_1", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "capucha_cantod_2", 1.0F, 1.0F, 0.7821723252011549F);
        escalar(g0, "capucha_cantod_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g0, "capucha_cantod_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "capucha_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "capucha_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "puerta", 0.25F, 0.6F, 0.25F);
        escalar(g0, "placa", 0.24761904761904763F, 0.6F, 0.24761904761904763F);
        escalar(g0, "farol3_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol3_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "farol10_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol10_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "farol17_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "farol17_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "cabina_techo_0", 1.0008F, 1.0F, 0.7263528776800517F);
        escalar(g0, "cabina_techo_1", 1.0008F, 1.0F, 0.7263528776800502F);
        escalar(g0, "cabina_techo_2", 1.0008F, 1.0F, 0.7263528776800522F);
        escalar(g0, "cabina_techo_3", 1.0008F, 1.0F, 0.7263528776800509F);
        escalar(g0, "cabina_techo_4", 1.0008F, 1.0F, 0.7263528776800512F);
        escalar(g0, "cabina_techo_5", 1.0008F, 1.0F, 0.7263528776800515F);
        escalar(g0, "cabina_techo_6", 1.0008F, 1.0F, 0.7263528776800504F);
        escalar(g0, "cabina_techo_7", 1.0008F, 1.0F, 0.7263528776800516F);
        escalar(g0, "cabina_techo_8", 1.0008F, 1.0F, 0.7263528776800515F);
        escalar(g0, "cabina_techo_9", 1.0008F, 1.0F, 0.7263528776800516F);
        escalar(g0, "cabina_techo_10", 1.0008F, 1.0F, 0.7263528776800507F);
        escalar(g0, "cabina_techo_11", 1.0008F, 1.0F, 0.7263528776800517F);
        escalar(g0, "cab_velocimetro", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "cab_velocimetro_aguja", 0.3F, 0.656F, 0.6F);
        escalar(g0, "cab_presion", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "cab_presion_aguja", 0.3F, 0.656F, 0.6F);
        escalar(g0, "cab_regulador", 0.8F, 0.9013878188659974F, 0.8F);
        escalar(g0, "cab_tubo", 0.6F, 0.9375F, 0.6F);
        escalar(g0, "cab_freno_manija", 0.6F, 1.0F, 0.6F);
        escalar(g1, "tender_caja_cantoi_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g1, "tender_caja_cantoi_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g1, "tender_caja_cantoi_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g1, "tender_caja_cantoi_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g1, "tender_caja_cantoi_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g1, "tender_caja_cantod_0", 1.0F, 1.0F, 0.6257378601609218F);
        escalar(g1, "tender_caja_cantod_1", 1.0F, 1.0F, 0.6257378601609255F);
        escalar(g1, "tender_caja_cantod_2", 1.0F, 1.0F, 0.6257378601609223F);
        escalar(g1, "tender_caja_cantod_3", 1.0F, 1.0F, 0.6257378601609239F);
        escalar(g1, "tender_caja_cantod_4", 1.0F, 1.0F, 0.6257378601609235F);
        escalar(g1, "tender_caja_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tender_caja_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g1, "tope_ti_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_ti_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tic_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tic_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_td_0", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_1", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_td_2", 1.0F, 0.08173218530138272F, 0.08173218530138272F);
        escalar(g1, "tope_tdc_0", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_1", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_2", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
        escalar(g1, "tope_tdc_3", 1.0F, 0.4315455233774214F, 0.4315455233774214F);
    }
}
