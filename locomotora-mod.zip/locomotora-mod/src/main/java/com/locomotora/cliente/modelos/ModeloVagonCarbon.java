package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Vagoneta de carbón" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonCarbon {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_carbon"), "main"),
            LocomotoraMod.id("textures/entity/vagon_carbon.png"),
            List.of(
                new DatosModelo.Animada("ri0_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri0_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri0_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.5F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("ri1_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("ri1_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("ri1_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.5F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd0_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd0_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd0_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -5.5F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("rd1_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("rd1_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("rd1_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 5.5F, -2.5F, 1.0471975511965976F, "cuerpo")),
            ModeloVagonCarbon::crearCapa,
            16.0F,
            ModeloVagonCarbon::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -5.5F, 5.5F)));

    private ModeloVagonCarbon() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 32);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("ri0_0", CubeListBuilder.create().texOffs(172, 0).addBox(-2.5F, -2.5F, -6.0F, 5.0F, 5.0F, 2.0F).texOffs(352, 20).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(508, 0).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-5.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("ri0_1", CubeListBuilder.create().texOffs(366, 20).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-5.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri0_2", CubeListBuilder.create().texOffs(380, 20).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(198, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-5.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ri1_0", CubeListBuilder.create().texOffs(172, 0).addBox(-2.5F, -2.5F, -6.0F, 5.0F, 5.0F, 2.0F).texOffs(352, 20).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(518, 0).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(5.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("ri1_1", CubeListBuilder.create().texOffs(366, 20).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(5.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ri1_2", CubeListBuilder.create().texOffs(380, 20).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(198, 0).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(5.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd0_0", CubeListBuilder.create().texOffs(172, 0).addBox(-2.5F, -2.5F, 4.0F, 5.0F, 5.0F, 2.0F).texOffs(352, 20).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(528, 0).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-5.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("rd0_1", CubeListBuilder.create().texOffs(366, 20).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-5.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd0_2", CubeListBuilder.create().texOffs(380, 20).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(198, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-5.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rd1_0", CubeListBuilder.create().texOffs(172, 0).addBox(-2.5F, -2.5F, 4.0F, 5.0F, 5.0F, 2.0F).texOffs(352, 20).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(186, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(538, 0).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(5.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("rd1_1", CubeListBuilder.create().texOffs(366, 20).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(192, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(5.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rd1_2", CubeListBuilder.create().texOffs(380, 20).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(198, 0).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(5.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(320, 20).addBox(-7.0F, -4.5F, 3.0F, 3.0F, 3.0F, 1.0F).texOffs(328, 20).addBox(-7.0F, -4.5F, -4.0F, 3.0F, 3.0F, 1.0F).texOffs(336, 20).addBox(4.0F, -4.5F, 3.0F, 3.0F, 3.0F, 1.0F).texOffs(344, 20).addBox(4.0F, -4.5F, -4.0F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cajon", CubeListBuilder.create().texOffs(0, 0).addBox(-10.0F, -13.0F, -6.0F, 20.0F, 8.0F, 12.0F).texOffs(64, 0).addBox(-10.5F, -13.0F, -6.5F, 21.0F, 1.0F, 13.0F).texOffs(156, 0).addBox(-4.5F, -12.0F, 6.0F, 1.0F, 7.0F, 1.0F).texOffs(160, 0).addBox(-4.5F, -12.0F, -7.0F, 1.0F, 7.0F, 1.0F).texOffs(164, 0).addBox(3.5F, -12.0F, 6.0F, 1.0F, 7.0F, 1.0F).texOffs(168, 0).addBox(3.5F, -12.0F, -7.0F, 1.0F, 7.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("topei", CubeListBuilder.create().texOffs(132, 0).addBox(-12.0F, -8.0F, -2.0F, 2.0F, 4.0F, 4.0F).texOffs(394, 20).addBox(-13.0F, -6.5F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("toped", CubeListBuilder.create().texOffs(144, 0).addBox(10.0F, -8.0F, -2.0F, 2.0F, 4.0F, 4.0F).texOffs(398, 20).addBox(12.0F, -6.5F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("carga_0", CubeListBuilder.create().texOffs(364, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.3125F, -13.2625F, -4.8125F, -2.7844931336662144F, 0.0361049997880088F, -0.20408726354628534F));
        g.addOrReplaceChild("carga_1", CubeListBuilder.create().texOffs(382, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.9375F, -13.606193177121687F, -4.8125F, -2.4199909401799147F, 0.016941661721502535F, -0.05336170580429633F));
        g.addOrReplaceChild("carga_2", CubeListBuilder.create().texOffs(204, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-3.5625F, -13.727953830845173F, -4.8125F, -2.327874820009069F, 0.008524995852319505F, -0.02512710386252756F));
        g.addOrReplaceChild("carga_3", CubeListBuilder.create().texOffs(224, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.1875F, -13.781123350383174F, -4.8125F, -2.2925555746825323F, 0.002631544401324759F, -0.007622098730496986F));
        g.addOrReplaceChild("carga_4", CubeListBuilder.create().texOffs(244, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(1.1875F, -13.781123350383174F, -4.8125F, -2.2925555746825323F, -0.002631544401324759F, 0.007622098730496986F));
        g.addOrReplaceChild("carga_5", CubeListBuilder.create().texOffs(264, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(3.5625F, -13.727953830845173F, -4.8125F, -2.327874820009069F, -0.008524995852319505F, 0.02512710386252756F));
        g.addOrReplaceChild("carga_6", CubeListBuilder.create().texOffs(400, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.9375F, -13.606193177121689F, -4.8125F, -2.4199909401799147F, -0.016941661721502535F, 0.05336170580429633F));
        g.addOrReplaceChild("carga_7", CubeListBuilder.create().texOffs(418, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.3125F, -13.2625F, -4.8125F, -2.7844931336662144F, -0.0361049997880088F, 0.20408726354628534F));
        g.addOrReplaceChild("carga_8", CubeListBuilder.create().texOffs(548, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.3125F, -13.606193177121687F, -3.4375F, -3.036754460950022F, 0.026528703322726166F, -0.4692040771200185F));
        g.addOrReplaceChild("carga_9", CubeListBuilder.create().texOffs(764, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-5.9375F, -14.399886354243375F, -3.4375F, -2.87839664471164F, 0.019817408898555124F, -0.15126254283177684F));
        g.addOrReplaceChild("carga_10", CubeListBuilder.create().texOffs(780, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-3.5625F, -14.681069125782624F, -3.4375F, -2.8259887378929056F, 0.011635701956843087F, -0.07492854034028852F));
        g.addOrReplaceChild("carga_11", CubeListBuilder.create().texOffs(796, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.1875F, -14.803853887591288F, -3.4375F, -2.8037369882242147F, 0.0038318714912379138F, -0.023155802572638776F));
        g.addOrReplaceChild("carga_12", CubeListBuilder.create().texOffs(812, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.1875F, -14.803853887591288F, -3.4375F, -2.8037369882242147F, -0.0038318714912379138F, 0.023155802572638776F));
        g.addOrReplaceChild("carga_13", CubeListBuilder.create().texOffs(828, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.5625F, -14.681069125782624F, -3.4375F, -2.8259887378929056F, -0.011635701956843087F, 0.07492854034028852F));
        g.addOrReplaceChild("carga_14", CubeListBuilder.create().texOffs(844, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.9375F, -14.399886354243376F, -3.4375F, -2.87839664471164F, -0.019817408898555124F, 0.15126254283177684F));
        g.addOrReplaceChild("carga_15", CubeListBuilder.create().texOffs(566, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.3125F, -13.606193177121689F, -3.4375F, -3.036754460950022F, -0.026528703322726166F, 0.4692040771200185F));
        g.addOrReplaceChild("carga_16", CubeListBuilder.create().texOffs(584, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.3125F, -13.727953830845173F, -2.0625F, -3.091327860436124F, 0.0F, -0.5499335236152416F));
        g.addOrReplaceChild("carga_17", CubeListBuilder.create().texOffs(860, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-5.9375F, -14.681069125782624F, -2.0625F, -3.008493170003346F, 0.012466384921469663F, -0.1857160812541581F));
        g.addOrReplaceChild("carga_18", CubeListBuilder.create().texOffs(876, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-3.5625F, -15.018730589874906F, -2.0625F, -2.980099695881866F, 0.007516566441168302F, -0.09323041114376601F));
        g.addOrReplaceChild("carga_19", CubeListBuilder.create().texOffs(892, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.1875F, -15.16617803913923F, -2.0625F, -2.9678493793413074F, 0.0025054133498485405F, -0.028981207325715717F));
        g.addOrReplaceChild("carga_20", CubeListBuilder.create().texOffs(908, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.1875F, -15.16617803913923F, -2.0625F, -2.9678493793413074F, -0.0025054133498485405F, 0.028981207325715717F));
        g.addOrReplaceChild("carga_21", CubeListBuilder.create().texOffs(924, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.5625F, -15.018730589874906F, -2.0625F, -2.980099695881866F, -0.007516566441168302F, 0.09323041114376601F));
        g.addOrReplaceChild("carga_22", CubeListBuilder.create().texOffs(940, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.9375F, -14.681069125782626F, -2.0625F, -3.008493170003346F, -0.012466384921469663F, 0.1857160812541581F));
        g.addOrReplaceChild("carga_23", CubeListBuilder.create().texOffs(602, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.3125F, -13.727953830845173F, -2.0625F, -3.091327860436124F, 0.0F, 0.5499335236152416F));
        g.addOrReplaceChild("carga_24", CubeListBuilder.create().texOffs(620, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.3125F, -13.781123350383174F, -0.6875F, -3.1262797015129147F, 0.0F, -0.5818306795338568F));
        g.addOrReplaceChild("carga_25", CubeListBuilder.create().texOffs(956, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-5.9375F, -14.803853887591291F, -0.6875F, -3.1001357263151315F, 0.004212418201695494F, -0.20054426092112426F));
        g.addOrReplaceChild("carga_26", CubeListBuilder.create().texOffs(972, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-3.5625F, -15.16617803913923F, -0.6875F, -3.091063515548499F, 0.002563904617900863F, -0.10117871142255139F));
        g.addOrReplaceChild("carga_27", CubeListBuilder.create().texOffs(988, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.1875F, -15.324395003862225F, -0.6875F, -3.0871282735477448F, 0.0008582630964815975F, -0.031521665450446656F));
        g.addOrReplaceChild("carga_28", CubeListBuilder.create().texOffs(1004, 0).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.1875F, -15.324395003862225F, -0.6875F, -3.0871282735477448F, -0.0008582630964815975F, 0.031521665450446656F));
        g.addOrReplaceChild("carga_29", CubeListBuilder.create().texOffs(0, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.5625F, -15.16617803913923F, -0.6875F, -3.091063515548499F, -0.002563904617900863F, 0.10117871142255139F));
        g.addOrReplaceChild("carga_30", CubeListBuilder.create().texOffs(16, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.9375F, -14.80385388759129F, -0.6875F, -3.1001357263151315F, -0.004212418201695494F, 0.20054426092112426F));
        g.addOrReplaceChild("carga_31", CubeListBuilder.create().texOffs(638, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.3125F, -13.781123350383174F, -0.6875F, -3.1262797015129147F, 0.0F, 0.5818306795338568F));
        g.addOrReplaceChild("carga_32", CubeListBuilder.create().texOffs(656, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.3125F, -13.781123350383174F, 0.6875F, 3.1262797015129147F, 0.0F, -0.5818306795338568F));
        g.addOrReplaceChild("carga_33", CubeListBuilder.create().texOffs(32, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-5.9375F, -14.803853887591288F, 0.6875F, 3.1001357263151315F, -0.004212418201695494F, -0.20054426092112426F));
        g.addOrReplaceChild("carga_34", CubeListBuilder.create().texOffs(48, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-3.5625F, -15.16617803913923F, 0.6875F, 3.091063515548499F, -0.002563904617900863F, -0.10117871142255139F));
        g.addOrReplaceChild("carga_35", CubeListBuilder.create().texOffs(64, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.1875F, -15.324395003862225F, 0.6875F, 3.0871282735477448F, -0.0008582630964815975F, -0.031521665450446656F));
        g.addOrReplaceChild("carga_36", CubeListBuilder.create().texOffs(80, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.1875F, -15.324395003862225F, 0.6875F, 3.0871282735477448F, 0.0008582630964815975F, 0.031521665450446656F));
        g.addOrReplaceChild("carga_37", CubeListBuilder.create().texOffs(96, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.5625F, -15.16617803913923F, 0.6875F, 3.091063515548499F, 0.002563904617900863F, 0.10117871142255139F));
        g.addOrReplaceChild("carga_38", CubeListBuilder.create().texOffs(112, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.9375F, -14.80385388759129F, 0.6875F, 3.1001357263151315F, 0.004212418201695494F, 0.20054426092112426F));
        g.addOrReplaceChild("carga_39", CubeListBuilder.create().texOffs(674, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.3125F, -13.781123350383174F, 0.6875F, 3.1262797015129147F, 0.0F, 0.5818306795338568F));
        g.addOrReplaceChild("carga_40", CubeListBuilder.create().texOffs(692, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.3125F, -13.727953830845173F, 2.0625F, 3.091327860436124F, 0.0F, -0.5499335236152416F));
        g.addOrReplaceChild("carga_41", CubeListBuilder.create().texOffs(128, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-5.9375F, -14.681069125782624F, 2.0625F, 3.008493170003346F, -0.012466384921469663F, -0.1857160812541581F));
        g.addOrReplaceChild("carga_42", CubeListBuilder.create().texOffs(144, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-3.5625F, -15.018730589874906F, 2.0625F, 2.980099695881866F, -0.007516566441168302F, -0.09323041114376601F));
        g.addOrReplaceChild("carga_43", CubeListBuilder.create().texOffs(160, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.1875F, -15.16617803913923F, 2.0625F, 2.9678493793413074F, -0.0025054133498485405F, -0.028981207325715717F));
        g.addOrReplaceChild("carga_44", CubeListBuilder.create().texOffs(176, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.1875F, -15.16617803913923F, 2.0625F, 2.9678493793413074F, 0.0025054133498485405F, 0.028981207325715717F));
        g.addOrReplaceChild("carga_45", CubeListBuilder.create().texOffs(192, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.5625F, -15.018730589874906F, 2.0625F, 2.980099695881866F, 0.007516566441168302F, 0.09323041114376601F));
        g.addOrReplaceChild("carga_46", CubeListBuilder.create().texOffs(208, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.9375F, -14.681069125782626F, 2.0625F, 3.008493170003346F, 0.012466384921469663F, 0.1857160812541581F));
        g.addOrReplaceChild("carga_47", CubeListBuilder.create().texOffs(710, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.3125F, -13.727953830845173F, 2.0625F, 3.091327860436124F, 0.0F, 0.5499335236152416F));
        g.addOrReplaceChild("carga_48", CubeListBuilder.create().texOffs(728, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-8.3125F, -13.606193177121689F, 3.4375F, 3.036754460950022F, -0.026528703322726166F, -0.4692040771200185F));
        g.addOrReplaceChild("carga_49", CubeListBuilder.create().texOffs(224, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-5.9375F, -14.399886354243376F, 3.4375F, 2.87839664471164F, -0.019817408898555124F, -0.15126254283177684F));
        g.addOrReplaceChild("carga_50", CubeListBuilder.create().texOffs(240, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-3.5625F, -14.681069125782626F, 3.4375F, 2.8259887378929056F, -0.011635701956843087F, -0.07492854034028852F));
        g.addOrReplaceChild("carga_51", CubeListBuilder.create().texOffs(256, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.1875F, -14.803853887591288F, 3.4375F, 2.8037369882242147F, -0.0038318714912379138F, -0.023155802572638776F));
        g.addOrReplaceChild("carga_52", CubeListBuilder.create().texOffs(272, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.1875F, -14.80385388759129F, 3.4375F, 2.8037369882242147F, 0.0038318714912379138F, 0.023155802572638776F));
        g.addOrReplaceChild("carga_53", CubeListBuilder.create().texOffs(288, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(3.5625F, -14.681069125782626F, 3.4375F, 2.8259887378929056F, 0.011635701956843087F, 0.07492854034028852F));
        g.addOrReplaceChild("carga_54", CubeListBuilder.create().texOffs(304, 20).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.9375F, -14.399886354243375F, 3.4375F, 2.87839664471164F, 0.019817408898555124F, 0.15126254283177684F));
        g.addOrReplaceChild("carga_55", CubeListBuilder.create().texOffs(746, 0).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.3125F, -13.606193177121689F, 3.4375F, 3.036754460950022F, 0.026528703322726166F, 0.4692040771200185F));
        g.addOrReplaceChild("carga_56", CubeListBuilder.create().texOffs(436, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.3125F, -13.2625F, 4.8125F, 2.7844931336662144F, -0.0361049997880088F, -0.20408726354628534F));
        g.addOrReplaceChild("carga_57", CubeListBuilder.create().texOffs(454, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.9375F, -13.606193177121689F, 4.8125F, 2.4199909401799147F, -0.016941661721502535F, -0.05336170580429633F));
        g.addOrReplaceChild("carga_58", CubeListBuilder.create().texOffs(284, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-3.5625F, -13.727953830845173F, 4.8125F, 2.327874820009069F, -0.008524995852319505F, -0.02512710386252756F));
        g.addOrReplaceChild("carga_59", CubeListBuilder.create().texOffs(304, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-1.1875F, -13.781123350383174F, 4.8125F, 2.2925555746825323F, -0.002631544401324759F, -0.007622098730496986F));
        g.addOrReplaceChild("carga_60", CubeListBuilder.create().texOffs(324, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(1.1875F, -13.781123350383174F, 4.8125F, 2.2925555746825323F, 0.002631544401324759F, 0.007622098730496986F));
        g.addOrReplaceChild("carga_61", CubeListBuilder.create().texOffs(344, 0).addBox(-2.5F, -1.0F, -2.5F, 5.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(3.5625F, -13.727953830845173F, 4.8125F, 2.327874820009069F, 0.008524995852319505F, 0.02512710386252756F));
        g.addOrReplaceChild("carga_62", CubeListBuilder.create().texOffs(472, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.9375F, -13.606193177121689F, 4.8125F, 2.4199909401799147F, 0.016941661721502535F, 0.05336170580429633F));
        g.addOrReplaceChild("carga_63", CubeListBuilder.create().texOffs(490, 0).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.3125F, -13.2625F, 4.8125F, 2.7844931336662144F, 0.0361049997880088F, 0.20408726354628534F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "carga_0", 0.5071752779915716F, 1.0F, 0.40063312845994953F);
        escalar(g0, "carga_1", 0.4872102899789206F, 1.0F, 0.47180599540183404F);
        escalar(g0, "carga_2", 0.4855537023977027F, 1.0F, 0.41066935328991094F);
        escalar(g0, "carga_3", 0.48505348837216966F, 1.0F, 0.42624594016157713F);
        escalar(g0, "carga_4", 0.48505348837216966F, 1.0F, 0.42624594016157713F);
        escalar(g0, "carga_5", 0.4855537023977027F, 1.0F, 0.41066935328991094F);
        escalar(g0, "carga_6", 0.4872102899789206F, 1.0F, 0.47180599540183404F);
        escalar(g0, "carga_7", 0.5071752779915716F, 1.0F, 0.40063312845994953F);
        escalar(g0, "carga_8", 0.4534126004738317F, 1.0F, 0.4813058082627482F);
        escalar(g0, "carga_9", 0.4909869620681985F, 1.0F, 0.4920142971717183F);
        escalar(g0, "carga_10", 0.48650211931215137F, 1.0F, 0.49902021829083193F);
        escalar(g0, "carga_11", 0.485145175351996F, 1.0F, 0.5024850169209883F);
        escalar(g0, "carga_12", 0.485145175351996F, 1.0F, 0.5024850169209883F);
        escalar(g0, "carga_13", 0.48650211931215137F, 1.0F, 0.49902021829083193F);
        escalar(g0, "carga_14", 0.4909869620681985F, 1.0F, 0.4920142971717183F);
        escalar(g0, "carga_15", 0.4534126004738317F, 1.0F, 0.4813058082627482F);
        escalar(g0, "carga_16", 0.4727648269793187F, 1.0F, 0.47659033169388615F);
        escalar(g0, "carga_17", 0.4934883111946192F, 1.0F, 0.4793099370144374F);
        escalar(g0, "carga_18", 0.4871333492232532F, 1.0F, 0.4811141427322622F);
        escalar(g0, "carga_19", 0.4852062901766832F, 1.0F, 0.48201361732574965F);
        escalar(g0, "carga_20", 0.4852062901766832F, 1.0F, 0.48201361732574965F);
        escalar(g0, "carga_21", 0.4871333492232532F, 1.0F, 0.4811141427322622F);
        escalar(g0, "carga_22", 0.4934883111946192F, 1.0F, 0.4793099370144374F);
        escalar(g0, "carga_23", 0.4727648269793187F, 1.0F, 0.47659033169388615F);
        escalar(g0, "carga_24", 0.4821383553487985F, 1.0F, 0.475153947308291F);
        escalar(g0, "carga_25", 0.4947341328922804F, 1.0F, 0.47541779373582044F);
        escalar(g0, "carga_26", 0.4874486510183459F, 1.0F, 0.47559360706541765F);
        escalar(g0, "carga_27", 0.48523684464160544F, 1.0F, 0.4756814884726597F);
        escalar(g0, "carga_28", 0.48523684464160544F, 1.0F, 0.4756814884726597F);
        escalar(g0, "carga_29", 0.4874486510183459F, 1.0F, 0.47559360706541765F);
        escalar(g0, "carga_30", 0.4947341328922804F, 1.0F, 0.47541779373582044F);
        escalar(g0, "carga_31", 0.4821383553487985F, 1.0F, 0.475153947308291F);
        escalar(g0, "carga_32", 0.4821383553487985F, 1.0F, 0.475153947308291F);
        escalar(g0, "carga_33", 0.4947341328922804F, 1.0F, 0.47541779373582044F);
        escalar(g0, "carga_34", 0.4874486510183459F, 1.0F, 0.47559360706541765F);
        escalar(g0, "carga_35", 0.48523684464160544F, 1.0F, 0.4756814884726597F);
        escalar(g0, "carga_36", 0.48523684464160544F, 1.0F, 0.4756814884726597F);
        escalar(g0, "carga_37", 0.4874486510183459F, 1.0F, 0.47559360706541765F);
        escalar(g0, "carga_38", 0.4947341328922804F, 1.0F, 0.47541779373582044F);
        escalar(g0, "carga_39", 0.4821383553487985F, 1.0F, 0.475153947308291F);
        escalar(g0, "carga_40", 0.4727648269793187F, 1.0F, 0.47659033169388615F);
        escalar(g0, "carga_41", 0.4934883111946192F, 1.0F, 0.4793099370144374F);
        escalar(g0, "carga_42", 0.4871333492232532F, 1.0F, 0.4811141427322622F);
        escalar(g0, "carga_43", 0.4852062901766832F, 1.0F, 0.48201361732574965F);
        escalar(g0, "carga_44", 0.4852062901766832F, 1.0F, 0.48201361732574965F);
        escalar(g0, "carga_45", 0.4871333492232532F, 1.0F, 0.4811141427322622F);
        escalar(g0, "carga_46", 0.4934883111946192F, 1.0F, 0.4793099370144374F);
        escalar(g0, "carga_47", 0.4727648269793187F, 1.0F, 0.47659033169388615F);
        escalar(g0, "carga_48", 0.4534126004738317F, 1.0F, 0.4813058082627482F);
        escalar(g0, "carga_49", 0.4909869620681985F, 1.0F, 0.4920142971717183F);
        escalar(g0, "carga_50", 0.48650211931215137F, 1.0F, 0.49902021829083193F);
        escalar(g0, "carga_51", 0.485145175351996F, 1.0F, 0.5024850169209883F);
        escalar(g0, "carga_52", 0.485145175351996F, 1.0F, 0.5024850169209883F);
        escalar(g0, "carga_53", 0.48650211931215137F, 1.0F, 0.49902021829083193F);
        escalar(g0, "carga_54", 0.4909869620681985F, 1.0F, 0.4920142971717183F);
        escalar(g0, "carga_55", 0.4534126004738317F, 1.0F, 0.4813058082627482F);
        escalar(g0, "carga_56", 0.5071752779915716F, 1.0F, 0.40063312845994953F);
        escalar(g0, "carga_57", 0.4872102899789206F, 1.0F, 0.47180599540183404F);
        escalar(g0, "carga_58", 0.4855537023977027F, 1.0F, 0.41066935328991094F);
        escalar(g0, "carga_59", 0.48505348837216966F, 1.0F, 0.42624594016157713F);
        escalar(g0, "carga_60", 0.48505348837216966F, 1.0F, 0.42624594016157713F);
        escalar(g0, "carga_61", 0.4855537023977027F, 1.0F, 0.41066935328991094F);
        escalar(g0, "carga_62", 0.4872102899789206F, 1.0F, 0.47180599540183404F);
        escalar(g0, "carga_63", 0.5071752779915716F, 1.0F, 0.40063312845994953F);
    }
}
