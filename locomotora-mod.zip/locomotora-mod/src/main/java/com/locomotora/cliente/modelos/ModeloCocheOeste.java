package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Coche del Oeste" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloCocheOeste {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("coche_oeste"), "main"),
            LocomotoraMod.id("textures/entity/coche_oeste.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -44.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -44.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -44.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -31.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -31.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -31.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -44.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -44.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -44.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -31.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -31.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -31.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 31.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 31.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 31.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 31.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 31.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 31.5F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.5F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.5F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 44.5F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloCocheOeste::crearCapa,
            16.0F,
            ModeloCocheOeste::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -38.0F, 38.0F)));

    private ModeloCocheOeste() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("caja", CubeListBuilder.create().texOffs(0, 40).addBox(-52.0F, -29.0F, 11.0F, 104.0F, 18.0F, 1.0F).texOffs(210, 40).addBox(-52.0F, -29.0F, -12.0F, 104.0F, 18.0F, 1.0F).texOffs(296, 0).addBox(-51.0F, -12.0F, -11.0F, 102.0F, 1.0F, 22.0F).texOffs(0, 0).addBox(-52.0F, -29.0F, -11.0F, 1.0F, 18.0F, 22.0F).texOffs(46, 0).addBox(51.0F, -29.0F, -11.0F, 1.0F, 18.0F, 22.0F), PartPose.ZERO);
        g.addOrReplaceChild("faldoni_0", CubeListBuilder.create().texOffs(550, 72).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-53.375F, -29.5F, -11.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_1", CubeListBuilder.create().texOffs(590, 72).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-38.125F, -29.5F, -11.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_2", CubeListBuilder.create().texOffs(630, 72).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-22.875F, -29.5F, -11.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_3", CubeListBuilder.create().texOffs(670, 72).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.625F, -29.5F, -11.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_4", CubeListBuilder.create().texOffs(710, 72).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.625F, -29.5F, -11.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_5", CubeListBuilder.create().texOffs(750, 72).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(22.875F, -29.5F, -11.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_6", CubeListBuilder.create().texOffs(790, 72).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.125F, -29.5F, -11.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_7", CubeListBuilder.create().texOffs(830, 72).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(53.375F, -29.5F, -11.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_8", CubeListBuilder.create().texOffs(870, 72).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-53.375F, -30.5F, -8.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_9", CubeListBuilder.create().texOffs(910, 72).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-38.125F, -30.5F, -8.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_10", CubeListBuilder.create().texOffs(950, 72).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-22.875F, -30.5F, -8.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_11", CubeListBuilder.create().texOffs(0, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.625F, -30.5F, -8.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_12", CubeListBuilder.create().texOffs(40, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.625F, -30.5F, -8.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_13", CubeListBuilder.create().texOffs(80, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(22.875F, -30.5F, -8.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_14", CubeListBuilder.create().texOffs(120, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.125F, -30.5F, -8.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldoni_15", CubeListBuilder.create().texOffs(160, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(53.375F, -30.5F, -8.0F, -2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_0", CubeListBuilder.create().texOffs(200, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-53.375F, -29.5F, 11.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_1", CubeListBuilder.create().texOffs(240, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-38.125F, -29.5F, 11.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_2", CubeListBuilder.create().texOffs(280, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-22.875F, -29.5F, 11.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_3", CubeListBuilder.create().texOffs(320, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.625F, -29.5F, 11.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_4", CubeListBuilder.create().texOffs(360, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.625F, -29.5F, 11.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_5", CubeListBuilder.create().texOffs(400, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(22.875F, -29.5F, 11.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_6", CubeListBuilder.create().texOffs(440, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.125F, -29.5F, 11.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_7", CubeListBuilder.create().texOffs(480, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(53.375F, -29.5F, 11.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_8", CubeListBuilder.create().texOffs(520, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-53.375F, -30.5F, 8.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_9", CubeListBuilder.create().texOffs(560, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-38.125F, -30.5F, 8.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_10", CubeListBuilder.create().texOffs(600, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-22.875F, -30.5F, 8.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_11", CubeListBuilder.create().texOffs(640, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-7.625F, -30.5F, 8.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_12", CubeListBuilder.create().texOffs(680, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.625F, -30.5F, 8.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_13", CubeListBuilder.create().texOffs(720, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(22.875F, -30.5F, 8.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_14", CubeListBuilder.create().texOffs(760, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.125F, -30.5F, 8.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("faldond_15", CubeListBuilder.create().texOffs(800, 80).addBox(-8.0F, -1.0F, -2.0F, 16.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(53.375F, -30.5F, 8.0F, 2.819842099193151F, 0.0F, 0.0F));
        g.addOrReplaceChild("linternai", CubeListBuilder.create().texOffs(754, 59).addBox(0.0F, -7.0F, -0.5F, 122.0F, 7.0F, 1.0F), PartPose.offset(-61.0F, -30.0F, -6.5F));
        g.addOrReplaceChild("linternad", CubeListBuilder.create().texOffs(0, 72).addBox(0.0F, -7.0F, -0.5F, 122.0F, 7.0F, 1.0F), PartPose.offset(-61.0F, -30.0F, 6.5F));
        g.addOrReplaceChild("techo_alto_0", CubeListBuilder.create().texOffs(156, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-58.96666666666667F, -32.50905335969227F, -6.25F, -2.948041013616741F, 0.0F, -0.7450999211840122F));
        g.addOrReplaceChild("techo_alto_1", CubeListBuilder.create().texOffs(426, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.900000000000006F, -34.875713505744834F, -6.25F, -2.8878460244853996F, 0.02928714392812976F, -0.2293177420158228F));
        g.addOrReplaceChild("techo_alto_2", CubeListBuilder.create().texOffs(442, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-50.83333333333333F, -35.49999347938591F, -6.25F, -2.8815150979725628F, 0.008147151260301834F, -0.06331525110709411F));
        g.addOrReplaceChild("techo_alto_3", CubeListBuilder.create().texOffs(458, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-46.766666666666666F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_4", CubeListBuilder.create().texOffs(474, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-42.7F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_5", CubeListBuilder.create().texOffs(490, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-38.63333333333333F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_6", CubeListBuilder.create().texOffs(506, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-34.56666666666666F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_7", CubeListBuilder.create().texOffs(522, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-30.5F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_8", CubeListBuilder.create().texOffs(538, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-26.433333333333337F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_9", CubeListBuilder.create().texOffs(554, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.366666666666667F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_10", CubeListBuilder.create().texOffs(570, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.300000000000004F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_11", CubeListBuilder.create().texOffs(586, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-14.233333333333334F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_12", CubeListBuilder.create().texOffs(602, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.166666666666664F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_13", CubeListBuilder.create().texOffs(618, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.099999999999998F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_14", CubeListBuilder.create().texOffs(634, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.0333333333333314F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_15", CubeListBuilder.create().texOffs(650, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.0333333333333314F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_16", CubeListBuilder.create().texOffs(666, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.099999999999994F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_17", CubeListBuilder.create().texOffs(682, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.166666666666664F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_18", CubeListBuilder.create().texOffs(698, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.233333333333334F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_19", CubeListBuilder.create().texOffs(714, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(18.299999999999997F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_20", CubeListBuilder.create().texOffs(730, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(22.36666666666666F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_21", CubeListBuilder.create().texOffs(746, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(26.433333333333323F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_22", CubeListBuilder.create().texOffs(762, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.499999999999993F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_23", CubeListBuilder.create().texOffs(778, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.56666666666667F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_24", CubeListBuilder.create().texOffs(794, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.63333333333334F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_25", CubeListBuilder.create().texOffs(810, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(42.7F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_26", CubeListBuilder.create().texOffs(826, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.766666666666666F, -35.63333333333333F, -6.25F, -2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_27", CubeListBuilder.create().texOffs(842, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.833333333333336F, -35.4999934793859F, -6.25F, -2.881515097972563F, -0.008147151260301834F, 0.06331525110709398F));
        g.addOrReplaceChild("techo_alto_28", CubeListBuilder.create().texOffs(858, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(54.900000000000006F, -34.875713505744834F, -6.25F, -2.8878460244853996F, -0.029287143928129835F, 0.22931774201582317F));
        g.addOrReplaceChild("techo_alto_29", CubeListBuilder.create().texOffs(174, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(58.96666666666667F, -32.50905335969226F, -6.25F, -2.948041013616741F, 0.0F, 0.7450999211840122F));
        g.addOrReplaceChild("techo_alto_30", CubeListBuilder.create().texOffs(192, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-58.96666666666667F, -33.04238669302559F, -3.75F, -3.0245271448550497F, 0.0F, -0.7450999211840125F));
        g.addOrReplaceChild("techo_alto_31", CubeListBuilder.create().texOffs(874, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.900000000000006F, -35.409046839078165F, -3.75F, -2.987271943912367F, 0.018324244323535216F, -0.23406143358586445F));
        g.addOrReplaceChild("techo_alto_32", CubeListBuilder.create().texOffs(890, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-50.83333333333333F, -36.03332681271924F, -3.75F, -2.9832696910794674F, 0.0051046087842514425F, -0.06466822395802364F));
        g.addOrReplaceChild("techo_alto_33", CubeListBuilder.create().texOffs(906, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-46.766666666666666F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_34", CubeListBuilder.create().texOffs(922, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-42.7F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_35", CubeListBuilder.create().texOffs(938, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-38.63333333333333F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_36", CubeListBuilder.create().texOffs(954, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-34.56666666666666F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_37", CubeListBuilder.create().texOffs(970, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-30.5F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_38", CubeListBuilder.create().texOffs(986, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-26.433333333333337F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_39", CubeListBuilder.create().texOffs(1002, 85).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.366666666666667F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_40", CubeListBuilder.create().texOffs(0, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.300000000000004F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_41", CubeListBuilder.create().texOffs(16, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-14.233333333333334F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_42", CubeListBuilder.create().texOffs(32, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.166666666666664F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_43", CubeListBuilder.create().texOffs(48, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.099999999999998F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_44", CubeListBuilder.create().texOffs(64, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.0333333333333314F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_45", CubeListBuilder.create().texOffs(80, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.0333333333333314F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_46", CubeListBuilder.create().texOffs(96, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.099999999999994F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_47", CubeListBuilder.create().texOffs(112, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.166666666666664F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_48", CubeListBuilder.create().texOffs(128, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.233333333333334F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_49", CubeListBuilder.create().texOffs(144, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(18.299999999999997F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_50", CubeListBuilder.create().texOffs(160, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(22.36666666666666F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_51", CubeListBuilder.create().texOffs(176, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(26.433333333333323F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_52", CubeListBuilder.create().texOffs(192, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.499999999999993F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_53", CubeListBuilder.create().texOffs(208, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.56666666666667F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_54", CubeListBuilder.create().texOffs(224, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.63333333333334F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("techo_alto_55", CubeListBuilder.create().texOffs(240, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(42.7F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_56", CubeListBuilder.create().texOffs(256, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.766666666666666F, -36.16666666666667F, -3.75F, -2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_57", CubeListBuilder.create().texOffs(272, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.833333333333336F, -36.03332681271924F, -3.75F, -2.9832696910794674F, -0.0051046087842514425F, 0.0646682239580235F));
        g.addOrReplaceChild("techo_alto_58", CubeListBuilder.create().texOffs(288, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(54.900000000000006F, -35.40904683907817F, -3.75F, -2.987271943912367F, -0.018324244323535216F, 0.23406143358586487F));
        g.addOrReplaceChild("techo_alto_59", CubeListBuilder.create().texOffs(210, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(58.96666666666667F, -33.0423866930256F, -3.75F, -3.0245271448550497F, 0.0F, 0.7450999211840125F));
        g.addOrReplaceChild("techo_alto_60", CubeListBuilder.create().texOffs(228, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-58.96666666666667F, -33.309053359692264F, -1.25F, -3.1024116405782425F, 0.0F, -0.7450999211840122F));
        g.addOrReplaceChild("techo_alto_61", CubeListBuilder.create().texOffs(304, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.900000000000006F, -35.67571350574483F, -1.25F, -3.089794420430788F, 0.006241611411674225F, -0.23658814885688614F));
        g.addOrReplaceChild("techo_alto_62", CubeListBuilder.create().texOffs(320, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-50.83333333333333F, -36.299993479385904F, -1.25F, -3.088423705132088F, 0.001740036126072577F, -0.06539061493032186F));
        g.addOrReplaceChild("techo_alto_63", CubeListBuilder.create().texOffs(336, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-46.766666666666666F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_64", CubeListBuilder.create().texOffs(352, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-42.7F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_65", CubeListBuilder.create().texOffs(368, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-38.63333333333333F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_66", CubeListBuilder.create().texOffs(384, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-34.56666666666666F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_67", CubeListBuilder.create().texOffs(400, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-30.5F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_68", CubeListBuilder.create().texOffs(416, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-26.433333333333337F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_69", CubeListBuilder.create().texOffs(432, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.366666666666667F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_70", CubeListBuilder.create().texOffs(448, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.300000000000004F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_71", CubeListBuilder.create().texOffs(464, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-14.233333333333334F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_72", CubeListBuilder.create().texOffs(480, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.166666666666664F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_73", CubeListBuilder.create().texOffs(496, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.099999999999998F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_74", CubeListBuilder.create().texOffs(512, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.0333333333333314F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_75", CubeListBuilder.create().texOffs(528, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.0333333333333314F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_76", CubeListBuilder.create().texOffs(544, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.099999999999994F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_77", CubeListBuilder.create().texOffs(560, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.166666666666664F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_78", CubeListBuilder.create().texOffs(576, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.233333333333334F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_79", CubeListBuilder.create().texOffs(592, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(18.299999999999997F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_80", CubeListBuilder.create().texOffs(608, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(22.36666666666666F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_81", CubeListBuilder.create().texOffs(624, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(26.433333333333323F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_82", CubeListBuilder.create().texOffs(640, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.499999999999993F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_83", CubeListBuilder.create().texOffs(656, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.56666666666667F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_84", CubeListBuilder.create().texOffs(672, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.63333333333334F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_85", CubeListBuilder.create().texOffs(688, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(42.7F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_86", CubeListBuilder.create().texOffs(704, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.766666666666666F, -36.43333333333334F, -1.25F, -3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_87", CubeListBuilder.create().texOffs(720, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.833333333333336F, -36.299993479385904F, -1.25F, -3.088423705132088F, -0.0017400361260724985F, 0.06539061493032174F));
        g.addOrReplaceChild("techo_alto_88", CubeListBuilder.create().texOffs(736, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(54.900000000000006F, -35.67571350574483F, -1.25F, -3.089794420430788F, -0.006241611411674304F, 0.23658814885688656F));
        g.addOrReplaceChild("techo_alto_89", CubeListBuilder.create().texOffs(246, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(58.96666666666667F, -33.309053359692264F, -1.25F, -3.1024116405782425F, 0.0F, 0.7450999211840122F));
        g.addOrReplaceChild("techo_alto_90", CubeListBuilder.create().texOffs(264, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-58.96666666666667F, -33.309053359692264F, 1.25F, 3.1024116405782425F, 0.0F, -0.7450999211840122F));
        g.addOrReplaceChild("techo_alto_91", CubeListBuilder.create().texOffs(752, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.900000000000006F, -35.67571350574483F, 1.25F, 3.089794420430788F, -0.006241611411674225F, -0.23658814885688614F));
        g.addOrReplaceChild("techo_alto_92", CubeListBuilder.create().texOffs(768, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-50.83333333333333F, -36.299993479385904F, 1.25F, 3.088423705132088F, -0.001740036126072577F, -0.06539061493032186F));
        g.addOrReplaceChild("techo_alto_93", CubeListBuilder.create().texOffs(784, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-46.766666666666666F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_94", CubeListBuilder.create().texOffs(800, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-42.7F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_95", CubeListBuilder.create().texOffs(816, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-38.63333333333333F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_96", CubeListBuilder.create().texOffs(832, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-34.56666666666666F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_97", CubeListBuilder.create().texOffs(848, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-30.5F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_98", CubeListBuilder.create().texOffs(864, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-26.433333333333337F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_99", CubeListBuilder.create().texOffs(880, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.366666666666667F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_100", CubeListBuilder.create().texOffs(896, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.300000000000004F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_101", CubeListBuilder.create().texOffs(912, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-14.233333333333334F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_102", CubeListBuilder.create().texOffs(928, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.166666666666664F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_103", CubeListBuilder.create().texOffs(944, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.099999999999998F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_104", CubeListBuilder.create().texOffs(960, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.0333333333333314F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_105", CubeListBuilder.create().texOffs(976, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.0333333333333314F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_106", CubeListBuilder.create().texOffs(992, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.099999999999994F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_107", CubeListBuilder.create().texOffs(1008, 90).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.166666666666664F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_108", CubeListBuilder.create().texOffs(0, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.233333333333334F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_109", CubeListBuilder.create().texOffs(16, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(18.299999999999997F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_110", CubeListBuilder.create().texOffs(32, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(22.36666666666666F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_111", CubeListBuilder.create().texOffs(48, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(26.433333333333323F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_112", CubeListBuilder.create().texOffs(64, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.499999999999993F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_113", CubeListBuilder.create().texOffs(80, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.56666666666667F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_114", CubeListBuilder.create().texOffs(96, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.63333333333334F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_115", CubeListBuilder.create().texOffs(112, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(42.7F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_116", CubeListBuilder.create().texOffs(128, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.766666666666666F, -36.43333333333334F, 1.25F, 3.088309802030101F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_117", CubeListBuilder.create().texOffs(144, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.833333333333336F, -36.299993479385904F, 1.25F, 3.088423705132088F, 0.0017400361260724985F, 0.06539061493032174F));
        g.addOrReplaceChild("techo_alto_118", CubeListBuilder.create().texOffs(160, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(54.900000000000006F, -35.67571350574484F, 1.25F, 3.089794420430788F, 0.006241611411674304F, 0.23658814885688656F));
        g.addOrReplaceChild("techo_alto_119", CubeListBuilder.create().texOffs(282, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(58.96666666666667F, -33.309053359692264F, 1.25F, 3.1024116405782425F, 0.0F, 0.7450999211840122F));
        g.addOrReplaceChild("techo_alto_120", CubeListBuilder.create().texOffs(300, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-58.96666666666667F, -33.0423866930256F, 3.749999999999999F, 3.0245271448550497F, 0.0F, -0.7450999211840122F));
        g.addOrReplaceChild("techo_alto_121", CubeListBuilder.create().texOffs(176, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.900000000000006F, -35.409046839078165F, 3.749999999999999F, 2.987271943912367F, -0.018324244323535216F, -0.23406143358586448F));
        g.addOrReplaceChild("techo_alto_122", CubeListBuilder.create().texOffs(192, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-50.83333333333333F, -36.03332681271924F, 3.749999999999999F, 2.9832696910794674F, -0.0051046087842514425F, -0.06466822395802363F));
        g.addOrReplaceChild("techo_alto_123", CubeListBuilder.create().texOffs(208, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-46.766666666666666F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_124", CubeListBuilder.create().texOffs(224, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-42.7F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_125", CubeListBuilder.create().texOffs(240, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-38.63333333333333F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_126", CubeListBuilder.create().texOffs(256, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-34.56666666666666F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_127", CubeListBuilder.create().texOffs(272, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-30.5F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_128", CubeListBuilder.create().texOffs(288, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-26.433333333333337F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_129", CubeListBuilder.create().texOffs(304, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.366666666666667F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_130", CubeListBuilder.create().texOffs(320, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.300000000000004F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_131", CubeListBuilder.create().texOffs(336, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-14.233333333333334F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_132", CubeListBuilder.create().texOffs(352, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.166666666666664F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_133", CubeListBuilder.create().texOffs(368, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.099999999999998F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_134", CubeListBuilder.create().texOffs(384, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.0333333333333314F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_135", CubeListBuilder.create().texOffs(400, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.0333333333333314F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_136", CubeListBuilder.create().texOffs(416, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.099999999999994F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_137", CubeListBuilder.create().texOffs(432, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.166666666666664F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_138", CubeListBuilder.create().texOffs(448, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.233333333333334F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_139", CubeListBuilder.create().texOffs(464, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(18.299999999999997F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_140", CubeListBuilder.create().texOffs(480, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(22.36666666666666F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_141", CubeListBuilder.create().texOffs(496, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(26.433333333333323F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_142", CubeListBuilder.create().texOffs(512, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.499999999999993F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_143", CubeListBuilder.create().texOffs(528, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.56666666666667F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_144", CubeListBuilder.create().texOffs(544, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.63333333333334F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("techo_alto_145", CubeListBuilder.create().texOffs(560, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(42.7F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_146", CubeListBuilder.create().texOffs(576, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.766666666666666F, -36.16666666666667F, 3.749999999999999F, 2.9829373914033925F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_147", CubeListBuilder.create().texOffs(592, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.833333333333336F, -36.03332681271924F, 3.749999999999999F, 2.9832696910794674F, 0.0051046087842514425F, 0.0646682239580235F));
        g.addOrReplaceChild("techo_alto_148", CubeListBuilder.create().texOffs(608, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(54.900000000000006F, -35.409046839078165F, 3.749999999999999F, 2.987271943912367F, 0.018324244323535216F, 0.23406143358586487F));
        g.addOrReplaceChild("techo_alto_149", CubeListBuilder.create().texOffs(318, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(58.96666666666667F, -33.0423866930256F, 3.749999999999999F, 3.0245271448550497F, 0.0F, 0.7450999211840122F));
        g.addOrReplaceChild("techo_alto_150", CubeListBuilder.create().texOffs(336, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-58.96666666666667F, -32.50905335969226F, 6.249999999999999F, 2.9480410136167405F, 0.0F, -0.745099921184012F));
        g.addOrReplaceChild("techo_alto_151", CubeListBuilder.create().texOffs(624, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-54.900000000000006F, -34.875713505744834F, 6.249999999999999F, 2.8878460244854F, -0.02928714392812976F, -0.22931774201582275F));
        g.addOrReplaceChild("techo_alto_152", CubeListBuilder.create().texOffs(640, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-50.83333333333333F, -35.49999347938591F, 6.249999999999999F, 2.881515097972563F, -0.008147151260301834F, -0.06331525110709413F));
        g.addOrReplaceChild("techo_alto_153", CubeListBuilder.create().texOffs(656, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-46.766666666666666F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_154", CubeListBuilder.create().texOffs(672, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-42.7F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_155", CubeListBuilder.create().texOffs(688, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-38.63333333333333F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_156", CubeListBuilder.create().texOffs(704, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-34.56666666666666F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_157", CubeListBuilder.create().texOffs(720, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-30.5F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_158", CubeListBuilder.create().texOffs(736, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-26.433333333333337F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_159", CubeListBuilder.create().texOffs(752, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.366666666666667F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_160", CubeListBuilder.create().texOffs(768, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-18.300000000000004F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_161", CubeListBuilder.create().texOffs(784, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-14.233333333333334F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_162", CubeListBuilder.create().texOffs(800, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.166666666666664F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_163", CubeListBuilder.create().texOffs(816, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.099999999999998F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_164", CubeListBuilder.create().texOffs(832, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.0333333333333314F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_165", CubeListBuilder.create().texOffs(848, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.0333333333333314F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_166", CubeListBuilder.create().texOffs(864, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(6.099999999999994F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_167", CubeListBuilder.create().texOffs(880, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.166666666666664F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_168", CubeListBuilder.create().texOffs(896, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.233333333333334F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_169", CubeListBuilder.create().texOffs(912, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(18.299999999999997F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_170", CubeListBuilder.create().texOffs(928, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(22.36666666666666F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_171", CubeListBuilder.create().texOffs(944, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(26.433333333333323F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_172", CubeListBuilder.create().texOffs(960, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(30.499999999999993F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_173", CubeListBuilder.create().texOffs(976, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(34.56666666666667F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_174", CubeListBuilder.create().texOffs(992, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.63333333333334F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_175", CubeListBuilder.create().texOffs(1008, 94).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(42.7F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_176", CubeListBuilder.create().texOffs(0, 98).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(46.766666666666666F, -35.63333333333333F, 6.249999999999999F, 2.8809902618424506F, 0.0F, 0.0F));
        g.addOrReplaceChild("techo_alto_177", CubeListBuilder.create().texOffs(16, 98).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(50.833333333333336F, -35.49999347938591F, 6.249999999999999F, 2.881515097972563F, 0.008147151260301834F, 0.06331525110709398F));
        g.addOrReplaceChild("techo_alto_178", CubeListBuilder.create().texOffs(32, 98).addBox(-2.5F, -1.0F, -1.5F, 5.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(54.900000000000006F, -34.875713505744834F, 6.249999999999999F, 2.8878460244854F, 0.02928714392812976F, 0.2293177420158232F));
        g.addOrReplaceChild("techo_alto_179", CubeListBuilder.create().texOffs(354, 85).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(58.96666666666667F, -32.50905335969227F, 6.249999999999999F, 2.9480410136167405F, 0.0F, 0.745099921184012F));
        g.addOrReplaceChild("plataformai", CubeListBuilder.create().texOffs(100, 0).addBox(-60.0F, -12.0F, -12.0F, 8.0F, 2.0F, 24.0F).texOffs(568, 59).addBox(-60.0F, -18.0F, -11.5F, 1.0F, 1.0F, 8.0F).texOffs(586, 59).addBox(-60.0F, -14.5F, -11.5F, 1.0F, 1.0F, 8.0F).texOffs(470, 72).addBox(-60.0F, -17.0F, -4.0F, 1.0F, 5.0F, 1.0F).texOffs(474, 72).addBox(-60.0F, -17.0F, -6.5F, 1.0F, 5.0F, 1.0F).texOffs(478, 72).addBox(-60.0F, -17.0F, -9.0F, 1.0F, 5.0F, 1.0F).texOffs(482, 72).addBox(-60.0F, -17.0F, -11.5F, 1.0F, 5.0F, 1.0F).texOffs(840, 80).addBox(-59.0F, -8.0F, -12.5F, 6.0F, 1.0F, 4.0F).texOffs(860, 80).addBox(-59.0F, -4.5F, -12.5F, 6.0F, 1.0F, 4.0F).texOffs(438, 72).addBox(-59.0F, -10.0F, -12.0F, 1.0F, 6.0F, 1.0F).texOffs(442, 72).addBox(-54.0F, -10.0F, -12.0F, 1.0F, 6.0F, 1.0F).texOffs(544, 59).addBox(-53.0F, -25.0F, -12.0F, 1.0F, 12.0F, 1.0F).texOffs(604, 59).addBox(-60.0F, -18.0F, 3.5F, 1.0F, 1.0F, 8.0F).texOffs(622, 59).addBox(-60.0F, -14.5F, 3.5F, 1.0F, 1.0F, 8.0F).texOffs(486, 72).addBox(-60.0F, -17.0F, 3.0F, 1.0F, 5.0F, 1.0F).texOffs(490, 72).addBox(-60.0F, -17.0F, 5.5F, 1.0F, 5.0F, 1.0F).texOffs(494, 72).addBox(-60.0F, -17.0F, 8.0F, 1.0F, 5.0F, 1.0F).texOffs(498, 72).addBox(-60.0F, -17.0F, 10.5F, 1.0F, 5.0F, 1.0F).texOffs(880, 80).addBox(-59.0F, -8.0F, 8.5F, 6.0F, 1.0F, 4.0F).texOffs(900, 80).addBox(-59.0F, -4.5F, 8.5F, 6.0F, 1.0F, 4.0F).texOffs(446, 72).addBox(-59.0F, -10.0F, 11.0F, 1.0F, 6.0F, 1.0F).texOffs(450, 72).addBox(-54.0F, -10.0F, 11.0F, 1.0F, 6.0F, 1.0F).texOffs(548, 59).addBox(-53.0F, -25.0F, 11.0F, 1.0F, 12.0F, 1.0F).texOffs(560, 59).addBox(-58.0F, -21.0F, -10.0F, 1.0F, 9.0F, 1.0F).texOffs(48, 98).addBox(-64.0F, -10.0F, -1.0F, 4.0F, 2.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("volantei", CubeListBuilder.create().texOffs(792, 0).addBox(-10.5F, 0.0F, -10.5F, 21.0F, 1.0F, 21.0F), PartPose.offsetAndRotation(-57.5F, -21.1F, -9.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("faroli", CubeListBuilder.create().texOffs(140, 85).addBox(-54.5F, -24.0F, -11.5F, 2.0F, 3.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("plataformad", CubeListBuilder.create().texOffs(164, 0).addBox(52.0F, -12.0F, -12.0F, 8.0F, 2.0F, 24.0F).texOffs(640, 59).addBox(59.0F, -18.0F, -11.5F, 1.0F, 1.0F, 8.0F).texOffs(658, 59).addBox(59.0F, -14.5F, -11.5F, 1.0F, 1.0F, 8.0F).texOffs(502, 72).addBox(59.0F, -17.0F, -4.0F, 1.0F, 5.0F, 1.0F).texOffs(506, 72).addBox(59.0F, -17.0F, -6.5F, 1.0F, 5.0F, 1.0F).texOffs(510, 72).addBox(59.0F, -17.0F, -9.0F, 1.0F, 5.0F, 1.0F).texOffs(514, 72).addBox(59.0F, -17.0F, -11.5F, 1.0F, 5.0F, 1.0F).texOffs(920, 80).addBox(53.0F, -8.0F, -12.5F, 6.0F, 1.0F, 4.0F).texOffs(940, 80).addBox(53.0F, -4.5F, -12.5F, 6.0F, 1.0F, 4.0F).texOffs(454, 72).addBox(53.0F, -10.0F, -12.0F, 1.0F, 6.0F, 1.0F).texOffs(458, 72).addBox(58.0F, -10.0F, -12.0F, 1.0F, 6.0F, 1.0F).texOffs(552, 59).addBox(52.0F, -25.0F, -12.0F, 1.0F, 12.0F, 1.0F).texOffs(676, 59).addBox(59.0F, -18.0F, 3.5F, 1.0F, 1.0F, 8.0F).texOffs(694, 59).addBox(59.0F, -14.5F, 3.5F, 1.0F, 1.0F, 8.0F).texOffs(518, 72).addBox(59.0F, -17.0F, 3.0F, 1.0F, 5.0F, 1.0F).texOffs(522, 72).addBox(59.0F, -17.0F, 5.5F, 1.0F, 5.0F, 1.0F).texOffs(526, 72).addBox(59.0F, -17.0F, 8.0F, 1.0F, 5.0F, 1.0F).texOffs(530, 72).addBox(59.0F, -17.0F, 10.5F, 1.0F, 5.0F, 1.0F).texOffs(960, 80).addBox(53.0F, -8.0F, 8.5F, 6.0F, 1.0F, 4.0F).texOffs(980, 80).addBox(53.0F, -4.5F, 8.5F, 6.0F, 1.0F, 4.0F).texOffs(462, 72).addBox(53.0F, -10.0F, 11.0F, 1.0F, 6.0F, 1.0F).texOffs(466, 72).addBox(58.0F, -10.0F, 11.0F, 1.0F, 6.0F, 1.0F).texOffs(556, 59).addBox(52.0F, -25.0F, 11.0F, 1.0F, 12.0F, 1.0F).texOffs(564, 59).addBox(57.0F, -21.0F, 9.0F, 1.0F, 9.0F, 1.0F).texOffs(60, 98).addBox(60.0F, -10.0F, -1.0F, 4.0F, 2.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("volanted", CubeListBuilder.create().texOffs(876, 0).addBox(-10.5F, 0.0F, -10.5F, 21.0F, 1.0F, 21.0F), PartPose.offsetAndRotation(57.5F, -21.1F, 9.5F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("farold", CubeListBuilder.create().texOffs(148, 85).addBox(52.5F, -24.0F, 9.5F, 2.0F, 3.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("bancos", CubeListBuilder.create().texOffs(0, 59).addBox(-49.0F, -16.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(488, 40).addBox(-50.0F, -22.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(24, 59).addBox(-49.0F, -16.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(508, 40).addBox(-50.0F, -22.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(48, 59).addBox(-40.0F, -16.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(528, 40).addBox(-41.0F, -22.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(72, 59).addBox(-40.0F, -16.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(548, 40).addBox(-41.0F, -22.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(96, 59).addBox(-31.0F, -16.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(568, 40).addBox(-32.0F, -22.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(120, 59).addBox(-31.0F, -16.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(588, 40).addBox(-32.0F, -22.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(144, 59).addBox(-22.0F, -16.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(608, 40).addBox(-23.0F, -22.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(168, 59).addBox(-22.0F, -16.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(628, 40).addBox(-23.0F, -22.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(192, 59).addBox(-13.0F, -16.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(648, 40).addBox(-14.0F, -22.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(216, 59).addBox(-13.0F, -16.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(668, 40).addBox(-14.0F, -22.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(240, 59).addBox(-4.0F, -16.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(688, 40).addBox(-5.0F, -22.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(264, 59).addBox(-4.0F, -16.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(708, 40).addBox(-5.0F, -22.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(288, 59).addBox(5.0F, -16.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(728, 40).addBox(4.0F, -22.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(312, 59).addBox(5.0F, -16.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(748, 40).addBox(4.0F, -22.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(336, 59).addBox(14.0F, -16.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(768, 40).addBox(13.0F, -22.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(360, 59).addBox(14.0F, -16.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(788, 40).addBox(13.0F, -22.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(384, 59).addBox(23.0F, -16.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(808, 40).addBox(22.0F, -22.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(408, 59).addBox(23.0F, -16.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(828, 40).addBox(22.0F, -22.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(432, 59).addBox(32.0F, -16.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(848, 40).addBox(31.0F, -22.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(456, 59).addBox(32.0F, -16.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(868, 40).addBox(31.0F, -22.0F, 2.0F, 1.0F, 10.0F, 9.0F).texOffs(480, 59).addBox(41.0F, -16.0F, -11.0F, 3.0F, 4.0F, 9.0F).texOffs(888, 40).addBox(40.0F, -22.0F, -11.0F, 1.0F, 10.0F, 9.0F).texOffs(504, 59).addBox(41.0F, -16.0F, 2.0F, 3.0F, 4.0F, 9.0F).texOffs(908, 40).addBox(40.0F, -22.0F, 2.0F, 1.0F, 10.0F, 9.0F), PartPose.ZERO);
        g.addOrReplaceChild("estufa", CubeListBuilder.create().texOffs(528, 59).addBox(-50.0F, -21.0F, 6.0F, 4.0F, 9.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("chimenea_estufa_0", CubeListBuilder.create().texOffs(420, 40).addBox(-6.0F, -35.0F, -2.5F, 12.0F, 14.0F, 5.0F).texOffs(228, 0).addBox(-2.5F, -35.0F, -6.0F, 5.0F, 14.0F, 12.0F), PartPose.offset(-48.0F, 0.0F, 8.0F));
        g.addOrReplaceChild("chimenea_estufa_1", CubeListBuilder.create().texOffs(454, 40).addBox(-6.0F, -35.0F, -2.5F, 12.0F, 14.0F, 5.0F).texOffs(262, 0).addBox(-2.5F, -35.0F, -6.0F, 5.0F, 14.0F, 12.0F), PartPose.offsetAndRotation(-48.0F, 0.0F, 8.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("lampara0", CubeListBuilder.create().texOffs(108, 98).addBox(-25.0F, -33.0F, -1.0F, 2.0F, 2.0F, 2.0F).texOffs(72, 98).addBox(-25.5F, -34.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("lampara1", CubeListBuilder.create().texOffs(116, 98).addBox(-1.0F, -33.0F, -1.0F, 2.0F, 2.0F, 2.0F).texOffs(84, 98).addBox(-1.5F, -34.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("lampara2", CubeListBuilder.create().texOffs(124, 98).addBox(23.0F, -33.0F, -1.0F, 2.0F, 2.0F, 2.0F).texOffs(96, 98).addBox(22.5F, -34.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(712, 59).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(372, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(730, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1000, 80).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-44.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(390, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(738, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-44.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(408, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-44.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(712, 59).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(372, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(730, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 80).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-31.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(390, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(738, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-31.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(408, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-31.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(712, 59).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(372, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(730, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 85).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-44.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(390, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(738, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-44.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(408, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-44.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(712, 59).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(372, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(730, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(10, 85).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-31.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(390, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(738, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-31.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(408, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-31.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(246, 72).addBox(-49.5F, -9.0F, 7.0F, 23.0F, 6.0F, 1.0F).texOffs(294, 72).addBox(-49.5F, -9.0F, -8.0F, 23.0F, 6.0F, 1.0F).texOffs(20, 85).addBox(-46.5F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(30, 85).addBox(-46.5F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(40, 85).addBox(-33.5F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(50, 85).addBox(-33.5F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_pivote", CubeListBuilder.create().texOffs(928, 40).addBox(-41.0F, -11.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(712, 59).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(372, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(730, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 85).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(31.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(390, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(738, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(31.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(408, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(31.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(712, 59).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(372, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(730, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 85).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(390, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(738, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(408, 85).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 59).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(712, 59).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(372, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(730, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 85).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(31.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(390, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(738, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(31.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(408, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(31.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(712, 59).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(372, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(730, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(90, 85).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(44.5F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(390, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(738, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.5F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(408, 85).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(746, 59).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(44.5F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(342, 72).addBox(26.5F, -9.0F, 7.0F, 23.0F, 6.0F, 1.0F).texOffs(390, 72).addBox(26.5F, -9.0F, -8.0F, 23.0F, 6.0F, 1.0F).texOffs(100, 85).addBox(29.5F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(110, 85).addBox(29.5F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(120, 85).addBox(42.5F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(130, 85).addBox(42.5F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_pivote", CubeListBuilder.create().texOffs(968, 40).addBox(35.0F, -11.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("bajo", CubeListBuilder.create().texOffs(544, 0).addBox(-52.0F, -11.0F, -10.0F, 104.0F, 2.0F, 20.0F).texOffs(534, 72).addBox(-15.5F, -9.0F, -8.0F, 1.0F, 5.0F, 1.0F).texOffs(538, 72).addBox(-15.5F, -9.0F, 7.0F, 1.0F, 5.0F, 1.0F).texOffs(542, 72).addBox(14.5F, -9.0F, -8.0F, 1.0F, 5.0F, 1.0F).texOffs(546, 72).addBox(14.5F, -9.0F, 7.0F, 1.0F, 5.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tirante_c2", CubeListBuilder.create().texOffs(92, 0).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 30.0F, 1.0F), PartPose.offsetAndRotation(-15.0F, -4.8F, -7.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("tirante_i2", CubeListBuilder.create().texOffs(960, 0).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 19.0F, 1.0F), PartPose.offsetAndRotation(-15.0F, -4.8F, -7.5F, 0.0F, 0.0F, 1.800028260071892F));
        g.addOrReplaceChild("tirante_d2", CubeListBuilder.create().texOffs(964, 0).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 19.0F, 1.0F), PartPose.offsetAndRotation(15.0F, -4.8F, -7.5F, 0.0F, 0.0F, -1.800028260071892F));
        g.addOrReplaceChild("tirante_c17", CubeListBuilder.create().texOffs(96, 0).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 30.0F, 1.0F), PartPose.offsetAndRotation(-15.0F, -4.8F, 7.5F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("tirante_i17", CubeListBuilder.create().texOffs(968, 0).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 19.0F, 1.0F), PartPose.offsetAndRotation(-15.0F, -4.8F, 7.5F, 0.0F, 0.0F, 1.800028260071892F));
        g.addOrReplaceChild("tirante_d17", CubeListBuilder.create().texOffs(972, 0).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 19.0F, 1.0F), PartPose.offsetAndRotation(15.0F, -4.8F, 7.5F, 0.0F, 0.0F, -1.800028260071892F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "faldoni_0", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_1", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_2", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_3", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_4", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_5", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_6", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_7", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_8", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_9", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_10", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_11", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_12", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_13", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_14", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldoni_15", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_0", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_1", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_2", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_3", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_4", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_5", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_6", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_7", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_8", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_9", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_10", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_11", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_12", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_13", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_14", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "faldond_15", 0.95625F, 1.0F, 0.8030694150420948F);
        escalar(g0, "techo_alto_0", 0.93045468361023F, 1.0F, 0.8791208164588902F);
        escalar(g0, "techo_alto_1", 0.8467046451951136F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_2", 0.8250802621676149F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_3", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_4", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_5", 0.8233333333333354F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_6", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_7", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_8", 0.8233333333333339F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_9", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_10", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_11", 0.8233333333333354F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_12", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_13", 0.8233333333333339F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_14", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_15", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_16", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_17", 0.8233333333333354F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_18", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_19", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_20", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_21", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_22", 0.8233333333333354F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_23", 0.8233333333333354F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_24", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_25", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_26", 0.8233333333333326F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_27", 0.8250802621676161F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_28", 0.8467046451951123F, 1.0F, 0.8791208164588906F);
        escalar(g0, "techo_alto_29", 0.93045468361023F, 1.0F, 0.8791208164588902F);
        escalar(g0, "techo_alto_30", 0.93045468361023F, 1.0F, 0.8605992600781441F);
        escalar(g0, "techo_alto_31", 0.8467046451951136F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_32", 0.8250802621676149F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_33", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_34", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_35", 0.8233333333333354F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_36", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_37", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_38", 0.8233333333333339F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_39", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_40", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_41", 0.8233333333333354F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_42", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_43", 0.8233333333333339F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_44", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_45", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_46", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_47", 0.8233333333333354F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_48", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_49", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_50", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_51", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_52", 0.8233333333333354F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_53", 0.8233333333333354F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_54", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_55", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_56", 0.8233333333333326F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_57", 0.8250802621676161F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_58", 0.8467046451951123F, 1.0F, 0.860599260078144F);
        escalar(g0, "techo_alto_59", 0.93045468361023F, 1.0F, 0.8605992600781441F);
        escalar(g0, "techo_alto_60", 0.9304546836102299F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_61", 0.8467046451951136F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_62", 0.8250802621676149F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_63", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_64", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_65", 0.8233333333333354F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_66", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_67", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_68", 0.8233333333333339F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_69", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_70", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_71", 0.8233333333333354F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_72", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_73", 0.8233333333333339F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_74", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_75", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_76", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_77", 0.8233333333333354F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_78", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_79", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_80", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_81", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_82", 0.8233333333333354F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_83", 0.8233333333333354F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_84", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_85", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_86", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_87", 0.8250802621676161F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_88", 0.8467046451951123F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_89", 0.9304546836102299F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_90", 0.9304546836102299F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_91", 0.8467046451951136F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_92", 0.8250802621676149F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_93", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_94", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_95", 0.8233333333333354F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_96", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_97", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_98", 0.8233333333333339F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_99", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_100", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_101", 0.8233333333333354F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_102", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_103", 0.8233333333333339F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_104", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_105", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_106", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_107", 0.8233333333333354F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_108", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_109", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_110", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_111", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_112", 0.8233333333333354F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_113", 0.8233333333333354F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_114", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_115", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_116", 0.8233333333333326F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_117", 0.8250802621676161F, 1.0F, 0.851184343583351F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "techo_alto_118", 0.8467046451951123F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_119", 0.9304546836102299F, 1.0F, 0.851184343583351F);
        escalar(g0, "techo_alto_120", 0.9304546836102299F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_121", 0.8467046451951136F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_122", 0.8250802621676149F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_123", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_124", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_125", 0.8233333333333354F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_126", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_127", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_128", 0.8233333333333339F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_129", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_130", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_131", 0.8233333333333354F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_132", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_133", 0.8233333333333339F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_134", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_135", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_136", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_137", 0.8233333333333354F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_138", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_139", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_140", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_141", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_142", 0.8233333333333354F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_143", 0.8233333333333354F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_144", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_145", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_146", 0.8233333333333326F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_147", 0.8250802621676161F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_148", 0.8467046451951123F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_149", 0.9304546836102299F, 1.0F, 0.8605992600781435F);
        escalar(g0, "techo_alto_150", 0.9304546836102298F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_151", 0.8467046451951136F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_152", 0.8250802621676149F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_153", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_154", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_155", 0.8233333333333354F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_156", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_157", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_158", 0.8233333333333339F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_159", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_160", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_161", 0.8233333333333354F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_162", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_163", 0.8233333333333339F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_164", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_165", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_166", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_167", 0.8233333333333354F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_168", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_169", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_170", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_171", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_172", 0.8233333333333354F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_173", 0.8233333333333354F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_174", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_175", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_176", 0.8233333333333326F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_177", 0.8250802621676161F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_178", 0.8467046451951123F, 1.0F, 0.8791208164588911F);
        escalar(g0, "techo_alto_179", 0.9304546836102298F, 1.0F, 0.8791208164588911F);
        escalar(g0, "volantei", 0.24761904761904763F, 0.6F, 0.24761904761904763F);
        escalar(g0, "volanted", 0.24761904761904763F, 0.6F, 0.24761904761904763F);
        escalar(g0, "chimenea_estufa_0", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "chimenea_estufa_1", 0.13858192987669302F, 1.0F, 0.13858192987669302F);
        escalar(g0, "tirante_c2", 0.8F, 1.0F, 0.8F);
        escalar(g0, "tirante_i2", 0.8F, 0.9728161137315388F, 0.8F);
        escalar(g0, "tirante_d2", 0.8F, 0.9728161137315388F, 0.8F);
        escalar(g0, "tirante_c17", 0.8F, 1.0F, 0.8F);
        escalar(g0, "tirante_i17", 0.8F, 0.9728161137315388F, 0.8F);
        escalar(g0, "tirante_d17", 0.8F, 0.9728161137315388F, 0.8F);
    }
}
