package com.locomotora.cliente;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;

/** Cosas del jugador de esta computadora (solo se usa del lado del cliente). */
public final class Local {
    private Local() {
    }

    /** ¿El jugador de esta computadora va sentado en {@code vehiculo}? */
    public static boolean vaEn(Entity vehiculo) {
        LocalPlayer jugador = Minecraft.getInstance().player;
        return jugador != null && jugador.getVehicle() == vehiculo;
    }
}
