package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Adler" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloAdler {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("adler"), "main"),
            LocomotoraMod.id("textures/entity/adler.png"),
            List.of(
                new DatosModelo.Animada("rdi0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -16.0F, -4.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rdi0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -16.0F, -4.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rdi0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -16.0F, -4.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rdd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -16.0F, -4.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rdd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -16.0F, -4.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rdd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -16.0F, -4.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmi0_0", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F, -6.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmi0_1", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F, -6.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmi0_2", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F, -6.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rmd0_0", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F, -6.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rmd0_1", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F, -6.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rmd0_2", DatosModelo.RUEDA, 6.0F, 0.0F, 0.0F, 0.0F, 0.0F, -6.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rti0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 15.0F, -4.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rti0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 15.0F, -4.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rti0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 15.0F, -4.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("rtd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 15.0F, -4.0F, 0.0F, "locomotora"),
                new DatosModelo.Animada("rtd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 15.0F, -4.0F, 0.5235987755982988F, "locomotora"),
                new DatosModelo.Animada("rtd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 15.0F, -4.0F, 1.0471975511965976F, "locomotora"),
                new DatosModelo.Animada("cab_manometro_aguja", DatosModelo.AGUJA, 1.0F, 0.0F, 3.9F, 0.0F, 15.719999999999999F, -19.4F, 0.0F, "locomotora", 4.8F, 0.0F, 3.9F),
                new DatosModelo.Animada("cab_palanca", DatosModelo.PALANCA, 1.0F, 0.0F, 0.0F, 0.0F, 18.0F, -12.0F, 0.0F, "locomotora", -0.22F, -5.5F, 0.0F),
                new DatosModelo.Animada("tri0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 31.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 31.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 31.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("tri1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 43.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("tri1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 43.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("tri1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 43.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 31.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 31.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 31.0F, -4.0F, 1.0471975511965976F, "tender"),
                new DatosModelo.Animada("trd1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 43.0F, -4.0F, 0.0F, "tender"),
                new DatosModelo.Animada("trd1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 43.0F, -4.0F, 0.5235987755982988F, "tender"),
                new DatosModelo.Animada("trd1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 43.0F, -4.0F, 1.0471975511965976F, "tender")),
            ModeloAdler::crearCapa,
            16.0F,
            ModeloAdler::preparar,
            List.of(
                new DatosModelo.Segmento("locomotora", -16.0F, 15.0F),
                new DatosModelo.Segmento("tender", 31.0F, 43.0F)));

    private ModeloAdler() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("locomotora", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("tender", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        piezas5(g1);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("locomotora");
        ModelPart g1 = raiz.getChild("tender");
        escalas0(g0, g1);
        escalas1(g0, g1);
        escalas2(g0, g1);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("rdi0_0", CubeListBuilder.create().texOffs(868, 76).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(48, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(928, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(888, 93).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-16.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rdi0_1", CubeListBuilder.create().texOffs(68, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(936, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rdi0_2", CubeListBuilder.create().texOffs(88, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(944, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rdd0_0", CubeListBuilder.create().texOffs(868, 76).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(48, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(928, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(898, 93).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-16.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rdd0_1", CubeListBuilder.create().texOffs(68, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(936, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rdd0_2", CubeListBuilder.create().texOffs(88, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(944, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmi0_0", CubeListBuilder.create().texOffs(592, 76).addBox(-6.0F, -6.0F, -6.0F, 12.0F, 12.0F, 2.0F).texOffs(804, 93).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(744, 76).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(908, 93).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(0.0F, -6.0F, 0.0F));
        g.addOrReplaceChild("rmi0_1", CubeListBuilder.create().texOffs(832, 93).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(754, 76).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmi0_2", CubeListBuilder.create().texOffs(860, 93).addBox(-6.0F, -1.5F, -6.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(764, 76).addBox(-1.5F, -6.0F, -6.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rmd0_0", CubeListBuilder.create().texOffs(592, 76).addBox(-6.0F, -6.0F, 4.0F, 12.0F, 12.0F, 2.0F).texOffs(804, 93).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(744, 76).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(918, 93).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(0.0F, -6.0F, 0.0F));
        g.addOrReplaceChild("rmd0_1", CubeListBuilder.create().texOffs(832, 93).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(754, 76).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -6.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rmd0_2", CubeListBuilder.create().texOffs(860, 93).addBox(-6.0F, -1.5F, 4.0F, 12.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(764, 76).addBox(-1.5F, -6.0F, 4.0F, 3.0F, 12.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(0.0F, -6.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rti0_0", CubeListBuilder.create().texOffs(888, 76).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(108, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(952, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(928, 93).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(15.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rti0_1", CubeListBuilder.create().texOffs(128, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(960, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(15.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rti0_2", CubeListBuilder.create().texOffs(148, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(968, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(15.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rtd0_0", CubeListBuilder.create().texOffs(888, 76).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(108, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(952, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(938, 93).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(15.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rtd0_1", CubeListBuilder.create().texOffs(128, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(960, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(15.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rtd0_2", CubeListBuilder.create().texOffs(148, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(968, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(15.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(516, 93).addBox(-23.0F, -9.0F, 6.5F, 44.0F, 4.0F, 1.0F).texOffs(606, 93).addBox(-23.0F, -9.0F, -7.5F, 44.0F, 4.0F, 1.0F).texOffs(920, 43).addBox(-24.0F, -11.0F, -8.0F, 1.0F, 7.0F, 16.0F).texOffs(988, 43).addBox(21.0F, -10.0F, -8.0F, 1.0F, 5.0F, 16.0F).texOffs(988, 93).addBox(-17.5F, -6.0F, 7.5F, 3.0F, 4.0F, 1.0F).texOffs(996, 93).addBox(-17.5F, -6.0F, -8.5F, 3.0F, 4.0F, 1.0F).texOffs(268, 119).addBox(-20.0F, -10.0F, 6.5F, 8.0F, 1.0F, 1.0F).texOffs(286, 119).addBox(-20.0F, -10.0F, -7.5F, 8.0F, 1.0F, 1.0F).texOffs(448, 119).addBox(-19.0F, -11.0F, 6.5F, 6.0F, 1.0F, 1.0F).texOffs(462, 119).addBox(-19.0F, -11.0F, -7.5F, 6.0F, 1.0F, 1.0F).texOffs(706, 102).addBox(-16.5F, -9.0F, 6.5F, 1.0F, 3.0F, 1.0F).texOffs(710, 102).addBox(-16.5F, -9.0F, -7.5F, 1.0F, 3.0F, 1.0F).texOffs(1004, 93).addBox(-1.5F, -8.0F, 7.5F, 3.0F, 4.0F, 1.0F).texOffs(1012, 93).addBox(-1.5F, -8.0F, -8.5F, 3.0F, 4.0F, 1.0F).texOffs(304, 119).addBox(-4.0F, -10.0F, 6.5F, 8.0F, 1.0F, 1.0F).texOffs(322, 119).addBox(-4.0F, -10.0F, -7.5F, 8.0F, 1.0F, 1.0F).texOffs(476, 119).addBox(-3.0F, -11.0F, 6.5F, 6.0F, 1.0F, 1.0F).texOffs(490, 119).addBox(-3.0F, -11.0F, -7.5F, 6.0F, 1.0F, 1.0F).texOffs(722, 119).addBox(-0.5F, -9.0F, 6.5F, 1.0F, 1.0F, 1.0F).texOffs(726, 119).addBox(-0.5F, -9.0F, -7.5F, 1.0F, 1.0F, 1.0F).texOffs(0, 102).addBox(13.5F, -6.0F, 7.5F, 3.0F, 4.0F, 1.0F).texOffs(8, 102).addBox(13.5F, -6.0F, -8.5F, 3.0F, 4.0F, 1.0F).texOffs(340, 119).addBox(11.0F, -10.0F, 6.5F, 8.0F, 1.0F, 1.0F).texOffs(358, 119).addBox(11.0F, -10.0F, -7.5F, 8.0F, 1.0F, 1.0F).texOffs(504, 119).addBox(12.0F, -11.0F, 6.5F, 6.0F, 1.0F, 1.0F).texOffs(518, 119).addBox(12.0F, -11.0F, -7.5F, 6.0F, 1.0F, 1.0F).texOffs(714, 102).addBox(14.5F, -9.0F, 6.5F, 1.0F, 3.0F, 1.0F).texOffs(718, 102).addBox(14.5F, -9.0F, -7.5F, 1.0F, 3.0F, 1.0F).texOffs(710, 119).addBox(-26.0F, -8.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tope_i_0", CubeListBuilder.create().texOffs(436, 43).addBox(-26.0F, -13.0F, -3.5F, 2.0F, 26.0F, 7.0F).texOffs(748, 0).addBox(-26.0F, -3.5F, -13.0F, 2.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -8.5F, -5.5F));
        g.addOrReplaceChild("tope_i_1", CubeListBuilder.create().texOffs(454, 43).addBox(-26.0F, -13.0F, -3.5F, 2.0F, 26.0F, 7.0F).texOffs(804, 0).addBox(-26.0F, -3.5F, -13.0F, 2.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -5.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_i_2", CubeListBuilder.create().texOffs(472, 43).addBox(-26.0F, -13.0F, -3.5F, 2.0F, 26.0F, 7.0F).texOffs(860, 0).addBox(-26.0F, -3.5F, -13.0F, 2.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -5.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_cabezai", CubeListBuilder.create().texOffs(488, 76).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(-27.05F, -8.5F, -5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("tope_cantoi_0", CubeListBuilder.create().texOffs(544, 43).addBox(-27.0F, -13.0F, -3.5F, 1.0F, 26.0F, 7.0F).texOffs(112, 43).addBox(-27.0F, -3.5F, -13.0F, 1.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -8.5F, -5.5F));
        g.addOrReplaceChild("tope_cantoi_1", CubeListBuilder.create().texOffs(560, 43).addBox(-27.0F, -13.0F, -3.5F, 1.0F, 26.0F, 7.0F).texOffs(166, 43).addBox(-27.0F, -3.5F, -13.0F, 1.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -5.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_cantoi_2", CubeListBuilder.create().texOffs(576, 43).addBox(-27.0F, -13.0F, -3.5F, 1.0F, 26.0F, 7.0F).texOffs(220, 43).addBox(-27.0F, -3.5F, -13.0F, 1.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -8.5F, -5.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_0", CubeListBuilder.create().texOffs(490, 43).addBox(-26.0F, -13.0F, -3.5F, 2.0F, 26.0F, 7.0F).texOffs(916, 0).addBox(-26.0F, -3.5F, -13.0F, 2.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -8.5F, 5.5F));
        g.addOrReplaceChild("tope_d_1", CubeListBuilder.create().texOffs(508, 43).addBox(-26.0F, -13.0F, -3.5F, 2.0F, 26.0F, 7.0F).texOffs(0, 43).addBox(-26.0F, -3.5F, -13.0F, 2.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 5.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_d_2", CubeListBuilder.create().texOffs(526, 43).addBox(-26.0F, -13.0F, -3.5F, 2.0F, 26.0F, 7.0F).texOffs(56, 43).addBox(-26.0F, -3.5F, -13.0F, 2.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 5.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_cabezad", CubeListBuilder.create().texOffs(540, 76).addBox(-6.5F, 0.0F, -6.5F, 13.0F, 1.0F, 13.0F), PartPose.offsetAndRotation(-27.05F, -8.5F, 5.5F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("tope_cantod_0", CubeListBuilder.create().texOffs(592, 43).addBox(-27.0F, -13.0F, -3.5F, 1.0F, 26.0F, 7.0F).texOffs(274, 43).addBox(-27.0F, -3.5F, -13.0F, 1.0F, 7.0F, 26.0F), PartPose.offset(0.0F, -8.5F, 5.5F));
        g.addOrReplaceChild("tope_cantod_1", CubeListBuilder.create().texOffs(608, 43).addBox(-27.0F, -13.0F, -3.5F, 1.0F, 26.0F, 7.0F).texOffs(328, 43).addBox(-27.0F, -3.5F, -13.0F, 1.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 5.5F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("tope_cantod_2", CubeListBuilder.create().texOffs(624, 43).addBox(-27.0F, -13.0F, -3.5F, 1.0F, 26.0F, 7.0F).texOffs(382, 43).addBox(-27.0F, -3.5F, -13.0F, 1.0F, 7.0F, 26.0F), PartPose.offsetAndRotation(0.0F, -8.5F, 5.5F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("estribo", CubeListBuilder.create().texOffs(196, 76).addBox(16.0F, -12.0F, -8.0F, 6.0F, 1.0F, 16.0F).texOffs(234, 93).addBox(21.0F, -20.0F, 7.0F, 1.0F, 8.0F, 1.0F).texOffs(238, 93).addBox(21.0F, -20.0F, -8.0F, 1.0F, 8.0F, 1.0F).texOffs(458, 76).addBox(21.0F, -20.0F, -7.0F, 1.0F, 1.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("guardabarrosi_0", CubeListBuilder.create().texOffs(1004, 113).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.782444100697286F, -6.892925705603696F, -5.05F, 0.0F, 1.5707963267948966F, 1.7016960206944713F));
        g.addOrReplaceChild("guardabarrosi_1", CubeListBuilder.create().texOffs(1014, 113).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.320231743753599F, -8.617925705603696F, -5.05F, 0.0F, 1.5707963267948966F, 1.963495408493621F));
        g.addOrReplaceChild("guardabarrosi_2", CubeListBuilder.create().texOffs(0, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.4273060381499025F, -10.16451839509359F, -5.05F, 0.0F, 1.5707963267948966F, 2.22529479629277F));
        g.addOrReplaceChild("guardabarrosi_3", CubeListBuilder.create().texOffs(10, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.164518395093589F, -11.427306038149904F, -5.05F, 0.0F, 1.5707963267948966F, 2.48709418409192F));
        g.addOrReplaceChild("guardabarrosi_4", CubeListBuilder.create().texOffs(20, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.6179257056036978F, -12.320231743753599F, -5.05F, 0.0F, 1.5707963267948966F, 2.7488935718910685F));
        g.addOrReplaceChild("guardabarrosi_5", CubeListBuilder.create().texOffs(30, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.8929257056036976F, -12.782444100697285F, -5.05F, 0.0F, 1.5707963267948966F, 3.0106929596902186F));
        g.addOrReplaceChild("guardabarrosi_6", CubeListBuilder.create().texOffs(40, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.8929257056036952F, -12.782444100697287F, -5.05F, 0.0F, 1.5707963267948966F, -3.0106929596902186F));
        g.addOrReplaceChild("guardabarrosi_7", CubeListBuilder.create().texOffs(50, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.617925705603695F, -12.320231743753599F, -5.05F, 0.0F, 1.5707963267948966F, -2.748893571891069F));
        g.addOrReplaceChild("guardabarrosi_8", CubeListBuilder.create().texOffs(60, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.164518395093588F, -11.427306038149903F, -5.05F, 0.0F, 1.5707963267948966F, -2.4870941840919207F));
        g.addOrReplaceChild("guardabarrosi_9", CubeListBuilder.create().texOffs(70, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.4273060381499025F, -10.164518395093591F, -5.05F, 0.0F, 1.5707963267948966F, -2.2252947962927707F));
        g.addOrReplaceChild("guardabarrosi_10", CubeListBuilder.create().texOffs(80, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.320231743753599F, -8.6179257056037F, -5.05F, 0.0F, 1.5707963267948966F, -1.9634954084936207F));
        g.addOrReplaceChild("guardabarrosi_11", CubeListBuilder.create().texOffs(90, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.782444100697285F, -6.892925705603698F, -5.05F, 0.0F, 1.5707963267948966F, -1.7016960206944718F));
        g.addOrReplaceChild("guardabarros_bordei", CubeListBuilder.create().texOffs(0, 76).addBox(0.0F, -16.0F, -0.5F, 32.0F, 16.0F, 1.0F), PartPose.offset(-8.0F, -6.0F, -6.75F));
        g.addOrReplaceChild("guardabarrosd_0", CubeListBuilder.create().texOffs(100, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.782444100697286F, -6.892925705603696F, 5.05F, 0.0F, -1.5707963267948966F, 1.7016960206944713F));
        g.addOrReplaceChild("guardabarrosd_1", CubeListBuilder.create().texOffs(110, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.320231743753599F, -8.617925705603696F, 5.05F, 0.0F, -1.5707963267948966F, 1.963495408493621F));
        g.addOrReplaceChild("guardabarrosd_2", CubeListBuilder.create().texOffs(120, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.4273060381499025F, -10.16451839509359F, 5.05F, 0.0F, -1.5707963267948966F, 2.22529479629277F));
        g.addOrReplaceChild("guardabarrosd_3", CubeListBuilder.create().texOffs(130, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.164518395093589F, -11.427306038149904F, 5.05F, 0.0F, -1.5707963267948966F, 2.48709418409192F));
        g.addOrReplaceChild("guardabarrosd_4", CubeListBuilder.create().texOffs(140, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.6179257056036978F, -12.320231743753599F, 5.05F, 0.0F, -1.5707963267948966F, 2.7488935718910685F));
        g.addOrReplaceChild("guardabarrosd_5", CubeListBuilder.create().texOffs(150, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.8929257056036976F, -12.782444100697285F, 5.05F, 0.0F, -1.5707963267948966F, 3.0106929596902186F));
        g.addOrReplaceChild("guardabarrosd_6", CubeListBuilder.create().texOffs(160, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.8929257056036952F, -12.782444100697287F, 5.05F, 0.0F, -1.5707963267948966F, -3.0106929596902186F));
        g.addOrReplaceChild("guardabarrosd_7", CubeListBuilder.create().texOffs(170, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.617925705603695F, -12.320231743753599F, 5.05F, 0.0F, -1.5707963267948966F, -2.748893571891069F));
        g.addOrReplaceChild("guardabarrosd_8", CubeListBuilder.create().texOffs(180, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.164518395093588F, -11.427306038149903F, 5.05F, 0.0F, -1.5707963267948966F, -2.4870941840919207F));
        g.addOrReplaceChild("guardabarrosd_9", CubeListBuilder.create().texOffs(190, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(5.4273060381499025F, -10.164518395093591F, 5.05F, 0.0F, -1.5707963267948966F, -2.2252947962927707F));
        g.addOrReplaceChild("guardabarrosd_10", CubeListBuilder.create().texOffs(200, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.320231743753599F, -8.6179257056037F, 5.05F, 0.0F, -1.5707963267948966F, -1.9634954084936207F));
        g.addOrReplaceChild("guardabarrosd_11", CubeListBuilder.create().texOffs(210, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.782444100697285F, -6.892925705603698F, 5.05F, 0.0F, -1.5707963267948966F, -1.7016960206944718F));
        g.addOrReplaceChild("guardabarros_borded", CubeListBuilder.create().texOffs(66, 76).addBox(0.0F, -16.0F, -0.5F, 32.0F, 16.0F, 1.0F), PartPose.offset(-8.0F, -6.0F, 6.75F));
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(988, 107).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -20.423333109150406F, 0.5823428514806717F, 3.0106929596902186F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(1006, 107).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -20.423333109150406F, 0.5823428514806717F, 3.0106929596902186F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(0, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -20.423333109150406F, 0.5823428514806717F, 3.0106929596902186F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(18, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -20.423333109150406F, 0.5823428514806717F, 3.0106929596902186F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(36, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -20.121890267665393F, 1.7073428514806714F, 2.748893571891069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(54, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -20.121890267665393F, 1.7073428514806714F, 2.748893571891069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(72, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -20.121890267665393F, 1.7073428514806714F, 2.748893571891069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(90, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -20.121890267665393F, 1.7073428514806714F, 2.748893571891069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(108, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -19.539547416184718F, 2.7159902576697315F, 2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(126, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -19.539547416184718F, 2.7159902576697315F, 2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(144, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -19.539547416184718F, 2.7159902576697315F, 2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(162, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -19.539547416184718F, 2.7159902576697315F, 2.4870941840919203F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(180, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -18.71599025766973F, 3.5395474161847185F, 2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(198, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -18.71599025766973F, 3.5395474161847185F, 2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(216, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -18.71599025766973F, 3.5395474161847185F, 2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(234, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -18.71599025766973F, 3.5395474161847185F, 2.2252947962927694F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(252, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -17.70734285148067F, 4.12189026766539F, 1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(270, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -17.70734285148067F, 4.12189026766539F, 1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(288, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -17.70734285148067F, 4.12189026766539F, 1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(306, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -17.70734285148067F, 4.12189026766539F, 1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(324, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -16.58234285148067F, 4.423333109150404F, 1.701696020694472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(342, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -16.58234285148067F, 4.423333109150404F, 1.701696020694472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(360, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -16.58234285148067F, 4.423333109150404F, 1.701696020694472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(378, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -16.58234285148067F, 4.423333109150404F, 1.701696020694472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(396, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -15.417657148519329F, 4.423333109150404F, 1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(414, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -15.417657148519329F, 4.423333109150404F, 1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(432, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -15.417657148519329F, 4.423333109150404F, 1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(450, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -15.417657148519329F, 4.423333109150404F, 1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(468, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -14.292657148519329F, 4.121890267665391F, 1.178097245096173F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(486, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -14.292657148519329F, 4.121890267665391F, 1.178097245096173F, 0.0F, 0.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(504, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -14.292657148519329F, 4.121890267665391F, 1.178097245096173F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(522, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -14.292657148519329F, 4.121890267665391F, 1.178097245096173F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(540, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -13.28400974233027F, 3.5395474161847194F, 0.9162978572970236F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(558, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -13.28400974233027F, 3.5395474161847194F, 0.9162978572970236F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(576, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -13.28400974233027F, 3.5395474161847194F, 0.9162978572970236F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(594, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -13.28400974233027F, 3.5395474161847194F, 0.9162978572970236F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(612, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -12.46045258381528F, 2.715990257669733F, 0.6544984694978736F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(630, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -12.46045258381528F, 2.715990257669733F, 0.6544984694978736F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(648, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -12.46045258381528F, 2.715990257669733F, 0.6544984694978736F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(666, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -12.46045258381528F, 2.715990257669733F, 0.6544984694978736F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(684, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -11.878109732334607F, 1.707342851480673F, 0.39269908169872425F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(702, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -11.878109732334607F, 1.707342851480673F, 0.39269908169872425F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(720, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -11.878109732334607F, 1.707342851480673F, 0.39269908169872425F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(738, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -11.878109732334607F, 1.707342851480673F, 0.39269908169872425F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(756, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -11.576666890849596F, 0.5823428514806726F, 0.1308996938995744F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(774, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -11.576666890849596F, 0.5823428514806726F, 0.1308996938995744F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(792, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -11.576666890849596F, 0.5823428514806726F, 0.1308996938995744F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(810, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -11.576666890849596F, 0.5823428514806726F, 0.1308996938995744F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(828, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -11.576666890849594F, -0.5823428514806706F, -0.13089969389957465F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(846, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -11.576666890849594F, -0.5823428514806706F, -0.13089969389957465F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(864, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -11.576666890849594F, -0.5823428514806706F, -0.13089969389957465F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(882, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -11.576666890849594F, -0.5823428514806706F, -0.13089969389957465F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(900, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -11.878109732334607F, -1.7073428514806694F, -0.3926990816987232F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(918, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -11.878109732334607F, -1.7073428514806694F, -0.3926990816987232F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(936, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -11.878109732334607F, -1.7073428514806694F, -0.3926990816987232F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(954, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -11.878109732334607F, -1.7073428514806694F, -0.3926990816987232F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(972, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -12.460452583815279F, -2.7159902576697306F, -0.6544984694978729F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(990, 110).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -12.460452583815279F, -2.7159902576697306F, -0.6544984694978729F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(0, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -12.460452583815279F, -2.7159902576697306F, -0.6544984694978729F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(18, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -12.460452583815279F, -2.7159902576697306F, -0.6544984694978729F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(36, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -13.284009742330266F, -3.539547416184718F, -0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(54, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -13.284009742330266F, -3.539547416184718F, -0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(72, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -13.284009742330266F, -3.539547416184718F, -0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(90, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -13.284009742330266F, -3.539547416184718F, -0.9162978572970233F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(108, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -14.292657148519325F, -4.12189026766539F, -1.1780972450961715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(126, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -14.292657148519325F, -4.12189026766539F, -1.1780972450961715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(144, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -14.292657148519325F, -4.12189026766539F, -1.1780972450961715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(162, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -14.292657148519325F, -4.12189026766539F, -1.1780972450961715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(180, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -15.417657148519327F, -4.423333109150404F, -1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(198, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -15.417657148519327F, -4.423333109150404F, -1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(216, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -15.417657148519327F, -4.423333109150404F, -1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(234, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -15.417657148519327F, -4.423333109150404F, -1.4398966328953218F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(252, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -16.58234285148067F, -4.423333109150404F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(270, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -16.58234285148067F, -4.423333109150404F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(288, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -16.58234285148067F, -4.423333109150404F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(306, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -16.58234285148067F, -4.423333109150404F, -1.7016960206944711F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(324, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -17.707342851480668F, -4.121890267665392F, -1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(342, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -17.707342851480668F, -4.121890267665392F, -1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(360, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -17.707342851480668F, -4.121890267665392F, -1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(378, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -17.707342851480668F, -4.121890267665392F, -1.9634954084936205F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(396, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -18.71599025766973F, -3.5395474161847202F, -2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(414, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -18.71599025766973F, -3.5395474161847202F, -2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(432, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -18.71599025766973F, -3.5395474161847202F, -2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(450, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -18.71599025766973F, -3.5395474161847202F, -2.2252947962927703F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(468, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -19.539547416184718F, -2.7159902576697332F, -2.487094184091917F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(486, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -19.539547416184718F, -2.7159902576697332F, -2.487094184091917F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(504, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -19.539547416184718F, -2.7159902576697332F, -2.487094184091917F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(522, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -19.539547416184718F, -2.7159902576697332F, -2.487094184091917F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(540, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -20.121890267665393F, -1.7073428514806746F, -2.7488935718910685F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(558, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -20.121890267665393F, -1.7073428514806746F, -2.7488935718910685F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(576, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -20.121890267665393F, -1.7073428514806746F, -2.7488935718910685F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(594, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -20.121890267665393F, -1.7073428514806746F, -2.7488935718910685F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(612, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-14.75F, -20.423333109150406F, -0.5823428514806741F, -3.010692959690219F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(630, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.25F, -20.423333109150406F, -0.5823428514806741F, -3.010692959690219F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(648, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.75F, -20.423333109150406F, -0.5823428514806741F, -3.010692959690219F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(666, 113).addBox(-3.5F, -1.0F, -1.0F, 7.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.75F, -20.423333109150406F, -0.5823428514806741F, -3.010692959690219F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_0", CubeListBuilder.create().texOffs(504, 0).addBox(-22.0F, -19.0F, -2.5F, 4.0F, 38.0F, 5.0F).texOffs(0, 0).addBox(-22.0F, -2.5F, -19.0F, 4.0F, 5.0F, 38.0F), PartPose.offset(0.0F, -16.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_1", CubeListBuilder.create().texOffs(522, 0).addBox(-22.0F, -19.0F, -2.5F, 4.0F, 38.0F, 5.0F).texOffs(84, 0).addBox(-22.0F, -2.5F, -19.0F, 4.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -16.0F, 0.0F, 0.2617993877991494F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_2", CubeListBuilder.create().texOffs(540, 0).addBox(-22.0F, -19.0F, -2.5F, 4.0F, 38.0F, 5.0F).texOffs(168, 0).addBox(-22.0F, -2.5F, -19.0F, 4.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -16.0F, 0.0F, 0.5235987755982988F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_3", CubeListBuilder.create().texOffs(558, 0).addBox(-22.0F, -19.0F, -2.5F, 4.0F, 38.0F, 5.0F).texOffs(252, 0).addBox(-22.0F, -2.5F, -19.0F, 4.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -16.0F, 0.0F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_4", CubeListBuilder.create().texOffs(576, 0).addBox(-22.0F, -19.0F, -2.5F, 4.0F, 38.0F, 5.0F).texOffs(336, 0).addBox(-22.0F, -2.5F, -19.0F, 4.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -16.0F, 0.0F, 1.0471975511965976F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_5", CubeListBuilder.create().texOffs(594, 0).addBox(-22.0F, -19.0F, -2.5F, 4.0F, 38.0F, 5.0F).texOffs(420, 0).addBox(-22.0F, -2.5F, -19.0F, 4.0F, 5.0F, 38.0F), PartPose.offsetAndRotation(0.0F, -16.0F, 0.0F, 1.3089969389957472F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta", CubeListBuilder.create().texOffs(612, 0).addBox(-17.0F, 0.0F, -17.0F, 34.0F, 1.0F, 34.0F), PartPose.offsetAndRotation(-22.05F, -16.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("puerta_aro", CubeListBuilder.create().texOffs(378, 93).addBox(-3.5F, 0.0F, -3.5F, 7.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-22.1F, -16.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("chimenea_base_0", CubeListBuilder.create().texOffs(416, 93).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(648, 76).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offset(-20.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_base_1", CubeListBuilder.create().texOffs(440, 93).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(672, 76).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-20.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_base_2", CubeListBuilder.create().texOffs(464, 93).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(696, 76).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-20.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_base_3", CubeListBuilder.create().texOffs(488, 93).addBox(-5.0F, -23.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(720, 76).addBox(-1.0F, -23.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-20.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea_0", CubeListBuilder.create().texOffs(722, 102).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.172314444114278F, -31.450000000000003F, 0.3635492607468353F, 0.1963495408493591F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_1", CubeListBuilder.create().texOffs(700, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.099207021878847F, -40.84F, 0.37809123117670873F, 0.19366015303735315F, -0.03259141888756071F, -1.4061472486455047F));
        g.addOrReplaceChild("chimenea_2", CubeListBuilder.create().texOffs(708, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.71443111537659F, -41.64F, 0.45462791764972665F, -2.993557735598713F, -0.12946644528488196F, -0.8572317494777967F));
        g.addOrReplaceChild("chimenea_3", CubeListBuilder.create().texOffs(716, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.691344560986455F, -42.0F, 0.45922011883810776F, 0.0F, 0.19634954084936218F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_4", CubeListBuilder.create().texOffs(798, 102).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.450563001987057F, -31.450000000000003F, 1.0353007028740553F, 0.5890486225480864F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_5", CubeListBuilder.create().texOffs(724, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.38858552206654F, -40.84F, 1.0767127309890174F, 0.5825311539003382F, -0.09292977684038818F, -1.4308590674828099F));
        g.addOrReplaceChild("chimenea_6", CubeListBuilder.create().texOffs(732, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.062388259326973F, -41.64F, 1.294670773699345F, -2.6771951676674224F, -0.37649167731482075F, -0.9376506008263514F));
        g.addOrReplaceChild("chimenea_7", CubeListBuilder.create().texOffs(740, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.0428164235626F, -42.0F, 1.307748256261965F, 0.0F, 0.5890486225480862F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_8", CubeListBuilder.create().texOffs(874, 102).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.964699297125946F, -31.450000000000003F, 1.5494369980129425F, 0.9817477042468118F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_9", CubeListBuilder.create().texOffs(748, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.923287269010984F, -40.84F, 1.61141447793346F, 0.9751948556492793F, -0.13932950240999317F, -1.4769545207650143F));
        g.addOrReplaceChild("chimenea_10", CubeListBuilder.create().texOffs(756, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.705329226300655F, -41.64F, 1.937611740673027F, -2.298758278154413F, -0.5826543658822885F, -1.114853658752474F));
        g.addOrReplaceChild("chimenea_11", CubeListBuilder.create().texOffs(764, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.692251743738034F, -42.0F, 1.957183576437401F, 0.0F, 0.9817477042468116F, -3.141592653589793F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("chimenea_12", CubeListBuilder.create().texOffs(0, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.636450739253164F, -31.450000000000003F, 1.8276855558857226F, 1.3744467859455343F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_13", CubeListBuilder.create().texOffs(772, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.62190876882329F, -40.84F, 1.9007929781211512F, 1.371722015680086F, -0.16456084257655537F, -1.5377584195785368F));
        g.addOrReplaceChild("chimenea_14", CubeListBuilder.create().texOffs(780, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.545372082350273F, -41.64F, 2.285568884623409F, -1.8301414178771587F, -0.7063416017651335F, -1.4002614167160727F));
        g.addOrReplaceChild("chimenea_15", CubeListBuilder.create().texOffs(788, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.540779881161892F, -42.0F, 2.308655439013544F, 0.0F, 1.3744467859455345F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_16", CubeListBuilder.create().texOffs(76, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.363549260746836F, -31.450000000000003F, 1.8276855558857223F, 1.7671458676442588F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_17", CubeListBuilder.create().texOffs(796, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.37809123117671F, -40.84F, 1.9007929781211512F, 1.7698706379097073F, -0.16456084257655537F, -1.6038342340112564F));
        g.addOrReplaceChild("chimenea_18", CubeListBuilder.create().texOffs(804, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.454627917649727F, -41.64F, 2.285568884623409F, -1.3114512357126344F, -0.7063416017651335F, -1.7413312368737204F));
        g.addOrReplaceChild("chimenea_19", CubeListBuilder.create().texOffs(812, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.459220118838108F, -42.0F, 2.308655439013544F, 3.141592653589793F, 1.3744467859455345F, 0.0F));
        g.addOrReplaceChild("chimenea_20", CubeListBuilder.create().texOffs(152, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.035300702874054F, -31.450000000000003F, 1.5494369980129425F, 2.159844949342981F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_21", CubeListBuilder.create().texOffs(820, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.076712730989016F, -40.84F, 1.6114144779334603F, 2.1663977979405136F, -0.13932950240999314F, -1.664638132824779F));
        g.addOrReplaceChild("chimenea_22", CubeListBuilder.create().texOffs(828, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.294670773699345F, -41.64F, 1.9376117406730273F, -0.8428343754353805F, -0.5826543658822885F, -2.026738994837319F));
        g.addOrReplaceChild("chimenea_23", CubeListBuilder.create().texOffs(836, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.307748256261966F, -42.0F, 1.9571835764374015F, 3.141592653589793F, 0.9817477042468113F, 0.0F));
        g.addOrReplaceChild("chimenea_24", CubeListBuilder.create().texOffs(228, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.549436998012943F, -31.450000000000003F, 1.0353007028740555F, 2.552544031041707F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_25", CubeListBuilder.create().texOffs(844, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.61141447793346F, -40.84F, 1.0767127309890177F, 2.559061499689455F, -0.09292977684038826F, -1.7107335861069832F));
        g.addOrReplaceChild("chimenea_26", CubeListBuilder.create().texOffs(852, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.937611740673027F, -41.64F, 1.2946707736993455F, -0.4643974859223708F, -0.37649167731482075F, -2.2039420527634417F));
        g.addOrReplaceChild("chimenea_27", CubeListBuilder.create().texOffs(860, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.9571835764374F, -42.0F, 1.3077482562619651F, 3.141592653589793F, 0.5890486225480864F, 0.0F));
        g.addOrReplaceChild("chimenea_28", CubeListBuilder.create().texOffs(304, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.827685555885722F, -31.450000000000003F, 0.36354926074683547F, 2.945243112740434F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_29", CubeListBuilder.create().texOffs(868, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.900792978121153F, -40.84F, 0.3780912311767089F, 2.94793250055244F, -0.032591418887560786F, -1.7354454049442887F));
        g.addOrReplaceChild("chimenea_30", CubeListBuilder.create().texOffs(876, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.28556888462341F, -41.64F, 0.45462791764972693F, -0.14803491799108046F, -0.12946644528488196F, -2.2843609041119963F));
        g.addOrReplaceChild("chimenea_31", CubeListBuilder.create().texOffs(884, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.308655439013542F, -42.0F, 0.45922011883810804F, 3.141592653589793F, 0.19634954084936218F, 0.0F));
        g.addOrReplaceChild("chimenea_32", CubeListBuilder.create().texOffs(380, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.827685555885722F, -31.450000000000003F, -0.3635492607468351F, -2.945243112740434F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_33", CubeListBuilder.create().texOffs(892, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.90079297812115F, -40.84F, -0.3780912311767085F, -2.94793250055244F, 0.03259141888756071F, -1.7354454049442885F));
        g.addOrReplaceChild("chimenea_34", CubeListBuilder.create().texOffs(900, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.28556888462341F, -41.64F, -0.45462791764972643F, 0.14803491799108048F, 0.12946644528488196F, -2.2843609041119963F));
        g.addOrReplaceChild("chimenea_35", CubeListBuilder.create().texOffs(908, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.308655439013545F, -42.0F, -0.45922011883810754F, -3.141592653589793F, -0.19634954084936204F, 0.0F));
        g.addOrReplaceChild("chimenea_36", CubeListBuilder.create().texOffs(456, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.549436998012943F, -31.450000000000003F, -1.0353007028740553F, -2.552544031041707F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_37", CubeListBuilder.create().texOffs(916, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.61141447793346F, -40.84F, -1.0767127309890174F, -2.5590614996894554F, 0.0929297768403881F, -1.7107335861069832F));
        g.addOrReplaceChild("chimenea_38", CubeListBuilder.create().texOffs(924, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.937611740673027F, -41.64F, -1.2946707736993448F, 0.46439748592237057F, 0.37649167731482075F, -2.2039420527634417F));
        g.addOrReplaceChild("chimenea_39", CubeListBuilder.create().texOffs(932, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.9571835764374F, -42.0F, -1.3077482562619647F, -3.141592653589793F, -0.5890486225480862F, 0.0F));
        g.addOrReplaceChild("chimenea_40", CubeListBuilder.create().texOffs(532, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.035300702874057F, -31.450000000000003F, -1.549436998012942F, -2.1598449493429834F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_41", CubeListBuilder.create().texOffs(940, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.076712730989016F, -40.84F, -1.61141447793346F, -2.1663977979405145F, 0.13932950240999276F, -1.6646381328247777F));
        g.addOrReplaceChild("chimenea_42", CubeListBuilder.create().texOffs(948, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.294670773699345F, -41.64F, -1.9376117406730269F, 0.8428343754353792F, 0.5826543658822884F, -2.0267389948373205F));
        g.addOrReplaceChild("chimenea_43", CubeListBuilder.create().texOffs(956, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.307748256261966F, -42.0F, -1.957183576437401F, -3.141592653589793F, -0.9817477042468098F, 0.0F));
        g.addOrReplaceChild("chimenea_44", CubeListBuilder.create().texOffs(608, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.363549260746836F, -31.450000000000003F, -1.8276855558857221F, -1.7671458676442586F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_45", CubeListBuilder.create().texOffs(964, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.37809123117671F, -40.84F, -1.9007929781211512F, -1.7698706379097071F, 0.16456084257655512F, -1.6038342340112555F));
        g.addOrReplaceChild("chimenea_46", CubeListBuilder.create().texOffs(972, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.454627917649727F, -41.64F, -2.285568884623409F, 1.3114512357126338F, 0.7063416017651333F, -1.741331236873722F));
        g.addOrReplaceChild("chimenea_47", CubeListBuilder.create().texOffs(980, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.459220118838108F, -42.0F, -2.308655439013544F, -3.141592653589793F, -1.3744467859455338F, 0.0F));
        g.addOrReplaceChild("chimenea_48", CubeListBuilder.create().texOffs(684, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.636450739253164F, -31.450000000000003F, -1.8276855558857223F, -1.374446785945534F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_49", CubeListBuilder.create().texOffs(988, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.62190876882329F, -40.84F, -1.900792978121151F, -1.3717220156800856F, 0.16456084257655532F, -1.5377584195785368F));
        g.addOrReplaceChild("chimenea_50", CubeListBuilder.create().texOffs(996, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.545372082350273F, -41.64F, -2.2855688846234083F, 1.8301414178771596F, 0.7063416017651333F, -1.4002614167160714F));
        g.addOrReplaceChild("chimenea_51", CubeListBuilder.create().texOffs(1004, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.540779881161892F, -42.0F, -2.308655439013544F, 0.0F, -1.3744467859455327F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_52", CubeListBuilder.create().texOffs(760, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.964699297125946F, -31.450000000000003F, -1.5494369980129425F, -0.9817477042468125F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_53", CubeListBuilder.create().texOffs(1012, 116).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.923287269010984F, -40.84F, -1.6114144779334603F, -0.97519485564928F, 0.13932950240999323F, -1.4769545207650143F));
        g.addOrReplaceChild("chimenea_54", CubeListBuilder.create().texOffs(0, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.705329226300655F, -41.64F, -1.937611740673027F, 2.298758278154414F, 0.5826543658822884F, -1.1148536587524727F));
        g.addOrReplaceChild("chimenea_55", CubeListBuilder.create().texOffs(8, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.692251743738034F, -42.0F, -1.9571835764374013F, 0.0F, -0.9817477042468098F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_56", CubeListBuilder.create().texOffs(836, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.450563001987057F, -31.450000000000003F, -1.0353007028740562F, -0.5890486225480869F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_57", CubeListBuilder.create().texOffs(16, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.38858552206654F, -40.84F, -1.0767127309890183F, -0.5825311539003387F, 0.09292977684038826F, -1.4308590674828099F));
        g.addOrReplaceChild("chimenea_58", CubeListBuilder.create().texOffs(24, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.062388259326973F, -41.64F, -1.294670773699346F, 2.677195167667422F, 0.376491677314821F, -0.9376506008263514F));
        g.addOrReplaceChild("chimenea_59", CubeListBuilder.create().texOffs(32, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.0428164235626F, -42.0F, -1.3077482562619658F, 0.0F, -0.5890486225480869F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_60", CubeListBuilder.create().texOffs(912, 107).addBox(-18.0F, -1.0F, -1.0F, 36.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.172314444114278F, -31.450000000000003F, -0.3635492607468361F, -0.19634954084935893F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("chimenea_61", CubeListBuilder.create().texOffs(40, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.099207021878847F, -40.84F, -0.3780912311767095F, -0.193660153037353F, 0.03259141888756087F, -1.4061472486455047F));
        g.addOrReplaceChild("chimenea_62", CubeListBuilder.create().texOffs(48, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.71443111537659F, -41.64F, -0.4546279176497277F, 2.993557735598713F, 0.12946644528488205F, -0.8572317494777969F));
        g.addOrReplaceChild("chimenea_63", CubeListBuilder.create().texOffs(56, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.691344560986458F, -42.0F, -0.45922011883810876F, 0.0F, -0.19634954084936226F, -3.141592653589793F));
        g.addOrReplaceChild("chimenea_hueco", CubeListBuilder.create().texOffs(132, 76).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-20.0F, -41.6F, 0.0F, 0.0F, 0.0F, 3.141592653589793F));
        g.addOrReplaceChild("hogar", CubeListBuilder.create().texOffs(954, 43).addBox(8.0F, -21.0F, -5.0F, 7.0F, 12.0F, 10.0F), PartPose.ZERO);
        g.addOrReplaceChild("cupula_0", CubeListBuilder.create().texOffs(228, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.90492762068456F, -21.76177152537082F, 0.6586298626761725F, 0.08042703482597427F, 0.004496413687599084F, -1.603674451045065F));
        g.addOrReplaceChild("cupula_1", CubeListBuilder.create().texOffs(572, 102).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.739877592713684F, -23.76238119705631F, 0.6267035225693298F, 0.07935642018389541F, 0.02268816427577339F, -1.7374676566572886F));
        g.addOrReplaceChild("cupula_2", CubeListBuilder.create().texOffs(584, 102).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.410003040814923F, -25.050507989849926F, 0.5628944625771048F, 0.07530232066075047F, 0.048205390510720175F, -1.9312992942076708F));
        g.addOrReplaceChild("cupula_3", CubeListBuilder.create().texOffs(64, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.912637737957942F, -25.988595274532976F, 0.4666869428840062F, 0.06431219987306787F, 0.08201913238464688F, -2.215853230885882F));
        g.addOrReplaceChild("cupula_4", CubeListBuilder.create().texOffs(72, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.229684687770877F, -26.610776035633897F, 0.3345803832830287F, 0.041063697287279766F, 0.11700235747839885F, -2.6062664748327173F));
        g.addOrReplaceChild("cupula_5", CubeListBuilder.create().texOffs(582, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.16897972833268F, -26.92207907926536F, 0.1294036395746678F, 0.009356562055732848F, 0.18982210249049875F, -3.025637901428262F));
        g.addOrReplaceChild("cupula_6", CubeListBuilder.create().texOffs(246, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.694976758988236F, -21.76177152537082F, 1.849920735429925F, 0.28621818730335813F, 0.017778707821242717F, -1.6015097920367614F));
        g.addOrReplaceChild("cupula_7", CubeListBuilder.create().texOffs(516, 102).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.540103862356355F, -23.76238119705631F, 1.7602479132319515F, 0.2825686770354134F, 0.06937427202394811F, -1.7325795275595437F));
        g.addOrReplaceChild("cupula_8", CubeListBuilder.create().texOffs(220, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.230569668355983F, -25.050507989849926F, 1.581024786742853F, 0.268751629493005F, 0.1470302691737637F, -1.9214270384172656F));
        g.addOrReplaceChild("cupula_9", CubeListBuilder.create().texOffs(230, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.76387235188389F, -25.988595274532976F, 1.3108027763690973F, 0.2308016043392301F, 0.24868137229538892F, -2.201443982721005F));
        g.addOrReplaceChild("cupula_10", CubeListBuilder.create().texOffs(80, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.123030793440101F, -26.610776035633897F, 0.9397496587665103F, 0.1486347110559826F, 0.3515746289456743F, -2.593041984103743F));
        g.addOrReplaceChild("cupula_11", CubeListBuilder.create().texOffs(590, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.12772984402748F, -26.92207907926536F, 0.36346131515597124F, 0.035802921651653774F, 0.5215330016437221F, -3.0180930870144778F));
        g.addOrReplaceChild("cupula_12", CubeListBuilder.create().texOffs(264, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.284788098630665F, -21.76177152537082F, 2.818642162439456F, 0.5261552925780131F, 0.027087925577137097F, -1.5975686512666405F));
        g.addOrReplaceChild("cupula_13", CubeListBuilder.create().texOffs(812, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.149798634895882F, -23.76238119705631F, 2.6820116611258933F, 0.5201146255119864F, 0.11475557968940457F, -1.7194977788564996F));
        g.addOrReplaceChild("cupula_14", CubeListBuilder.create().texOffs(240, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.88000414041435F, -25.050507989849926F, 2.408937333598563F, 0.49712291524348257F, 0.24260590801171183F, -1.8947217564203793F));
        g.addOrReplaceChild("cupula_15", CubeListBuilder.create().texOffs(250, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.473223988127447F, -25.988595274532976F, 1.9972120433895153F, 0.43216434651187907F, 0.40812723020719455F, -2.1613926431442514F));
        g.addOrReplaceChild("cupula_16", CubeListBuilder.create().texOffs(260, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.914657187902167F, -26.610776035633897F, 1.431854867944808F, 0.3090774989345624F, 0.6856852964778907F, -2.5120245813343516F));
        g.addOrReplaceChild("cupula_17", CubeListBuilder.create().texOffs(684, 113).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.69227723745291F, -21.76177152537082F, 3.580441841096569F, 0.8053848201247691F, 0.03440855264412852F, -1.591874300379033F));
        g.addOrReplaceChild("cupula_18", CubeListBuilder.create().texOffs(824, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.586009069764584F, -23.76238119705631F, 3.4068839591518483F, 0.7979635470617712F, 0.15823388192716517F, -1.693953075752622F));
        g.addOrReplaceChild("cupula_19", CubeListBuilder.create().texOffs(270, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.373617926132216F, -25.050507989849926F, 3.0600053233898796F, 0.7693740922821166F, 0.33411226355117707F, -1.841421155505243F));
        g.addOrReplaceChild("cupula_20", CubeListBuilder.create().texOffs(280, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.053387144858512F, -25.988595274532976F, 2.537002270449573F, 0.6848691305262334F, 0.5612978274665384F, -2.07668746654111F));
        g.addOrReplaceChild("cupula_21", CubeListBuilder.create().texOffs(598, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.613664897290406F, -26.610776035633897F, 1.8188449558742148F, 0.5226847286367439F, 0.8755399417170048F, -2.394955949857792F));
        g.addOrReplaceChild("cupula_22", CubeListBuilder.create().texOffs(700, 113).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.93882723866772F, -21.76177152537082F, 4.107827261556302F, 1.1176526253700716F, 0.03947686217350914F, -1.5846313102770708F));
        g.addOrReplaceChild("cupula_23", CubeListBuilder.create().texOffs(836, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.869081710291518F, -23.76238119705631F, 3.9087049658867423F, 1.1111621655542776F, 0.1935138804745992F, -1.6525311969501904F));
        g.addOrReplaceChild("cupula_24", CubeListBuilder.create().texOffs(290, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.729685945244443F, -25.050507989849926F, 3.510732430743407F, 1.0857438903856937F, 0.40891980254906274F, -1.7523485589738224F));
        g.addOrReplaceChild("cupula_25", CubeListBuilder.create().texOffs(300, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.519513270509298F, -25.988595274532976F, 2.9106930238507154F, 1.006430588329295F, 0.6902043900504894F, -1.9220540212164565F));
        g.addOrReplaceChild("cupula_26", CubeListBuilder.create().texOffs(606, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.23091640126284F, -26.610776035633897F, 2.086753877280129F, 0.8293263813437577F, 1.0263859983538357F, -2.1877201176522F));
        g.addOrReplaceChild("cupula_27", CubeListBuilder.create().texOffs(282, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.012267670970362F, -21.76177152537082F, 4.3777640837372935F, 1.438177972384102F, 0.04207154366922908F, -1.575722289734016F));
        g.addOrReplaceChild("cupula_28", CubeListBuilder.create().texOffs(848, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.987436073109484F, -23.76238119705631F, 4.165556904917593F, 1.4355883664256817F, 0.21179295927597733F, -1.5977099899209426F));
        g.addOrReplaceChild("cupula_29", CubeListBuilder.create().texOffs(310, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.937806804226641F, -25.050507989849926F, 3.7414324810477573F, 1.42532963514745F, 0.44842531037346944F, -1.631046435488938F));
        g.addOrReplaceChild("cupula_30", CubeListBuilder.create().texOffs(320, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.86297873335423F, -25.988595274532976F, 3.101962805945926F, 1.3924508484205163F, 0.7624535079974877F, -1.6906221795338263F));
        g.addOrReplaceChild("cupula_31", CubeListBuilder.create().texOffs(330, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.760229186997915F, -26.610776035633897F, 2.2238803128482716F, 1.291188487455038F, 1.1249593395391089F, -1.8181493036986216F));
        g.addOrReplaceChild("cupula_32", CubeListBuilder.create().texOffs(532, 119).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.600647275224743F, -26.92207907926536F, 0.8601167935705883F, 0.6521349483265647F, 1.4238765935069195F, -2.482783824492855F));
        g.addOrReplaceChild("cupula_33", CubeListBuilder.create().texOffs(300, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.98773232902965F, -21.76177152537082F, 4.3777640837372935F, 1.7034146812056883F, 0.04207154366922908F, -1.5658703638557774F));
        g.addOrReplaceChild("cupula_34", CubeListBuilder.create().texOffs(860, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.012563926890525F, -23.76238119705631F, 4.165556904917593F, 1.7060042871641086F, 0.21179295927597735F, -1.5438826636688512F));
        g.addOrReplaceChild("cupula_35", CubeListBuilder.create().texOffs(340, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.062193195773368F, -25.050507989849926F, 3.7414324810477577F, 1.7162630184423395F, 0.4484253103734696F, -1.5105462181008569F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("cupula_36", CubeListBuilder.create().texOffs(350, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.137021266645776F, -25.988595274532976F, 3.101962805945926F, 1.749141805169273F, 0.762453507997488F, -1.4509704740559692F));
        g.addOrReplaceChild("cupula_37", CubeListBuilder.create().texOffs(360, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.23977081300209F, -26.610776035633897F, 2.223880312848271F, 1.8504041661347495F, 1.1249593395391093F, -1.323443349891177F));
        g.addOrReplaceChild("cupula_38", CubeListBuilder.create().texOffs(542, 119).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.39935272477526F, -26.92207907926536F, 0.8601167935705883F, 2.48945770526322F, 1.4238765935069204F, -0.6588088290969468F));
        g.addOrReplaceChild("cupula_39", CubeListBuilder.create().texOffs(716, 113).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.061172761332282F, -21.76177152537082F, 4.107827261556303F, 2.0239400282197213F, 0.03947686217350914F, -1.5569613433127225F));
        g.addOrReplaceChild("cupula_40", CubeListBuilder.create().texOffs(872, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.130918289708482F, -23.76238119705631F, 3.908704965886743F, 2.0304304880355155F, 0.1935138804745993F, -1.4890614566396025F));
        g.addOrReplaceChild("cupula_41", CubeListBuilder.create().texOffs(370, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.27031405475556F, -25.050507989849926F, 3.510732430743408F, 2.055848763204099F, 0.40891980254906274F, -1.3892440946159712F));
        g.addOrReplaceChild("cupula_42", CubeListBuilder.create().texOffs(380, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.480486729490703F, -25.988595274532976F, 2.910693023850716F, 2.1351620652604972F, 0.6902043900504898F, -1.219538632373337F));
        g.addOrReplaceChild("cupula_43", CubeListBuilder.create().texOffs(614, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.769083598737158F, -26.610776035633897F, 2.0867538772801293F, 2.312266272246034F, 1.0263859983538361F, -0.9538725359375944F));
        g.addOrReplaceChild("cupula_44", CubeListBuilder.create().texOffs(732, 113).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.30772276254709F, -21.76177152537082F, 3.5804418410965697F, 2.336207833465024F, 0.03440855264412852F, -1.5497183532107603F));
        g.addOrReplaceChild("cupula_45", CubeListBuilder.create().texOffs(884, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.413990930235418F, -23.76238119705631F, 3.4068839591518483F, 2.343629106528022F, 0.15823388192716537F, -1.4476395778371705F));
        g.addOrReplaceChild("cupula_46", CubeListBuilder.create().texOffs(390, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.626382073867786F, -25.050507989849926F, 3.06000532338988F, 2.3722185613076774F, 0.3341122635511769F, -1.3001714980845507F));
        g.addOrReplaceChild("cupula_47", CubeListBuilder.create().texOffs(400, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.946612855141488F, -25.988595274532976F, 2.537002270449574F, 2.45672352306356F, 0.5612978274665381F, -1.0649051870486836F));
        g.addOrReplaceChild("cupula_48", CubeListBuilder.create().texOffs(622, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.386335102709594F, -26.610776035633897F, 1.8188449558742148F, 2.6189079249530494F, 0.8755399417170051F, -0.7466367037320014F));
        g.addOrReplaceChild("cupula_49", CubeListBuilder.create().texOffs(318, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.715211901369337F, -21.76177152537082F, 2.8186421624394575F, 2.6154373610117796F, 0.027087925577137184F, -1.5440240023231526F));
        g.addOrReplaceChild("cupula_50", CubeListBuilder.create().texOffs(896, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.85020136510412F, -23.76238119705631F, 2.6820116611258946F, 2.6214780280778065F, 0.11475557968940481F, -1.4220948747332927F));
        g.addOrReplaceChild("cupula_51", CubeListBuilder.create().texOffs(410, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.11999585958565F, -25.050507989849926F, 2.4089373335985638F, 2.6444697383463103F, 0.24260590801171195F, -1.246870897169414F));
        g.addOrReplaceChild("cupula_52", CubeListBuilder.create().texOffs(420, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.526776011872554F, -25.988595274532976F, 1.997212043389516F, 2.709428307077914F, 0.40812723020719444F, -0.9802000104455424F));
        g.addOrReplaceChild("cupula_53", CubeListBuilder.create().texOffs(430, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.085342812097833F, -26.610776035633897F, 1.4318548679448089F, 2.8325151546552307F, 0.6856852964778914F, -0.6295680722554421F));
        g.addOrReplaceChild("cupula_54", CubeListBuilder.create().texOffs(336, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.305023241011764F, -21.76177152537082F, 1.8499207354299265F, 2.855374466286436F, 0.01777870782124285F, -1.5400828615530315F));
        g.addOrReplaceChild("cupula_55", CubeListBuilder.create().texOffs(530, 102).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.459896137643646F, -23.76238119705631F, 1.7602479132319526F, 2.8590239765543797F, 0.06937427202394811F, -1.4090131260302494F));
        g.addOrReplaceChild("cupula_56", CubeListBuilder.create().texOffs(440, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.769430331644017F, -25.050507989849926F, 1.5810247867428544F, 2.8728410240967865F, 0.147030269173764F, -1.2201656151725278F));
        g.addOrReplaceChild("cupula_57", CubeListBuilder.create().texOffs(450, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.23612764811611F, -25.988595274532976F, 1.3108027763690984F, 2.9107910492505624F, 0.24868137229538936F, -0.9401486708687875F));
        g.addOrReplaceChild("cupula_58", CubeListBuilder.create().texOffs(88, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.8769692065599F, -26.610776035633897F, 0.939749658766511F, 2.99295794253381F, 0.35157462894567476F, -0.5485506694860515F));
        g.addOrReplaceChild("cupula_59", CubeListBuilder.create().texOffs(630, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.87227015597252F, -26.92207907926536F, 0.36346131515597146F, 3.1057897319381396F, 0.5215330016437224F, -0.12349956657531543F));
        g.addOrReplaceChild("cupula_60", CubeListBuilder.create().texOffs(354, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.09507237931544F, -21.76177152537082F, 0.6586298626761837F, 3.061165618763817F, 0.004496413687599241F, -1.537918202544728F));
        g.addOrReplaceChild("cupula_61", CubeListBuilder.create().texOffs(596, 102).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.260122407286318F, -23.76238119705631F, 0.6267035225693406F, 3.062236233405896F, 0.022688164275773862F, -1.4041249969325051F));
        g.addOrReplaceChild("cupula_62", CubeListBuilder.create().texOffs(608, 102).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.589996959185077F, -25.050507989849926F, 0.5628944625771146F, 3.0662903329290416F, 0.04820539051072072F, -1.2102933593821226F));
        g.addOrReplaceChild("cupula_63", CubeListBuilder.create().texOffs(96, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.087362262042058F, -25.988595274532976F, 0.46668694288401424F, 3.0772804537167238F, 0.08201913238464854F, -0.9257394227039103F));
        g.addOrReplaceChild("cupula_64", CubeListBuilder.create().texOffs(104, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.770315312229123F, -26.610776035633897F, 0.3345803832830344F, 3.100528956302512F, 0.11700235747840138F, -0.5353261787570763F));
        g.addOrReplaceChild("cupula_65", CubeListBuilder.create().texOffs(638, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.83102027166732F, -26.92207907926536F, 0.12940363957467F, 3.13223609153406F, 0.18982210249050188F, -0.1159547521615312F));
        g.addOrReplaceChild("cupula_66", CubeListBuilder.create().texOffs(372, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.09507237931544F, -21.76177152537082F, -0.6586298626761609F, -3.06116561876382F, -0.004496413687599005F, -1.5379182025447282F));
        g.addOrReplaceChild("cupula_67", CubeListBuilder.create().texOffs(620, 102).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.260122407286318F, -23.76238119705631F, -0.6267035225693187F, -3.062236233405899F, -0.022688164275773F, -1.4041249969325047F));
        g.addOrReplaceChild("cupula_68", CubeListBuilder.create().texOffs(632, 102).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.589996959185077F, -25.050507989849926F, -0.562894462577095F, -3.066290332929044F, -0.048205390510719315F, -1.2102933593821226F));
        g.addOrReplaceChild("cupula_69", CubeListBuilder.create().texOffs(112, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.087362262042058F, -25.988595274532976F, -0.4666869428839979F, -3.0772804537167264F, -0.08201913238464548F, -0.9257394227039112F));
        g.addOrReplaceChild("cupula_70", CubeListBuilder.create().texOffs(120, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.770315312229123F, -26.610776035633897F, -0.3345803832830228F, -3.1005289563025142F, -0.11700235747839687F, -0.535326178757076F));
        g.addOrReplaceChild("cupula_71", CubeListBuilder.create().texOffs(646, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.83102027166732F, -26.92207907926536F, -0.12940363957466552F, -3.1322360915340606F, -0.1898221024904955F, -0.11595475216153119F));
        g.addOrReplaceChild("cupula_72", CubeListBuilder.create().texOffs(390, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.305023241011764F, -21.76177152537082F, -1.8499207354299227F, -2.8553744662864364F, -0.017778707821242804F, -1.540082861553032F));
        g.addOrReplaceChild("cupula_73", CubeListBuilder.create().texOffs(544, 102).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.459896137643645F, -23.76238119705631F, -1.7602479132319493F, -2.8590239765543806F, -0.06937427202394787F, -1.4090131260302488F));
        g.addOrReplaceChild("cupula_74", CubeListBuilder.create().texOffs(460, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.769430331644017F, -25.050507989849926F, -1.5810247867428515F, -2.872841024096788F, -0.1470302691737636F, -1.2201656151725275F));
        g.addOrReplaceChild("cupula_75", CubeListBuilder.create().texOffs(470, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.23612764811611F, -25.988595274532976F, -1.3108027763690955F, -2.910791049250563F, -0.24868137229538875F, -0.9401486708687884F));
        g.addOrReplaceChild("cupula_76", CubeListBuilder.create().texOffs(128, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.876969206559899F, -26.610776035633897F, -0.9397496587665091F, -2.99295794253381F, -0.35157462894567415F, -0.5485506694860506F));
        g.addOrReplaceChild("cupula_77", CubeListBuilder.create().texOffs(654, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.87227015597252F, -26.92207907926536F, -0.3634613151559708F, -3.1057897319381396F, -0.5215330016437215F, -0.12349956657531541F));
        g.addOrReplaceChild("cupula_78", CubeListBuilder.create().texOffs(408, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(8.715211901369335F, -21.76177152537082F, -2.818642162439455F, -2.61543736101178F, -0.027087925577137184F, -1.5440240023231526F));
        g.addOrReplaceChild("cupula_79", CubeListBuilder.create().texOffs(908, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.850201365104118F, -23.76238119705631F, -2.682011661125892F, -2.6214780280778074F, -0.1147555796894045F, -1.422094874733293F));
        g.addOrReplaceChild("cupula_80", CubeListBuilder.create().texOffs(480, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.119995859585648F, -25.050507989849926F, -2.408937333598562F, -2.644469738346312F, -0.2426059080117114F, -1.246870897169414F));
        g.addOrReplaceChild("cupula_81", CubeListBuilder.create().texOffs(490, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.526776011872553F, -25.988595274532976F, -1.9972120433895144F, -2.709428307077915F, -0.408127230207194F, -0.9802000104455418F));
        g.addOrReplaceChild("cupula_82", CubeListBuilder.create().texOffs(500, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.085342812097833F, -26.610776035633897F, -1.4318548679448075F, -2.8325151546552316F, -0.6856852964778906F, -0.6295680722554414F));
        g.addOrReplaceChild("cupula_83", CubeListBuilder.create().texOffs(748, 113).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.307722762547089F, -21.76177152537082F, -3.5804418410965684F, -2.3362078334650245F, -0.03440855264412844F, -1.5497183532107603F));
        g.addOrReplaceChild("cupula_84", CubeListBuilder.create().texOffs(920, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.413990930235416F, -23.76238119705631F, -3.4068839591518474F, -2.343629106528023F, -0.15823388192716517F, -1.4476395778371711F));
        g.addOrReplaceChild("cupula_85", CubeListBuilder.create().texOffs(510, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.626382073867784F, -25.050507989849926F, -3.060005323389879F, -2.3722185613076774F, -0.33411226355117696F, -1.3001714980845502F));
        g.addOrReplaceChild("cupula_86", CubeListBuilder.create().texOffs(520, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(9.946612855141488F, -25.988595274532976F, -2.537002270449573F, -2.45672352306356F, -0.5612978274665384F, -1.0649051870486825F));
        g.addOrReplaceChild("cupula_87", CubeListBuilder.create().texOffs(662, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.386335102709594F, -26.610776035633897F, -1.8188449558742141F, -2.618907924953049F, -0.8755399417170048F, -0.7466367037320014F));
        g.addOrReplaceChild("cupula_88", CubeListBuilder.create().texOffs(764, 113).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.061172761332278F, -21.76177152537082F, -4.107827261556302F, -2.0239400282197226F, -0.03947686217350905F, -1.5569613433127225F));
        g.addOrReplaceChild("cupula_89", CubeListBuilder.create().texOffs(932, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.13091828970848F, -23.76238119705631F, -3.908704965886742F, -2.0304304880355164F, -0.1935138804745991F, -1.489061456639603F));
        g.addOrReplaceChild("cupula_90", CubeListBuilder.create().texOffs(530, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.270314054755557F, -25.050507989849926F, -3.5107324307434062F, -2.0558487632041005F, -0.4089198025490627F, -1.3892440946159708F));
        g.addOrReplaceChild("cupula_91", CubeListBuilder.create().texOffs(540, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.480486729490702F, -25.988595274532976F, -2.9106930238507145F, -2.1351620652605F, -0.690204390050489F, -1.2195386323733355F));
        g.addOrReplaceChild("cupula_92", CubeListBuilder.create().texOffs(670, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.769083598737158F, -26.610776035633897F, -2.0867538772801284F, -2.3122662722460365F, -1.0263859983538357F, -0.953872535937593F));
        g.addOrReplaceChild("cupula_93", CubeListBuilder.create().texOffs(426, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.987732329029631F, -21.76177152537082F, -4.3777640837372935F, -1.703414681205693F, -0.04207154366922908F, -1.565870363855777F));
        g.addOrReplaceChild("cupula_94", CubeListBuilder.create().texOffs(944, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.01256392689051F, -23.76238119705631F, -4.165556904917593F, -1.7060042871641132F, -0.21179295927597733F, -1.5438826636688503F));
        g.addOrReplaceChild("cupula_95", CubeListBuilder.create().texOffs(550, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.062193195773352F, -25.050507989849926F, -3.7414324810477573F, -1.7162630184423446F, -0.4484253103734694F, -1.5105462181008549F));
        g.addOrReplaceChild("cupula_96", CubeListBuilder.create().texOffs(560, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.137021266645764F, -25.988595274532976F, -3.101962805945926F, -1.749141805169279F, -0.7624535079974876F, -1.450970474055965F));
        g.addOrReplaceChild("cupula_97", CubeListBuilder.create().texOffs(570, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.239770813002083F, -26.610776035633897F, -2.2238803128482716F, -1.8504041661347592F, -1.1249593395391084F, -1.323443349891168F));
        g.addOrReplaceChild("cupula_98", CubeListBuilder.create().texOffs(552, 119).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.399352724775255F, -26.92207907926536F, -0.8601167935705883F, -2.489457705263237F, -1.4238765935069182F, -0.6588088290969297F));
        g.addOrReplaceChild("cupula_99", CubeListBuilder.create().texOffs(444, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(12.012267670970344F, -21.76177152537082F, -4.3777640837372935F, -1.4381779723841068F, -0.04207154366922908F, -1.5757222897340155F));
        g.addOrReplaceChild("cupula_100", CubeListBuilder.create().texOffs(956, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.987436073109468F, -23.76238119705631F, -4.165556904917593F, -1.4355883664256865F, -0.21179295927597744F, -1.5977099899209417F));
        g.addOrReplaceChild("cupula_101", CubeListBuilder.create().texOffs(580, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.937806804226627F, -25.050507989849926F, -3.7414324810477577F, -1.4253296351474556F, -0.4484253103734696F, -1.631046435488936F));
        g.addOrReplaceChild("cupula_102", CubeListBuilder.create().texOffs(590, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.862978733354218F, -25.988595274532976F, -3.101962805945926F, -1.392450848420523F, -0.7624535079974882F, -1.6906221795338219F));
        g.addOrReplaceChild("cupula_103", CubeListBuilder.create().texOffs(600, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(11.760229186997906F, -26.610776035633897F, -2.223880312848271F, -1.2911884874550479F, -1.1249593395391098F, -1.8181493036986127F));
        g.addOrReplaceChild("cupula_104", CubeListBuilder.create().texOffs(562, 119).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(11.60064727522474F, -26.92207907926536F, -0.8601167935705883F, -0.6521349483265798F, -1.4238765935069226F, -2.48278382449284F));
        g.addOrReplaceChild("cupula_105", CubeListBuilder.create().texOffs(780, 113).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.938827238667718F, -21.76177152537082F, -4.107827261556304F, -1.1176526253700718F, -0.03947686217350914F, -1.5846313102770704F));
        g.addOrReplaceChild("cupula_106", CubeListBuilder.create().texOffs(968, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.869081710291518F, -23.76238119705631F, -3.908704965886744F, -1.1111621655542785F, -0.1935138804745991F, -1.6525311969501901F));
        g.addOrReplaceChild("cupula_107", CubeListBuilder.create().texOffs(610, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.72968594524444F, -25.050507989849926F, -3.510732430743408F, -1.0857438903856944F, -0.4089198025490631F, -1.7523485589738224F));
        g.addOrReplaceChild("cupula_108", CubeListBuilder.create().texOffs(620, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.519513270509297F, -25.988595274532976F, -2.910693023850716F, -1.0064305883292957F, -0.6902043900504898F, -1.9220540212164565F));
        g.addOrReplaceChild("cupula_109", CubeListBuilder.create().texOffs(678, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.230916401262842F, -26.610776035633897F, -2.0867538772801293F, -0.8293263813437601F, -1.0263859983538364F, -2.1877201176521974F));
        g.addOrReplaceChild("cupula_110", CubeListBuilder.create().texOffs(796, 113).addBox(-3.0F, -1.0F, -1.0F, 6.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.69227723745291F, -21.76177152537082F, -3.58044184109657F, -0.8053848201247709F, -0.03440855264412852F, -1.5918743003790325F));
        g.addOrReplaceChild("cupula_111", CubeListBuilder.create().texOffs(980, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.586009069764582F, -23.76238119705631F, -3.406883959151849F, -0.7979635470617713F, -0.15823388192716523F, -1.6939530757526222F));
        g.addOrReplaceChild("cupula_112", CubeListBuilder.create().texOffs(630, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.373617926132214F, -25.050507989849926F, -3.0600053233898805F, -0.7693740922821156F, -0.33411226355117724F, -1.8414211555052433F));
        g.addOrReplaceChild("cupula_113", CubeListBuilder.create().texOffs(640, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.053387144858512F, -25.988595274532976F, -2.537002270449574F, -0.6848691305262343F, -0.5612978274665386F, -2.0766874665411095F));
        g.addOrReplaceChild("cupula_114", CubeListBuilder.create().texOffs(686, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.613664897290407F, -26.610776035633897F, -1.8188449558742152F, -0.5226847286367448F, -0.8755399417170054F, -2.394955949857791F));
        g.addOrReplaceChild("cupula_115", CubeListBuilder.create().texOffs(462, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.284788098630663F, -21.76177152537082F, -2.8186421624394575F, -0.5261552925780136F, -0.027087925577137184F, -1.5975686512666405F));
        g.addOrReplaceChild("cupula_116", CubeListBuilder.create().texOffs(992, 113).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.14979863489588F, -23.76238119705631F, -2.6820116611258946F, -0.5201146255119867F, -0.11475557968940481F, -1.7194977788565007F));
        g.addOrReplaceChild("cupula_117", CubeListBuilder.create().texOffs(650, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.88000414041435F, -25.050507989849926F, -2.4089373335985638F, -0.49712291524348295F, -0.24260590801171208F, -1.8947217564203793F));
        g.addOrReplaceChild("cupula_118", CubeListBuilder.create().texOffs(660, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.473223988127446F, -25.988595274532976F, -1.997212043389516F, -0.43216434651187907F, -0.40812723020719444F, -2.161392643144251F));
        g.addOrReplaceChild("cupula_119", CubeListBuilder.create().texOffs(670, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.914657187902167F, -26.610776035633897F, -1.4318548679448089F, -0.30907749893456227F, -0.6856852964778912F, -2.512024581334351F));
        g.addOrReplaceChild("cupula_120", CubeListBuilder.create().texOffs(480, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.694976758988236F, -21.76177152537082F, -1.849920735429928F, -0.2862181873033578F, -0.01777870782124285F, -1.6015097920367616F));
        g.addOrReplaceChild("cupula_121", CubeListBuilder.create().texOffs(558, 102).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.540103862356355F, -23.76238119705631F, -1.7602479132319542F, -0.28256867703541394F, -0.06937427202394802F, -1.7325795275595437F));
        g.addOrReplaceChild("cupula_122", CubeListBuilder.create().texOffs(680, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.230569668355983F, -25.050507989849926F, -1.5810247867428557F, -0.2687516294930071F, -0.1470302691737644F, -1.9214270384172656F));
        g.addOrReplaceChild("cupula_123", CubeListBuilder.create().texOffs(690, 116).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.76387235188389F, -25.988595274532976F, -1.310802776369099F, -0.23080160433923114F, -0.24868137229538978F, -2.2014439827210057F));
        g.addOrReplaceChild("cupula_124", CubeListBuilder.create().texOffs(136, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.123030793440101F, -26.610776035633897F, -0.9397496587665116F, -0.14863471105598317F, -0.3515746289456751F, -2.593041984103742F));
        g.addOrReplaceChild("cupula_125", CubeListBuilder.create().texOffs(694, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.12772984402748F, -26.92207907926536F, -0.3634613151559718F, -0.035802921651653836F, -0.5215330016437227F, -3.0180930870144778F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("cupula_126", CubeListBuilder.create().texOffs(498, 102).addBox(-3.0F, -1.0F, -1.5F, 6.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.904927620684562F, -21.76177152537082F, -0.6586298626761942F, -0.08042703482597716F, -0.004496413687599241F, -1.6036744510450653F));
        g.addOrReplaceChild("cupula_127", CubeListBuilder.create().texOffs(644, 102).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.739877592713682F, -23.76238119705631F, -0.6267035225693505F, -0.0793564201838983F, -0.022688164275774178F, -1.737467656657288F));
        g.addOrReplaceChild("cupula_128", CubeListBuilder.create().texOffs(656, 102).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(14.410003040814921F, -25.050507989849926F, -0.5628944625771234F, -0.0753023206607525F, -0.04820539051072159F, -1.9312992942076708F));
        g.addOrReplaceChild("cupula_129", CubeListBuilder.create().texOffs(144, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.91263773795794F, -25.988595274532976F, -0.4666869428840215F, -0.06431219987307035F, -0.08201913238464972F, -2.215853230885883F));
        g.addOrReplaceChild("cupula_130", CubeListBuilder.create().texOffs(152, 119).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(13.229684687770877F, -26.610776035633897F, -0.3345803832830397F, -0.04106369728728163F, -0.11700235747840303F, -2.606266474832717F));
        g.addOrReplaceChild("cupula_131", CubeListBuilder.create().texOffs(702, 119).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.16897972833268F, -26.92207907926536F, -0.12940363957467205F, -0.009356562055733106F, -0.18982210249050482F, -3.025637901428262F));
        g.addOrReplaceChild("valvula_0", CubeListBuilder.create().texOffs(242, 93).addBox(-6.0F, -29.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(322, 76).addBox(-2.5F, -29.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(11.5F, 0.0F, 0.0F));
        g.addOrReplaceChild("valvula_1", CubeListBuilder.create().texOffs(276, 93).addBox(-6.0F, -29.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(356, 76).addBox(-2.5F, -29.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(11.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("silbato_0", CubeListBuilder.create().texOffs(310, 93).addBox(-6.0F, -25.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(390, 76).addBox(-2.5F, -25.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(13.5F, 0.0F, 2.5F));
        g.addOrReplaceChild("silbato_1", CubeListBuilder.create().texOffs(344, 93).addBox(-6.0F, -25.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(424, 76).addBox(-2.5F, -25.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(13.5F, 0.0F, 2.5F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("puerta_fuego", CubeListBuilder.create().texOffs(406, 93).addBox(15.0F, -16.0F, -2.0F, 1.0F, 4.0F, 4.0F).texOffs(700, 102).addBox(15.5F, -15.0F, -1.0F, 1.0F, 2.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_manometro", CubeListBuilder.create().texOffs(828, 76).addBox(-5.0F, 0.0F, -5.0F, 10.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(15.6F, -19.4F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("cab_manometro_aguja", CubeListBuilder.create().texOffs(730, 119).addBox(0.0F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(15.719999999999999F, -19.4F, 0.0F, 3.9F, 0.0F, 0.0F));
        g.addOrReplaceChild("cab_grifos", CubeListBuilder.create().texOffs(734, 119).addBox(15.0F, -17.4F, 2.5F, 1.0F, 1.0F, 1.0F).texOffs(738, 119).addBox(15.0F, -15.899999999999999F, 2.5F, 1.0F, 1.0F, 1.0F).texOffs(742, 119).addBox(15.0F, -14.399999999999999F, 2.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_regulador", CubeListBuilder.create().texOffs(512, 93).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 5.0F, 1.0F), PartPose.offsetAndRotation(15.3F, -17.0F, 0.0F, -0.8059360376985919F, 0.0F, -1.2160906747839564F));
        g.addOrReplaceChild("cab_palanca", CubeListBuilder.create().texOffs(1000, 76).addBox(-0.5F, -9.0F, -0.5F, 1.0F, 9.0F, 1.0F).texOffs(692, 102).addBox(-1.0F, -11.0F, -1.0F, 2.0F, 2.0F, 2.0F), PartPose.offset(18.0F, -12.0F, -5.5F));
        g.addOrReplaceChild("cab_palanca_cuadrante", CubeListBuilder.create().texOffs(572, 119).addBox(16.0F, -13.0F, -6.0F, 4.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento0", CubeListBuilder.create().texOffs(668, 102).addBox(18.0F, -13.0F, -5.0F, 3.0F, 1.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("cab_asiento1", CubeListBuilder.create().texOffs(680, 102).addBox(18.0F, -13.0F, 2.0F, 3.0F, 1.0F, 3.0F), PartPose.ZERO);
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("tri0_0", CubeListBuilder.create().texOffs(908, 76).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(168, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(976, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(948, 93).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(31.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("tri0_1", CubeListBuilder.create().texOffs(188, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(984, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(31.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri0_2", CubeListBuilder.create().texOffs(208, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(31.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tri1_0", CubeListBuilder.create().texOffs(908, 76).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(168, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(976, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(958, 93).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(43.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("tri1_1", CubeListBuilder.create().texOffs(188, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(984, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("tri1_2", CubeListBuilder.create().texOffs(208, 102).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 76).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd0_0", CubeListBuilder.create().texOffs(908, 76).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(168, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(976, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(968, 93).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(31.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("trd0_1", CubeListBuilder.create().texOffs(188, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(984, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(31.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd0_2", CubeListBuilder.create().texOffs(208, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(31.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("trd1_0", CubeListBuilder.create().texOffs(908, 76).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(168, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(976, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(978, 93).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(43.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("trd1_1", CubeListBuilder.create().texOffs(188, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(984, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("trd1_2", CubeListBuilder.create().texOffs(208, 102).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(992, 76).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(43.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("tender_chasis", CubeListBuilder.create().texOffs(696, 93).addBox(24.0F, -9.0F, 6.5F, 26.0F, 4.0F, 1.0F).texOffs(750, 93).addBox(24.0F, -9.0F, -7.5F, 26.0F, 4.0F, 1.0F).texOffs(16, 102).addBox(29.5F, -6.0F, 7.5F, 3.0F, 4.0F, 1.0F).texOffs(24, 102).addBox(29.5F, -6.0F, -8.5F, 3.0F, 4.0F, 1.0F).texOffs(376, 119).addBox(27.0F, -9.0F, 7.5F, 8.0F, 1.0F, 1.0F).texOffs(394, 119).addBox(27.0F, -9.0F, -8.5F, 8.0F, 1.0F, 1.0F).texOffs(32, 102).addBox(41.5F, -6.0F, 7.5F, 3.0F, 4.0F, 1.0F).texOffs(40, 102).addBox(41.5F, -6.0F, -8.5F, 3.0F, 4.0F, 1.0F).texOffs(412, 119).addBox(39.0F, -9.0F, 7.5F, 8.0F, 1.0F, 1.0F).texOffs(430, 119).addBox(39.0F, -9.0F, -8.5F, 8.0F, 1.0F, 1.0F).texOffs(716, 119).addBox(22.0F, -9.0F, -0.5F, 2.0F, 1.0F, 1.0F).texOffs(240, 76).addBox(24.0F, -10.0F, -7.5F, 26.0F, 1.0F, 15.0F), PartPose.ZERO);
        g.addOrReplaceChild("tender", CubeListBuilder.create().texOffs(838, 43).addBox(24.0F, -19.0F, -7.5F, 26.0F, 9.0F, 15.0F).texOffs(160, 119).addBox(24.0F, -20.0F, 6.5F, 26.0F, 1.0F, 1.0F).texOffs(214, 119).addBox(24.0F, -20.0F, -7.5F, 26.0F, 1.0F, 1.0F).texOffs(620, 76).addBox(24.0F, -20.0F, -6.5F, 1.0F, 1.0F, 13.0F).texOffs(774, 76).addBox(25.0F, -20.0F, -6.0F, 15.0F, 1.0F, 12.0F).texOffs(198, 93).addBox(27.0F, -21.0F, -4.0F, 10.0F, 1.0F, 8.0F), PartPose.ZERO);
        g.addOrReplaceChild("boca_agua_0", CubeListBuilder.create().texOffs(0, 93).addBox(-13.0F, -21.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(640, 43).addBox(-3.5F, -21.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offset(45.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("boca_agua_1", CubeListBuilder.create().texOffs(66, 93).addBox(-13.0F, -21.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(706, 43).addBox(-3.5F, -21.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(45.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("boca_agua_2", CubeListBuilder.create().texOffs(132, 93).addBox(-13.0F, -21.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(772, 43).addBox(-3.5F, -21.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(45.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1) {
        escalar(g0, "tope_i_0", 1.0F, 0.06687178797385858F, 0.06687178797385858F);
        escalar(g0, "tope_i_1", 1.0F, 0.06687178797385858F, 0.06687178797385858F);
        escalar(g0, "tope_i_2", 1.0F, 0.06687178797385858F, 0.06687178797385858F);
        escalar(g0, "tope_cabezai", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "tope_cantoi_0", 1.0F, 0.11888317862019303F, 0.11888317862019303F);
        escalar(g0, "tope_cantoi_1", 1.0F, 0.11888317862019303F, 0.11888317862019303F);
        escalar(g0, "tope_cantoi_2", 1.0F, 0.11888317862019303F, 0.11888317862019303F);
        escalar(g0, "tope_d_0", 1.0F, 0.06687178797385858F, 0.06687178797385858F);
        escalar(g0, "tope_d_1", 1.0F, 0.06687178797385858F, 0.06687178797385858F);
        escalar(g0, "tope_d_2", 1.0F, 0.06687178797385858F, 0.06687178797385858F);
        escalar(g0, "tope_cabezad", 0.24615384615384617F, 0.6F, 0.24615384615384617F);
        escalar(g0, "tope_cantod_0", 1.0F, 0.11888317862019303F, 0.11888317862019303F);
        escalar(g0, "tope_cantod_1", 1.0F, 0.11888317862019303F, 0.11888317862019303F);
        escalar(g0, "tope_cantod_2", 1.0F, 0.11888317862019303F, 0.11888317862019303F);
        escalar(g0, "guardabarrosi_0", 0.9833333333333333F, 1.0F, 0.9256307263183557F);
        escalar(g0, "guardabarrosi_1", 0.9833333333333333F, 1.0F, 0.925630726318356F);
        escalar(g0, "guardabarrosi_2", 0.9833333333333333F, 1.0F, 0.9256307263183567F);
        escalar(g0, "guardabarrosi_3", 0.9833333333333333F, 1.0F, 0.9256307263183552F);
        escalar(g0, "guardabarrosi_4", 0.9833333333333333F, 1.0F, 0.925630726318356F);
        escalar(g0, "guardabarrosi_5", 0.9833333333333333F, 1.0F, 0.9256307263183564F);
        escalar(g0, "guardabarrosi_6", 0.9833333333333333F, 1.0F, 0.9256307263183551F);
        escalar(g0, "guardabarrosi_7", 0.9833333333333333F, 1.0F, 0.9256307263183567F);
        escalar(g0, "guardabarrosi_8", 0.9833333333333333F, 1.0F, 0.925630726318356F);
        escalar(g0, "guardabarrosi_9", 0.9833333333333333F, 1.0F, 0.9256307263183551F);
        escalar(g0, "guardabarrosi_10", 0.9833333333333333F, 1.0F, 0.9256307263183564F);
        escalar(g0, "guardabarrosi_11", 0.9833333333333333F, 1.0F, 0.9256307263183566F);
        escalar(g0, "guardabarros_bordei", 0.5F, 0.5F, 1.0F);
        escalar(g0, "guardabarrosd_0", 0.9833333333333333F, 1.0F, 0.9256307263183557F);
        escalar(g0, "guardabarrosd_1", 0.9833333333333333F, 1.0F, 0.925630726318356F);
        escalar(g0, "guardabarrosd_2", 0.9833333333333333F, 1.0F, 0.9256307263183567F);
        escalar(g0, "guardabarrosd_3", 0.9833333333333333F, 1.0F, 0.9256307263183552F);
        escalar(g0, "guardabarrosd_4", 0.9833333333333333F, 1.0F, 0.925630726318356F);
        escalar(g0, "guardabarrosd_5", 0.9833333333333333F, 1.0F, 0.9256307263183564F);
        escalar(g0, "guardabarrosd_6", 0.9833333333333333F, 1.0F, 0.9256307263183551F);
        escalar(g0, "guardabarrosd_7", 0.9833333333333333F, 1.0F, 0.9256307263183567F);
        escalar(g0, "guardabarrosd_8", 0.9833333333333333F, 1.0F, 0.925630726318356F);
        escalar(g0, "guardabarrosd_9", 0.9833333333333333F, 1.0F, 0.9256307263183551F);
        escalar(g0, "guardabarrosd_10", 0.9833333333333333F, 1.0F, 0.9256307263183564F);
        escalar(g0, "guardabarrosd_11", 0.9833333333333333F, 1.0F, 0.9256307263183566F);
        escalar(g0, "guardabarros_borded", 0.5F, 0.5F, 1.0F);
        escalar(g0, "caldera_0", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_1", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_2", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_3", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_4", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_5", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_6", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_7", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_8", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_9", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_10", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_11", 0.9285714285714286F, 1.0F, 0.5873678649902321F);
        escalar(g0, "caldera_12", 0.9285714285714286F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_13", 0.9285714285714286F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_14", 0.9285714285714286F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_15", 0.9285714285714286F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_16", 0.9285714285714286F, 1.0F, 0.5873678649902323F);
        escalar(g0, "caldera_17", 0.9285714285714286F, 1.0F, 0.5873678649902323F);
        escalar(g0, "caldera_18", 0.9285714285714286F, 1.0F, 0.5873678649902323F);
        escalar(g0, "caldera_19", 0.9285714285714286F, 1.0F, 0.5873678649902323F);
        escalar(g0, "caldera_20", 0.9285714285714286F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_21", 0.9285714285714286F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_22", 0.9285714285714286F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_23", 0.9285714285714286F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_24", 0.9285714285714286F, 1.0F, 0.587367864990231F);
        escalar(g0, "caldera_25", 0.9285714285714286F, 1.0F, 0.587367864990231F);
        escalar(g0, "caldera_26", 0.9285714285714286F, 1.0F, 0.587367864990231F);
        escalar(g0, "caldera_27", 0.9285714285714286F, 1.0F, 0.587367864990231F);
        escalar(g0, "caldera_28", 0.9285714285714286F, 1.0F, 0.5873678649902333F);
        escalar(g0, "caldera_29", 0.9285714285714286F, 1.0F, 0.5873678649902333F);
        escalar(g0, "caldera_30", 0.9285714285714286F, 1.0F, 0.5873678649902333F);
        escalar(g0, "caldera_31", 0.9285714285714286F, 1.0F, 0.5873678649902333F);
        escalar(g0, "caldera_32", 0.9285714285714286F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_33", 0.9285714285714286F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_34", 0.9285714285714286F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_35", 0.9285714285714286F, 1.0F, 0.5873678649902324F);
        escalar(g0, "caldera_36", 0.9285714285714286F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_37", 0.9285714285714286F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_38", 0.9285714285714286F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_39", 0.9285714285714286F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_40", 0.9285714285714286F, 1.0F, 0.5873678649902322F);
        escalar(g0, "caldera_41", 0.9285714285714286F, 1.0F, 0.5873678649902322F);
        escalar(g0, "caldera_42", 0.9285714285714286F, 1.0F, 0.5873678649902322F);
        escalar(g0, "caldera_43", 0.9285714285714286F, 1.0F, 0.5873678649902322F);
        escalar(g0, "caldera_44", 0.9285714285714286F, 1.0F, 0.5873678649902325F);
        escalar(g0, "caldera_45", 0.9285714285714286F, 1.0F, 0.5873678649902325F);
        escalar(g0, "caldera_46", 0.9285714285714286F, 1.0F, 0.5873678649902325F);
        escalar(g0, "caldera_47", 0.9285714285714286F, 1.0F, 0.5873678649902325F);
        escalar(g0, "caldera_48", 0.9285714285714286F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_49", 0.9285714285714286F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_50", 0.9285714285714286F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_51", 0.9285714285714286F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_52", 0.9285714285714286F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_53", 0.9285714285714286F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_54", 0.9285714285714286F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_55", 0.9285714285714286F, 1.0F, 0.5873678649902315F);
        escalar(g0, "caldera_56", 0.9285714285714286F, 1.0F, 0.5873678649902335F);
        escalar(g0, "caldera_57", 0.9285714285714286F, 1.0F, 0.5873678649902335F);
        escalar(g0, "caldera_58", 0.9285714285714286F, 1.0F, 0.5873678649902335F);
        escalar(g0, "caldera_59", 0.9285714285714286F, 1.0F, 0.5873678649902335F);
        escalar(g0, "caldera_60", 0.9285714285714286F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_61", 0.9285714285714286F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_62", 0.9285714285714286F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_63", 0.9285714285714286F, 1.0F, 0.5873678649902314F);
        escalar(g0, "caldera_64", 0.9285714285714286F, 1.0F, 0.5873678649902317F);
        escalar(g0, "caldera_65", 0.9285714285714286F, 1.0F, 0.5873678649902317F);
        escalar(g0, "caldera_66", 0.9285714285714286F, 1.0F, 0.5873678649902317F);
        escalar(g0, "caldera_67", 0.9285714285714286F, 1.0F, 0.5873678649902317F);
        escalar(g0, "caldera_68", 0.9285714285714286F, 1.0F, 0.5873678649902337F);
        escalar(g0, "caldera_69", 0.9285714285714286F, 1.0F, 0.5873678649902337F);
        escalar(g0, "caldera_70", 0.9285714285714286F, 1.0F, 0.5873678649902337F);
        escalar(g0, "caldera_71", 0.9285714285714286F, 1.0F, 0.5873678649902337F);
        escalar(g0, "caldera_72", 0.9285714285714286F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_73", 0.9285714285714286F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_74", 0.9285714285714286F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_75", 0.9285714285714286F, 1.0F, 0.5873678649902319F);
        escalar(g0, "caldera_76", 0.9285714285714286F, 1.0F, 0.5873678649902305F);
        escalar(g0, "caldera_77", 0.9285714285714286F, 1.0F, 0.5873678649902305F);
        escalar(g0, "caldera_78", 0.9285714285714286F, 1.0F, 0.5873678649902305F);
        escalar(g0, "caldera_79", 0.9285714285714286F, 1.0F, 0.5873678649902305F);
        escalar(g0, "caldera_80", 0.9285714285714286F, 1.0F, 0.5873678649902329F);
        escalar(g0, "caldera_81", 0.9285714285714286F, 1.0F, 0.5873678649902329F);
        escalar(g0, "caldera_82", 0.9285714285714286F, 1.0F, 0.5873678649902329F);
        escalar(g0, "caldera_83", 0.9285714285714286F, 1.0F, 0.5873678649902329F);
        escalar(g0, "caldera_84", 0.9285714285714286F, 1.0F, 0.5873678649902326F);
        escalar(g0, "caldera_85", 0.9285714285714286F, 1.0F, 0.5873678649902326F);
        escalar(g0, "caldera_86", 0.9285714285714286F, 1.0F, 0.5873678649902326F);
        escalar(g0, "caldera_87", 0.9285714285714286F, 1.0F, 0.5873678649902326F);
        escalar(g0, "caldera_88", 0.9285714285714286F, 1.0F, 0.5873678649902313F);
        escalar(g0, "caldera_89", 0.9285714285714286F, 1.0F, 0.5873678649902313F);
        escalar(g0, "caldera_90", 0.9285714285714286F, 1.0F, 0.5873678649902313F);
        escalar(g0, "caldera_91", 0.9285714285714286F, 1.0F, 0.5873678649902313F);
        escalar(g0, "caldera_92", 0.9285714285714286F, 1.0F, 0.5873678649902334F);
        escalar(g0, "caldera_93", 0.9285714285714286F, 1.0F, 0.5873678649902334F);
        escalar(g0, "caldera_94", 0.9285714285714286F, 1.0F, 0.5873678649902334F);
        escalar(g0, "caldera_95", 0.9285714285714286F, 1.0F, 0.5873678649902334F);
        escalar(g0, "caja_humo_0", 1.0F, 0.26090654246679224F, 0.26090654246679224F);
        escalar(g0, "caja_humo_1", 1.0F, 0.26090654246679224F, 0.26090654246679224F);
        escalar(g0, "caja_humo_2", 1.0F, 0.26090654246679224F, 0.26090654246679224F);
        escalar(g0, "caja_humo_3", 1.0F, 0.26090654246679224F, 0.26090654246679224F);
        escalar(g0, "caja_humo_4", 1.0F, 0.26090654246679224F, 0.26090654246679224F);
        escalar(g0, "caja_humo_5", 1.0F, 0.26090654246679224F, 0.26090654246679224F);
        escalar(g0, "puerta", 0.24705882352941178F, 0.6F, 0.24705882352941178F);
        escalar(g0, "puerta_aro", 0.2285714285714286F, 0.6F, 0.2285714285714286F);
        escalar(g0, "chimenea_base_0", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "chimenea_base_1", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "chimenea_base_2", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "chimenea_base_3", 0.4707769345935506F, 1.0F, 0.4707769345935506F);
        escalar(g0, "chimenea_0", 0.4972222222222222F, 1.0F, 0.3706716118306435F);
        escalar(g0, "chimenea_1", 0.4465153972709129F, 1.0F, 0.3854984763038693F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1) {
        escalar(g0, "chimenea_2", 0.48433046569465316F, 1.0F, 0.46353460511032063F);
        escalar(g0, "chimenea_3", 0.2999999999999997F, 1.0F, 0.4682167728387078F);
        escalar(g0, "chimenea_4", 0.4972222222222222F, 1.0F, 0.37067161183064357F);
        escalar(g0, "chimenea_5", 0.44651539727091283F, 1.0F, 0.3854984763038695F);
        escalar(g0, "chimenea_6", 0.48433046569465327F, 1.0F, 0.4635346051103211F);
        escalar(g0, "chimenea_7", 0.30000000000000004F, 1.0F, 0.4682167728387079F);
        escalar(g0, "chimenea_8", 0.4972222222222222F, 1.0F, 0.3706716118306446F);
        escalar(g0, "chimenea_9", 0.44651539727091283F, 1.0F, 0.3854984763038698F);
        escalar(g0, "chimenea_10", 0.4843304656946531F, 1.0F, 0.46353460511032085F);
        escalar(g0, "chimenea_11", 0.2999999999999997F, 1.0F, 0.4682167728387081F);
        escalar(g0, "chimenea_12", 0.4972222222222222F, 1.0F, 0.3706716118306431F);
        escalar(g0, "chimenea_13", 0.4465153972709129F, 1.0F, 0.38549847630386913F);
        escalar(g0, "chimenea_14", 0.4843304656946531F, 1.0F, 0.4635346051103204F);
        escalar(g0, "chimenea_15", 0.2999999999999999F, 1.0F, 0.46821677283870766F);
        escalar(g0, "chimenea_16", 0.4972222222222222F, 1.0F, 0.3706716118306431F);
        escalar(g0, "chimenea_17", 0.4465153972709129F, 1.0F, 0.38549847630386913F);
        escalar(g0, "chimenea_18", 0.4843304656946531F, 1.0F, 0.4635346051103204F);
        escalar(g0, "chimenea_19", 0.2999999999999999F, 1.0F, 0.46821677283870766F);
        escalar(g0, "chimenea_20", 0.4972222222222222F, 1.0F, 0.37067161183064457F);
        escalar(g0, "chimenea_21", 0.44651539727091283F, 1.0F, 0.38549847630386974F);
        escalar(g0, "chimenea_22", 0.4843304656946531F, 1.0F, 0.4635346051103208F);
        escalar(g0, "chimenea_23", 0.2999999999999997F, 1.0F, 0.468216772838708F);
        escalar(g0, "chimenea_24", 0.4972222222222222F, 1.0F, 0.3706716118306436F);
        escalar(g0, "chimenea_25", 0.44651539727091283F, 1.0F, 0.3854984763038696F);
        escalar(g0, "chimenea_26", 0.4843304656946533F, 1.0F, 0.463534605110321F);
        escalar(g0, "chimenea_27", 0.3000000000000001F, 1.0F, 0.46821677283870783F);
        escalar(g0, "chimenea_28", 0.4972222222222222F, 1.0F, 0.37067161183064345F);
        escalar(g0, "chimenea_29", 0.4465153972709129F, 1.0F, 0.38549847630386924F);
        escalar(g0, "chimenea_30", 0.4843304656946532F, 1.0F, 0.46353460511032063F);
        escalar(g0, "chimenea_31", 0.2999999999999997F, 1.0F, 0.4682167728387079F);
        escalar(g0, "chimenea_32", 0.4972222222222222F, 1.0F, 0.3706716118306435F);
        escalar(g0, "chimenea_33", 0.4465153972709129F, 1.0F, 0.3854984763038693F);
        escalar(g0, "chimenea_34", 0.48433046569465316F, 1.0F, 0.46353460511032063F);
        escalar(g0, "chimenea_35", 0.2999999999999997F, 1.0F, 0.4682167728387078F);
        escalar(g0, "chimenea_36", 0.4972222222222222F, 1.0F, 0.3706716118306437F);
        escalar(g0, "chimenea_37", 0.44651539727091283F, 1.0F, 0.38549847630386963F);
        escalar(g0, "chimenea_38", 0.48433046569465327F, 1.0F, 0.46353460511032113F);
        escalar(g0, "chimenea_39", 0.30000000000000004F, 1.0F, 0.468216772838708F);
        escalar(g0, "chimenea_40", 0.4972222222222222F, 1.0F, 0.370671611830643F);
        escalar(g0, "chimenea_41", 0.4465153972709128F, 1.0F, 0.3854984763038689F);
        escalar(g0, "chimenea_42", 0.4843304656946534F, 1.0F, 0.4635346051103201F);
        escalar(g0, "chimenea_43", 0.30000000000000004F, 1.0F, 0.4682167728387072F);
        escalar(g0, "chimenea_44", 0.4972222222222222F, 1.0F, 0.3706716118306449F);
        escalar(g0, "chimenea_45", 0.44651539727091283F, 1.0F, 0.38549847630387013F);
        escalar(g0, "chimenea_46", 0.4843304656946533F, 1.0F, 0.4635346051103214F);
        escalar(g0, "chimenea_47", 0.3000000000000002F, 1.0F, 0.46821677283870855F);
        escalar(g0, "chimenea_48", 0.4972222222222222F, 1.0F, 0.3706716118306432F);
        escalar(g0, "chimenea_49", 0.4465153972709129F, 1.0F, 0.38549847630386924F);
        escalar(g0, "chimenea_50", 0.4843304656946533F, 1.0F, 0.46353460511032135F);
        escalar(g0, "chimenea_51", 0.30000000000000016F, 1.0F, 0.46821677283870855F);
        escalar(g0, "chimenea_52", 0.4972222222222222F, 1.0F, 0.37067161183064445F);
        escalar(g0, "chimenea_53", 0.44651539727091283F, 1.0F, 0.38549847630386963F);
        escalar(g0, "chimenea_54", 0.4843304656946533F, 1.0F, 0.46353460511031996F);
        escalar(g0, "chimenea_55", 0.3F, 1.0F, 0.46821677283870716F);
        escalar(g0, "chimenea_56", 0.4972222222222222F, 1.0F, 0.3706716118306433F);
        escalar(g0, "chimenea_57", 0.44651539727091283F, 1.0F, 0.3854984763038692F);
        escalar(g0, "chimenea_58", 0.4843304656946533F, 1.0F, 0.46353460511032063F);
        escalar(g0, "chimenea_59", 0.30000000000000016F, 1.0F, 0.46821677283870744F);
        escalar(g0, "chimenea_60", 0.4972222222222222F, 1.0F, 0.37067161183064384F);
        escalar(g0, "chimenea_61", 0.4465153972709129F, 1.0F, 0.3854984763038697F);
        escalar(g0, "chimenea_62", 0.4843304656946532F, 1.0F, 0.4635346051103211F);
        escalar(g0, "chimenea_63", 0.2999999999999997F, 1.0F, 0.4682167728387083F);
        escalar(g0, "chimenea_hueco", 0.25F, 0.6F, 0.25F);
        escalar(g0, "cupula_0", 0.4241661426419881F, 1.0F, 0.44717873991946305F);
        escalar(g0, "cupula_1", 0.5065964234537113F, 1.0F, 0.425825413766449F);
        escalar(g0, "cupula_2", 0.39960343150038485F, 1.0F, 0.38314793601699687F);
        escalar(g0, "cupula_3", 0.5022717230507475F, 1.0F, 0.4782020458376651F);
        escalar(g0, "cupula_4", 0.4783857923851116F, 1.0F, 0.3456666012170806F);
        escalar(g0, "cupula_5", 0.4719070089681674F, 1.0F, 0.2796474990848761F);
        escalar(g0, "cupula_6", 0.4241947970112841F, 1.0F, 0.37684695401865625F);
        escalar(g0, "cupula_7", 0.38059575243933397F, 1.0F, 0.35890288190077974F);
        escalar(g0, "cupula_8", 0.4026443311475643F, 1.0F, 0.48455888135477665F);
        escalar(g0, "cupula_9", 0.3420487731865797F, 1.0F, 0.40344930227942627F);
        escalar(g0, "cupula_10", 0.4986511102944403F, 1.0F, 0.2920743549103527F);
        escalar(g0, "cupula_11", 0.498140400867696F, 1.0F, 0.23819239847782014F);
        escalar(g0, "cupula_12", 0.4242339670124015F, 1.0F, 0.34287844368847575F);
        escalar(g0, "cupula_13", 0.38148060727607813F, 1.0F, 0.4898714352232283F);
        escalar(g0, "cupula_14", 0.40676827472286065F, 1.0F, 0.44101237492438244F);
        escalar(g0, "cupula_15", 0.35167784099409394F, 1.0F, 0.36734557891672653F);
        escalar(g0, "cupula_16", 0.3501459341484952F, 1.0F, 0.2661906275320213F);
        escalar(g0, "cupula_17", 0.4242707425288201F, 1.0F, 0.4802491731209776F);
        escalar(g0, "cupula_18", 0.38230968588138103F, 1.0F, 0.4574543745750705F);
        escalar(g0, "cupula_19", 0.41060481413143207F, 1.0F, 0.41189592149028575F);
        escalar(g0, "cupula_20", 0.3604967007853792F, 1.0F, 0.34320558546471797F);
        escalar(g0, "cupula_21", 0.36603294677666237F, 1.0F, 0.49776803785376245F);
        escalar(g0, "cupula_22", 0.4242961947393042F, 1.0F, 0.4707591008608173F);
        escalar(g0, "cupula_23", 0.38288252205966206F, 1.0F, 0.4484243228693764F);
        escalar(g0, "cupula_24", 0.41324017164036936F, 1.0F, 0.40378528237806055F);
        escalar(g0, "cupula_25", 0.36648002570556226F, 1.0F, 0.3364811821817468F);
        escalar(g0, "cupula_26", 0.37664564813583684F, 1.0F, 0.48812622780498516F);
        escalar(g0, "cupula_27", 0.42430663853971046F, 1.0F, 0.3511997042280342F);
        escalar(g0, "cupula_28", 0.3831173338366918F, 1.0F, 0.5017482804466641F);
        escalar(g0, "cupula_29", 0.4143166618777656F, 1.0F, 0.45167995563583063F);
        escalar(g0, "cupula_30", 0.3689065458640755F, 1.0F, 0.3761899022511601F);
        escalar(g0, "cupula_31", 0.3809124601359368F, 1.0F, 0.2725313600856837F);
        escalar(g0, "cupula_32", 0.44269559765992483F, 1.0F, 0.22307534568658224F);
        escalar(g0, "cupula_33", 0.42430663853971046F, 1.0F, 0.3511997042280394F);
        escalar(g0, "cupula_34", 0.3831173338366918F, 1.0F, 0.501748280446672F);
        escalar(g0, "cupula_35", 0.4143166618777656F, 1.0F, 0.4516799556358376F);
        escalar(g0, "cupula_36", 0.3689065458640756F, 1.0F, 0.37618990225116533F);
        escalar(g0, "cupula_37", 0.38091246013593677F, 1.0F, 0.27253136008568757F);
        escalar(g0, "cupula_38", 0.4426955976599249F, 1.0F, 0.22307534568658574F);
        escalar(g0, "cupula_39", 0.4242961947393042F, 1.0F, 0.4707591008608182F);
        escalar(g0, "cupula_40", 0.3828825220596621F, 1.0F, 0.44842432286937695F);
        escalar(g0, "cupula_41", 0.41324017164036936F, 1.0F, 0.4037852823780611F);
        escalar(g0, "cupula_42", 0.3664800257055623F, 1.0F, 0.33648118218174766F);
        escalar(g0, "cupula_43", 0.37664564813583673F, 1.0F, 0.488126227804986F);
        escalar(g0, "cupula_44", 0.4242707425288201F, 1.0F, 0.4802491731209776F);
        escalar(g0, "cupula_45", 0.3823096858813811F, 1.0F, 0.4574543745750705F);
        escalar(g0, "cupula_46", 0.410604814131432F, 1.0F, 0.4118959214902854F);
        escalar(g0, "cupula_47", 0.36049670078537915F, 1.0F, 0.34320558546471763F);
        escalar(g0, "cupula_48", 0.3660329467766625F, 1.0F, 0.49776803785376245F);
        escalar(g0, "cupula_49", 0.4242339670124015F, 1.0F, 0.3428784436884755F);
        escalar(g0, "cupula_50", 0.38148060727607824F, 1.0F, 0.48987143522322785F);
        escalar(g0, "cupula_51", 0.40676827472286065F, 1.0F, 0.44101237492438206F);
        escalar(g0, "cupula_52", 0.3516778409940939F, 1.0F, 0.36734557891672603F);
        escalar(g0, "cupula_53", 0.3501459341484951F, 1.0F, 0.26619062753202094F);
        escalar(g0, "cupula_54", 0.4241947970112841F, 1.0F, 0.37684695401865637F);
        escalar(g0, "cupula_55", 0.380595752439334F, 1.0F, 0.35890288190077985F);
        escalar(g0, "cupula_56", 0.4026443311475643F, 1.0F, 0.4845588813547771F);
        escalar(g0, "cupula_57", 0.34204877318657995F, 1.0F, 0.40344930227942655F);
        escalar(g0, "cupula_58", 0.49865111029443965F, 1.0F, 0.29207435491035283F);
        escalar(g0, "cupula_59", 0.4981404008676962F, 1.0F, 0.23819239847782017F);
        escalar(g0, "cupula_60", 0.4241661426419881F, 1.0F, 0.44717873991945645F);
        escalar(g0, "cupula_61", 0.5065964234537113F, 1.0F, 0.42582541376644273F);
        escalar(g0, "cupula_62", 0.39960343150038485F, 1.0F, 0.38314793601699115F);
        escalar(g0, "cupula_63", 0.5022717230507477F, 1.0F, 0.47820204583765813F);
        escalar(g0, "cupula_64", 0.47838579238511125F, 1.0F, 0.34566660121707554F);
        escalar(g0, "cupula_65", 0.47190700896816745F, 1.0F, 0.2796474990848722F);
        escalar(g0, "cupula_66", 0.4241661426419881F, 1.0F, 0.4471787399194695F);
        escalar(g0, "cupula_67", 0.5065964234537113F, 1.0F, 0.42582541376645516F);
        escalar(g0, "cupula_68", 0.39960343150038474F, 1.0F, 0.3831479360170024F);
        escalar(g0, "cupula_69", 0.5022717230507475F, 1.0F, 0.4782020458376719F);
        escalar(g0, "cupula_70", 0.4783857923851116F, 1.0F, 0.3456666012170854F);
        escalar(g0, "cupula_71", 0.4719070089681674F, 1.0F, 0.27964749908487985F);
        escalar(g0, "cupula_72", 0.4241947970112841F, 1.0F, 0.3768469540186559F);
        escalar(g0, "cupula_73", 0.380595752439334F, 1.0F, 0.35890288190077957F);
        escalar(g0, "cupula_74", 0.4026443311475643F, 1.0F, 0.4845588813547765F);
        escalar(g0, "cupula_75", 0.3420487731865796F, 1.0F, 0.4034493022794261F);
        escalar(g0, "cupula_76", 0.4986511102944402F, 1.0F, 0.2920743549103526F);
        escalar(g0, "cupula_77", 0.4981404008676959F, 1.0F, 0.23819239847782003F);
        escalar(g0, "cupula_78", 0.4242339670124015F, 1.0F, 0.3428784436884767F);
        escalar(g0, "cupula_79", 0.38148060727607813F, 1.0F, 0.4898714352232295F);
        escalar(g0, "cupula_80", 0.40676827472286065F, 1.0F, 0.4410123749243834F);
        escalar(g0, "cupula_81", 0.35167784099409394F, 1.0F, 0.36734557891672737F);
        escalar(g0, "cupula_82", 0.3501459341484952F, 1.0F, 0.2661906275320219F);
        escalar(g0, "cupula_83", 0.4242707425288201F, 1.0F, 0.48024917312097654F);
        escalar(g0, "cupula_84", 0.38230968588138103F, 1.0F, 0.45745437457506954F);
        escalar(g0, "cupula_85", 0.41060481413143207F, 1.0F, 0.41189592149028487F);
        escalar(g0, "cupula_86", 0.36049670078537926F, 1.0F, 0.34320558546471747F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1) {
        escalar(g0, "cupula_87", 0.36603294677666237F, 1.0F, 0.4977680378537622F);
        escalar(g0, "cupula_88", 0.4242961947393042F, 1.0F, 0.4707591008608175F);
        escalar(g0, "cupula_89", 0.38288252205966206F, 1.0F, 0.4484243228693766F);
        escalar(g0, "cupula_90", 0.41324017164036936F, 1.0F, 0.4037852823780608F);
        escalar(g0, "cupula_91", 0.36648002570556226F, 1.0F, 0.33648118218174655F);
        escalar(g0, "cupula_92", 0.37664564813583684F, 1.0F, 0.4881262278049838F);
        escalar(g0, "cupula_93", 0.42430663853971046F, 1.0F, 0.35119970422802976F);
        escalar(g0, "cupula_94", 0.3831173338366918F, 1.0F, 0.5017482804466583F);
        escalar(g0, "cupula_95", 0.4143166618777656F, 1.0F, 0.4516799556358254F);
        escalar(g0, "cupula_96", 0.3689065458640755F, 1.0F, 0.3761899022511557F);
        escalar(g0, "cupula_97", 0.3809124601359368F, 1.0F, 0.272531360085681F);
        escalar(g0, "cupula_98", 0.44269559765992494F, 1.0F, 0.2230753456865805F);
        escalar(g0, "cupula_99", 0.42430663853971046F, 1.0F, 0.3511997042280444F);
        escalar(g0, "cupula_100", 0.3831173338366918F, 1.0F, 0.5017482804466785F);
        escalar(g0, "cupula_101", 0.4143166618777656F, 1.0F, 0.45167995563584384F);
        escalar(g0, "cupula_102", 0.3689065458640756F, 1.0F, 0.37618990225117066F);
        escalar(g0, "cupula_103", 0.38091246013593677F, 1.0F, 0.2725313600856911F);
        escalar(g0, "cupula_104", 0.4426955976599249F, 1.0F, 0.2230753456865884F);
        escalar(g0, "cupula_105", 0.4242961947393042F, 1.0F, 0.47075910086081674F);
        escalar(g0, "cupula_106", 0.38288252205966206F, 1.0F, 0.4484243228693763F);
        escalar(g0, "cupula_107", 0.41324017164036936F, 1.0F, 0.40378528237806044F);
        escalar(g0, "cupula_108", 0.36648002570556243F, 1.0F, 0.3364811821817467F);
        escalar(g0, "cupula_109", 0.3766456481358367F, 1.0F, 0.488126227804985F);
        escalar(g0, "cupula_110", 0.4242707425288201F, 1.0F, 0.4802491731209787F);
        escalar(g0, "cupula_111", 0.38230968588138103F, 1.0F, 0.4574543745750711F);
        escalar(g0, "cupula_112", 0.41060481413143207F, 1.0F, 0.4118959214902861F);
        escalar(g0, "cupula_113", 0.36049670078537915F, 1.0F, 0.3432055854647186F);
        escalar(g0, "cupula_114", 0.3660329467766623F, 1.0F, 0.4977680378537634F);
        escalar(g0, "cupula_115", 0.4242339670124015F, 1.0F, 0.3428784436884755F);
        escalar(g0, "cupula_116", 0.38148060727607824F, 1.0F, 0.48987143522322785F);
        escalar(g0, "cupula_117", 0.40676827472286065F, 1.0F, 0.441012374924382F);
        escalar(g0, "cupula_118", 0.3516778409940939F, 1.0F, 0.3673455789167259F);
        escalar(g0, "cupula_119", 0.3501459341484951F, 1.0F, 0.2661906275320209F);
        escalar(g0, "cupula_120", 0.4241947970112841F, 1.0F, 0.37684695401865564F);
        escalar(g0, "cupula_121", 0.380595752439334F, 1.0F, 0.3589028819007792F);
        escalar(g0, "cupula_122", 0.4026443311475643F, 1.0F, 0.4845588813547762F);
        escalar(g0, "cupula_123", 0.34204877318657995F, 1.0F, 0.40344930227942577F);
        escalar(g0, "cupula_124", 0.49865111029443976F, 1.0F, 0.2920743549103523F);
        escalar(g0, "cupula_125", 0.49814040086769623F, 1.0F, 0.2381923984778198F);
        escalar(g0, "cupula_126", 0.4241661426419881F, 1.0F, 0.4471787399194511F);
        escalar(g0, "cupula_127", 0.5065964234537113F, 1.0F, 0.4258254137664377F);
        escalar(g0, "cupula_128", 0.39960343150038485F, 1.0F, 0.3831479360169867F);
        escalar(g0, "cupula_129", 0.5022717230507479F, 1.0F, 0.47820204583765247F);
        escalar(g0, "cupula_130", 0.47838579238511136F, 1.0F, 0.3456666012170715F);
        escalar(g0, "cupula_131", 0.47190700896816756F, 1.0F, 0.2796474990848691F);
        escalar(g0, "valvula_0", 0.1077859454596501F, 1.0F, 0.1077859454596501F);
        escalar(g0, "valvula_1", 0.1077859454596501F, 1.0F, 0.1077859454596501F);
        escalar(g0, "silbato_0", 0.07698996104260723F, 1.0F, 0.07698996104260723F);
        escalar(g0, "silbato_1", 0.07698996104260723F, 1.0F, 0.07698996104260723F);
        escalar(g0, "cab_manometro", 0.24F, 0.6F, 0.24F);
        escalar(g0, "cab_manometro_aguja", 0.3F, 0.9839999999999999F, 0.6F);
        escalar(g0, "cab_regulador", 0.7F, 0.8316249154516715F, 0.7F);
        escalar(g1, "boca_agua_0", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
        escalar(g1, "boca_agua_1", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
        escalar(g1, "boca_agua_2", 0.11145297995643097F, 1.0F, 0.11145297995643097F);
    }
}
