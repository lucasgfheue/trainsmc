package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Tolva de mineral" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonTolva {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_tolva"), "main"),
            LocomotoraMod.id("textures/entity/vagon_tolva.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -16.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -8.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 8.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 16.0F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloVagonTolva::crearCapa,
            16.0F,
            ModeloVagonTolva::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -12.0F, 12.0F)));

    private ModeloVagonTolva() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 64);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(408, 0).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(712, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(426, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(552, 49).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-16.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(730, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(748, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(408, 0).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(712, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(426, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(562, 49).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-8.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(730, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(748, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(408, 0).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(712, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(426, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(572, 49).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-16.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(730, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(748, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(408, 0).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(712, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(426, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(582, 49).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-8.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(730, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(748, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(450, 0).addBox(-21.0F, -9.0F, 7.0F, 18.0F, 6.0F, 1.0F).texOffs(488, 0).addBox(-21.0F, -9.0F, -8.0F, 18.0F, 6.0F, 1.0F).texOffs(592, 49).addBox(-18.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(602, 49).addBox(-18.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(612, 49).addBox(-10.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(622, 49).addBox(-10.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(408, 0).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(712, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(426, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(632, 49).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(8.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(730, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(748, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(408, 0).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(712, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(426, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(642, 49).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(16.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(730, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(748, 49).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 0).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(408, 0).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(712, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(426, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(652, 49).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(8.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(730, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(748, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(8.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(408, 0).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(712, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(426, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(662, 49).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(16.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(730, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(748, 49).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(442, 0).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(16.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(526, 0).addBox(3.0F, -9.0F, 7.0F, 18.0F, 6.0F, 1.0F).texOffs(564, 0).addBox(3.0F, -9.0F, -8.0F, 18.0F, 6.0F, 1.0F).texOffs(672, 49).addBox(6.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(682, 49).addBox(6.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(692, 49).addBox(14.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(702, 49).addBox(14.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(308, 0).addBox(-22.0F, -12.0F, -3.0F, 44.0F, 3.0F, 6.0F).texOffs(100, 0).addBox(-22.0F, -12.0F, -10.0F, 2.0F, 3.0F, 20.0F).texOffs(612, 38).addBox(-27.0F, -10.5F, -1.5F, 5.0F, 3.0F, 3.0F).texOffs(144, 0).addBox(20.0F, -12.0F, -10.0F, 2.0F, 3.0F, 20.0F).texOffs(628, 38).addBox(22.0F, -10.5F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja", CubeListBuilder.create().texOffs(0, 0).addBox(-15.0F, -30.0F, -10.0F, 30.0F, 18.0F, 20.0F), PartPose.ZERO);
        g.addOrReplaceChild("puntai_0", CubeListBuilder.create().texOffs(826, 0).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-16.25F, -16.5F, -7.5F, -3.141592653589793F, 0.0F, -1.8417431771333173F));
        g.addOrReplaceChild("puntai_1", CubeListBuilder.create().texOffs(856, 0).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-18.75F, -25.5F, -7.5F, -3.141592653589793F, 0.0F, -1.8417431771333173F));
        g.addOrReplaceChild("puntai_2", CubeListBuilder.create().texOffs(886, 0).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-16.25F, -16.5F, -2.5F, -3.141592653589793F, 0.0F, -1.8417431771333173F));
        g.addOrReplaceChild("puntai_3", CubeListBuilder.create().texOffs(916, 0).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-18.75F, -25.5F, -2.5F, -3.141592653589793F, 0.0F, -1.8417431771333173F));
        g.addOrReplaceChild("puntai_4", CubeListBuilder.create().texOffs(946, 0).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-16.25F, -16.5F, 2.5F, -3.141592653589793F, 0.0F, -1.8417431771333173F));
        g.addOrReplaceChild("puntai_5", CubeListBuilder.create().texOffs(976, 0).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-18.75F, -25.5F, 2.5F, -3.141592653589793F, 0.0F, -1.8417431771333173F));
        g.addOrReplaceChild("puntai_6", CubeListBuilder.create().texOffs(0, 38).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-16.25F, -16.5F, 7.5F, -3.141592653589793F, 0.0F, -1.8417431771333173F));
        g.addOrReplaceChild("puntai_7", CubeListBuilder.create().texOffs(30, 38).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-18.75F, -25.5F, 7.5F, -3.141592653589793F, 0.0F, -1.8417431771333173F));
        g.addOrReplaceChild("punta_ladoii", CubeListBuilder.create().texOffs(188, 0).addBox(0.0F, -18.0F, -0.5F, 5.0F, 18.0F, 1.0F), PartPose.offset(-20.0F, -12.0F, -9.5F));
        g.addOrReplaceChild("punta_ladoid", CubeListBuilder.create().texOffs(200, 0).addBox(0.0F, -18.0F, -0.5F, 5.0F, 18.0F, 1.0F), PartPose.offset(-20.0F, -12.0F, 9.5F));
        g.addOrReplaceChild("puntad_0", CubeListBuilder.create().texOffs(60, 38).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(16.25F, -16.5F, -7.5F, 0.0F, 0.0F, -1.299849476456476F));
        g.addOrReplaceChild("puntad_1", CubeListBuilder.create().texOffs(90, 38).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(18.75F, -25.5F, -7.5F, 0.0F, 0.0F, -1.299849476456476F));
        g.addOrReplaceChild("puntad_2", CubeListBuilder.create().texOffs(120, 38).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(16.25F, -16.5F, -2.5F, 0.0F, 0.0F, -1.299849476456476F));
        g.addOrReplaceChild("puntad_3", CubeListBuilder.create().texOffs(150, 38).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(18.75F, -25.5F, -2.5F, 0.0F, 0.0F, -1.299849476456476F));
        g.addOrReplaceChild("puntad_4", CubeListBuilder.create().texOffs(180, 38).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(16.25F, -16.5F, 2.5F, 0.0F, 0.0F, -1.299849476456476F));
        g.addOrReplaceChild("puntad_5", CubeListBuilder.create().texOffs(210, 38).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(18.75F, -25.5F, 2.5F, 0.0F, 0.0F, -1.299849476456476F));
        g.addOrReplaceChild("puntad_6", CubeListBuilder.create().texOffs(240, 38).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(16.25F, -16.5F, 7.5F, 0.0F, 0.0F, -1.299849476456476F));
        g.addOrReplaceChild("puntad_7", CubeListBuilder.create().texOffs(270, 38).addBox(-5.0F, -1.0F, -2.5F, 10.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(18.75F, -25.5F, 7.5F, 0.0F, 0.0F, -1.299849476456476F));
        g.addOrReplaceChild("punta_ladodi", CubeListBuilder.create().texOffs(212, 0).addBox(0.0F, -18.0F, -0.5F, 5.0F, 18.0F, 1.0F), PartPose.offset(15.0F, -12.0F, -9.5F));
        g.addOrReplaceChild("punta_ladodd", CubeListBuilder.create().texOffs(224, 0).addBox(0.0F, -18.0F, -0.5F, 5.0F, 18.0F, 1.0F), PartPose.offset(15.0F, -12.0F, 9.5F));
        g.addOrReplaceChild("tolvas", CubeListBuilder.create().texOffs(236, 0).addBox(-10.0F, -12.0F, -5.0F, 8.0F, 6.0F, 10.0F).texOffs(272, 0).addBox(2.0F, -12.0F, -5.0F, 8.0F, 6.0F, 10.0F), PartPose.ZERO);
        g.addOrReplaceChild("carga_0", CubeListBuilder.create().texOffs(300, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-16.2F, -29.370000000000005F, -8.370000000000001F, -2.8619458254777514F, 0.019881968525402728F, -0.14318084132507833F));
        g.addOrReplaceChild("carga_1", CubeListBuilder.create().texOffs(326, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-12.600000000000001F, -29.73F, -8.370000000000001F, -2.546716818069461F, 0.011599880869406536F, -0.04210978339957631F));
        g.addOrReplaceChild("carga_2", CubeListBuilder.create().texOffs(352, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-9.0F, -29.87243181254603F, -8.370000000000001F, -2.448673482802984F, 0.007157065946405598F, -0.023178476906466083F));
        g.addOrReplaceChild("carga_3", CubeListBuilder.create().texOffs(602, 0).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-5.4F, -29.953339966247F, -8.370000000000001F, -2.3992100251048165F, 0.003940256418526136F, -0.012203835164765123F));
        g.addOrReplaceChild("carga_4", CubeListBuilder.create().texOffs(630, 0).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-1.7999999999999998F, -29.990908153700975F, -8.370000000000001F, -2.3776651268923534F, 0.0012615868536817898F, -0.0038424402432896063F));
        g.addOrReplaceChild("carga_5", CubeListBuilder.create().texOffs(658, 0).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(1.8000000000000007F, -29.99090815370097F, -8.370000000000001F, -2.3776651268923534F, -0.0012615868536817898F, 0.0038424402432896063F));
        g.addOrReplaceChild("carga_6", CubeListBuilder.create().texOffs(686, 0).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(5.400000000000002F, -29.953339966247F, -8.370000000000001F, -2.3992100251048165F, -0.003940256418526136F, 0.012203835164765045F));
        g.addOrReplaceChild("carga_7", CubeListBuilder.create().texOffs(378, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(9.000000000000002F, -29.87243181254603F, -8.370000000000001F, -2.448673482802984F, -0.007157065946405598F, 0.023178476906466083F));
        g.addOrReplaceChild("carga_8", CubeListBuilder.create().texOffs(404, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(12.6F, -29.730000000000004F, -8.370000000000001F, -2.546716818069461F, -0.011599880869406536F, 0.04210978339957631F));
        g.addOrReplaceChild("carga_9", CubeListBuilder.create().texOffs(430, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(16.2F, -29.369999999999997F, -8.370000000000001F, -2.8619458254777514F, -0.019881968525402728F, 0.14318084132507825F));
        g.addOrReplaceChild("carga_10", CubeListBuilder.create().texOffs(748, 38).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.2F, -29.73F, -6.51F, -3.050504284068793F, 0.0F, -0.33667481938672716F));
        g.addOrReplaceChild("carga_11", CubeListBuilder.create().texOffs(772, 38).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-12.600000000000001F, -30.57F, -6.51F, -2.9209412538601867F, 0.012453963435065128F, -0.11334823883597635F));
        g.addOrReplaceChild("carga_12", CubeListBuilder.create().texOffs(796, 38).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -30.90234089594073F, -6.51F, -2.8720820584773894F, 0.008720555404186274F, -0.06545393932769372F));
        g.addOrReplaceChild("carga_13", CubeListBuilder.create().texOffs(820, 38).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.4F, -31.091126587909663F, -6.51F, -2.8449578195185086F, 0.005159127164771961F, -0.03532012884785858F));
        g.addOrReplaceChild("carga_14", CubeListBuilder.create().texOffs(844, 38).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.7999999999999998F, -31.178785691968937F, -6.51F, -2.8325245833085884F, 0.0017074981890064552F, -0.011239976745998106F));
        g.addOrReplaceChild("carga_15", CubeListBuilder.create().texOffs(868, 38).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.8000000000000007F, -31.178785691968937F, -6.51F, -2.8325245833085884F, -0.0017074981890064552F, 0.011239976745998106F));
        g.addOrReplaceChild("carga_16", CubeListBuilder.create().texOffs(892, 38).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.400000000000002F, -31.091126587909663F, -6.51F, -2.8449578195185086F, -0.005159127164771883F, 0.03532012884785856F));
        g.addOrReplaceChild("carga_17", CubeListBuilder.create().texOffs(916, 38).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(9.000000000000002F, -30.902340895940732F, -6.51F, -2.8720820584773894F, -0.008720555404186274F, 0.06545393932769376F));
        g.addOrReplaceChild("carga_18", CubeListBuilder.create().texOffs(940, 38).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.6F, -30.570000000000004F, -6.51F, -2.9209412538601867F, -0.012453963435065128F, 0.1133482388359764F));
        g.addOrReplaceChild("carga_19", CubeListBuilder.create().texOffs(964, 38).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(16.2F, -29.729999999999997F, -6.51F, -3.050504284068793F, 0.0F, 0.336674819386727F));
        g.addOrReplaceChild("carga_20", CubeListBuilder.create().texOffs(988, 38).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.2F, -29.87243181254603F, -4.65F, -3.089829567901002F, 0.0F, -0.40536256112042346F));
        g.addOrReplaceChild("carga_21", CubeListBuilder.create().texOffs(0, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-12.600000000000001F, -30.90234089594073F, -4.65F, -3.0120920915821374F, 0.009157443089022688F, -0.1408865686791752F));
        g.addOrReplaceChild("carga_22", CubeListBuilder.create().texOffs(24, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -31.309818166789405F, -4.65F, -2.9822191625035477F, 0.006528168244704327F, -0.08209192350369918F));
        g.addOrReplaceChild("carga_23", CubeListBuilder.create().texOffs(48, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.4F, -31.541284951281973F, -4.65F, -2.9654339249180395F, 0.003904341250681825F, -0.04453347372105981F));
        g.addOrReplaceChild("carga_24", CubeListBuilder.create().texOffs(72, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.7999999999999998F, -31.64876222213065F, -4.65F, -2.9576845533116143F, 0.00129899772625888F, -0.014207638129536515F));
        g.addOrReplaceChild("carga_25", CubeListBuilder.create().texOffs(96, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.8000000000000007F, -31.64876222213065F, -4.65F, -2.9576845533116143F, -0.00129899772625888F, 0.014207638129536515F));
        g.addOrReplaceChild("carga_26", CubeListBuilder.create().texOffs(120, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.400000000000002F, -31.541284951281973F, -4.65F, -2.9654339249180395F, -0.003904341250681825F, 0.04453347372105978F));
        g.addOrReplaceChild("carga_27", CubeListBuilder.create().texOffs(144, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(9.000000000000002F, -31.309818166789405F, -4.65F, -2.9822191625035477F, -0.006528168244704327F, 0.08209192350369926F));
        g.addOrReplaceChild("carga_28", CubeListBuilder.create().texOffs(168, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.6F, -30.90234089594073F, -4.65F, -3.0120920915821374F, -0.009157443089022608F, 0.1408865686791753F));
        g.addOrReplaceChild("carga_29", CubeListBuilder.create().texOffs(192, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(16.2F, -29.872431812546026F, -4.65F, -3.089829567901002F, 0.0F, 0.40536256112042335F));
        g.addOrReplaceChild("carga_30", CubeListBuilder.create().texOffs(216, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.2F, -29.953339966247F, -2.7899999999999996F, -3.1139317233905754F, 0.0F, -0.4426956016549801F));
        g.addOrReplaceChild("carga_31", CubeListBuilder.create().texOffs(240, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-12.600000000000001F, -31.091126587909663F, -2.7899999999999996F, -3.071138066182031F, 0.005548107883549217F, -0.15633833061192717F));
        g.addOrReplaceChild("carga_32", CubeListBuilder.create().texOffs(264, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -31.541284951281973F, -2.7899999999999996F, -3.054582383339911F, 0.003984871582413659F, -0.0914556848693F));
        g.addOrReplaceChild("carga_33", CubeListBuilder.create().texOffs(288, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.4F, -31.79699665923862F, -2.7899999999999996F, -3.045238223947513F, 0.0023939535948821343F, -0.04972701139862511F));
        g.addOrReplaceChild("carga_34", CubeListBuilder.create().texOffs(312, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.7999999999999998F, -31.91573160669764F, -2.7899999999999996F, -3.0409123944309124F, 0.0007982022046186291F, -0.015881867968624997F));
        g.addOrReplaceChild("carga_35", CubeListBuilder.create().texOffs(336, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.8000000000000007F, -31.91573160669764F, -2.7899999999999996F, -3.0409123944309124F, -0.0007982022046187076F, 0.015881867968624987F));
        g.addOrReplaceChild("carga_36", CubeListBuilder.create().texOffs(360, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.400000000000002F, -31.79699665923862F, -2.7899999999999996F, -3.045238223947513F, -0.0023939535948821343F, 0.04972701139862508F));
        g.addOrReplaceChild("carga_37", CubeListBuilder.create().texOffs(384, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(9.000000000000002F, -31.541284951281973F, -2.7899999999999996F, -3.054582383339911F, -0.003984871582413659F, 0.0914556848693001F));
        g.addOrReplaceChild("carga_38", CubeListBuilder.create().texOffs(408, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.6F, -31.091126587909663F, -2.7899999999999996F, -3.0711380661820304F, -0.005548107883549217F, 0.15633833061192723F));
        g.addOrReplaceChild("carga_39", CubeListBuilder.create().texOffs(432, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(16.2F, -29.953339966247F, -2.7899999999999996F, -3.1139317233905754F, 0.0F, 0.4426956016549799F));
        g.addOrReplaceChild("carga_40", CubeListBuilder.create().texOffs(644, 38).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.2F, -29.990908153700975F, -0.9299999999999997F, -3.1328311670529434F, 0.0F, -0.4595986299065136F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("carga_41", CubeListBuilder.create().texOffs(456, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-12.600000000000001F, -31.178785691968937F, -0.9299999999999997F, -3.1190895846617335F, 0.001855673482912823F, -0.16346829561327345F));
        g.addOrReplaceChild("carga_42", CubeListBuilder.create().texOffs(480, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -31.64876222213065F, -0.9299999999999997F, -3.113759851741768F, 0.0013368809430637776F, -0.09578351808119843F));
        g.addOrReplaceChild("carga_43", CubeListBuilder.create().texOffs(504, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.4F, -31.91573160669764F, -0.9299999999999997F, -3.110746649364114F, 0.000804588347513346F, -0.0521290794338982F));
        g.addOrReplaceChild("carga_44", CubeListBuilder.create().texOffs(528, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.7999999999999998F, -32.03969384566991F, -0.9299999999999997F, -3.109350244689832F, 0.00026850053106255105F, -0.01665646360898785F));
        g.addOrReplaceChild("carga_45", CubeListBuilder.create().texOffs(552, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.8000000000000007F, -32.0396938456699F, -0.9299999999999997F, -3.109350244689832F, -0.00026850053106255105F, 0.016656463608987843F));
        g.addOrReplaceChild("carga_46", CubeListBuilder.create().texOffs(576, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.400000000000002F, -31.91573160669764F, -0.9299999999999997F, -3.110746649364114F, -0.000804588347513346F, 0.052129079433898176F));
        g.addOrReplaceChild("carga_47", CubeListBuilder.create().texOffs(600, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(9.000000000000002F, -31.64876222213065F, -0.9299999999999997F, -3.113759851741768F, -0.0013368809430637776F, 0.09578351808119853F));
        g.addOrReplaceChild("carga_48", CubeListBuilder.create().texOffs(624, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.6F, -31.178785691968937F, -0.9299999999999997F, -3.1190895846617335F, -0.001855673482912823F, 0.16346829561327353F));
        g.addOrReplaceChild("carga_49", CubeListBuilder.create().texOffs(670, 38).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(16.2F, -29.99090815370097F, -0.9299999999999997F, -3.1328311670529434F, 0.0F, 0.45959862990651335F));
        g.addOrReplaceChild("carga_50", CubeListBuilder.create().texOffs(696, 38).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.2F, -29.990908153700975F, 0.9300000000000006F, 3.1328311670529434F, 0.0F, -0.4595986299065136F));
        g.addOrReplaceChild("carga_51", CubeListBuilder.create().texOffs(648, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-12.600000000000001F, -31.178785691968937F, 0.9300000000000006F, 3.1190895846617335F, -0.001855673482912823F, -0.16346829561327345F));
        g.addOrReplaceChild("carga_52", CubeListBuilder.create().texOffs(672, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -31.648762222130646F, 0.9300000000000006F, 3.113759851741768F, -0.0013368809430637776F, -0.09578351808119843F));
        g.addOrReplaceChild("carga_53", CubeListBuilder.create().texOffs(696, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.4F, -31.91573160669764F, 0.9300000000000006F, 3.110746649364114F, -0.000804588347513346F, -0.0521290794338982F));
        g.addOrReplaceChild("carga_54", CubeListBuilder.create().texOffs(720, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.7999999999999998F, -32.03969384566991F, 0.9300000000000006F, 3.109350244689832F, -0.00026850053106255105F, -0.016656463608987846F));
        g.addOrReplaceChild("carga_55", CubeListBuilder.create().texOffs(744, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.8000000000000007F, -32.0396938456699F, 0.9300000000000006F, 3.109350244689832F, 0.00026850053106255105F, 0.016656463608987843F));
        g.addOrReplaceChild("carga_56", CubeListBuilder.create().texOffs(768, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.400000000000002F, -31.915731606697637F, 0.9300000000000006F, 3.110746649364114F, 0.000804588347513346F, 0.052129079433898176F));
        g.addOrReplaceChild("carga_57", CubeListBuilder.create().texOffs(792, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(9.000000000000002F, -31.64876222213065F, 0.9300000000000006F, 3.113759851741768F, 0.0013368809430637776F, 0.09578351808119853F));
        g.addOrReplaceChild("carga_58", CubeListBuilder.create().texOffs(816, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.6F, -31.178785691968937F, 0.9300000000000006F, 3.1190895846617335F, 0.001855673482912823F, 0.16346829561327353F));
        g.addOrReplaceChild("carga_59", CubeListBuilder.create().texOffs(722, 38).addBox(-4.5F, -1.0F, -2.0F, 9.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(16.2F, -29.99090815370097F, 0.9300000000000006F, 3.1328311670529434F, 0.0F, 0.45959862990651335F));
        g.addOrReplaceChild("carga_60", CubeListBuilder.create().texOffs(840, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.2F, -29.953339966247F, 2.790000000000001F, 3.1139317233905754F, 0.0F, -0.4426956016549801F));
        g.addOrReplaceChild("carga_61", CubeListBuilder.create().texOffs(864, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-12.600000000000001F, -31.091126587909663F, 2.790000000000001F, 3.0711380661820304F, -0.005548107883549217F, -0.15633833061192717F));
        g.addOrReplaceChild("carga_62", CubeListBuilder.create().texOffs(888, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -31.541284951281973F, 2.790000000000001F, 3.054582383339911F, -0.003984871582413659F, -0.0914556848693F));
        g.addOrReplaceChild("carga_63", CubeListBuilder.create().texOffs(912, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.4F, -31.79699665923862F, 2.790000000000001F, 3.045238223947512F, -0.002393953594882213F, -0.0497270113986246F));
        g.addOrReplaceChild("carga_64", CubeListBuilder.create().texOffs(936, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.7999999999999998F, -31.91573160669764F, 2.790000000000001F, 3.0409123944309115F, -0.0007982022046186291F, -0.015881867968625493F));
        g.addOrReplaceChild("carga_65", CubeListBuilder.create().texOffs(960, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.8000000000000007F, -31.915731606697637F, 2.790000000000001F, 3.0409123944309115F, 0.0007982022046187076F, 0.015881867968625472F));
        g.addOrReplaceChild("carga_66", CubeListBuilder.create().texOffs(984, 44).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.400000000000002F, -31.79699665923862F, 2.790000000000001F, 3.045238223947512F, 0.002393953594882213F, 0.04972701139862458F));
        g.addOrReplaceChild("carga_67", CubeListBuilder.create().texOffs(0, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(9.000000000000002F, -31.541284951281973F, 2.790000000000001F, 3.054582383339911F, 0.003984871582413659F, 0.0914556848693001F));
        g.addOrReplaceChild("carga_68", CubeListBuilder.create().texOffs(24, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.6F, -31.091126587909663F, 2.790000000000001F, 3.0711380661820304F, 0.005548107883549217F, 0.15633833061192723F));
        g.addOrReplaceChild("carga_69", CubeListBuilder.create().texOffs(48, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(16.2F, -29.953339966247F, 2.790000000000001F, 3.1139317233905754F, 0.0F, 0.4426956016549799F));
        g.addOrReplaceChild("carga_70", CubeListBuilder.create().texOffs(72, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.2F, -29.872431812546026F, 4.650000000000001F, 3.0898295679010013F, 0.0F, -0.405362561120423F));
        g.addOrReplaceChild("carga_71", CubeListBuilder.create().texOffs(96, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-12.600000000000001F, -30.902340895940725F, 4.650000000000001F, 3.0120920915821365F, -0.009157443089022766F, -0.14088656867917565F));
        g.addOrReplaceChild("carga_72", CubeListBuilder.create().texOffs(120, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -31.3098181667894F, 4.650000000000001F, 2.9822191625035477F, -0.006528168244704327F, -0.08209192350369916F));
        g.addOrReplaceChild("carga_73", CubeListBuilder.create().texOffs(144, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.4F, -31.541284951281973F, 4.650000000000001F, 2.9654339249180404F, -0.003904341250681668F, -0.04453347372105931F));
        g.addOrReplaceChild("carga_74", CubeListBuilder.create().texOffs(168, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.7999999999999998F, -31.64876222213065F, 4.650000000000001F, 2.957684553311615F, -0.0012989977262588014F, -0.014207638129537006F));
        g.addOrReplaceChild("carga_75", CubeListBuilder.create().texOffs(192, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.8000000000000007F, -31.64876222213065F, 4.650000000000001F, 2.957684553311615F, 0.0012989977262588014F, 0.014207638129536976F));
        g.addOrReplaceChild("carga_76", CubeListBuilder.create().texOffs(216, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.400000000000002F, -31.541284951281973F, 4.650000000000001F, 2.9654339249180404F, 0.003904341250681668F, 0.04453347372105928F));
        g.addOrReplaceChild("carga_77", CubeListBuilder.create().texOffs(240, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(9.000000000000002F, -31.3098181667894F, 4.650000000000001F, 2.982219162503547F, 0.006528168244704249F, 0.08209192350369973F));
        g.addOrReplaceChild("carga_78", CubeListBuilder.create().texOffs(264, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.6F, -30.902340895940725F, 4.650000000000001F, 3.0120920915821356F, 0.009157443089022766F, 0.14088656867917526F));
        g.addOrReplaceChild("carga_79", CubeListBuilder.create().texOffs(288, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(16.2F, -29.872431812546026F, 4.650000000000001F, 3.0898295679010013F, 0.0F, 0.40536256112042285F));
        g.addOrReplaceChild("carga_80", CubeListBuilder.create().texOffs(312, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-16.2F, -29.730000000000004F, 6.510000000000002F, 3.0505042840687935F, 0.0F, -0.3366748193867267F));
        g.addOrReplaceChild("carga_81", CubeListBuilder.create().texOffs(336, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-12.600000000000001F, -30.570000000000004F, 6.510000000000002F, 2.9209412538601875F, -0.01245396343506505F, -0.11334823883597685F));
        g.addOrReplaceChild("carga_82", CubeListBuilder.create().texOffs(360, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -30.90234089594073F, 6.510000000000002F, 2.8720820584773894F, -0.008720555404186274F, -0.06545393932769372F));
        g.addOrReplaceChild("carga_83", CubeListBuilder.create().texOffs(384, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.4F, -31.091126587909663F, 6.510000000000002F, 2.8449578195185086F, -0.005159127164771883F, -0.0353201288478586F));
        g.addOrReplaceChild("carga_84", CubeListBuilder.create().texOffs(408, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.7999999999999998F, -31.178785691968937F, 6.510000000000002F, 2.8325245833085884F, -0.0017074981890064552F, -0.011239976745998125F));
        g.addOrReplaceChild("carga_85", CubeListBuilder.create().texOffs(432, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(1.8000000000000007F, -31.178785691968937F, 6.510000000000002F, 2.8325245833085884F, 0.0017074981890064552F, 0.011239976745998125F));
        g.addOrReplaceChild("carga_86", CubeListBuilder.create().texOffs(456, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(5.400000000000002F, -31.091126587909663F, 6.510000000000002F, 2.8449578195185086F, 0.005159127164771883F, 0.03532012884785854F));
        g.addOrReplaceChild("carga_87", CubeListBuilder.create().texOffs(480, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(9.000000000000002F, -30.90234089594073F, 6.510000000000002F, 2.8720820584773903F, 0.00872055540418643F, 0.06545393932769422F));
        g.addOrReplaceChild("carga_88", CubeListBuilder.create().texOffs(504, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.6F, -30.57F, 6.510000000000002F, 2.9209412538601884F, 0.012453963435064972F, 0.11334823883597644F));
        g.addOrReplaceChild("carga_89", CubeListBuilder.create().texOffs(528, 49).addBox(-4.0F, -1.0F, -2.0F, 8.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(16.2F, -29.729999999999997F, 6.510000000000002F, 3.0505042840687935F, 0.0F, 0.33667481938672655F));
        g.addOrReplaceChild("carga_90", CubeListBuilder.create().texOffs(456, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-16.2F, -29.369999999999997F, 8.370000000000001F, 2.8619458254777514F, -0.019881968525402728F, -0.14318084132507836F));
        g.addOrReplaceChild("carga_91", CubeListBuilder.create().texOffs(482, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-12.600000000000001F, -29.730000000000004F, 8.370000000000001F, 2.546716818069461F, -0.011599880869406536F, -0.04210978339957635F));
        g.addOrReplaceChild("carga_92", CubeListBuilder.create().texOffs(508, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(-9.0F, -29.872431812546026F, 8.370000000000001F, 2.448673482802984F, -0.007157065946405677F, -0.023178476906466083F));
        g.addOrReplaceChild("carga_93", CubeListBuilder.create().texOffs(714, 0).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-5.4F, -29.953339966247F, 8.370000000000001F, 2.399210025104816F, -0.003940256418526057F, -0.012203835164765123F));
        g.addOrReplaceChild("carga_94", CubeListBuilder.create().texOffs(742, 0).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(-1.7999999999999998F, -29.99090815370097F, 8.370000000000001F, 2.377665126892353F, -0.0012615868536818683F, -0.0038424402432895278F));
        g.addOrReplaceChild("carga_95", CubeListBuilder.create().texOffs(770, 0).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(1.8000000000000007F, -29.99090815370097F, 8.370000000000001F, 2.377665126892353F, 0.0012615868536818683F, 0.0038424402432895278F));
        g.addOrReplaceChild("carga_96", CubeListBuilder.create().texOffs(798, 0).addBox(-4.0F, -1.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.offsetAndRotation(5.400000000000002F, -29.953339966247F, 8.370000000000001F, 2.399210025104816F, 0.003940256418526057F, 0.012203835164765045F));
        g.addOrReplaceChild("carga_97", CubeListBuilder.create().texOffs(534, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(9.000000000000002F, -29.872431812546026F, 8.370000000000001F, 2.448673482802984F, 0.007157065946405677F, 0.023178476906466083F));
        g.addOrReplaceChild("carga_98", CubeListBuilder.create().texOffs(560, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(12.6F, -29.729999999999997F, 8.370000000000001F, 2.546716818069461F, 0.011599880869406536F, 0.04210978339957635F));
        g.addOrReplaceChild("carga_99", CubeListBuilder.create().texOffs(586, 38).addBox(-4.0F, -1.0F, -2.5F, 8.0F, 1.0F, 5.0F), PartPose.offsetAndRotation(16.2F, -29.369999999999997F, 8.370000000000001F, 2.8619458254777514F, 0.019881968525402728F, 0.14318084132507825F));
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "puntai_0", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntai_1", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntai_2", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntai_3", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntai_4", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntai_5", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntai_6", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntai_7", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntad_0", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntad_1", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntad_2", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntad_3", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntad_4", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntad_5", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntad_6", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "puntad_7", 0.9390770846134704F, 1.0F, 1.01F);
        escalar(g0, "carga_0", 0.4661568964504873F, 1.0F, 0.411081379947219F);
        escalar(g0, "carga_1", 0.45737220147521995F, 1.0F, 0.460308929354171F);
        escalar(g0, "carga_2", 0.45663149532610015F, 1.0F, 0.49384774166816003F);
        escalar(g0, "carga_3", 0.4563625971049783F, 1.0F, 0.4291169205172783F);
        escalar(g0, "carga_4", 0.45626148049448567F, 1.0F, 0.4376299730675017F);
        escalar(g0, "carga_5", 0.4562614804944859F, 1.0F, 0.4376299730675017F);
        escalar(g0, "carga_6", 0.4563625971049785F, 1.0F, 0.4291169205172783F);
        escalar(g0, "carga_7", 0.45663149532609976F, 1.0F, 0.49384774166816003F);
        escalar(g0, "carga_8", 0.45737220147521973F, 1.0F, 0.460308929354171F);
        escalar(g0, "carga_9", 0.4661568964504875F, 1.0F, 0.411081379947219F);
        escalar(g0, "carga_10", 0.48348931277154F, 1.0F, 0.4818148010577043F);
        escalar(g0, "carga_11", 0.4593633907315433F, 1.0F, 0.4894319599614362F);
        escalar(g0, "carga_12", 0.4573092633856012F, 1.0F, 0.49506560703240104F);
        escalar(g0, "carga_13", 0.45656273081462206F, 1.0F, 0.498784971233802F);
        escalar(g0, "carga_14", 0.4562818898575094F, 1.0F, 0.5006339852286678F);
        escalar(g0, "carga_15", 0.4562818898575096F, 1.0F, 0.5006339852286678F);
        escalar(g0, "carga_16", 0.4565627308146223F, 1.0F, 0.498784971233802F);
        escalar(g0, "carga_17", 0.4573092633856008F, 1.0F, 0.49506560703240104F);
        escalar(g0, "carga_18", 0.4593633907315431F, 1.0F, 0.4894319599614362F);
        escalar(g0, "carga_19", 0.48348931277154017F, 1.0F, 0.4818148010577043F);
        escalar(g0, "carga_20", 0.49608241632105265F, 1.0F, 0.4789733398097215F);
        escalar(g0, "carga_21", 0.46085105283872607F, 1.0F, 0.48158622755786645F);
        escalar(g0, "carga_22", 0.45781692158987175F, 1.0F, 0.48353636841649483F);
        escalar(g0, "carga_23", 0.45671277273902067F, 1.0F, 0.4848319830067975F);
        escalar(g0, "carga_24", 0.4562971962723768F, 1.0F, 0.48547845758844804F);
        escalar(g0, "carga_25", 0.456297196272377F, 1.0F, 0.48547845758844804F);
        escalar(g0, "carga_26", 0.4567127727390209F, 1.0F, 0.4848319830067975F);
        escalar(g0, "carga_27", 0.4578169215898713F, 1.0F, 0.48353636841649483F);
        escalar(g0, "carga_28", 0.46085105283872585F, 1.0F, 0.48158622755786645F);
        escalar(g0, "carga_29", 0.4960824163210529F, 1.0F, 0.4789733398097215F);
        escalar(g0, "carga_30", 0.504299396327351F, 1.0F, 0.4779355608347366F);
        escalar(g0, "carga_31", 0.4618401258859626F, 1.0F, 0.4787093289514404F);
        escalar(g0, "carga_32", 0.4581550434462722F, 1.0F, 0.47928881296374914F);
        escalar(g0, "carga_33", 0.4568127729269451F, 1.0F, 0.47967473614412925F);
        escalar(g0, "carga_34", 0.4563074002597463F, 1.0F, 0.4798675781831687F);
        escalar(g0, "carga_35", 0.45630740025974653F, 1.0F, 0.4798675781831687F);
        escalar(g0, "carga_36", 0.45681277292694533F, 1.0F, 0.47967473614412925F);
        escalar(g0, "carga_37", 0.4581550434462718F, 1.0F, 0.47928881296374914F);
        escalar(g0, "carga_38", 0.4618401258859624F, 1.0F, 0.4787093289514404F);
        escalar(g0, "carga_39", 0.5042993963273511F, 1.0F, 0.4779355608347366F);
        escalar(g0, "carga_40", 0.45187292781873534F, 1.0F, 0.4775444375109437F);
        escalar(g0, "carga_41", 0.46233385718974307F, 1.0F, 0.4776234316604825F);
        escalar(g0, "carga_42", 0.45832400950408814F, 1.0F, 0.4776826684691625F);
        escalar(g0, "carga_43", 0.4568627646979512F, 1.0F, 0.4777221554844202F);
        escalar(g0, "carga_44", 0.4563125021666743F, 1.0F, 0.47774189773521053F);
        escalar(g0, "carga_45", 0.4563125021666745F, 1.0F, 0.47774189773521053F);
        escalar(g0, "carga_46", 0.4568627646979514F, 1.0F, 0.4777221554844202F);
        escalar(g0, "carga_47", 0.4583240095040877F, 1.0F, 0.4776826684691625F);
        escalar(g0, "carga_48", 0.46233385718974285F, 1.0F, 0.4776234316604825F);
        escalar(g0, "carga_49", 0.45187292781873556F, 1.0F, 0.4775444375109437F);
        escalar(g0, "carga_50", 0.45187292781873534F, 1.0F, 0.47754443751094416F);
        escalar(g0, "carga_51", 0.46233385718974307F, 1.0F, 0.47762343166048293F);
        escalar(g0, "carga_52", 0.45832400950408814F, 1.0F, 0.47768266846916296F);
        escalar(g0, "carga_53", 0.4568627646979512F, 1.0F, 0.4777221554844207F);
        escalar(g0, "carga_54", 0.4563125021666743F, 1.0F, 0.477741897735211F);
        escalar(g0, "carga_55", 0.4563125021666745F, 1.0F, 0.477741897735211F);
        escalar(g0, "carga_56", 0.4568627646979514F, 1.0F, 0.4777221554844207F);
        escalar(g0, "carga_57", 0.4583240095040877F, 1.0F, 0.47768266846916296F);
        escalar(g0, "carga_58", 0.46233385718974285F, 1.0F, 0.47762343166048293F);
        escalar(g0, "carga_59", 0.45187292781873556F, 1.0F, 0.47754443751094416F);
        escalar(g0, "carga_60", 0.504299396327351F, 1.0F, 0.4779355608347364F);
        escalar(g0, "carga_61", 0.4618401258859626F, 1.0F, 0.47870932895144025F);
        escalar(g0, "carga_62", 0.4581550434462722F, 1.0F, 0.4792888129637489F);
        escalar(g0, "carga_63", 0.4568127729269451F, 1.0F, 0.4796747361441291F);
        escalar(g0, "carga_64", 0.4563074002597463F, 1.0F, 0.47986757818316855F);
        escalar(g0, "carga_65", 0.45630740025974653F, 1.0F, 0.47986757818316855F);
        escalar(g0, "carga_66", 0.45681277292694533F, 1.0F, 0.4796747361441291F);
        escalar(g0, "carga_67", 0.4581550434462718F, 1.0F, 0.4792888129637489F);
        escalar(g0, "carga_68", 0.4618401258859624F, 1.0F, 0.47870932895144025F);
        escalar(g0, "carga_69", 0.5042993963273511F, 1.0F, 0.4779355608347364F);
        escalar(g0, "carga_70", 0.49608241632105254F, 1.0F, 0.47897333980972184F);
        escalar(g0, "carga_71", 0.46085105283872607F, 1.0F, 0.4815862275578667F);
        escalar(g0, "carga_72", 0.45781692158987175F, 1.0F, 0.4835363684164951F);
        escalar(g0, "carga_73", 0.45671277273902067F, 1.0F, 0.48483198300679764F);
        escalar(g0, "carga_74", 0.4562971962723768F, 1.0F, 0.4854784575884482F);
        escalar(g0, "carga_75", 0.456297196272377F, 1.0F, 0.4854784575884482F);
        escalar(g0, "carga_76", 0.4567127727390209F, 1.0F, 0.48483198300679764F);
        escalar(g0, "carga_77", 0.4578169215898713F, 1.0F, 0.48353636841649517F);
        escalar(g0, "carga_78", 0.46085105283872585F, 1.0F, 0.4815862275578668F);
        escalar(g0, "carga_79", 0.49608241632105277F, 1.0F, 0.47897333980972184F);
        escalar(g0, "carga_80", 0.4834893127715399F, 1.0F, 0.481814801057704F);
        escalar(g0, "carga_81", 0.4593633907315433F, 1.0F, 0.48943195996143585F);
        escalar(g0, "carga_82", 0.4573092633856012F, 1.0F, 0.4950656070324008F);
        escalar(g0, "carga_83", 0.45656273081462206F, 1.0F, 0.4987849712338018F);
        escalar(g0, "carga_84", 0.4562818898575094F, 1.0F, 0.5006339852286675F);
        escalar(g0, "carga_85", 0.4562818898575096F, 1.0F, 0.5006339852286675F);
        escalar(g0, "carga_86", 0.4565627308146223F, 1.0F, 0.4987849712338018F);
        escalar(g0, "carga_87", 0.45730926338560085F, 1.0F, 0.4950656070324007F);
        escalar(g0, "carga_88", 0.4593633907315431F, 1.0F, 0.4894319599614358F);
        escalar(g0, "carga_89", 0.4834893127715401F, 1.0F, 0.481814801057704F);
        escalar(g0, "carga_90", 0.4661568964504873F, 1.0F, 0.41108137994721883F);
        escalar(g0, "carga_91", 0.45737220147521995F, 1.0F, 0.4603089293541709F);
        escalar(g0, "carga_92", 0.45663149532610015F, 1.0F, 0.4938477416681598F);
        escalar(g0, "carga_93", 0.4563625971049783F, 1.0F, 0.4291169205172782F);
        escalar(g0, "carga_94", 0.45626148049448567F, 1.0F, 0.4376299730675015F);
        escalar(g0, "carga_95", 0.4562614804944859F, 1.0F, 0.4376299730675015F);
        escalar(g0, "carga_96", 0.4563625971049785F, 1.0F, 0.4291169205172782F);
        escalar(g0, "carga_97", 0.45663149532609976F, 1.0F, 0.4938477416681598F);
        escalar(g0, "carga_98", 0.45737220147521973F, 1.0F, 0.4603089293541709F);
        escalar(g0, "carga_99", 0.4661568964504875F, 1.0F, 0.41108137994721883F);
    }
}
