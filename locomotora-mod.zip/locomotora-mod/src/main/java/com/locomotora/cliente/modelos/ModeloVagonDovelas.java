package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Portadovelas de túnel" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloVagonDovelas {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("vagon_dovelas"), "main"),
            LocomotoraMod.id("textures/entity/vagon_dovelas.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -17.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -17.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -17.5F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -10.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -10.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -10.5F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -17.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -17.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -17.5F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -10.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -10.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, -10.5F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 10.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 10.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 10.5F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 17.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 17.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 17.5F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 10.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 10.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 10.5F, -2.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 17.5F, -2.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 17.5F, -2.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 2.5F, 0.0F, 0.0F, 0.0F, 17.5F, -2.5F, 1.0471975511965976F, "cuerpo")),
            ModeloVagonDovelas::crearCapa,
            16.0F,
            ModeloVagonDovelas::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -14.0F, 14.0F)));

    private ModeloVagonDovelas() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        return LayerDefinition.create(malla, 1024, 128);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(316, 52).addBox(-2.5F, -2.5F, -6.0F, 5.0F, 5.0F, 2.0F).texOffs(816, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(348, 52).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-17.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(830, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(336, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-17.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(844, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(342, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-17.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(316, 52).addBox(-2.5F, -2.5F, -6.0F, 5.0F, 5.0F, 2.0F).texOffs(816, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(358, 52).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-10.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(830, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(336, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(844, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(342, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(316, 52).addBox(-2.5F, -2.5F, 4.0F, 5.0F, 5.0F, 2.0F).texOffs(816, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(368, 52).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-17.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(830, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(336, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-17.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(844, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(342, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-17.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(316, 52).addBox(-2.5F, -2.5F, 4.0F, 5.0F, 5.0F, 2.0F).texOffs(816, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(378, 52).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-10.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(830, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(336, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(844, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(342, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-10.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(188, 52).addBox(-21.5F, -9.0F, 7.0F, 15.0F, 6.0F, 1.0F).texOffs(220, 52).addBox(-21.5F, -9.0F, -8.0F, 15.0F, 6.0F, 1.0F).texOffs(388, 52).addBox(-19.5F, -4.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(398, 52).addBox(-19.5F, -4.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(408, 52).addBox(-12.5F, -4.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(418, 52).addBox(-12.5F, -4.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(316, 52).addBox(-2.5F, -2.5F, -6.0F, 5.0F, 5.0F, 2.0F).texOffs(816, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(428, 52).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(10.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(830, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(336, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(10.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(844, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(342, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(10.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(316, 52).addBox(-2.5F, -2.5F, -6.0F, 5.0F, 5.0F, 2.0F).texOffs(816, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(438, 52).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(17.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(830, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(336, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(17.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(844, 86).addBox(-2.5F, -0.5F, -6.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(342, 52).addBox(-0.5F, -2.5F, -6.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(17.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(316, 52).addBox(-2.5F, -2.5F, 4.0F, 5.0F, 5.0F, 2.0F).texOffs(816, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(448, 52).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(10.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(830, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(336, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(10.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(844, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(342, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(10.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(316, 52).addBox(-2.5F, -2.5F, 4.0F, 5.0F, 5.0F, 2.0F).texOffs(816, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(330, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(458, 52).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(17.5F, -2.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(830, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(336, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(17.5F, -2.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(844, 86).addBox(-2.5F, -0.5F, 4.0F, 5.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(342, 52).addBox(-0.5F, -2.5F, 4.0F, 1.0F, 5.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(17.5F, -2.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(252, 52).addBox(6.5F, -9.0F, 7.0F, 15.0F, 6.0F, 1.0F).texOffs(284, 52).addBox(6.5F, -9.0F, -8.0F, 15.0F, 6.0F, 1.0F).texOffs(468, 52).addBox(8.5F, -4.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(478, 52).addBox(8.5F, -4.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(488, 52).addBox(15.5F, -4.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(498, 52).addBox(15.5F, -4.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bastidor", CubeListBuilder.create().texOffs(40, 52).addBox(-21.0F, -9.0F, -9.0F, 42.0F, 3.0F, 18.0F).texOffs(984, 0).addBox(-23.0F, -9.0F, -9.0F, 2.0F, 4.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("topei", CubeListBuilder.create().texOffs(160, 52).addBox(-25.0F, -8.5F, -2.5F, 2.0F, 4.0F, 5.0F).texOffs(930, 86).addBox(-26.0F, -7.0F, -0.5F, 1.0F, 1.0F, 1.0F).texOffs(0, 52).addBox(21.0F, -9.0F, -9.0F, 2.0F, 4.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("toped", CubeListBuilder.create().texOffs(174, 52).addBox(23.0F, -8.5F, -2.5F, 2.0F, 4.0F, 5.0F).texOffs(934, 86).addBox(25.0F, -7.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("dovela00_ext_0", CubeListBuilder.create().texOffs(508, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -11.899811851493478F, -8.334206016256159F, -0.5497787143782137F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_ext_1", CubeListBuilder.create().texOffs(548, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -10.763495676131829F, -6.104059952915954F, -0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_ext_2", CubeListBuilder.create().texOffs(588, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -9.990041144877669F, -3.723611675321426F, -0.23561944901923504F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_ext_3", CubeListBuilder.create().texOffs(628, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -9.598493275238898F, -1.251475720321847F, -0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_ext_4", CubeListBuilder.create().texOffs(668, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -9.598493275238898F, 1.251475720321847F, 0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_ext_5", CubeListBuilder.create().texOffs(708, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -9.990041144877669F, 3.7236116753214263F, 0.23561944901923504F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_ext_6", CubeListBuilder.create().texOffs(748, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -10.763495676131829F, 6.104059952915954F, 0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_ext_7", CubeListBuilder.create().texOffs(788, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -11.899811851493478F, 8.334206016256159F, 0.5497787143782137F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_int_0", CubeListBuilder.create().texOffs(828, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -13.599835370056793F, -7.292430264224139F, 2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_int_1", CubeListBuilder.create().texOffs(868, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -12.60555871661535F, -5.3410524588014585F, 2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_int_2", CubeListBuilder.create().texOffs(908, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -11.92878600176796F, -3.2581602159062477F, 2.9059732045705586F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_int_3", CubeListBuilder.create().texOffs(948, 52).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -11.586181615834036F, -1.095041255281616F, 3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_int_4", CubeListBuilder.create().texOffs(0, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -11.586181615834036F, 1.095041255281616F, -3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_int_5", CubeListBuilder.create().texOffs(40, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -11.92878600176796F, 3.2581602159062477F, -2.9059732045705586F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_int_6", CubeListBuilder.create().texOffs(80, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -12.60555871661535F, 5.3410524588014585F, -2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_int_7", CubeListBuilder.create().texOffs(120, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -13.599835370056793F, 7.292430264224139F, -2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_cantoi_0", CubeListBuilder.create().texOffs(360, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.5F, -13.364745084375787F, -8.816778784387097F, -2.1991148575128556F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_cantod_0", CubeListBuilder.create().texOffs(398, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.5F, -13.364745084375787F, 8.816778784387097F, 2.1991148575128556F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela00_tapaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(-19.0F, -9.0F, -10.0F));
        g.addOrReplaceChild("dovela00_tapab", CubeListBuilder.create().texOffs(82, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(-3.0F, -9.0F, -10.0F));
        g.addOrReplaceChild("dovela00_tacos", CubeListBuilder.create().texOffs(858, 86).addBox(-16.0F, -10.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(864, 86).addBox(-6.0F, -10.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("dovela01_ext_0", CubeListBuilder.create().texOffs(160, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -14.899811851493478F, -8.334206016256159F, -0.5497787143782137F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_ext_1", CubeListBuilder.create().texOffs(200, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -13.763495676131829F, -6.104059952915954F, -0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_ext_2", CubeListBuilder.create().texOffs(240, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -12.990041144877669F, -3.723611675321426F, -0.23561944901923504F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_ext_3", CubeListBuilder.create().texOffs(280, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -12.598493275238898F, -1.251475720321847F, -0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_ext_4", CubeListBuilder.create().texOffs(320, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -12.598493275238898F, 1.251475720321847F, 0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_ext_5", CubeListBuilder.create().texOffs(360, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -12.990041144877669F, 3.7236116753214263F, 0.23561944901923504F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_ext_6", CubeListBuilder.create().texOffs(400, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -13.763495676131829F, 6.104059952915954F, 0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_ext_7", CubeListBuilder.create().texOffs(440, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -14.899811851493478F, 8.334206016256159F, 0.5497787143782137F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_int_0", CubeListBuilder.create().texOffs(480, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -16.59983537005679F, -7.292430264224139F, 2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_int_1", CubeListBuilder.create().texOffs(520, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -15.605558716615349F, -5.3410524588014585F, 2.74889357189107F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_int_2", CubeListBuilder.create().texOffs(560, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -14.92878600176796F, -3.2581602159062477F, 2.9059732045705586F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_int_3", CubeListBuilder.create().texOffs(600, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -14.586181615834036F, -1.095041255281616F, 3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_int_4", CubeListBuilder.create().texOffs(640, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -14.586181615834036F, 1.095041255281616F, -3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_int_5", CubeListBuilder.create().texOffs(680, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -14.92878600176796F, 3.2581602159062477F, -2.9059732045705586F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_int_6", CubeListBuilder.create().texOffs(720, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -15.605558716615349F, 5.3410524588014585F, -2.74889357189107F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_int_7", CubeListBuilder.create().texOffs(760, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -16.59983537005679F, 7.292430264224139F, -2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_cantoi_0", CubeListBuilder.create().texOffs(436, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.5F, -16.364745084375787F, -8.816778784387097F, -2.199114857512856F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_cantod_0", CubeListBuilder.create().texOffs(474, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.5F, -16.364745084375787F, 8.816778784387097F, 2.199114857512856F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela01_tapaa", CubeListBuilder.create().texOffs(164, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(-19.0F, -12.0F, -10.0F));
        g.addOrReplaceChild("dovela01_tapab", CubeListBuilder.create().texOffs(246, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(-3.0F, -12.0F, -10.0F));
        g.addOrReplaceChild("dovela01_tacos", CubeListBuilder.create().texOffs(870, 86).addBox(-16.0F, -13.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(876, 86).addBox(-6.0F, -13.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("dovela02_ext_0", CubeListBuilder.create().texOffs(800, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -17.899811851493478F, -8.334206016256159F, -0.5497787143782131F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_ext_1", CubeListBuilder.create().texOffs(840, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -16.76349567613183F, -6.104059952915954F, -0.392699081698725F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_ext_2", CubeListBuilder.create().texOffs(880, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -15.990041144877669F, -3.723611675321426F, -0.23561944901923437F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_ext_3", CubeListBuilder.create().texOffs(920, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -15.598493275238898F, -1.251475720321847F, -0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_ext_4", CubeListBuilder.create().texOffs(960, 74).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -15.598493275238898F, 1.251475720321847F, 0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_ext_5", CubeListBuilder.create().texOffs(0, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -15.990041144877669F, 3.7236116753214263F, 0.23561944901923437F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_ext_6", CubeListBuilder.create().texOffs(40, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -16.76349567613183F, 6.104059952915954F, 0.392699081698725F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_ext_7", CubeListBuilder.create().texOffs(80, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -17.899811851493478F, 8.334206016256159F, 0.5497787143782131F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_int_0", CubeListBuilder.create().texOffs(120, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -19.59983537005679F, -7.292430264224139F, 2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_int_1", CubeListBuilder.create().texOffs(160, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -18.60555871661535F, -5.3410524588014585F, 2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_int_2", CubeListBuilder.create().texOffs(200, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -17.92878600176796F, -3.2581602159062477F, 2.905973204570559F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_int_3", CubeListBuilder.create().texOffs(240, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -17.586181615834036F, -1.095041255281616F, 3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_int_4", CubeListBuilder.create().texOffs(280, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -17.586181615834036F, 1.095041255281616F, -3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_int_5", CubeListBuilder.create().texOffs(320, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -17.92878600176796F, 3.2581602159062477F, -2.905973204570559F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_int_6", CubeListBuilder.create().texOffs(360, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -18.60555871661535F, 5.3410524588014585F, -2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_int_7", CubeListBuilder.create().texOffs(400, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.5F, -19.59983537005679F, 7.292430264224139F, -2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_cantoi_0", CubeListBuilder.create().texOffs(512, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.5F, -19.364745084375787F, -8.816778784387097F, -2.199114857512856F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_cantod_0", CubeListBuilder.create().texOffs(550, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.5F, -19.364745084375787F, 8.816778784387097F, 2.199114857512856F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela02_tapaa", CubeListBuilder.create().texOffs(328, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(-19.0F, -15.0F, -10.0F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("dovela02_tapab", CubeListBuilder.create().texOffs(410, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(-3.0F, -15.0F, -10.0F));
        g.addOrReplaceChild("dovela02_tacos", CubeListBuilder.create().texOffs(882, 86).addBox(-16.0F, -16.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(888, 86).addBox(-6.0F, -16.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("dovela10_ext_0", CubeListBuilder.create().texOffs(440, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -11.899811851493478F, -8.334206016256159F, -0.5497787143782137F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_ext_1", CubeListBuilder.create().texOffs(480, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -10.763495676131829F, -6.104059952915954F, -0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_ext_2", CubeListBuilder.create().texOffs(520, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -9.990041144877669F, -3.723611675321426F, -0.23561944901923504F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_ext_3", CubeListBuilder.create().texOffs(560, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -9.598493275238898F, -1.251475720321847F, -0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_ext_4", CubeListBuilder.create().texOffs(600, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -9.598493275238898F, 1.251475720321847F, 0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_ext_5", CubeListBuilder.create().texOffs(640, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -9.990041144877669F, 3.7236116753214263F, 0.23561944901923504F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_ext_6", CubeListBuilder.create().texOffs(680, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -10.763495676131829F, 6.104059952915954F, 0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_ext_7", CubeListBuilder.create().texOffs(720, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -11.899811851493478F, 8.334206016256159F, 0.5497787143782137F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_int_0", CubeListBuilder.create().texOffs(760, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -13.599835370056793F, -7.292430264224139F, 2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_int_1", CubeListBuilder.create().texOffs(800, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -12.60555871661535F, -5.3410524588014585F, 2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_int_2", CubeListBuilder.create().texOffs(840, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -11.92878600176796F, -3.2581602159062477F, 2.9059732045705586F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_int_3", CubeListBuilder.create().texOffs(880, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -11.586181615834036F, -1.095041255281616F, 3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_int_4", CubeListBuilder.create().texOffs(920, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -11.586181615834036F, 1.095041255281616F, -3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_int_5", CubeListBuilder.create().texOffs(960, 78).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -11.92878600176796F, 3.2581602159062477F, -2.9059732045705586F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_int_6", CubeListBuilder.create().texOffs(0, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -12.60555871661535F, 5.3410524588014585F, -2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_int_7", CubeListBuilder.create().texOffs(40, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -13.599835370056793F, 7.292430264224139F, -2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_cantoi_0", CubeListBuilder.create().texOffs(588, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.5F, -13.364745084375787F, -8.816778784387097F, -2.1991148575128556F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_cantod_0", CubeListBuilder.create().texOffs(626, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.5F, -13.364745084375787F, 8.816778784387097F, 2.1991148575128556F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela10_tapaa", CubeListBuilder.create().texOffs(492, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(2.0F, -9.0F, -10.0F));
        g.addOrReplaceChild("dovela10_tapab", CubeListBuilder.create().texOffs(574, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(18.0F, -9.0F, -10.0F));
        g.addOrReplaceChild("dovela10_tacos", CubeListBuilder.create().texOffs(894, 86).addBox(5.0F, -10.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(900, 86).addBox(15.0F, -10.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("dovela11_ext_0", CubeListBuilder.create().texOffs(80, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -14.899811851493478F, -8.334206016256159F, -0.5497787143782137F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_ext_1", CubeListBuilder.create().texOffs(120, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -13.763495676131829F, -6.104059952915954F, -0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_ext_2", CubeListBuilder.create().texOffs(160, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -12.990041144877669F, -3.723611675321426F, -0.23561944901923504F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_ext_3", CubeListBuilder.create().texOffs(200, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -12.598493275238898F, -1.251475720321847F, -0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_ext_4", CubeListBuilder.create().texOffs(240, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -12.598493275238898F, 1.251475720321847F, 0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_ext_5", CubeListBuilder.create().texOffs(280, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -12.990041144877669F, 3.7236116753214263F, 0.23561944901923504F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_ext_6", CubeListBuilder.create().texOffs(320, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -13.763495676131829F, 6.104059952915954F, 0.39269908169872375F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_ext_7", CubeListBuilder.create().texOffs(360, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -14.899811851493478F, 8.334206016256159F, 0.5497787143782137F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_int_0", CubeListBuilder.create().texOffs(400, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -16.59983537005679F, -7.292430264224139F, 2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_int_1", CubeListBuilder.create().texOffs(440, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -15.605558716615349F, -5.3410524588014585F, 2.74889357189107F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_int_2", CubeListBuilder.create().texOffs(480, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -14.92878600176796F, -3.2581602159062477F, 2.9059732045705586F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_int_3", CubeListBuilder.create().texOffs(520, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -14.586181615834036F, -1.095041255281616F, 3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_int_4", CubeListBuilder.create().texOffs(560, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -14.586181615834036F, 1.095041255281616F, -3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_int_5", CubeListBuilder.create().texOffs(600, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -14.92878600176796F, 3.2581602159062477F, -2.9059732045705586F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_int_6", CubeListBuilder.create().texOffs(640, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -15.605558716615349F, 5.3410524588014585F, -2.74889357189107F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_int_7", CubeListBuilder.create().texOffs(680, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -16.59983537005679F, 7.292430264224139F, -2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_cantoi_0", CubeListBuilder.create().texOffs(664, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.5F, -16.364745084375787F, -8.816778784387097F, -2.199114857512856F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_cantod_0", CubeListBuilder.create().texOffs(702, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.5F, -16.364745084375787F, 8.816778784387097F, 2.199114857512856F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela11_tapaa", CubeListBuilder.create().texOffs(656, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(2.0F, -12.0F, -10.0F));
        g.addOrReplaceChild("dovela11_tapab", CubeListBuilder.create().texOffs(738, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(18.0F, -12.0F, -10.0F));
        g.addOrReplaceChild("dovela11_tacos", CubeListBuilder.create().texOffs(906, 86).addBox(5.0F, -13.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(912, 86).addBox(15.0F, -13.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("dovela12_ext_0", CubeListBuilder.create().texOffs(720, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -17.899811851493478F, -8.334206016256159F, -0.5497787143782131F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_ext_1", CubeListBuilder.create().texOffs(760, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -16.76349567613183F, -6.104059952915954F, -0.392699081698725F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_ext_2", CubeListBuilder.create().texOffs(800, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -15.990041144877669F, -3.723611675321426F, -0.23561944901923437F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_ext_3", CubeListBuilder.create().texOffs(840, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -15.598493275238898F, -1.251475720321847F, -0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_ext_4", CubeListBuilder.create().texOffs(880, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -15.598493275238898F, 1.251475720321847F, 0.07853981633974456F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_ext_5", CubeListBuilder.create().texOffs(920, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -15.990041144877669F, 3.7236116753214263F, 0.23561944901923437F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_ext_6", CubeListBuilder.create().texOffs(960, 82).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -16.76349567613183F, 6.104059952915954F, 0.392699081698725F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_ext_7", CubeListBuilder.create().texOffs(0, 86).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -17.899811851493478F, 8.334206016256159F, 0.5497787143782131F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_int_0", CubeListBuilder.create().texOffs(40, 86).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -19.59983537005679F, -7.292430264224139F, 2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_int_1", CubeListBuilder.create().texOffs(80, 86).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -18.60555871661535F, -5.3410524588014585F, 2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_int_2", CubeListBuilder.create().texOffs(120, 86).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -17.92878600176796F, -3.2581602159062477F, 2.905973204570559F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_int_3", CubeListBuilder.create().texOffs(160, 86).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -17.586181615834036F, -1.095041255281616F, 3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_int_4", CubeListBuilder.create().texOffs(200, 86).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -17.586181615834036F, 1.095041255281616F, -3.0630528372500483F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_int_5", CubeListBuilder.create().texOffs(240, 86).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -17.92878600176796F, 3.2581602159062477F, -2.905973204570559F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_int_6", CubeListBuilder.create().texOffs(280, 86).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -18.60555871661535F, 5.3410524588014585F, -2.7488935718910694F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_int_7", CubeListBuilder.create().texOffs(320, 86).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(10.5F, -19.59983537005679F, 7.292430264224139F, -2.5918139392115798F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_cantoi_0", CubeListBuilder.create().texOffs(740, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.5F, -19.364745084375787F, -8.816778784387097F, -2.199114857512856F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_cantod_0", CubeListBuilder.create().texOffs(778, 86).addBox(-8.5F, -1.0F, -1.0F, 17.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.5F, -19.364745084375787F, 8.816778784387097F, 2.199114857512856F, 0.0F, 0.0F));
        g.addOrReplaceChild("dovela12_tapaa", CubeListBuilder.create().texOffs(820, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(2.0F, -15.0F, -10.0F));
        g.addOrReplaceChild("dovela12_tapab", CubeListBuilder.create().texOffs(902, 0).addBox(0.0F, -12.0F, 0.0F, 1.0F, 12.0F, 40.0F), PartPose.offset(18.0F, -15.0F, -10.0F));
        g.addOrReplaceChild("dovela12_tacos", CubeListBuilder.create().texOffs(918, 86).addBox(5.0F, -16.0F, -1.0F, 1.0F, 1.0F, 2.0F).texOffs(924, 86).addBox(15.0F, -16.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "dovela00_ext_0", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela00_ext_1", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela00_ext_2", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela00_ext_3", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela00_ext_4", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela00_ext_5", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela00_ext_6", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela00_ext_7", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela00_int_0", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela00_int_1", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela00_int_2", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela00_int_3", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela00_int_4", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela00_int_5", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela00_int_6", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela00_int_7", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela00_cantoi_0", 1.0029411764705882F, 1.0F, 1.025F);
        escalar(g0, "dovela00_cantod_0", 1.0029411764705882F, 1.0F, 1.025F);
        escalar(g0, "dovela00_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "dovela00_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "dovela01_ext_0", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela01_ext_1", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela01_ext_2", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela01_ext_3", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela01_ext_4", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela01_ext_5", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela01_ext_6", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela01_ext_7", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela01_int_0", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela01_int_1", 1.0029411764705882F, 1.0F, 0.7489515601265525F);
        escalar(g0, "dovela01_int_2", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela01_int_3", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela01_int_4", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela01_int_5", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela01_int_6", 1.0029411764705882F, 1.0F, 0.7489515601265525F);
        escalar(g0, "dovela01_int_7", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela01_cantoi_0", 1.0029411764705882F, 1.0F, 1.0249999999999995F);
        escalar(g0, "dovela01_cantod_0", 1.0029411764705882F, 1.0F, 1.0249999999999995F);
        escalar(g0, "dovela01_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "dovela01_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "dovela02_ext_0", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela02_ext_1", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela02_ext_2", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela02_ext_3", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela02_ext_4", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela02_ext_5", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela02_ext_6", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela02_ext_7", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela02_int_0", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela02_int_1", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela02_int_2", 1.0029411764705882F, 1.0F, 0.7489515601265525F);
        escalar(g0, "dovela02_int_3", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela02_int_4", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela02_int_5", 1.0029411764705882F, 1.0F, 0.7489515601265525F);
        escalar(g0, "dovela02_int_6", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela02_int_7", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela02_cantoi_0", 1.0029411764705882F, 1.0F, 1.0249999999999995F);
        escalar(g0, "dovela02_cantod_0", 1.0029411764705882F, 1.0F, 1.0249999999999995F);
        escalar(g0, "dovela02_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "dovela02_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "dovela10_ext_0", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela10_ext_1", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela10_ext_2", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela10_ext_3", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela10_ext_4", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela10_ext_5", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela10_ext_6", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela10_ext_7", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela10_int_0", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela10_int_1", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela10_int_2", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela10_int_3", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela10_int_4", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela10_int_5", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela10_int_6", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela10_int_7", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela10_cantoi_0", 1.0029411764705882F, 1.0F, 1.025F);
        escalar(g0, "dovela10_cantod_0", 1.0029411764705882F, 1.0F, 1.025F);
        escalar(g0, "dovela10_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "dovela10_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "dovela11_ext_0", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela11_ext_1", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela11_ext_2", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela11_ext_3", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela11_ext_4", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela11_ext_5", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela11_ext_6", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela11_ext_7", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela11_int_0", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela11_int_1", 1.0029411764705882F, 1.0F, 0.7489515601265525F);
        escalar(g0, "dovela11_int_2", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela11_int_3", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela11_int_4", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela11_int_5", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela11_int_6", 1.0029411764705882F, 1.0F, 0.7489515601265525F);
        escalar(g0, "dovela11_int_7", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela11_cantoi_0", 1.0029411764705882F, 1.0F, 1.0249999999999995F);
        escalar(g0, "dovela11_cantod_0", 1.0029411764705882F, 1.0F, 1.0249999999999995F);
        escalar(g0, "dovela11_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "dovela11_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "dovela12_ext_0", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela12_ext_1", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela12_ext_2", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela12_ext_3", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela12_ext_4", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela12_ext_5", 1.0029411764705882F, 1.0F, 0.8535636877636792F);
        escalar(g0, "dovela12_ext_6", 1.0029411764705882F, 1.0F, 0.8535636877636796F);
        escalar(g0, "dovela12_ext_7", 1.0029411764705882F, 1.0F, 0.8535636877636793F);
        escalar(g0, "dovela12_int_0", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela12_int_1", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela12_int_2", 1.0029411764705882F, 1.0F, 0.7489515601265525F);
        escalar(g0, "dovela12_int_3", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela12_int_4", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela12_int_5", 1.0029411764705882F, 1.0F, 0.7489515601265525F);
        escalar(g0, "dovela12_int_6", 1.0029411764705882F, 1.0F, 0.7489515601265526F);
        escalar(g0, "dovela12_int_7", 1.0029411764705882F, 1.0F, 0.7489515601265527F);
        escalar(g0, "dovela12_cantoi_0", 1.0029411764705882F, 1.0F, 1.0249999999999995F);
        escalar(g0, "dovela12_cantod_0", 1.0029411764705882F, 1.0F, 1.0249999999999995F);
        escalar(g0, "dovela12_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "dovela12_tapab", 1.0F, 0.5F, 0.5F);
    }
}
