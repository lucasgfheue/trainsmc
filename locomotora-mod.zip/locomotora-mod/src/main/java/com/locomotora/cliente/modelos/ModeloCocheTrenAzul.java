package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "Coche Tren Azul" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloCocheTrenAzul {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("coche_tren_azul"), "main"),
            LocomotoraMod.id("textures/entity/coche_tren_azul.png"),
            List.of(
                new DatosModelo.Animada("bogie0i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -58.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -58.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -58.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -58.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -58.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -58.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie0d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, -42.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 58.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 58.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1i1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 58.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d0_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 42.0F, -3.5F, 1.0471975511965976F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_0", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 58.0F, -3.5F, 0.0F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_1", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 58.0F, -3.5F, 0.5235987755982988F, "cuerpo"),
                new DatosModelo.Animada("bogie1d1_2", DatosModelo.RUEDA, 3.5F, 0.0F, 0.0F, 0.0F, 58.0F, -3.5F, 1.0471975511965976F, "cuerpo")),
            ModeloCocheTrenAzul::crearCapa,
            16.0F,
            ModeloCocheTrenAzul::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", -50.0F, 50.0F)));

    private ModeloCocheTrenAzul() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        return LayerDefinition.create(malla, 1024, 256);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("caja", CubeListBuilder.create().texOffs(482, 76).addBox(-70.0F, -31.0F, 11.5F, 140.0F, 20.0F, 1.0F).texOffs(0, 100).addBox(-70.0F, -31.0F, -12.5F, 140.0F, 20.0F, 1.0F).texOffs(0, 76).addBox(-69.0F, -12.0F, -11.5F, 138.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_techo_0", CubeListBuilder.create().texOffs(646, 148).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -31.737882370268238F, -11.619666982027539F, -2.4439976288837912F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_1", CubeListBuilder.create().texOffs(0, 157).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.09636151369325F, -9.772733601944374F, -2.570833087921246F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_2", CubeListBuilder.create().texOffs(286, 157).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.21029915457268F, -7.768794624375898F, -2.6976685469587003F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_3", CubeListBuilder.create().texOffs(572, 157).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.061799128742905F, -5.64004468895034F, -2.8245040059961535F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_4", CubeListBuilder.create().texOffs(0, 161).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.637181511256756F, -3.420683608035631F, -2.9513394650336116F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_5", CubeListBuilder.create().texOffs(286, 161).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.92720239366151F, -1.1463669235443572F, -3.0781749240710674F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_6", CubeListBuilder.create().texOffs(572, 161).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.92720239366151F, 1.1463669235443557F, 3.0781749240710674F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_7", CubeListBuilder.create().texOffs(0, 165).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.637181511256756F, 3.420683608035629F, 2.9513394650336116F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_8", CubeListBuilder.create().texOffs(286, 165).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -35.061799128742905F, 5.640044688950338F, 2.8245040059961535F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_9", CubeListBuilder.create().texOffs(572, 165).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -34.21029915457268F, 7.7687946243758965F, 2.6976685469587025F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_10", CubeListBuilder.create().texOffs(0, 169).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -33.09636151369325F, 9.77273360194437F, 2.5708330879212444F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_techo_11", CubeListBuilder.create().texOffs(286, 169).addBox(-70.0F, -1.0F, -1.5F, 140.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.0F, -31.737882370268235F, 11.619666982027539F, 2.4439976288837912F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_puntaa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -25.0F, 0.0F, 1.0F, 25.0F, 23.0F), PartPose.offset(-70.0F, -11.0F, -11.5F));
        g.addOrReplaceChild("caja_puntab", CubeListBuilder.create().texOffs(48, 0).addBox(0.0F, -25.0F, 0.0F, 1.0F, 25.0F, 23.0F), PartPose.offset(69.0F, -11.0F, -11.5F));
        g.addOrReplaceChild("literas", CubeListBuilder.create().texOffs(96, 0).addBox(-60.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(264, 121).addBox(-59.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(800, 130).addBox(-57.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(296, 121).addBox(-59.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(828, 130).addBox(-57.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(328, 121).addBox(-59.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(856, 130).addBox(-57.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(360, 121).addBox(-59.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(884, 130).addBox(-57.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(144, 0).addBox(-50.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(392, 121).addBox(-49.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(912, 130).addBox(-47.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(424, 121).addBox(-49.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(940, 130).addBox(-47.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(456, 121).addBox(-49.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(968, 130).addBox(-47.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(488, 121).addBox(-49.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(996, 130).addBox(-47.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(192, 0).addBox(-40.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(520, 121).addBox(-39.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(0, 139).addBox(-37.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(552, 121).addBox(-39.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(28, 139).addBox(-37.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(584, 121).addBox(-39.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(56, 139).addBox(-37.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(616, 121).addBox(-39.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(84, 139).addBox(-37.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(240, 0).addBox(-30.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(648, 121).addBox(-29.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(112, 139).addBox(-27.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(680, 121).addBox(-29.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(140, 139).addBox(-27.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(712, 121).addBox(-29.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(168, 139).addBox(-27.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(744, 121).addBox(-29.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(196, 139).addBox(-27.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(288, 0).addBox(-20.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(776, 121).addBox(-19.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(224, 139).addBox(-17.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(808, 121).addBox(-19.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(252, 139).addBox(-17.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(840, 121).addBox(-19.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(280, 139).addBox(-17.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(872, 121).addBox(-19.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(308, 139).addBox(-17.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(336, 0).addBox(-10.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(904, 121).addBox(-9.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(336, 139).addBox(-7.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(936, 121).addBox(-9.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(364, 139).addBox(-7.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(968, 121).addBox(-9.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(392, 139).addBox(-7.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(0, 130).addBox(-9.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(420, 139).addBox(-7.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(384, 0).addBox(0.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(32, 130).addBox(1.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(448, 139).addBox(3.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(64, 130).addBox(1.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(476, 139).addBox(3.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(96, 130).addBox(1.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(504, 139).addBox(3.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(128, 130).addBox(1.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(532, 139).addBox(3.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(432, 0).addBox(10.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(160, 130).addBox(11.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(560, 139).addBox(13.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(192, 130).addBox(11.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(588, 139).addBox(13.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(224, 130).addBox(11.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(616, 139).addBox(13.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(256, 130).addBox(11.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(644, 139).addBox(13.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(480, 0).addBox(20.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(288, 130).addBox(21.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(672, 139).addBox(23.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(320, 130).addBox(21.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(700, 139).addBox(23.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(352, 130).addBox(21.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(728, 139).addBox(23.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(384, 130).addBox(21.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(756, 139).addBox(23.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(528, 0).addBox(30.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(416, 130).addBox(31.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(784, 139).addBox(33.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(448, 130).addBox(31.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(812, 139).addBox(33.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(480, 130).addBox(31.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(840, 139).addBox(33.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(512, 130).addBox(31.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(868, 139).addBox(33.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(576, 0).addBox(40.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(544, 130).addBox(41.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(896, 139).addBox(43.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(576, 130).addBox(41.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(924, 139).addBox(43.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(608, 130).addBox(41.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(952, 139).addBox(43.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(640, 130).addBox(41.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(980, 139).addBox(43.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(624, 0).addBox(50.0F, -29.0F, -11.5F, 1.0F, 17.0F, 23.0F).texOffs(672, 130).addBox(51.0F, -16.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(0, 148).addBox(53.0F, -17.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(704, 130).addBox(51.0F, -16.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(28, 148).addBox(53.0F, -17.0F, 3.0F, 6.0F, 1.0F, 8.0F).texOffs(736, 130).addBox(51.0F, -24.0F, -11.0F, 8.0F, 1.0F, 8.0F).texOffs(56, 148).addBox(53.0F, -25.0F, -11.0F, 6.0F, 1.0F, 8.0F).texOffs(768, 130).addBox(51.0F, -24.0F, 3.0F, 8.0F, 1.0F, 8.0F).texOffs(84, 148).addBox(53.0F, -25.0F, 3.0F, 6.0F, 1.0F, 8.0F), PartPose.ZERO);
        g.addOrReplaceChild("aire", CubeListBuilder.create().texOffs(362, 100).addBox(-46.0F, -38.0F, -5.0F, 12.0F, 3.0F, 10.0F).texOffs(370, 148).addBox(-44.0F, -39.0F, -3.0F, 8.0F, 1.0F, 6.0F).texOffs(406, 100).addBox(-6.0F, -38.0F, -5.0F, 12.0F, 3.0F, 10.0F).texOffs(398, 148).addBox(-4.0F, -39.0F, -3.0F, 8.0F, 1.0F, 6.0F).texOffs(450, 100).addBox(34.0F, -38.0F, -5.0F, 12.0F, 3.0F, 10.0F).texOffs(426, 148).addBox(36.0F, -39.0F, -3.0F, 8.0F, 1.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0i0_0", CubeListBuilder.create().texOffs(112, 148).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(572, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(130, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(486, 148).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-58.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i0_1", CubeListBuilder.create().texOffs(590, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(138, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i0_2", CubeListBuilder.create().texOffs(608, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(146, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0i1_0", CubeListBuilder.create().texOffs(112, 148).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(572, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(130, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(496, 148).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-42.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0i1_1", CubeListBuilder.create().texOffs(590, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(138, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0i1_2", CubeListBuilder.create().texOffs(608, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(146, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d0_0", CubeListBuilder.create().texOffs(112, 148).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(572, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(130, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(506, 148).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-58.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d0_1", CubeListBuilder.create().texOffs(590, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(138, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d0_2", CubeListBuilder.create().texOffs(608, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(146, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0d1_0", CubeListBuilder.create().texOffs(112, 148).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(572, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(130, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(516, 148).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-42.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie0d1_1", CubeListBuilder.create().texOffs(590, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(138, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie0d1_2", CubeListBuilder.create().texOffs(608, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(146, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie0", CubeListBuilder.create().texOffs(154, 148).addBox(-63.0F, -9.0F, 7.0F, 26.0F, 6.0F, 1.0F).texOffs(208, 148).addBox(-63.0F, -9.0F, -8.0F, 26.0F, 6.0F, 1.0F).texOffs(526, 148).addBox(-60.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(536, 148).addBox(-60.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(546, 148).addBox(-44.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(556, 148).addBox(-44.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie0_pivote", CubeListBuilder.create().texOffs(282, 100).addBox(-53.0F, -11.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuelle_aire02_0", CubeListBuilder.create().texOffs(494, 100).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(728, 0).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offset(-50.0F, 0.0F, -7.5F));
        g.addOrReplaceChild("fuelle_aire02_1", CubeListBuilder.create().texOffs(560, 100).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(794, 0).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(-50.0F, 0.0F, -7.5F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("fuelle_aire02_2", CubeListBuilder.create().texOffs(626, 100).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(860, 0).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(-50.0F, 0.0F, -7.5F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("fuelle_aire017_0", CubeListBuilder.create().texOffs(692, 100).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(926, 0).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offset(-50.0F, 0.0F, 7.5F));
        g.addOrReplaceChild("fuelle_aire017_1", CubeListBuilder.create().texOffs(758, 100).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(0, 48).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(-50.0F, 0.0F, 7.5F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("fuelle_aire017_2", CubeListBuilder.create().texOffs(824, 100).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(66, 48).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(-50.0F, 0.0F, 7.5F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("bogie1i0_0", CubeListBuilder.create().texOffs(112, 148).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(572, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(130, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(566, 148).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(42.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i0_1", CubeListBuilder.create().texOffs(590, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(138, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i0_2", CubeListBuilder.create().texOffs(608, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(146, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1i1_0", CubeListBuilder.create().texOffs(112, 148).addBox(-3.5F, -3.5F, -6.0F, 7.0F, 7.0F, 2.0F).texOffs(572, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(130, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(576, 148).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(58.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1i1_1", CubeListBuilder.create().texOffs(590, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(138, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(58.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1i1_2", CubeListBuilder.create().texOffs(608, 169).addBox(-3.5F, -1.0F, -6.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(146, 148).addBox(-1.0F, -3.5F, -6.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(58.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d0_0", CubeListBuilder.create().texOffs(112, 148).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(572, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(130, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(586, 148).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(42.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d0_1", CubeListBuilder.create().texOffs(590, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(138, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d0_2", CubeListBuilder.create().texOffs(608, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(146, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(42.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1d1_0", CubeListBuilder.create().texOffs(112, 148).addBox(-3.5F, -3.5F, 4.0F, 7.0F, 7.0F, 2.0F).texOffs(572, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(130, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(596, 148).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(58.0F, -3.5F, 0.0F));
        g.addOrReplaceChild("bogie1d1_1", CubeListBuilder.create().texOffs(590, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(138, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(58.0F, -3.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("bogie1d1_2", CubeListBuilder.create().texOffs(608, 169).addBox(-3.5F, -1.0F, 4.0F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(146, 148).addBox(-1.0F, -3.5F, 4.0F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(58.0F, -3.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("bogie1", CubeListBuilder.create().texOffs(262, 148).addBox(37.0F, -9.0F, 7.0F, 26.0F, 6.0F, 1.0F).texOffs(316, 148).addBox(37.0F, -9.0F, -8.0F, 26.0F, 6.0F, 1.0F).texOffs(606, 148).addBox(40.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(616, 148).addBox(40.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F).texOffs(626, 148).addBox(56.0F, -5.5F, 8.0F, 4.0F, 4.0F, 1.0F).texOffs(636, 148).addBox(56.0F, -5.5F, -9.0F, 4.0F, 4.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("bogie1_pivote", CubeListBuilder.create().texOffs(322, 100).addBox(47.0F, -11.0F, -7.0F, 6.0F, 3.0F, 14.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuelle_aire12_0", CubeListBuilder.create().texOffs(890, 100).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(132, 48).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offset(50.0F, 0.0F, -7.5F));
        g.addOrReplaceChild("fuelle_aire12_1", CubeListBuilder.create().texOffs(956, 100).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(198, 48).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(50.0F, 0.0F, -7.5F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("fuelle_aire12_2", CubeListBuilder.create().texOffs(0, 121).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(264, 48).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(50.0F, 0.0F, -7.5F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("fuelle_aire117_0", CubeListBuilder.create().texOffs(66, 121).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(330, 48).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offset(50.0F, 0.0F, 7.5F));
        g.addOrReplaceChild("fuelle_aire117_1", CubeListBuilder.create().texOffs(132, 121).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(396, 48).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(50.0F, 0.0F, 7.5F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("fuelle_aire117_2", CubeListBuilder.create().texOffs(198, 121).addBox(-13.0F, -10.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(462, 48).addBox(-3.5F, -10.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(50.0F, 0.0F, 7.5F, 0.0F, 1.0471975511965976F, 0.0F));
        g.addOrReplaceChild("bajo_piso", CubeListBuilder.create().texOffs(528, 48).addBox(-70.0F, -11.0F, -11.0F, 140.0F, 2.0F, 22.0F).texOffs(322, 76).addBox(-32.0F, -9.0F, -9.0F, 22.0F, 4.0F, 18.0F).texOffs(402, 76).addBox(10.0F, -9.0F, -9.0F, 22.0F, 4.0F, 18.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuellei", CubeListBuilder.create().texOffs(672, 0).addBox(-72.0F, -31.0F, -6.0F, 2.0F, 19.0F, 12.0F).texOffs(454, 148).addBox(-77.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuelled", CubeListBuilder.create().texOffs(700, 0).addBox(70.0F, -31.0F, -6.0F, 2.0F, 19.0F, 12.0F).texOffs(470, 148).addBox(72.0F, -11.0F, -1.5F, 5.0F, 3.0F, 3.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "caja_techo_0", 1.0001428571428572F, 1.0F, 0.7724506846320365F);
        escalar(g0, "caja_techo_1", 1.0001428571428572F, 1.0F, 0.7724506846320346F);
        escalar(g0, "caja_techo_2", 1.0001428571428572F, 1.0F, 0.7724506846320374F);
        escalar(g0, "caja_techo_3", 1.0001428571428572F, 1.0F, 0.7724506846320361F);
        escalar(g0, "caja_techo_4", 1.0001428571428572F, 1.0F, 0.7724506846320361F);
        escalar(g0, "caja_techo_5", 1.0001428571428572F, 1.0F, 0.7724506846320365F);
        escalar(g0, "caja_techo_6", 1.0001428571428572F, 1.0F, 0.7724506846320355F);
        escalar(g0, "caja_techo_7", 1.0001428571428572F, 1.0F, 0.7724506846320366F);
        escalar(g0, "caja_techo_8", 1.0001428571428572F, 1.0F, 0.7724506846320368F);
        escalar(g0, "caja_techo_9", 1.0001428571428572F, 1.0F, 0.7724506846320353F);
        escalar(g0, "caja_techo_10", 1.0001428571428572F, 1.0F, 0.7724506846320368F);
        escalar(g0, "caja_techo_11", 1.0001428571428572F, 1.0F, 0.7724506846320365F);
        escalar(g0, "fuelle_aire02_0", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
        escalar(g0, "fuelle_aire02_1", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
        escalar(g0, "fuelle_aire02_2", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
        escalar(g0, "fuelle_aire017_0", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
        escalar(g0, "fuelle_aire017_1", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
        escalar(g0, "fuelle_aire017_2", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
        escalar(g0, "fuelle_aire12_0", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
        escalar(g0, "fuelle_aire12_1", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
        escalar(g0, "fuelle_aire12_2", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
        escalar(g0, "fuelle_aire117_0", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
        escalar(g0, "fuelle_aire117_1", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
        escalar(g0, "fuelle_aire117_2", 0.14860397327524127F, 1.0F, 0.14860397327524127F);
    }
}
