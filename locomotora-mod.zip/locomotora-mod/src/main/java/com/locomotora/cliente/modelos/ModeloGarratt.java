package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D "EAR 59 Garratt" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, riel en Y = 0. Las superficies curvas están hechas
 * con placas finas giradas y estiradas a medida (escala de cada pieza), así que no tienen escalones.
 */
public final class ModeloGarratt {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("garratt"), "main"),
            LocomotoraMod.id("textures/entity/garratt.png"),
            List.of(
                new DatosModelo.Animada("furmi0_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -100.0F, -6.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("furmi0_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -100.0F, -6.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("furmi0_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -100.0F, -6.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("furmi1_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -86.0F, -6.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("furmi1_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -86.0F, -6.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("furmi1_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -86.0F, -6.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("furmi2_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -72.0F, -6.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("furmi2_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -72.0F, -6.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("furmi2_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -72.0F, -6.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("furmi3_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -58.0F, -6.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("furmi3_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -58.0F, -6.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("furmi3_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, -58.0F, -6.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("fubiela_i", DatosModelo.BIELA, 6.5F, 2.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fumotriz_i", DatosModelo.MOTRIZ, 6.5F, 2.5F, 0.0F, -38.0F, -86.0F, -9.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fucruceta_i", DatosModelo.CRUCETA, 6.5F, 2.5F, 0.0F, -38.0F, 0.0F, 0.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("furmd0_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -100.0F, -6.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("furmd0_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -100.0F, -6.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("furmd0_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -100.0F, -6.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("furmd1_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -86.0F, -6.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("furmd1_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -86.0F, -6.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("furmd1_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -86.0F, -6.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("furmd2_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -72.0F, -6.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("furmd2_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -72.0F, -6.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("furmd2_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -72.0F, -6.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("furmd3_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -58.0F, -6.5F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("furmd3_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -58.0F, -6.5F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("furmd3_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, -58.0F, -6.5F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("fubiela_d", DatosModelo.BIELA, 6.5F, 2.5F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fumotriz_d", DatosModelo.MOTRIZ, 6.5F, 2.5F, 1.5707963267948966F, -38.0F, -86.0F, -9.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fucruceta_d", DatosModelo.CRUCETA, 6.5F, 2.5F, 1.5707963267948966F, -38.0F, 0.0F, 0.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fubi0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -128.0F, -4.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fubi0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -128.0F, -4.0F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fubi0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -128.0F, -4.0F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("fubi1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -118.0F, -4.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fubi1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -118.0F, -4.0F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fubi1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -118.0F, -4.0F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("fubd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -128.0F, -4.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fubd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -128.0F, -4.0F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fubd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -128.0F, -4.0F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("fubd1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -118.0F, -4.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("fubd1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -118.0F, -4.0F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("fubd1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -118.0F, -4.0F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("futi0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -46.0F, -4.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("futi0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -46.0F, -4.0F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("futi0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -46.0F, -4.0F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("futd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -46.0F, -4.0F, 0.0F, "unidad_delantera"),
                new DatosModelo.Animada("futd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -46.0F, -4.0F, 0.5235987755982988F, "unidad_delantera"),
                new DatosModelo.Animada("futd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, -46.0F, -4.0F, 1.0471975511965976F, "unidad_delantera"),
                new DatosModelo.Animada("rurmi0_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 58.0F, -6.5F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rurmi0_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 58.0F, -6.5F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rurmi0_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 58.0F, -6.5F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rurmi1_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 72.0F, -6.5F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rurmi1_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 72.0F, -6.5F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rurmi1_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 72.0F, -6.5F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rurmi2_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 86.0F, -6.5F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rurmi2_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 86.0F, -6.5F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rurmi2_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 86.0F, -6.5F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rurmi3_0", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 100.0F, -6.5F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rurmi3_1", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 100.0F, -6.5F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rurmi3_2", DatosModelo.RUEDA, 6.5F, 0.0F, 0.0F, 0.0F, 100.0F, -6.5F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rubiela_i", DatosModelo.BIELA, 6.5F, 2.5F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rumotriz_i", DatosModelo.MOTRIZ, 6.5F, 2.5F, 0.0F, 24.0F, 86.0F, -9.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rucruceta_i", DatosModelo.CRUCETA, 6.5F, 2.5F, 0.0F, 24.0F, 0.0F, 0.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd0_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 58.0F, -6.5F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd0_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 58.0F, -6.5F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd0_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 58.0F, -6.5F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd1_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 72.0F, -6.5F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd1_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 72.0F, -6.5F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd1_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 72.0F, -6.5F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd2_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 86.0F, -6.5F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd2_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 86.0F, -6.5F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd2_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 86.0F, -6.5F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd3_0", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 100.0F, -6.5F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd3_1", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 100.0F, -6.5F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rurmd3_2", DatosModelo.RUEDA, 6.5F, 0.0F, 1.5707963267948966F, 0.0F, 100.0F, -6.5F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rubiela_d", DatosModelo.BIELA, 6.5F, 2.5F, 1.5707963267948966F, 0.0F, 0.0F, 0.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rumotriz_d", DatosModelo.MOTRIZ, 6.5F, 2.5F, 1.5707963267948966F, 24.0F, 86.0F, -9.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rucruceta_d", DatosModelo.CRUCETA, 6.5F, 2.5F, 1.5707963267948966F, 24.0F, 0.0F, 0.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rubi0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 118.0F, -4.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rubi0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 118.0F, -4.0F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rubi0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 118.0F, -4.0F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rubi1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 128.0F, -4.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rubi1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 128.0F, -4.0F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rubi1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 128.0F, -4.0F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rubd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 118.0F, -4.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rubd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 118.0F, -4.0F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rubd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 118.0F, -4.0F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rubd1_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 128.0F, -4.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rubd1_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 128.0F, -4.0F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rubd1_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 128.0F, -4.0F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("ruti0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 46.0F, -4.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("ruti0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 46.0F, -4.0F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("ruti0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 46.0F, -4.0F, 1.0471975511965976F, "unidad_trasera"),
                new DatosModelo.Animada("rutd0_0", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 46.0F, -4.0F, 0.0F, "unidad_trasera"),
                new DatosModelo.Animada("rutd0_1", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 46.0F, -4.0F, 0.5235987755982988F, "unidad_trasera"),
                new DatosModelo.Animada("rutd0_2", DatosModelo.RUEDA, 4.0F, 0.0F, 0.0F, 0.0F, 46.0F, -4.0F, 1.0471975511965976F, "unidad_trasera")),
            ModeloGarratt::crearCapa,
            16.0F,
            ModeloGarratt::preparar,
            List.of(
                new DatosModelo.Segmento("unidad_delantera", -123.0F, -46.0F),
                new DatosModelo.Segmento("caldera", -52.0F, 52.0F),
                new DatosModelo.Segmento("unidad_trasera", 46.0F, 123.0F)));

    private ModeloGarratt() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("unidad_delantera", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("caldera", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g2 = raiz.addOrReplaceChild("unidad_trasera", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g1);
        piezas3(g1);
        piezas4(g1);
        piezas5(g1);
        piezas6(g1);
        piezas7(g2);
        piezas8(g2);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("unidad_delantera");
        ModelPart g1 = raiz.getChild("caldera");
        ModelPart g2 = raiz.getChild("unidad_trasera");
        escalas0(g0, g1, g2);
        escalas1(g0, g1, g2);
        escalas2(g0, g1, g2);
        escalas3(g0, g1, g2);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("furmi0_0", CubeListBuilder.create().texOffs(990, 230).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(972, 300).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(374, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(296, 354).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-100.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("furmi0_1", CubeListBuilder.create().texOffs(0, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-100.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("furmi0_2", CubeListBuilder.create().texOffs(30, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-100.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("furmi1_0", CubeListBuilder.create().texOffs(990, 230).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(972, 300).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(384, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(302, 354).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-86.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("furmi1_1", CubeListBuilder.create().texOffs(0, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-86.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("furmi1_2", CubeListBuilder.create().texOffs(30, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-86.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("furmi2_0", CubeListBuilder.create().texOffs(990, 230).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(972, 300).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(394, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(308, 354).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-72.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("furmi2_1", CubeListBuilder.create().texOffs(0, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-72.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("furmi2_2", CubeListBuilder.create().texOffs(30, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-72.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("furmi3_0", CubeListBuilder.create().texOffs(990, 230).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(972, 300).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(404, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(314, 354).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-58.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("furmi3_1", CubeListBuilder.create().texOffs(0, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("furmi3_2", CubeListBuilder.create().texOffs(30, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fubiela_i", CubeListBuilder.create().texOffs(684, 354).addBox(-100.0F, -9.5F, -7.5F, 42.0F, 1.0F, 1.0F).texOffs(912, 334).addBox(-101.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(920, 334).addBox(-87.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(928, 334).addBox(-73.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(936, 334).addBox(-59.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fumotriz_i", CubeListBuilder.create().texOffs(86, 357).addBox(-38.0F, -0.5F, -0.5F, 38.0F, 1.0F, 1.0F).texOffs(944, 334).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(-86.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("fucruceta_i", CubeListBuilder.create().texOffs(414, 309).addBox(-125.41767397929361F, -8.0F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(566, 357).addBox(-133.91767397929362F, -7.0F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuguias_i", CubeListBuilder.create().texOffs(342, 357).addBox(-130.41767397929362F, -5.0F, -9.0F, 13.0F, 1.0F, 1.0F).texOffs(370, 357).addBox(-130.41767397929362F, -9.0F, -9.0F, 13.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fucil_i_0", CubeListBuilder.create().texOffs(890, 252).addBox(-142.41767397929362F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(186, 252).addBox(-142.41767397929362F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, -8.5F));
        g.addOrReplaceChild("fucil_i_1", CubeListBuilder.create().texOffs(918, 252).addBox(-142.41767397929362F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(230, 252).addBox(-142.41767397929362F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_i_2", CubeListBuilder.create().texOffs(946, 252).addBox(-142.41767397929362F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(274, 252).addBox(-142.41767397929362F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_i_3", CubeListBuilder.create().texOffs(974, 252).addBox(-142.41767397929362F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(318, 252).addBox(-142.41767397929362F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_i_a_0", CubeListBuilder.create().texOffs(418, 279).addBox(-142.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(720, 267).addBox(-142.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, -8.5F));
        g.addOrReplaceChild("fucil_i_a_1", CubeListBuilder.create().texOffs(424, 279).addBox(-142.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(742, 267).addBox(-142.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_i_a_2", CubeListBuilder.create().texOffs(430, 279).addBox(-142.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(764, 267).addBox(-142.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_i_a_3", CubeListBuilder.create().texOffs(436, 279).addBox(-142.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(786, 267).addBox(-142.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_i_b_0", CubeListBuilder.create().texOffs(442, 279).addBox(-130.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(808, 267).addBox(-130.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, -8.5F));
        g.addOrReplaceChild("fucil_i_b_1", CubeListBuilder.create().texOffs(448, 279).addBox(-130.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(830, 267).addBox(-130.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_i_b_2", CubeListBuilder.create().texOffs(454, 279).addBox(-130.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(852, 267).addBox(-130.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_i_b_3", CubeListBuilder.create().texOffs(460, 279).addBox(-130.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(874, 267).addBox(-130.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("furmd0_0", CubeListBuilder.create().texOffs(990, 230).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(972, 300).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(424, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(320, 354).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-100.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("furmd0_1", CubeListBuilder.create().texOffs(0, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-100.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("furmd0_2", CubeListBuilder.create().texOffs(30, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-100.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("furmd1_0", CubeListBuilder.create().texOffs(990, 230).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(972, 300).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(434, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(326, 354).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-86.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("furmd1_1", CubeListBuilder.create().texOffs(0, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-86.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("furmd1_2", CubeListBuilder.create().texOffs(30, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-86.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("furmd2_0", CubeListBuilder.create().texOffs(990, 230).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(972, 300).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(444, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(332, 354).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-72.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("furmd2_1", CubeListBuilder.create().texOffs(0, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-72.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("furmd2_2", CubeListBuilder.create().texOffs(30, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-72.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("furmd3_0", CubeListBuilder.create().texOffs(990, 230).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(972, 300).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(30, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(454, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(338, 354).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(-58.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("furmd3_1", CubeListBuilder.create().texOffs(0, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(40, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("furmd3_2", CubeListBuilder.create().texOffs(30, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(50, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-58.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fubiela_d", CubeListBuilder.create().texOffs(770, 354).addBox(-100.0F, -9.5F, 6.5F, 42.0F, 1.0F, 1.0F).texOffs(952, 334).addBox(-101.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(960, 334).addBox(-87.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(968, 334).addBox(-73.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(976, 334).addBox(-59.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fumotriz_d", CubeListBuilder.create().texOffs(164, 357).addBox(-38.0F, -0.5F, -0.5F, 38.0F, 1.0F, 1.0F).texOffs(984, 334).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(-86.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("fucruceta_d", CubeListBuilder.create().texOffs(464, 309).addBox(-125.41767397929361F, -8.0F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(588, 357).addBox(-133.91767397929362F, -7.0F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fuguias_d", CubeListBuilder.create().texOffs(398, 357).addBox(-130.41767397929362F, -5.0F, 8.0F, 13.0F, 1.0F, 1.0F).texOffs(426, 357).addBox(-130.41767397929362F, -9.0F, 8.0F, 13.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("fucil_d_0", CubeListBuilder.create().texOffs(0, 267).addBox(-142.41767397929362F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(362, 252).addBox(-142.41767397929362F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, 8.5F));
        g.addOrReplaceChild("fucil_d_1", CubeListBuilder.create().texOffs(28, 267).addBox(-142.41767397929362F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(406, 252).addBox(-142.41767397929362F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_d_2", CubeListBuilder.create().texOffs(56, 267).addBox(-142.41767397929362F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(450, 252).addBox(-142.41767397929362F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_d_3", CubeListBuilder.create().texOffs(84, 267).addBox(-142.41767397929362F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(494, 252).addBox(-142.41767397929362F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_d_a_0", CubeListBuilder.create().texOffs(466, 279).addBox(-142.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(896, 267).addBox(-142.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, 8.5F));
        g.addOrReplaceChild("fucil_d_a_1", CubeListBuilder.create().texOffs(472, 279).addBox(-142.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(918, 267).addBox(-142.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_d_a_2", CubeListBuilder.create().texOffs(478, 279).addBox(-142.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(940, 267).addBox(-142.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_d_a_3", CubeListBuilder.create().texOffs(484, 279).addBox(-142.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(962, 267).addBox(-142.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_d_b_0", CubeListBuilder.create().texOffs(490, 279).addBox(-130.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(984, 267).addBox(-130.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, 8.5F));
        g.addOrReplaceChild("fucil_d_b_1", CubeListBuilder.create().texOffs(496, 279).addBox(-130.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(0, 279).addBox(-130.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_d_b_2", CubeListBuilder.create().texOffs(502, 279).addBox(-130.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(22, 279).addBox(-130.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("fucil_d_b_3", CubeListBuilder.create().texOffs(508, 279).addBox(-130.91767397929362F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(44, 279).addBox(-130.91767397929362F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("fubi0_0", CubeListBuilder.create().texOffs(706, 279).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(120, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(786, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(474, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-128.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("fubi0_1", CubeListBuilder.create().texOffs(140, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-128.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fubi0_2", CubeListBuilder.create().texOffs(160, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-128.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fubi1_0", CubeListBuilder.create().texOffs(706, 279).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(120, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(786, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(484, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-118.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("fubi1_1", CubeListBuilder.create().texOffs(140, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-118.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fubi1_2", CubeListBuilder.create().texOffs(160, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-118.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fubd0_0", CubeListBuilder.create().texOffs(706, 279).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(120, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(786, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(494, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-128.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("fubd0_1", CubeListBuilder.create().texOffs(140, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-128.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fubd0_2", CubeListBuilder.create().texOffs(160, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-128.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fubd1_0", CubeListBuilder.create().texOffs(706, 279).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(120, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(786, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(504, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-118.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("fubd1_1", CubeListBuilder.create().texOffs(140, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(794, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-118.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("fubd1_2", CubeListBuilder.create().texOffs(160, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(802, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-118.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("futi0_0", CubeListBuilder.create().texOffs(726, 279).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(180, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(514, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("futi0_1", CubeListBuilder.create().texOffs(200, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(818, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("futi0_2", CubeListBuilder.create().texOffs(220, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(826, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("futd0_0", CubeListBuilder.create().texOffs(726, 279).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(180, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(810, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(524, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(-46.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("futd0_1", CubeListBuilder.create().texOffs(200, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(818, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("futd0_2", CubeListBuilder.create().texOffs(220, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(826, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-46.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("fu_bastidor", CubeListBuilder.create().texOffs(0, 291).addBox(-140.0F, -12.0F, 2.0F, 100.0F, 8.0F, 1.0F).texOffs(202, 291).addBox(-140.0F, -12.0F, -3.0F, 100.0F, 8.0F, 1.0F).texOffs(132, 202).addBox(-140.0F, -12.0F, -12.0F, 100.0F, 1.0F, 24.0F).texOffs(606, 142).addBox(-143.0F, -12.0F, -12.0F, 3.0F, 6.0F, 24.0F).texOffs(402, 300).addBox(-146.0F, -11.0F, -2.0F, 3.0F, 4.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("fu_tanque", CubeListBuilder.create().texOffs(102, 142).addBox(-138.0F, -27.0F, -12.5F, 88.0F, 15.0F, 25.0F).texOffs(282, 230).addBox(-138.0F, -32.0F, -7.5F, 88.0F, 5.0F, 15.0F), PartPose.ZERO);
        g.addOrReplaceChild("fu_tanque_cantoi_0", CubeListBuilder.create().texOffs(48, 338).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-94.0F, -27.772542485937365F, -12.377641290737884F, -1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("fu_tanque_cantoi_1", CubeListBuilder.create().texOffs(228, 338).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-94.0F, -29.24200561666855F, -11.900183776675252F, -2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("fu_tanque_cantoi_2", CubeListBuilder.create().texOffs(408, 338).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-94.0F, -30.49200561666855F, -10.99200561666855F, -2.3561944901923457F, 0.0F, 0.0F));
        g.addOrReplaceChild("fu_tanque_cantoi_3", CubeListBuilder.create().texOffs(588, 338).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-94.0F, -31.400183776675252F, -9.74200561666855F, -2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("fu_tanque_cantoi_4", CubeListBuilder.create().texOffs(768, 338).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-94.0F, -31.877641290737884F, -8.272542485937368F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("fu_tanque_cantod_0", CubeListBuilder.create().texOffs(0, 342).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-94.0F, -27.772542485937365F, 12.377641290737884F, 1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("fu_tanque_cantod_1", CubeListBuilder.create().texOffs(180, 342).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-94.0F, -29.24200561666855F, 11.900183776675252F, 2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("fu_tanque_cantod_2", CubeListBuilder.create().texOffs(360, 342).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-94.0F, -30.49200561666855F, 10.99200561666855F, 2.3561944901923457F, 0.0F, 0.0F));
        g.addOrReplaceChild("fu_tanque_cantod_3", CubeListBuilder.create().texOffs(540, 342).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-94.0F, -31.400183776675252F, 9.74200561666855F, 2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("fu_tanque_cantod_4", CubeListBuilder.create().texOffs(720, 342).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-94.0F, -31.877641290737884F, 8.272542485937368F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("fu_tanque_tapaa", CubeListBuilder.create().texOffs(710, 73).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 50.0F), PartPose.offset(-138.0F, -27.0F, -12.5F));
        g.addOrReplaceChild("fu_tanque_tapab", CubeListBuilder.create().texOffs(812, 73).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 50.0F), PartPose.offset(-51.0F, -27.0F, -12.5F));
        g.addOrReplaceChild("fu_faro_0", CubeListBuilder.create().texOffs(760, 330).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(336, 267).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-138.2F, -27.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_faro_1", CubeListBuilder.create().texOffs(784, 330).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(360, 267).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-138.2F, -27.0F, 0.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("fu_faro_2", CubeListBuilder.create().texOffs(808, 330).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(384, 267).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-138.2F, -27.0F, 0.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_faro_3", CubeListBuilder.create().texOffs(832, 330).addBox(-5.0F, -0.6666666666666667F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(408, 267).addBox(-1.0F, -0.6666666666666667F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-138.2F, -27.0F, 0.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_faro_vidrio", CubeListBuilder.create().texOffs(694, 230).addBox(-9.0F, 0.0F, -9.0F, 18.0F, 1.0F, 18.0F), PartPose.offsetAndRotation(-139.42F, -27.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_farol3_0", CubeListBuilder.create().texOffs(856, 330).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(432, 267).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-143.2F, -13.5F, -7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_farol3_1", CubeListBuilder.create().texOffs(880, 330).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(456, 267).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-143.2F, -13.5F, -7.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_farol3_2", CubeListBuilder.create().texOffs(904, 330).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(480, 267).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-143.2F, -13.5F, -7.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_farol3_3", CubeListBuilder.create().texOffs(928, 330).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(504, 267).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-143.2F, -13.5F, -7.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_farol3_vidrio", CubeListBuilder.create().texOffs(198, 300).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-143.82F, -13.5F, -7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_farol17_0", CubeListBuilder.create().texOffs(952, 330).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(528, 267).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-143.2F, -13.5F, 7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_farol17_1", CubeListBuilder.create().texOffs(976, 330).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(552, 267).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-143.2F, -13.5F, 7.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_farol17_2", CubeListBuilder.create().texOffs(1000, 330).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(576, 267).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-143.2F, -13.5F, 7.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_farol17_3", CubeListBuilder.create().texOffs(0, 334).addBox(-5.0F, -1.0F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(600, 267).addBox(-1.0F, -1.0F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-143.2F, -13.5F, 7.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_farol17_vidrio", CubeListBuilder.create().texOffs(230, 300).addBox(-4.0F, 0.0F, -4.0F, 8.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-143.82F, -13.5F, 7.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("fu_boca_0", CubeListBuilder.create().texOffs(808, 291).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(714, 142).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offset(-120.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("fu_boca_1", CubeListBuilder.create().texOffs(874, 291).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(780, 142).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(-120.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("fu_boca_2", CubeListBuilder.create().texOffs(940, 291).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(846, 142).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(-120.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("cuna", CubeListBuilder.create().texOffs(440, 300).addBox(-54.0F, -14.0F, 9.5F, 108.0F, 5.0F, 1.0F).texOffs(658, 300).addBox(-54.0F, -14.0F, -10.5F, 108.0F, 5.0F, 1.0F).texOffs(0, 230).addBox(-54.0F, -14.0F, -10.5F, 108.0F, 1.0F, 21.0F), PartPose.ZERO);
        g.addOrReplaceChild("caja_humo_0", CubeListBuilder.create().texOffs(444, 73).addBox(-48.0F, -31.0F, -3.5F, 12.0F, 62.0F, 7.0F).texOffs(288, 0).addBox(-48.0F, -3.5F, -31.0F, 12.0F, 7.0F, 62.0F), PartPose.offset(0.0F, -27.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_1", CubeListBuilder.create().texOffs(482, 73).addBox(-48.0F, -31.0F, -3.5F, 12.0F, 62.0F, 7.0F).texOffs(436, 0).addBox(-48.0F, -3.5F, -31.0F, 12.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -27.0F, 0.0F, 0.2243994752564138F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_2", CubeListBuilder.create().texOffs(520, 73).addBox(-48.0F, -31.0F, -3.5F, 12.0F, 62.0F, 7.0F).texOffs(584, 0).addBox(-48.0F, -3.5F, -31.0F, 12.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -27.0F, 0.0F, 0.4487989505128276F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_3", CubeListBuilder.create().texOffs(558, 73).addBox(-48.0F, -31.0F, -3.5F, 12.0F, 62.0F, 7.0F).texOffs(732, 0).addBox(-48.0F, -3.5F, -31.0F, 12.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -27.0F, 0.0F, 0.6731984257692414F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_4", CubeListBuilder.create().texOffs(596, 73).addBox(-48.0F, -31.0F, -3.5F, 12.0F, 62.0F, 7.0F).texOffs(0, 73).addBox(-48.0F, -3.5F, -31.0F, 12.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -27.0F, 0.0F, 0.8975979010256552F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_5", CubeListBuilder.create().texOffs(634, 73).addBox(-48.0F, -31.0F, -3.5F, 12.0F, 62.0F, 7.0F).texOffs(148, 73).addBox(-48.0F, -3.5F, -31.0F, 12.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -27.0F, 0.0F, 1.121997376282069F, 0.0F, 0.0F));
        g.addOrReplaceChild("caja_humo_6", CubeListBuilder.create().texOffs(672, 73).addBox(-48.0F, -31.0F, -3.5F, 12.0F, 62.0F, 7.0F).texOffs(296, 73).addBox(-48.0F, -3.5F, -31.0F, 12.0F, 7.0F, 62.0F), PartPose.offsetAndRotation(0.0F, -27.0F, 0.0F, 1.3463968515384828F, 0.0F, 0.0F));
        g.addOrReplaceChild("puerta", CubeListBuilder.create().texOffs(0, 0).addBox(-36.0F, 0.0F, -36.0F, 72.0F, 1.0F, 72.0F), PartPose.offsetAndRotation(-48.1F, -27.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("caldera_0", CubeListBuilder.create().texOffs(288, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -36.87463956090912F, 1.112604669781572F, 3.029392915961585F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_1", CubeListBuilder.create().texOffs(328, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -36.87463956090912F, 1.112604669781572F, 3.029392915961585F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_2", CubeListBuilder.create().texOffs(368, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -36.87463956090912F, 1.112604669781572F, 3.029392915961585F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_3", CubeListBuilder.create().texOffs(408, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -36.87463956090912F, 1.112604669781572F, 3.029392915961585F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_4", CubeListBuilder.create().texOffs(448, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -36.379483900421214F, 3.282023365369363F, 2.804993440705175F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_5", CubeListBuilder.create().texOffs(488, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -36.379483900421214F, 3.282023365369363F, 2.804993440705175F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_6", CubeListBuilder.create().texOffs(528, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -36.379483900421214F, 3.282023365369363F, 2.804993440705175F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_7", CubeListBuilder.create().texOffs(568, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -36.379483900421214F, 3.282023365369363F, 2.804993440705175F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_8", CubeListBuilder.create().texOffs(608, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -35.41400175185225F, 5.286867704881458F, 2.580593965448758F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_9", CubeListBuilder.create().texOffs(648, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -35.41400175185225F, 5.286867704881458F, 2.580593965448758F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_10", CubeListBuilder.create().texOffs(688, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -35.41400175185225F, 5.286867704881458F, 2.580593965448758F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_11", CubeListBuilder.create().texOffs(728, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -35.41400175185225F, 5.286867704881458F, 2.580593965448758F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_12", CubeListBuilder.create().texOffs(768, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -34.026606421633815F, 7.026606421633817F, 2.3561944901923453F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_13", CubeListBuilder.create().texOffs(808, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -34.026606421633815F, 7.026606421633817F, 2.3561944901923453F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_14", CubeListBuilder.create().texOffs(848, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -34.026606421633815F, 7.026606421633817F, 2.3561944901923453F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_15", CubeListBuilder.create().texOffs(888, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -34.026606421633815F, 7.026606421633817F, 2.3561944901923453F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_16", CubeListBuilder.create().texOffs(928, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -32.28686770488146F, 8.414001751852243F, 2.131795014935931F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_17", CubeListBuilder.create().texOffs(968, 314).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -32.28686770488146F, 8.414001751852243F, 2.131795014935931F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_18", CubeListBuilder.create().texOffs(0, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -32.28686770488146F, 8.414001751852243F, 2.131795014935931F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_19", CubeListBuilder.create().texOffs(40, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -32.28686770488146F, 8.414001751852243F, 2.131795014935931F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_20", CubeListBuilder.create().texOffs(80, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -30.282023365369362F, 9.379483900421214F, 1.9073955396795175F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_21", CubeListBuilder.create().texOffs(120, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -30.282023365369362F, 9.379483900421214F, 1.9073955396795175F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_22", CubeListBuilder.create().texOffs(160, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -30.282023365369362F, 9.379483900421214F, 1.9073955396795175F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_23", CubeListBuilder.create().texOffs(200, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -30.282023365369362F, 9.379483900421214F, 1.9073955396795175F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_24", CubeListBuilder.create().texOffs(240, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -28.11260466978157F, 9.874639560909118F, 1.6829960644231032F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_25", CubeListBuilder.create().texOffs(280, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -28.11260466978157F, 9.874639560909118F, 1.6829960644231032F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_26", CubeListBuilder.create().texOffs(320, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -28.11260466978157F, 9.874639560909118F, 1.6829960644231032F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_27", CubeListBuilder.create().texOffs(360, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -28.11260466978157F, 9.874639560909118F, 1.6829960644231032F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_28", CubeListBuilder.create().texOffs(400, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -25.887395330218425F, 9.874639560909118F, 1.45859658916669F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_29", CubeListBuilder.create().texOffs(440, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -25.887395330218425F, 9.874639560909118F, 1.45859658916669F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_30", CubeListBuilder.create().texOffs(480, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -25.887395330218425F, 9.874639560909118F, 1.45859658916669F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_31", CubeListBuilder.create().texOffs(520, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -25.887395330218425F, 9.874639560909118F, 1.45859658916669F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_32", CubeListBuilder.create().texOffs(560, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -23.717976634630638F, 9.379483900421214F, 1.2341971139102759F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_33", CubeListBuilder.create().texOffs(600, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -23.717976634630638F, 9.379483900421214F, 1.2341971139102759F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_34", CubeListBuilder.create().texOffs(640, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -23.717976634630638F, 9.379483900421214F, 1.2341971139102759F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_35", CubeListBuilder.create().texOffs(680, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -23.717976634630638F, 9.379483900421214F, 1.2341971139102759F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_36", CubeListBuilder.create().texOffs(720, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -21.713132295118545F, 8.414001751852247F, 1.009797638653862F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_37", CubeListBuilder.create().texOffs(760, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -21.713132295118545F, 8.414001751852247F, 1.009797638653862F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_38", CubeListBuilder.create().texOffs(800, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -21.713132295118545F, 8.414001751852247F, 1.009797638653862F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_39", CubeListBuilder.create().texOffs(840, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -21.713132295118545F, 8.414001751852247F, 1.009797638653862F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_40", CubeListBuilder.create().texOffs(880, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -19.973393578366185F, 7.026606421633819F, 0.7853981633974495F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_41", CubeListBuilder.create().texOffs(920, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -19.973393578366185F, 7.026606421633819F, 0.7853981633974495F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_42", CubeListBuilder.create().texOffs(960, 318).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -19.973393578366185F, 7.026606421633819F, 0.7853981633974495F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_43", CubeListBuilder.create().texOffs(0, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -19.973393578366185F, 7.026606421633819F, 0.7853981633974495F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_44", CubeListBuilder.create().texOffs(40, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -18.585998248147753F, 5.286867704881459F, 0.5609986881410337F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_45", CubeListBuilder.create().texOffs(80, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -18.585998248147753F, 5.286867704881459F, 0.5609986881410337F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_46", CubeListBuilder.create().texOffs(120, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -18.585998248147753F, 5.286867704881459F, 0.5609986881410337F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_47", CubeListBuilder.create().texOffs(160, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -18.585998248147753F, 5.286867704881459F, 0.5609986881410337F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_48", CubeListBuilder.create().texOffs(200, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -17.620516099578786F, 3.2820233653693665F, 0.3365992128846206F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_49", CubeListBuilder.create().texOffs(240, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -17.620516099578786F, 3.2820233653693665F, 0.3365992128846206F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_50", CubeListBuilder.create().texOffs(280, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -17.620516099578786F, 3.2820233653693665F, 0.3365992128846206F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_51", CubeListBuilder.create().texOffs(320, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -17.620516099578786F, 3.2820233653693665F, 0.3365992128846206F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_52", CubeListBuilder.create().texOffs(360, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -17.125360439090883F, 1.1126046697815755F, 0.11219973762820791F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_53", CubeListBuilder.create().texOffs(400, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -17.125360439090883F, 1.1126046697815755F, 0.11219973762820791F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_54", CubeListBuilder.create().texOffs(440, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -17.125360439090883F, 1.1126046697815755F, 0.11219973762820791F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_55", CubeListBuilder.create().texOffs(480, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -17.125360439090883F, 1.1126046697815755F, 0.11219973762820791F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_56", CubeListBuilder.create().texOffs(520, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -17.125360439090883F, -1.1126046697815708F, -0.11219973762820654F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_57", CubeListBuilder.create().texOffs(560, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -17.125360439090883F, -1.1126046697815708F, -0.11219973762820654F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_58", CubeListBuilder.create().texOffs(600, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -17.125360439090883F, -1.1126046697815708F, -0.11219973762820654F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_59", CubeListBuilder.create().texOffs(640, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -17.125360439090883F, -1.1126046697815708F, -0.11219973762820654F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_60", CubeListBuilder.create().texOffs(680, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -17.620516099578786F, -3.282023365369361F, -0.33659921288461997F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_61", CubeListBuilder.create().texOffs(720, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -17.620516099578786F, -3.282023365369361F, -0.33659921288461997F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_62", CubeListBuilder.create().texOffs(760, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -17.620516099578786F, -3.282023365369361F, -0.33659921288461997F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_63", CubeListBuilder.create().texOffs(800, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -17.620516099578786F, -3.282023365369361F, -0.33659921288461997F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_64", CubeListBuilder.create().texOffs(840, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -18.585998248147753F, -5.286867704881455F, -0.5609986881410357F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_65", CubeListBuilder.create().texOffs(880, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -18.585998248147753F, -5.286867704881455F, -0.5609986881410357F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_66", CubeListBuilder.create().texOffs(920, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -18.585998248147753F, -5.286867704881455F, -0.5609986881410357F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_67", CubeListBuilder.create().texOffs(960, 322).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -18.585998248147753F, -5.286867704881455F, -0.5609986881410357F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_68", CubeListBuilder.create().texOffs(0, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -19.97339357836618F, -7.026606421633813F, -0.7853981633974472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_69", CubeListBuilder.create().texOffs(40, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -19.97339357836618F, -7.026606421633813F, -0.7853981633974472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_70", CubeListBuilder.create().texOffs(80, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -19.97339357836618F, -7.026606421633813F, -0.7853981633974472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_71", CubeListBuilder.create().texOffs(120, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -19.97339357836618F, -7.026606421633813F, -0.7853981633974472F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_72", CubeListBuilder.create().texOffs(160, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -21.713132295118534F, -8.414001751852242F, -1.0097976386538612F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_73", CubeListBuilder.create().texOffs(200, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -21.713132295118534F, -8.414001751852242F, -1.0097976386538612F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_74", CubeListBuilder.create().texOffs(240, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -21.713132295118534F, -8.414001751852242F, -1.0097976386538612F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_75", CubeListBuilder.create().texOffs(280, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -21.713132295118534F, -8.414001751852242F, -1.0097976386538612F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_76", CubeListBuilder.create().texOffs(320, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -23.717976634630627F, -9.37948390042121F, -1.2341971139102752F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_77", CubeListBuilder.create().texOffs(360, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -23.717976634630627F, -9.37948390042121F, -1.2341971139102752F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_78", CubeListBuilder.create().texOffs(400, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -23.717976634630627F, -9.37948390042121F, -1.2341971139102752F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_79", CubeListBuilder.create().texOffs(440, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -23.717976634630627F, -9.37948390042121F, -1.2341971139102752F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_80", CubeListBuilder.create().texOffs(480, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -25.88739533021842F, -9.874639560909117F, -1.4585965891666888F, 0.0F, 0.0F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("caldera_81", CubeListBuilder.create().texOffs(520, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -25.88739533021842F, -9.874639560909117F, -1.4585965891666888F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_82", CubeListBuilder.create().texOffs(560, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -25.88739533021842F, -9.874639560909117F, -1.4585965891666888F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_83", CubeListBuilder.create().texOffs(600, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -25.88739533021842F, -9.874639560909117F, -1.4585965891666888F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_84", CubeListBuilder.create().texOffs(640, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -28.112604669781568F, -9.874639560909118F, -1.682996064423103F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_85", CubeListBuilder.create().texOffs(680, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -28.112604669781568F, -9.874639560909118F, -1.682996064423103F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_86", CubeListBuilder.create().texOffs(720, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -28.112604669781568F, -9.874639560909118F, -1.682996064423103F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_87", CubeListBuilder.create().texOffs(760, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -28.112604669781568F, -9.874639560909118F, -1.682996064423103F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_88", CubeListBuilder.create().texOffs(800, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -30.282023365369362F, -9.379483900421214F, -1.9073955396795172F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_89", CubeListBuilder.create().texOffs(840, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -30.282023365369362F, -9.379483900421214F, -1.9073955396795172F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_90", CubeListBuilder.create().texOffs(880, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -30.282023365369362F, -9.379483900421214F, -1.9073955396795172F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_91", CubeListBuilder.create().texOffs(920, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -30.282023365369362F, -9.379483900421214F, -1.9073955396795172F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_92", CubeListBuilder.create().texOffs(960, 326).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -32.28686770488146F, -8.414001751852245F, -2.131795014935932F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_93", CubeListBuilder.create().texOffs(0, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -32.28686770488146F, -8.414001751852245F, -2.131795014935932F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_94", CubeListBuilder.create().texOffs(40, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -32.28686770488146F, -8.414001751852245F, -2.131795014935932F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_95", CubeListBuilder.create().texOffs(80, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -32.28686770488146F, -8.414001751852245F, -2.131795014935932F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_96", CubeListBuilder.create().texOffs(120, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -34.026606421633815F, -7.026606421633819F, -2.3561944901923426F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_97", CubeListBuilder.create().texOffs(160, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -34.026606421633815F, -7.026606421633819F, -2.3561944901923426F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_98", CubeListBuilder.create().texOffs(200, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -34.026606421633815F, -7.026606421633819F, -2.3561944901923426F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_99", CubeListBuilder.create().texOffs(240, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -34.026606421633815F, -7.026606421633819F, -2.3561944901923426F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_100", CubeListBuilder.create().texOffs(280, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -35.41400175185224F, -5.286867704881464F, -2.580593965448759F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_101", CubeListBuilder.create().texOffs(320, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -35.41400175185224F, -5.286867704881464F, -2.580593965448759F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_102", CubeListBuilder.create().texOffs(360, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -35.41400175185224F, -5.286867704881464F, -2.580593965448759F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_103", CubeListBuilder.create().texOffs(400, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -35.41400175185224F, -5.286867704881464F, -2.580593965448759F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_104", CubeListBuilder.create().texOffs(440, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -36.37948390042121F, -3.2820233653693727F, -2.8049934407051715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_105", CubeListBuilder.create().texOffs(480, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -36.37948390042121F, -3.2820233653693727F, -2.8049934407051715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_106", CubeListBuilder.create().texOffs(520, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -36.37948390042121F, -3.2820233653693727F, -2.8049934407051715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_107", CubeListBuilder.create().texOffs(560, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -36.37948390042121F, -3.2820233653693727F, -2.8049934407051715F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_108", CubeListBuilder.create().texOffs(600, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-27.75F, -36.87463956090912F, -1.1126046697815788F, -3.0293929159615853F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_109", CubeListBuilder.create().texOffs(640, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-11.25F, -36.87463956090912F, -1.1126046697815788F, -3.0293929159615853F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_110", CubeListBuilder.create().texOffs(680, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(5.25F, -36.87463956090912F, -1.1126046697815788F, -3.0293929159615853F, 0.0F, 0.0F));
        g.addOrReplaceChild("caldera_111", CubeListBuilder.create().texOffs(720, 330).addBox(-8.5F, -1.0F, -1.5F, 17.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(21.75F, -36.87463956090912F, -1.1126046697815788F, -3.0293929159615853F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_0", CubeListBuilder.create().texOffs(876, 300).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(90, 252).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offset(-42.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_1", CubeListBuilder.create().texOffs(900, 300).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(114, 252).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-42.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_2", CubeListBuilder.create().texOffs(924, 300).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(138, 252).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-42.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_3", CubeListBuilder.create().texOffs(948, 300).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 4.0F, 2.0F).texOffs(162, 252).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 4.0F, 10.0F), PartPose.offsetAndRotation(-42.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("chimenea_labio_0", CubeListBuilder.create().texOffs(900, 348).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(610, 279).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offset(-42.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("chimenea_labio_1", CubeListBuilder.create().texOffs(924, 348).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(634, 279).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-42.0F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F, 0.0F));
        g.addOrReplaceChild("chimenea_labio_2", CubeListBuilder.create().texOffs(948, 348).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(658, 279).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-42.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("chimenea_labio_3", CubeListBuilder.create().texOffs(972, 348).addBox(-5.0F, -40.0F, -1.0F, 10.0F, 1.0F, 2.0F).texOffs(682, 279).addBox(-1.0F, -40.0F, -5.0F, 2.0F, 1.0F, 10.0F), PartPose.offsetAndRotation(-42.0F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F, 0.0F));
        g.addOrReplaceChild("domo_arena_0", CubeListBuilder.create().texOffs(472, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.614752861305579F, -35.67830806393077F, 0.6701232371976483F, 0.07891475032283476F, 0.010386778017985534F, -1.6604609033111029F));
        g.addOrReplaceChild("domo_arena_1", CubeListBuilder.create().texOffs(484, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.85639320475216F, -36.82700641892781F, 0.6331974257059422F, 0.0739253265164006F, 0.041702843342707206F, -1.9387796090360503F));
        g.addOrReplaceChild("domo_arena_2", CubeListBuilder.create().texOffs(712, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.333873260875087F, -37.66441492150743F, 0.5602322151290824F, 0.06154168533106228F, 0.07290447886926758F, -2.251970589728536F));
        g.addOrReplaceChild("domo_arena_3", CubeListBuilder.create().texOffs(840, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.03846634744119F, -38.298319024476406F, 0.45256115688689325F, 0.04327797316167554F, 0.09682410651452715F, -2.5635826151726557F));
        g.addOrReplaceChild("domo_arena_4", CubeListBuilder.create().texOffs(120, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.969257359497725F, -38.72789543167236F, 0.3103240910098027F, 0.023470756210375483F, 0.11029877611100514F, -2.8407460319425635F));
        g.addOrReplaceChild("domo_arena_5", CubeListBuilder.create().texOffs(654, 357).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.24605130307666F, -38.94529297370636F, 0.11521324237466748F, 0.005743150072623238F, 0.151248427368369F, -3.0691589231335668F));
        g.addOrReplaceChild("domo_arena_6", CubeListBuilder.create().texOffs(130, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.827322772778532F, -35.67830806393077F, 1.7326412942324207F, 0.3843041050397767F, 0.03494474116657898F, -1.6560252880461153F));
        g.addOrReplaceChild("domo_arena_7", CubeListBuilder.create().texOffs(140, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.057249872982446F, -36.82700641892781F, 1.6371675331953863F, 0.36111088773480426F, 0.1403492023242689F, -1.9219858385652713F));
        g.addOrReplaceChild("domo_arena_8", CubeListBuilder.create().texOffs(848, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.511584621657462F, -37.66441492150743F, 1.4485118802195083F, 0.30269592171403503F, 0.24555443094611407F, -2.227166168434589F));
        g.addOrReplaceChild("domo_arena_9", CubeListBuilder.create().texOffs(856, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.182023352653903F, -38.298319024476406F, 1.170122307453361F, 0.21459820238426033F, 0.3264627627914406F, -2.540013644032253F));
        g.addOrReplaceChild("domo_arena_10", CubeListBuilder.create().texOffs(734, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.067695319699997F, -38.72789543167236F, 0.8023603791553625F, 0.11722620386214422F, 0.3759014550024245F, -2.8255388741708334F));
        g.addOrReplaceChild("domo_arena_11", CubeListBuilder.create().texOffs(150, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.25217216636162F, -35.67830806393077F, 2.416761738347055F, 0.7360504728333924F, 0.0547675074995653F, -1.6422323659880302F));
        g.addOrReplaceChild("domo_arena_12", CubeListBuilder.create().texOffs(160, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.45868878361404F, -36.82700641892781F, 2.283590877500977F, 0.6993803657812054F, 0.2216449598758065F, -1.8685208725966451F));
        g.addOrReplaceChild("domo_arena_13", CubeListBuilder.create().texOffs(864, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.86676454029249F, -37.66441492150743F, 2.0204459522630236F, 0.6021059715794945F, 0.39468650644016173F, -2.143686677575464F));
        g.addOrReplaceChild("domo_arena_14", CubeListBuilder.create().texOffs(872, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.46894122445716F, -38.298319024476406F, 1.6321363407723966F, 0.44202329956271175F, 0.5363385921680208F, -2.454853464197945F));
        g.addOrReplaceChild("domo_arena_15", CubeListBuilder.create().texOffs(742, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.264436746591972F, -38.72789543167236F, 1.1191663682282056F, 0.23534767534756446F, 0.5447698791026188F, -2.7924249282852793F));
        g.addOrReplaceChild("domo_arena_16", CubeListBuilder.create().texOffs(170, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.8927349078395F, -35.67830806393077F, 2.914977203940961F, 1.0652894035663254F, 0.06589541459899842F, -1.6224833649624983F));
        g.addOrReplaceChild("domo_arena_17", CubeListBuilder.create().texOffs(180, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.06395458607017F, -36.82700641892781F, 2.754353168300189F, 1.0284657917767623F, 0.2699703917383336F, -1.78897618251745F));
        g.addOrReplaceChild("domo_arena_18", CubeListBuilder.create().texOffs(880, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.402283775661825F, -37.66441492150743F, 2.4369609131058416F, 0.9237570186598557F, 0.4956105679558826F, -2.006439009803173F));
        g.addOrReplaceChild("domo_arena_19", CubeListBuilder.create().texOffs(888, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.901538990435487F, -38.298319024476406F, 1.9686012698666526F, 0.7256496239082483F, 0.70319665392017F, -2.291727976339259F));
        g.addOrReplaceChild("domo_arena_20", CubeListBuilder.create().texOffs(750, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.56107181227802F, -38.72789543167236F, 1.3498825304284636F, 0.37743993167236295F, 0.70966353414391F, -2.727804955264202F));
        g.addOrReplaceChild("domo_arena_21", CubeListBuilder.create().texOffs(496, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.77231833598689F, -35.67830806393077F, 3.2454156211722527F, 1.3282486116066174F, 0.06958527778300325F, -1.6025348451446173F));
        g.addOrReplaceChild("domo_arena_22", CubeListBuilder.create().texOffs(896, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.895070314463076F, -36.82700641892781F, 3.0665834321247636F, 1.301169344525453F, 0.2881105756091945F, -1.7059331573517644F));
        g.addOrReplaceChild("domo_arena_23", CubeListBuilder.create().texOffs(904, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.137627582574915F, -37.66441492150743F, 2.713211960933084F, 1.2198925567786403F, 0.5440706032116122F, -1.8483585192422087F));
        g.addOrReplaceChild("domo_arena_24", CubeListBuilder.create().texOffs(912, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.49555703327425F, -38.298319024476406F, 2.1917596146025184F, 1.0447498394052435F, 0.809235472219285F, -2.0631483305572647F));
        g.addOrReplaceChild("domo_arena_25", CubeListBuilder.create().texOffs(758, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.96839379822882F, -38.72789543167236F, 1.502903640233337F, 0.5681017178086744F, 0.8930483605148094F, -2.5920081053564976F));
        g.addOrReplaceChild("domo_arena_26", CubeListBuilder.create().texOffs(214, 309).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.13841298073595F, -35.67830806393077F, 3.4107477745401047F, 1.5221840134315983F, 0.0699483012824305F, -1.5812930533174652F));
        g.addOrReplaceChild("domo_arena_27", CubeListBuilder.create().texOffs(326, 309).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.185889024082975F, -36.82700641892781F, 3.222805285192764F, 1.5118795575762647F, 0.2916084952791898F, -1.6157565345324838F));
        g.addOrReplaceChild("domo_arena_28", CubeListBuilder.create().texOffs(722, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.279701437682874F, -37.66441492150743F, 2.8514319082082658F, 1.4799178377129285F, 0.5614275801533937F, -1.6649763942878189F));
        g.addOrReplaceChild("domo_arena_29", CubeListBuilder.create().texOffs(732, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.41813565542443F, -38.298319024476406F, 2.3034150631012964F, 1.4049172037533708F, 0.8661819873759653F, -1.7472103115668602F));
        g.addOrReplaceChild("domo_arena_30", CubeListBuilder.create().texOffs(920, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.601011882982796F, -38.72789543167236F, 1.5794664981684354F, 1.2213841821541722F, 1.1688863356250212F, -1.9287888522781986F));
        g.addOrReplaceChild("domo_arena_31", CubeListBuilder.create().texOffs(766, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.85186868837372F, -38.94529297370636F, 0.5864045420514867F, 0.36075812310102723F, 1.3077500595524136F, -2.787815913415452F));
        g.addOrReplaceChild("domo_arena_32", CubeListBuilder.create().texOffs(228, 309).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-20.861587019244183F, -35.67830806393077F, 3.4107477745401047F, 1.6194086401570753F, 0.0699483012824152F, -1.56029960027257F));
        g.addOrReplaceChild("domo_arena_33", CubeListBuilder.create().texOffs(338, 309).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-20.814110975898252F, -36.82700641892781F, 3.2228052851927647F, 1.6297130960121688F, 0.2916084952791406F, -1.5258361190583465F));
        g.addOrReplaceChild("domo_arena_34", CubeListBuilder.create().texOffs(742, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.720298562300517F, -37.66441492150743F, 2.8514319082082658F, 1.6616748158747725F, 0.561427580153384F, -1.4766162593041314F));
        g.addOrReplaceChild("domo_arena_35", CubeListBuilder.create().texOffs(752, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.581864344562156F, -38.298319024476406F, 2.303415063101297F, 1.7366754498326762F, 0.8661819873762023F, -1.3943823420269F));
        g.addOrReplaceChild("domo_arena_36", CubeListBuilder.create().texOffs(928, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.398988117008003F, -38.72789543167236F, 1.5794664981684357F, 1.9202084714282943F, 1.1688863356259502F, -1.2128038013190983F));
        g.addOrReplaceChild("domo_arena_37", CubeListBuilder.create().texOffs(774, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.148131311622866F, -38.94529297370636F, 0.5864045420514868F, 2.780834530481421F, 1.3077500595575087F, -0.35377674018183575F));
        g.addOrReplaceChild("domo_arena_38", CubeListBuilder.create().texOffs(508, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.22768166401311F, -35.67830806393077F, 3.245415621172253F, 1.8133440419831757F, 0.0695852777830036F, -1.5390578084451754F));
        g.addOrReplaceChild("domo_arena_39", CubeListBuilder.create().texOffs(936, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.104929685536924F, -36.82700641892781F, 3.0665834321247645F, 1.84042330906434F, 0.2881105756091945F, -1.435659496238028F));
        g.addOrReplaceChild("domo_arena_40", CubeListBuilder.create().texOffs(944, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.86237241742508F, -37.66441492150743F, 2.7132119609330845F, 1.921700096811153F, 0.5440706032116124F, -1.2932341343475855F));
        g.addOrReplaceChild("domo_arena_41", CubeListBuilder.create().texOffs(952, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.50444296672575F, -38.298319024476406F, 2.191759614602519F, 2.0968428141845514F, 0.8092354722192847F, -1.0784443230325278F));
        g.addOrReplaceChild("domo_arena_42", CubeListBuilder.create().texOffs(782, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.03160620177118F, -38.72789543167236F, 1.5029036402333371F, 2.5734909357811198F, 0.8930483605148094F, -0.5495845482332957F));
        g.addOrReplaceChild("domo_arena_43", CubeListBuilder.create().texOffs(190, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.1072650921605F, -35.67830806393077F, 2.9149772039409614F, 2.076303250023468F, 0.06589541459899842F, -1.5191092886272948F));
        g.addOrReplaceChild("domo_arena_44", CubeListBuilder.create().texOffs(200, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.93604541392983F, -36.82700641892781F, 2.7543531683001894F, 2.11312686181303F, 0.2699703917383339F, -1.3526164710723425F));
        g.addOrReplaceChild("domo_arena_45", CubeListBuilder.create().texOffs(960, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.597716224338175F, -37.66441492150743F, 2.4369609131058416F, 2.2178356349299353F, 0.49561056795588276F, -1.135153643786621F));
        g.addOrReplaceChild("domo_arena_46", CubeListBuilder.create().texOffs(968, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.09846100956451F, -38.298319024476406F, 1.968601269866653F, 2.415943029681542F, 0.7031966539201708F, -0.8498646772505354F));
        g.addOrReplaceChild("domo_arena_47", CubeListBuilder.create().texOffs(790, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.43892818772198F, -38.72789543167236F, 1.3498825304284638F, 2.7641527219174287F, 0.70966353414391F, -0.4137876983255915F));
        g.addOrReplaceChild("domo_arena_48", CubeListBuilder.create().texOffs(210, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.74782783363838F, -35.67830806393077F, 2.4167617383470557F, 2.4055421807564F, 0.05476750749956518F, -1.4993602876017629F));
        g.addOrReplaceChild("domo_arena_49", CubeListBuilder.create().texOffs(220, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.54131121638596F, -36.82700641892781F, 2.2835908775009774F, 2.4422122878085872F, 0.22164495987580674F, -1.2730717809931482F));
        g.addOrReplaceChild("domo_arena_50", CubeListBuilder.create().texOffs(976, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.13323545970751F, -37.66441492150743F, 2.0204459522630236F, 2.5394866820102986F, 0.39468650644016195F, -0.9979059760143293F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("domo_arena_51", CubeListBuilder.create().texOffs(984, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.53105877554284F, -38.298319024476406F, 1.632136340772397F, 2.6995693540270813F, 0.536338592168021F, -0.6867391893918483F));
        g.addOrReplaceChild("domo_arena_52", CubeListBuilder.create().texOffs(798, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.735563253408028F, -38.72789543167236F, 1.119166368228206F, 2.9062449782422286F, 0.5447698791026189F, -0.34916772530451406F));
        g.addOrReplaceChild("domo_arena_53", CubeListBuilder.create().texOffs(230, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.17267722722147F, -35.67830806393077F, 1.7326412942324216F, 2.7572885485500156F, 0.03494474116657922F, -1.4855673655436774F));
        g.addOrReplaceChild("domo_arena_54", CubeListBuilder.create().texOffs(240, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.942750127017554F, -36.82700641892781F, 1.6371675331953874F, 2.780481765854989F, 0.1403492023242689F, -1.219606815024522F));
        g.addOrReplaceChild("domo_arena_55", CubeListBuilder.create().texOffs(992, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.488415378342538F, -37.66441492150743F, 1.4485118802195092F, 2.8388967318757583F, 0.2455544309461141F, -0.9144264851552044F));
        g.addOrReplaceChild("domo_arena_56", CubeListBuilder.create().texOffs(1000, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.817976647346097F, -38.298319024476406F, 1.1701223074533618F, 2.926994451205533F, 0.32646276279144065F, -0.6015790095575402F));
        g.addOrReplaceChild("domo_arena_57", CubeListBuilder.create().texOffs(806, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.932304680300007F, -38.72789543167236F, 0.8023603791553631F, 3.024366449727649F, 0.3759014550024246F, -0.3160537794189599F));
        g.addOrReplaceChild("domo_arena_58", CubeListBuilder.create().texOffs(520, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-24.38524713869442F, -35.67830806393077F, 0.6701232372101994F, 3.0626779032654876F, 0.010386778018180942F, -1.4811317502786803F));
        g.addOrReplaceChild("domo_arena_59", CubeListBuilder.create().texOffs(532, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-24.14360679524784F, -36.82700641892781F, 0.6331974257178017F, 3.067667327072016F, 0.04170284334348956F, -1.202813044553706F));
        g.addOrReplaceChild("domo_arena_60", CubeListBuilder.create().texOffs(762, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-23.666126739124913F, -37.66441492150743F, 0.5602322151395751F, 3.080050968257587F, 0.07290447887062972F, -0.8896220638612057F));
        g.addOrReplaceChild("domo_arena_61", CubeListBuilder.create().texOffs(1008, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.96153365255881F, -38.298319024476406F, 0.45256115689536947F, 3.0983146804273143F, 0.09682410651632807F, -0.5780100384170885F));
        g.addOrReplaceChild("domo_arena_62", CubeListBuilder.create().texOffs(250, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.030742640502275F, -38.72789543167236F, 0.3103240910156149F, 3.1181218973789826F, 0.11029877611305004F, -0.3008466216471993F));
        g.addOrReplaceChild("domo_arena_63", CubeListBuilder.create().texOffs(664, 357).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.75394869692334F, -38.94529297370636F, 0.11521324237682537F, 3.1358495035170626F, 0.15124842737115876F, -0.0724337304562263F));
        g.addOrReplaceChild("domo_arena_64", CubeListBuilder.create().texOffs(544, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-24.385247138694425F, -35.67830806393077F, -0.6701232371850969F, -3.0626779032684306F, -0.010386778017790282F, -1.4811317502786994F));
        g.addOrReplaceChild("domo_arena_65", CubeListBuilder.create().texOffs(556, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-24.14360679524784F, -36.82700641892781F, -0.6331974256940824F, -3.067667327074771F, -0.04170284334192439F, -1.2028130445537781F));
        g.addOrReplaceChild("domo_arena_66", CubeListBuilder.create().texOffs(772, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-23.666126739124913F, -37.66441492150743F, -0.5602322151185892F, -3.0800509682598762F, -0.07290447886790483F, -0.8896220638613108F));
        g.addOrReplaceChild("domo_arena_67", CubeListBuilder.create().texOffs(1016, 351).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.96153365255881F, -38.298319024476406F, -0.4525611568784167F, -3.098314680428921F, -0.0968241065127263F, -0.5780100384171871F));
        g.addOrReplaceChild("domo_arena_68", CubeListBuilder.create().texOffs(260, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.030742640502275F, -38.72789543167236F, -0.31032409100399033F, -3.118121897379853F, -0.11029877610896031F, -0.3008466216472602F));
        g.addOrReplaceChild("domo_arena_69", CubeListBuilder.create().texOffs(674, 357).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.75394869692334F, -38.94529297370636F, -0.11521324237250954F, -3.1358495035172775F, -0.15124842736557909F, -0.07243373045622628F));
        g.addOrReplaceChild("domo_arena_70", CubeListBuilder.create().texOffs(270, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.172677227221467F, -35.67830806393077F, -1.732641294232419F, -2.7572885485500156F, -0.03494474116657929F, -1.4855673655436774F));
        g.addOrReplaceChild("domo_arena_71", CubeListBuilder.create().texOffs(280, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.942750127017554F, -36.82700641892781F, -1.6371675331953846F, -2.7804817658549887F, -0.14034920232426878F, -1.219606815024522F));
        g.addOrReplaceChild("domo_arena_72", CubeListBuilder.create().texOffs(0, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.488415378342538F, -37.66441492150743F, -1.448511880219507F, -2.8388967318757583F, -0.24555443094611407F, -0.9144264851552044F));
        g.addOrReplaceChild("domo_arena_73", CubeListBuilder.create().texOffs(8, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.817976647346097F, -38.298319024476406F, -1.1701223074533598F, -2.926994451205533F, -0.32646276279144043F, -0.6015790095575402F));
        g.addOrReplaceChild("domo_arena_74", CubeListBuilder.create().texOffs(814, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.932304680300007F, -38.72789543167236F, -0.8023603791553616F, -3.024366449727649F, -0.37590145500242406F, -0.3160537794189599F));
        g.addOrReplaceChild("domo_arena_75", CubeListBuilder.create().texOffs(290, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.74782783363838F, -35.67830806393077F, -2.4167617383470543F, -2.405542180756404F, -0.054767507499565535F, -1.4993602876017618F));
        g.addOrReplaceChild("domo_arena_76", CubeListBuilder.create().texOffs(300, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.54131121638596F, -36.82700641892781F, -2.283590877500976F, -2.4422122878085895F, -0.22164495987580635F, -1.273071780993148F));
        g.addOrReplaceChild("domo_arena_77", CubeListBuilder.create().texOffs(16, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.133235459707514F, -37.66441492150743F, -2.0204459522630227F, -2.5394866820103004F, -0.3946865064401613F, -0.9979059760143287F));
        g.addOrReplaceChild("domo_arena_78", CubeListBuilder.create().texOffs(24, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.53105877554284F, -38.298319024476406F, -1.6321363407723957F, -2.6995693540270826F, -0.53633859216802F, -0.6867391893918479F));
        g.addOrReplaceChild("domo_arena_79", CubeListBuilder.create().texOffs(822, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.735563253408028F, -38.72789543167236F, -1.1191663682282051F, -2.906244978242229F, -0.5447698791026185F, -0.34916772530451406F));
        g.addOrReplaceChild("domo_arena_80", CubeListBuilder.create().texOffs(310, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-23.1072650921605F, -35.67830806393077F, -2.914977203940961F, -2.076303250023466F, -0.06589541459899872F, -1.5191092886272939F));
        g.addOrReplaceChild("domo_arena_81", CubeListBuilder.create().texOffs(320, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.93604541392983F, -36.82700641892781F, -2.754353168300189F, -2.1131268618130306F, -0.2699703917383334F, -1.3526164710723434F));
        g.addOrReplaceChild("domo_arena_82", CubeListBuilder.create().texOffs(32, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.597716224338175F, -37.66441492150743F, -2.4369609131058416F, -2.2178356349299375F, -0.4956105679558826F, -1.1351536437866203F));
        g.addOrReplaceChild("domo_arena_83", CubeListBuilder.create().texOffs(40, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.098461009564513F, -38.298319024476406F, -1.9686012698666524F, -2.4159430296815447F, -0.70319665392017F, -0.849864677250534F));
        g.addOrReplaceChild("domo_arena_84", CubeListBuilder.create().texOffs(830, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.43892818772198F, -38.72789543167236F, -1.3498825304284636F, -2.76415272191743F, -0.70966353414391F, -0.4137876983255915F));
        g.addOrReplaceChild("domo_arena_85", CubeListBuilder.create().texOffs(568, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-22.22768166401311F, -35.67830806393077F, -3.2454156211722522F, -1.813344041983177F, -0.06958527778300325F, -1.539057808445176F));
        g.addOrReplaceChild("domo_arena_86", CubeListBuilder.create().texOffs(48, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-22.104929685536927F, -36.82700641892781F, -3.0665834321247636F, -1.840423309064341F, -0.2881105756091946F, -1.4356594962380278F));
        g.addOrReplaceChild("domo_arena_87", CubeListBuilder.create().texOffs(56, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.86237241742508F, -37.66441492150743F, -2.713211960933084F, -1.9217000968111526F, -0.544070603211612F, -1.2932341343475855F));
        g.addOrReplaceChild("domo_arena_88", CubeListBuilder.create().texOffs(64, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-21.50444296672575F, -38.298319024476406F, -2.1917596146025184F, -2.0968428141845514F, -0.8092354722192847F, -1.0784443230325278F));
        g.addOrReplaceChild("domo_arena_89", CubeListBuilder.create().texOffs(838, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.031606201771183F, -38.72789543167236F, -1.5029036402333367F, -2.5734909357811198F, -0.8930483605148093F, -0.5495845482332957F));
        g.addOrReplaceChild("domo_arena_90", CubeListBuilder.create().texOffs(242, 309).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-20.861587019275554F, -35.67830806393077F, -3.4107477745401047F, -1.619408640158843F, -0.06994830128243942F, -1.5602996002721872F));
        g.addOrReplaceChild("domo_arena_91", CubeListBuilder.create().texOffs(350, 309).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-20.814110975927893F, -36.82700641892781F, -3.222805285192764F, -1.6297130960143158F, -0.2916084952792183F, -1.525836119056708F));
        g.addOrReplaceChild("domo_arena_92", CubeListBuilder.create().texOffs(782, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.72029856232674F, -37.66441492150743F, -2.8514319082082658F, -1.661674815878075F, -0.5614275801533994F, -1.4766162593007268F));
        g.addOrReplaceChild("domo_arena_93", CubeListBuilder.create().texOffs(792, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-20.581864344583337F, -38.298319024476406F, -2.3034150631012964F, -1.736675449838589F, -0.8661819873758286F, -1.3943823420206387F));
        g.addOrReplaceChild("domo_arena_94", CubeListBuilder.create().texOffs(72, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.39898811702253F, -38.72789543167236F, -1.5794664981684354F, -1.9202084714398628F, -1.1688863356244834F, -1.2128038013072497F));
        g.addOrReplaceChild("domo_arena_95", CubeListBuilder.create().texOffs(846, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.14813131162826F, -38.94529297370636F, -0.5864045420514867F, -2.780834530493019F, -1.3077500595494633F, -0.3537767401700019F));
        g.addOrReplaceChild("domo_arena_96", CubeListBuilder.create().texOffs(256, 309).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.138412980767313F, -35.67830806393077F, -3.4107477745401047F, -1.522184013433366F, -0.06994830128240621F, -1.5812930533170817F));
        g.addOrReplaceChild("domo_arena_97", CubeListBuilder.create().texOffs(362, 309).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-19.185889024112612F, -36.82700641892781F, -3.2228052851927647F, -1.5118795575784112F, -0.29160849527911215F, -1.6157565345308462F));
        g.addOrReplaceChild("domo_arena_98", CubeListBuilder.create().texOffs(802, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.2797014377091F, -37.66441492150743F, -2.8514319082082658F, -1.4799178377162319F, -0.5614275801533782F, -1.664976394284413F));
        g.addOrReplaceChild("domo_arena_99", CubeListBuilder.create().texOffs(812, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-19.418135655445614F, -38.298319024476406F, -2.303415063101297F, -1.4049172037592839F, -0.8661819873763392F, -1.7472103115605988F));
        g.addOrReplaceChild("domo_arena_100", CubeListBuilder.create().texOffs(80, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-19.601011882997323F, -38.72789543167236F, -1.5794664981684357F, -1.2213841821657412F, -1.1688863356264874F, -1.92878885226635F));
        g.addOrReplaceChild("domo_arena_101", CubeListBuilder.create().texOffs(854, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.851868688379113F, -38.94529297370636F, -0.5864045420514868F, -0.36075812311262356F, -1.3077500595604579F, -2.78781591340362F));
        g.addOrReplaceChild("domo_arena_102", CubeListBuilder.create().texOffs(580, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-17.772318335986892F, -35.67830806393077F, -3.2454156211722536F, -1.328248611606618F, -0.06958527778300327F, -1.602534845144617F));
        g.addOrReplaceChild("domo_arena_103", CubeListBuilder.create().texOffs(88, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.895070314463076F, -36.82700641892781F, -3.066583432124765F, -1.3011693445254537F, -0.28811057560919434F, -1.7059331573517642F));
        g.addOrReplaceChild("domo_arena_104", CubeListBuilder.create().texOffs(96, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.13762758257492F, -37.66441492150743F, -2.7132119609330845F, -1.219892556778641F, -0.5440706032116126F, -1.8483585192422076F));
        g.addOrReplaceChild("domo_arena_105", CubeListBuilder.create().texOffs(104, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-18.49555703327425F, -38.298319024476406F, -2.1917596146025193F, -1.0447498394052428F, -0.809235472219285F, -2.063148330557265F));
        g.addOrReplaceChild("domo_arena_106", CubeListBuilder.create().texOffs(862, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.96839379822882F, -38.72789543167236F, -1.5029036402333371F, -0.5681017178086737F, -0.8930483605148094F, -2.5920081053564976F));
        g.addOrReplaceChild("domo_arena_107", CubeListBuilder.create().texOffs(330, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.8927349078395F, -35.67830806393077F, -2.9149772039409623F, -1.0652894035663272F, -0.06589541459899834F, -1.6224833649624983F));
        g.addOrReplaceChild("domo_arena_108", CubeListBuilder.create().texOffs(340, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.063954586070174F, -36.82700641892781F, -2.75435316830019F, -1.0284657917767641F, -0.26997039173833365F, -1.7889761825174495F));
        g.addOrReplaceChild("domo_arena_109", CubeListBuilder.create().texOffs(112, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.402283775661825F, -37.66441492150743F, -2.436960913105842F, -0.9237570186598574F, -0.4956105679558831F, -2.006439009803173F));
        g.addOrReplaceChild("domo_arena_110", CubeListBuilder.create().texOffs(120, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.90153899043549F, -38.298319024476406F, -1.968601269866653F, -0.7256496239082505F, -0.7031966539201707F, -2.291727976339258F));
        g.addOrReplaceChild("domo_arena_111", CubeListBuilder.create().texOffs(870, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.561071812278023F, -38.72789543167236F, -1.3498825304284638F, -0.37743993167236434F, -0.7096635341439104F, -2.727804955264202F));
        g.addOrReplaceChild("domo_arena_112", CubeListBuilder.create().texOffs(350, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.25217216636162F, -35.67830806393077F, -2.416761738347056F, -0.7360504728333919F, -0.054767507499565014F, -1.6422323659880296F));
        g.addOrReplaceChild("domo_arena_113", CubeListBuilder.create().texOffs(360, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.45868878361404F, -36.82700641892781F, -2.283590877500978F, -0.6993803657812054F, -0.2216449598758067F, -1.8685208725966451F));
        g.addOrReplaceChild("domo_arena_114", CubeListBuilder.create().texOffs(128, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.86676454029249F, -37.66441492150743F, -2.0204459522630245F, -0.6021059715794924F, -0.39468650644016157F, -2.1436866775754657F));
        g.addOrReplaceChild("domo_arena_115", CubeListBuilder.create().texOffs(136, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.46894122445716F, -38.298319024476406F, -1.632136340772397F, -0.4420232995627111F, -0.5363385921680204F, -2.4548534641979445F));
        g.addOrReplaceChild("domo_arena_116", CubeListBuilder.create().texOffs(878, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.264436746591972F, -38.72789543167236F, -1.119166368228206F, -0.23534767534756454F, -0.5447698791026189F, -2.7924249282852793F));
        g.addOrReplaceChild("domo_arena_117", CubeListBuilder.create().texOffs(370, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.827322772778532F, -35.67830806393077F, -1.7326412942324225F, -0.3843041050397783F, -0.03494474116657898F, -1.6560252880461146F));
        g.addOrReplaceChild("domo_arena_118", CubeListBuilder.create().texOffs(380, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.057249872982446F, -36.82700641892781F, -1.6371675331953883F, -0.3611108877348048F, -0.14034920232426906F, -1.9219858385652713F));
        g.addOrReplaceChild("domo_arena_119", CubeListBuilder.create().texOffs(144, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-16.511584621657462F, -37.66441492150743F, -1.44851188021951F, -0.3026959217140372F, -0.24555443094611523F, -2.22716616843459F));
        g.addOrReplaceChild("domo_arena_120", CubeListBuilder.create().texOffs(152, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.182023352653903F, -38.298319024476406F, -1.1701223074533624F, -0.21459820238426258F, -0.32646276279144243F, -2.5400136440322516F));
        g.addOrReplaceChild("domo_arena_121", CubeListBuilder.create().texOffs(886, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-18.067695319699993F, -38.72789543167236F, -0.8023603791553634F, -0.11722620386214443F, -0.3759014550024248F, -2.8255388741708334F));
        g.addOrReplaceChild("domo_arena_122", CubeListBuilder.create().texOffs(592, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.614752861305579F, -35.67830806393077F, -0.6701232372180382F, -0.07891475032522545F, -0.010386778018302867F, -1.6604609033111184F));
        g.addOrReplaceChild("domo_arena_123", CubeListBuilder.create().texOffs(604, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-15.85639320475216F, -36.82700641892781F, -0.6331974257252087F, -0.0739253265186383F, -0.04170284334397836F, -1.938779609036109F));
        g.addOrReplaceChild("domo_arena_124", CubeListBuilder.create().texOffs(822, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-16.333873260875087F, -37.66441492150743F, -0.5602322151461286F, -0.06154168533292192F, -0.07290447887148085F, -2.251970589728621F));
        g.addOrReplaceChild("domo_arena_125", CubeListBuilder.create().texOffs(160, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.03846634744119F, -38.298319024476406F, -0.4525611569006634F, -0.043277973162980744F, -0.09682410651745282F, -2.5635826151727357F));
        g.addOrReplaceChild("domo_arena_126", CubeListBuilder.create().texOffs(390, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-17.969257359497725F, -38.72789543167236F, -0.31032409101924496F, -0.023470756211082282F, -0.11029877611432716F, -2.840746031942613F));
        g.addOrReplaceChild("domo_arena_127", CubeListBuilder.create().texOffs(684, 357).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-19.24605130307666F, -38.94529297370636F, -0.1152132423781731F, -0.005743150072797755F, -0.15124842737290117F, -3.0691589231335668F));
        g.addOrReplaceChild("domo_vapor_0", CubeListBuilder.create().texOffs(360, 334).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.38524713869442F, -35.76309657192212F, 0.6701232371976483F, 0.07898128495970484F, 0.009240545685903476F, -1.6505429736738513F));
        g.addOrReplaceChild("domo_vapor_1", CubeListBuilder.create().texOffs(616, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.1436067952478397F, -37.05538222129378F, 0.6331974257059422F, 0.0749508523010405F, 0.03758755501912242F, -1.9009588901114232F));
        g.addOrReplaceChild("domo_vapor_2", CubeListBuilder.create().texOffs(628, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.6661267391249135F, -37.99746678669586F, 0.5602322151290824F, 0.06427567059792495F, 0.06769953473411261F, -2.19517358376448F));
        g.addOrReplaceChild("domo_vapor_3", CubeListBuilder.create().texOffs(400, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.9615336525588103F, -38.710608902535945F, 0.45256115688689325F, 0.046866123226786696F, 0.09322296751544876F, -2.508495473667189F));
        g.addOrReplaceChild("domo_vapor_4", CubeListBuilder.create().texOffs(410, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.030742640502274488F, -39.193882360631406F, 0.3103240910098027F, 0.026102162691801444F, 0.1090454822034164F, -2.8057669327599455F));
        g.addOrReplaceChild("domo_vapor_5", CubeListBuilder.create().texOffs(694, 357).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.2460513030766598F, -39.43845459541965F, 0.11521324237466748F, 0.006456540622123599F, 0.15114492215371148F, -3.06014249053908F));
        g.addOrReplaceChild("domo_vapor_6", CubeListBuilder.create().texOffs(996, 348).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.172677227221468F, -35.76309657192212F, 1.7326412942324207F, 0.38461199514024796F, 0.03108827960436061F, -1.6465938818999084F));
        g.addOrReplaceChild("domo_vapor_7", CubeListBuilder.create().texOffs(420, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.9427501270175536F, -37.05538222129378F, 1.6371675331953863F, 0.36589470205152924F, 0.12649078800384964F, -1.8856327645270128F));
        g.addOrReplaceChild("domo_vapor_8", CubeListBuilder.create().texOffs(430, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.4884153783425373F, -37.99746678669586F, 1.4485118802195083F, 0.31569198005078475F, 0.2279836962187411F, -2.1711901389775283F));
        g.addOrReplaceChild("domo_vapor_9", CubeListBuilder.create().texOffs(440, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.8179766473460959F, -38.710608902535945F, 1.170122307453361F, 0.23206767102432493F, 0.3142617630373068F, -2.483993842754308F));
        g.addOrReplaceChild("domo_vapor_10", CubeListBuilder.create().texOffs(894, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-0.06769531969999515F, -39.193882360631406F, 0.8023603791553625F, 0.13028943901098317F, 0.3715953145645371F, -2.7890677727601916F));
        g.addOrReplaceChild("domo_vapor_11", CubeListBuilder.create().texOffs(1008, 348).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.7478278336383792F, -35.76309657192212F, 2.416761738347055F, 0.7365299515750781F, 0.04871839523878552F, -1.6343177415171966F));
        g.addOrReplaceChild("domo_vapor_12", CubeListBuilder.create().texOffs(450, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.5413112163859577F, -37.05538222129378F, 2.283590877500977F, 0.7070334775708477F, 0.19945120116628964F, -1.8370734419864376F));
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("domo_vapor_13", CubeListBuilder.create().texOffs(460, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.1332354597075107F, -37.99746678669586F, 2.0204459522630236F, 0.6243630099018597F, 0.36508331566755414F, -2.0914248061845044F));
        g.addOrReplaceChild("domo_vapor_14", CubeListBuilder.create().texOffs(470, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.5310587755428398F, -38.710608902535945F, 1.6321363407723966F, 0.47501450207611284F, 0.5143117130745245F, -2.396576964306602F));
        g.addOrReplaceChild("domo_vapor_15", CubeListBuilder.create().texOffs(902, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-0.2644367465919751F, -39.193882360631406F, 1.1191663682282056F, 0.2612314418605902F, 0.5380094265121743F, -2.7528410665500624F));
        g.addOrReplaceChild("domo_vapor_16", CubeListBuilder.create().texOffs(0, 351).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.1072650921605F, -35.76309657192212F, 2.914977203940961F, 1.065761977443255F, 0.058607653752114325F, -1.6167493379129658F));
        g.addOrReplaceChild("domo_vapor_17", CubeListBuilder.create().texOffs(480, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.936045413929828F, -37.05538222129378F, 2.754353168300189F, 1.0362638928077315F, 0.24232518511291992F, -1.7654016542150475F));
        g.addOrReplaceChild("domo_vapor_18", CubeListBuilder.create().texOffs(490, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.5977162243381733F, -37.99746678669586F, 2.4369609131058416F, 0.9486710609618635F, 0.45537570443326675F, -1.9632065506265126F));
        g.addOrReplaceChild("domo_vapor_19", CubeListBuilder.create().texOffs(168, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.09846100956451037F, -38.710608902535945F, 1.9686012698666526F, 0.7693630385357708F, 0.6688535708301449F, -2.2340438679848154F));
        g.addOrReplaceChild("domo_vapor_20", CubeListBuilder.create().texOffs(910, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-0.5610718122780208F, -39.193882360631406F, 1.3498825304284636F, 0.4175486716259329F, 0.6992894185453891F, -2.682728746518494F));
        g.addOrReplaceChild("domo_vapor_21", CubeListBuilder.create().texOffs(374, 334).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.22768166401311296F, -35.76309657192212F, 3.2454156211722527F, 1.328591391515035F, 0.06188092194328552F, -1.5990108436073345F));
        g.addOrReplaceChild("domo_vapor_22", CubeListBuilder.create().texOffs(500, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.10492968553692594F, -37.05538222129378F, 3.0665834321247636F, 1.3069655460763627F, 0.2580379023790637F, -1.6911045246020775F));
        g.addOrReplaceChild("domo_vapor_23", CubeListBuilder.create().texOffs(176, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.1376275825749172F, -37.99746678669586F, 2.713211960933084F, 1.2398421108651811F, 0.4966629171406366F, -1.819012319324255F));
        g.addOrReplaceChild("domo_vapor_24", CubeListBuilder.create().texOffs(184, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.4955570332742494F, -38.710608902535945F, 2.1917596146025184F, 1.0862331915520975F, 0.7622484338044001F, -2.0160383107043116F));
        g.addOrReplaceChild("domo_vapor_25", CubeListBuilder.create().texOffs(918, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-0.9683937982288191F, -39.193882360631406F, 1.502903640233337F, 0.6229932071738209F, 0.8759002206465418F, -2.5382193368015713F));
        g.addOrReplaceChild("domo_vapor_26", CubeListBuilder.create().texOffs(150, 309).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.1384129807359469F, -35.76309657192212F, 3.4107477745401047F, 1.5223133524210843F, 0.06219825657546708F, -1.580126889045151F));
        g.addOrReplaceChild("domo_vapor_27", CubeListBuilder.create().texOffs(270, 309).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.1858890240829738F, -37.05538222129378F, 3.222805285192764F, 1.5140995589618922F, 0.26079218503602813F, -1.610771125632853F));
        g.addOrReplaceChild("domo_vapor_28", CubeListBuilder.create().texOffs(832, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.279701437682875F, -37.99746678669586F, 2.8514319082082658F, 1.4879091899342547F, 0.510164621616423F, -1.6545900472429915F));
        g.addOrReplaceChild("domo_vapor_29", CubeListBuilder.create().texOffs(842, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.4181356554244287F, -38.710608902535945F, 2.3034150631012964F, 1.423577890695769F, 0.8092502776846168F, -1.7280102174315761F));
        g.addOrReplaceChild("domo_vapor_30", CubeListBuilder.create().texOffs(192, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.6010118829827962F, -39.193882360631406F, 1.5794664981684354F, 1.2589205929020126F, 1.1298096759213838F, -1.8918973500228315F));
        g.addOrReplaceChild("domo_vapor_31", CubeListBuilder.create().texOffs(926, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.8518686883737194F, -39.43845459541965F, 0.5864045420514867F, 0.4016167287068569F, 1.3037833892317567F, -2.7478141937699085F));
        g.addOrReplaceChild("domo_vapor_32", CubeListBuilder.create().texOffs(166, 309).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.861587019244185F, -35.76309657192212F, 3.4107477745401047F, 1.6192793011675921F, 0.062198256575453394F, -1.561465764544858F));
        g.addOrReplaceChild("domo_vapor_33", CubeListBuilder.create().texOffs(284, 309).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.814110975898253F, -37.05538222129378F, 3.2228052851927647F, 1.6274930946265929F, 0.26079218503598106F, -1.5308215279578632F));
        g.addOrReplaceChild("domo_vapor_34", CubeListBuilder.create().texOffs(852, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.720298562300515F, -37.99746678669586F, 2.8514319082082658F, 1.6536834636536275F, 0.5101646216163959F, -1.487002606348725F));
        g.addOrReplaceChild("domo_vapor_35", CubeListBuilder.create().texOffs(862, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.581864344562154F, -38.710608902535945F, 2.303415063101297F, 1.7180147628906821F, 0.8092502776847845F, -1.4135824361617686F));
        g.addOrReplaceChild("domo_vapor_36", CubeListBuilder.create().texOffs(200, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.3989881170080034F, -39.193882360631406F, 1.5794664981684357F, 1.8826720606811194F, 1.1298096759221756F, -1.2496953035738132F));
        g.addOrReplaceChild("domo_vapor_37", CubeListBuilder.create().texOffs(934, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-2.1481313116228646F, -39.43845459541965F, 0.5864045420514868F, 2.7399759248749334F, 1.3037833892367623F, -0.3937784598280555F));
        g.addOrReplaceChild("domo_vapor_38", CubeListBuilder.create().texOffs(388, 334).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.227681664013111F, -35.76309657192212F, 3.245415621172253F, 1.8130012620747582F, 0.061880921943285656F, -1.542581809982459F));
        g.addOrReplaceChild("domo_vapor_39", CubeListBuilder.create().texOffs(510, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.1049296855369235F, -37.05538222129378F, 3.0665834321247645F, 1.8346271075134304F, 0.25803790237906343F, -1.4504881289877156F));
        g.addOrReplaceChild("domo_vapor_40", CubeListBuilder.create().texOffs(208, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.862372417425081F, -37.99746678669586F, 2.7132119609330845F, 1.9017505427246122F, 0.4966629171406368F, -1.3225803342655382F));
        g.addOrReplaceChild("domo_vapor_41", CubeListBuilder.create().texOffs(216, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5044429667257493F, -38.710608902535945F, 2.191759614602519F, 2.0553594620376954F, 0.7622484338044003F, -1.1255543428854817F));
        g.addOrReplaceChild("domo_vapor_42", CubeListBuilder.create().texOffs(942, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.03160620177118F, -39.193882360631406F, 1.5029036402333371F, 2.518599446415972F, 0.8759002206465423F, -0.6033733167882223F));
        g.addOrReplaceChild("domo_vapor_43", CubeListBuilder.create().texOffs(12, 351).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.1072650921605F, -35.76309657192212F, 2.9149772039409614F, 2.0758306761465377F, 0.058607653752114325F, -1.5248433156768275F));
        g.addOrReplaceChild("domo_vapor_44", CubeListBuilder.create().texOffs(520, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.936045413929827F, -37.05538222129378F, 2.7543531683001894F, 2.105328760782061F, 0.2423251851129199F, -1.3761909993747459F));
        g.addOrReplaceChild("domo_vapor_45", CubeListBuilder.create().texOffs(530, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.597716224338172F, -37.99746678669586F, 2.4369609131058416F, 2.192921592627929F, 0.45537570443326675F, -1.1783861029632807F));
        g.addOrReplaceChild("domo_vapor_46", CubeListBuilder.create().texOffs(224, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0984610095645095F, -38.710608902535945F, 1.968601269866653F, 2.3722296150540223F, 0.6688535708301451F, -0.9075487856049783F));
        g.addOrReplaceChild("domo_vapor_47", CubeListBuilder.create().texOffs(950, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.438928187721978F, -39.193882360631406F, 1.3498825304284638F, 2.72404398196386F, 0.6992894185453894F, -0.45886390707129954F));
        g.addOrReplaceChild("domo_vapor_48", CubeListBuilder.create().texOffs(24, 351).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.747827833638379F, -35.76309657192212F, 2.4167617383470557F, 2.405062702014715F, 0.0487183952387854F, -1.5072749120725968F));
        g.addOrReplaceChild("domo_vapor_49", CubeListBuilder.create().texOffs(540, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.5413112163859575F, -37.05538222129378F, 2.2835908775009774F, 2.4345591760189453F, 0.1994512011662897F, -1.3045192116033557F));
        g.addOrReplaceChild("domo_vapor_50", CubeListBuilder.create().texOffs(550, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.13323545970751F, -37.99746678669586F, 2.0204459522630236F, 2.517229643687933F, 0.3650833156675544F, -1.0501678474052887F));
        g.addOrReplaceChild("domo_vapor_51", CubeListBuilder.create().texOffs(560, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.5310587755428395F, -38.710608902535945F, 1.632136340772397F, 2.6665781515136793F, 0.5143117130745252F, -0.7450156892831917F));
        g.addOrReplaceChild("domo_vapor_52", CubeListBuilder.create().texOffs(958, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.7355632534080243F, -39.193882360631406F, 1.119166368228206F, 2.8803612117292023F, 0.5380094265121744F, -0.3887515870397308F));
        g.addOrReplaceChild("domo_vapor_53", CubeListBuilder.create().texOffs(36, 351).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.172677227221468F, -35.76309657192212F, 1.7326412942324216F, 2.756980658449544F, 0.03108827960436061F, -1.494998771689885F));
        g.addOrReplaceChild("domo_vapor_54", CubeListBuilder.create().texOffs(570, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.942750127017553F, -37.05538222129378F, 1.6371675331953874F, 2.775697951538264F, 0.1264907880038498F, -1.2559598890627806F));
        g.addOrReplaceChild("domo_vapor_55", CubeListBuilder.create().texOffs(580, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.488415378342537F, -37.99746678669586F, 1.4485118802195092F, 2.825900673539009F, 0.2279836962187409F, -0.9704025146122651F));
        g.addOrReplaceChild("domo_vapor_56", CubeListBuilder.create().texOffs(590, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.817976647346096F, -38.710608902535945F, 1.1701223074533618F, 2.9095249825654688F, 0.3142617630373066F, -0.6575988108354855F));
        g.addOrReplaceChild("domo_vapor_57", CubeListBuilder.create().texOffs(966, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.932304680300005F, -39.193882360631406F, 0.8023603791553631F, 3.01130321457881F, 0.37159531456453704F, -0.3525248808296016F));
        g.addOrReplaceChild("domo_vapor_58", CubeListBuilder.create().texOffs(402, 334).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.385247138694421F, -35.76309657192212F, 0.6701232372101994F, 3.0626113686286156F, 0.009240545686077215F, -1.4910496799159334F));
        g.addOrReplaceChild("domo_vapor_59", CubeListBuilder.create().texOffs(640, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.143606795247839F, -37.05538222129378F, 0.6331974257178017F, 3.0666418012873558F, 0.03758755501982813F, -1.2406337634783369F));
        g.addOrReplaceChild("domo_vapor_60", CubeListBuilder.create().texOffs(652, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-5.6661267391249135F, -37.99746678669586F, 0.5602322151395751F, 3.077316982990672F, 0.06769953473537896F, -0.946419069825262F));
        g.addOrReplaceChild("domo_vapor_61", CubeListBuilder.create().texOffs(600, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.96153365255881F, -38.710608902535945F, 0.45256115689536947F, 3.094726530362136F, 0.0932229675171841F, -0.6330971799225534F));
        g.addOrReplaceChild("domo_vapor_62", CubeListBuilder.create().texOffs(610, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.030742640502274F, -39.193882360631406F, 0.3103240910156149F, 3.115490490897508F, 0.10904548220543867F, -0.33582572082981416F));
        g.addOrReplaceChild("domo_vapor_63", CubeListBuilder.create().texOffs(704, 357).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-2.75394869692334F, -39.43845459541965F, 0.11521324237682537F, 3.135136112967549F, 0.1511449221564995F, -0.08145016305071351F));
        g.addOrReplaceChild("domo_vapor_64", CubeListBuilder.create().texOffs(416, 334).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.385247138694421F, -35.76309657192212F, -0.6701232371850969F, -3.062611368631562F, -0.00924054568572966F, -1.4910496799159505F));
        g.addOrReplaceChild("domo_vapor_65", CubeListBuilder.create().texOffs(664, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-6.143606795247839F, -37.05538222129378F, -0.6331974256940824F, -3.06664180129015F, -0.03758755501841679F, -1.2406337634784028F));
        g.addOrReplaceChild("domo_vapor_66", CubeListBuilder.create().texOffs(676, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-5.6661267391249135F, -37.99746678669586F, -0.5602322151185892F, -3.077316982993065F, -0.06769953473284625F, -0.9464190698253641F));
        g.addOrReplaceChild("domo_vapor_67", CubeListBuilder.create().texOffs(620, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.96153365255881F, -38.710608902535945F, -0.4525611568784167F, -3.094726530363877F, -0.09322296751371326F, -0.6330971799226558F));
        g.addOrReplaceChild("domo_vapor_68", CubeListBuilder.create().texOffs(630, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.030742640502274F, -39.193882360631406F, -0.31032409100399033F, -3.1154904908984755F, -0.10904548220139403F, -0.33582572082988116F));
        g.addOrReplaceChild("domo_vapor_69", CubeListBuilder.create().texOffs(714, 357).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-2.75394869692334F, -39.43845459541965F, -0.11521324237250954F, -3.1351361129677904F, -0.1511449221509235F, -0.08145016305071351F));
        g.addOrReplaceChild("domo_vapor_70", CubeListBuilder.create().texOffs(48, 351).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.1726772272214685F, -35.76309657192212F, -1.732641294232419F, -2.756980658449545F, -0.03108827960436061F, -1.4949987716898847F));
        g.addOrReplaceChild("domo_vapor_71", CubeListBuilder.create().texOffs(640, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.942750127017555F, -37.05538222129378F, -1.6371675331953846F, -2.7756979515382643F, -0.12649078800384964F, -1.2559598890627803F));
        g.addOrReplaceChild("domo_vapor_72", CubeListBuilder.create().texOffs(650, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.4884153783425385F, -37.99746678669586F, -1.448511880219507F, -2.825900673539009F, -0.22798369621874082F, -0.9704025146122651F));
        g.addOrReplaceChild("domo_vapor_73", CubeListBuilder.create().texOffs(660, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.8179766473460965F, -38.710608902535945F, -1.1701223074533598F, -2.9095249825654688F, -0.3142617630373062F, -0.6575988108354852F));
        g.addOrReplaceChild("domo_vapor_74", CubeListBuilder.create().texOffs(974, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.932304680300005F, -39.193882360631406F, -0.8023603791553616F, -3.0113032145788106F, -0.3715953145645367F, -0.3525248808296017F));
        g.addOrReplaceChild("domo_vapor_75", CubeListBuilder.create().texOffs(60, 351).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.74782783363838F, -35.76309657192212F, -2.4167617383470543F, -2.405062702014716F, -0.04871839523878556F, -1.5072749120725966F));
        g.addOrReplaceChild("domo_vapor_76", CubeListBuilder.create().texOffs(670, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.541311216385958F, -37.05538222129378F, -2.283590877500976F, -2.4345591760189462F, -0.19945120116628948F, -1.3045192116033553F));
        g.addOrReplaceChild("domo_vapor_77", CubeListBuilder.create().texOffs(680, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.133235459707511F, -37.99746678669586F, -2.0204459522630227F, -2.5172296436879344F, -0.3650833156675538F, -1.0501678474052887F));
        g.addOrReplaceChild("domo_vapor_78", CubeListBuilder.create().texOffs(690, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.53105877554284F, -38.710608902535945F, -1.6321363407723957F, -2.6665781515136815F, -0.514311713074524F, -0.7450156892831907F));
        g.addOrReplaceChild("domo_vapor_79", CubeListBuilder.create().texOffs(982, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.735563253408025F, -39.193882360631406F, -1.1191663682282051F, -2.8803612117292032F, -0.5380094265121741F, -0.3887515870397309F));
        g.addOrReplaceChild("domo_vapor_80", CubeListBuilder.create().texOffs(72, 351).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-5.107265092160501F, -35.76309657192212F, -2.914977203940961F, -2.0758306761465386F, -0.05860765375211441F, -1.5248433156768273F));
        g.addOrReplaceChild("domo_vapor_81", CubeListBuilder.create().texOffs(700, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.936045413929829F, -37.05538222129378F, -2.754353168300189F, -2.1053287607820628F, -0.2423251851129197F, -1.3761909993747456F));
        g.addOrReplaceChild("domo_vapor_82", CubeListBuilder.create().texOffs(710, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.597716224338173F, -37.99746678669586F, -2.4369609131058416F, -2.1929215926279304F, -0.4553757044332667F, -1.17838610296328F));
        g.addOrReplaceChild("domo_vapor_83", CubeListBuilder.create().texOffs(232, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.098461009564511F, -38.710608902535945F, -1.9686012698666524F, -2.3722296150540227F, -0.6688535708301449F, -0.9075487856049779F));
        g.addOrReplaceChild("domo_vapor_84", CubeListBuilder.create().texOffs(990, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.43892818772198F, -39.193882360631406F, -1.3498825304284636F, -2.7240439819638604F, -0.6992894185453891F, -0.45886390707129915F));
        g.addOrReplaceChild("domo_vapor_85", CubeListBuilder.create().texOffs(430, 334).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-4.227681664013114F, -35.76309657192212F, -3.2454156211722522F, -1.813001262074759F, -0.06188092194328552F, -1.5425818099824589F));
        g.addOrReplaceChild("domo_vapor_86", CubeListBuilder.create().texOffs(720, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.104929685536928F, -37.05538222129378F, -3.0665834321247636F, -1.834627107513431F, -0.2580379023790635F, -1.4504881289877156F));
        g.addOrReplaceChild("domo_vapor_87", CubeListBuilder.create().texOffs(240, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.8623724174250844F, -37.99746678669586F, -2.713211960933084F, -1.901750542724613F, -0.4966629171406367F, -1.3225803342655373F));
        g.addOrReplaceChild("domo_vapor_88", CubeListBuilder.create().texOffs(248, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-3.5044429667257515F, -38.710608902535945F, -2.1917596146025184F, -2.0553594620376963F, -0.7622484338044003F, -1.1255543428854813F));
        g.addOrReplaceChild("domo_vapor_89", CubeListBuilder.create().texOffs(998, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-3.0316062017711816F, -39.193882360631406F, -1.5029036402333367F, -2.5185994464159727F, -0.8759002206465415F, -0.6033733167882216F));
        g.addOrReplaceChild("domo_vapor_90", CubeListBuilder.create().texOffs(182, 309).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.8615870192755533F, -35.76309657192212F, -3.4107477745401047F, -1.619279301169355F, -0.06219825657547505F, -1.5614657645445174F));
        g.addOrReplaceChild("domo_vapor_91", CubeListBuilder.create().texOffs(298, 309).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.814110975927893F, -37.05538222129378F, -3.222805285192764F, -1.627493094628658F, -0.26079218503605517F, -1.5308215279564061F));
        g.addOrReplaceChild("domo_vapor_92", CubeListBuilder.create().texOffs(872, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.720298562326739F, -37.99746678669586F, -2.8514319082082658F, -1.6536834636566442F, -0.5101646216164388F, -1.4870026063456887F));
        g.addOrReplaceChild("domo_vapor_93", CubeListBuilder.create().texOffs(882, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-2.5818643445833382F, -38.710608902535945F, -2.3034150631012964F, -1.7180147628959586F, -0.8092502776845196F, -1.4135824361561613F));
        g.addOrReplaceChild("domo_vapor_94", CubeListBuilder.create().texOffs(256, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.3989881170225296F, -39.193882360631406F, -1.5794664981684354F, -1.882672060691636F, -1.129809675920926F, -1.2496953035629954F));
        g.addOrReplaceChild("domo_vapor_95", CubeListBuilder.create().texOffs(1006, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-2.1481313116282577F, -39.43845459541965F, -0.5864045420514867F, -2.7399759248875686F, -1.3037833892288597F, -0.39377845981515575F));
        g.addOrReplaceChild("domo_vapor_96", CubeListBuilder.create().texOffs(198, 309).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.1384129807673145F, -35.76309657192212F, -3.4107477745401047F, -1.5223133524228474F, -0.062198256575445414F, -1.5801268890448101F));
        g.addOrReplaceChild("domo_vapor_97", CubeListBuilder.create().texOffs(312, 309).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.1858890241126125F, -37.05538222129378F, -3.2228052851927647F, -1.5140995589639576F, -0.2607921850359539F, -1.610771125631396F));
        g.addOrReplaceChild("domo_vapor_98", CubeListBuilder.create().texOffs(892, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.2797014377090985F, -37.99746678669586F, -2.8514319082082658F, -1.4879091899372712F, -0.51016462161638F, -1.6545900472399555F));
        g.addOrReplaceChild("domo_vapor_99", CubeListBuilder.create().texOffs(902, 334).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-1.4181356554456124F, -38.710608902535945F, -2.303415063101297F, -1.4235778907010455F, -0.8092502776848821F, -1.728010217425969F));
        g.addOrReplaceChild("domo_vapor_100", CubeListBuilder.create().texOffs(264, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-1.6010118829973221F, -39.193882360631406F, -1.5794664981684357F, -1.2589205929125291F, -1.129809675922634F, -1.8918973500120142F));
        g.addOrReplaceChild("domo_vapor_101", CubeListBuilder.create().texOffs(1014, 357).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.8518686883791124F, -39.43845459541965F, -0.5864045420514868F, -0.4016167287194918F, -1.3037833892396584F, -2.747814193757009F));
        g.addOrReplaceChild("domo_vapor_102", CubeListBuilder.create().texOffs(444, 334).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(0.22768166401310985F, -35.76309657192212F, -3.2454156211722536F, -1.3285913915150354F, -0.06188092194328554F, -1.5990108436073343F));
    }

    private static void piezas6(PartDefinition g) {
        g.addOrReplaceChild("domo_vapor_103", CubeListBuilder.create().texOffs(730, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.104929685536923F, -37.05538222129378F, -3.066583432124765F, -1.3069655460763636F, -0.25803790237906343F, -1.6911045246020773F));
        g.addOrReplaceChild("domo_vapor_104", CubeListBuilder.create().texOffs(272, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.13762758257491975F, -37.99746678669586F, -2.7132119609330845F, -1.2398421108651816F, -0.496662917140637F, -1.8190123193242547F));
        g.addOrReplaceChild("domo_vapor_105", CubeListBuilder.create().texOffs(280, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-0.4955570332742515F, -38.710608902535945F, -2.1917596146025193F, -1.0862331915520984F, -0.7622484338044001F, -2.016038310704311F));
        g.addOrReplaceChild("domo_vapor_106", CubeListBuilder.create().texOffs(0, 359).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-0.9683937982288205F, -39.193882360631406F, -1.5029036402333371F, -0.6229932071738215F, -0.8759002206465424F, -2.538219336801571F));
        g.addOrReplaceChild("domo_vapor_107", CubeListBuilder.create().texOffs(84, 351).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.1072650921604983F, -35.76309657192212F, -2.9149772039409623F, -1.065761977443256F, -0.05860765375211429F, -1.6167493379129656F));
        g.addOrReplaceChild("domo_vapor_108", CubeListBuilder.create().texOffs(740, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.9360454139298263F, -37.05538222129378F, -2.75435316830019F, -1.0362638928077323F, -0.24232518511291998F, -1.7654016542150472F));
        g.addOrReplaceChild("domo_vapor_109", CubeListBuilder.create().texOffs(750, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.5977162243381718F, -37.99746678669586F, -2.436960913105842F, -0.9486710609618642F, -0.455375704433267F, -1.9632065506265124F));
        g.addOrReplaceChild("domo_vapor_110", CubeListBuilder.create().texOffs(288, 354).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.09846100956450915F, -38.710608902535945F, -1.968601269866653F, -0.7693630385357713F, -0.6688535708301451F, -2.234043867984815F));
        g.addOrReplaceChild("domo_vapor_111", CubeListBuilder.create().texOffs(8, 359).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-0.5610718122780216F, -39.193882360631406F, -1.3498825304284638F, -0.4175486716259334F, -0.6992894185453895F, -2.6827287465184937F));
        g.addOrReplaceChild("domo_vapor_112", CubeListBuilder.create().texOffs(96, 351).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.7478278336383783F, -35.76309657192212F, -2.416761738347056F, -0.7365299515750778F, -0.04871839523878536F, -1.6343177415171966F));
        g.addOrReplaceChild("domo_vapor_113", CubeListBuilder.create().texOffs(760, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.541311216385957F, -37.05538222129378F, -2.283590877500978F, -0.7070334775708473F, -0.1994512011662897F, -1.8370734419864378F));
        g.addOrReplaceChild("domo_vapor_114", CubeListBuilder.create().texOffs(770, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.1332354597075103F, -37.99746678669586F, -2.0204459522630245F, -0.6243630099018596F, -0.3650833156675543F, -2.0914248061845044F));
        g.addOrReplaceChild("domo_vapor_115", CubeListBuilder.create().texOffs(780, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.5310587755428393F, -38.710608902535945F, -1.632136340772397F, -0.47501450207611323F, -0.5143117130745247F, -2.3965769643066017F));
        g.addOrReplaceChild("domo_vapor_116", CubeListBuilder.create().texOffs(16, 359).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-0.2644367465919754F, -39.193882360631406F, -1.119166368228206F, -0.26123144186059044F, -0.5380094265121745F, -2.7528410665500624F));
        g.addOrReplaceChild("domo_vapor_117", CubeListBuilder.create().texOffs(108, 351).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.1726772272214676F, -35.76309657192212F, -1.7326412942324225F, -0.3846119951402496F, -0.031088279604360534F, -1.6465938818999084F));
        g.addOrReplaceChild("domo_vapor_118", CubeListBuilder.create().texOffs(790, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.9427501270175531F, -37.05538222129378F, -1.6371675331953883F, -0.36589470205153063F, -0.12649078800385002F, -1.8856327645270128F));
        g.addOrReplaceChild("domo_vapor_119", CubeListBuilder.create().texOffs(800, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(1.488415378342537F, -37.99746678669586F, -1.44851188021951F, -0.31569198005078575F, -0.2279836962187414F, -2.171190138977528F));
        g.addOrReplaceChild("domo_vapor_120", CubeListBuilder.create().texOffs(810, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.8179766473460954F, -38.710608902535945F, -1.1701223074533624F, -0.23206767102432538F, -0.3142617630373072F, -2.4839938427543076F));
        g.addOrReplaceChild("domo_vapor_121", CubeListBuilder.create().texOffs(24, 359).addBox(-1.5F, -1.0F, -0.5F, 3.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-0.06769531969999548F, -39.193882360631406F, -0.8023603791553634F, -0.13028943901098344F, -0.3715953145645375F, -2.7890677727601916F));
        g.addOrReplaceChild("domo_vapor_122", CubeListBuilder.create().texOffs(458, 334).addBox(-2.0F, -1.0F, -1.5F, 4.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.38524713869442F, -35.76309657192212F, -0.6701232372180382F, -0.07898128496209757F, -0.009240545686185792F, -1.650542973673865F));
        g.addOrReplaceChild("domo_vapor_123", CubeListBuilder.create().texOffs(688, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(2.1436067952478397F, -37.05538222129378F, -0.6331974257252087F, -0.07495085230330978F, -0.03758755502026869F, -1.900958890111477F));
        g.addOrReplaceChild("domo_vapor_124", CubeListBuilder.create().texOffs(700, 334).addBox(-1.5F, -1.0F, -1.5F, 3.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(1.666126739124913F, -37.99746678669586F, -0.5602322151461286F, -0.0642756705998682F, -0.06769953473616967F, -2.195173583764563F));
        g.addOrReplaceChild("domo_vapor_125", CubeListBuilder.create().texOffs(820, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.9615336525588101F, -38.710608902535945F, -0.4525611569006634F, -0.04686612322820083F, -0.09322296751826802F, -2.5084954736672724F));
        g.addOrReplaceChild("domo_vapor_126", CubeListBuilder.create().texOffs(830, 351).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.03074264050227432F, -39.193882360631406F, -0.31032409101924496F, -0.026102162692587763F, -0.10904548220670185F, -2.8057669327599997F));
        g.addOrReplaceChild("domo_vapor_127", CubeListBuilder.create().texOffs(724, 357).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.2460513030766598F, -39.43845459541965F, -0.1152132423781731F, -0.006456540622319833F, -0.15114492215824069F, -3.06014249053908F));
        g.addOrReplaceChild("silbato_0", CubeListBuilder.create().texOffs(334, 300).addBox(-6.0F, -39.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(922, 230).addBox(-2.5F, -39.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offset(14.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("silbato_1", CubeListBuilder.create().texOffs(368, 300).addBox(-6.0F, -39.0F, -2.5F, 12.0F, 3.0F, 5.0F).texOffs(956, 230).addBox(-2.5F, -39.0F, -6.0F, 5.0F, 3.0F, 12.0F), PartPose.offsetAndRotation(14.0F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F, 0.0F));
        g.addOrReplaceChild("pasamanos", CubeListBuilder.create().texOffs(392, 354).addBox(-44.0F, -33.0F, 10.0F, 72.0F, 1.0F, 1.0F).texOffs(538, 354).addBox(-44.0F, -33.0F, -11.0F, 72.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina", CubeListBuilder.create().texOffs(628, 202).addBox(31.0F, -38.0F, 11.5F, 17.0F, 24.0F, 1.0F).texOffs(664, 202).addBox(31.0F, -38.0F, -12.5F, 17.0F, 24.0F, 1.0F).texOffs(700, 202).addBox(31.0F, -15.0F, -11.5F, 17.0F, 1.0F, 23.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_frente", CubeListBuilder.create().texOffs(554, 142).addBox(0.0F, -8.0F, 0.0F, 1.0F, 8.0F, 25.0F), PartPose.offset(30.0F, -32.0F, -12.5F));
        g.addOrReplaceChild("cabina_fuego", CubeListBuilder.create().texOffs(258, 230).addBox(31.0F, -26.0F, -5.0F, 2.0F, 11.0F, 10.0F).texOffs(430, 300).addBox(33.0F, -20.0F, -2.0F, 1.0F, 3.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("cabina_techo_0", CubeListBuilder.create().texOffs(694, 309).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -37.280047391071406F, -11.526459469667696F, -2.6818551972416236F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_1", CubeListBuilder.create().texOffs(742, 309).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -38.16112455113704F, -9.542532937373895F, -2.7654438256685654F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_2", CubeListBuilder.create().texOffs(790, 309).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -38.873484783820615F, -7.491970978685589F, -2.8490324540955045F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_3", CubeListBuilder.create().texOffs(838, 309).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -39.41215368367204F, -5.389092650331454F, -2.932621082522443F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_4", CubeListBuilder.create().texOffs(886, 309).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -39.77336973034208F, -3.2485823338048823F, -3.016209710949384F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_5", CubeListBuilder.create().texOffs(934, 309).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -39.95461055524703F, -1.085387194452817F, -3.0997983393763233F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_6", CubeListBuilder.create().texOffs(0, 314).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -39.95461055524703F, 1.0853871944528155F, 3.0997983393763233F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_7", CubeListBuilder.create().texOffs(48, 314).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -39.77336973034208F, 3.2485823338048796F, 3.016209710949384F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_8", CubeListBuilder.create().texOffs(96, 314).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -39.41215368367204F, 5.3890926503314525F, 2.932621082522443F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_9", CubeListBuilder.create().texOffs(144, 314).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -38.873484783820615F, 7.491970978685588F, 2.849032454095504F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_10", CubeListBuilder.create().texOffs(192, 314).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -38.16112455113704F, 9.542532937373895F, 2.765443825668566F, 0.0F, 0.0F));
        g.addOrReplaceChild("cabina_techo_11", CubeListBuilder.create().texOffs(240, 314).addBox(-10.5F, -1.0F, -1.5F, 21.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.5F, -37.280047391071406F, 11.526459469667696F, 2.6818551972416236F, 0.0F, 0.0F));
        g.addOrReplaceChild("numeroi", CubeListBuilder.create().texOffs(262, 300).addBox(0.0F, -7.0F, -0.5F, 17.0F, 7.0F, 1.0F), PartPose.offset(34.75F, -20.25F, -13.0F));
        g.addOrReplaceChild("numerod", CubeListBuilder.create().texOffs(298, 300).addBox(0.0F, -7.0F, -0.5F, 17.0F, 7.0F, 1.0F), PartPose.offset(34.75F, -20.25F, 13.0F));
    }

    private static void piezas7(PartDefinition g) {
        g.addOrReplaceChild("rurmi0_0", CubeListBuilder.create().texOffs(0, 252).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(60, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(534, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(344, 354).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(58.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rurmi0_1", CubeListBuilder.create().texOffs(90, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(58.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rurmi0_2", CubeListBuilder.create().texOffs(120, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(58.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rurmi1_0", CubeListBuilder.create().texOffs(0, 252).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(60, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(544, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(350, 354).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(72.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rurmi1_1", CubeListBuilder.create().texOffs(90, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rurmi1_2", CubeListBuilder.create().texOffs(120, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rurmi2_0", CubeListBuilder.create().texOffs(0, 252).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(60, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(554, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(356, 354).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(86.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rurmi2_1", CubeListBuilder.create().texOffs(90, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rurmi2_2", CubeListBuilder.create().texOffs(120, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rurmi3_0", CubeListBuilder.create().texOffs(0, 252).addBox(-6.5F, -6.5F, -6.0F, 13.0F, 13.0F, 2.0F).texOffs(60, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(564, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F).texOffs(362, 354).addBox(-1.0F, -3.5F, -7.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(100.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rurmi3_1", CubeListBuilder.create().texOffs(90, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(100.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rurmi3_2", CubeListBuilder.create().texOffs(120, 309).addBox(-6.5F, -1.5F, -6.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 252).addBox(-1.5F, -6.5F, -6.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(100.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rubiela_i", CubeListBuilder.create().texOffs(856, 354).addBox(58.0F, -9.5F, -7.5F, 42.0F, 1.0F, 1.0F).texOffs(992, 334).addBox(56.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(1000, 334).addBox(70.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(1008, 334).addBox(84.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F).texOffs(1016, 334).addBox(98.5F, -10.5F, -7.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("rumotriz_i", CubeListBuilder.create().texOffs(242, 357).addBox(0.0F, -0.5F, -0.5F, 24.0F, 1.0F, 1.0F).texOffs(0, 338).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(86.0F, -9.0F, -8.5F));
        g.addOrReplaceChild("rucruceta_i", CubeListBuilder.create().texOffs(574, 309).addBox(108.36943652456003F, -8.0F, -9.5F, 3.0F, 3.0F, 2.0F).texOffs(610, 357).addBox(109.86943652456003F, -7.0F, -9.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("ruguias_i", CubeListBuilder.create().texOffs(454, 357).addBox(103.36943652456003F, -5.0F, -9.0F, 13.0F, 1.0F, 1.0F).texOffs(482, 357).addBox(103.36943652456003F, -9.0F, -9.0F, 13.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("rucil_i_0", CubeListBuilder.create().texOffs(112, 267).addBox(116.36943652456003F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(538, 252).addBox(116.36943652456003F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, -8.5F));
        g.addOrReplaceChild("rucil_i_1", CubeListBuilder.create().texOffs(140, 267).addBox(116.36943652456003F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(582, 252).addBox(116.36943652456003F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_i_2", CubeListBuilder.create().texOffs(168, 267).addBox(116.36943652456003F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(626, 252).addBox(116.36943652456003F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_i_3", CubeListBuilder.create().texOffs(196, 267).addBox(116.36943652456003F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(670, 252).addBox(116.36943652456003F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_i_a_0", CubeListBuilder.create().texOffs(514, 279).addBox(115.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(66, 279).addBox(115.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, -8.5F));
        g.addOrReplaceChild("rucil_i_a_1", CubeListBuilder.create().texOffs(520, 279).addBox(115.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(88, 279).addBox(115.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_i_a_2", CubeListBuilder.create().texOffs(526, 279).addBox(115.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(110, 279).addBox(115.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_i_a_3", CubeListBuilder.create().texOffs(532, 279).addBox(115.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(132, 279).addBox(115.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_i_b_0", CubeListBuilder.create().texOffs(538, 279).addBox(127.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(154, 279).addBox(127.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, -8.5F));
        g.addOrReplaceChild("rucil_i_b_1", CubeListBuilder.create().texOffs(544, 279).addBox(127.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(176, 279).addBox(127.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_i_b_2", CubeListBuilder.create().texOffs(550, 279).addBox(127.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(198, 279).addBox(127.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_i_b_3", CubeListBuilder.create().texOffs(556, 279).addBox(127.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(220, 279).addBox(127.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, -8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rurmd0_0", CubeListBuilder.create().texOffs(0, 252).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(60, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(584, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(368, 354).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(58.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rurmd0_1", CubeListBuilder.create().texOffs(90, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(58.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rurmd0_2", CubeListBuilder.create().texOffs(120, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(58.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rurmd1_0", CubeListBuilder.create().texOffs(0, 252).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(60, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(594, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(374, 354).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(72.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rurmd1_1", CubeListBuilder.create().texOffs(90, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rurmd1_2", CubeListBuilder.create().texOffs(120, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(72.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rurmd2_0", CubeListBuilder.create().texOffs(0, 252).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(60, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(604, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(380, 354).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(86.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rurmd2_1", CubeListBuilder.create().texOffs(90, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rurmd2_2", CubeListBuilder.create().texOffs(120, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(86.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rurmd3_0", CubeListBuilder.create().texOffs(0, 252).addBox(-6.5F, -6.5F, 4.0F, 13.0F, 13.0F, 2.0F).texOffs(60, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(60, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(614, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F).texOffs(386, 354).addBox(-1.0F, -3.5F, 6.0F, 2.0F, 2.0F, 1.0F), PartPose.offset(100.0F, -6.5F, 0.0F));
        g.addOrReplaceChild("rurmd3_1", CubeListBuilder.create().texOffs(90, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(70, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(100.0F, -6.5F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rurmd3_2", CubeListBuilder.create().texOffs(120, 309).addBox(-6.5F, -1.5F, 4.0F, 13.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(80, 252).addBox(-1.5F, -6.5F, 4.0F, 3.0F, 13.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(100.0F, -6.5F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rubiela_d", CubeListBuilder.create().texOffs(0, 357).addBox(58.0F, -9.5F, 6.5F, 42.0F, 1.0F, 1.0F).texOffs(8, 338).addBox(56.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(16, 338).addBox(70.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(24, 338).addBox(84.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F).texOffs(32, 338).addBox(98.5F, -10.5F, 6.5F, 3.0F, 3.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("rumotriz_d", CubeListBuilder.create().texOffs(292, 357).addBox(0.0F, -0.5F, -0.5F, 24.0F, 1.0F, 1.0F).texOffs(40, 338).addBox(-1.5F, -1.5F, -0.5F, 3.0F, 3.0F, 1.0F), PartPose.offset(86.0F, -9.0F, 8.5F));
        g.addOrReplaceChild("rucruceta_d", CubeListBuilder.create().texOffs(624, 309).addBox(108.36943652456003F, -8.0F, 7.5F, 3.0F, 3.0F, 2.0F).texOffs(632, 357).addBox(109.86943652456003F, -7.0F, 8.0F, 10.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("ruguias_d", CubeListBuilder.create().texOffs(510, 357).addBox(103.36943652456003F, -5.0F, 8.0F, 13.0F, 1.0F, 1.0F).texOffs(538, 357).addBox(103.36943652456003F, -9.0F, 8.0F, 13.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("rucil_d_0", CubeListBuilder.create().texOffs(224, 267).addBox(116.36943652456003F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(714, 252).addBox(116.36943652456003F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, 8.5F));
        g.addOrReplaceChild("rucil_d_1", CubeListBuilder.create().texOffs(252, 267).addBox(116.36943652456003F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(758, 252).addBox(116.36943652456003F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_d_2", CubeListBuilder.create().texOffs(280, 267).addBox(116.36943652456003F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(802, 252).addBox(116.36943652456003F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_d_3", CubeListBuilder.create().texOffs(308, 267).addBox(116.36943652456003F, -5.0F, -1.0F, 12.0F, 10.0F, 2.0F).texOffs(846, 252).addBox(116.36943652456003F, -1.0F, -5.0F, 12.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_d_a_0", CubeListBuilder.create().texOffs(562, 279).addBox(115.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(242, 279).addBox(115.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, 8.5F));
        g.addOrReplaceChild("rucil_d_a_1", CubeListBuilder.create().texOffs(568, 279).addBox(115.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(264, 279).addBox(115.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_d_a_2", CubeListBuilder.create().texOffs(574, 279).addBox(115.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(286, 279).addBox(115.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_d_a_3", CubeListBuilder.create().texOffs(580, 279).addBox(115.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(308, 279).addBox(115.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_d_b_0", CubeListBuilder.create().texOffs(586, 279).addBox(127.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(330, 279).addBox(127.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offset(0.0F, -6.5F, 8.5F));
        g.addOrReplaceChild("rucil_d_b_1", CubeListBuilder.create().texOffs(592, 279).addBox(127.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(352, 279).addBox(127.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.39269908169872414F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_d_b_2", CubeListBuilder.create().texOffs(598, 279).addBox(127.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(374, 279).addBox(127.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 0.7853981633974483F, 0.0F, 0.0F));
        g.addOrReplaceChild("rucil_d_b_3", CubeListBuilder.create().texOffs(604, 279).addBox(127.86943652456003F, -5.0F, -1.0F, 1.0F, 10.0F, 2.0F).texOffs(396, 279).addBox(127.86943652456003F, -1.0F, -5.0F, 1.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(0.0F, -6.5F, 8.5F, 1.1780972450961724F, 0.0F, 0.0F));
        g.addOrReplaceChild("rubi0_0", CubeListBuilder.create().texOffs(746, 279).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(240, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(834, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(634, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(118.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rubi0_1", CubeListBuilder.create().texOffs(260, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(842, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(118.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rubi0_2", CubeListBuilder.create().texOffs(280, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(850, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(118.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rubi1_0", CubeListBuilder.create().texOffs(746, 279).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(240, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(834, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(644, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(128.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rubi1_1", CubeListBuilder.create().texOffs(260, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(842, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(128.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rubi1_2", CubeListBuilder.create().texOffs(280, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(850, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(128.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rubd0_0", CubeListBuilder.create().texOffs(746, 279).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(240, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(834, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(654, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(118.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rubd0_1", CubeListBuilder.create().texOffs(260, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(842, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(118.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rubd0_2", CubeListBuilder.create().texOffs(280, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(850, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(118.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rubd1_0", CubeListBuilder.create().texOffs(746, 279).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(240, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(834, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(664, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(128.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rubd1_1", CubeListBuilder.create().texOffs(260, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(842, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(128.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rubd1_2", CubeListBuilder.create().texOffs(280, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(850, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(128.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ruti0_0", CubeListBuilder.create().texOffs(766, 279).addBox(-4.0F, -4.0F, -6.0F, 8.0F, 8.0F, 2.0F).texOffs(300, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(858, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(674, 309).addBox(-1.0F, -1.0F, -6.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(46.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("ruti0_1", CubeListBuilder.create().texOffs(320, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(866, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("ruti0_2", CubeListBuilder.create().texOffs(340, 334).addBox(-4.0F, -1.0F, -6.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(874, 279).addBox(-1.0F, -4.0F, -6.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("rutd0_0", CubeListBuilder.create().texOffs(766, 279).addBox(-4.0F, -4.0F, 4.0F, 8.0F, 8.0F, 2.0F).texOffs(300, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(858, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(684, 309).addBox(-1.0F, -1.0F, 3.5F, 2.0F, 2.0F, 3.0F), PartPose.offset(46.0F, -4.0F, 0.0F));
        g.addOrReplaceChild("rutd0_1", CubeListBuilder.create().texOffs(320, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(866, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F));
        g.addOrReplaceChild("rutd0_2", CubeListBuilder.create().texOffs(340, 334).addBox(-4.0F, -1.0F, 4.0F, 8.0F, 2.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(874, 279).addBox(-1.0F, -4.0F, 4.0F, 2.0F, 8.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(46.0F, -4.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F));
        g.addOrReplaceChild("ru_bastidor", CubeListBuilder.create().texOffs(404, 291).addBox(40.0F, -12.0F, 2.0F, 100.0F, 8.0F, 1.0F).texOffs(606, 291).addBox(40.0F, -12.0F, -3.0F, 100.0F, 8.0F, 1.0F).texOffs(380, 202).addBox(40.0F, -12.0F, -12.0F, 100.0F, 1.0F, 24.0F).texOffs(660, 142).addBox(140.0F, -12.0F, -12.0F, 3.0F, 6.0F, 24.0F).texOffs(416, 300).addBox(143.0F, -11.0F, -2.0F, 3.0F, 4.0F, 4.0F), PartPose.ZERO);
        g.addOrReplaceChild("ru_tanque", CubeListBuilder.create().texOffs(328, 142).addBox(50.0F, -27.0F, -12.5F, 88.0F, 15.0F, 25.0F).texOffs(488, 230).addBox(50.0F, -32.0F, -7.5F, 88.0F, 5.0F, 15.0F), PartPose.ZERO);
        g.addOrReplaceChild("ru_tanque_cantoi_0", CubeListBuilder.create().texOffs(0, 345).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(94.0F, -27.772542485937365F, -12.377641290737884F, -1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("ru_tanque_cantoi_1", CubeListBuilder.create().texOffs(180, 345).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(94.0F, -29.24200561666855F, -11.900183776675252F, -2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("ru_tanque_cantoi_2", CubeListBuilder.create().texOffs(360, 345).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(94.0F, -30.49200561666855F, -10.99200561666855F, -2.3561944901923457F, 0.0F, 0.0F));
        g.addOrReplaceChild("ru_tanque_cantoi_3", CubeListBuilder.create().texOffs(540, 345).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(94.0F, -31.400183776675252F, -9.74200561666855F, -2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("ru_tanque_cantoi_4", CubeListBuilder.create().texOffs(720, 345).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(94.0F, -31.877641290737884F, -8.272542485937368F, -2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("ru_tanque_cantod_0", CubeListBuilder.create().texOffs(0, 348).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(94.0F, -27.772542485937365F, 12.377641290737884F, 1.7278759594743862F, 0.0F, 0.0F));
        g.addOrReplaceChild("ru_tanque_cantod_1", CubeListBuilder.create().texOffs(180, 348).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(94.0F, -29.24200561666855F, 11.900183776675252F, 2.0420352248333655F, 0.0F, 0.0F));
        g.addOrReplaceChild("ru_tanque_cantod_2", CubeListBuilder.create().texOffs(360, 348).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(94.0F, -30.49200561666855F, 10.99200561666855F, 2.3561944901923457F, 0.0F, 0.0F));
        g.addOrReplaceChild("ru_tanque_cantod_3", CubeListBuilder.create().texOffs(540, 348).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(94.0F, -31.400183776675252F, 9.74200561666855F, 2.6703537555513237F, 0.0F, 0.0F));
        g.addOrReplaceChild("ru_tanque_cantod_4", CubeListBuilder.create().texOffs(720, 348).addBox(-44.0F, -1.0F, -1.0F, 88.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(94.0F, -31.877641290737884F, 8.272542485937368F, 2.984513020910304F, 0.0F, 0.0F));
        g.addOrReplaceChild("ru_tanque_tapaa", CubeListBuilder.create().texOffs(914, 73).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 50.0F), PartPose.offset(50.0F, -27.0F, -12.5F));
        g.addOrReplaceChild("ru_tanque_tapab", CubeListBuilder.create().texOffs(0, 142).addBox(0.0F, -10.0F, 0.0F, 1.0F, 10.0F, 50.0F), PartPose.offset(137.0F, -27.0F, -12.5F));
        g.addOrReplaceChild("ru_faro_0", CubeListBuilder.create().texOffs(24, 334).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(624, 267).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(138.2F, -27.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("ru_faro_1", CubeListBuilder.create().texOffs(48, 334).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(648, 267).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(138.2F, -27.0F, 0.0F, 0.0F, 0.39269908169872414F, -1.5707963267948966F));
    }

    private static void piezas8(PartDefinition g) {
        g.addOrReplaceChild("ru_faro_2", CubeListBuilder.create().texOffs(72, 334).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(672, 267).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(138.2F, -27.0F, 0.0F, 0.0F, 0.7853981633974482F, -1.5707963267948966F));
        g.addOrReplaceChild("ru_faro_3", CubeListBuilder.create().texOffs(96, 334).addBox(-5.0F, -0.7499999999999999F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(696, 267).addBox(-1.0F, -0.7499999999999999F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(138.2F, -27.0F, 0.0F, 0.0F, 1.1780972450961724F, -1.5707963267948966F));
        g.addOrReplaceChild("ru_faro_vidrio", CubeListBuilder.create().texOffs(862, 230).addBox(-7.5F, 0.0F, -7.5F, 15.0F, 1.0F, 15.0F), PartPose.offsetAndRotation(139.22F, -27.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("ru_carbon", CubeListBuilder.create().texOffs(766, 230).addBox(52.0F, -33.0F, -8.0F, 32.0F, 1.0F, 16.0F), PartPose.ZERO);
        g.addOrReplaceChild("ru_boca_0", CubeListBuilder.create().texOffs(0, 300).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(912, 142).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offset(120.0F, 0.0F, 0.0F));
        g.addOrReplaceChild("ru_boca_1", CubeListBuilder.create().texOffs(66, 300).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(0, 202).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(120.0F, 0.0F, 0.0F, 0.0F, 0.5235987755982988F, 0.0F));
        g.addOrReplaceChild("ru_boca_2", CubeListBuilder.create().texOffs(132, 300).addBox(-13.0F, -34.0F, -3.5F, 26.0F, 2.0F, 7.0F).texOffs(66, 202).addBox(-3.5F, -34.0F, -13.0F, 7.0F, 2.0F, 26.0F), PartPose.offsetAndRotation(120.0F, 0.0F, 0.0F, 0.0F, 1.0471975511965976F, 0.0F));
    }

    private static void escalas0(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "fucil_i_0", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "fucil_i_1", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "fucil_i_2", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "fucil_i_3", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "fucil_i_a_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_i_a_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_i_a_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_i_a_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_i_b_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_i_b_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_i_b_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_i_b_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_d_0", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "fucil_d_1", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "fucil_d_2", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "fucil_d_3", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g0, "fucil_d_a_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_d_a_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_d_a_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_d_a_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_d_b_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_d_b_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_d_b_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fucil_d_b_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g0, "fu_tanque_cantoi_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g0, "fu_tanque_cantoi_1", 1.0F, 1.0F, 0.7821723252011554F);
        escalar(g0, "fu_tanque_cantoi_2", 1.0F, 1.0F, 0.7821723252011537F);
        escalar(g0, "fu_tanque_cantoi_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g0, "fu_tanque_cantoi_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "fu_tanque_cantod_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g0, "fu_tanque_cantod_1", 1.0F, 1.0F, 0.7821723252011554F);
        escalar(g0, "fu_tanque_cantod_2", 1.0F, 1.0F, 0.7821723252011537F);
        escalar(g0, "fu_tanque_cantod_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g0, "fu_tanque_cantod_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g0, "fu_tanque_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "fu_tanque_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g0, "fu_faro_0", 0.4315455233774214F, 0.8999999999999999F, 0.4315455233774214F);
        escalar(g0, "fu_faro_1", 0.4315455233774214F, 0.8999999999999999F, 0.4315455233774214F);
        escalar(g0, "fu_faro_2", 0.4315455233774214F, 0.8999999999999999F, 0.4315455233774214F);
        escalar(g0, "fu_faro_3", 0.4315455233774214F, 0.8999999999999999F, 0.4315455233774214F);
        escalar(g0, "fu_faro_vidrio", 0.24444444444444446F, 0.15F, 0.24444444444444446F);
        escalar(g0, "fu_farol3_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "fu_farol3_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "fu_farol3_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "fu_farol3_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "fu_farol3_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "fu_farol17_0", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "fu_farol17_1", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "fu_farol17_2", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "fu_farol17_3", 0.1961570560806461F, 0.6F, 0.1961570560806461F);
        escalar(g0, "fu_farol17_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "fu_boca_0", 0.1857549665940516F, 1.0F, 0.1857549665940516F);
        escalar(g0, "fu_boca_1", 0.1857549665940516F, 1.0F, 0.1857549665940516F);
        escalar(g0, "fu_boca_2", 0.1857549665940516F, 1.0F, 0.1857549665940516F);
        escalar(g1, "caja_humo_0", 1.0F, 0.3333744188028943F, 0.3333744188028943F);
        escalar(g1, "caja_humo_1", 1.0F, 0.3333744188028943F, 0.3333744188028943F);
        escalar(g1, "caja_humo_2", 1.0F, 0.3333744188028943F, 0.3333744188028943F);
        escalar(g1, "caja_humo_3", 1.0F, 0.3333744188028943F, 0.3333744188028943F);
        escalar(g1, "caja_humo_4", 1.0F, 0.3333744188028943F, 0.3333744188028943F);
        escalar(g1, "caja_humo_5", 1.0F, 0.3333744188028943F, 0.3333744188028943F);
        escalar(g1, "caja_humo_6", 1.0F, 0.3333744188028943F, 0.3333744188028943F);
        escalar(g1, "puerta", 0.25F, 0.6F, 0.25F);
        escalar(g1, "caldera_0", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_1", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_2", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_3", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_4", 0.9705882352941176F, 1.0F, 0.7464298406887186F);
        escalar(g1, "caldera_5", 0.9705882352941176F, 1.0F, 0.7464298406887186F);
        escalar(g1, "caldera_6", 0.9705882352941176F, 1.0F, 0.7464298406887186F);
        escalar(g1, "caldera_7", 0.9705882352941176F, 1.0F, 0.7464298406887186F);
        escalar(g1, "caldera_8", 0.9705882352941176F, 1.0F, 0.746429840688719F);
        escalar(g1, "caldera_9", 0.9705882352941176F, 1.0F, 0.746429840688719F);
        escalar(g1, "caldera_10", 0.9705882352941176F, 1.0F, 0.746429840688719F);
        escalar(g1, "caldera_11", 0.9705882352941176F, 1.0F, 0.746429840688719F);
        escalar(g1, "caldera_12", 0.9705882352941176F, 1.0F, 0.7464298406887192F);
        escalar(g1, "caldera_13", 0.9705882352941176F, 1.0F, 0.7464298406887192F);
        escalar(g1, "caldera_14", 0.9705882352941176F, 1.0F, 0.7464298406887192F);
        escalar(g1, "caldera_15", 0.9705882352941176F, 1.0F, 0.7464298406887192F);
        escalar(g1, "caldera_16", 0.9705882352941176F, 1.0F, 0.7464298406887185F);
        escalar(g1, "caldera_17", 0.9705882352941176F, 1.0F, 0.7464298406887185F);
        escalar(g1, "caldera_18", 0.9705882352941176F, 1.0F, 0.7464298406887185F);
        escalar(g1, "caldera_19", 0.9705882352941176F, 1.0F, 0.7464298406887185F);
        escalar(g1, "caldera_20", 0.9705882352941176F, 1.0F, 0.7464298406887204F);
        escalar(g1, "caldera_21", 0.9705882352941176F, 1.0F, 0.7464298406887204F);
        escalar(g1, "caldera_22", 0.9705882352941176F, 1.0F, 0.7464298406887204F);
        escalar(g1, "caldera_23", 0.9705882352941176F, 1.0F, 0.7464298406887204F);
        escalar(g1, "caldera_24", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_25", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_26", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_27", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_28", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_29", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_30", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_31", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_32", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_33", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_34", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_35", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_36", 0.9705882352941176F, 1.0F, 0.7464298406887173F);
        escalar(g1, "caldera_37", 0.9705882352941176F, 1.0F, 0.7464298406887173F);
        escalar(g1, "caldera_38", 0.9705882352941176F, 1.0F, 0.7464298406887173F);
        escalar(g1, "caldera_39", 0.9705882352941176F, 1.0F, 0.7464298406887173F);
        escalar(g1, "caldera_40", 0.9705882352941176F, 1.0F, 0.7464298406887214F);
        escalar(g1, "caldera_41", 0.9705882352941176F, 1.0F, 0.7464298406887214F);
        escalar(g1, "caldera_42", 0.9705882352941176F, 1.0F, 0.7464298406887214F);
        escalar(g1, "caldera_43", 0.9705882352941176F, 1.0F, 0.7464298406887214F);
        escalar(g1, "caldera_44", 0.9705882352941176F, 1.0F, 0.7464298406887182F);
        escalar(g1, "caldera_45", 0.9705882352941176F, 1.0F, 0.7464298406887182F);
        escalar(g1, "caldera_46", 0.9705882352941176F, 1.0F, 0.7464298406887182F);
        escalar(g1, "caldera_47", 0.9705882352941176F, 1.0F, 0.7464298406887182F);
        escalar(g1, "caldera_48", 0.9705882352941176F, 1.0F, 0.7464298406887174F);
        escalar(g1, "caldera_49", 0.9705882352941176F, 1.0F, 0.7464298406887174F);
        escalar(g1, "caldera_50", 0.9705882352941176F, 1.0F, 0.7464298406887174F);
        escalar(g1, "caldera_51", 0.9705882352941176F, 1.0F, 0.7464298406887174F);
        escalar(g1, "caldera_52", 0.9705882352941176F, 1.0F, 0.7464298406887205F);
        escalar(g1, "caldera_53", 0.9705882352941176F, 1.0F, 0.7464298406887205F);
        escalar(g1, "caldera_54", 0.9705882352941176F, 1.0F, 0.7464298406887205F);
        escalar(g1, "caldera_55", 0.9705882352941176F, 1.0F, 0.7464298406887205F);
        escalar(g1, "caldera_56", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_57", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_58", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_59", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_60", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_61", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_62", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_63", 0.9705882352941176F, 1.0F, 0.7464298406887188F);
        escalar(g1, "caldera_64", 0.9705882352941176F, 1.0F, 0.7464298406887182F);
        escalar(g1, "caldera_65", 0.9705882352941176F, 1.0F, 0.7464298406887182F);
        escalar(g1, "caldera_66", 0.9705882352941176F, 1.0F, 0.7464298406887182F);
        escalar(g1, "caldera_67", 0.9705882352941176F, 1.0F, 0.7464298406887182F);
        escalar(g1, "caldera_68", 0.9705882352941176F, 1.0F, 0.7464298406887199F);
        escalar(g1, "caldera_69", 0.9705882352941176F, 1.0F, 0.7464298406887199F);
        escalar(g1, "caldera_70", 0.9705882352941176F, 1.0F, 0.7464298406887199F);
        escalar(g1, "caldera_71", 0.9705882352941176F, 1.0F, 0.7464298406887199F);
        escalar(g1, "caldera_72", 0.9705882352941176F, 1.0F, 0.7464298406887163F);
        escalar(g1, "caldera_73", 0.9705882352941176F, 1.0F, 0.7464298406887163F);
        escalar(g1, "caldera_74", 0.9705882352941176F, 1.0F, 0.7464298406887163F);
        escalar(g1, "caldera_75", 0.9705882352941176F, 1.0F, 0.7464298406887163F);
        escalar(g1, "caldera_76", 0.9705882352941176F, 1.0F, 0.7464298406887192F);
        escalar(g1, "caldera_77", 0.9705882352941176F, 1.0F, 0.7464298406887192F);
        escalar(g1, "caldera_78", 0.9705882352941176F, 1.0F, 0.7464298406887192F);
        escalar(g1, "caldera_79", 0.9705882352941176F, 1.0F, 0.7464298406887192F);
        escalar(g1, "caldera_80", 0.9705882352941176F, 1.0F, 0.7464298406887213F);
        escalar(g1, "caldera_81", 0.9705882352941176F, 1.0F, 0.7464298406887213F);
        escalar(g1, "caldera_82", 0.9705882352941176F, 1.0F, 0.7464298406887213F);
        escalar(g1, "caldera_83", 0.9705882352941176F, 1.0F, 0.7464298406887213F);
        escalar(g1, "caldera_84", 0.9705882352941176F, 1.0F, 0.74642984068872F);
        escalar(g1, "caldera_85", 0.9705882352941176F, 1.0F, 0.74642984068872F);
        escalar(g1, "caldera_86", 0.9705882352941176F, 1.0F, 0.74642984068872F);
        escalar(g1, "caldera_87", 0.9705882352941176F, 1.0F, 0.74642984068872F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g1, "caldera_88", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_89", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_90", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_91", 0.9705882352941176F, 1.0F, 0.7464298406887191F);
        escalar(g1, "caldera_92", 0.9705882352941176F, 1.0F, 0.7464298406887178F);
        escalar(g1, "caldera_93", 0.9705882352941176F, 1.0F, 0.7464298406887178F);
        escalar(g1, "caldera_94", 0.9705882352941176F, 1.0F, 0.7464298406887178F);
        escalar(g1, "caldera_95", 0.9705882352941176F, 1.0F, 0.7464298406887178F);
        escalar(g1, "caldera_96", 0.9705882352941176F, 1.0F, 0.7464298406887205F);
        escalar(g1, "caldera_97", 0.9705882352941176F, 1.0F, 0.7464298406887205F);
        escalar(g1, "caldera_98", 0.9705882352941176F, 1.0F, 0.7464298406887205F);
        escalar(g1, "caldera_99", 0.9705882352941176F, 1.0F, 0.7464298406887205F);
        escalar(g1, "caldera_100", 0.9705882352941176F, 1.0F, 0.7464298406887157F);
        escalar(g1, "caldera_101", 0.9705882352941176F, 1.0F, 0.7464298406887157F);
        escalar(g1, "caldera_102", 0.9705882352941176F, 1.0F, 0.7464298406887157F);
        escalar(g1, "caldera_103", 0.9705882352941176F, 1.0F, 0.7464298406887157F);
        escalar(g1, "caldera_104", 0.9705882352941176F, 1.0F, 0.746429840688719F);
        escalar(g1, "caldera_105", 0.9705882352941176F, 1.0F, 0.746429840688719F);
        escalar(g1, "caldera_106", 0.9705882352941176F, 1.0F, 0.746429840688719F);
        escalar(g1, "caldera_107", 0.9705882352941176F, 1.0F, 0.746429840688719F);
        escalar(g1, "caldera_108", 0.9705882352941176F, 1.0F, 0.7464298406887219F);
        escalar(g1, "caldera_109", 0.9705882352941176F, 1.0F, 0.7464298406887219F);
        escalar(g1, "caldera_110", 0.9705882352941176F, 1.0F, 0.7464298406887219F);
        escalar(g1, "caldera_111", 0.9705882352941176F, 1.0F, 0.7464298406887219F);
        escalar(g1, "chimenea_0", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g1, "chimenea_1", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g1, "chimenea_2", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g1, "chimenea_3", 0.5884711682419382F, 1.0F, 0.5884711682419382F);
        escalar(g1, "chimenea_labio_0", 0.706165401890326F, 1.0F, 0.706165401890326F);
        escalar(g1, "chimenea_labio_1", 0.706165401890326F, 1.0F, 0.706165401890326F);
        escalar(g1, "chimenea_labio_2", 0.706165401890326F, 1.0F, 0.706165401890326F);
        escalar(g1, "chimenea_labio_3", 0.706165401890326F, 1.0F, 0.706165401890326F);
        escalar(g1, "domo_arena_0", 0.46077024047273385F, 1.0F, 0.4548214943191063F);
        escalar(g1, "domo_arena_1", 0.34364607540009723F, 1.0F, 0.43012681166014466F);
        escalar(g1, "domo_arena_2", 0.48625682833037337F, 1.0F, 0.3813302477513303F);
        escalar(g1, "domo_arena_3", 0.505409467592322F, 1.0F, 0.46398545224678134F);
        escalar(g1, "domo_arena_4", 0.37941189948349335F, 1.0F, 0.32130073948296634F);
        escalar(g1, "domo_arena_5", 0.39165079753708665F, 1.0F, 0.2511516803787644F);
        escalar(g1, "domo_arena_6", 0.4608136453534226F, 1.0F, 0.4335210580576002F);
        escalar(g1, "domo_arena_7", 0.34416331054790783F, 1.0F, 0.4101837703998819F);
        escalar(g1, "domo_arena_8", 0.4884723319366909F, 1.0F, 0.36406941192137876F);
        escalar(g1, "domo_arena_9", 0.5094364242389567F, 1.0F, 0.29602079343202514F);
        escalar(g1, "domo_arena_10", 0.3833187179098811F, 1.0F, 0.41225258898601846F);
        escalar(g1, "domo_arena_11", 0.4607618819223695F, 1.0F, 0.4044453758789379F);
        escalar(g1, "domo_arena_12", 0.34354618433385803F, 1.0F, 0.3827102460028414F);
        escalar(g1, "domo_arena_13", 0.48582629087570084F, 1.0F, 0.33976174292983674F);
        escalar(g1, "domo_arena_14", 0.5046214630226983F, 1.0F, 0.2763848165942753F);
        escalar(g1, "domo_arena_15", 0.37864380359094096F, 1.0F, 0.3853235581996346F);
        escalar(g1, "domo_arena_16", 0.4606012208066286F, 1.0F, 0.4381587466055034F);
        escalar(g1, "domo_arena_17", 0.3416241453941968F, 1.0F, 0.4145659083213164F);
        escalar(g1, "domo_arena_18", 0.4775216809266673F, 1.0F, 0.36794658314011675F);
        escalar(g1, "domo_arena_19", 0.48937459469609546F, 1.0F, 0.2991528109148048F);
        escalar(g1, "domo_arena_20", 0.36374776541227893F, 1.0F, 0.4165478779810182F);
        escalar(g1, "domo_arena_21", 0.46035920667680347F, 1.0F, 0.3530070218498284F);
        escalar(g1, "domo_arena_22", 0.5080652409009769F, 1.0F, 0.5008839355514947F);
        escalar(g1, "domo_arena_23", 0.4647441148187919F, 1.0F, 0.44431792900720124F);
        escalar(g1, "domo_arena_24", 0.4654908502098563F, 1.0F, 0.36084634389140013F);
        escalar(g1, "domo_arena_25", 0.34010359578278376F, 1.0F, 0.5011551813291059F);
        escalar(g1, "domo_arena_26", 0.46010998459317864F, 1.0F, 0.43629015529365134F);
        escalar(g1, "domo_arena_27", 0.5035301691676325F, 1.0F, 0.4125247669462767F);
        escalar(g1, "domo_arena_28", 0.4512477850345544F, 1.0F, 0.48741931165568203F);
        escalar(g1, "domo_arena_29", 0.4396722489828956F, 1.0F, 0.3950234360868839F);
        escalar(g1, "domo_arena_30", 0.47111209413857535F, 1.0F, 0.40944809543592564F);
        escalar(g1, "domo_arena_31", 0.4229944164294861F, 1.0F, 0.31660417330670504F);
        escalar(g1, "domo_arena_32", 0.46010998459317864F, 1.0F, 0.43629015530357196F);
        escalar(g1, "domo_arena_33", 0.5035301691676325F, 1.0F, 0.4125247669556503F);
        escalar(g1, "domo_arena_34", 0.4512477850345542F, 1.0F, 0.4874193116667413F);
        escalar(g1, "domo_arena_35", 0.4396722489828956F, 1.0F, 0.3950234360958181F);
        escalar(g1, "domo_arena_36", 0.47111209413857535F, 1.0F, 0.4094480954451148F);
        escalar(g1, "domo_arena_37", 0.4229944164294861F, 1.0F, 0.3166041733135291F);
        escalar(g1, "domo_arena_38", 0.46035920667680347F, 1.0F, 0.35300702184982896F);
        escalar(g1, "domo_arena_39", 0.508065240900977F, 1.0F, 0.5008839355514956F);
        escalar(g1, "domo_arena_40", 0.46474411481879174F, 1.0F, 0.4443179290072004F);
        escalar(g1, "domo_arena_41", 0.46549085020985637F, 1.0F, 0.3608463438913984F);
        escalar(g1, "domo_arena_42", 0.34010359578278376F, 1.0F, 0.5011551813291025F);
        escalar(g1, "domo_arena_43", 0.4606012208066286F, 1.0F, 0.4381587466055034F);
        escalar(g1, "domo_arena_44", 0.3416241453941969F, 1.0F, 0.4145659083213172F);
        escalar(g1, "domo_arena_45", 0.4775216809266673F, 1.0F, 0.36794658314011836F);
        escalar(g1, "domo_arena_46", 0.48937459469609557F, 1.0F, 0.2991528109148064F);
        escalar(g1, "domo_arena_47", 0.36374776541227893F, 1.0F, 0.41654787798102133F);
        escalar(g1, "domo_arena_48", 0.4607618819223695F, 1.0F, 0.4044453758789376F);
        escalar(g1, "domo_arena_49", 0.34354618433385803F, 1.0F, 0.38271024600284115F);
        escalar(g1, "domo_arena_50", 0.48582629087570084F, 1.0F, 0.33976174292983663F);
        escalar(g1, "domo_arena_51", 0.5046214630226983F, 1.0F, 0.27638481659427516F);
        escalar(g1, "domo_arena_52", 0.37864380359094096F, 1.0F, 0.3853235581996344F);
        escalar(g1, "domo_arena_53", 0.4608136453534226F, 1.0F, 0.4335210580576004F);
        escalar(g1, "domo_arena_54", 0.34416331054790783F, 1.0F, 0.41018377039988196F);
        escalar(g1, "domo_arena_55", 0.48847233193669093F, 1.0F, 0.36406941192137876F);
        escalar(g1, "domo_arena_56", 0.5094364242389567F, 1.0F, 0.29602079343202525F);
        escalar(g1, "domo_arena_57", 0.38331871790988115F, 1.0F, 0.4122525889860185F);
        escalar(g1, "domo_arena_58", 0.46077024047273385F, 1.0F, 0.45482149431076585F);
        escalar(g1, "domo_arena_59", 0.3436460754000974F, 1.0F, 0.4301268116522638F);
        escalar(g1, "domo_arena_60", 0.4862568283303731F, 1.0F, 0.3813302477443575F);
        escalar(g1, "domo_arena_61", 0.505409467592322F, 1.0F, 0.4639854522383322F);
        escalar(g1, "domo_arena_62", 0.37941189948349335F, 1.0F, 0.3213007394771728F);
        escalar(g1, "domo_arena_63", 0.39165079753708665F, 1.0F, 0.2511516803744625F);
        escalar(g1, "domo_arena_64", 0.46077024047273385F, 1.0F, 0.4548214943274466F);
        escalar(g1, "domo_arena_65", 0.3436460754000974F, 1.0F, 0.4301268116680254F);
        escalar(g1, "domo_arena_66", 0.4862568283303731F, 1.0F, 0.38133024775830293F);
        escalar(g1, "domo_arena_67", 0.505409467592322F, 1.0F, 0.4639854522552301F);
        escalar(g1, "domo_arena_68", 0.37941189948349335F, 1.0F, 0.3213007394887597F);
        escalar(g1, "domo_arena_69", 0.39165079753708665F, 1.0F, 0.2511516803830662F);
        escalar(g1, "domo_arena_70", 0.4608136453534226F, 1.0F, 0.4335210580576002F);
        escalar(g1, "domo_arena_71", 0.34416331054790783F, 1.0F, 0.41018377039988174F);
        escalar(g1, "domo_arena_72", 0.4884723319366909F, 1.0F, 0.36406941192137854F);
        escalar(g1, "domo_arena_73", 0.5094364242389567F, 1.0F, 0.29602079343202503F);
        escalar(g1, "domo_arena_74", 0.3833187179098811F, 1.0F, 0.41225258898601824F);
        escalar(g1, "domo_arena_75", 0.46076188192236955F, 1.0F, 0.4044453758789379F);
        escalar(g1, "domo_arena_76", 0.34354618433385803F, 1.0F, 0.3827102460028421F);
        escalar(g1, "domo_arena_77", 0.48582629087570084F, 1.0F, 0.3397617429298374F);
        escalar(g1, "domo_arena_78", 0.5046214630226983F, 1.0F, 0.2763848165942758F);
        escalar(g1, "domo_arena_79", 0.3786438035909409F, 1.0F, 0.38532355819963526F);
        escalar(g1, "domo_arena_80", 0.4606012208066286F, 1.0F, 0.4381587466055041F);
        escalar(g1, "domo_arena_81", 0.3416241453941968F, 1.0F, 0.41456590832131635F);
        escalar(g1, "domo_arena_82", 0.4775216809266673F, 1.0F, 0.36794658314011675F);
        escalar(g1, "domo_arena_83", 0.4893745946960955F, 1.0F, 0.2991528109148047F);
        escalar(g1, "domo_arena_84", 0.3637477654122789F, 1.0F, 0.41654787798101817F);
        escalar(g1, "domo_arena_85", 0.46035920667680347F, 1.0F, 0.3530070218498273F);
        escalar(g1, "domo_arena_86", 0.5080652409009769F, 1.0F, 0.5008839355514938F);
        escalar(g1, "domo_arena_87", 0.46474411481879163F, 1.0F, 0.44431792900720035F);
        escalar(g1, "domo_arena_88", 0.46549085020985637F, 1.0F, 0.3608463438913984F);
        escalar(g1, "domo_arena_89", 0.34010359578278365F, 1.0F, 0.5011551813291024F);
        escalar(g1, "domo_arena_90", 0.46010998459317864F, 1.0F, 0.43629015528790877F);
        escalar(g1, "domo_arena_91", 0.5035301691676326F, 1.0F, 0.4125247669408504F);
        escalar(g1, "domo_arena_92", 0.45124778503455415F, 1.0F, 0.4874193116492809F);
        escalar(g1, "domo_arena_93", 0.4396722489828956F, 1.0F, 0.39502343608171353F);
        escalar(g1, "domo_arena_94", 0.47111209413857535F, 1.0F, 0.409448095430608F);
        escalar(g1, "domo_arena_95", 0.4229944164294864F, 1.0F, 0.3166041733027572F);
        escalar(g1, "domo_arena_96", 0.46010998459317864F, 1.0F, 0.4362901553093149F);
        escalar(g1, "domo_arena_97", 0.5035301691676325F, 1.0F, 0.4125247669610771F);
        escalar(g1, "domo_arena_98", 0.4512477850345542F, 1.0F, 0.48741931167314306F);
        escalar(g1, "domo_arena_99", 0.4396722489828956F, 1.0F, 0.39502343610098967F);
        escalar(g1, "domo_arena_100", 0.47111209413857535F, 1.0F, 0.4094480954504342F);
        escalar(g1, "domo_arena_101", 0.4229944164294861F, 1.0F, 0.3166041733174787F);
        escalar(g1, "domo_arena_102", 0.46035920667680347F, 1.0F, 0.3530070218498283F);
        escalar(g1, "domo_arena_103", 0.5080652409009769F, 1.0F, 0.5008839355514946F);
        escalar(g1, "domo_arena_104", 0.46474411481879174F, 1.0F, 0.44431792900720035F);
        escalar(g1, "domo_arena_105", 0.46549085020985637F, 1.0F, 0.36084634389139836F);
        escalar(g1, "domo_arena_106", 0.34010359578278376F, 1.0F, 0.5011551813291024F);
        escalar(g1, "domo_arena_107", 0.4606012208066286F, 1.0F, 0.438158746605505F);
        escalar(g1, "domo_arena_108", 0.3416241453941968F, 1.0F, 0.414565908321318F);
        escalar(g1, "domo_arena_109", 0.47752168092666736F, 1.0F, 0.3679465831401184F);
        escalar(g1, "domo_arena_110", 0.4893745946960955F, 1.0F, 0.2991528109148064F);
        escalar(g1, "domo_arena_111", 0.36374776541227893F, 1.0F, 0.41654787798102144F);
        escalar(g1, "domo_arena_112", 0.4607618819223694F, 1.0F, 0.4044453758789375F);
        escalar(g1, "domo_arena_113", 0.34354618433385803F, 1.0F, 0.3827102460028413F);
        escalar(g1, "domo_arena_114", 0.48582629087570134F, 1.0F, 0.3397617429298361F);
        escalar(g1, "domo_arena_115", 0.5046214630226976F, 1.0F, 0.2763848165942746F);
        escalar(g1, "domo_arena_116", 0.37864380359094096F, 1.0F, 0.3853235581996345F);
        escalar(g1, "domo_arena_117", 0.4608136453534226F, 1.0F, 0.43352105805759955F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g1, "domo_arena_118", 0.34416331054790783F, 1.0F, 0.4101837703998812F);
        escalar(g1, "domo_arena_119", 0.4884723319366914F, 1.0F, 0.3640694119213783F);
        escalar(g1, "domo_arena_120", 0.5094364242389562F, 1.0F, 0.296020793432025F);
        escalar(g1, "domo_arena_121", 0.38331871790988115F, 1.0F, 0.4122525889860177F);
        escalar(g1, "domo_arena_122", 0.46077024047273385F, 1.0F, 0.45482149430555757F);
        escalar(g1, "domo_arena_123", 0.34364607540009723F, 1.0F, 0.43012681164734246F);
        escalar(g1, "domo_arena_124", 0.4862568283303734F, 1.0F, 0.38133024774000335F);
        escalar(g1, "domo_arena_125", 0.505409467592322F, 1.0F, 0.4639854522330562F);
        escalar(g1, "domo_arena_126", 0.37941189948349335F, 1.0F, 0.321300739473555F);
        escalar(g1, "domo_arena_127", 0.39165079753708665F, 1.0F, 0.25115168037177615F);
        escalar(g1, "domo_vapor_0", 0.3878143070346687F, 1.0F, 0.4548214943191063F);
        escalar(g1, "domo_vapor_1", 0.380400485532394F, 1.0F, 0.43012681166014466F);
        escalar(g1, "domo_vapor_2", 0.348297701162735F, 1.0F, 0.3813302477513303F);
        escalar(g1, "domo_vapor_3", 0.349434171675513F, 1.0F, 0.46398545224678134F);
        escalar(g1, "domo_vapor_4", 0.38358047808659324F, 1.0F, 0.32130073948296634F);
        escalar(g1, "domo_vapor_5", 0.3919077491277164F, 1.0F, 0.25115168037876423F);
        escalar(g1, "domo_vapor_6", 0.38784326902554445F, 1.0F, 0.4335210580576002F);
        escalar(g1, "domo_vapor_7", 0.38086686243267803F, 1.0F, 0.41018377039988196F);
        escalar(g1, "domo_vapor_8", 0.3496704512696976F, 1.0F, 0.364069411921379F);
        escalar(g1, "domo_vapor_9", 0.3520210450878875F, 1.0F, 0.29602079343202536F);
        escalar(g1, "domo_vapor_10", 0.3874441444294123F, 1.0F, 0.41225258898601863F);
        escalar(g1, "domo_vapor_11", 0.3878087299972708F, 1.0F, 0.4044453758789377F);
        escalar(g1, "domo_vapor_12", 0.3803104679993015F, 1.0F, 0.38271024600284154F);
        escalar(g1, "domo_vapor_13", 0.3480312724923176F, 1.0F, 0.3397617429298364F);
        escalar(g1, "domo_vapor_14", 0.34892855337806217F, 1.0F, 0.276384816594275F);
        escalar(g1, "domo_vapor_15", 0.3828212155871064F, 1.0F, 0.3853235581996344F);
        escalar(g1, "domo_vapor_16", 0.3877015343299292F, 1.0F, 0.4381587466055037F);
        escalar(g1, "domo_vapor_17", 0.3785787793513807F, 1.0F, 0.4145659083213166F);
        escalar(g1, "domo_vapor_18", 0.342894842466686F, 1.0F, 0.3679465831401176F);
        escalar(g1, "domo_vapor_19", 0.5087262142664825F, 1.0F, 0.2991528109148054F);
        escalar(g1, "domo_vapor_20", 0.368099937854158F, 1.0F, 0.4165478779810194F);
        escalar(g1, "domo_vapor_21", 0.38754007277073393F, 1.0F, 0.3530070218498281F);
        escalar(g1, "domo_vapor_22", 0.3759567968770889F, 1.0F, 0.5008839355514945F);
        escalar(g1, "domo_vapor_23", 0.5025244215246003F, 1.0F, 0.44431792900720046F);
        escalar(g1, "domo_vapor_24", 0.48582307012298726F, 1.0F, 0.3608463438913989F);
        escalar(g1, "domo_vapor_25", 0.3447643198761812F, 1.0F, 0.5011551813291035F);
        escalar(g1, "domo_vapor_26", 0.3873738191576822F, 1.0F, 0.4362901552936512F);
        escalar(g1, "domo_vapor_27", 0.37324054323786066F, 1.0F, 0.41252476694627643F);
        escalar(g1, "domo_vapor_28", 0.49008953290055396F, 1.0F, 0.48741931165568214F);
        escalar(g1, "domo_vapor_29", 0.4611671945254202F, 1.0F, 0.3950234360868842F);
        escalar(g1, "domo_vapor_30", 0.4786853859880684F, 1.0F, 0.4094480954359261F);
        escalar(g1, "domo_vapor_31", 0.42341941406759914F, 1.0F, 0.31660417330670537F);
        escalar(g1, "domo_vapor_32", 0.3873738191576822F, 1.0F, 0.4362901553035723F);
        escalar(g1, "domo_vapor_33", 0.37324054323786066F, 1.0F, 0.4125247669556509F);
        escalar(g1, "domo_vapor_34", 0.490089532900554F, 1.0F, 0.4874193116667411F);
        escalar(g1, "domo_vapor_35", 0.46116719452542015F, 1.0F, 0.39502343609581775F);
        escalar(g1, "domo_vapor_36", 0.4786853859880684F, 1.0F, 0.4094480954451146F);
        escalar(g1, "domo_vapor_37", 0.4234194140675991F, 1.0F, 0.316604173313528F);
        escalar(g1, "domo_vapor_38", 0.38754007277073393F, 1.0F, 0.35300702184982863F);
        escalar(g1, "domo_vapor_39", 0.3759567968770888F, 1.0F, 0.500883935551495F);
        escalar(g1, "domo_vapor_40", 0.5025244215246003F, 1.0F, 0.4443179290072007F);
        escalar(g1, "domo_vapor_41", 0.4858230701229872F, 1.0F, 0.360846343891399F);
        escalar(g1, "domo_vapor_42", 0.34476431987618117F, 1.0F, 0.5011551813291042F);
        escalar(g1, "domo_vapor_43", 0.3877015343299292F, 1.0F, 0.4381587466055042F);
        escalar(g1, "domo_vapor_44", 0.3785787793513807F, 1.0F, 0.4145659083213172F);
        escalar(g1, "domo_vapor_45", 0.34289484246668606F, 1.0F, 0.3679465831401182F);
        escalar(g1, "domo_vapor_46", 0.5087262142664826F, 1.0F, 0.2991528109148058F);
        escalar(g1, "domo_vapor_47", 0.36809993785415784F, 1.0F, 0.41654787798101955F);
        escalar(g1, "domo_vapor_48", 0.3878087299972708F, 1.0F, 0.40444537587893714F);
        escalar(g1, "domo_vapor_49", 0.38031046799930146F, 1.0F, 0.38271024600284115F);
        escalar(g1, "domo_vapor_50", 0.34803127249231763F, 1.0F, 0.3397617429298363F);
        escalar(g1, "domo_vapor_51", 0.3489285533780622F, 1.0F, 0.27638481659427516F);
        escalar(g1, "domo_vapor_52", 0.3828212155871064F, 1.0F, 0.3853235581996345F);
        escalar(g1, "domo_vapor_53", 0.38784326902554445F, 1.0F, 0.4335210580576004F);
        escalar(g1, "domo_vapor_54", 0.38086686243267803F, 1.0F, 0.4101837703998821F);
        escalar(g1, "domo_vapor_55", 0.3496704512696976F, 1.0F, 0.364069411921379F);
        escalar(g1, "domo_vapor_56", 0.3520210450878874F, 1.0F, 0.2960207934320253F);
        escalar(g1, "domo_vapor_57", 0.3874441444294125F, 1.0F, 0.4122525889860187F);
        escalar(g1, "domo_vapor_58", 0.3878143070346687F, 1.0F, 0.45482149431076585F);
        escalar(g1, "domo_vapor_59", 0.3804004855323941F, 1.0F, 0.4301268116522637F);
        escalar(g1, "domo_vapor_60", 0.34829770116273506F, 1.0F, 0.3813302477443575F);
        escalar(g1, "domo_vapor_61", 0.34943417167551294F, 1.0F, 0.46398545223833226F);
        escalar(g1, "domo_vapor_62", 0.3835804780865933F, 1.0F, 0.3213007394771728F);
        escalar(g1, "domo_vapor_63", 0.39190774912771636F, 1.0F, 0.25115168037446234F);
        escalar(g1, "domo_vapor_64", 0.3878143070346687F, 1.0F, 0.4548214943274466F);
        escalar(g1, "domo_vapor_65", 0.3804004855323941F, 1.0F, 0.4301268116680254F);
        escalar(g1, "domo_vapor_66", 0.34829770116273506F, 1.0F, 0.38133024775830293F);
        escalar(g1, "domo_vapor_67", 0.349434171675513F, 1.0F, 0.46398545225523014F);
        escalar(g1, "domo_vapor_68", 0.38358047808659324F, 1.0F, 0.3213007394887597F);
        escalar(g1, "domo_vapor_69", 0.3919077491277163F, 1.0F, 0.251151680383066F);
        escalar(g1, "domo_vapor_70", 0.38784326902554445F, 1.0F, 0.4335210580576001F);
        escalar(g1, "domo_vapor_71", 0.38086686243267803F, 1.0F, 0.41018377039988174F);
        escalar(g1, "domo_vapor_72", 0.3496704512696976F, 1.0F, 0.36406941192137876F);
        escalar(g1, "domo_vapor_73", 0.35202104508788756F, 1.0F, 0.29602079343202514F);
        escalar(g1, "domo_vapor_74", 0.3874441444294123F, 1.0F, 0.41225258898601824F);
        escalar(g1, "domo_vapor_75", 0.3878087299972708F, 1.0F, 0.4044453758789386F);
        escalar(g1, "domo_vapor_76", 0.3803104679993015F, 1.0F, 0.38271024600284254F);
        escalar(g1, "domo_vapor_77", 0.3480312724923175F, 1.0F, 0.3397617429298372F);
        escalar(g1, "domo_vapor_78", 0.3489285533780622F, 1.0F, 0.2763848165942756F);
        escalar(g1, "domo_vapor_79", 0.38282121558710624F, 1.0F, 0.38532355819963526F);
        escalar(g1, "domo_vapor_80", 0.3877015343299292F, 1.0F, 0.43815874660550314F);
        escalar(g1, "domo_vapor_81", 0.3785787793513807F, 1.0F, 0.41456590832131596F);
        escalar(g1, "domo_vapor_82", 0.342894842466686F, 1.0F, 0.36794658314011736F);
        escalar(g1, "domo_vapor_83", 0.5087262142664826F, 1.0F, 0.29915281091480533F);
        escalar(g1, "domo_vapor_84", 0.368099937854158F, 1.0F, 0.416547877981019F);
        escalar(g1, "domo_vapor_85", 0.38754007277073393F, 1.0F, 0.35300702184982774F);
        escalar(g1, "domo_vapor_86", 0.3759567968770889F, 1.0F, 0.5008839355514939F);
        escalar(g1, "domo_vapor_87", 0.5025244215246004F, 1.0F, 0.44431792900719974F);
        escalar(g1, "domo_vapor_88", 0.48582307012298726F, 1.0F, 0.3608463438913984F);
        escalar(g1, "domo_vapor_89", 0.34476431987618134F, 1.0F, 0.5011551813291033F);
        escalar(g1, "domo_vapor_90", 0.3873738191576822F, 1.0F, 0.43629015528790877F);
        escalar(g1, "domo_vapor_91", 0.37324054323786066F, 1.0F, 0.4125247669408505F);
        escalar(g1, "domo_vapor_92", 0.490089532900554F, 1.0F, 0.48741931164928126F);
        escalar(g1, "domo_vapor_93", 0.4611671945254202F, 1.0F, 0.39502343608171336F);
        escalar(g1, "domo_vapor_94", 0.47868538598806853F, 1.0F, 0.40944809543060745F);
        escalar(g1, "domo_vapor_95", 0.42341941406759914F, 1.0F, 0.3166041733027561F);
        escalar(g1, "domo_vapor_96", 0.3873738191576822F, 1.0F, 0.43629015530931525F);
        escalar(g1, "domo_vapor_97", 0.37324054323786066F, 1.0F, 0.4125247669610773F);
        escalar(g1, "domo_vapor_98", 0.490089532900554F, 1.0F, 0.4874193116731425F);
        escalar(g1, "domo_vapor_99", 0.46116719452542015F, 1.0F, 0.39502343610098894F);
        escalar(g1, "domo_vapor_100", 0.4786853859880684F, 1.0F, 0.40944809545043354F);
        escalar(g1, "domo_vapor_101", 0.4234194140675991F, 1.0F, 0.3166041733174776F);
        escalar(g1, "domo_vapor_102", 0.38754007277073393F, 1.0F, 0.353007021849828F);
        escalar(g1, "domo_vapor_103", 0.3759567968770888F, 1.0F, 0.5008839355514945F);
        escalar(g1, "domo_vapor_104", 0.5025244215246003F, 1.0F, 0.4443179290072005F);
        escalar(g1, "domo_vapor_105", 0.4858230701229872F, 1.0F, 0.360846343891399F);
        escalar(g1, "domo_vapor_106", 0.34476431987618117F, 1.0F, 0.5011551813291037F);
        escalar(g1, "domo_vapor_107", 0.3877015343299292F, 1.0F, 0.4381587466055049F);
        escalar(g1, "domo_vapor_108", 0.3785787793513807F, 1.0F, 0.41456590832131773F);
        escalar(g1, "domo_vapor_109", 0.342894842466686F, 1.0F, 0.3679465831401185F);
        escalar(g1, "domo_vapor_110", 0.5087262142664825F, 1.0F, 0.29915281091480617F);
        escalar(g1, "domo_vapor_111", 0.36809993785415784F, 1.0F, 0.41654787798102033F);
        escalar(g1, "domo_vapor_112", 0.3878087299972708F, 1.0F, 0.4044453758789374F);
        escalar(g1, "domo_vapor_113", 0.3803104679993015F, 1.0F, 0.3827102460028413F);
        escalar(g1, "domo_vapor_114", 0.3480312724923176F, 1.0F, 0.3397617429298362F);
        escalar(g1, "domo_vapor_115", 0.3489285533780622F, 1.0F, 0.2763848165942749F);
        escalar(g1, "domo_vapor_116", 0.3828212155871063F, 1.0F, 0.38532355819963426F);
        escalar(g1, "domo_vapor_117", 0.38784326902554445F, 1.0F, 0.43352105805759955F);
        escalar(g1, "domo_vapor_118", 0.38086686243267803F, 1.0F, 0.4101837703998813F);
        escalar(g1, "domo_vapor_119", 0.34967045126969754F, 1.0F, 0.3640694119213783F);
        escalar(g1, "domo_vapor_120", 0.35202104508788756F, 1.0F, 0.2960207934320248F);
        escalar(g1, "domo_vapor_121", 0.3874441444294123F, 1.0F, 0.4122525889860179F);
        escalar(g1, "domo_vapor_122", 0.3878143070346687F, 1.0F, 0.45482149430555757F);
        escalar(g1, "domo_vapor_123", 0.3804004855323941F, 1.0F, 0.43012681164734246F);
        escalar(g1, "domo_vapor_124", 0.348297701162735F, 1.0F, 0.38133024774000335F);
        escalar(g1, "domo_vapor_125", 0.3494341716755131F, 1.0F, 0.4639854522330563F);
        escalar(g1, "domo_vapor_126", 0.38358047808659324F, 1.0F, 0.32130073947355503F);
        escalar(g1, "domo_vapor_127", 0.3919077491277164F, 1.0F, 0.251151680371776F);
        escalar(g1, "silbato_0", 0.12318393766817158F, 1.0F, 0.12318393766817158F);
        escalar(g1, "silbato_1", 0.12318393766817158F, 1.0F, 0.12318393766817158F);
        escalar(g1, "cabina_techo_0", 1.000952380952381F, 1.0F, 0.7308905619357534F);
        escalar(g1, "cabina_techo_1", 1.000952380952381F, 1.0F, 0.7308905619357519F);
        escalar(g1, "cabina_techo_2", 1.000952380952381F, 1.0F, 0.7308905619357532F);
        escalar(g1, "cabina_techo_3", 1.000952380952381F, 1.0F, 0.7308905619357526F);
        escalar(g1, "cabina_techo_4", 1.000952380952381F, 1.0F, 0.7308905619357526F);
        escalar(g1, "cabina_techo_5", 1.000952380952381F, 1.0F, 0.7308905619357532F);
        escalar(g1, "cabina_techo_6", 1.000952380952381F, 1.0F, 0.7308905619357522F);
        escalar(g1, "cabina_techo_7", 1.000952380952381F, 1.0F, 0.7308905619357531F);
        escalar(g1, "cabina_techo_8", 1.000952380952381F, 1.0F, 0.7308905619357532F);
        escalar(g1, "cabina_techo_9", 1.000952380952381F, 1.0F, 0.7308905619357526F);
    }

    private static void escalas3(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g1, "cabina_techo_10", 1.000952380952381F, 1.0F, 0.7308905619357525F);
        escalar(g1, "cabina_techo_11", 1.000952380952381F, 1.0F, 0.7308905619357534F);
        escalar(g1, "numeroi", 0.5F, 0.5F, 1.0F);
        escalar(g1, "numerod", 0.5F, 0.5F, 1.0F);
        escalar(g2, "rucil_i_0", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g2, "rucil_i_1", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g2, "rucil_i_2", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g2, "rucil_i_3", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g2, "rucil_i_a_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_i_a_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_i_a_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_i_a_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_i_b_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_i_b_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_i_b_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_i_b_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_d_0", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g2, "rucil_d_1", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g2, "rucil_d_2", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g2, "rucil_d_3", 1.0F, 0.706165401890326F, 0.706165401890326F);
        escalar(g2, "rucil_d_a_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_d_a_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_d_a_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_d_a_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_d_b_0", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_d_b_1", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_d_b_2", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "rucil_d_b_3", 1.0F, 0.8042439299306489F, 0.8042439299306489F);
        escalar(g2, "ru_tanque_cantoi_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g2, "ru_tanque_cantoi_1", 1.0F, 1.0F, 0.7821723252011554F);
        escalar(g2, "ru_tanque_cantoi_2", 1.0F, 1.0F, 0.7821723252011537F);
        escalar(g2, "ru_tanque_cantoi_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g2, "ru_tanque_cantoi_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g2, "ru_tanque_cantod_0", 1.0F, 1.0F, 0.782172325201154F);
        escalar(g2, "ru_tanque_cantod_1", 1.0F, 1.0F, 0.7821723252011554F);
        escalar(g2, "ru_tanque_cantod_2", 1.0F, 1.0F, 0.7821723252011537F);
        escalar(g2, "ru_tanque_cantod_3", 1.0F, 1.0F, 0.7821723252011547F);
        escalar(g2, "ru_tanque_cantod_4", 1.0F, 1.0F, 0.7821723252011539F);
        escalar(g2, "ru_tanque_tapaa", 1.0F, 0.5F, 0.5F);
        escalar(g2, "ru_tanque_tapab", 1.0F, 0.5F, 0.5F);
        escalar(g2, "ru_faro_0", 0.353082700945163F, 0.8F, 0.353082700945163F);
        escalar(g2, "ru_faro_1", 0.353082700945163F, 0.8F, 0.353082700945163F);
        escalar(g2, "ru_faro_2", 0.353082700945163F, 0.8F, 0.353082700945163F);
        escalar(g2, "ru_faro_3", 0.353082700945163F, 0.8F, 0.353082700945163F);
        escalar(g2, "ru_faro_vidrio", 0.24000000000000002F, 0.15F, 0.24000000000000002F);
        escalar(g2, "ru_boca_0", 0.1857549665940516F, 1.0F, 0.1857549665940516F);
        escalar(g2, "ru_boca_1", 0.1857549665940516F, 1.0F, 0.1857549665940516F);
        escalar(g2, "ru_boca_2", 0.1857549665940516F, 1.0F, 0.1857549665940516F);
    }
}
