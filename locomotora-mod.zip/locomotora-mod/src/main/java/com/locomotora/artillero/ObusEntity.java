package com.locomotora.artillero;

import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModItems;
import com.locomotora.registro.ModSonidos;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * El obús que tiran las torretas del tren artillero: vuela casi derecho (cae un poco, como cualquier cosa que se tira)
 * dejando una estela de humo y explota al chocar con algo. La explosión lastima a los que estén cerca (menos detrás de
 * una pared) y los empuja, pero no rompe bloques. A su propio tren, a los que van en él y, si el tren es de alguien, a su
 * dueño y a sus mascotas, no les hace nada.
 */
public class ObusEntity extends ThrowableItemProjectile {
    /** Si en 6 segundos no chocó con nada, se deshace. */
    private static final int VIDA = 120;

    private float danoImpacto = 6.0F;
    private float radio = 2.0F;
    private float danoExplosion = 6.0F;
    /** Contra jugadores (los tiros del tren hostil se ajustan a la dificultad). */
    private float contraJugadores = 1.0F;
    /** La locomotora del tren que lo tiró y el dueño de ese tren (si tiene). */
    @Nullable
    private UUID tren;
    @Nullable
    private UUID dueno;
    /** A quién se le cuenta el golpe (la locomotora hostil, o el dueño del tren). */
    @Nullable
    private Entity causante;

    public ObusEntity(EntityType<? extends ObusEntity> tipo, Level level) {
        super(tipo, level);
    }

    /** Un obús recién salido de la boca de un caño. */
    public static ObusEntity tirar(ServerLevel nivel, Torreta.Tiro tiro, Vec3 boca, Vec3 direccion, Entity tirador,
                                   @Nullable UUID tren, @Nullable UUID dueno, @Nullable Entity causante,
                                   float contraJugadores) {
        ObusEntity o = new ObusEntity(ModEntidades.OBUS.get(), nivel);
        o.setPos(boca.x, boca.y, boca.z);
        o.setOwner(tirador);
        o.danoImpacto = tiro.danoImpacto();
        o.radio = tiro.radio();
        o.danoExplosion = tiro.danoExplosion();
        o.contraJugadores = contraJugadores;
        o.tren = tren;
        o.dueno = dueno;
        o.causante = causante;
        o.shoot(direccion.x, direccion.y, direccion.z, tiro.velocidad(), tiro.imprecision());
        nivel.addFreshEntity(o);
        return o;
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.OBUS.get();
    }

    @Override
    public void tick() {
        super.tick();
        if (this.isRemoved()) {
            return;
        }
        if (this.level().isClientSide()) {
            // la estela de humo
            this.level().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY(), this.getZ(), 0.0, 0.01, 0.0);
            if (this.tickCount % 2 == 0) {
                this.level().addParticle(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
            }
        } else if (this.tickCount > VIDA) {
            this.discard();
        }
    }

    /** Pasa de largo por su propio tren, por los que van en él y por el dueño del tren. */
    @Override
    protected boolean canHitEntity(Entity otra) {
        return super.canHitEntity(otra) && !TrenArtillero.protegido(otra, this.tren, this.dueno);
    }

    @Override
    protected void onHit(HitResult resultado) {
        super.onHit(resultado);
        if (!this.level().isClientSide() && !this.isRemoved()) {
            Entity golpeado = resultado instanceof EntityHitResult e ? e.getEntity() : null;
            explotar((ServerLevel) this.level(), resultado.getLocation(), golpeado);
            this.discard();
        }
    }

    private void explotar(ServerLevel nivel, Vec3 punto, @Nullable Entity golpeado) {
        boolean grande = this.radio >= 2.0F;
        nivel.sendParticles(grande ? ParticleTypes.EXPLOSION_EMITTER : ParticleTypes.EXPLOSION, punto.x, punto.y, punto.z,
                1, 0.0, 0.0, 0.0, 0.0);
        nivel.sendParticles(ParticleTypes.LARGE_SMOKE, punto.x, punto.y, punto.z, grande ? 14 : 5, 0.4, 0.3, 0.4, 0.03);
        nivel.playSound(null, punto.x, punto.y, punto.z, ModSonidos.OBUS.get(), SoundSource.HOSTILE,
                grande ? 3.0F : 1.2F, (grande ? 0.9F : 1.4F) + this.random.nextFloat() * 0.2F);

        if (golpeado instanceof PartEntity<?> parte) {
            golpeado = parte.getParent();
        }
        // la explosión se mide desde un poco antes del choque (si no, la pared con la que chocó la tapa)
        Vec3 v = this.getDeltaMovement();
        Vec3 centro = v.lengthSqr() > 1.0E-6 ? punto.subtract(v.normalize().scale(0.3)) : punto;
        DamageSource fuente = TrenArtillero.fuenteObus(nivel, this, this.causante != null ? this.causante : this.getOwner());
        double r = this.radio;
        AABB zona = new AABB(centro.x - r - 2.0, centro.y - r - 2.0, centro.z - r - 2.0,
                centro.x + r + 2.0, centro.y + r + 2.0, centro.z + r + 2.0);
        for (Entity e : nivel.getEntities(this, zona, e -> e.isAlive() && !(e instanceof PartEntity<?>))) {
            boolean blindado = TrenArtillero.esBlindado(e);
            if (!(e instanceof LivingEntity) && !blindado) {
                continue;
            }
            if (e instanceof Player p && (p.isSpectator() || p.isCreative())) {
                continue;
            }
            if (TrenArtillero.protegido(e, this.tren, this.dueno)) {
                continue;
            }
            Vec3 c = e.getBoundingBox().getCenter();
            // a un vehículo blindado (largo) se lo mide desde cerca de sus puntas
            double d = Math.max(0.0, c.distanceTo(centro) - (blindado ? 1.5 : e.getBbWidth() / 2.0));
            double cerca = 1.0 - d / r;
            if (e != golpeado && cerca <= 0.0) {
                continue;
            }
            float dano = (float) (this.danoExplosion * Math.max(0.0, cerca));
            if (e == golpeado) {
                dano += this.danoImpacto;
            } else if (nivel.clip(new ClipContext(centro, c, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this))
                    .getType() != HitResult.Type.MISS) {
                dano *= 0.35F; // detrás de una pared
            }
            if (e instanceof Player) {
                dano *= this.contraJugadores;
            }
            if (dano <= 0.0F) {
                continue;
            }
            e.hurt(fuente, dano);
            if (e instanceof LivingEntity && !blindado) {
                // sale despedido (un poco para arriba)
                Vec3 afuera = c.subtract(centro);
                double largo = afuera.length();
                double k = 0.55 * Math.max(0.2, cerca);
                if (largo > 1.0E-4) {
                    e.push(afuera.x / largo * k, 0.18 + 0.2 * Math.max(0.0, cerca), afuera.z / largo * k);
                    e.hurtMarked = true;
                }
            }
        }
    }

    // ================================================================= guardado

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("DanoImpacto", this.danoImpacto);
        tag.putFloat("Radio", this.radio);
        tag.putFloat("DanoExplosion", this.danoExplosion);
        tag.putFloat("ContraJugadores", this.contraJugadores);
        if (this.tren != null) {
            tag.putUUID("Tren", this.tren);
        }
        if (this.dueno != null) {
            tag.putUUID("Dueno", this.dueno);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.danoImpacto = tag.getFloat("DanoImpacto");
        this.radio = Math.max(0.5F, tag.getFloat("Radio"));
        this.danoExplosion = tag.getFloat("DanoExplosion");
        this.contraJugadores = tag.contains("ContraJugadores") ? tag.getFloat("ContraJugadores") : 1.0F;
        this.tren = tag.hasUUID("Tren") ? tag.getUUID("Tren") : null;
        this.dueno = tag.hasUUID("Dueno") ? tag.getUUID("Dueno") : null;
    }
}
