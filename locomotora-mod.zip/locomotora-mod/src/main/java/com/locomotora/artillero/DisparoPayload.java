package com.locomotora.artillero;

import com.locomotora.LocomotoraMod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/**
 * El clic izquierdo de un tirador del tren artillero (del cliente al servidor): "¡fuego!". No lleva datos: el servidor
 * sabe en qué va sentado el jugador y adónde mira.
 */
public record DisparoPayload() implements CustomPacketPayload {
    public static final DisparoPayload FUEGO = new DisparoPayload();
    public static final CustomPacketPayload.Type<DisparoPayload> TIPO =
            new CustomPacketPayload.Type<>(LocomotoraMod.id("disparo"));
    public static final StreamCodec<ByteBuf, DisparoPayload> CODEC = StreamCodec.unit(FUEGO);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TIPO;
    }
}
