package com.locomotora.artillero;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import com.locomotora.entidad.LocomotoraEntity;
import com.locomotora.entidad.TipoLocomotora;
import com.locomotora.entidad.VagonEntity;
import com.locomotora.registro.ModSonidos;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * La locomotora blindada del tren artillero, con su torreta. Tiene 100 de vida (el blindaje), que comparte con sus
 * vagones: un golpe a cualquiera de ellos le baja la vida a la locomotora.
 * <ul>
 *   <li><b>Hostil</b> (como aparece entre los trenes que pasan solos): a los jugadores que ve (hasta 48 bloques, sin
 *       paredes en el medio) los persigue por la vía, frena a tiro y les dispara con todas sus torretas. No se rompe y
 *       no deja subirse ni abrir sus vagones (no tiene barra de vida: su blindaje se ve en el estado del maquinista).</li>
 *   <li><b>Derrotado</b> (vida en 0): pasa a ser de quien lo derrotó y queda quieto, con la vida entera y los cofres de
 *       sus vagones abiertos.</li>
 *   <li><b>De alguien</b>: se maneja como cualquier locomotora. El maquinista apunta las torretas mirando y tira con
 *       clic izquierdo (la de la locomotora y las de los vagones que no llevan tirador). Sin maquinista, sus torretas
 *       disparan solas a todo lo que ataque a su dueño (o a los que van en el tren) o lo tenga de blanco: monstruos,
 *       jugadores que le peguen, otros trenes artilleros. Lo que lo lastima (menos los jugadores, que lo rompen para
 *       llevárselo) le baja el blindaje, que se repara solo de a poco.</li>
 * </ul>
 */
public class ArtilleroEntity extends LocomotoraEntity {
    public static final float VIDA_MAXIMA = 100.0F;
    /** Hasta dónde ve a los jugadores (bloques). Agachados se los ve de más cerca, e invisibles casi nada. */
    private static final double VISTA = 48.0;
    private static final double VISTA_INVISIBLE = 6.0;
    /** A quien le pegó se lo busca más lejos. */
    private static final double VISTA_REVANCHA = 64.0;
    /** Hasta dónde defiende a su dueño (bloques). */
    private static final double DEFENSA = 40.0;
    /** Ticks que sigue apuntando al blanco que dejó de ver. */
    private static final int MEMORIA = 100;
    /** Lo más que le saca un solo golpe (es un blindaje: ni un bloque de TNT lo deshace de una). */
    private static final float GOLPE_MAXIMO = 25.0F;
    /** Medio largo del casco (bloques) y largo de cada tramo del casco. */
    private static final double PASO_PARTES = 1.4;

    private static final EntityDataAccessor<Boolean> DATA_HOSTIL =
            SynchedEntityData.defineId(ArtilleroEntity.class, EntityDataSerializers.BOOLEAN);
    /** El blanco de las torretas (número de entidad; -1 = ninguno): el cliente lo usa para girarlas. */
    private static final EntityDataAccessor<Integer> DATA_BLANCO =
            SynchedEntityData.defineId(ArtilleroEntity.class, EntityDataSerializers.INT);
    /** Quién apunta la torreta mirando (el maquinista, si el tren es de alguien; -1 = nadie): el cliente la gira igual. */
    private static final EntityDataAccessor<Integer> DATA_TIRADOR =
            SynchedEntityData.defineId(ArtilleroEntity.class, EntityDataSerializers.INT);

    private final Torreta torreta = new Torreta(Torreta.LOCOMOTORA);
    private final ParteBlindada[] partes;

    // ------------------------------------------------- servidor
    private float vida = VIDA_MAXIMA;
    @Nullable
    private UUID dueno;
    /** Ticks desde que vio a su blanco por última vez. */
    private int sinVer;
    /** Cuándo peleó o lo golpearon por última vez (tiempo del mundo). */
    private long ultimoCombate = Long.MIN_VALUE / 2;
    private long ultimoGolpe = Long.MIN_VALUE / 2;
    /** El último jugador que lo lastimó y cuándo (para saber quién lo derrotó y para la revancha). */
    @Nullable
    private UUID ultimoJugador;
    private long ultimoJugadorCuando = Long.MIN_VALUE / 2;
    /** La marcha con que anda cuando no pelea (0 = espera quieto). */
    private int marchaPatrulla;

    public ArtilleroEntity(EntityType<? extends LocomotoraEntity> tipoEntidad, Level level, TipoLocomotora tipo) {
        super(tipoEntidad, level, tipo);
        // los tramos se crean justo después de la locomotora: sus números de entidad quedan seguidos al de ella
        int n = Math.max(2, (int) Math.ceil((tipo.largoFrente() + tipo.largoAtras()) / PASO_PARTES));
        this.partes = new ParteBlindada[n];
        for (int i = 0; i < n; i++) {
            this.partes[i] = new ParteBlindada(this, 1.7F, 2.3F);
        }
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_HOSTIL, false);
        builder.define(DATA_BLANCO, -1);
        builder.define(DATA_TIRADOR, -1);
    }

    // ================================================================= estado

    public boolean esHostil() {
        return this.entityData.get(DATA_HOSTIL);
    }

    /** Lo deja hostil, con la vida entera; {@code patrulla}: la marcha con que anda cuando no pelea. */
    public void hacerHostil(int patrulla) {
        this.entityData.set(DATA_HOSTIL, true);
        this.vida = VIDA_MAXIMA;
        this.dueno = null;
        this.marchaPatrulla = patrulla;
    }

    /** El tren pasa a ser de este jugador (por ejemplo, el que lo puso con el ítem). */
    public void ponerDueno(@Nullable UUID jugador) {
        this.dueno = jugador;
    }

    @Nullable
    public UUID duenoId() {
        return this.dueno;
    }

    /** El dueño, si está en este mundo. */
    @Nullable
    public Player getDueno() {
        return this.dueno == null ? null : this.level().getPlayerByUUID(this.dueno);
    }

    public float getVida() {
        return this.vida;
    }

    /** ¿Está peleando (o peleó hace poco)? Mientras tanto el despachante no lo hace desaparecer. */
    public boolean enCombate() {
        long ahora = this.level().getGameTime();
        return getBlanco() != null || ahora - this.ultimoCombate < 20L * 30L || ahora - this.ultimoGolpe < 20L * 60L;
    }

    /** El blanco de las torretas (en el cliente, el que mandó el servidor). */
    @Nullable
    public Entity getBlanco() {
        int id = this.entityData.get(DATA_BLANCO);
        if (id < 0) {
            return null;
        }
        Entity e = this.level().getEntity(id);
        return e != null && e.isAlive() ? e : null;
    }

    private void setBlanco(@Nullable Entity e) {
        int id = e == null ? -1 : e.getId();
        if (this.entityData.get(DATA_BLANCO) != id) {
            this.entityData.set(DATA_BLANCO, id);
        }
    }

    /** El número de entidad del que maneja la torreta (-1 = nadie). */
    public int tiradorId() {
        return this.entityData.get(DATA_TIRADOR);
    }

    @Nullable
    private Player getTirador() {
        int id = tiradorId();
        return id >= 0 && this.level().getEntity(id) instanceof Player p ? p : null;
    }

    private void setTirador(@Nullable Player p) {
        int id = p == null ? -1 : p.getId();
        if (this.entityData.get(DATA_TIRADOR) != id) {
            this.entityData.set(DATA_TIRADOR, id);
        }
    }

    /** Clic izquierdo del maquinista: tira la torreta de la locomotora si ya recargó. */
    boolean dispararManual(ServerLevel nivel) {
        if (this.torreta.gatillo()) {
            TrenArtillero.disparar(nivel, this.torreta, this, this, this);
            return true;
        }
        return false;
    }

    /** Es de metal: el fuego y la lava no le hacen nada. */
    @Override
    public boolean fireImmune() {
        return true;
    }

    @Override
    protected Component agregarAlEstado(Component estado) {
        return Component.translatable("estado.locomotora.artillero", estado, Mth.ceil(this.vida));
    }

    // ================================================================= tick

    @Override
    public void tick() {
        super.tick();
        if (this.isRemoved()) {
            return;
        }
        moverPartes();
        if (this.level().isClientSide()) {
            Player tirador = getTirador();
            if (tirador != null) {
                this.torreta.apuntar(this, this, TrenArtillero.miraDe(tirador));
            } else {
                Entity blanco = getBlanco();
                this.torreta.apuntar(this, this, blanco == null ? null : TrenArtillero.puntoDeMira(blanco));
            }
        } else {
            tickCombate((ServerLevel) this.level());
        }
    }

    private void tickCombate(ServerLevel nivel) {
        long ahora = nivel.getGameTime();
        if ((this.tickCount + getId()) % 10 == 0) {
            elegirBlanco(nivel);
            if (esHostil()) {
                manejar(ahora);
            } else if (this.vida < VIDA_MAXIMA && ahora - this.ultimoGolpe > 200L && this.tickCount % 40 < 10) {
                // el blindaje se repara solo de a poco
                this.vida = Math.min(VIDA_MAXIMA, this.vida + 1.0F);
            }
        }
        // si el tren es de alguien y va el maquinista, él apunta mirando y tira con clic izquierdo
        Player tirador = esHostil() ? null : getMaquinista();
        setTirador(tirador);
        if (tirador != null) {
            this.torreta.apuntar(this, this, TrenArtillero.miraDe(tirador));
            if (this.torreta.tirarAhora(false)) {
                TrenArtillero.disparar(nivel, this.torreta, this, this, this);   // el resto de una ráfaga
            }
            return;
        }
        Entity blanco = getBlanco();
        boolean apunta = this.torreta.apuntar(this, this, blanco == null ? null : TrenArtillero.puntoDeMira(blanco));
        if (this.torreta.tirarAhora(apunta && this.sinVer == 0)) {
            TrenArtillero.disparar(nivel, this.torreta, this, this, this);
        }
    }

    // ================================================================= a quién le tira

    /** El eje de su cañón (de ahí mira). */
    private Vec3 ojo() {
        return this.torreta.eje(this, this).add(0.0, 0.25, 0.0);
    }

    private void elegirBlanco(ServerLevel nivel) {
        Vec3 ojo = ojo();
        Entity nuevo = esHostil() ? buscarJugador(nivel, ojo) : buscarAmenaza(nivel, ojo);
        if (nuevo != null) {
            setBlanco(nuevo);
            this.sinVer = 0;
            this.ultimoCombate = nivel.getGameTime();
            return;
        }
        // lo dejó de ver: sigue apuntando para ese lado un rato, sin tirar
        Entity anterior = getBlanco();
        this.sinVer += 10;
        if (anterior == null || this.sinVer > MEMORIA || !blancoValido(anterior)) {
            setBlanco(null);
        }
    }

    private static boolean blancoValido(Entity e) {
        if (!e.isAlive()) {
            return false;
        }
        return !(e instanceof Player p) || (!p.isSpectator() && !p.isCreative());
    }

    /** Hostil: el jugador que ve más cerca (o el que le estaba tirando, si lo sigue viendo). */
    @Nullable
    private Entity buscarJugador(ServerLevel nivel, Vec3 ojo) {
        if (nivel.getDifficulty() == Difficulty.PEACEFUL) {
            return null;
        }
        Entity actual = getBlanco();
        long ahora = nivel.getGameTime();
        Player mejor = null;
        double mejorDistancia = Double.MAX_VALUE;
        for (ServerPlayer j : nivel.players()) {
            if (!blancoValido(j)) {
                continue;
            }
            double alcance = j.isInvisible() ? VISTA_INVISIBLE : (j.isDiscrete() ? VISTA * 0.6 : VISTA);
            if (j.getUUID().equals(this.ultimoJugador) && ahora - this.ultimoJugadorCuando < 200L) {
                alcance = Math.max(alcance, VISTA_REVANCHA);
            }
            double d = j.distanceToSqr(ojo);
            if (d > alcance * alcance || !TrenArtillero.seVe(nivel, ojo, j, this)) {
                continue;
            }
            if (j == actual) {
                return j; // no cambia de blanco mientras lo vea
            }
            if (d < mejorDistancia) {
                mejorDistancia = d;
                mejor = j;
            }
        }
        return mejor;
    }

    /**
     * De alguien: lo que ataca (o tiene de blanco) a su dueño o a los que van en el tren. Si hay varios, el más cercano
     * que se vea.
     */
    @Nullable
    private Entity buscarAmenaza(ServerLevel nivel, Vec3 ojo) {
        List<Player> protegidos = protegidos(nivel);
        if (protegidos.isEmpty()) {
            return null;
        }
        List<Entity> candidatos = new ArrayList<>();
        for (Player p : protegidos) {
            LivingEntity agresor = p.getLastHurtByMob();
            if (agresor != null && p.tickCount - p.getLastHurtByMobTimestamp() < 100) {
                candidatos.add(agresor);
            }
        }
        AABB zona = this.getBoundingBox().inflate(DEFENSA, 16.0, DEFENSA);
        for (Mob m : nivel.getEntitiesOfClass(Mob.class, zona, m -> m.isAlive() && m.getTarget() != null)) {
            if (protegidos.contains(m.getTarget())) {
                candidatos.add(m);
            }
        }
        AABB lejos = this.getBoundingBox().inflate(VISTA, 16.0, VISTA);
        candidatos.addAll(nivel.getEntitiesOfClass(ArtilleroEntity.class, lejos, a -> a != this && a.esHostil()));

        Entity actual = getBlanco();
        Entity mejor = null;
        double mejorDistancia = Double.MAX_VALUE;
        for (Entity c : candidatos) {
            if (!blancoValido(c) || c == this || protegidos.contains(c)
                    || TrenArtillero.protegido(c, this.getUUID(), this.dueno)) {
                continue;
            }
            double alcance = c instanceof ArtilleroEntity ? VISTA : DEFENSA;
            double d = c.distanceToSqr(ojo);
            if (d > alcance * alcance || !TrenArtillero.seVe(nivel, ojo, c, this)) {
                continue;
            }
            if (c == actual) {
                return c;
            }
            if (d < mejorDistancia) {
                mejorDistancia = d;
                mejor = c;
            }
        }
        return mejor;
    }

    /** A quiénes defiende: su dueño (si anda cerca) y los jugadores que van en el tren. */
    private List<Player> protegidos(ServerLevel nivel) {
        List<Player> lista = new ArrayList<>();
        Player d = getDueno();
        if (d != null && d.isAlive() && d.distanceToSqr(this) < 64.0 * 64.0) {
            lista.add(d);
        }
        for (Entity p : this.getPassengers()) {
            if (p instanceof Player j && !lista.contains(j)) {
                lista.add(j);
            }
        }
        for (VagonEntity w : vagones(nivel)) {
            for (Entity p : w.getPassengers()) {
                if (p instanceof Player j && !lista.contains(j)) {
                    lista.add(j);
                }
            }
        }
        return lista;
    }

    /** Los vagones de este tren (los enganchados detrás, o los que salieron con él). */
    List<VagonEntity> vagones(ServerLevel nivel) {
        return nivel.getEntitiesOfClass(VagonEntity.class, this.getBoundingBox().inflate(48.0, 12.0, 48.0),
                w -> TrenArtillero.cabezaDe(w) == this);
    }

    // ================================================================= cómo anda (hostil)

    /**
     * Persigue al blanco por la vía: si está lejos adelante, va hacia él; a tiro, frena y pelea; si quedó atrás,
     * retrocede. Sin blanco, al rato sigue su camino.
     */
    private void manejar(long ahora) {
        Entity blanco = getBlanco();
        int marcha;
        if (blanco != null) {
            double dx = blanco.getX() - this.getX();
            double dz = blanco.getZ() - this.getZ();
            double adelante = dx * frenteX() + dz * frenteZ();
            if (adelante > 30.0) {
                marcha = 2;
            } else if (adelante > 16.0) {
                marcha = 1;
            } else if (adelante < -16.0) {
                marcha = -1;
            } else {
                marcha = 0;
            }
        } else if (ahora - this.ultimoCombate < 200L) {
            marcha = 0;
        } else {
            marcha = this.marchaPatrulla;
        }
        if (getMarcha() != marcha) {
            if (getMarcha() == 0 && marcha != 0 && getCombustible() > 0) {
                silbar();
            }
            ponerMarcha(marcha);
        }
    }

    // ================================================================= golpes

    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (this.level().isClientSide() || this.isRemoved()) {
            return true;
        }
        if (this.isInvulnerableTo(fuente)) {
            return false;
        }
        Entity quien = fuente.getEntity();
        boolean aMano = quien != null && fuente.getDirectEntity() == quien;
        // sus propios obuses (y los de sus vagones) no le hacen nada; los del dueño, tampoco
        if (fuente.getDirectEntity() instanceof ObusEntity && quien != null
                && TrenArtillero.protegido(quien, this.getUUID(), this.dueno)) {
            return false;
        }
        if (quien instanceof Player jugador && aMano && (jugador.getAbilities().instabuild || !esHostil())) {
            // en creativo se saca como cualquier vagoneta; si es de alguien, a mano se rompe como cualquier locomotora
            // (para llevársela)
            return super.hurt(fuente, cantidad);
        }
        if (!esHostil() && quien instanceof Player) {
            return false; // al tren de alguien, las flechas y los tiros de los jugadores no le hacen nada
        }
        return recibir((ServerLevel) this.level(), fuente, cantidad, this);
    }

    /**
     * Un golpe al blindaje (a la locomotora o a uno de sus vagones, {@code golpeado}): baja la vida, sacude al que
     * recibió el golpe y, si era hostil y la vida llega a 0, queda derrotado.
     */
    boolean recibir(ServerLevel nivel, DamageSource fuente, float cantidad, AbstractMinecart golpeado) {
        Entity quien = fuente.getEntity();
        float dano = Math.min(cantidad, GOLPE_MAXIMO);
        if (dano <= 0.0F) {
            return false;
        }
        long ahora = nivel.getGameTime();
        this.vida -= dano;
        this.ultimoGolpe = ahora;
        // se sacude un poco (es pesado) y suena a chapa
        golpeado.setHurtDir(-golpeado.getHurtDir());
        golpeado.setHurtTime(8);
        golpeado.setDamage(Math.min(6.0F, golpeado.getDamage() + 3.0F));
        nivel.playSound(null, golpeado.getX(), golpeado.getY() + 1.0, golpeado.getZ(), ModSonidos.BLINDAJE.get(),
                SoundSource.HOSTILE, 0.6F, 0.6F + this.random.nextFloat() * 0.3F);

        Player atacante = jugadorDetras(quien);
        if (atacante != null) {
            this.ultimoJugador = atacante.getUUID();
            this.ultimoJugadorCuando = ahora;
        }
        if (esHostil()) {
            this.ultimoCombate = ahora;
            // le devuelve el golpe (si es un blanco que puede tener)
            if (atacante != null && blancoValido(atacante) && getBlanco() == null) {
                setBlanco(atacante);
                this.sinVer = 0;
            }
            if (this.vida <= 0.0F) {
                derrotar(nivel, quien);
            }
        } else if (this.vida <= 0.0F) {
            // de alguien: se rompió el blindaje
            this.vida = 0.0F;
            this.destroy(fuente);
        }
        return true;
    }

    /** El jugador que está detrás de un golpe: el que pegó, o el dueño del tren artillero que tiró el obús. */
    @Nullable
    private static Player jugadorDetras(@Nullable Entity quien) {
        if (quien instanceof PartEntity<?> parte) {
            quien = parte.getParent();
        }
        if (quien instanceof Player p) {
            return p;
        }
        if (quien instanceof ArtilleroEntity a && !a.esHostil()) {
            return a.getDueno();
        }
        if (quien instanceof VagonArmadoEntity w && TrenArtillero.cabezaDe(w) instanceof ArtilleroEntity a
                && !a.esHostil()) {
            return a.getDueno();
        }
        return null;
    }

    /**
     * ¡Derrotado! Queda quieto, con la vida entera, y pasa a ser de quien lo derrotó (el que dio el último golpe; si no
     * fue un jugador, el último que le pegó, y si no, el jugador más cercano).
     */
    private void derrotar(ServerLevel nivel, @Nullable Entity quien) {
        Player ganador = jugadorDetras(quien);
        long ahora = nivel.getGameTime();
        if (ganador == null && this.ultimoJugador != null && ahora - this.ultimoJugadorCuando < 20L * 60L) {
            ganador = nivel.getPlayerByUUID(this.ultimoJugador);
        }
        if (ganador == null) {
            Player cerca = nivel.getNearestPlayer(this, 32.0);
            if (cerca != null && !cerca.isSpectator()) {
                ganador = cerca;
            }
        }
        this.entityData.set(DATA_HOSTIL, false);
        this.vida = VIDA_MAXIMA;
        this.dueno = ganador != null ? ganador.getUUID() : null;
        this.marchaPatrulla = 0;
        setBlanco(null);
        ponerMarcha(0);
        TrenArtillero.quitarMarcas(nivel, this);

        // explosiones y humo a lo largo del tren (sin romper nada)
        for (int i = -2; i <= 2; i++) {
            Vec3 p = puntoDeLaLoco(i * 1.2, 0.0, 1.6);
            nivel.sendParticles(ParticleTypes.EXPLOSION, p.x, p.y, p.z, 1, 0.3, 0.3, 0.3, 0.0);
            nivel.sendParticles(ParticleTypes.LARGE_SMOKE, p.x, p.y + 0.5, p.z, 10, 0.4, 0.4, 0.4, 0.04);
        }
        for (VagonEntity w : vagones(nivel)) {
            nivel.sendParticles(ParticleTypes.LARGE_SMOKE, w.getX(), w.getY() + 1.6, w.getZ(), 12, 0.6, 0.4, 0.6, 0.04);
        }
        nivel.playSound(null, this.getX(), this.getY() + 1.0, this.getZ(), ModSonidos.OBUS.get(),
                SoundSource.HOSTILE, 4.0F, 0.7F);
        nivel.playSound(null, this.getX(), this.getY() + 1.0, this.getZ(), ModSonidos.VICTORIA.get(),
                SoundSource.PLAYERS, 1.0F, 1.0F);

        Component nombre = ganador != null ? ganador.getDisplayName() : Component.literal("?");
        for (ServerPlayer j : nivel.players()) {
            if (j.distanceToSqr(this) > 96.0 * 96.0) {
                continue;
            }
            if (j == ganador) {
                j.displayClientMessage(Component.translatable("mensaje.locomotora.artillero_ganado")
                        .withStyle(ChatFormatting.GOLD), false);
            } else if (ganador != null) {
                j.displayClientMessage(Component.translatable("mensaje.locomotora.artillero_derrotado", nombre)
                        .withStyle(ChatFormatting.GOLD), false);
            } else {
                j.displayClientMessage(Component.translatable("mensaje.locomotora.artillero_sin_dueno")
                        .withStyle(ChatFormatting.GOLD), false);
            }
        }
    }

    // ================================================================= interacción

    /** Hostil no deja hacer nada (ni subirse ni cargarlo); derrotado sin dueño, el primero que se sube se lo queda. */
    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        if (esHostil()) {
            if (!this.level().isClientSide()) {
                jugador.displayClientMessage(Component.translatable("mensaje.locomotora.artillero_blindado")
                        .withStyle(ChatFormatting.RED), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }
        boolean iba = jugador.getVehicle() == this;
        InteractionResult resultado = super.interact(jugador, mano);
        if (!this.level().isClientSide() && this.dueno == null && jugador.getVehicle() == this) {
            this.dueno = jugador.getUUID();
            jugador.displayClientMessage(Component.translatable("mensaje.locomotora.artillero_tuyo")
                    .withStyle(ChatFormatting.GOLD), false);
        }
        if (!this.level().isClientSide() && !iba && getMaquinista() == jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.locomotora.artillero_apuntar")
                    .withStyle(ChatFormatting.YELLOW), false);
        }
        return resultado;
    }

    // ================================================================= la torreta, para dibujarla

    @Override
    public float giroTorreta(float tickParcial) {
        return this.torreta.giro(tickParcial);
    }

    @Override
    public float alzaTorreta(float tickParcial) {
        return this.torreta.alza(tickParcial);
    }

    // ================================================================= tramos del casco

    @Override
    public boolean isMultipartEntity() {
        return true;
    }

    @Override
    public PartEntity<?>[] getParts() {
        return this.partes;
    }

    /** En el cliente los tramos toman los números de entidad que tienen en el servidor (los que siguen al de ella). */
    @Override
    public void recreateFromPacket(ClientboundAddEntityPacket paquete) {
        super.recreateFromPacket(paquete);
        for (int i = 0; i < this.partes.length; i++) {
            this.partes[i].setId(paquete.getId() + 1 + i);
        }
    }

    /** Los tramos acompañan a la locomotora siguiendo la vía (también en el cliente, para poder apuntarle). */
    private void moverPartes() {
        double largo = getTipo().largoFrente() + getTipo().largoAtras();
        double paso = largo / this.partes.length;
        for (int i = 0; i < this.partes.length; i++) {
            ParteBlindada p = this.partes[i];
            Vec3 c = puntoDeLaLoco(getTipo().largoFrente() - (i + 0.5) * paso, 0.0, 0.0);
            p.xo = p.getX();
            p.yo = p.getY();
            p.zo = p.getZ();
            p.xOld = p.xo;
            p.yOld = p.yo;
            p.zOld = p.zo;
            p.setPos(c.x, c.y, c.z);
        }
    }

    // ================================================================= guardado

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Hostil", esHostil());
        tag.putFloat("Vida", this.vida);
        tag.putInt("MarchaPatrulla", this.marchaPatrulla);
        if (this.dueno != null) {
            tag.putUUID("Dueno", this.dueno);
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(DATA_HOSTIL, tag.getBoolean("Hostil"));
        this.vida = tag.contains("Vida") ? Mth.clamp(tag.getFloat("Vida"), 1.0F, VIDA_MAXIMA) : VIDA_MAXIMA;
        this.marchaPatrulla = tag.getInt("MarchaPatrulla");
        this.dueno = tag.hasUUID("Dueno") ? tag.getUUID("Dueno") : null;
    }
}
