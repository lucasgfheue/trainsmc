package com.locomotora.artillero;

import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import com.locomotora.entidad.TipoVagon;
import com.locomotora.entidad.VagonEntity;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.HasCustomInventoryScreen;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Un vagón blindado del tren artillero (el del cañón o el antiaéreo), con su torreta. Enganchado detrás de una
 * locomotora artillera, le tira al mismo blanco que ella; los golpes que recibe le bajan la vida a la locomotora.
 * Mientras el tren es hostil no se puede subir, abrir su cofre (ahí va el botín) ni desengancharlo.
 * <p>
 * Tiene una cabina para la tripulación (clic derecho para subir). El primero que se sienta es el tirador: apunta la
 * torreta mirando y tira con clic izquierdo; si no hay tirador, la maneja el maquinista del tren. Sentado, la tecla del
 * inventario abre el cofre del vagón.
 */
public class VagonArmadoEntity extends VagonEntity implements HasCustomInventoryScreen {
    /** El blanco de su torreta (número de entidad; -1 = ninguno): el cliente lo usa para girarla. */
    private static final EntityDataAccessor<Integer> DATA_BLANCO =
            SynchedEntityData.defineId(VagonArmadoEntity.class, EntityDataSerializers.INT);
    /** Quién apunta la torreta mirando (el tirador, o el maquinista si no hay; -1 = nadie): el cliente la gira igual. */
    private static final EntityDataAccessor<Integer> DATA_TIRADOR =
            SynchedEntityData.defineId(VagonArmadoEntity.class, EntityDataSerializers.INT);

    private final Torreta torreta;
    /** La locomotora artillera con la que salió (los que aparecen hostiles): sigue siendo suyo aunque se suelte. */
    @Nullable
    private UUID tren;
    /** ¿Ve al blanco desde su torreta? (se mira cada tanto) */
    private boolean loVe;

    public VagonArmadoEntity(EntityType<? extends VagonEntity> tipoEntidad, Level level, TipoVagon tipo) {
        super(tipoEntidad, level, tipo);
        this.torreta = new Torreta(tipo == TipoVagon.ANTIAEREO ? Torreta.ANTIAEREO : Torreta.CANON);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_BLANCO, -1);
        builder.define(DATA_TIRADOR, -1);
    }

    /** Lo marca como de ese tren artillero (al aparecer con él). */
    public void marcarTren(UUID loco) {
        this.tren = loco;
    }

    @Nullable
    UUID trenMarcado() {
        return this.tren;
    }

    /**
     * La locomotora artillera de su tren: la que encabeza los enganches o, si se soltó, la hostil con la que salió.
     * Solo en el servidor.
     */
    @Nullable
    public ArtilleroEntity artillero() {
        ArtilleroEntity cabeza = TrenArtillero.cabezaDe(this);
        if (cabeza != null) {
            return cabeza;
        }
        if (this.tren != null && this.level() instanceof ServerLevel nivel
                && nivel.getEntity(this.tren) instanceof ArtilleroEntity a && a.esHostil()) {
            return a;
        }
        return null;
    }

    @Nullable
    private Entity getBlanco() {
        int id = this.entityData.get(DATA_BLANCO);
        if (id < 0) {
            return null;
        }
        Entity e = this.level().getEntity(id);
        return e != null && e.isAlive() ? e : null;
    }

    // ================================================================= el tirador

    /** El número de entidad del que maneja la torreta (-1 = nadie). */
    public int tiradorId() {
        return this.entityData.get(DATA_TIRADOR);
    }

    @Nullable
    private Player getTirador() {
        int id = tiradorId();
        return id >= 0 && this.level().getEntity(id) instanceof Player p ? p : null;
    }

    private void setTirador(@Nullable Player p) {
        int id = p == null ? -1 : p.getId();
        if (this.entityData.get(DATA_TIRADOR) != id) {
            this.entityData.set(DATA_TIRADOR, id);
        }
    }

    /**
     * Quién maneja la torreta: el que va en el asiento del tirador o, si está libre, el maquinista de la locomotora
     * artillera (si el tren es de alguien). Solo en el servidor.
     */
    @Nullable
    Player controlador() {
        if (enAsiento(0) instanceof Player p) {
            return p;
        }
        ArtilleroEntity cabeza = artillero();
        return cabeza != null && !cabeza.esHostil() ? cabeza.getMaquinista() : null;
    }

    /** Clic izquierdo del que la maneja: tira si ya recargó (solo enganchado a su locomotora artillera). */
    boolean dispararManual(ServerLevel nivel) {
        ArtilleroEntity cabeza = artillero();
        if (cabeza != null && !cabeza.esHostil() && this.torreta.gatillo()) {
            TrenArtillero.disparar(nivel, this.torreta, this, this, cabeza);
            return true;
        }
        return false;
    }

    // ================================================================= tick

    @Override
    public void tick() {
        super.tick();
        if (this.isRemoved()) {
            return;
        }
        if (this.level().isClientSide()) {
            Player tirador = getTirador();
            if (tirador != null) {
                this.torreta.apuntar(this, this, TrenArtillero.miraDe(tirador));
            } else {
                Entity blanco = getBlanco();
                this.torreta.apuntar(this, this, blanco == null ? null : TrenArtillero.puntoDeMira(blanco));
            }
            return;
        }
        ServerLevel nivel = (ServerLevel) this.level();
        ArtilleroEntity cabeza = artillero();
        // si el tren es de alguien y hay quien la maneje, apunta adonde mira y tira con su clic izquierdo
        Player tirador = cabeza != null && cabeza.esHostil() ? null : controlador();
        setTirador(tirador);
        if (tirador != null) {
            this.torreta.apuntar(this, this, TrenArtillero.miraDe(tirador));
            if (cabeza != null && this.torreta.tirarAhora(false)) {
                TrenArtillero.disparar(nivel, this.torreta, this, this, cabeza);   // el resto de una ráfaga
            }
            return;
        }
        Entity blanco = cabeza != null ? cabeza.getBlanco() : null;
        int id = blanco == null ? -1 : blanco.getId();
        if (this.entityData.get(DATA_BLANCO) != id) {
            this.entityData.set(DATA_BLANCO, id);
        }
        if ((this.tickCount + getId()) % 5 == 0) {
            this.loVe = blanco != null
                    && TrenArtillero.seVe(nivel, this.torreta.eje(this, this).add(0.0, 0.25, 0.0), blanco, this);
        }
        boolean apunta = this.torreta.apuntar(this, this, blanco == null ? null : TrenArtillero.puntoDeMira(blanco));
        if (cabeza != null && this.torreta.tirarAhora(apunta && this.loVe)) {
            TrenArtillero.disparar(nivel, this.torreta, this, this, cabeza);
        }
    }

    // ================================================================= golpes e interacción

    /**
     * El blindaje es uno solo para todo el tren: los golpes le bajan la vida a la locomotora. Si el tren es de alguien,
     * los jugadores lo rompen a mano (para llevárselo) como a cualquier vagón.
     */
    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (this.level().isClientSide() || this.isRemoved()) {
            return true;
        }
        ArtilleroEntity cabeza = artillero();
        if (cabeza == null || this.isInvulnerableTo(fuente)) {
            return super.hurt(fuente, cantidad);
        }
        Entity quien = fuente.getEntity();
        if (fuente.getDirectEntity() instanceof ObusEntity && quien != null
                && TrenArtillero.protegido(quien, cabeza.getUUID(), cabeza.duenoId())) {
            return false;
        }
        boolean aMano = quien != null && fuente.getDirectEntity() == quien;
        if (quien instanceof Player jugador && aMano && (jugador.getAbilities().instabuild || !cabeza.esHostil())) {
            // en creativo, o si el tren es de alguien: a mano se rompe como cualquier vagón
            return super.hurt(fuente, cantidad);
        }
        if (!cabeza.esHostil() && quien instanceof Player) {
            return false; // al tren de alguien, las flechas y los tiros de los jugadores no le hacen nada
        }
        return cabeza.recibir((ServerLevel) this.level(), fuente, cantidad, this);
    }

    /** El primero que sube se sienta en el puesto del tirador (si está libre); los demás, en la cabina. */
    @Override
    protected int asientoParaSubir(Player jugador) {
        return enAsiento(0) == null ? 0 : super.asientoParaSubir(jugador);
    }

    /** Clic derecho: subirse a la cabina (el primero es el tirador). Hostil, no deja. */
    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        if (!this.level().isClientSide()) {
            ArtilleroEntity cabeza = artillero();
            if (cabeza != null && cabeza.esHostil()) {
                jugador.displayClientMessage(Component.translatable("mensaje.locomotora.artillero_blindado")
                        .withStyle(ChatFormatting.RED), true);
                return InteractionResult.CONSUME;
            }
        }
        boolean iba = jugador.getVehicle() == this;
        if (!iba && !jugador.isSecondaryUseActive() && this.getPassengers().size() >= getTipo().cantidadAsientos()) {
            if (!this.level().isClientSide()) {
                jugador.displayClientMessage(Component.translatable("mensaje.locomotora.cabina_llena")
                        .withStyle(ChatFormatting.RED), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }
        InteractionResult resultado = super.interact(jugador, mano);
        if (!this.level().isClientSide() && !iba && jugador.getVehicle() == this) {
            jugador.displayClientMessage(Component.translatable(enAsiento(0) == jugador
                    ? "mensaje.locomotora.tirador" : "mensaje.locomotora.tripulante").withStyle(ChatFormatting.YELLOW),
                    false);
        }
        return resultado;
    }

    /** Sentado en la cabina, la tecla del inventario abre el cofre del vagón (si el tren no es hostil). */
    @Override
    public void openCustomInventoryScreen(Player jugador) {
        if (this.level().isClientSide()) {
            return;
        }
        ArtilleroEntity cabeza = artillero();
        if (cabeza != null && cabeza.esHostil()) {
            return;
        }
        jugador.openMenu(this);
    }

    // ================================================================= la torreta, para dibujarla

    @Override
    public float giroTorreta(float tickParcial) {
        return this.torreta.giro(tickParcial);
    }

    @Override
    public float alzaTorreta(float tickParcial) {
        return this.torreta.alza(tickParcial);
    }

    /** Es de metal: el fuego y la lava no le hacen nada. */
    @Override
    public boolean fireImmune() {
        return true;
    }

    // ================================================================= guardado

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (this.tren != null) {
            tag.putUUID("TrenArtillero", this.tren);
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.tren = tag.hasUUID("TrenArtillero") ? tag.getUUID("TrenArtillero") : null;
    }
}
