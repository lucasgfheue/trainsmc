package com.locomotora.artillero;

import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import com.locomotora.entidad.TipoVagon;
import com.locomotora.entidad.VagonEntity;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Un vagón blindado del tren artillero (el del cañón o el antiaéreo), con su torreta. Enganchado detrás de una
 * locomotora artillera, le tira al mismo blanco que ella; los golpes que recibe le bajan la vida a la locomotora.
 * Mientras el tren es hostil no se puede abrir su cofre (ahí va el botín) ni desengancharlo.
 */
public class VagonArmadoEntity extends VagonEntity {
    /** El blanco de su torreta (número de entidad; -1 = ninguno): el cliente lo usa para girarla. */
    private static final EntityDataAccessor<Integer> DATA_BLANCO =
            SynchedEntityData.defineId(VagonArmadoEntity.class, EntityDataSerializers.INT);

    private final Torreta torreta;
    /** La locomotora artillera con la que salió (los que aparecen hostiles): sigue siendo suyo aunque se suelte. */
    @Nullable
    private UUID tren;
    /** ¿Ve al blanco desde su torreta? (se mira cada tanto) */
    private boolean loVe;

    public VagonArmadoEntity(EntityType<? extends VagonEntity> tipoEntidad, Level level, TipoVagon tipo) {
        super(tipoEntidad, level, tipo);
        this.torreta = new Torreta(tipo == TipoVagon.ANTIAEREO ? Torreta.ANTIAEREO : Torreta.CANON);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_BLANCO, -1);
    }

    /** Lo marca como de ese tren artillero (al aparecer con él). */
    public void marcarTren(UUID loco) {
        this.tren = loco;
    }

    @Nullable
    UUID trenMarcado() {
        return this.tren;
    }

    /**
     * La locomotora artillera de su tren: la que encabeza los enganches o, si se soltó, la hostil con la que salió.
     * Solo en el servidor.
     */
    @Nullable
    public ArtilleroEntity artillero() {
        ArtilleroEntity cabeza = TrenArtillero.cabezaDe(this);
        if (cabeza != null) {
            return cabeza;
        }
        if (this.tren != null && this.level() instanceof ServerLevel nivel
                && nivel.getEntity(this.tren) instanceof ArtilleroEntity a && a.esHostil()) {
            return a;
        }
        return null;
    }

    @Nullable
    private Entity getBlanco() {
        int id = this.entityData.get(DATA_BLANCO);
        if (id < 0) {
            return null;
        }
        Entity e = this.level().getEntity(id);
        return e != null && e.isAlive() ? e : null;
    }

    // ================================================================= tick

    @Override
    public void tick() {
        super.tick();
        if (this.isRemoved()) {
            return;
        }
        if (this.level().isClientSide()) {
            Entity blanco = getBlanco();
            this.torreta.apuntar(this, this, blanco == null ? null : TrenArtillero.puntoDeMira(blanco));
            return;
        }
        ServerLevel nivel = (ServerLevel) this.level();
        ArtilleroEntity cabeza = artillero();
        Entity blanco = cabeza != null ? cabeza.getBlanco() : null;
        int id = blanco == null ? -1 : blanco.getId();
        if (this.entityData.get(DATA_BLANCO) != id) {
            this.entityData.set(DATA_BLANCO, id);
        }
        if ((this.tickCount + getId()) % 5 == 0) {
            this.loVe = blanco != null
                    && TrenArtillero.seVe(nivel, this.torreta.eje(this, this).add(0.0, 0.25, 0.0), blanco, this);
        }
        boolean apunta = this.torreta.apuntar(this, this, blanco == null ? null : TrenArtillero.puntoDeMira(blanco));
        if (cabeza != null && this.torreta.tirarAhora(apunta && this.loVe)) {
            TrenArtillero.disparar(nivel, this.torreta, this, this, cabeza);
        }
    }

    // ================================================================= golpes e interacción

    /**
     * El blindaje es uno solo para todo el tren: los golpes le bajan la vida a la locomotora. Si el tren es de alguien,
     * los jugadores lo rompen a mano (para llevárselo) como a cualquier vagón.
     */
    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (this.level().isClientSide() || this.isRemoved()) {
            return true;
        }
        ArtilleroEntity cabeza = artillero();
        if (cabeza == null || this.isInvulnerableTo(fuente)) {
            return super.hurt(fuente, cantidad);
        }
        Entity quien = fuente.getEntity();
        if (fuente.getDirectEntity() instanceof ObusEntity && quien != null
                && TrenArtillero.protegido(quien, cabeza.getUUID(), cabeza.duenoId())) {
            return false;
        }
        boolean aMano = quien != null && fuente.getDirectEntity() == quien;
        if (quien instanceof Player jugador && aMano && (jugador.getAbilities().instabuild || !cabeza.esHostil())) {
            // en creativo, o si el tren es de alguien: a mano se rompe como cualquier vagón
            return super.hurt(fuente, cantidad);
        }
        if (!cabeza.esHostil() && quien instanceof Player) {
            return false; // al tren de alguien, las flechas y los tiros de los jugadores no le hacen nada
        }
        return cabeza.recibir((ServerLevel) this.level(), fuente, cantidad, this);
    }

    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        if (!this.level().isClientSide()) {
            ArtilleroEntity cabeza = artillero();
            if (cabeza != null && cabeza.esHostil()) {
                jugador.displayClientMessage(Component.translatable("mensaje.locomotora.artillero_blindado")
                        .withStyle(ChatFormatting.RED), true);
                return InteractionResult.CONSUME;
            }
        }
        return super.interact(jugador, mano);
    }

    // ================================================================= la torreta, para dibujarla

    @Override
    public float giroTorreta(float tickParcial) {
        return this.torreta.giro(tickParcial);
    }

    @Override
    public float alzaTorreta(float tickParcial) {
        return this.torreta.alza(tickParcial);
    }

    /** Es de metal: el fuego y la lava no le hacen nada. */
    @Override
    public boolean fireImmune() {
        return true;
    }

    // ================================================================= guardado

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (this.tren != null) {
            tag.putUUID("TrenArtillero", this.tren);
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.tren = tag.hasUUID("TrenArtillero") ? tag.getUUID("TrenArtillero") : null;
    }
}
