package com.locomotora.artillero;

import org.jetbrains.annotations.Nullable;

import com.locomotora.entidad.VehiculoDeVia;

import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

/**
 * Una torreta del tren artillero: dónde está el eje de su cañón sobre el vehículo, hasta dónde sube, qué tan rápido gira,
 * cada cuánto tira y qué tira. Cada lado lleva su propio estado: el servidor, para saber cuándo ya le apunta al blanco y
 * puede tirar; el cliente, para dibujarla girando de a poco hacia el blanco (los dos giran igual, así que coinciden).
 * <p>
 * El giro es hacia la derecha del frente del vehículo (radianes, 0 = mirando adelante); el alza, cuánto sube el caño.
 */
public final class Torreta {
    /** Rozamiento del aire por tick de los obuses (el de cualquier proyectil que se tira). */
    private static final double ROCE = 0.99;
    /** Lo que cae un obús por tick (la gravedad de los proyectiles que se tiran). */
    private static final double GRAVEDAD = 0.03;
    private static final float PI = (float) Math.PI;

    /**
     * Lo que tira: velocidad del obús (bloques por tick), daño del impacto, radio y daño de la explosión, y la
     * imprecisión (la de un arco es 1).
     */
    public record Tiro(float velocidad, float danoImpacto, float radio, float danoExplosion, float imprecision) {
    }

    /**
     * Medidas de una torreta.
     *
     * @param adelante    del centro del vehículo al eje del cañón, hacia el frente (bloques)
     * @param alto        altura del eje del cañón sobre el riel (bloques)
     * @param cano        del eje a la boca del caño (bloques)
     * @param velocidadGiro cuánto gira (y sube) por tick, en radianes
     * @param recarga     ticks entre un tiro (o una ráfaga) y el siguiente
     * @param rafaga      tiros seguidos de cada ráfaga
     * @param entreTiros  ticks entre los tiros de una ráfaga
     */
    public record Medidas(double adelante, double alto, double cano, float alzaMinima, float alzaMaxima, float alzaReposo,
                          float velocidadGiro, int recarga, int rafaga, int entreTiros, Tiro tiro) {
    }

    /** La torreta de la locomotora blindada (la del maquinista). */
    public static final Medidas LOCOMOTORA = new Medidas(0.5, 2.19, 1.88, -0.12F, 0.55F, 0.0F, 0.10F, 50, 1, 0,
            new Tiro(2.6F, 8.0F, 2.5F, 8.0F, 1.0F));
    /** La torreta grande del vagón cañón: más lenta, tira más fuerte y más lejos. */
    public static final Medidas CANON = new Medidas(0.0, 2.16, 2.81, -0.12F, 0.60F, 0.0F, 0.07F, 70, 1, 0,
            new Tiro(3.0F, 12.0F, 3.0F, 12.0F, 0.6F));
    /** Los dos caños del vagón antiaéreo: giran rápido, suben casi derechos y tiran ráfagas de obuses chicos. */
    public static final Medidas ANTIAEREO = new Medidas(0.0, 1.44, 1.38, 0.12F, 1.45F, 0.35F, 0.16F, 30, 3, 4,
            new Tiro(3.2F, 4.0F, 1.3F, 3.0F, 2.5F));

    private final Medidas medidas;
    private float giro;
    private float giroAnterior;
    private float alza;
    private float alzaAnterior;
    /** Ticks que faltan para poder tirar. */
    private int espera;
    /** Tiros que quedan de la ráfaga y ticks hasta el próximo. */
    private int quedan;
    private int entre;

    public Torreta(Medidas medidas) {
        this.medidas = medidas;
        this.alza = medidas.alzaReposo();
        this.alzaAnterior = this.alza;
        // la primera vez no tiran todas juntas
        this.espera = 20 + (int) (Math.random() * 30.0);
    }

    public Medidas medidas() {
        return this.medidas;
    }

    // ================================================================= dónde está y hacia dónde mira

    /** El eje del cañón, en el mundo. */
    public Vec3 eje(Entity vehiculo, VehiculoDeVia v) {
        double a = this.medidas.adelante();
        return new Vec3(vehiculo.getX() + v.frenteX() * a, vehiculo.getY() + this.medidas.alto(),
                vehiculo.getZ() + v.frenteZ() * a);
    }

    /** Hacia dónde apunta el caño ahora, en el mundo (largo 1). */
    public Vec3 direccion(VehiculoDeVia v) {
        double fx = v.frenteX();
        double fz = v.frenteZ();
        double c = Math.cos(this.giro);
        double s = Math.sin(this.giro);
        // el frente girado hacia la derecha, que es (-frenteZ, frenteX)
        double hx = fx * c - fz * s;
        double hz = fz * c + fx * s;
        double ca = Math.cos(this.alza);
        return new Vec3(hx * ca, Math.sin(this.alza), hz * ca);
    }

    /** La boca del caño, en el mundo: de ahí sale el obús. */
    public Vec3 boca(Entity vehiculo, VehiculoDeVia v) {
        return eje(vehiculo, v).add(direccion(v).scale(this.medidas.cano()));
    }

    /** El giro para dibujarla (interpolado entre ticks, por el camino más corto). */
    public float giro(float tickParcial) {
        return this.giroAnterior + envolver(this.giro - this.giroAnterior) * tickParcial;
    }

    public float alza(float tickParcial) {
        return Mth.lerp(tickParcial, this.alzaAnterior, this.alza);
    }

    // ================================================================= apuntar y tirar

    /**
     * Un tick: gira y sube el caño hacia el blanco (o vuelve a mirar al frente si no hay). Devuelve si ya le apunta
     * (y el blanco está al alcance de su cañón).
     */
    public boolean apuntar(Entity vehiculo, VehiculoDeVia v, @Nullable Vec3 blanco) {
        this.giroAnterior = this.giro;
        this.alzaAnterior = this.alza;
        float giroBuscado = 0.0F;
        float alzaBuscada = this.medidas.alzaReposo();
        boolean alcanza = false;
        if (blanco != null) {
            Vec3 e = eje(vehiculo, v);
            double dx = blanco.x - e.x;
            double dy = blanco.y - e.y;
            double dz = blanco.z - e.z;
            double adelante = dx * v.frenteX() + dz * v.frenteZ();
            double derecha = -dx * v.frenteZ() + dz * v.frenteX();
            giroBuscado = (float) Math.atan2(derecha, adelante);
            double alzaJusta = alzaPara(Math.sqrt(dx * dx + dz * dz), dy, this.medidas.tiro().velocidad());
            if (Double.isNaN(alzaJusta)) {
                alzaBuscada = this.medidas.alzaMaxima();
            } else {
                alcanza = alzaJusta >= this.medidas.alzaMinima() - 0.03 && alzaJusta <= this.medidas.alzaMaxima() + 0.03;
                alzaBuscada = (float) Mth.clamp(alzaJusta, this.medidas.alzaMinima(), this.medidas.alzaMaxima());
            }
        }
        float paso = this.medidas.velocidadGiro();
        this.giro = envolver(this.giro + Mth.clamp(envolver(giroBuscado - this.giro), -paso, paso));
        this.alza += Mth.clamp(alzaBuscada - this.alza, -paso, paso);
        return blanco != null && alcanza && Math.abs(envolver(giroBuscado - this.giro)) < 0.05F
                && Math.abs(alzaBuscada - this.alza) < 0.05F;
    }

    /**
     * Un tick del servidor: ¿tira ahora? Tira cuando ya recargó y le apunta al blanco; las ráfagas, una vez empezadas,
     * siguen hasta el último tiro.
     */
    public boolean tirarAhora(boolean apunta) {
        if (this.espera > 0) {
            this.espera--;
        }
        if (this.quedan > 0) {
            if (--this.entre <= 0) {
                this.quedan--;
                this.entre = this.medidas.entreTiros();
                return true;
            }
            return false;
        }
        if (apunta && this.espera <= 0) {
            this.quedan = this.medidas.rafaga() - 1;
            this.entre = this.medidas.entreTiros();
            this.espera = this.medidas.recarga();
            return true;
        }
        return false;
    }

    /**
     * La elevación (radianes) para que un obús que sale a {@code v0} bloques por tick caiga a {@code h} bloques en planta
     * y {@code dy} de altura, o NaN si no llega. Los proyectiles pierden el 1% de la velocidad por tick y caen 0,03:
     * en n ticks avanzan v·(1 - 0,99ⁿ)/0,01 y caen 3·(n - (1 - 0,99ⁿ)/0,01) más que en línea recta.
     */
    static double alzaPara(double h, double dy, double v0) {
        if (h < 0.5) {
            return dy >= 0.0 ? Math.PI / 2.0 : -Math.PI / 2.0;
        }
        double theta = Math.atan2(dy, h);
        for (int i = 0; i < 5; i++) {
            double vh = v0 * Math.cos(theta);
            double q = (1.0 - ROCE) * h / vh;
            if (vh <= 1.0E-6 || q >= 1.0) {
                return Double.NaN;
            }
            double n = Math.log(1.0 - q) / Math.log(ROCE);
            double caida = GRAVEDAD / (1.0 - ROCE) * (n - h / vh);
            theta = Math.atan2(dy + caida, h);
        }
        return theta;
    }

    /** Un ángulo llevado a (-π, π]. */
    static float envolver(float a) {
        a = a % (2.0F * PI);
        if (a > PI) {
            a -= 2.0F * PI;
        } else if (a <= -PI) {
            a += 2.0F * PI;
        }
        return a;
    }
}
