package com.locomotora.artillero;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * Un tramo del casco de la locomotora blindada: mide casi 7 bloques y su caja de choque (la de una vagoneta) apenas uno,
 * así que el casco se arma con tramos para poder pegarle, tirarle flechas o hacerle clic en cualquier parte. Lo que le
 * pase a un tramo le pasa a la locomotora. No se guarda ni se manda a los clientes: cada lado arma los suyos.
 */
public class ParteBlindada extends PartEntity<ArtilleroEntity> {
    private final EntityDimensions medida;

    public ParteBlindada(ArtilleroEntity loco, float ancho, float alto) {
        super(loco);
        this.medida = EntityDimensions.scalable(ancho, alto);
        this.refreshDimensions();
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    /** Se le puede apuntar, salvo desde arriba de la misma locomotora (si no, el maquinista no podría apuntar a nada). */
    @Override
    public boolean isPickable() {
        ArtilleroEntity loco = this.getParent();
        if (loco.isRemoved()) {
            return false;
        }
        return !(this.level().isClientSide() && com.locomotora.cliente.Local.vaEn(loco));
    }

    /** Las flechas pegan en cualquier parte del casco. */
    @Override
    public boolean canBeHitByProjectile() {
        return !this.getParent().isRemoved();
    }

    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        return !this.isInvulnerableTo(fuente) && this.getParent().hurt(fuente, cantidad);
    }

    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        return this.getParent().interact(jugador, mano);
    }

    @Override
    public ItemStack getPickResult() {
        return this.getParent().getPickResult();
    }

    @Override
    public boolean is(Entity otra) {
        return this == otra || this.getParent() == otra;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket(ServerEntity entidad) {
        throw new UnsupportedOperationException();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return this.medida;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }
}
