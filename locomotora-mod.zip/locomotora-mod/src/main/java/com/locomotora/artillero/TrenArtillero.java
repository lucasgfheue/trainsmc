package com.locomotora.artillero;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import com.locomotora.LocomotoraMod;
import com.locomotora.entidad.Enganches;
import com.locomotora.entidad.LocomotoraEntity;
import com.locomotora.entidad.TipoLocomotora;
import com.locomotora.entidad.TipoVagon;
import com.locomotora.entidad.VagonEntity;
import com.locomotora.entidad.ParteCoche;
import com.locomotora.entidad.VehiculoDeVia;
import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModItems;
import com.locomotora.registro.ModSonidos;
import com.locomotora.tren.Despachante;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * Lo que comparten la locomotora blindada y sus vagones: quién es de qué tren, a quién no se lastima, cómo se tira, el
 * botín de los cofres y cómo se pone un tren artillero hostil en la vía.
 */
public final class TrenArtillero {
    /** El tipo de daño de los obuses (data/locomotora/damage_type/obus.json): "fue alcanzado por un obús de...". */
    static final ResourceKey<DamageType> OBUS = ResourceKey.create(Registries.DAMAGE_TYPE, LocomotoraMod.id("obus"));
    /** Cuántos vehículos seguidos se recorren buscando la cabeza del tren (protege de círculos). */
    private static final int PROFUNDIDAD = 64;

    private TrenArtillero() {
    }

    // ================================================================= de qué tren es cada uno

    /** La locomotora blindada a la que va enganchado (directa o indirectamente) este vehículo, o null. Solo servidor. */
    @Nullable
    static ArtilleroEntity cabezaDe(Entity e) {
        Entity actual = e;
        for (int i = 0; i < PROFUNDIDAD; i++) {
            if (actual instanceof ArtilleroEntity a) {
                return a;
            }
            if (!(actual instanceof VagonEntity w)) {
                return null;
            }
            AbstractMinecart lider = w.getLider();
            if (lider == null) {
                return null;
            }
            actual = lider;
        }
        return null;
    }

    /** ¿Es un vehículo blindado del tren artillero (la locomotora o un vagón con torreta)? */
    static boolean esBlindado(Entity e) {
        return e instanceof ArtilleroEntity || e instanceof VagonArmadoEntity;
    }

    /**
     * ¿A {@code e} no lo lastiman los obuses del tren {@code tren}? Su propia locomotora y sus vagones (y quienes van en
     * ellos) y, si el tren es de alguien, su dueño y las mascotas del dueño.
     */
    static boolean protegido(Entity e, @Nullable UUID tren, @Nullable UUID dueno) {
        if (e instanceof PartEntity<?> parte) {
            e = parte.getParent();
        }
        if (dueno != null) {
            if (dueno.equals(e.getUUID())) {
                return true;
            }
            if (e instanceof OwnableEntity mascota && dueno.equals(mascota.getOwnerUUID())) {
                return true;
            }
        }
        if (tren == null) {
            return false;
        }
        Entity raiz = e.getRootVehicle();
        if (raiz != e && delTren(raiz, tren)) {
            return true;
        }
        return delTren(e, tren);
    }

    /** ¿Es {@code e} la locomotora {@code tren} o un vagón enganchado detrás de ella? */
    private static boolean delTren(Entity e, UUID tren) {
        Entity actual = e;
        for (int i = 0; i < PROFUNDIDAD && actual != null; i++) {
            if (tren.equals(actual.getUUID())) {
                return true;
            }
            if (actual instanceof VagonArmadoEntity armado && tren.equals(armado.trenMarcado())) {
                return true;
            }
            actual = actual instanceof VagonEntity w ? w.getLider() : null;
        }
        return false;
    }

    // ================================================================= tirar

    /** Dónde se apunta: al pecho de los que caminan, al medio de lo demás. */
    static Vec3 puntoDeMira(Entity e) {
        if (e instanceof PartEntity<?> parte) {
            e = parte.getParent();
        }
        return new Vec3(e.getX(), e.getY() + e.getBbHeight() * 0.6, e.getZ());
    }

    /** ¿Se ve a {@code e} desde {@code desde}? (a los ojos o al medio del cuerpo, sin bloques en el medio) */
    static boolean seVe(Level nivel, Vec3 desde, Entity e, Entity yo) {
        Vec3[] puntos = {e.getEyePosition(), e.getBoundingBox().getCenter()};
        for (Vec3 p : puntos) {
            if (nivel.clip(new ClipContext(desde, p, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, yo)).getType()
                    == HitResult.Type.MISS) {
                return true;
            }
        }
        return false;
    }

    // ================================================================= las torretas a mano

    /** Hasta dónde se busca adónde mira el tirador (bloques). */
    private static final double MIRA = 160.0;

    /**
     * Adónde mira el que maneja una torreta: lo primero que tiene delante (un bloque o algo vivo, o una aeronave), sin
     * contar los trenes (ni los que van en ellos); si no hay nada, un punto lejos en esa dirección. Se calcula igual en el
     * servidor (para tirar) y en el cliente (para girar la torreta), con el giro de la cabeza del tirador.
     */
    public static Vec3 miraDe(Player tirador) {
        Vec3 ojo = tirador.getEyePosition();
        Vec3 fin = ojo.add(tirador.getViewVector(1.0F).scale(MIRA));
        HitResult bloque = tirador.level().clip(new ClipContext(ojo, fin, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, tirador));
        if (bloque.getType() != HitResult.Type.MISS) {
            fin = bloque.getLocation();
        }
        AABB zona = new AABB(ojo, fin).inflate(1.0);
        EntityHitResult algo = ProjectileUtil.getEntityHitResult(tirador, ojo, fin, zona,
                e -> e.isPickable() && !e.isSpectator() && !(e instanceof VehiculoDeVia) && !(e instanceof ParteCoche)
                        && !(e instanceof ParteBlindada) && !(e.getVehicle() instanceof VehiculoDeVia),
                ojo.distanceToSqr(fin));
        return algo != null ? algo.getLocation() : fin;
    }

    /**
     * ¿Este jugador maneja alguna torreta (es el maquinista de un tren artillero que es de alguien, o el tirador de un
     * vagón con torreta)? Sirve en el cliente: ahí el clic izquierdo dispara en vez de pegar.
     */
    public static boolean manejaTorreta(Player jugador) {
        Entity v = jugador.getVehicle();
        if (v instanceof ArtilleroEntity a) {
            return !a.esHostil() && a.tiradorId() == jugador.getId();
        }
        return v instanceof VagonArmadoEntity w && w.tiradorId() == jugador.getId();
    }

    /**
     * El clic izquierdo de un tirador (llega del cliente): tiran las torretas que maneja, si ya recargaron. El
     * maquinista maneja la de la locomotora y las de los vagones que no tienen tirador propio.
     */
    public static void disparoManual(ServerPlayer jugador) {
        Entity v = jugador.getVehicle();
        ServerLevel nivel = jugador.serverLevel();
        boolean intento = false;
        boolean tiro = false;
        if (v instanceof ArtilleroEntity a && !a.esHostil() && a.getMaquinista() == jugador) {
            intento = true;
            tiro = a.dispararManual(nivel);
            for (VagonEntity w : a.vagones(nivel)) {
                if (w instanceof VagonArmadoEntity armado && armado.controlador() == jugador) {
                    tiro |= armado.dispararManual(nivel);
                }
            }
        } else if (v instanceof VagonArmadoEntity armado && armado.controlador() == jugador) {
            intento = true;
            tiro = armado.dispararManual(nivel);
        }
        if (intento && !tiro) {
            jugador.displayClientMessage(Component.translatable("mensaje.locomotora.recargando")
                    .withStyle(ChatFormatting.GRAY), true);
        }
    }

    /** El golpe de un obús, contado a {@code causante} (la locomotora hostil, o el dueño del tren). */
    static DamageSource fuenteObus(ServerLevel nivel, Entity obus, @Nullable Entity causante) {
        Optional<Holder.Reference<DamageType>> tipo = nivel.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolder(OBUS);
        // si faltara el tipo de daño (un paquete de datos que lo borró), el de una explosión común
        return tipo.<DamageSource>map(t -> new DamageSource(t, obus, causante))
                .orElseGet(() -> nivel.damageSources().explosion(obus, causante));
    }

    /**
     * Tira un obús con la torreta de {@code vehiculo}: el fogonazo, el humo y el estampido en la boca del caño.
     *
     * @param cabeza la locomotora del tren (quién tira, a nombre de quién y qué no se lastima)
     */
    static void disparar(ServerLevel nivel, Torreta torreta, AbstractMinecart vehiculo,
                         VehiculoDeVia v, ArtilleroEntity cabeza) {
        Vec3 boca = torreta.boca(vehiculo, v);
        Vec3 direccion = torreta.direccion(v);
        Player dueno = cabeza.getDueno();
        Entity causante = cabeza.esHostil() || dueno == null ? cabeza : dueno;
        float contraJugadores = cabeza.esHostil() ? danoSegunDificultad(nivel.getDifficulty()) : 1.0F;
        ObusEntity.tirar(nivel, torreta.medidas().tiro(), boca, direccion, vehiculo, cabeza.getUUID(),
                cabeza.duenoId(), causante, contraJugadores);
        boolean chico = torreta.medidas().rafaga() > 1;
        nivel.sendParticles(ParticleTypes.FLAME, boca.x, boca.y, boca.z, chico ? 2 : 5,
                0.08, 0.08, 0.08, 0.02);
        nivel.sendParticles(ParticleTypes.LARGE_SMOKE, boca.x, boca.y, boca.z, chico ? 2 : 6,
                0.15, 0.15, 0.15, 0.02);
        if (!chico) {
            nivel.sendParticles(ParticleTypes.EXPLOSION, boca.x, boca.y, boca.z, 1,
                    0.0, 0.0, 0.0, 0.0);
        }
        nivel.playSound(null, boca.x, boca.y, boca.z,
                chico ? ModSonidos.RAFAGA.get() : ModSonidos.CANONAZO.get(), SoundSource.HOSTILE,
                chico ? 2.5F : 4.0F, chico ? 0.7F + nivel.getRandom().nextFloat() * 0.2F : 1.5F);
    }

    /** Contra los jugadores, los tiros del tren hostil pegan según la dificultad. */
    private static float danoSegunDificultad(Difficulty dificultad) {
        return switch (dificultad) {
            case PEACEFUL -> 0.0F;
            case EASY -> 0.6F;
            case NORMAL -> 1.0F;
            case HARD -> 1.4F;
        };
    }

    // ================================================================= el botín de los cofres

    /** Llena el cofre de un vagón del tren artillero: munición y lo que llevaba. */
    static void llenarBotin(VagonEntity w, RandomSource azar) {
        List<ItemStack> cosas = new ArrayList<>();
        if (w.getTipo() == TipoVagon.CANON) {
            cosas.add(new ItemStack(Items.GUNPOWDER, 8 + azar.nextInt(17)));
            cosas.add(new ItemStack(Items.IRON_INGOT, 6 + azar.nextInt(9)));
            cosas.add(new ItemStack(Items.TNT, 1 + azar.nextInt(4)));
            cosas.add(new ItemStack(ModItems.BIDON_DIESEL.get(), 1 + azar.nextInt(3)));
            if (azar.nextInt(3) == 0) {
                cosas.add(new ItemStack(Items.DIAMOND, 1 + azar.nextInt(2)));
            }
        } else {
            cosas.add(new ItemStack(Items.ARROW, 16 + azar.nextInt(33)));
            cosas.add(new ItemStack(Items.GOLD_INGOT, 3 + azar.nextInt(7)));
            cosas.add(new ItemStack(Items.EMERALD, 1 + azar.nextInt(5)));
            cosas.add(new ItemStack(Items.DIAMOND, 1 + azar.nextInt(3)));
            cosas.add(new ItemStack(Items.COOKED_BEEF, 4 + azar.nextInt(7)));
        }
        int n = w.getContainerSize();
        for (ItemStack cosa : cosas) {
            for (int intento = 0; intento < 8; intento++) {
                int i = azar.nextInt(n);
                if (w.getItem(i).isEmpty()) {
                    w.setItem(i, cosa);
                    break;
                }
            }
        }
    }

    // ================================================================= poner un tren hostil

    /** Los vagones de un tren artillero: el cañón y el antiaéreo, y a veces un segundo cañón. */
    public static TipoVagon[] vagones(RandomSource azar) {
        return azar.nextInt(3) == 0
                ? new TipoVagon[]{TipoVagon.CANON, TipoVagon.ANTIAEREO, TipoVagon.CANON}
                : new TipoVagon[]{TipoVagon.CANON, TipoVagon.ANTIAEREO};
    }

    /**
     * Deja hostil a un tren artillero recién puesto (la locomotora y sus vagones): con su vida entera, los cofres llenos
     * y, si {@code patrulla} no es 0, andando por la vía con esa marcha cuando no está peleando.
     */
    public static void hacerHostil(LocomotoraEntity loco, List<VagonEntity> vagones, int patrulla, RandomSource azar) {
        if (!(loco instanceof ArtilleroEntity a)) {
            return;
        }
        a.hacerHostil(patrulla);
        for (VagonEntity w : vagones) {
            if (w instanceof VagonArmadoEntity armado) {
                armado.marcarTren(loco.getUUID());
            }
            llenarBotin(w, azar);
        }
    }

    /**
     * Pone un tren artillero hostil en el riel {@code pos} (para probarlo en creativo): la locomotora mirando hacia
     * {@code rumbo} y los vagones detrás, mientras haya riel. No anda solo: espera a ver a alguien.
     */
    public static boolean ponerHostil(ServerLevel nivel, BlockPos pos, double altura, float rumbo) {
        double fx = Math.cos(Math.toRadians(rumbo));
        double fz = Math.sin(Math.toRadians(rumbo));
        double x = pos.getX() + 0.5;
        double y = pos.getY() + 0.0625 + altura;
        double z = pos.getZ() + 0.5;
        LocomotoraEntity loco = ModEntidades.porTipo(TipoLocomotora.ARTILLERO).get().create(nivel);
        if (loco == null) {
            return false;
        }
        loco.moveTo(x, y, z, 0.0F, 0.0F);
        loco.setRumbo(rumbo);
        loco.ponerCombustible(LocomotoraEntity.COMBUSTIBLE_MAXIMO);
        nivel.addFreshEntity(loco);
        List<VagonEntity> puestos = new ArrayList<>();
        AbstractMinecart lider = loco;
        double largoLider = TipoLocomotora.ARTILLERO.largoAtras();
        double d = 0.0;
        for (TipoVagon tv : vagones(nivel.getRandom())) {
            d += largoLider + tv.largoFrente() + Enganches.HUECO;
            double wx = x - fx * d;
            double wz = z - fz * d;
            BlockPos riel = BlockPos.containing(wx, y, wz);
            if (!BaseRailBlock.isRail(nivel.getBlockState(riel)) && !BaseRailBlock.isRail(nivel.getBlockState(riel.below()))) {
                break; // se acabó el riel
            }
            VagonEntity w = ModEntidades.porTipo(tv).get().create(nivel);
            if (w == null) {
                break;
            }
            w.moveTo(wx, y, wz, 0.0F, 0.0F);
            w.setRumbo(rumbo);
            nivel.addFreshEntity(w);
            w.engancharA(new Enganches.Propuesta(lider, false, true, 0.0));
            puestos.add(w);
            lider = w;
            largoLider = tv.largoAtras();
        }
        hacerHostil(loco, puestos, 0, nivel.getRandom());
        nivel.playSound(null, x, y + 1.0, z, ModSonidos.BLINDAJE.get(), SoundSource.HOSTILE, 1.0F, 0.6F);
        return true;
    }

    /** Ya no es un tren que pasa solo (para que el despachante no lo haga desaparecer): la locomotora y sus vagones. */
    static void quitarMarcas(ServerLevel nivel, ArtilleroEntity loco) {
        loco.getPersistentData().remove(Despachante.MARCA);
        for (VagonEntity w : nivel.getEntitiesOfClass(VagonEntity.class, loco.getBoundingBox().inflate(64.0, 16.0, 64.0),
                w -> cabezaDe(w) == loco || (w instanceof VagonArmadoEntity a && loco.getUUID().equals(a.trenMarcado())))) {
            w.getPersistentData().remove(Despachante.MARCA);
            w.getPersistentData().remove(Despachante.TREN);
        }
    }
}
