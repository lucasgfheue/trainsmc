package com.locomotora.aereo;

import java.util.Locale;

import net.minecraft.util.RandomSource;

/**
 * Los globos aerostáticos y los zeppelines que pasan volando (medidas en bloques, del modelo del estudio de diseño).
 * <ul>
 *   <li>Globo: una sola caja de choque, de la canasta (abajo, en la posición de la entidad) a la corona.</li>
 *   <li>Zeppelin: la entidad está debajo del casco (su caja es el tramo del medio) y el casco se cubre con tramos
 *       ({@link ParteAeronave}) a lo largo del rumbo, de la nariz a la cola.</li>
 * </ul>
 * Los dos últimos son los hostiles: salen solo de noche y tiran bombas.
 */
public enum TipoAeronave {
    GLOBO_ARCOIRIS("globo_arcoiris", false, 4.0F, 14.4F, 0.08F),
    GLOBO_ROJO("globo_rojo", false, 3.62F, 15.2F, 0.08F),
    GLOBO_DAMERO("globo_damero", false, 4.25F, 13.9F, 0.08F),
    GLOBO_ATARDECER("globo_atardecer", false, 4.0F, 14.5F, 0.08F),
    GLOBO_ANTIGUO("globo_antiguo", false, 3.61F, 13.3F, 0.07F),
    ZEPPELIN_PLATEADO("zeppelin_plateado", false, 4.0F, 24.2F, 0.2F,
            new float[]{22.1F, 16.66F, 11.23F, 5.79F, 0.35F, -5.08F, -10.52F, -15.96F, -21.4F},
            new float[]{3.74F, 4.0F, 4.0F, 4.0F, 4.0F, 4.0F, 3.72F, 3.2F, 1.87F}),
    ZEPPELIN_MILITAR("zeppelin_militar", false, 3.13F, 22.7F, 0.24F,
            new float[]{20.72F, 16.64F, 12.56F, 8.49F, 4.41F, 0.33F, -3.75F, -7.82F, -11.9F, -15.98F, -20.06F},
            new float[]{2.92F, 3.13F, 3.13F, 3.13F, 3.13F, 3.13F, 3.13F, 3.1F, 2.91F, 2.23F, 1.47F}),
    ZEPPELIN_PUBLICIDAD("zeppelin_publicidad", false, 4.75F, 14.2F, 0.16F,
            new float[]{12.9F, 6.55F, 0.21F, -6.14F, -12.48F},
            new float[]{3.85F, 4.75F, 4.75F, 4.16F, 2.11F}),
    ZEPPELIN_LUJO("zeppelin_lujo", false, 4.5F, 26.2F, 0.18F,
            new float[]{23.94F, 18.05F, 12.16F, 6.27F, 0.38F, -5.51F, -11.4F, -17.29F, -23.18F},
            new float[]{4.2F, 4.5F, 4.5F, 4.5F, 4.5F, 4.5F, 4.18F, 3.6F, 2.1F}),
    ZEPPELIN_MODERNO("zeppelin_moderno", false, 3.75F, 15.2F, 0.22F,
            new float[]{13.82F, 9.28F, 4.75F, 0.22F, -4.31F, -8.84F, -13.37F},
            new float[]{3.04F, 3.75F, 3.75F, 3.75F, 3.33F, 2.68F, 1.1F}),
    GLOBO_BOMBARDERO("globo_bombardero", true, 3.88F, 14.4F, 0.1F),
    ZEPPELIN_BOMBARDERO("zeppelin_bombardero", true, 3.5F, 20.7F, 0.17F,
            new float[]{18.88F, 14.23F, 9.59F, 4.95F, 0.3F, -4.34F, -8.99F, -13.63F, -18.28F},
            new float[]{3.27F, 3.5F, 3.5F, 3.5F, 3.5F, 3.5F, 3.39F, 2.81F, 1.64F});

    /** Lo que cuelga debajo del casco de un zeppelin (las góndolas): las cajas de choque bajan esto de más. */
    public static final float GONDOLA = 1.5F;

    private static final TipoAeronave[] NORMALES = {GLOBO_ARCOIRIS, GLOBO_ROJO, GLOBO_DAMERO, GLOBO_ATARDECER,
            GLOBO_ANTIGUO, ZEPPELIN_PLATEADO, ZEPPELIN_MILITAR, ZEPPELIN_PUBLICIDAD, ZEPPELIN_LUJO, ZEPPELIN_MODERNO};

    private final String id;
    private final boolean globo;
    private final boolean hostil;
    /** Globo: radio de la envoltura. Zeppelin: radio del casco. */
    private final float radio;
    /** Globo: alto del modelo (de la canasta a la corona). Zeppelin: medio largo (de la nariz o la cola al medio). */
    private final float medida;
    /** Velocidad de crucero (bloques por tick). */
    private final float velocidad;
    /** Zeppelin: los tramos del casco (cuánto hacia la nariz, desde el medio) y el radio de cada uno. */
    private final float[] tramos;
    private final float[] radios;

    TipoAeronave(String id, boolean hostil, float radio, float alto, float velocidad) {
        this(id, true, hostil, radio, alto, velocidad, new float[0], new float[0]);
    }

    TipoAeronave(String id, boolean hostil, float radio, float medioLargo, float velocidad, float[] tramos,
                 float[] radios) {
        this(id, false, hostil, radio, medioLargo, velocidad, tramos, radios);
    }

    TipoAeronave(String id, boolean globo, boolean hostil, float radio, float medida, float velocidad, float[] tramos,
                 float[] radios) {
        this.id = id;
        this.globo = globo;
        this.hostil = hostil;
        this.radio = radio;
        this.medida = medida;
        this.velocidad = velocidad;
        this.tramos = tramos;
        this.radios = radios;
    }

    public String id() {
        return this.id;
    }

    public boolean globo() {
        return this.globo;
    }

    public boolean hostil() {
        return this.hostil;
    }

    /** 50 de vida los globos y 100 los zeppelines. */
    public float vida() {
        return this.globo ? 50.0F : 100.0F;
    }

    public float radio() {
        return this.radio;
    }

    public float velocidad() {
        return this.velocidad;
    }

    /** Ancho de la caja de choque de la entidad. */
    public float ancho() {
        return this.radio * 2.0F;
    }

    /** Alto de la caja de choque de la entidad: el globo entero, o el tramo del medio del zeppelin (con la góndola). */
    public float alto() {
        return this.globo ? this.medida : this.radio * 2.0F + GONDOLA;
    }

    /** Medio largo del zeppelin (de la nariz al medio); en un globo, su radio. */
    public float medioLargo() {
        return this.globo ? this.radio : this.medida;
    }

    /** Alto total del modelo, para saber hasta dónde dibujarlo. */
    public float altoModelo() {
        return this.globo ? this.medida : this.radio * 2.0F + GONDOLA + 4.0F;
    }

    /** Cuánto más arriba que la posición de la entidad está el origen del modelo (el eje del casco del zeppelin). */
    public float ejeY() {
        return this.globo ? 0.0F : this.radio + GONDOLA;
    }

    /** Altura del punto alrededor del que se balancea y se inclina el globo (el medio de la envoltura). */
    public float pivoteGlobo() {
        return this.medida * 0.62F;
    }

    public int cantidadTramos() {
        return this.tramos.length;
    }

    public float tramo(int i) {
        return this.tramos[i];
    }

    public float radioTramo(int i) {
        return this.radios[i];
    }

    /** Fuerza de sus bombas (como la de una explosión: la de una creeper es 3). */
    public float potenciaBomba() {
        return this.globo ? 1.5F : 2.0F;
    }

    /** Nombre de la entidad y del ítem (sin el espacio de nombres del mod). */
    public String nombreRegistro() {
        return this.id;
    }

    public static TipoAeronave normalAlAzar(RandomSource azar) {
        return NORMALES[azar.nextInt(NORMALES.length)];
    }

    public static TipoAeronave hostilAlAzar(RandomSource azar) {
        return azar.nextBoolean() ? GLOBO_BOMBARDERO : ZEPPELIN_BOMBARDERO;
    }

    public static TipoAeronave porId(String id) {
        for (TipoAeronave t : values()) {
            if (t.id.equals(id)) {
                return t;
            }
        }
        return TipoAeronave.valueOf(id.toUpperCase(Locale.ROOT));
    }
}
