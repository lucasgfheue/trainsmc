package com.locomotora.aereo;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * Un tramo del casco de un zeppelin, para que las flechas (y los golpes) le peguen en cualquier parte del casco y no
 * solo en el medio: un zeppelin mide hasta 52 bloques de largo. Lo que le pase a un tramo le pasa al zeppelin. No se
 * guarda ni se manda a los clientes: cada lado arma los suyos (sus números de entidad siguen al del zeppelin).
 */
public class ParteAeronave extends PartEntity<AeronaveEntity> {
    private final EntityDimensions medida;

    public ParteAeronave(AeronaveEntity aeronave, float ancho, float alto) {
        super(aeronave);
        this.medida = EntityDimensions.scalable(ancho, alto);
        this.refreshDimensions();
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    /** Se le puede apuntar mientras vuela (cayendo ya no: está perdido). */
    @Override
    public boolean isPickable() {
        AeronaveEntity aeronave = this.getParent();
        return !aeronave.isRemoved() && !aeronave.cayendo();
    }

    @Override
    public boolean canBeHitByProjectile() {
        return this.isPickable();
    }

    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        return !this.isInvulnerableTo(fuente) && this.getParent().hurt(fuente, cantidad);
    }

    /** No se puede subir a un zeppelin. */
    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        return InteractionResult.PASS;
    }

    @Override
    public boolean is(Entity otra) {
        return this == otra || this.getParent() == otra;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket(ServerEntity entidad) {
        throw new UnsupportedOperationException();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return this.medida;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }
}
