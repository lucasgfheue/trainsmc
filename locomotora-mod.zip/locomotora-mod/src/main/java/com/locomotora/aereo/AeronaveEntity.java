package com.locomotora.aereo;

import java.util.ArrayList;
import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModItems;
import com.locomotora.registro.ModSonidos;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.Difficulty;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * Un globo aerostático o un zeppelin que pasa volando bien alto: atraviesa los bloques (no choca con nada), no se puede
 * subir a él y, cuando lo matan (50 de vida los globos, 100 los zeppelines), explota, cae envuelto en llamas y al tocar
 * el suelo explota otra vez sin dejar nada.
 * <p>
 * Los bombarderos (hostiles) salen solo de noche y tiran bombas ({@link BombaEntity}):
 * <ul>
 *   <li>El globo va hacia un jugador solo si lo ve (nada en el medio); si no ve a nadie, sigue de largo, y si lo pierde
 *       de vista un rato, también.</li>
 *   <li>El zeppelin ve a través de los bloques: va hacia el jugador más cercano y lo bombardea en pasadas.</li>
 * </ul>
 * Con el día se retiran. No se guardan: si el mundo se cierra, ya pasaron.
 */
public class AeronaveEntity extends Entity {
    private static final EntityDataAccessor<Boolean> DATA_CAYENDO =
            SynchedEntityData.defineId(AeronaveEntity.class, EntityDataSerializers.BOOLEAN);
    /** Evento de entidad: le pegaron (el cliente la pinta de rojo un momento). */
    private static final byte GOLPE = 60;

    /** Después de esto (ticks) se retira, y si queda lejos de todos, se va. */
    private static final int VIDA_MAXIMA = 20 * 60 * 6;
    /** Más lejos que esto de todos los jugadores (en horizontal), se va. */
    private static final double LEJOS = 200.0;
    /** Hasta dónde ve el globo bombardero (con la vista: nada en el medio). */
    private static final double VISTA_GLOBO = 64.0;
    /** Hasta dónde encuentra a alguien el zeppelin bombardero (a través de los bloques). */
    private static final double ALCANCE_ZEPPELIN = 96.0;
    /** Si el globo no ve a su blanco por tanto tiempo (ticks), sigue de largo. */
    private static final int OLVIDO = 200;

    private final TipoAeronave tipo;
    @Nullable
    private final ParteAeronave[] partes;
    /** La barra de vida de los bombarderos (a los que están cerca). */
    @Nullable
    private final ServerBossEvent barra;

    private float vida;
    /** A qué altura vuela (la de la posición de la entidad). */
    private double alturaCrucero = Double.NaN;
    private int sueloAdelante = Integer.MIN_VALUE;
    /** Los que pone el despachante salen solo de noche y se retiran con el día; los de un ítem, no. */
    private boolean soloDeNoche;
    // ------------------------------------------------- bombardero
    @Nullable
    private UUID blancoId;
    @Nullable
    private UUID avisado;
    private int sinVerlo;
    private int recarga;
    private int rafaga;
    private int entreBombas;
    private double blancoX = Double.NaN;
    private double blancoZ = Double.NaN;
    private double blancoVx;
    private double blancoVz;
    private boolean retirada;
    // ------------------------------------------------- cayendo
    private int caida;
    private int esperaSonido = 20;

    // ------------------------------------------------- cliente
    private int lerpPasos;
    private double lerpX;
    private double lerpY;
    private double lerpZ;
    private float lerpYRot;
    private float lerpXRot;
    private int golpe;
    private int caidaCliente;

    public AeronaveEntity(EntityType<? extends AeronaveEntity> tipoEntidad, Level level, TipoAeronave tipo) {
        super(tipoEntidad, level);
        this.tipo = tipo;
        this.noPhysics = true;
        this.setNoGravity(true);
        this.vida = tipo.vida();
        if (tipo.globo()) {
            this.partes = null;
        } else {
            // los tramos se crean justo después de la aeronave: sus números de entidad quedan seguidos al de ella
            int n = tipo.cantidadTramos();
            this.partes = new ParteAeronave[n];
            for (int i = 0; i < n; i++) {
                float r = tipo.radioTramo(i);
                this.partes[i] = new ParteAeronave(this, r * 2.0F, r * 2.0F + TipoAeronave.GONDOLA);
            }
        }
        this.barra = tipo.hostil()
                ? new ServerBossEvent(Component.translatable("entity.locomotora." + tipo.id()),
                        BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10)
                : null;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_CAYENDO, false);
    }

    public TipoAeronave getTipo() {
        return this.tipo;
    }

    /** ¿Ya la derribaron? (cae envuelta en llamas) */
    public boolean cayendo() {
        return this.entityData.get(DATA_CAYENDO);
    }

    /** Para el cliente: le acaban de pegar. */
    public boolean golpeada() {
        return this.golpe > 0;
    }

    /** Para el cliente: cuánto hace que viene cayendo (ticks). */
    public int ticksCayendo() {
        return this.caidaCliente;
    }

    /** Pone la altura de vuelo (y si sale solo de noche, como las que manda el despachante). */
    public void preparar(double altura, boolean soloDeNoche) {
        this.alturaCrucero = altura;
        this.soloDeNoche = soloDeNoche;
    }

    // ================================================================= aparecer

    /**
     * Para probarla (el ítem del modo creativo): sale delante del jugador hacia donde mira, sube un poco y se va como
     * cualquier otra. Un bombardero que sale así ataca también de día (si el jugador no está en creativo).
     */
    public static AeronaveEntity soltarDelante(ServerLevel nivel, TipoAeronave tipo, Player jugador) {
        float rumbo = jugador.getYRot();
        double hx = -Math.sin(Math.toRadians(rumbo));
        double hz = Math.cos(Math.toRadians(rumbo));
        double adelante = tipo.globo() ? 9.0 : tipo.medioLargo() + 6.0;
        double x = jugador.getX() + hx * adelante;
        double z = jugador.getZ() + hz * adelante;
        double y = jugador.getY() + (tipo.globo() ? 2.0 : 6.0);
        AeronaveEntity a = new AeronaveEntity(ModEntidades.porTipo(tipo).get(), nivel, tipo);
        a.moveTo(x, y, z, rumbo, 0.0F);
        a.preparar(y + (tipo.globo() ? 14.0 : 12.0), false);
        nivel.addFreshEntity(a);
        DespachanteAereo.registrar(a);
        return a;
    }

    // ================================================================= tick

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) {
            tickCliente();
            moverPartes();
            return;
        }
        ServerLevel nivel = (ServerLevel) this.level();
        if (Double.isNaN(this.alturaCrucero)) {
            this.alturaCrucero = this.getY();
        }
        if (this.tipo.hostil() && nivel.getDifficulty() == Difficulty.PEACEFUL) {
            this.discard();
            return;
        }
        if (cayendo()) {
            caer(nivel);
        } else {
            if (this.tipo.hostil()) {
                pensar(nivel);
                if (this.tickCount % 10 == 0) {
                    actualizarBarra(nivel);
                }
            }
            volar(nivel);
            sonar(nivel);
            if (this.tickCount % 20 == 0 && debeIrse(nivel)) {
                this.discard();
                return;
            }
        }
        moverPartes();
    }

    private void tickCliente() {
        if (this.lerpPasos > 0) {
            double f = 1.0 / this.lerpPasos;
            double x = this.getX() + (this.lerpX - this.getX()) * f;
            double y = this.getY() + (this.lerpY - this.getY()) * f;
            double z = this.getZ() + (this.lerpZ - this.getZ()) * f;
            float rumbo = Mth.rotLerp((float) f, this.getYRot(), this.lerpYRot);
            float cabeceo = this.getXRot() + (this.lerpXRot - this.getXRot()) * (float) f;
            this.lerpPasos--;
            this.setPos(x, y, z);
            this.setRot(rumbo, cabeceo);
        }
        if (this.golpe > 0) {
            this.golpe--;
        }
        if (cayendo()) {
            this.caidaCliente++;
            // llamas y humo por todo el casco (se ven de lejos)
            int n = this.tipo.globo() ? 2 : 4;
            for (int i = 0; i < n; i++) {
                Vec3 p = puntoAlAzar();
                this.level().addAlwaysVisibleParticle(ParticleTypes.FLAME, p.x, p.y, p.z,
                        (this.random.nextDouble() - 0.5) * 0.06, 0.04, (this.random.nextDouble() - 0.5) * 0.06);
                if (this.random.nextInt(3) != 0) {
                    this.level().addAlwaysVisibleParticle(ParticleTypes.LARGE_SMOKE, p.x, p.y + 0.6, p.z,
                            0.0, 0.07, 0.0);
                }
            }
        }
    }

    /** Un punto cualquiera de la tela (para las llamas cuando cae). */
    private Vec3 puntoAlAzar() {
        if (this.tipo.globo()) {
            double a = this.random.nextDouble() * Math.PI * 2.0;
            double r = this.tipo.radio() * (0.6 + this.random.nextDouble() * 0.4);
            double y = this.getY() + this.tipo.pivoteGlobo() + (this.random.nextDouble() - 0.3) * this.tipo.radio() * 1.6;
            return new Vec3(this.getX() + Math.cos(a) * r, y, this.getZ() + Math.sin(a) * r);
        }
        double s = (this.random.nextDouble() * 2.0 - 1.0) * this.tipo.medioLargo() * 0.9;
        double a = this.random.nextDouble() * Math.PI * 2.0;
        double r = this.tipo.radio() * 0.9;
        return puntoDelCasco(s, Math.cos(a) * r, Math.sin(a) * r);
    }

    /** Un punto del zeppelin: tanto hacia la nariz (sobre el eje), tanto hacia arriba y tanto hacia la derecha. */
    private Vec3 puntoDelCasco(double adelante, double arriba, double derecha) {
        double rumbo = Math.toRadians(this.getYRot());
        double cabeceo = Math.toRadians(this.getXRot());
        double hx = -Math.sin(rumbo);
        double hz = Math.cos(rumbo);
        double cp = Math.cos(cabeceo);
        double sp = Math.sin(cabeceo);
        // adelante (con la nariz para abajo si cabecea), arriba (perpendicular) y a la derecha (horizontal)
        double ax = hx * cp;
        double ay = -sp;
        double az = hz * cp;
        double ux = hx * sp;
        double uy = cp;
        double uz = hz * sp;
        double rx = -hz;
        double rz = hx;
        return new Vec3(this.getX() + ax * adelante + ux * arriba + rx * derecha,
                this.getY() + this.tipo.ejeY() + ay * adelante + uy * arriba,
                this.getZ() + az * adelante + uz * arriba + rz * derecha);
    }

    /** El medio de la aeronave (la envoltura del globo, el eje del casco del zeppelin). */
    private Vec3 centro() {
        return new Vec3(this.getX(), this.getY() + (this.tipo.globo() ? this.tipo.pivoteGlobo() : this.tipo.ejeY()),
                this.getZ());
    }

    // ================================================================= volar

    private void volar(ServerLevel nivel) {
        float rumbo = this.getYRot();
        double alturaObjetivo = this.alturaCrucero;
        float velocidad = this.tipo.velocidad();
        Player blanco = this.tipo.hostil() ? blancoValido(nivel) : null;
        if (blanco != null) {
            // hacia el blanco, girando de a poco (el zeppelin, más despacio)
            double dx = blanco.getX() - this.getX();
            double dz = blanco.getZ() - this.getZ();
            float hacia = (float) Math.toDegrees(Math.atan2(-dx, dz));
            float giroMaximo = this.tipo.globo() ? 2.5F : 1.4F;
            rumbo += Mth.clamp(Mth.wrapDegrees(hacia - rumbo), -giroMaximo, giroMaximo);
            alturaObjetivo = blanco.getY() + (this.tipo.globo() ? 19.0 : 21.0);
            velocidad = this.tipo.globo() ? 0.13F : 0.21F;
        }
        double fx = -Math.sin(Math.toRadians(rumbo));
        double fz = Math.cos(Math.toRadians(rumbo));
        // por encima de las montañas que tiene adelante
        if (this.tickCount % 10 == 0 || this.sueloAdelante == Integer.MIN_VALUE) {
            int alto = Integer.MIN_VALUE;
            for (int k = 0; k <= 3; k++) {
                double ax = this.getX() + fx * k * 10.0;
                double az = this.getZ() + fz * k * 10.0;
                alto = Math.max(alto, nivel.getHeight(Heightmap.Types.MOTION_BLOCKING, Mth.floor(ax), Mth.floor(az)));
            }
            this.sueloAdelante = alto;
        }
        double margen = this.tipo.globo() ? 12.0 : 10.0;
        if (this.sueloAdelante + margen > alturaObjetivo) {
            alturaObjetivo = this.sueloAdelante + margen;
            if (blanco == null) {
                this.alturaCrucero = Math.max(this.alturaCrucero, alturaObjetivo);
            }
        }
        double vy = Mth.clamp((alturaObjetivo - this.getY()) * 0.03, -0.08, 0.08);
        Vec3 v = new Vec3(fx * velocidad, vy, fz * velocidad);
        this.setYRot(rumbo);
        this.setDeltaMovement(v);
        this.setPos(this.getX() + v.x, this.getY() + v.y, this.getZ() + v.z);
    }

    /** El quemador del globo (cada tanto) y el zumbido de los motores del zeppelin (siempre). */
    private void sonar(ServerLevel nivel) {
        if (--this.esperaSonido > 0) {
            return;
        }
        if (this.tipo.globo()) {
            nivel.playSound(null, this.getX(), this.getY() + 2.5, this.getZ(), ModSonidos.QUEMADOR.get(),
                    SoundSource.NEUTRAL, 3.0F, 0.8F + this.random.nextFloat() * 0.25F);
            this.esperaSonido = 90 + this.random.nextInt(120);
        } else {
            nivel.playSound(null, this.getX(), this.getY() + this.tipo.ejeY(), this.getZ(),
                    ModSonidos.MOTOR_ZEPPELIN.get(), SoundSource.NEUTRAL, 4.0F, 0.52F + this.random.nextFloat() * 0.06F);
            this.esperaSonido = 36;
        }
    }

    private boolean debeIrse(ServerLevel nivel) {
        double cerca = DespachanteAereo.distanciaAlMasCercano(nivel, this);
        return cerca > LEJOS || (this.tickCount > VIDA_MAXIMA && cerca > 120.0) || this.tickCount > VIDA_MAXIMA * 2;
    }

    // ================================================================= el bombardero

    private static boolean esDeNoche(Level nivel) {
        long hora = nivel.getDayTime() % 24000L;
        return hora >= 13000L && hora < 23000L;
    }

    private void pensar(ServerLevel nivel) {
        if (!this.retirada && ((this.soloDeNoche && !esDeNoche(nivel)) || this.tickCount > VIDA_MAXIMA)) {
            // se hizo de día (o ya anduvo mucho): se va
            this.retirada = true;
            this.blancoId = null;
        }
        if (this.retirada) {
            return;
        }
        Player blanco = blancoValido(nivel);
        if (this.tickCount % 10 == 0) {
            if (this.tipo.globo()) {
                // el globo solo va hacia alguien que ve; si lo pierde de vista un rato, sigue de largo
                if (blanco != null) {
                    if (seVe(nivel, blanco)) {
                        this.sinVerlo = 0;
                    } else if ((this.sinVerlo += 10) > OLVIDO) {
                        this.blancoId = null;
                        blanco = null;
                    }
                }
                if (blanco == null) {
                    blanco = buscar(nivel, true);
                    if (blanco != null) {
                        empezar(nivel, blanco);
                    }
                }
            } else if (blanco == null) {
                // el zeppelin lo encuentra a través de los bloques
                blanco = buscar(nivel, false);
                if (blanco != null) {
                    empezar(nivel, blanco);
                }
            }
        }
        if (blanco == null) {
            this.blancoX = Double.NaN;
            return;
        }
        // hacia dónde se mueve el blanco (para tirarle adelante)
        if (!Double.isNaN(this.blancoX)) {
            this.blancoVx = this.blancoVx * 0.7 + (blanco.getX() - this.blancoX) * 0.3;
            this.blancoVz = this.blancoVz * 0.7 + (blanco.getZ() - this.blancoZ) * 0.3;
        }
        this.blancoX = blanco.getX();
        this.blancoZ = blanco.getZ();
        bombardear(nivel, blanco);
    }

    private static boolean atacable(Player p) {
        return p.isAlive() && !p.isSpectator() && !p.isCreative();
    }

    private double alcance() {
        return this.tipo.globo() ? VISTA_GLOBO : ALCANCE_ZEPPELIN;
    }

    @Nullable
    private Player blancoValido(ServerLevel nivel) {
        if (this.blancoId == null) {
            return null;
        }
        Player p = nivel.getPlayerByUUID(this.blancoId);
        double lejos = alcance() * 1.4;
        if (p == null || !atacable(p) || p.distanceToSqr(this) > lejos * lejos) {
            this.blancoId = null;
            return null;
        }
        return p;
    }

    /** El jugador más cercano al que puede atacar (el globo, solo si lo ve). */
    @Nullable
    private Player buscar(ServerLevel nivel, boolean conVista) {
        Player mejor = null;
        double mejorD = alcance() * alcance();
        for (ServerPlayer p : nivel.players()) {
            if (!atacable(p)) {
                continue;
            }
            double d = p.distanceToSqr(this);
            if (d < mejorD && (!conVista || seVe(nivel, p))) {
                mejor = p;
                mejorD = d;
            }
        }
        return mejor;
    }

    /** ¿Desde la canasta se le ven los ojos al jugador? (nada sólido en el medio) */
    private boolean seVe(ServerLevel nivel, Player p) {
        Vec3 desde = new Vec3(this.getX(), this.getY() + 0.6, this.getZ());
        Vec3 hasta = p.getEyePosition();
        if (desde.distanceToSqr(hasta) > VISTA_GLOBO * VISTA_GLOBO) {
            return false;
        }
        return nivel.clip(new ClipContext(desde, hasta, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this))
                .getType() == HitResult.Type.MISS;
    }

    /** Lo vio: va hacia él (la primera vez suena la alarma y se le avisa). */
    private void empezar(ServerLevel nivel, Player p) {
        this.blancoId = p.getUUID();
        this.sinVerlo = 0;
        this.blancoX = Double.NaN;
        if (!p.getUUID().equals(this.avisado)) {
            this.avisado = p.getUUID();
            nivel.playSound(null, this.getX(), this.getY(), this.getZ(), ModSonidos.ALARMA_AEREA.get(),
                    SoundSource.HOSTILE, 8.0F, this.tipo.globo() ? 1.15F : 0.9F);
            p.displayClientMessage(Component.translatable(this.tipo.globo()
                    ? "mensaje.locomotora.globo_bombardero_te_vio"
                    : "mensaje.locomotora.zeppelin_bombardero_te_vio").withStyle(ChatFormatting.RED), true);
        }
    }

    /** Suelta una bomba (el zeppelin, una tanda de tres) cuando caería cerca del blanco. */
    private void bombardear(ServerLevel nivel, Player blanco) {
        if (this.rafaga > 0) {
            if (--this.entreBombas <= 0) {
                soltarBomba(nivel);
                this.rafaga--;
                this.entreBombas = 6;
            }
            return;
        }
        if (this.recarga > 0) {
            this.recarga--;
            return;
        }
        if (!apuntado(blanco)) {
            return;
        }
        soltarBomba(nivel);
        if (this.tipo.globo()) {
            this.recarga = 50;
        } else {
            this.rafaga = 2;
            this.entreBombas = 6;
            this.recarga = 80;
        }
    }

    /** Dónde sale la bomba: abajo de la canasta del globo, o de la bodega del zeppelin (abajo del medio del casco). */
    private Vec3 puntoDeSuelta() {
        if (this.tipo.globo()) {
            return new Vec3(this.getX(), this.getY() - 0.5, this.getZ());
        }
        return new Vec3(this.getX(), this.getY() + this.tipo.ejeY() - this.tipo.radio() - 0.6, this.getZ());
    }

    /**
     * ¿Una bomba soltada ahora caería cerca del blanco? Se sigue su vuelo como lo hace el juego (cada tick avanza, se
     * frena un 1 % y cae 0,03 más rápido), sale con la velocidad de la aeronave y el blanco sigue moviéndose.
     */
    private boolean apuntado(Player blanco) {
        Vec3 s = puntoDeSuelta();
        Vec3 v = this.getDeltaMovement();
        double x = s.x;
        double y = s.y;
        double z = s.z;
        double vx = v.x;
        double vy = -0.05;
        double vz = v.z;
        int t = 0;
        while (y > blanco.getY() && t < 200) {
            x += vx;
            y += vy;
            z += vz;
            vx *= 0.99;
            vy = vy * 0.99 - 0.03;
            vz *= 0.99;
            t++;
        }
        double px = blanco.getX() + this.blancoVx * t * 0.7;
        double pz = blanco.getZ() + this.blancoVz * t * 0.7;
        double tolerancia = this.tipo.globo() ? 3.0 : 4.5;
        return (x - px) * (x - px) + (z - pz) * (z - pz) < tolerancia * tolerancia;
    }

    private void soltarBomba(ServerLevel nivel) {
        Vec3 s = puntoDeSuelta();
        Vec3 v = this.getDeltaMovement();
        double disperso = this.tipo.globo() ? 0.012 : 0.02;
        Vec3 velocidad = new Vec3(v.x + this.random.nextGaussian() * disperso, -0.05,
                v.z + this.random.nextGaussian() * disperso);
        BombaEntity.soltar(nivel, this, s, velocidad, this.tipo.potenciaBomba());
        nivel.playSound(null, s.x, s.y, s.z, ModSonidos.BOMBA.get(), SoundSource.HOSTILE, 3.0F,
                0.9F + this.random.nextFloat() * 0.2F);
    }

    /** La barra de vida del bombardero, a los que están cerca. */
    private void actualizarBarra(ServerLevel nivel) {
        if (this.barra == null) {
            return;
        }
        this.barra.setProgress(Mth.clamp(this.vida / this.tipo.vida(), 0.0F, 1.0F));
        for (ServerPlayer j : new ArrayList<>(this.barra.getPlayers())) {
            if (j.level() != nivel || j.distanceToSqr(this) > 96.0 * 96.0) {
                this.barra.removePlayer(j);
            }
        }
        for (ServerPlayer j : nivel.players()) {
            if (!j.isSpectator() && j.distanceToSqr(this) < 80.0 * 80.0) {
                this.barra.addPlayer(j);
            }
        }
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer jugador) {
        super.stopSeenByPlayer(jugador);
        if (this.barra != null) {
            this.barra.removePlayer(jugador);
        }
    }

    // ================================================================= golpes, caída y explosiones

    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (this.level().isClientSide() || this.isRemoved() || cayendo() || this.isInvulnerableTo(fuente)) {
            return false;
        }
        // sus propias bombas y explosiones no le hacen nada
        if (fuente.getEntity() == this || fuente.getDirectEntity() == this
                || (fuente.getDirectEntity() instanceof BombaEntity b && b.getOwner() == this)) {
            return false;
        }
        ServerLevel nivel = (ServerLevel) this.level();
        this.vida -= cantidad;
        this.level().broadcastEntityEvent(this, GOLPE);
        Vec3 c = centro();
        nivel.playSound(null, c.x, c.y, c.z, ModSonidos.AERONAVE_GOLPE.get(), SoundSource.NEUTRAL, 2.5F,
                0.8F + this.random.nextFloat() * 0.3F);
        if (this.barra != null) {
            this.barra.setProgress(Mth.clamp(this.vida / this.tipo.vida(), 0.0F, 1.0F));
        }
        if (this.vida <= 0.0F) {
            morir(nivel, fuente);
        }
        return true;
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == GOLPE) {
            this.golpe = 8;
        } else {
            super.handleEntityEvent(id);
        }
    }

    /** Explota en el aire y empieza a caer envuelta en llamas. */
    private void morir(ServerLevel nivel, DamageSource fuente) {
        this.vida = 0.0F;
        this.entityData.set(DATA_CAYENDO, true);
        this.caida = 0;
        this.blancoId = null;
        if (this.barra != null) {
            this.barra.removeAllPlayers();
        }
        Vec3 c = centro();
        nivel.explode(this, c.x, c.y, c.z, this.tipo.globo() ? 2.0F : 3.0F, Level.ExplosionInteraction.NONE);
        if (!this.tipo.globo()) {
            // en un zeppelin largo explota más de un lugar
            for (double s : new double[]{this.tipo.medioLargo() * 0.5, -this.tipo.medioLargo() * 0.5}) {
                Vec3 p = puntoDelCasco(s, 0.0, 0.0);
                nivel.sendParticles(ParticleTypes.EXPLOSION_EMITTER, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
            }
        }
        if (this.tipo.hostil() && fuente.getEntity() instanceof ServerPlayer jugador) {
            jugador.displayClientMessage(Component.translatable("mensaje.locomotora.bombardero_derribado",
                    this.getDisplayName()).withStyle(ChatFormatting.GOLD), true);
        }
        this.setDeltaMovement(this.getDeltaMovement().multiply(0.7, 0.0, 0.7));
    }

    private void caer(ServerLevel nivel) {
        this.caida++;
        Vec3 v = this.getDeltaMovement();
        double vy = Math.max(v.y - 0.03, this.tipo.globo() ? -0.9 : -1.1);
        v = new Vec3(v.x * 0.985, vy, v.z * 0.985);
        this.setDeltaMovement(v);
        this.setPos(this.getX() + v.x, this.getY() + v.y, this.getZ() + v.z);
        // el zeppelin cae de nariz; el globo, de costado
        float maximo = this.tipo.globo() ? 28.0F : 38.0F;
        this.setXRot(Math.min(maximo, this.getXRot() + (this.tipo.globo() ? 0.7F : 0.9F)));
        if (this.caida % 12 == 0) {
            Vec3 c = centro();
            nivel.playSound(null, c.x, c.y, c.z, ModSonidos.AERONAVE_FUEGO.get(), SoundSource.NEUTRAL, 3.0F,
                    0.7F + this.random.nextFloat() * 0.3F);
        }
        Vec3 bajo = puntoMasBajo();
        int suelo = nivel.getHeight(Heightmap.Types.MOTION_BLOCKING, Mth.floor(bajo.x), Mth.floor(bajo.z));
        if (bajo.y <= suelo + 0.2 || this.caida > 20 * 45) {
            estrellarse(nivel, new Vec3(bajo.x, Math.max(bajo.y, suelo), bajo.z));
        }
    }

    /** Lo primero que toca el suelo: la canasta del globo, o la nariz (o la góndola) del zeppelin. */
    private Vec3 puntoMasBajo() {
        if (this.tipo.globo()) {
            return new Vec3(this.getX(), this.getY() - 0.3, this.getZ());
        }
        Vec3 nariz = puntoDelCasco(this.tipo.medioLargo() * 0.95, -this.tipo.radio() * 0.5, 0.0);
        Vec3 gondola = new Vec3(this.getX(), this.getY(), this.getZ());
        return nariz.y < gondola.y ? nariz : gondola;
    }

    /** Toca el suelo: explota otra vez (lastima a los que estén cerca, sin romper bloques) y no queda nada. */
    private void estrellarse(ServerLevel nivel, Vec3 punto) {
        nivel.explode(this, punto.x, punto.y + 0.5, punto.z, this.tipo.globo() ? 2.5F : 4.0F,
                Level.ExplosionInteraction.NONE);
        if (this.partes != null) {
            for (int i = 0; i < this.partes.length; i += 2) {
                ParteAeronave p = this.partes[i];
                double y = Math.max(p.getY(), punto.y);
                nivel.sendParticles(ParticleTypes.EXPLOSION_EMITTER, p.getX(), y + 0.5, p.getZ(), 1, 0.0, 0.0, 0.0, 0.0);
                nivel.sendParticles(ParticleTypes.LARGE_SMOKE, p.getX(), y + 1.0, p.getZ(), 12, 1.5, 0.8, 1.5, 0.04);
                nivel.sendParticles(ParticleTypes.FLAME, p.getX(), y + 0.5, p.getZ(), 10, 1.5, 0.5, 1.5, 0.03);
            }
        } else {
            nivel.sendParticles(ParticleTypes.LARGE_SMOKE, punto.x, punto.y + 1.0, punto.z, 20, 1.5, 1.0, 1.5, 0.04);
            nivel.sendParticles(ParticleTypes.FLAME, punto.x, punto.y + 0.5, punto.z, 16, 1.2, 0.4, 1.2, 0.03);
        }
        this.discard();
    }

    // ================================================================= tramos del casco

    /** Los tramos acompañan al zeppelin (también en el cliente, para poder apuntarle), con la nariz baja si cae. */
    private void moverPartes() {
        if (this.partes == null) {
            return;
        }
        for (int i = 0; i < this.partes.length; i++) {
            ParteAeronave p = this.partes[i];
            Vec3 c = puntoDelCasco(this.tipo.tramo(i), 0.0, 0.0);
            p.xo = p.getX();
            p.yo = p.getY();
            p.zo = p.getZ();
            p.xOld = p.xo;
            p.yOld = p.yo;
            p.zOld = p.zo;
            p.setPos(c.x, c.y - this.tipo.radioTramo(i) - TipoAeronave.GONDOLA, c.z);
        }
    }

    @Override
    public boolean isMultipartEntity() {
        return this.partes != null;
    }

    @Override
    public PartEntity<?>[] getParts() {
        return this.partes;
    }

    /** En el cliente los tramos toman los números de entidad que tienen en el servidor (los que siguen al suyo). */
    @Override
    public void recreateFromPacket(ClientboundAddEntityPacket paquete) {
        super.recreateFromPacket(paquete);
        if (this.partes != null) {
            for (int i = 0; i < this.partes.length; i++) {
                this.partes[i].setId(paquete.getId() + 1 + i);
            }
        }
    }

    // ================================================================= en el cliente: moverse suave y dibujarse lejos

    /** Las posiciones que llegan del servidor se siguen de a poco (si no, avanzaría a saltos). */
    @Override
    public void lerpTo(double x, double y, double z, float rumbo, float cabeceo, int pasos) {
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYRot = rumbo;
        this.lerpXRot = cabeceo;
        this.lerpPasos = Math.max(1, pasos);
    }

    @Override
    public AABB getBoundingBoxForCulling() {
        double l = this.tipo.medioLargo() + 2.0;
        double abajo = cayendo() ? l : 2.0;
        return new AABB(this.getX() - l, this.getY() - abajo, this.getZ() - l,
                this.getX() + l, this.getY() + this.tipo.altoModelo() + 2.0, this.getZ() + l);
    }

    /** Se ve de lejos (vuela alto y es grande). */
    @Override
    public boolean shouldRenderAtSqrDistance(double distancia) {
        double r = 320.0 * getViewScale();
        return distancia < r * r;
    }

    // ================================================================= no choca, no se empuja, nadie se sube

    @Override
    public boolean isPickable() {
        return !this.isRemoved() && !cayendo();
    }

    @Override
    public boolean canBeHitByProjectile() {
        return this.isPickable();
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean canBeCollidedWith() {
        return false;
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    @Override
    protected boolean canAddPassenger(Entity pasajero) {
        return false;
    }

    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        return InteractionResult.PASS;
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(ModItems.porTipo(this.tipo).get());
    }

    // ================================================================= quitarla y guardado (no se guarda)

    @Override
    public void remove(Entity.RemovalReason motivo) {
        if (this.barra != null) {
            this.barra.removeAllPlayers();
        }
        super.remove(motivo);
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("Vida")) {
            this.vida = Mth.clamp(tag.getFloat("Vida"), 1.0F, this.tipo.vida());
        }
        if (tag.contains("Altura")) {
            this.alturaCrucero = tag.getDouble("Altura");
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putFloat("Vida", this.vida);
        if (!Double.isNaN(this.alturaCrucero)) {
            tag.putDouble("Altura", this.alturaCrucero);
        }
    }
}
