package com.locomotora.aereo;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModReglas;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/**
 * Los globos y zeppelines que pasan solos: cada tantos minutos (regla {@code locomotoraMinutosAeronave}, 5 de fábrica)
 * a cada jugador que esté al aire libre le pasa uno por al lado, bien alto, de un lado del cielo al otro. Aparece a
 * unos 100 bloques, pasa a 18-36 bloques de costado y se va. De noche, a veces (regla
 * {@code locomotoraAeronavesHostiles}, nunca en pacífico) el que viene es un bombardero, derecho hacia el jugador.
 * Los que quedan lejos de todos se quitan (aunque estén donde el mundo no se mueve).
 */
public final class DespachanteAereo {
    /** Las aeronaves que andan por ahí (para quitarlas cuando quedan lejos de todos). */
    private static final Set<UUID> ACTIVAS = new HashSet<>();
    private static final Map<UUID, Long> ULTIMO = new HashMap<>();
    /** Más lejos que esto de todos los jugadores, una aeronave se quita aunque no se esté moviendo. */
    private static final double LEJOS = 176.0;

    private DespachanteAereo() {
    }

    public static void alTick(LevelTickEvent.Post evento) {
        if (!(evento.getLevel() instanceof ServerLevel nivel) || nivel.dimension() != Level.OVERWORLD) {
            return;
        }
        long ahora = nivel.getGameTime();
        if (ahora % 20L != 11L) {
            return;
        }
        administrar(nivel);
        if (!ModReglas.aeronaves(nivel.getGameRules())) {
            return;
        }
        long espera = 20L * 60L * Math.max(1, ModReglas.minutosAeronave(nivel.getGameRules()));
        for (ServerPlayer jugador : nivel.players()) {
            if (jugador.isSpectator()) {
                continue;
            }
            // la primera, a la mitad de la espera (así no viene justo con el primer tren); si se abrió otro mundo con
            // la hora más atrás, se vuelve a contar desde ahora
            long ultimo = ULTIMO.computeIfAbsent(jugador.getUUID(), k -> ahora - espera / 2L);
            if (ultimo > ahora) {
                ultimo = ahora - espera / 2L;
                ULTIMO.put(jugador.getUUID(), ultimo);
            }
            if (ahora - ultimo < espera || bajoTierra(nivel, jugador) || hayUnaCerca(nivel, jugador)) {
                continue;
            }
            if (lanzar(nivel, jugador)) {
                ULTIMO.put(jugador.getUUID(), ahora);
            }
        }
    }

    public static void registrar(AeronaveEntity aeronave) {
        ACTIVAS.add(aeronave.getUUID());
    }

    /** Distancia (en horizontal) al jugador más cercano que no sea espectador. */
    public static double distanciaAlMasCercano(ServerLevel nivel, Entity e) {
        double mejor = Double.MAX_VALUE;
        for (ServerPlayer j : nivel.players()) {
            if (j.isSpectator()) {
                continue;
            }
            double dx = j.getX() - e.getX();
            double dz = j.getZ() - e.getZ();
            mejor = Math.min(mejor, Math.sqrt(dx * dx + dz * dz));
        }
        return mejor;
    }

    /**
     * Quita las que quedaron lejos de todos o donde el mundo ya no se mueve (ahí quedarían quietas en el cielo, y
     * solas no se quitan).
     */
    private static void administrar(ServerLevel nivel) {
        Iterator<UUID> it = ACTIVAS.iterator();
        while (it.hasNext()) {
            Entity e = nivel.getEntity(it.next());
            if (!(e instanceof AeronaveEntity) || e.isRemoved()) {
                it.remove();
            } else if (distanciaAlMasCercano(nivel, e) > LEJOS || !nivel.isPositionEntityTicking(e.blockPosition())) {
                e.discard();
                it.remove();
            }
        }
    }

    /** En una cueva no la vería: se espera a que salga. */
    private static boolean bajoTierra(ServerLevel nivel, ServerPlayer jugador) {
        int superficie = nivel.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(jugador.getX()),
                Mth.floor(jugador.getZ()));
        return jugador.getY() < superficie - 12;
    }

    private static boolean hayUnaCerca(ServerLevel nivel, ServerPlayer jugador) {
        for (UUID id : ACTIVAS) {
            Entity e = nivel.getEntity(id);
            if (e instanceof AeronaveEntity a && !a.isRemoved()) {
                double dx = a.getX() - jugador.getX();
                double dz = a.getZ() - jugador.getZ();
                if (dx * dx + dz * dz < 150.0 * 150.0) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean esDeNoche(ServerLevel nivel) {
        long hora = nivel.getDayTime() % 24000L;
        return hora >= 13000L && hora < 23000L;
    }

    /** Le manda una al jugador: de noche, a veces, un bombardero. */
    private static boolean lanzar(ServerLevel nivel, ServerPlayer jugador) {
        RandomSource azar = nivel.getRandom();
        boolean hostil = esDeNoche(nivel) && ModReglas.aeronavesHostiles(nivel.getGameRules())
                && nivel.getDifficulty() != Difficulty.PEACEFUL && azar.nextBoolean();
        TipoAeronave tipo = hostil ? TipoAeronave.hostilAlAzar(azar) : TipoAeronave.normalAlAzar(azar);
        return aparecer(nivel, tipo, jugador, azar) != null;
    }

    /**
     * Una aeronave que viene de lejos y pasa por al lado del jugador (el bombardero, casi por encima). Se busca un lugar
     * donde el mundo se mueva (si está lejos, quedaría quieta). Devuelve null si no encontró dónde.
     */
    @Nullable
    public static AeronaveEntity aparecer(ServerLevel nivel, TipoAeronave tipo, ServerPlayer jugador,
                                          RandomSource azar) {
        double angulo = azar.nextDouble() * Math.PI * 2.0;
        double hx = Math.cos(angulo);
        double hz = Math.sin(angulo);
        double costado = (azar.nextBoolean() ? 1.0 : -1.0)
                * (tipo.hostil() ? azar.nextDouble() * 8.0 : 18.0 + azar.nextDouble() * 18.0);
        float rumbo = (float) Math.toDegrees(Math.atan2(-hx, hz));
        for (double atras = 104.0; atras >= 48.0; atras -= 14.0) {
            double x = jugador.getX() - hx * atras - hz * costado;
            double z = jugador.getZ() - hz * atras + hx * costado;
            if (!nivel.isPositionEntityTicking(BlockPos.containing(x, jugador.getY(), z))) {
                continue;
            }
            double base = Math.max(jugador.getY(),
                    nivel.getHeight(Heightmap.Types.MOTION_BLOCKING, Mth.floor(x), Mth.floor(z)));
            double sobre;
            if (tipo.hostil()) {
                sobre = tipo.globo() ? 18.0 + azar.nextDouble() * 4.0 : 20.0 + azar.nextDouble() * 4.0;
            } else {
                sobre = tipo.globo() ? 30.0 + azar.nextDouble() * 10.0 : 34.0 + azar.nextDouble() * 12.0;
            }
            double y = Math.min(base + sobre, nivel.getMaxBuildHeight() + 40.0);
            AeronaveEntity a = new AeronaveEntity(ModEntidades.porTipo(tipo).get(), nivel, tipo);
            a.moveTo(x, y, z, rumbo, 0.0F);
            a.preparar(y, true);
            nivel.addFreshEntity(a);
            registrar(a);
            return a;
        }
        return null;
    }
}
