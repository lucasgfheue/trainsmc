package com.locomotora.aereo;

import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModItems;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * La bomba que sueltan el globo y el zeppelin bombarderos: cae con la mecha encendida y explota al tocar algo, como
 * una explosión del juego (lastima y rompe bloques; con la regla {@code mobGriefing} apagada no rompe nada). A las
 * aeronaves no les pega: pasa de largo.
 */
public class BombaEntity extends ThrowableItemProjectile {
    /** Si en 20 segundos no tocó nada (cayó fuera del mundo cargado), se deshace. */
    private static final int VIDA = 400;

    private float potencia = 1.5F;

    public BombaEntity(EntityType<? extends BombaEntity> tipo, Level level) {
        super(tipo, level);
    }

    /** Una bomba que suelta una aeronave: sale con la velocidad que llevaba la aeronave. */
    public static BombaEntity soltar(ServerLevel nivel, AeronaveEntity aeronave, Vec3 desde, Vec3 velocidad,
                                     float potencia) {
        BombaEntity b = new BombaEntity(ModEntidades.BOMBA.get(), nivel);
        b.setPos(desde.x, desde.y, desde.z);
        b.setOwner(aeronave);
        b.potencia = potencia;
        b.setDeltaMovement(velocidad);
        nivel.addFreshEntity(b);
        return b;
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.BOMBA.get();
    }

    @Override
    public void tick() {
        super.tick();
        if (this.isRemoved()) {
            return;
        }
        if (this.level().isClientSide()) {
            // la mecha encendida
            this.level().addParticle(ParticleTypes.SMOKE, this.getX(), this.getY() + 0.3, this.getZ(), 0.0, 0.02, 0.0);
            if (this.tickCount % 3 == 0) {
                this.level().addParticle(ParticleTypes.SMALL_FLAME, this.getX(), this.getY() + 0.3, this.getZ(),
                        0.0, 0.01, 0.0);
            }
        } else if (this.tickCount > VIDA) {
            this.discard();
        }
    }

    /** Atraviesa las aeronaves (la que la soltó y cualquier otra) y las otras bombas. */
    @Override
    protected boolean canHitEntity(Entity otra) {
        return super.canHitEntity(otra) && !(otra instanceof AeronaveEntity) && !(otra instanceof ParteAeronave)
                && !(otra instanceof BombaEntity);
    }

    @Override
    protected void onHit(HitResult resultado) {
        super.onHit(resultado);
        if (!this.level().isClientSide() && !this.isRemoved()) {
            Vec3 p = resultado.getLocation();
            this.level().explode(this, this.damageSources().explosion(this, this.getOwner()), null, p.x, p.y, p.z,
                    this.potencia, false, Level.ExplosionInteraction.MOB);
            this.discard();
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("Potencia", this.potencia);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.potencia = tag.contains("Potencia") ? Math.max(0.5F, tag.getFloat("Potencia")) : 1.5F;
    }
}
