package com.locomotora.generacion;

import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;

import com.locomotora.LocomotoraMod;
import com.locomotora.entidad.LocomotoraEntity;
import com.locomotora.entidad.VagonEntity;
import com.locomotora.mundo.Mundo;
import com.locomotora.mundo.Plano;
import com.locomotora.mundo.Ruido;
import com.locomotora.registro.ModBloques;
import com.locomotora.via.Pieza;
import com.locomotora.via.ViaBlock;
import com.locomotora.via.ViaBlockEntity;
import com.locomotora.via.ViaDesvioBlock;
import com.mojang.logging.LogUtils;

import net.minecraft.commands.arguments.blocks.BlockStateParser;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.storage.loot.LootTable;

/** El chunk que se está generando (y sus 8 vecinos), como lo ve la red de vías. */
final class MundoMC implements Mundo {
    private static final Logger LOG = LogUtils.getLogger();
    private static final Map<String, BlockState> ESTADOS = new ConcurrentHashMap<>();
    private static final Set<String> AVISADOS = ConcurrentHashMap.newKeySet();

    private final WorldGenLevel nivel;
    private final int chunkX;
    private final int chunkZ;
    private final long semilla;
    private final int minY;
    private final int maxY;
    private final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

    MundoMC(WorldGenLevel nivel, int chunkX, int chunkZ, long semilla) {
        this.nivel = nivel;
        this.chunkX = chunkX;
        this.chunkZ = chunkZ;
        this.semilla = semilla;
        this.minY = nivel.getMinBuildHeight();
        this.maxY = nivel.getMaxBuildHeight() - 1;
    }

    /** Un estado de bloque escrito como en los comandos (se lee una sola vez). */
    static BlockState estado(String texto) {
        BlockState b = ESTADOS.get(texto);
        if (b == null) {
            try {
                b = BlockStateParser.parseForBlock(BuiltInRegistries.BLOCK.asLookup(), texto, false).blockState();
            } catch (Exception e) {
                if (AVISADOS.add(texto)) {
                    LOG.warn("Locomotora: no conozco el bloque {}", texto);
                }
                b = Blocks.AIR.defaultBlockState();
            }
            ESTADOS.put(texto, b);
        }
        return b;
    }

    private boolean adentro(int x, int y, int z) {
        return y >= this.minY && y <= this.maxY && Math.abs((x >> 4) - this.chunkX) <= 1
                && Math.abs((z >> 4) - this.chunkZ) <= 1;
    }

    @Override
    public int tipo(int x, int y, int z) {
        if (!adentro(x, y, z)) {
            return AIRE;
        }
        BlockState s = this.nivel.getBlockState(this.pos.set(x, y, z));
        if (s.isAir()) {
            return AIRE;
        }
        if (s.is(BlockTags.LOGS) || s.is(BlockTags.LEAVES)) {
            return ARBOL;
        }
        if (s.is(BlockTags.ICE)) {
            // un río o lago congelado: los pilares del puente bajan hasta el fondo
            return AGUA;
        }
        FluidState f = s.getFluidState();
        if (!f.isEmpty() && !s.blocksMotion()) {
            return f.is(FluidTags.LAVA) ? LAVA : AGUA;
        }
        return s.blocksMotion() ? SOLIDO : PLANTA;
    }

    @Override
    public String id(int x, int y, int z) {
        if (!adentro(x, y, z)) {
            return "minecraft:air";
        }
        Block b = this.nivel.getBlockState(this.pos.set(x, y, z)).getBlock();
        return BuiltInRegistries.BLOCK.getKey(b).toString();
    }

    @Override
    public int cima(int x, int z) {
        if (!adentro(x, this.minY, z)) {
            return this.minY;
        }
        return this.nivel.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1;
    }

    @Override
    public void poner(int x, int y, int z, String estado) {
        if (!adentro(x, y, z)) {
            return;
        }
        this.nivel.setBlock(new BlockPos(x, y, z), estado(estado), 2);
    }

    @Override
    public void ponerVia(Plano.PiezaPlan pp, Pieza.Celda celda) {
        if (!adentro(celda.x, celda.y, celda.z)) {
            return;
        }
        BlockPos p = new BlockPos(celda.x, celda.y, celda.z);
        Block bloque = ModBloques.bloquePara(pp.pieza.tipo).get();
        ViaBlock via = (ViaBlock) bloque;
        boolean agua = this.nivel.getFluidState(p).is(FluidTags.WATER);
        BlockState estado = bloque.defaultBlockState()
                .setValue(via.getShapeProperty(), RailShape.valueOf(celda.forma().name()))
                .setValue(BaseRailBlock.WATERLOGGED, agua);
        if (bloque instanceof ViaDesvioBlock) {
            estado = estado.setValue(ViaDesvioBlock.AGUJA, celda.esAguja());
        }
        this.nivel.setBlock(p, estado, 2);
        if (this.nivel.getBlockEntity(p) instanceof ViaBlockEntity entidad) {
            entidad.poner(pp.pieza, pp.config);
        }
    }

    private static ResourceKey<LootTable> tabla(String id) {
        return ResourceKey.create(Registries.LOOT_TABLE, ResourceLocation.parse(id));
    }

    @Override
    public void botin(int x, int y, int z, String tabla) {
        if (!adentro(x, y, z)) {
            return;
        }
        RandomizableContainer.setBlockEntityLootTable(this.nivel, RandomSource.create(Ruido.hash(this.semilla, x, y, z)),
                new BlockPos(x, y, z), tabla(tabla));
    }

    @Override
    public void entidad(Plano.EntidadPlan e) {
        Optional<EntityType<?>> tipo = BuiltInRegistries.ENTITY_TYPE.getOptional(LocomotoraMod.id(e.tipo));
        if (tipo.isEmpty()) {
            return;
        }
        Entity ent = tipo.get().create(this.nivel.getLevel());
        if (ent == null) {
            return;
        }
        ent.moveTo(e.x, e.y, e.z, 0.0F, 0.0F);
        ent.setUUID(new UUID(e.uuidAlto, e.uuidBajo));
        if (ent instanceof LocomotoraEntity loco) {
            loco.setRumbo(e.rumbo);
        } else if (ent instanceof VagonEntity vagon) {
            vagon.setRumbo(e.rumbo);
            if (e.enganchado()) {
                vagon.engancharEnGeneracion(new UUID(e.liderAlto, e.liderBajo), e.alFrenteDelLider, e.liderPorMiFrente);
            }
            if (e.botin != null) {
                vagon.setLootTable(tabla(e.botin), Ruido.hash(this.semilla, e.uuidAlto, e.uuidBajo, 3));
            }
        }
        this.nivel.addFreshEntity(ent);
    }

    @Override
    public int minY() {
        return this.minY;
    }

    @Override
    public int maxY() {
        return this.maxY;
    }
}
