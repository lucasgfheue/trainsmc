package com.locomotora.generacion;

import java.util.Optional;

import com.locomotora.mundo.Red;
import com.locomotora.registro.ModMundo;
import com.mojang.serialization.MapCodec;

import net.minecraft.core.Vec3i;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.structure.placement.RandomSpreadStructurePlacement;
import net.minecraft.world.level.levelgen.structure.placement.RandomSpreadType;
import net.minecraft.world.level.levelgen.structure.placement.StructurePlacement;
import net.minecraft.world.level.levelgen.structure.placement.StructurePlacementType;

/**
 * Dónde caen las estaciones abandonadas, para el juego: una región de la red por cada región de las aldeas
 * (34 chunks), y en cada región el chunk de la estación (si la región tiene una). Es una "ubicación al azar
 * repartida" como la de las aldeas, así {@code /locate structure} la sabe buscar; solo que en vez de sortear el
 * chunk, le pregunta a la red de vías dónde quedó la estación.
 */
public final class UbicacionRed extends RandomSpreadStructurePlacement {
    public static final MapCodec<UbicacionRed> CODEC = MapCodec.unit(() -> new UbicacionRed());
    /** Tamaño de la región en chunks (la de las aldeas). */
    public static final int REGION = Red.REGION / 16;

    public UbicacionRed() {
        super(Vec3i.ZERO, StructurePlacement.FrequencyReductionMethod.DEFAULT, 1.0F, 1_402_765_331, Optional.empty(),
                REGION, 8, RandomSpreadType.LINEAR);
    }

    @Override
    public ChunkPos getPotentialStructureChunk(long semilla, int x, int z) {
        int rx = Math.floorDiv(x, REGION);
        int rz = Math.floorDiv(z, REGION);
        Red red = Redes.delMundoPrincipal(semilla);
        Red.Nodo n = red == null ? null : red.nodo(rx, rz);
        if (n != null && n.tipo == Red.ABANDONADA) {
            return new ChunkPos(n.x >> 4, n.z >> 4);
        }
        // la región no tiene estación: un chunk de la esquina, donde la estructura igual no se arma
        return new ChunkPos(rx * REGION, rz * REGION);
    }

    @Override
    public StructurePlacementType<?> type() {
        return ModMundo.UBICACION_RED.get();
    }
}
