package com.locomotora.generacion;

import com.locomotora.registro.ModMundo;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;

/** La única "pieza" de la estación abandonada: solo su caja (los bloques los pone la red de vías). */
public final class MarcaEstacion extends StructurePiece {
    public MarcaEstacion(BoundingBox caja) {
        super(ModMundo.MARCA_ESTACION.get(), 0, caja);
    }

    public MarcaEstacion(CompoundTag tag) {
        super(ModMundo.MARCA_ESTACION.get(), tag);
    }

    @Override
    protected void addAdditionalSaveData(StructurePieceSerializationContext contexto, CompoundTag tag) {
    }

    @Override
    public void postProcess(WorldGenLevel nivel, StructureManager estructuras, ChunkGenerator generador, RandomSource azar,
                            BoundingBox caja, ChunkPos chunk, BlockPos pivote) {
    }
}
