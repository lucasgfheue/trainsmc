package com.locomotora.generacion;

import com.locomotora.mundo.Red;
import com.locomotora.mundo.Terreno;

import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.tags.BiomeTags;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;

/** El terreno que va a tener el mundo, sacado del generador (sirve aunque el chunk todavía no exista). */
final class TerrenoMC implements Terreno, Red.Biomas {
    private final ChunkGenerator generador;
    private final RandomState azar;
    private final LevelHeightAccessor alturas;

    TerrenoMC(ChunkGenerator generador, RandomState azar, LevelHeightAccessor alturas) {
        this.generador = generador;
        this.azar = azar;
        this.alturas = alturas;
    }

    @Override
    public int altura(int x, int z) {
        return this.generador.getBaseHeight(x, z, Heightmap.Types.WORLD_SURFACE_WG, this.alturas, this.azar);
    }

    @Override
    public int nivelMar() {
        return this.generador.getSeaLevel();
    }

    @Override
    public int minY() {
        return this.alturas.getMinBuildHeight();
    }

    @Override
    public int maxY() {
        return this.alturas.getMaxBuildHeight() - 1;
    }

    Holder<Biome> bioma(int x, int y, int z) {
        return this.generador.getBiomeSource().getNoiseBiome(QuartPos.fromBlock(x), QuartPos.fromBlock(y),
                QuartPos.fromBlock(z), this.azar.sampler());
    }

    @Override
    public boolean desierto(int x, int z) {
        Holder<Biome> b = bioma(x, altura(x, z), z);
        return b.is(Biomes.DESERT) || b.is(BiomeTags.IS_BADLANDS);
    }
}
