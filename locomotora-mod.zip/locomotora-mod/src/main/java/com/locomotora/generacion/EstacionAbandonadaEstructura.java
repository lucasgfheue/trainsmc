package com.locomotora.generacion;

import java.util.Optional;

import com.locomotora.mundo.EstacionAbandonada;
import com.locomotora.mundo.Red;
import com.locomotora.registro.ModMundo;
import com.mojang.serialization.MapCodec;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;

/**
 * La estación abandonada como estructura del juego: no pone bloques (de eso se encarga la red de vías), solo marca
 * dónde está, así se la encuentra con {@code /locate structure locomotora:estacion_abandonada}.
 */
public final class EstacionAbandonadaEstructura extends Structure {
    public static final MapCodec<EstacionAbandonadaEstructura> CODEC = simpleCodec(EstacionAbandonadaEstructura::new);

    public EstacionAbandonadaEstructura(Structure.StructureSettings ajustes) {
        super(ajustes);
    }

    @Override
    protected Optional<Structure.GenerationStub> findGenerationPoint(Structure.GenerationContext contexto) {
        Red red = Redes.paraGenerador(contexto.chunkGenerator(), contexto.seed());
        if (red == null) {
            return Optional.empty();
        }
        ChunkPos c = contexto.chunkPos();
        Red.Nodo n = red.nodo(Math.floorDiv(c.x, UbicacionRed.REGION), Math.floorDiv(c.z, UbicacionRed.REGION));
        if (n.tipo != Red.ABANDONADA || (n.x >> 4) != c.x || (n.z >> 4) != c.z) {
            return Optional.empty();
        }
        BoundingBox caja = caja(n);
        return Optional.of(new Structure.GenerationStub(new BlockPos(n.x, n.y, n.z),
                piezas -> piezas.addPiece(new MarcaEstacion(caja))));
    }

    /** Lo que ocupa la estación: a lo largo de la vía y hacia el lado del edificio. */
    static BoundingBox caja(Red.Nodo n) {
        int largo = EstacionAbandonada.MEDIO + 4;
        int z0 = n.s > 0 ? n.z - 16 : n.z - 33;
        int z1 = n.s > 0 ? n.z + 33 : n.z + 16;
        return new BoundingBox(n.x - largo, n.y - 8, z0, n.x + largo, n.y + 24, z1);
    }

    @Override
    public StructureType<?> type() {
        return ModMundo.ESTACION_ABANDONADA.get();
    }
}
