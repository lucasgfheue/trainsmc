package com.locomotora.generacion;

import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;

import com.locomotora.mundo.Generador;
import com.locomotora.registro.ModReglas;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * La red de vías como "feature" del mundo: corre una vez por chunk (al final de la decoración, después de árboles y
 * aldeas) y pone lo que le toca: la línea, las estaciones y los caminos.
 */
public class RedFeature extends Feature<NoneFeatureConfiguration> {
    private static final Logger LOG = LogUtils.getLogger();
    private static final AtomicInteger FALLAS = new AtomicInteger();

    public RedFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> contexto) {
        WorldGenLevel nivel = contexto.level();
        ServerLevel servidor = nivel.getLevel();
        if (servidor.dimension() != Level.OVERWORLD || !ModReglas.redDeVias(servidor.getGameRules())) {
            return false;
        }
        ChunkPos chunk = new ChunkPos(contexto.origin());
        try {
            Generador.generar(Redes.de(servidor), new MundoMC(nivel, chunk.x, chunk.z, servidor.getSeed()), chunk.x, chunk.z);
            return true;
        } catch (RuntimeException e) {
            if (FALLAS.incrementAndGet() <= 5) {
                LOG.error("Locomotora: no se pudo poner la red de vías en el chunk {}", chunk, e);
            }
            return false;
        }
    }
}
