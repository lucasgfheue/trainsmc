package com.locomotora.generacion;

import java.util.ArrayList;
import java.util.List;

import org.jetbrains.annotations.Nullable;

import com.locomotora.mundo.Aldeas;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.chunk.ChunkGeneratorStructureState;
import net.minecraft.world.level.levelgen.LegacyRandomSource;
import net.minecraft.world.level.levelgen.WorldgenRandom;
import net.minecraft.world.level.levelgen.structure.BuiltinStructureSets;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureSet;
import net.minecraft.world.level.levelgen.structure.placement.RandomSpreadStructurePlacement;

/**
 * Dónde pone el juego las aldeas: las mismas cuentas que hace al generar (la región de cada aldea, el chunk elegido
 * dentro de ella y qué aldea va según el bioma), sin generar nada.
 */
final class AldeasMC implements Aldeas {
    private static final int[][] MUESTRAS = {{0, 0}, {6, 6}, {-6, 6}, {6, -6}, {-6, -6}};

    private final long semilla;
    private final TerrenoMC terreno;
    private final ChunkGeneratorStructureState estado;
    @Nullable
    private final StructureSet conjunto;
    @Nullable
    private final RandomSpreadStructurePlacement ubicacion;

    AldeasMC(ServerLevel nivel, TerrenoMC terreno) {
        this.semilla = nivel.getSeed();
        this.terreno = terreno;
        this.estado = nivel.getChunkSource().getGeneratorState();
        StructureSet set = nivel.registryAccess().registryOrThrow(Registries.STRUCTURE_SET).get(BuiltinStructureSets.VILLAGES);
        this.conjunto = set;
        this.ubicacion = set != null && set.placement() instanceof RandomSpreadStructurePlacement r ? r : null;
    }

    /**
     * Tamaño de la región en bloques. Si un paquete de datos cambió cómo se reparten las aldeas (y quedan más juntas
     * que en el juego normal), la red no las usa: devuelve 0 y no se hacen estaciones de pueblo.
     */
    @Override
    public int region() {
        if (this.ubicacion == null || this.ubicacion.separation() < 8) {
            return 0;
        }
        return this.ubicacion.spacing() * 16;
    }

    @Override
    @Nullable
    public Aldea aldea(int rx, int rz) {
        if (this.ubicacion == null || this.conjunto == null) {
            return null;
        }
        int espacio = this.ubicacion.spacing();
        ChunkPos c = this.ubicacion.getPotentialStructureChunk(this.semilla, rx * espacio, rz * espacio);
        if (!this.ubicacion.isStructureChunk(this.estado, c.x, c.z)) {
            return null;
        }
        int x = c.getMinBlockX();
        int z = c.getMinBlockZ();
        // como el juego: elige una de las aldeas del conjunto por peso; si el bioma no le sirve, prueba otra
        List<StructureSet.StructureSelectionEntry> lista = new ArrayList<>(this.conjunto.structures());
        WorldgenRandom azar = new WorldgenRandom(new LegacyRandomSource(0L));
        azar.setLargeFeatureSeed(this.semilla, c.x, c.z);
        int total = 0;
        for (StructureSet.StructureSelectionEntry e : lista) {
            total += e.weight();
        }
        while (!lista.isEmpty() && total > 0) {
            int j = azar.nextInt(total);
            int k = 0;
            for (StructureSet.StructureSelectionEntry e : lista) {
                j -= e.weight();
                if (j < 0) {
                    break;
                }
                k++;
            }
            k = Math.min(k, lista.size() - 1);
            StructureSet.StructureSelectionEntry e = lista.get(k);
            if (sirve(e.structure().value(), x, z)) {
                String nombre = e.structure().unwrapKey().map(r -> r.location().toString()).orElse("minecraft:village_plains");
                return new Aldea(x, z, nombre);
            }
            lista.remove(k);
            total -= e.weight();
        }
        return null;
    }

    /** ¿El bioma del lugar le sirve a esta aldea? (se mira en varios puntos alrededor del centro) */
    private boolean sirve(Structure s, int x, int z) {
        for (int[] d : MUESTRAS) {
            int px = x + d[0];
            int pz = z + d[1];
            Holder<Biome> b = this.terreno.bioma(px, this.terreno.altura(px, pz), pz);
            if (s.biomes().contains(b)) {
                return true;
            }
        }
        return false;
    }
}
