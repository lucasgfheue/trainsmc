package com.locomotora.generacion;

import java.util.Map;
import java.util.WeakHashMap;

import com.locomotora.mundo.Red;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.RandomState;

/** La red de vías de cada mundo (una por nivel; se arma la primera vez que se pide). */
public final class Redes {
    private static final Map<ServerLevel, Red> REDES = new WeakHashMap<>();

    private Redes() {
    }

    public static Red de(ServerLevel nivel) {
        synchronized (REDES) {
            Red red = REDES.get(nivel);
            if (red == null) {
                ChunkGenerator generador = nivel.getChunkSource().getGenerator();
                RandomState azar = nivel.getChunkSource().randomState();
                TerrenoMC terreno = new TerrenoMC(generador, azar, nivel);
                red = new Red(nivel.getSeed(), terreno, new AldeasMC(nivel, terreno));
                REDES.put(nivel, red);
            }
            return red;
        }
    }
}
