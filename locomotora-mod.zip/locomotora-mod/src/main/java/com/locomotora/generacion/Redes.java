package com.locomotora.generacion;

import java.util.Map;
import java.util.WeakHashMap;

import org.jetbrains.annotations.Nullable;

import com.locomotora.mundo.Red;
import com.locomotora.registro.ModReglas;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.RandomState;
import net.neoforged.neoforge.server.ServerLifecycleHooks;

/** La red de vías de cada mundo (una por nivel; se arma la primera vez que se pide). */
public final class Redes {
    private static final Map<ServerLevel, Red> REDES = new WeakHashMap<>();

    private Redes() {
    }

    public static Red de(ServerLevel nivel) {
        synchronized (REDES) {
            Red red = REDES.get(nivel);
            if (red == null) {
                ChunkGenerator generador = nivel.getChunkSource().getGenerator();
                RandomState azar = nivel.getChunkSource().randomState();
                TerrenoMC terreno = new TerrenoMC(generador, azar, nivel);
                red = new Red(nivel.getSeed(), terreno, new AldeasMC(nivel, terreno));
                REDES.put(nivel, red);
            }
            return red;
        }
    }

    /**
     * El mundo normal del servidor, si tiene esa semilla y la red de vías está prendida (la ubicación de las
     * estaciones abandonadas solo conoce la semilla).
     */
    @Nullable
    private static ServerLevel principal(long semilla) {
        MinecraftServer servidor = ServerLifecycleHooks.getCurrentServer();
        if (servidor == null) {
            return null;
        }
        ServerLevel mundo = servidor.getLevel(Level.OVERWORLD);
        if (mundo == null || mundo.getSeed() != semilla || !ModReglas.redDeVias(mundo.getGameRules())) {
            return null;
        }
        return mundo;
    }

    /** La red del mundo normal con esa semilla, o null. */
    @Nullable
    public static Red delMundoPrincipal(long semilla) {
        ServerLevel mundo = principal(semilla);
        return mundo == null ? null : de(mundo);
    }

    /** La red del mundo normal si {@code generador} es el suyo (otra dimensión con la misma semilla no tiene red). */
    @Nullable
    public static Red paraGenerador(ChunkGenerator generador, long semilla) {
        ServerLevel mundo = principal(semilla);
        if (mundo == null || mundo.getChunkSource().getGenerator() != generador) {
            return null;
        }
        return de(mundo);
    }
}
