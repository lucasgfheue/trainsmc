package com.locomotora.via;

import com.locomotora.registro.ModBloques;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.ItemStack;

/**
 * El menú de una vía (Shift + clic derecho con el ítem en la mano): botones para cambiar las medidas. Los botones
 * llegan al servidor como "clic en botón del menú" (lo del juego, sin paquetes propios) y el servidor guarda el cambio
 * en el ítem; los valores vuelven a la pantalla como datos del menú.
 */
public class ViaMenu extends AbstractContainerMenu {
    // botones (con +100: de a 5)
    public static final int LARGO_MENOS = 0;
    public static final int LARGO_MAS = 1;
    public static final int RADIO_MENOS = 2;
    public static final int RADIO_MAS = 3;
    public static final int LADO = 4;
    public static final int ALTO_MENOS = 5;
    public static final int ALTO_MAS = 6;
    public static final int PASO_MENOS = 7;
    public static final int PASO_MAS = 8;
    public static final int BAJA = 9;
    public static final int DE_A_CINCO = 100;

    private final ContainerData datos;
    private final InteractionHand mano;

    /** En el cliente: los datos llegan del servidor. */
    public ViaMenu(int id, Inventory inventario) {
        super(ModBloques.VIA_MENU.get(), id);
        this.mano = InteractionHand.MAIN_HAND;
        this.datos = new SimpleContainerData(ConfigVia.CANTIDAD_DATOS);
        this.addDataSlots(this.datos);
    }

    /** En el servidor: los datos salen del ítem que el jugador tiene en esa mano. */
    public ViaMenu(int id, Inventory inventario, InteractionHand mano) {
        super(ModBloques.VIA_MENU.get(), id);
        this.mano = mano;
        Player jugador = inventario.player;
        this.datos = new ContainerData() {
            @Override
            public int get(int i) {
                return ViaItem.config(jugador.getItemInHand(mano)).dato(i);
            }

            @Override
            public void set(int i, int valor) {
            }

            @Override
            public int getCount() {
                return ConfigVia.CANTIDAD_DATOS;
            }
        };
        this.addDataSlots(this.datos);
    }

    /** La configuración que muestra la pantalla. */
    public ConfigVia config() {
        int[] d = new int[ConfigVia.CANTIDAD_DATOS];
        for (int i = 0; i < d.length; i++) {
            d[i] = this.datos.get(i);
        }
        return ConfigVia.desdeDatos(d);
    }

    @Override
    public boolean clickMenuButton(Player jugador, int boton) {
        ItemStack stack = jugador.getItemInHand(this.mano);
        if (!(stack.getItem() instanceof ViaItem)) {
            return false;
        }
        ConfigVia c = ViaItem.config(stack);
        int paso = boton >= DE_A_CINCO ? 5 : 1;
        switch (boton % DE_A_CINCO) {
            case LARGO_MENOS -> c.largo -= paso;
            case LARGO_MAS -> c.largo += paso;
            case RADIO_MENOS -> c.radio -= paso;
            case RADIO_MAS -> c.radio += paso;
            case LADO -> c.izquierda = !c.izquierda;
            case ALTO_MENOS -> c.alto -= paso;
            case ALTO_MAS -> c.alto += paso;
            case PASO_MENOS -> c.paso -= 1;
            case PASO_MAS -> c.paso += 1;
            case BAJA -> c.baja = !c.baja;
            default -> {
                return false;
            }
        }
        // si aumenta la pendiente y el alto no entra en 30 bloques, se acorta
        ViaItem.guardar(stack, c.ajustar());
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player jugador, int indice) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player jugador) {
        return jugador.getItemInHand(this.mano).getItem() instanceof ViaItem;
    }
}
