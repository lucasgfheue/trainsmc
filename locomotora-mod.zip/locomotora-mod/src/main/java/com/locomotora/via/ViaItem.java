package com.locomotora.via;

import java.util.List;

import org.jetbrains.annotations.Nullable;

import com.locomotora.registro.ModBloques;
import com.locomotora.registro.ModItems;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.level.material.Fluids;

/**
 * Ítem de una pieza de vía. Clic derecho en el piso: pone la pieza entera mirando hacia donde mira el jugador
 * (si se hace clic en la punta de una vía, sigue desde ahí). Shift + clic derecho: abre el menú para elegir las
 * medidas (hasta 30 bloques).
 */
public class ViaItem extends Item {
    private final TipoVia tipo;

    public ViaItem(Item.Properties propiedades, TipoVia tipo) {
        super(propiedades);
        this.tipo = tipo;
    }

    public TipoVia tipoVia() {
        return this.tipo;
    }

    // ------------------------------------------------------------------ configuración guardada en el ítem
    public static ConfigVia config(ItemStack stack) {
        TipoVia tipo = stack.getItem() instanceof ViaItem v ? v.tipo : TipoVia.RECTA;
        CustomData datos = stack.get(DataComponents.CUSTOM_DATA);
        if (datos == null) {
            return new ConfigVia(tipo);
        }
        return DatosVia.leerConfig(datos.copyTag(), tipo);
    }

    public static void guardar(ItemStack stack, ConfigVia c) {
        CompoundTag t = DatosVia.guardarConfig(c);
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(t));
    }

    /** Un ítem de la pieza con esa configuración. */
    public static ItemStack kit(ConfigVia c) {
        ItemStack stack = new ItemStack(ModItems.viaPorTipo(c.tipo).get());
        guardar(stack, c);
        return stack;
    }

    // ------------------------------------------------------------------ usar
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player jugador, InteractionHand mano) {
        ItemStack stack = jugador.getItemInHand(mano);
        if (jugador.isShiftKeyDown()) {
            abrirMenu(level, jugador, mano, stack);
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }
        return InteractionResultHolder.pass(stack);
    }

    @Override
    public InteractionResult useOn(UseOnContext contexto) {
        Level level = contexto.getLevel();
        Player jugador = contexto.getPlayer();
        ItemStack stack = contexto.getItemInHand();
        if (jugador != null && jugador.isShiftKeyDown()) {
            abrirMenu(level, jugador, contexto.getHand(), stack);
            return InteractionResult.sidedSuccess(level.isClientSide());
        }
        ConfigVia config = config(stack);
        Pieza p = piezaAPoner(level, contexto.getClickedPos(), contexto.getClickedFace(),
                contexto.getHorizontalDirection(), config);
        Component error = validar(level, jugador, p);
        if (error != null) {
            if (!level.isClientSide && jugador != null) {
                jugador.displayClientMessage(error.copy().withStyle(ChatFormatting.RED), true);
            }
            return InteractionResult.FAIL;
        }
        if (!level.isClientSide) {
            poner(level, p, config);
            if (jugador == null || !jugador.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide());
    }

    private static void abrirMenu(Level level, Player jugador, InteractionHand mano, ItemStack stack) {
        if (!level.isClientSide) {
            jugador.openMenu(new SimpleMenuProvider((id, inventario, j) -> new ViaMenu(id, inventario, mano),
                    stack.getHoverName()));
        }
    }

    // ------------------------------------------------------------------ dónde va la pieza
    public static Pieza.Rumbo rumbo(Direction d) {
        return switch (d) {
            case EAST -> Pieza.Rumbo.ESTE;
            case SOUTH -> Pieza.Rumbo.SUR;
            case WEST -> Pieza.Rumbo.OESTE;
            default -> Pieza.Rumbo.NORTE;
        };
    }

    /**
     * La celda donde empieza la pieza al hacer clic en 'clic' (por la cara 'cara') mirando hacia 'mirando': arriba del
     * bloque tocado (o en su lugar si es pasto o nieve); si se toca un riel, la celda siguiente hacia adelante (para
     * seguir la vía desde su punta).
     */
    public static BlockPos celdaInicial(Level level, BlockPos clic, Direction cara, Direction mirando) {
        BlockState estado = level.getBlockState(clic);
        if (estado.getBlock() instanceof BaseRailBlock riel) {
            RailShape f = riel.getRailDirection(estado, level, clic, null);
            BlockPos siguiente = clic.relative(mirando);
            boolean sube = (f == RailShape.ASCENDING_EAST && mirando == Direction.EAST)
                    || (f == RailShape.ASCENDING_WEST && mirando == Direction.WEST)
                    || (f == RailShape.ASCENDING_NORTH && mirando == Direction.NORTH)
                    || (f == RailShape.ASCENDING_SOUTH && mirando == Direction.SOUTH);
            return sube ? siguiente.above() : siguiente;
        }
        if (estado.canBeReplaced()) {
            return clic;
        }
        return clic.relative(cara);
    }

    public static Pieza piezaAPoner(Level level, BlockPos clic, Direction cara, Direction mirando, ConfigVia c) {
        BlockPos inicio = celdaInicial(level, clic, cara, mirando);
        return c.colocar(inicio.getX(), inicio.getY(), inicio.getZ(), rumbo(mirando));
    }

    /** ¿Se puede poner? null si sí; si no, por qué. */
    @Nullable
    public static Component validar(Level level, @Nullable Player jugador, Pieza p) {
        for (Pieza.Celda c : p.celdas()) {
            BlockPos pos = new BlockPos(c.x, c.y, c.z);
            Component error = validarCelda(level, jugador, pos);
            if (error != null) {
                return error;
            }
        }
        return null;
    }

    @Nullable
    public static Component validarCelda(Level level, @Nullable Player jugador, BlockPos pos) {
        if (level.isOutsideBuildHeight(pos) || !level.getWorldBorder().isWithinBounds(pos)) {
            return Component.translatable("mensaje.locomotora.via_fuera");
        }
        BlockState s = level.getBlockState(pos);
        if (!s.canBeReplaced() || s.getBlock() instanceof BaseRailBlock) {
            return Component.translatable("mensaje.locomotora.via_ocupado", pos.getX(), pos.getY(), pos.getZ());
        }
        if (jugador != null && !level.mayInteract(jugador, pos)) {
            return Component.translatable("mensaje.locomotora.via_protegido");
        }
        return null;
    }

    /** Pone la pieza: cada bloque con su forma y la pieza guardada, y balasto donde falta piso. */
    public static void poner(Level level, Pieza p, ConfigVia c) {
        Block bloque = ModBloques.bloquePara(p.tipo).get();
        ViaBlock via = (ViaBlock) bloque;
        // primero los soportes, así los rieles ya tienen piso
        BlockState balasto = ModBloques.BALASTO.get().defaultBlockState();
        BlockState losa = ModBloques.LOSA_BALASTO.get().defaultBlockState();
        for (int[][] columna : p.soportes()) {
            for (int[] q : columna) {
                BlockPos pos = new BlockPos(q[0], q[1], q[2]);
                if (level.isOutsideBuildHeight(pos) || !level.getBlockState(pos).canBeReplaced()) {
                    break;
                }
                boolean agua = level.getFluidState(pos).getType() == Fluids.WATER;
                level.setBlock(pos, q[3] == 1 ? losa.setValue(SlabBlock.WATERLOGGED, agua) : balasto, 3);
            }
        }
        for (Pieza.Celda celda : p.celdas()) {
            BlockPos pos = new BlockPos(celda.x, celda.y, celda.z);
            boolean agua = level.getFluidState(pos).getType() == Fluids.WATER;
            BlockState estado = bloque.defaultBlockState()
                    .setValue(via.getShapeProperty(), RailShape.valueOf(celda.forma().name()))
                    .setValue(BaseRailBlock.WATERLOGGED, agua);
            if (bloque instanceof ViaDesvioBlock) {
                estado = estado.setValue(ViaDesvioBlock.AGUJA, celda.esAguja());
            }
            level.setBlock(pos, estado, 3);
            if (level.getBlockEntity(pos) instanceof ViaBlockEntity entidad) {
                entidad.poner(p, c);
            }
        }
        level.playSound((Player) null, new BlockPos(p.ox, p.oy, p.oz), SoundType.METAL.getPlaceSound(),
                SoundSource.BLOCKS, 1.0F, 0.8F);
    }

    // ------------------------------------------------------------------ descripción
    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext contexto, List<Component> lineas,
                                TooltipFlag opciones) {
        ConfigVia c = config(stack);
        lineas.add(descripcion(c).withStyle(ChatFormatting.GOLD));
        lineas.add(Component.translatable("tooltip.locomotora.via_poner").withStyle(ChatFormatting.GRAY));
        lineas.add(Component.translatable("tooltip.locomotora.via_menu").withStyle(ChatFormatting.DARK_AQUA));
        if (c.tipo == TipoVia.DOS_CAMINOS) {
            lineas.add(Component.translatable("tooltip.locomotora.via_aguja").withStyle(ChatFormatting.DARK_AQUA));
        }
        if (c.tipo == TipoVia.SUBIDA) {
            lineas.add(Component.translatable("tooltip.locomotora.via_balasto").withStyle(ChatFormatting.GRAY));
        }
    }

    /** "Largo: 8 bloques", "Radio 6, a la derecha"... */
    public static net.minecraft.network.chat.MutableComponent descripcion(ConfigVia c) {
        Component lado = Component.translatable(c.izquierda ? "texto.locomotora.izquierda" : "texto.locomotora.derecha");
        return switch (c.tipo) {
            case RECTA -> Component.translatable("tooltip.locomotora.via_recta", c.largo);
            case CURVA -> Component.translatable("tooltip.locomotora.via_curva", c.radio, lado);
            case DOS_CAMINOS -> Component.translatable("tooltip.locomotora.via_dos_caminos",
                    c.pieza(0, 0, 0, Pieza.Rumbo.NORTE).largo, c.radio, lado);
            case SUBIDA -> Component.translatable(c.baja ? "tooltip.locomotora.via_baja" : "tooltip.locomotora.via_sube",
                    c.alto, c.paso, c.largoSubida());
        };
    }
}
