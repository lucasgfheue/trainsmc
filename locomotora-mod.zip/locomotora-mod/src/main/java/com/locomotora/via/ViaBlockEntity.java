package com.locomotora.via;

import org.jetbrains.annotations.Nullable;

import com.locomotora.registro.ModBloques;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Lo que guarda cada bloque de una pieza de vía: la pieza entera (tipo, configuración, dónde empieza y hacia dónde va).
 * Con eso cada bloque sabe su parte del dibujo, por dónde se dibujan los trenes y qué otros bloques quitar al romperla.
 */
public class ViaBlockEntity extends BlockEntity {
    @Nullable
    private ConfigVia config;
    private int ox;
    private int oy;
    private int oz;
    private Pieza.Rumbo rumbo = Pieza.Rumbo.ESTE;
    @Nullable
    private Pieza pieza;

    /** Lo que dibuja este bloque (solo en el cliente): caras ya calculadas y con qué aguja. */
    @Nullable
    private float[] caras;
    private boolean carasDesviado;

    public ViaBlockEntity(BlockPos pos, BlockState estado) {
        super(ModBloques.VIA_ENTIDAD.get(), pos, estado);
    }

    /** Al poner la pieza: cada bloque guarda la pieza entera. */
    public void poner(Pieza p, ConfigVia c) {
        this.config = c.copia();
        this.ox = p.ox;
        this.oy = p.oy;
        this.oz = p.oz;
        this.rumbo = p.rumbo;
        this.pieza = p;
        this.caras = null;
        this.setChanged();
    }

    @Nullable
    public ConfigVia config() {
        return this.config;
    }

    @Nullable
    public Pieza pieza() {
        if (this.pieza == null && this.config != null) {
            this.pieza = this.config.pieza(this.ox, this.oy, this.oz, this.rumbo);
        }
        return this.pieza;
    }

    /** Las caras que dibuja este bloque (se calculan una vez; el disco del cambio depende de la aguja). */
    @Nullable
    public float[] caras(boolean desviado) {
        Pieza p = pieza();
        if (p == null) {
            return null;
        }
        if (this.caras == null || this.carasDesviado != desviado) {
            BlockPos pos = this.getBlockPos();
            this.caras = DibujoVia.celda(p, pos.getX(), pos.getZ(), desviado, pos.getX(), pos.getY(), pos.getZ());
            this.carasDesviado = desviado;
        }
        return this.caras;
    }

    // ------------------------------------------------------------------ guardar y mandar al cliente
    @Override
    public void saveAdditional(CompoundTag tag, HolderLookup.Provider registros) {
        super.saveAdditional(tag, registros);
        if (this.config != null) {
            tag.put("pieza", DatosVia.guardarPieza(this.config, this.ox, this.oy, this.oz, this.rumbo));
        }
    }

    @Override
    public void loadAdditional(CompoundTag tag, HolderLookup.Provider registros) {
        super.loadAdditional(tag, registros);
        if (tag.contains("pieza")) {
            CompoundTag t = tag.getCompound("pieza");
            this.config = DatosVia.leerConfig(t);
            int[] o = DatosVia.leerOrigen(t);
            this.ox = o[0];
            this.oy = o[1];
            this.oz = o[2];
            this.rumbo = DatosVia.leerRumbo(t);
        } else {
            this.config = null;
        }
        this.pieza = null;
        this.caras = null;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registros) {
        CompoundTag tag = new CompoundTag();
        this.saveAdditional(tag, registros);
        return tag;
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
