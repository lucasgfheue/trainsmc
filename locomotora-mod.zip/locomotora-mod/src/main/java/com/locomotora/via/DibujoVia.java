package com.locomotora.via;

import java.util.Arrays;

/**
 * Las caras que dibuja cada bloque de una pieza de vía: durmientes de madera, rieles de acero (redondos en las
 * curvas), el terraplén de balasto de las subidas y el poste del cambio del desvío.
 * <p>
 * Textura via.png de 32x32: madera (filas 0-7), arriba del riel (8-9), costado del riel (10-11), hierro (12-13),
 * balasto (filas 16-31, columnas 0-15), disco verde (16-19, 16-19) y disco amarillo (20-23, 16-19).
 * <p>
 * Medidas en 1/16 de bloque: durmientes de 14 x 3 x 1 cada medio bloque; rieles de 1 x 1 a 5 del centro, con la parte
 * de arriba a 2/16 del piso. Cada bloque dibuja los durmientes y los trozos de riel cuyo centro de vía cae en su
 * columna (los trozos pueden asomar un poco al bloque de al lado: ese no los dibuja).
 * <p>
 * No usa nada del juego: devuelve las caras en números (se prueban contra el prototipo).
 */
public final class DibujoVia {
    /** Floats por cara: 4 vértices de (x, y, z, u, v) y la normal (nx, ny, nz). */
    public static final int POR_CARA = 23;

    private static final double T = 1.0 / 16.0;
    // regiones de la textura en píxeles: u0, v0, u1, v1
    private static final int[] MADERA = {0, 0, 32, 8};
    private static final int[] ACERO_ARRIBA = {0, 8, 32, 10};
    private static final int[] ACERO_COSTADO = {0, 10, 32, 12};
    private static final int[] HIERRO = {0, 12, 32, 14};
    private static final int[] BALASTO = {0, 16, 16, 32};
    private static final int[] VERDE = {16, 16, 20, 20};
    private static final int[] AMARILLO = {20, 16, 24, 20};

    private static final double LARGO_DURMIENTE = 14 * T;
    private static final double ANCHO_DURMIENTE = 3 * T;
    private static final double ALTO_DURMIENTE = T;
    private static final double TROCHA = 5 * T;
    private static final double ANCHO_RIEL = T;
    private static final double ALTO_RIEL = T;
    /** En el desvío: mientras la curva está a menos de esto de la recta, los durmientes son los largos de la recta. */
    private static final double JUNTOS = 0.85;

    private float[] datos = new float[POR_CARA * 64];
    private int caras;
    private final double refX;
    private final double refY;
    private final double refZ;

    private DibujoVia(double refX, double refY, double refZ) {
        this.refX = refX;
        this.refY = refY;
        this.refZ = refZ;
    }

    /**
     * Las caras del bloque de la columna (x, z) de la pieza, en coordenadas relativas a (refX, refY, refZ) (la
     * esquina del bloque que las dibuja).
     *
     * @param desviado cómo está la aguja (solo cambia el disco del poste)
     */
    public static float[] celda(Pieza p, int x, int z, boolean desviado, double refX, double refY, double refZ) {
        DibujoVia d = new DibujoVia(refX, refY, refZ);
        d.pieza(p, x, z, true, desviado);
        return Arrays.copyOf(d.datos, d.caras * POR_CARA);
    }

    /** Todas las caras de la pieza (para las pruebas y las imágenes). */
    public static float[] entera(Pieza p, boolean desviado, double refX, double refY, double refZ) {
        DibujoVia d = new DibujoVia(refX, refY, refZ);
        d.pieza(p, 0, 0, false, desviado);
        return Arrays.copyOf(d.datos, d.caras * POR_CARA);
    }

    private void pieza(Pieza p, int x, int z, boolean soloCelda, boolean desviado) {
        if (p.tipo == TipoVia.DOS_CAMINOS) {
            ruta(p, Pieza.RECTA, x, z, soloCelda, null);
            ruta(p, Pieza.CURVA, x, z, soloCelda, p.ruta(Pieza.RECTA).trazo);
            double[] c = p.aMundo(p.agujaU() + 0.5, 0.5, 0.0);
            if (!soloCelda || ((int) Math.floor(c[0]) == x && (int) Math.floor(c[2]) == z)) {
                poste(p, desviado);
            }
        } else {
            ruta(p, 0, x, z, soloCelda, null);
        }
    }

    // ------------------------------------------------------------------ una ruta
    private void ruta(Pieza p, int indice, int x, int z, boolean soloCelda, Pieza.Trazo compartidaCon) {
        Pieza.Trazo tr = p.ruta(indice).trazo;
        double largo = tr.largo();
        int n = Math.max(1, (int) Math.rint(largo / 0.5));
        double e = largo / n;

        // durmientes (y en la subida el terraplén debajo de cada uno)
        for (int k = 0; k < n; k++) {
            double s = e * (k + 0.5);
            double[] c = mundo(p, tr, s, 0.0, 0.0);
            if (soloCelda && !mia(c, x, z)) {
                continue;
            }
            double[] local = tr.punto(s);
            if (compartidaCon != null && compartidaCon.cercano(local[0], local[1])[0] < JUNTOS) {
                continue;
            }
            double largoD = LARGO_DURMIENTE;
            double[] centro = c;
            if (p.tipo == TipoVia.DOS_CAMINOS && indice == Pieza.RECTA) {
                Pieza.Trazo curva = p.ruta(Pieza.CURVA).trazo;
                double[] dc = curva.cercano(local[0], local[1]);
                if (dc[0] < JUNTOS) {
                    double lado = curva.punto(dc[1])[1] - local[1];
                    largoD = LARGO_DURMIENTE + Math.abs(lado);
                    centro = mundo(p, tr, s, lado / 2.0, 0.0);
                }
            }
            caja(centro, adelante(p, tr, s, largo), ANCHO_DURMIENTE, largoD, ALTO_DURMIENTE, MADERA, null, true);
            if (p.tipo == TipoVia.SUBIDA) {
                int i = Math.min(Math.max((int) Math.floor(local[0]), 0), p.largo - 1);
                double piso = p.oy + p.pisoDibujo(i);
                double s0 = Math.max(0.0, s - e / 2.0);
                double s1 = Math.min(largo, s + e / 2.0);
                double w = LARGO_DURMIENTE / 2.0 + T;
                if (c[1] - piso > 1.0E-3) {
                    prisma(mundo(p, tr, s0, -w, 0.0), mundo(p, tr, s1, -w, 0.0), mundo(p, tr, s0, w, 0.0),
                            mundo(p, tr, s1, w, 0.0), piso);
                }
            }
        }

        // rieles: trozos cortos a cada lado, apoyados arriba de los durmientes
        double base = 0.0;
        int cantidad = tr.tramos().size();
        for (int t = 0; t < cantidad; t++) {
            Pieza.Tramo tramo = tr.tramos().get(t);
            int m = pasosDeRiel(tramo);
            for (int j = 0; j < m; j++) {
                double s0 = base + tramo.largo() * j / m;
                double s1 = base + tramo.largo() * (j + 1) / m;
                boolean puntas = (t == 0 && j == 0) || (t == cantidad - 1 && j == m - 1);
                if (soloCelda && !mia(mundo(p, tr, (s0 + s1) / 2.0, 0.0, 0.0), x, z)) {
                    continue;
                }
                for (int lado = -1; lado <= 1; lado += 2) {
                    double[] a = mundo(p, tr, s0, lado * TROCHA, ALTO_DURMIENTE);
                    double[] b = mundo(p, tr, s1, lado * TROCHA, ALTO_DURMIENTE);
                    double[] medio = {(a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0, (a[2] + b[2]) / 2.0};
                    double[] d = {b[0] - a[0], b[1] - a[1], b[2] - a[2]};
                    double l = Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]);
                    caja(medio, d, l + 0.008, ANCHO_RIEL, ALTO_RIEL, ACERO_COSTADO, ACERO_ARRIBA, puntas);
                }
            }
            base += tramo.largo();
        }
    }

    /** En cuántos trozos se dibuja el riel de un tramo: rectos de medio bloque, curvos de a lo sumo unos 7 grados. */
    static int pasosDeRiel(Pieza.Tramo tramo) {
        double largoMax = tramo.radio() > 0.0 ? Math.min(0.5, 0.12 * tramo.radio()) : 0.5;
        return Math.max(1, (int) Math.ceil(tramo.largo() / largoMax - 1.0E-9));
    }

    /** El poste del cambio al lado de la aguja, con su disco: verde de frente = recta, amarillo de canto = desviado. */
    private void poste(Pieza p, boolean desviado) {
        int ai = p.agujaU();
        double[] centro = p.aMundo(ai + 0.5, -0.35, 0.0);
        double[] f = resta(p.aMundo(ai + 1, 0.5, 0.0), p.aMundo(ai, 0.5, 0.0));
        caja(centro, f, 2 * T, 2 * T, 9 * T, HIERRO, null, true);
        double[] lado = resta(p.aMundo(ai + 0.5, 0.5, 0.0), p.aMundo(ai + 0.5, -0.5, 0.0));
        double[] disco = {centro[0], centro[1] + 9 * T, centro[2]};
        caja(disco, desviado ? lado : f, 0.5 * T, 4 * T, 4 * T, desviado ? AMARILLO : VERDE, null, true);
    }

    // ------------------------------------------------------------------ ayudas
    /** Punto del trazo a la distancia s, corrido 'lateral' hacia la derecha (en planta) y 'dh' hacia arriba. */
    private static double[] mundo(Pieza p, Pieza.Trazo tr, double s, double lateral, double dh) {
        double[] q = tr.punto(s);
        double[] t = tr.tangente(s);
        double nl = Pieza.hypot(t[0], t[1]);
        if (nl == 0.0) {
            nl = 1.0;
        }
        return p.aMundo(q[0] - t[1] / nl * lateral, q[1] + t[0] / nl * lateral, q[2] + dh);
    }

    private static double[] adelante(Pieza p, Pieza.Trazo tr, double s, double largo) {
        return resta(mundo(p, tr, Math.min(largo, s + 0.01), 0.0, 0.0), mundo(p, tr, Math.max(0.0, s - 0.01), 0.0, 0.0));
    }

    private static boolean mia(double[] punto, int x, int z) {
        return (int) Math.floor(punto[0]) == x && (int) Math.floor(punto[2]) == z;
    }

    private static double[] resta(double[] a, double[] b) {
        return new double[]{a[0] - b[0], a[1] - b[1], a[2] - b[2]};
    }

    /**
     * Caja apoyada en 'centro' (el medio de su base), con el largo a lo largo de 'adelante' (que puede subir: la caja
     * se inclina) y el alto hacia arriba. Sin la cara de abajo; las puntas solo si se piden.
     */
    private void caja(double[] centro, double[] adelante, double largo, double ancho, double alto, int[] region,
                      int[] tapa, boolean puntas) {
        double fl = Math.sqrt(adelante[0] * adelante[0] + adelante[1] * adelante[1] + adelante[2] * adelante[2]);
        double fx = adelante[0] / fl;
        double fy = adelante[1] / fl;
        double fz = adelante[2] / fl;
        // arriba: (0, 1, 0) sin lo que tiene a lo largo de 'adelante'
        double ux = -fx * fy;
        double uy = 1.0 - fy * fy;
        double uz = -fz * fy;
        double ul = Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= ul;
        uy /= ul;
        uz /= ul;
        // derecha = adelante x arriba
        double dx = fy * uz - fz * uy;
        double dy = fz * ux - fx * uz;
        double dz = fx * uy - fy * ux;
        double hl = largo / 2.0;
        double hw = ancho / 2.0;
        double[][] p = new double[8][];
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                for (int k = 0; k < 2; k++) {
                    double a = i == 1 ? hl : -hl;
                    double b = j == 1 ? hw : -hw;
                    double h = k == 1 ? alto : 0.0;
                    p[i * 4 + j * 2 + k] = new double[]{centro[0] + fx * a + dx * b + ux * h,
                            centro[1] + fy * a + dy * b + uy * h, centro[2] + fz * a + dz * b + uz * h};
                }
            }
        }
        cara(p[1], p[3], p[7], p[5], tapa != null ? tapa : region);   // arriba
        cara(p[2], p[6], p[7], p[3], region);                          // costado derecho
        cara(p[4], p[0], p[1], p[5], region);                          // costado izquierdo
        if (puntas) {
            cara(p[0], p[2], p[3], p[1], region);                      // punta de atrás
            cara(p[6], p[4], p[5], p[7], region);                      // punta de adelante
        }
    }

    /** Terraplén: arriba los bordes a0-a1 (izquierdo) y b0-b1 (derecho); abajo llega hasta la altura 'piso'. */
    private void prisma(double[] a0, double[] a1, double[] b0, double[] b1, double piso) {
        double[] ba0 = {a0[0], piso, a0[2]};
        double[] ba1 = {a1[0], piso, a1[2]};
        double[] bb0 = {b0[0], piso, b0[2]};
        double[] bb1 = {b1[0], piso, b1[2]};
        cara(a0, b0, b1, a1, BALASTO);        // arriba
        cara(bb0, bb1, b1, b0, BALASTO);      // costado derecho
        cara(ba1, ba0, a0, a1, BALASTO);      // costado izquierdo
        cara(ba0, bb0, b0, a0, BALASTO);      // atrás
        cara(bb1, ba1, a1, b1, BALASTO);      // adelante
    }

    /** Cuadrilátero a-b-c-d (antihorario visto desde afuera) con la región de la textura estirada encima. */
    private void cara(double[] a, double[] b, double[] c, double[] d, int[] region) {
        double e1x = b[0] - a[0];
        double e1y = b[1] - a[1];
        double e1z = b[2] - a[2];
        double e2x = d[0] - a[0];
        double e2y = d[1] - a[1];
        double e2z = d[2] - a[2];
        double nx = e1y * e2z - e1z * e2y;
        double ny = e1z * e2x - e1x * e2z;
        double nz = e1x * e2y - e1y * e2x;
        double nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (nl < 1.0E-12) {
            e1x = c[0] - b[0];
            e1y = c[1] - b[1];
            e1z = c[2] - b[2];
            e2x = a[0] - b[0];
            e2y = a[1] - b[1];
            e2z = a[2] - b[2];
            nx = e1y * e2z - e1z * e2y;
            ny = e1z * e2x - e1x * e2z;
            nz = e1x * e2y - e1y * e2x;
            nl = Math.sqrt(nx * nx + ny * ny + nz * nz);
        }
        if (nl > 0.0) {
            nx /= nl;
            ny /= nl;
            nz /= nl;
        } else {
            nx = 0.0;
            ny = 1.0;
            nz = 0.0;
        }
        if ((this.caras + 1) * POR_CARA > this.datos.length) {
            this.datos = Arrays.copyOf(this.datos, this.datos.length * 2);
        }
        int o = this.caras * POR_CARA;
        float u0 = region[0] / 32.0F;
        float v0 = region[1] / 32.0F;
        float u1 = region[2] / 32.0F;
        float v1 = region[3] / 32.0F;
        o = vertice(o, a, u0, v1);
        o = vertice(o, b, u1, v1);
        o = vertice(o, c, u1, v0);
        o = vertice(o, d, u0, v0);
        this.datos[o] = (float) nx;
        this.datos[o + 1] = (float) ny;
        this.datos[o + 2] = (float) nz;
        this.caras++;
    }

    private int vertice(int o, double[] p, float u, float v) {
        this.datos[o] = (float) (p[0] - this.refX);
        this.datos[o + 1] = (float) (p[1] - this.refY);
        this.datos[o + 2] = (float) (p[2] - this.refZ);
        this.datos[o + 3] = u;
        this.datos[o + 4] = v;
        return o + 5;
    }
}
