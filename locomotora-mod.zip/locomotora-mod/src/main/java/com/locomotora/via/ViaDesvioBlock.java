package com.locomotora.via;

import java.util.List;

import org.jetbrains.annotations.Nullable;

import com.mojang.serialization.MapCodec;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Bloque de una vía de dos caminos (desvío). Todos sus bloques tienen una sola forma, salvo la aguja: el bloque donde
 * la curva se separa de la recta, que tiene las dos y usa la del camino puesto.
 * <ul>
 *   <li>El camino se cambia con clic derecho (con la mano vacía) en la aguja o en el tramo común, o con redstone al lado
 *       (con señal: desviado; sin señal: recto).</li>
 *   <li>Mientras haya una vagoneta en el tramo común o en la aguja no se cambia (espera a que pase).</li>
 *   <li>Si un tren llega desde un ramal hacia la punta (de talón), la aguja se pone sola para el lado del que viene.</li>
 * </ul>
 */
public class ViaDesvioBlock extends ViaBlock {
    public static final MapCodec<ViaDesvioBlock> CODEC = simpleCodec(ViaDesvioBlock::new);
    public static final EnumProperty<RailShape> SHAPE = ViaCurvaBlock.SHAPE;
    /** El bloque donde se separan los caminos. */
    public static final BooleanProperty AGUJA = BooleanProperty.create("aguja");
    /** Camino puesto en la aguja: la curva (si no, la recta). */
    public static final BooleanProperty DESVIADO = BooleanProperty.create("desviado");
    public static final BooleanProperty POWERED = BlockStateProperties.POWERED;

    public ViaDesvioBlock(BlockBehaviour.Properties propiedades) {
        super(propiedades);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(SHAPE, RailShape.NORTH_SOUTH)
                .setValue(WATERLOGGED, Boolean.FALSE)
                .setValue(AGUJA, Boolean.FALSE)
                .setValue(DESVIADO, Boolean.FALSE)
                .setValue(POWERED, Boolean.FALSE));
    }

    @Override
    public MapCodec<? extends BaseRailBlock> codec() {
        return CODEC;
    }

    @Override
    public TipoVia tipoVia() {
        return TipoVia.DOS_CAMINOS;
    }

    @Override
    public Property<RailShape> getShapeProperty() {
        return SHAPE;
    }

    @Override
    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(SHAPE, WATERLOGGED, AGUJA, DESVIADO, POWERED);
    }

    public static RailShape forma(Pieza.Forma f) {
        return RailShape.valueOf(f.name());
    }

    // ------------------------------------------------------------------ por dónde va cada vagoneta
    /**
     * La forma para esa vagoneta: la del camino puesto, salvo que venga desde un ramal hacia la punta (de talón):
     * entonces la de ese ramal (y al pasar, la aguja se pone sola).
     */
    @Override
    public RailShape getRailDirection(BlockState estado, BlockGetter level, BlockPos pos,
                                      @Nullable AbstractMinecart vagoneta) {
        RailShape actual = estado.getValue(SHAPE);
        if (vagoneta == null || !estado.getValue(AGUJA)) {
            return actual;
        }
        Pieza p = pieza(level, pos);
        Pieza.Celda c = p != null ? p.celda(pos.getX(), pos.getY(), pos.getZ()) : null;
        if (c == null || !c.esAguja()) {
            return actual;
        }
        int llegada = rutaDeLlegada(p, c, vagoneta.getDeltaMovement());
        return llegada < 0 ? actual : forma(c.formas[llegada]);
    }

    /**
     * Si la vagoneta viene desde un ramal hacia la punta, de cuál (RECTA o CURVA); si no, -1. Viene de la curva si se
     * aleja de su lado (aunque sea poco: los vagones siguen la tangente del trazo dibujado); de la recta si va hacia la
     * punta sin alejarse del lado de la curva.
     */
    static int rutaDeLlegada(Pieza p, Pieza.Celda c, Vec3 movimiento) {
        double vx = movimiento.x;
        double vz = movimiento.z;
        double rapidez = Math.sqrt(vx * vx + vz * vz);
        if (rapidez < 1.0E-4) {
            return -1;
        }
        int[] punta = p.ladoAMundo(-1, 0);
        int[] lados = c.formas[Pieza.CURVA].lados();
        int lcx = lados[0] == punta[0] && lados[1] == punta[1] ? lados[2] : lados[0];
        int lcz = lados[0] == punta[0] && lados[1] == punta[1] ? lados[3] : lados[1];
        if (vx * lcx + vz * lcz < -0.05 * rapidez) {
            return Pieza.CURVA;
        }
        if (vx * punta[0] + vz * punta[1] > 0.5 * rapidez) {
            return Pieza.RECTA;
        }
        return -1;
    }

    /** Para Via: la forma de la aguja entrando por el lado (dx, dz); null si se entra por la punta. */
    @Nullable
    public RailShape formaAlEntrar(BlockState estado, BlockGetter level, BlockPos pos, int dx, int dz) {
        if (!estado.getValue(AGUJA)) {
            return null;
        }
        Pieza p = pieza(level, pos);
        Pieza.Celda c = p != null ? p.celda(pos.getX(), pos.getY(), pos.getZ()) : null;
        if (c == null || !c.esAguja()) {
            return null;
        }
        boolean recta = c.formas[Pieza.RECTA].tieneLado(dx, dz);
        boolean curva = c.formas[Pieza.CURVA].tieneLado(dx, dz);
        if (recta && !curva) {
            return forma(c.formas[Pieza.RECTA]);
        }
        if (curva && !recta) {
            return forma(c.formas[Pieza.CURVA]);
        }
        return null;
    }

    /** Para Via: qué camino está puesto en el desvío de esta pieza. */
    public static boolean desviado(BlockGetter level, Pieza p) {
        int[] a = p.aguja();
        if (a == null) {
            return false;
        }
        BlockState s = level.getBlockState(new BlockPos(a[0], a[1], a[2]));
        return s.getBlock() instanceof ViaDesvioBlock && s.getValue(DESVIADO);
    }

    @Override
    public void onMinecartPass(BlockState estado, Level level, BlockPos pos, AbstractMinecart vagoneta) {
        if (level.isClientSide || !estado.getValue(AGUJA)) {
            return;
        }
        Pieza p = pieza(level, pos);
        Pieza.Celda c = p != null ? p.celda(pos.getX(), pos.getY(), pos.getZ()) : null;
        if (c == null || !c.esAguja()) {
            return;
        }
        int llegada = rutaDeLlegada(p, c, vagoneta.getDeltaMovement());
        if (llegada < 0 || (llegada == Pieza.CURVA) == estado.getValue(DESVIADO) || ocupada(level, p, vagoneta)) {
            return;
        }
        cambiar(level, pos, estado, c, llegada == Pieza.CURVA);
    }

    /** ¿Hay alguna vagoneta (que no sea 'menos') en el tramo común o en la aguja? */
    static boolean ocupada(Level level, Pieza p, @Nullable AbstractMinecart menos) {
        double[] z = p.zonaAguja();
        List<AbstractMinecart> hay = level.getEntitiesOfClass(AbstractMinecart.class,
                new AABB(z[0], z[1], z[2], z[3], z[4], z[5]), v -> v != menos && v.isAlive());
        return !hay.isEmpty();
    }

    private static void cambiar(Level level, BlockPos aguja, BlockState estado, Pieza.Celda c, boolean desviado) {
        RailShape f = forma(c.formas[desviado ? Pieza.CURVA : Pieza.RECTA]);
        level.setBlock(aguja, estado.setValue(DESVIADO, desviado).setValue(SHAPE, f), 3);
        level.playSound((Player) null, aguja, SoundEvents.LEVER_CLICK, SoundSource.BLOCKS, 0.5F, 0.7F);
    }

    // ------------------------------------------------------------------ cambiarla a mano o con redstone
    @Override
    public ItemInteractionResult useItemOn(ItemStack enMano, BlockState estado, Level level, BlockPos pos,
                                              Player jugador, InteractionHand mano, BlockHitResult golpe) {
        // con algo en la mano (una vagoneta, una locomotora...) se usa eso; con la mano vacía se cambia la aguja
        return enMano.isEmpty() ? ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION
                : ItemInteractionResult.SKIP_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public InteractionResult useWithoutItem(BlockState estado, Level level, BlockPos pos, Player jugador,
                                               BlockHitResult golpe) {
        Pieza p = pieza(level, pos);
        Pieza.Celda c = p != null ? p.celda(pos.getX(), pos.getY(), pos.getZ()) : null;
        if (c == null || !(c.esAguja() || c.esComun())) {
            return InteractionResult.PASS;
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        int[] a = p.aguja();
        BlockPos posAguja = new BlockPos(a[0], a[1], a[2]);
        BlockState sa = level.getBlockState(posAguja);
        Pieza.Celda ca = p.celda(a[0], a[1], a[2]);
        if (!(sa.getBlock() instanceof ViaDesvioBlock) || !sa.getValue(AGUJA) || ca == null) {
            return InteractionResult.PASS;
        }
        if (ocupada(level, p, null)) {
            jugador.displayClientMessage(Component.translatable("mensaje.locomotora.aguja_ocupada"), true);
            return InteractionResult.CONSUME;
        }
        boolean desviado = !sa.getValue(DESVIADO);
        cambiar(level, posAguja, sa, ca, desviado);
        jugador.displayClientMessage(Component.translatable(
                desviado ? "mensaje.locomotora.aguja_curva" : "mensaje.locomotora.aguja_recta"), true);
        return InteractionResult.CONSUME;
    }

    /** Redstone al lado de la aguja o del tramo común: con señal, desviado; sin señal, recto. */
    @Override
    public void neighborChanged(BlockState estado, Level level, BlockPos pos, Block vecino, BlockPos desde,
                                   boolean movido) {
        if (level.isClientSide) {
            return;
        }
        Pieza p = pieza(level, pos);
        Pieza.Celda c = p != null ? p.celda(pos.getX(), pos.getY(), pos.getZ()) : null;
        if (c == null || !(c.esAguja() || c.esComun())) {
            return;
        }
        boolean senal = false;
        for (Pieza.Celda z : p.celdas()) {
            if ((z.esAguja() || z.esComun()) && level.hasNeighborSignal(new BlockPos(z.x, z.y, z.z))) {
                senal = true;
                break;
            }
        }
        int[] a = p.aguja();
        BlockPos posAguja = new BlockPos(a[0], a[1], a[2]);
        BlockState sa = level.getBlockState(posAguja);
        if (sa.getBlock() instanceof ViaDesvioBlock && sa.getValue(AGUJA) && sa.getValue(POWERED) != senal) {
            level.setBlock(posAguja, sa.setValue(POWERED, senal), 2);
            level.scheduleTick(posAguja, this, 2);
        }
    }

    @Override
    public void tick(BlockState estado, ServerLevel level, BlockPos pos, RandomSource azar) {
        if (!estado.getValue(AGUJA) || estado.getValue(POWERED) == estado.getValue(DESVIADO)) {
            return;
        }
        Pieza p = pieza(level, pos);
        Pieza.Celda c = p != null ? p.celda(pos.getX(), pos.getY(), pos.getZ()) : null;
        if (c == null || !c.esAguja()) {
            return;
        }
        if (ocupada(level, p, null)) {
            // espera a que pase el tren
            level.scheduleTick(pos, this, 10);
            return;
        }
        cambiar(level, pos, estado, c, estado.getValue(POWERED));
    }
}
