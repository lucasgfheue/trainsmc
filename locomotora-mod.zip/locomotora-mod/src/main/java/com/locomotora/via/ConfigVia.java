package com.locomotora.via;

/**
 * Lo que se elige en el menú de una vía (Shift + clic derecho): cuánto mide, para qué lado dobla, cuánto sube.
 * Se guarda en el ítem y en cada bloque de la pieza puesta.
 */
public final class ConfigVia {
    /** Lo más largo que puede llegar una pieza (en bloques). */
    public static final int MAX = 30;

    public final TipoVia tipo;
    /** Recta (y la recta del desvío): cantidad de bloques. */
    public int largo;
    /** Curva (y la curva del desvío): radio en bloques. */
    public int radio;
    /** Curva y desvío: hacia la izquierda (si no, a la derecha). */
    public boolean izquierda;
    /** Subida: cuántos bloques sube. */
    public int alto;
    /** Subida: cada cuántos bloques sube uno (1 = 45 grados, 4 = suave). */
    public int paso;
    /** Subida: si se pone desde arriba para bajar. */
    public boolean baja;

    public ConfigVia(TipoVia tipo) {
        this.tipo = tipo;
        switch (tipo) {
            case RECTA -> this.largo = 8;
            case CURVA -> this.radio = 6;
            case DOS_CAMINOS -> {
                this.largo = 10;
                this.radio = 6;
            }
            case SUBIDA -> {
                this.alto = 2;
                this.paso = 2;
            }
        }
        if (this.largo == 0) {
            this.largo = 8;
        }
        if (this.radio == 0) {
            this.radio = 6;
        }
        if (this.alto == 0) {
            this.alto = 2;
        }
        if (this.paso == 0) {
            this.paso = 2;
        }
        ajustar();
    }

    public ConfigVia copia() {
        ConfigVia c = new ConfigVia(this.tipo);
        c.largo = this.largo;
        c.radio = this.radio;
        c.izquierda = this.izquierda;
        c.alto = this.alto;
        c.paso = this.paso;
        c.baja = this.baja;
        return c;
    }

    /** Deja todo dentro de lo permitido (como mucho 30 bloques). */
    public ConfigVia ajustar() {
        this.largo = limitar(this.largo, 1, MAX);
        this.radio = limitar(this.radio, 2, MAX);
        this.paso = limitar(this.paso, 1, 4);
        this.alto = limitar(this.alto, 1, MAX / this.paso);
        return this;
    }

    /** Largo de la subida en bloques. */
    public int largoSubida() {
        return this.alto * this.paso;
    }

    public Pieza pieza(int x, int y, int z, Pieza.Rumbo rumbo) {
        return Pieza.obtener(this.tipo, x, y, z, rumbo, this.izquierda, this.largo, this.radio, this.alto, this.paso);
    }

    /**
     * La pieza que queda al ponerla desde la celda (x, y, z) mirando hacia {@code rumbo}. Una subida que baja es la
     * misma rampa puesta desde abajo mirando para el otro lado, con su última celda en (x, y, z).
     */
    public Pieza colocar(int x, int y, int z, Pieza.Rumbo rumbo) {
        if (this.tipo == TipoVia.SUBIDA && this.baja) {
            int l = largoSubida();
            return pieza(x + rumbo.dx * (l - 1), y - this.alto, z + rumbo.dz * (l - 1), rumbo.contrario());
        }
        return pieza(x, y, z, rumbo);
    }

    // ------------------------------------------------------------------ para el menú (datos sincronizados)
    public static final int DATO_LARGO = 0;
    public static final int DATO_RADIO = 1;
    public static final int DATO_IZQUIERDA = 2;
    public static final int DATO_ALTO = 3;
    public static final int DATO_PASO = 4;
    public static final int DATO_BAJA = 5;
    public static final int DATO_TIPO = 6;
    public static final int CANTIDAD_DATOS = 7;

    public int dato(int i) {
        return switch (i) {
            case DATO_LARGO -> this.largo;
            case DATO_RADIO -> this.radio;
            case DATO_IZQUIERDA -> this.izquierda ? 1 : 0;
            case DATO_ALTO -> this.alto;
            case DATO_PASO -> this.paso;
            case DATO_BAJA -> this.baja ? 1 : 0;
            case DATO_TIPO -> this.tipo.ordinal();
            default -> 0;
        };
    }

    public void ponerDato(int i, int valor) {
        switch (i) {
            case DATO_LARGO -> this.largo = valor;
            case DATO_RADIO -> this.radio = valor;
            case DATO_IZQUIERDA -> this.izquierda = valor != 0;
            case DATO_ALTO -> this.alto = valor;
            case DATO_PASO -> this.paso = valor;
            case DATO_BAJA -> this.baja = valor != 0;
            default -> {
            }
        }
        ajustar();
    }

    /** Arma la configuración que mandó el servidor al menú. */
    public static ConfigVia desdeDatos(int[] datos) {
        ConfigVia c = new ConfigVia(TipoVia.porOrdinal(datos[DATO_TIPO]));
        c.largo = datos[DATO_LARGO];
        c.radio = datos[DATO_RADIO];
        c.izquierda = datos[DATO_IZQUIERDA] != 0;
        c.paso = datos[DATO_PASO];
        c.alto = datos[DATO_ALTO];
        c.baja = datos[DATO_BAJA] != 0;
        return c.ajustar();
    }

    private static int limitar(int v, int min, int max) {
        return v < min ? min : (v > max ? max : v);
    }
}
