package com.locomotora.via;

import net.minecraft.nbt.CompoundTag;

/** Cómo se guardan la configuración de una vía (en el ítem) y la pieza puesta (en cada bloque). */
public final class DatosVia {
    private DatosVia() {
    }

    public static CompoundTag guardarConfig(ConfigVia c) {
        CompoundTag t = new CompoundTag();
        t.putString("tipo", c.tipo.id());
        t.putInt("largo", c.largo);
        t.putInt("radio", c.radio);
        t.putBoolean("izquierda", c.izquierda);
        t.putInt("alto", c.alto);
        t.putInt("paso", c.paso);
        t.putBoolean("baja", c.baja);
        return t;
    }

    /** Lee la configuración guardada (si falta algo, queda lo de fábrica de ese tipo). */
    public static ConfigVia leerConfig(CompoundTag t) {
        return leerConfig(t, tipoDe(t.getString("tipo")));
    }

    public static ConfigVia leerConfig(CompoundTag t, TipoVia tipo) {
        ConfigVia c = new ConfigVia(tipo);
        if (t.contains("largo")) {
            c.largo = t.getInt("largo");
        }
        if (t.contains("radio")) {
            c.radio = t.getInt("radio");
        }
        if (t.contains("izquierda")) {
            c.izquierda = t.getBoolean("izquierda");
        }
        if (t.contains("paso")) {
            c.paso = t.getInt("paso");
        }
        if (t.contains("alto")) {
            c.alto = t.getInt("alto");
        }
        if (t.contains("baja")) {
            c.baja = t.getBoolean("baja");
        }
        return c.ajustar();
    }

    public static CompoundTag guardarPieza(ConfigVia c, int ox, int oy, int oz, Pieza.Rumbo rumbo) {
        CompoundTag t = guardarConfig(c);
        t.putInt("x", ox);
        t.putInt("y", oy);
        t.putInt("z", oz);
        t.putString("rumbo", rumbo.name());
        return t;
    }

    public static int[] leerOrigen(CompoundTag t) {
        return new int[]{t.getInt("x"), t.getInt("y"), t.getInt("z")};
    }

    public static Pieza.Rumbo leerRumbo(CompoundTag t) {
        String r = t.getString("rumbo");
        for (Pieza.Rumbo rumbo : Pieza.Rumbo.values()) {
            if (rumbo.name().equals(r)) {
                return rumbo;
            }
        }
        return Pieza.Rumbo.ESTE;
    }

    public static TipoVia tipoDe(String id) {
        for (TipoVia t : TipoVia.values()) {
            if (t.id().equals(id)) {
                return t;
            }
        }
        return TipoVia.RECTA;
    }
}
