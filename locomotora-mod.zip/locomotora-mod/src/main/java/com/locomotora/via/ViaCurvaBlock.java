package com.locomotora.via;

import com.mojang.serialization.MapCodec;

import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.RailShape;

/** Bloque de una vía curva (se dibuja redonda con ViaRenderer). */
public class ViaCurvaBlock extends ViaBlock {
    public static final MapCodec<ViaCurvaBlock> CODEC = simpleCodec(ViaCurvaBlock::new);
    /** Solo las formas planas (rectas y curvas). */
    public static final EnumProperty<RailShape> SHAPE = EnumProperty.create("shape", RailShape.class,
            RailShape.NORTH_SOUTH, RailShape.EAST_WEST, RailShape.SOUTH_EAST, RailShape.SOUTH_WEST,
            RailShape.NORTH_WEST, RailShape.NORTH_EAST);

    public ViaCurvaBlock(BlockBehaviour.Properties propiedades) {
        super(propiedades);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(SHAPE, RailShape.NORTH_SOUTH)
                .setValue(WATERLOGGED, Boolean.FALSE));
    }

    @Override
    public MapCodec<? extends BaseRailBlock> codec() {
        return CODEC;
    }

    @Override
    public TipoVia tipoVia() {
        return TipoVia.CURVA;
    }

    @Override
    public Property<RailShape> getShapeProperty() {
        return SHAPE;
    }

    @Override
    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(SHAPE, WATERLOGGED);
    }
}
