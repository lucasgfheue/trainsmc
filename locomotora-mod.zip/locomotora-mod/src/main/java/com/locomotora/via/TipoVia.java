package com.locomotora.via;

/** Las cuatro piezas de vía del mod. */
public enum TipoVia {
    /** Recta de 1 a 30 bloques. */
    RECTA("recta"),
    /** Cuarto de círculo de radio 2 a 30, hacia la izquierda o la derecha. */
    CURVA("curva"),
    /** Desvío: una recta y una curva que salen juntas, con una aguja que elige el camino. */
    DOS_CAMINOS("dos_caminos"),
    /** Rampa que sube (o baja) de a un bloque cada 1, 2, 3 o 4 bloques. */
    SUBIDA("subida");

    private final String id;

    TipoVia(String id) {
        this.id = id;
    }

    public String id() {
        return this.id;
    }

    public static TipoVia porOrdinal(int i) {
        TipoVia[] todos = values();
        return todos[Math.floorMod(i, todos.length)];
    }
}
