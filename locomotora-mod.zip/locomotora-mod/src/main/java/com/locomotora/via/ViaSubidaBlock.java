package com.locomotora.via;

import com.mojang.serialization.MapCodec;

import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.RailShape;

/**
 * Bloque de una vía en subida. Para las vagonetas sube a escalones (riel plano, riel en subida, plano...), pero se
 * dibuja como una rampa pareja con su terraplén de balasto.
 */
public class ViaSubidaBlock extends ViaBlock {
    public static final MapCodec<ViaSubidaBlock> CODEC = simpleCodec(ViaSubidaBlock::new);
    public static final EnumProperty<RailShape> SHAPE = BlockStateProperties.RAIL_SHAPE_STRAIGHT;

    public ViaSubidaBlock(BlockBehaviour.Properties propiedades) {
        super(propiedades);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(SHAPE, RailShape.NORTH_SOUTH)
                .setValue(WATERLOGGED, Boolean.FALSE));
    }

    @Override
    public MapCodec<? extends BaseRailBlock> codec() {
        return CODEC;
    }

    @Override
    public TipoVia tipoVia() {
        return TipoVia.SUBIDA;
    }

    @Override
    public Property<RailShape> getShapeProperty() {
        return SHAPE;
    }

    @Override
    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(SHAPE, WATERLOGGED);
    }
}
