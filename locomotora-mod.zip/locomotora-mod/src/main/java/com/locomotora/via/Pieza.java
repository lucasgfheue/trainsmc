package com.locomotora.via;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Una pieza de vía puesta en el mundo: qué bloques ocupa, qué forma de riel tiene cada uno (la física de las vagonetas
 * es la del juego) y el trazo redondo que se dibuja (y por donde se dibujan los trenes).
 * <p>
 * Coordenadas locales: u hacia adelante, v hacia la derecha, h hacia arriba. La celda (i, j) con altura k ocupa
 * u en [i, i+1], v en [j, j+1] y la altura [k, k+1]. La pieza entra por el borde de atrás de la celda (0, 0), en
 * (u, v) = (0, 0.5), mirando hacia +u. Una pieza "a la izquierda" es el espejo (v pasa a 1 - v).
 * <p>
 * No usa nada del juego (se prueba sola): las formas de riel tienen los mismos nombres que {@code RailShape}.
 * Las cuentas son con {@link StrictMath} para que el servidor y cada cliente den exactamente lo mismo.
 */
public final class Pieza {
    /** Altura de la parte de arriba de los rieles nuevos sobre el bloque (los del juego están a 1/16). */
    public static final double ALTO_PROPIO = 2.0 / 16.0;
    /** Rutas del desvío. */
    public static final int RECTA = 0;
    public static final int CURVA = 1;

    // ------------------------------------------------------------------ rumbos y formas
    public enum Rumbo {
        ESTE(1, 0), SUR(0, 1), OESTE(-1, 0), NORTE(0, -1);

        public final int dx;
        public final int dz;

        Rumbo(int dx, int dz) {
            this.dx = dx;
            this.dz = dz;
        }

        public Rumbo contrario() {
            return switch (this) {
                case ESTE -> OESTE;
                case OESTE -> ESTE;
                case SUR -> NORTE;
                case NORTE -> SUR;
            };
        }
    }

    /** Las formas de riel del juego (mismos nombres que RailShape). */
    public enum Forma {
        NORTH_SOUTH, EAST_WEST, ASCENDING_EAST, ASCENDING_WEST, ASCENDING_NORTH, ASCENDING_SOUTH,
        SOUTH_EAST, SOUTH_WEST, NORTH_WEST, NORTH_EAST;

        /** La forma plana que une los dos lados (dx, dz) dados. */
        static Forma deLados(int ax, int az, int bx, int bz) {
            boolean n = (az == -1 && ax == 0) || (bz == -1 && bx == 0);
            boolean s = (az == 1 && ax == 0) || (bz == 1 && bx == 0);
            boolean e = (ax == 1 && az == 0) || (bx == 1 && bz == 0);
            boolean o = (ax == -1 && az == 0) || (bx == -1 && bz == 0);
            if (n && s) {
                return NORTH_SOUTH;
            }
            if (e && o) {
                return EAST_WEST;
            }
            if (s && e) {
                return SOUTH_EAST;
            }
            if (s && o) {
                return SOUTH_WEST;
            }
            if (n && o) {
                return NORTH_WEST;
            }
            if (n && e) {
                return NORTH_EAST;
            }
            throw new IllegalArgumentException("lados que no forman un riel");
        }

        /** El riel en subida que sube hacia el lado (dx, dz). */
        static Forma subidaHacia(int dx, int dz) {
            if (dx == 1) {
                return ASCENDING_EAST;
            }
            if (dx == -1) {
                return ASCENDING_WEST;
            }
            return dz == 1 ? ASCENDING_SOUTH : ASCENDING_NORTH;
        }

        /** Las dos salidas: {dx, dz, dx, dz}. */
        public int[] lados() {
            return switch (this) {
                case NORTH_SOUTH, ASCENDING_NORTH, ASCENDING_SOUTH -> new int[]{0, -1, 0, 1};
                case EAST_WEST, ASCENDING_EAST, ASCENDING_WEST -> new int[]{-1, 0, 1, 0};
                case SOUTH_EAST -> new int[]{0, 1, 1, 0};
                case SOUTH_WEST -> new int[]{0, 1, -1, 0};
                case NORTH_WEST -> new int[]{0, -1, -1, 0};
                case NORTH_EAST -> new int[]{0, -1, 1, 0};
            };
        }

        public boolean tieneLado(int dx, int dz) {
            int[] l = lados();
            return (l[0] == dx && l[1] == dz) || (l[2] == dx && l[3] == dz);
        }
    }

    // ------------------------------------------------------------------ tramos del trazo (en coordenadas locales)
    /** Un tramo del trazo: segmento recto o cuarto de círculo. */
    public abstract static class Tramo {
        public abstract double largo();

        /** Punto (u, v, h) a la distancia s del principio del tramo. */
        public abstract double[] punto(double s);

        /** Hacia dónde va (u, v, h), de largo 1. */
        public abstract double[] tangente(double s);

        /** {distancia en planta, s} del punto del tramo más cercano a (u, v). */
        public abstract double[] cercano(double u, double v);

        /** Radio si es curvo; 0 si es recto. */
        public abstract double radio();
    }

    public static final class Linea extends Tramo {
        final double[] a;
        final double[] b;
        final double largo;

        Linea(double au, double av, double ah, double bu, double bv, double bh) {
            this.a = new double[]{au, av, ah};
            this.b = new double[]{bu, bv, bh};
            double du = bu - au;
            double dv = bv - av;
            double dh = bh - ah;
            this.largo = StrictMath.sqrt(du * du + dv * dv + dh * dh);
        }

        @Override
        public double largo() {
            return this.largo;
        }

        @Override
        public double[] punto(double s) {
            double k = this.largo > 0.0 ? s / this.largo : 0.0;
            return new double[]{this.a[0] + (this.b[0] - this.a[0]) * k, this.a[1] + (this.b[1] - this.a[1]) * k,
                    this.a[2] + (this.b[2] - this.a[2]) * k};
        }

        @Override
        public double[] tangente(double s) {
            return new double[]{(this.b[0] - this.a[0]) / this.largo, (this.b[1] - this.a[1]) / this.largo,
                    (this.b[2] - this.a[2]) / this.largo};
        }

        @Override
        public double[] cercano(double u, double v) {
            double du = this.b[0] - this.a[0];
            double dv = this.b[1] - this.a[1];
            double l2 = du * du + dv * dv;
            double k = l2 > 0.0 ? Math.max(0.0, Math.min(1.0, ((u - this.a[0]) * du + (v - this.a[1]) * dv) / l2)) : 0.0;
            double pu = this.a[0] + du * k;
            double pv = this.a[1] + dv * k;
            return new double[]{hypot(u - pu, v - pv), k * this.largo};
        }

        @Override
        public double radio() {
            return 0.0;
        }
    }

    /** Cuarto de círculo plano: punto = c + r (sin t, -cos t), t de 0 a pi/2 (gira hacia +v), a la altura h. */
    public static final class Arco extends Tramo {
        final double cu;
        final double cv;
        final double r;
        final double h;
        final double largo;

        Arco(double cu, double cv, double r, double h) {
            this.cu = cu;
            this.cv = cv;
            this.r = r;
            this.h = h;
            this.largo = r * Math.PI / 2.0;
        }

        @Override
        public double largo() {
            return this.largo;
        }

        @Override
        public double[] punto(double s) {
            double t = s / this.r;
            return new double[]{this.cu + this.r * StrictMath.sin(t), this.cv - this.r * StrictMath.cos(t), this.h};
        }

        @Override
        public double[] tangente(double s) {
            double t = s / this.r;
            return new double[]{StrictMath.cos(t), StrictMath.sin(t), 0.0};
        }

        @Override
        public double[] cercano(double u, double v) {
            double t = StrictMath.atan2(u - this.cu, -(v - this.cv));
            t = Math.max(0.0, Math.min(Math.PI / 2.0, t));
            double pu = this.cu + this.r * StrictMath.sin(t);
            double pv = this.cv - this.r * StrictMath.cos(t);
            return new double[]{hypot(u - pu, v - pv), t * this.r};
        }

        @Override
        public double radio() {
            return this.r;
        }
    }

    /** Varios tramos seguidos: el camino de una ruta de la pieza. */
    public static final class Trazo {
        final List<Tramo> tramos;
        final double largo;

        Trazo(List<Tramo> tramos) {
            this.tramos = tramos;
            double l = 0.0;
            for (Tramo t : tramos) {
                l += t.largo();
            }
            this.largo = l;
        }

        public double largo() {
            return this.largo;
        }

        public List<Tramo> tramos() {
            return this.tramos;
        }

        public double[] punto(double s) {
            for (int i = 0; i < this.tramos.size(); i++) {
                Tramo t = this.tramos.get(i);
                if (s <= t.largo() || i == this.tramos.size() - 1) {
                    return t.punto(Math.min(Math.max(s, 0.0), t.largo()));
                }
                s -= t.largo();
            }
            throw new IllegalStateException();
        }

        public double[] tangente(double s) {
            for (int i = 0; i < this.tramos.size(); i++) {
                Tramo t = this.tramos.get(i);
                if (s <= t.largo() || i == this.tramos.size() - 1) {
                    return t.tangente(Math.min(Math.max(s, 0.0), t.largo()));
                }
                s -= t.largo();
            }
            throw new IllegalStateException();
        }

        /** {distancia en planta, s sobre el trazo} del punto más cercano a (u, v). */
        public double[] cercano(double u, double v) {
            double mejor = 1.0E18;
            double sMejor = 0.0;
            double base = 0.0;
            for (Tramo t : this.tramos) {
                double[] c = t.cercano(u, v);
                if (c[0] < mejor - 1.0E-9) {
                    mejor = c[0];
                    sMejor = base + c[1];
                }
                base += t.largo();
            }
            return new double[]{mejor, sMejor};
        }
    }

    static Trazo trazoRecta(int largo) {
        return new Trazo(List.of(new Linea(0.0, 0.5, 0.0, largo, 0.5, 0.0)));
    }

    static Trazo trazoCurva(int r) {
        return new Trazo(List.of(new Linea(0.0, 0.5, 0.0, 0.5, 0.5, 0.0), new Arco(0.5, 0.5 + r, r, 0.0),
                new Linea(r + 0.5, r + 0.5, 0.0, r + 0.5, r + 1.0, 0.0)));
    }

    static Trazo trazoSubida(int largo, int alto) {
        return new Trazo(List.of(new Linea(0.0, 0.5, 0.0, largo, 0.5, alto)));
    }

    /** Las celdas (i, j) por las que pasa un trazo plano, en orden y unidas siempre por un lado (nunca en diagonal). */
    static List<int[]> celdasDe(Trazo trazo) {
        List<int[]> celdas = new ArrayList<>();
        double paso = 0.02;
        double s = 0.0;
        while (s < trazo.largo - 1.0E-9) {
            double[] p = trazo.punto(s);
            int cu = (int) Math.floor(p[0]);
            int cv = (int) Math.floor(p[1]);
            int[] previa = celdas.isEmpty() ? null : celdas.get(celdas.size() - 1);
            if (previa == null || previa[0] != cu || previa[1] != cv) {
                if (previa != null && Math.abs(cu - previa[0]) + Math.abs(cv - previa[1]) == 2) {
                    // pasó justo por una esquina: va la celda del medio más cercana al trazo
                    double da = trazo.cercano(cu + 0.5, previa[1] + 0.5)[0];
                    double db = trazo.cercano(previa[0] + 0.5, cv + 0.5)[0];
                    celdas.add(da <= db ? new int[]{cu, previa[1]} : new int[]{previa[0], cv});
                }
                celdas.add(new int[]{cu, cv});
            }
            s += paso;
        }
        return celdas;
    }

    // ------------------------------------------------------------------ rutas y celdas
    /** Una ruta de la pieza (la única, o la recta / la curva del desvío). */
    public static final class Ruta {
        public final Trazo trazo;
        /** Celdas locales {i, j, k} en orden. */
        final int[][] celdas;
        /** Forma de riel de cada celda (en el mundo). */
        final Forma[] formas;

        Ruta(Trazo trazo, int[][] celdas, Forma[] formas) {
            this.trazo = trazo;
            this.celdas = celdas;
            this.formas = formas;
        }

        public int cantidad() {
            return this.celdas.length;
        }
    }

    /** Lo que se sabe de un bloque de la pieza. */
    public static final class Celda {
        public final int x;
        public final int y;
        public final int z;
        /** Forma por ruta (null si la ruta no pasa por acá). */
        public final Forma[] formas;
        /** Índice local hacia adelante (u) de la celda en la primera ruta que pasa por acá. */
        public final int indice;

        Celda(int x, int y, int z, int rutas, int indice) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.formas = new Forma[rutas];
            this.indice = indice;
        }

        /** La forma normal del bloque: la de la recta si la tiene (en el desvío), si no la de su única ruta. */
        public Forma forma() {
            for (Forma f : this.formas) {
                if (f != null) {
                    return f;
                }
            }
            throw new IllegalStateException();
        }

        /** ¿Es la aguja del desvío? (las dos rutas pasan y con distinta forma) */
        public boolean esAguja() {
            return this.formas.length == 2 && this.formas[0] != null && this.formas[1] != null
                    && this.formas[0] != this.formas[1];
        }

        /** ¿Las dos rutas pasan por acá con la misma forma? (tramo común del desvío) */
        public boolean esComun() {
            return this.formas.length == 2 && this.formas[0] != null && this.formas[0] == this.formas[1];
        }

        /** La única ruta que pasa por acá, o -1 si pasan las dos. */
        public int rutaUnica() {
            if (this.formas.length == 1) {
                return 0;
            }
            if (this.formas[0] != null && this.formas[1] != null) {
                return -1;
            }
            return this.formas[0] != null ? 0 : 1;
        }
    }

    // ------------------------------------------------------------------ la pieza
    public final TipoVia tipo;
    public final int ox;
    public final int oy;
    public final int oz;
    public final Rumbo rumbo;
    public final boolean izquierda;
    public final int largo;
    public final int radio;
    public final int alto;
    public final int paso;
    private final Ruta[] rutas;
    /** Desvío: u de la celda de la aguja. */
    private final int agujaU;
    private final Map<Long, Celda> celdas = new LinkedHashMap<>();

    /** Piezas ya armadas (todos los bloques de una pieza la comparten): se arman una sola vez. */
    private static final Map<String, Pieza> ARMADAS = new LinkedHashMap<>(64, 0.75F, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Pieza> mas) {
            return size() > 512;
        }
    };

    /** La pieza con esos datos (la misma para todos los bloques que la piden). */
    public static Pieza obtener(TipoVia tipo, int ox, int oy, int oz, Rumbo rumbo, boolean izquierda, int largo,
                                int radio, int alto, int paso) {
        String clave = tipo.ordinal() + ":" + ox + ":" + oy + ":" + oz + ":" + rumbo.ordinal() + ":" + izquierda + ":"
                + largo + ":" + radio + ":" + alto + ":" + paso;
        synchronized (ARMADAS) {
            Pieza p = ARMADAS.get(clave);
            if (p == null) {
                p = new Pieza(tipo, ox, oy, oz, rumbo, izquierda, largo, radio, alto, paso);
                ARMADAS.put(clave, p);
            }
            return p;
        }
    }

    public Pieza(TipoVia tipo, int ox, int oy, int oz, Rumbo rumbo, boolean izquierda, int largo, int radio, int alto,
                 int paso) {
        this.tipo = tipo;
        this.ox = ox;
        this.oy = oy;
        this.oz = oz;
        this.rumbo = rumbo;
        this.izquierda = izquierda;
        this.radio = Math.max(2, Math.min(ConfigVia.MAX, radio));
        this.paso = Math.max(1, Math.min(4, paso));
        this.alto = Math.max(1, Math.min(ConfigVia.MAX / this.paso, alto));
        int l = Math.max(1, Math.min(ConfigVia.MAX, largo));
        int agU = -1;
        switch (tipo) {
            case RECTA -> {
                this.rutas = new Ruta[]{rectaDe(l)};
                this.largo = l;
            }
            case CURVA -> {
                Trazo tr = trazoCurva(this.radio);
                List<int[]> cel = celdasDe(tr);
                this.rutas = new Ruta[]{curvaDe(tr, cel)};
                this.largo = l;
            }
            case DOS_CAMINOS -> {
                Trazo trc = trazoCurva(this.radio);
                List<int[]> celc = celdasDe(trc);
                int d = 0;
                while (celc.get(d)[1] == 0) {
                    d++;
                }
                agU = celc.get(d - 1)[0];
                // la recta tiene que pasar la aguja
                this.largo = Math.max(l, agU + 2);
                this.rutas = new Ruta[]{rectaDe(this.largo), curvaDe(trc, celc)};
            }
            default -> {
                int n = this.alto * this.paso;
                this.largo = n;
                int medio = (this.paso - 1) / 2;
                int[][] cel = new int[n][];
                Forma[] formas = new Forma[n];
                int[] adelante = ladoAMundo(1, 0);
                Forma plana = Forma.deLados(-adelante[0], -adelante[1], adelante[0], adelante[1]);
                Forma sube = Forma.subidaHacia(adelante[0], adelante[1]);
                for (int i = 0; i < n; i++) {
                    int g = i / this.paso;
                    int m = i % this.paso;
                    cel[i] = new int[]{i, 0, g + (m > medio ? 1 : 0)};
                    formas[i] = m == medio ? sube : plana;
                }
                this.rutas = new Ruta[]{new Ruta(trazoSubida(n, this.alto), cel, formas)};
            }
        }
        this.agujaU = agU;
        for (int r = 0; r < this.rutas.length; r++) {
            Ruta ruta = this.rutas[r];
            for (int k = 0; k < ruta.celdas.length; k++) {
                int[] c = ruta.celdas[k];
                int[] p = celdaAMundo(c[0], c[1], c[2]);
                long clave = clave(p[0], p[1], p[2]);
                Celda celda = this.celdas.get(clave);
                if (celda == null) {
                    celda = new Celda(p[0], p[1], p[2], this.rutas.length, c[0]);
                    this.celdas.put(clave, celda);
                }
                celda.formas[r] = ruta.formas[k];
            }
        }
    }

    private Ruta rectaDe(int n) {
        int[][] cel = new int[n][];
        Forma[] formas = new Forma[n];
        int[] adelante = ladoAMundo(1, 0);
        Forma f = Forma.deLados(-adelante[0], -adelante[1], adelante[0], adelante[1]);
        for (int i = 0; i < n; i++) {
            cel[i] = new int[]{i, 0, 0};
            formas[i] = f;
        }
        return new Ruta(trazoRecta(n), cel, formas);
    }

    /** Curva: entra por atrás de la primera celda y sale por la derecha (local) de la última. */
    private Ruta curvaDe(Trazo tr, List<int[]> cel) {
        int n = cel.size();
        int[][] celdas = new int[n][];
        Forma[] formas = new Forma[n];
        for (int k = 0; k < n; k++) {
            int[] c = cel.get(k);
            celdas[k] = new int[]{c[0], c[1], 0};
            int eu;
            int ev;
            int su;
            int sv;
            if (k == 0) {
                eu = -1;
                ev = 0;
            } else {
                eu = cel.get(k - 1)[0] - c[0];
                ev = cel.get(k - 1)[1] - c[1];
            }
            if (k == n - 1) {
                su = 0;
                sv = 1;
            } else {
                su = cel.get(k + 1)[0] - c[0];
                sv = cel.get(k + 1)[1] - c[1];
            }
            int[] e = ladoAMundo(eu, ev);
            int[] s = ladoAMundo(su, sv);
            formas[k] = Forma.deLados(e[0], e[1], s[0], s[1]);
        }
        return new Ruta(tr, celdas, formas);
    }

    // ------------------------------------------------------------------ de local a mundo y al revés
    public double[] aMundo(double u, double v, double h) {
        if (this.izquierda) {
            v = 1.0 - v;
        }
        double x;
        double z;
        switch (this.rumbo) {
            case ESTE -> {
                x = this.ox + u;
                z = this.oz + v;
            }
            case SUR -> {
                x = this.ox + 1 - v;
                z = this.oz + u;
            }
            case OESTE -> {
                x = this.ox + 1 - u;
                z = this.oz + 1 - v;
            }
            default -> {
                x = this.ox + v;
                z = this.oz + 1 - u;
            }
        }
        return new double[]{x, this.oy + h, z};
    }

    public double[] aLocal(double x, double y, double z) {
        double u;
        double v;
        switch (this.rumbo) {
            case ESTE -> {
                u = x - this.ox;
                v = z - this.oz;
            }
            case SUR -> {
                u = z - this.oz;
                v = this.ox + 1 - x;
            }
            case OESTE -> {
                u = this.ox + 1 - x;
                v = this.oz + 1 - z;
            }
            default -> {
                u = this.oz + 1 - z;
                v = x - this.ox;
            }
        }
        if (this.izquierda) {
            v = 1.0 - v;
        }
        return new double[]{u, v, y - this.oy};
    }

    public int[] celdaAMundo(int i, int j, int k) {
        double[] p = aMundo(i + 0.5, j + 0.5, k);
        return new int[]{(int) Math.floor(p[0]), (int) Math.floor(p[1] + 0.5), (int) Math.floor(p[2])};
    }

    /** Un lado local (du, dv) como lado del mundo (dx, dz). */
    public int[] ladoAMundo(int du, int dv) {
        if (this.izquierda) {
            dv = -dv;
        }
        return switch (this.rumbo) {
            case ESTE -> new int[]{du, dv};
            case SUR -> new int[]{-dv, du};
            case OESTE -> new int[]{-du, -dv};
            case NORTE -> new int[]{dv, -du};
        };
    }

    // ------------------------------------------------------------------ consultas
    public static long clave(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (long) (y & 0xFFF);
    }

    /** Todos los bloques de la pieza (sin repetir), en orden. */
    public Collection<Celda> celdas() {
        return Collections.unmodifiableCollection(this.celdas.values());
    }

    /** El bloque (x, y, z) de la pieza, o null si no es suyo. */
    public Celda celda(int x, int y, int z) {
        return this.celdas.get(clave(x, y, z));
    }

    public int cantidadRutas() {
        return this.rutas.length;
    }

    public Ruta ruta(int i) {
        return this.rutas[i];
    }

    /** Desvío: el bloque de la aguja {x, y, z}; null en las otras piezas. */
    public int[] aguja() {
        return this.tipo == TipoVia.DOS_CAMINOS ? celdaAMundo(this.agujaU, 0, 0) : null;
    }

    /** Desvío: u local de la aguja (-1 en las otras piezas). */
    public int agujaU() {
        return this.agujaU;
    }

    /**
     * Desvío: la caja (minX, minY, minZ, maxX, maxY, maxZ) que cubre el tramo común y la aguja: mientras haya una
     * vagoneta ahí no se puede cambiar la aguja.
     */
    public double[] zonaAguja() {
        double[] a = aMundo(-0.2, -0.2, 0.0);
        double[] b = aMundo(this.agujaU + 1.2, 1.2, 0.0);
        return new double[]{Math.min(a[0], b[0]), this.oy - 0.5, Math.min(a[2], b[2]),
                Math.max(a[0], b[0]), this.oy + 2.0, Math.max(a[2], b[2])};
    }

    /**
     * Lleva un punto del camino de las vagonetas al trazo dibujado de la ruta (en planta) y le pone la altura de arriba
     * de los rieles nuevos.
     */
    public double[] ajustar(double x, double y, double z, int ruta) {
        Trazo tr = this.rutas[ruta].trazo;
        double[] l = aLocal(x, y, z);
        double[] c = tr.cercano(l[0], l[1]);
        double[] p = tr.punto(c[1]);
        double[] m = aMundo(p[0], p[1], p[2]);
        m[1] += ALTO_PROPIO;
        return m;
    }

    // ------------------------------------------------------------------ soportes (balasto donde falta piso)
    /**
     * En la subida, las celdas que quedan después de la celda en subida de cada tramo tienen el trazo dibujado por
     * debajo de su piso (la rampa dibujada va pareja y las celdas suben de a escalones): debajo va una losa.
     */
    public boolean hunde(int i) {
        if (this.tipo != TipoVia.SUBIDA) {
            return false;
        }
        return i % this.paso > (this.paso - 1) / 2;
    }

    /** Altura (local) hasta donde se dibuja el terraplén de la celda i: lo de arriba de su soporte. */
    public double pisoDibujo(int i) {
        int k = this.tipo == TipoVia.SUBIDA ? this.rutas[0].celdas[i][2] : 0;
        return hunde(i) ? k - 0.5 : k;
    }

    /**
     * Columnas de soporte, cada una de arriba hacia abajo: {x, y, z, 1 si va una losa / 0 si va un bloque}. Van desde
     * abajo de cada celda hasta el nivel del piso de la primera celda. Al ponerlas, cada lugar se llena si está libre y
     * la columna se corta en el primer bloque firme que encuentra.
     */
    public List<int[][]> soportes() {
        List<int[][]> columnas = new ArrayList<>();
        java.util.Set<Long> vistas = new java.util.HashSet<>();
        for (Ruta ruta : this.rutas) {
            for (int i = 0; i < ruta.celdas.length; i++) {
                int[] c = ruta.celdas[i];
                int[] p = celdaAMundo(c[0], c[1], c[2]);
                if (!vistas.add(clave(p[0], 0, p[2]))) {
                    continue;
                }
                int n = p[1] - 1 - (this.oy - 2);
                int[][] col = new int[n][];
                for (int k = 0; k < n; k++) {
                    int yy = p[1] - 1 - k;
                    col[k] = new int[]{p[0], yy, p[2], (k == 0 && hunde(i)) ? 1 : 0};
                }
                columnas.add(col);
            }
        }
        return columnas;
    }

    /** Ancho y fondo que ocupa la pieza (en bloques), para mostrar en el menú. */
    public int[] tamano() {
        int minX = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int minZ = Integer.MAX_VALUE;
        int maxZ = Integer.MIN_VALUE;
        int minY = Integer.MAX_VALUE;
        int maxY = Integer.MIN_VALUE;
        for (Celda c : this.celdas.values()) {
            minX = Math.min(minX, c.x);
            maxX = Math.max(maxX, c.x);
            minZ = Math.min(minZ, c.z);
            maxZ = Math.max(maxZ, c.z);
            minY = Math.min(minY, c.y);
            maxY = Math.max(maxY, c.y);
        }
        return new int[]{maxX - minX + 1, maxZ - minZ + 1, maxY - minY};
    }

    /** ¿Describe la misma pieza? (mismos datos y en el mismo lugar) */
    public boolean misma(Pieza o) {
        return o != null && o.tipo == this.tipo && o.ox == this.ox && o.oy == this.oy && o.oz == this.oz
                && o.rumbo == this.rumbo && o.izquierda == this.izquierda && o.largo == this.largo
                && o.radio == this.radio && o.alto == this.alto && o.paso == this.paso;
    }

    static double hypot(double a, double b) {
        return StrictMath.sqrt(a * a + b * b);
    }
}
