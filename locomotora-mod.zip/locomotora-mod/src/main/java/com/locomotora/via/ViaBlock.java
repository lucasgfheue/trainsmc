package com.locomotora.via;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.level.material.PushReaction;

/**
 * Un bloque de una pieza de vía del mod. Para las vagonetas es un riel común (la forma de cada bloque la eligió la
 * pieza al ponerla y nunca cambia sola: los rieles de al lado no la tuercen). Cada bloque guarda la pieza entera, así
 * al romper uno se quita toda y se recupera el ítem con la misma configuración.
 */
public abstract class ViaBlock extends BaseRailBlock implements EntityBlock {
    /** Mientras se quita una pieza entera, los otros bloques no vuelven a quitarla. */
    private static final ThreadLocal<Boolean> QUITANDO = ThreadLocal.withInitial(() -> Boolean.FALSE);

    protected ViaBlock(BlockBehaviour.Properties propiedades) {
        super(true, propiedades);
    }

    public static BlockBehaviour.Properties propiedades() {
        return BlockBehaviour.Properties.of()
                .noCollission()
                .strength(0.7F)
                .sound(SoundType.METAL)
                .pushReaction(PushReaction.BLOCK)
                .noLootTable();
    }

    /** Qué pieza forma este bloque. */
    public abstract TipoVia tipoVia();

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState estado) {
        return new ViaBlockEntity(pos, estado);
    }

    /** Las piezas curvas, el desvío y la subida se dibujan con su propio dibujante (redondas). */
    @Override
    public RenderShape getRenderShape(BlockState estado) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    // ------------------------------------------------------------------ la forma no cambia sola
    /** Ningún riel vecino puede cambiarle la forma a un bloque de una pieza. */
    @Override
    public boolean isValidRailShape(RailShape forma) {
        return false;
    }

    @Override
    public boolean isFlexibleRail(BlockState estado, BlockGetter level, BlockPos pos) {
        return false;
    }

    @Override
    public boolean canMakeSlopes(BlockState estado, BlockGetter level, BlockPos pos) {
        return false;
    }

    @Override
    public BlockState updateDir(Level level, BlockPos pos, BlockState estado, boolean siempre) {
        return estado;
    }

    @Override
    public void onPlace(BlockState estado, Level level, BlockPos pos, BlockState anterior, boolean movido) {
        // nada: la pieza ya viene armada
    }

    @Override
    public void neighborChanged(BlockState estado, Level level, BlockPos pos, Block vecino, BlockPos desde,
                                   boolean movido) {
        // nada: no se cae si le sacan el piso ni se tuerce
    }

    @Override
    public boolean canSurvive(BlockState estado, LevelReader level, BlockPos pos) {
        return true;
    }

    // ------------------------------------------------------------------ quitar la pieza entera
    @Nullable
    public static ViaBlockEntity entidad(BlockGetter level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof ViaBlockEntity v ? v : null;
    }

    @Nullable
    public static Pieza pieza(BlockGetter level, BlockPos pos) {
        ViaBlockEntity v = entidad(level, pos);
        return v != null ? v.pieza() : null;
    }

    /** El ítem que devuelve la pieza (con la misma configuración). */
    public ItemStack kit(BlockGetter level, BlockPos pos) {
        ViaBlockEntity v = entidad(level, pos);
        ConfigVia config = v != null && v.config() != null ? v.config() : new ConfigVia(tipoVia());
        return ViaItem.kit(config);
    }

    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState estado, Player jugador) {
        if (!level.isClientSide && !jugador.isCreative()) {
            popResource(level, pos, kit(level, pos));
        }
        return super.playerWillDestroy(level, pos, estado, jugador);
    }

    @Override
    public void onBlockExploded(BlockState estado, Level level, BlockPos pos, Explosion explosion) {
        if (!level.isClientSide && entidad(level, pos) != null) {
            popResource(level, pos, kit(level, pos));
        }
        super.onBlockExploded(estado, level, pos, explosion);
    }

    @Override
    public ItemStack getCloneItemStack(LevelReader level, BlockPos pos, BlockState estado) {
        return kit(level, pos);
    }

    @Override
    public void onRemove(BlockState estado, Level level, BlockPos pos, BlockState nuevo, boolean movido) {
        if (!level.isClientSide && !nuevo.is(estado.getBlock()) && !QUITANDO.get()) {
            Pieza p = pieza(level, pos);
            if (p != null) {
                QUITANDO.set(Boolean.TRUE);
                try {
                    for (Pieza.Celda c : p.celdas()) {
                        BlockPos otra = new BlockPos(c.x, c.y, c.z);
                        if (otra.equals(pos)) {
                            continue;
                        }
                        BlockState s = level.getBlockState(otra);
                        if (s.getBlock() instanceof ViaBlock && p.misma(pieza(level, otra))) {
                            level.removeBlock(otra, false);
                        }
                    }
                } finally {
                    QUITANDO.set(Boolean.FALSE);
                }
            }
        }
        super.onRemove(estado, level, pos, nuevo, movido);
    }
}
