package com.locomotora.via;

import com.mojang.serialization.MapCodec;

import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.RailShape;

/** Bloque de una vía recta: se dibuja con su modelo de bloque (dos durmientes y dos rieles). */
public class ViaRectaBlock extends ViaBlock {
    public static final MapCodec<ViaRectaBlock> CODEC = simpleCodec(ViaRectaBlock::new);
    public static final EnumProperty<RailShape> SHAPE = BlockStateProperties.RAIL_SHAPE_STRAIGHT;

    public ViaRectaBlock(BlockBehaviour.Properties propiedades) {
        super(propiedades);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(SHAPE, RailShape.NORTH_SOUTH)
                .setValue(WATERLOGGED, Boolean.FALSE));
    }

    @Override
    public MapCodec<? extends BaseRailBlock> codec() {
        return CODEC;
    }

    @Override
    public TipoVia tipoVia() {
        return TipoVia.RECTA;
    }

    @Override
    public Property<RailShape> getShapeProperty() {
        return SHAPE;
    }

    @Override
    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(SHAPE, WATERLOGGED);
    }

    @Override
    public RenderShape getRenderShape(BlockState estado) {
        return RenderShape.MODEL;
    }
}
