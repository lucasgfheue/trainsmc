package com.locomotora.item;

import java.util.List;

import com.locomotora.artillero.TrenArtillero;
import com.locomotora.entidad.Enganches;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.phys.Vec3;

/**
 * Para probar el tren artillero (modo creativo): pone en el riel un tren artillero hostil con sus vagones, con la
 * locomotora mirando hacia el jugador y los vagones detrás. No anda solo: espera a ver a alguien (que no esté en creativo).
 */
public class ArtilleroHostilItem extends Item {

    public ArtilleroHostilItem(Properties propiedades) {
        super(propiedades);
    }

    @Override
    public InteractionResult useOn(UseOnContext contexto) {
        Level level = contexto.getLevel();
        BlockPos pos = contexto.getClickedPos();
        BlockState estado = level.getBlockState(pos);
        if (!BaseRailBlock.isRail(estado)) {
            return InteractionResult.FAIL;
        }
        if (level instanceof ServerLevel servidor) {
            RailShape forma = estado.getBlock() instanceof BaseRailBlock riel
                    ? riel.getRailDirection(estado, level, pos, null)
                    : RailShape.NORTH_SOUTH;
            double altura = forma.isAscending() ? 0.5 : 0.0;
            Player jugador = contexto.getPlayer();
            Vec3 mirada = jugador != null
                    ? jugador.getLookAngle()
                    : Vec3.atLowerCornerOf(contexto.getHorizontalDirection().getNormal());
            // la locomotora mira hacia el jugador; los vagones quedan del otro lado
            float rumbo = Enganches.rumboSegunDireccion(-mirada.x, -mirada.z, forma);
            if (!TrenArtillero.ponerHostil(servidor, pos, altura, rumbo)) {
                return InteractionResult.FAIL;
            }
            if (jugador != null && !jugador.getAbilities().instabuild) {
                contexto.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext contexto, List<Component> lineas, TooltipFlag opciones) {
        lineas.add(Component.translatable("tooltip.locomotora.artillero_hostil").withStyle(ChatFormatting.GOLD));
        lineas.add(Component.translatable("tooltip.locomotora.artillero_hostil.uso").withStyle(ChatFormatting.GRAY));
    }
}
