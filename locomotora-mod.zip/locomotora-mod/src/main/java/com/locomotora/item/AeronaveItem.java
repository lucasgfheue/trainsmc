package com.locomotora.item;

import java.util.List;

import com.locomotora.aereo.AeronaveEntity;
import com.locomotora.aereo.TipoAeronave;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * Para ver de cerca un globo o un zeppelin (modo creativo): con clic derecho sale delante del jugador, hacia donde
 * mira, y se va volando como los que pasan solos. Un bombardero que sale así ataca también de día (si el jugador no
 * está en creativo).
 */
public class AeronaveItem extends Item {
    private final TipoAeronave tipo;

    public AeronaveItem(Properties propiedades, TipoAeronave tipo) {
        super(propiedades);
        this.tipo = tipo;
    }

    public TipoAeronave getTipo() {
        return this.tipo;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player jugador, InteractionHand mano) {
        ItemStack stack = jugador.getItemInHand(mano);
        if (level instanceof ServerLevel nivel) {
            AeronaveEntity.soltarDelante(nivel, this.tipo, jugador);
            if (!jugador.getAbilities().instabuild) {
                stack.shrink(1);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext contexto, List<Component> lineas, TooltipFlag opciones) {
        lineas.add(Component.translatable(this.tipo.globo() ? "tooltip.locomotora.globo" : "tooltip.locomotora.zeppelin",
                (int) this.tipo.vida()).withStyle(ChatFormatting.GOLD));
        if (this.tipo.hostil()) {
            lineas.add(Component.translatable(this.tipo.globo() ? "tooltip.locomotora.globo_bombardero"
                    : "tooltip.locomotora.zeppelin_bombardero").withStyle(ChatFormatting.RED));
        }
        lineas.add(Component.translatable("tooltip.locomotora.aeronave.uso").withStyle(ChatFormatting.GRAY));
    }
}
