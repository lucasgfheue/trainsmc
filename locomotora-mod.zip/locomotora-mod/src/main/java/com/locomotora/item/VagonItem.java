package com.locomotora.item;

import java.util.List;

import com.locomotora.entidad.Enganches;
import com.locomotora.entidad.TipoVagon;
import com.locomotora.entidad.VagonEntity;
import com.locomotora.registro.ModEntidades;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.Vec3;

/** Ítem que pone un vagón o un coche sobre un riel; si tiene una locomotora o un vagón al lado, se engancha solo. */
public class VagonItem extends Item {
    private final TipoVagon tipo;

    public VagonItem(Properties propiedades, TipoVagon tipo) {
        super(propiedades);
        this.tipo = tipo;
    }

    public TipoVagon getTipo() {
        return this.tipo;
    }

    @Override
    public InteractionResult useOn(UseOnContext contexto) {
        Level level = contexto.getLevel();
        BlockPos pos = contexto.getClickedPos();
        BlockState estado = level.getBlockState(pos);
        if (!BaseRailBlock.isRail(estado)) {
            return InteractionResult.FAIL;
        }

        ItemStack stack = contexto.getItemInHand();
        if (level instanceof ServerLevel servidor) {
            RailShape forma = estado.getBlock() instanceof BaseRailBlock riel
                    ? riel.getRailDirection(estado, level, pos, null)
                    : RailShape.NORTH_SOUTH;
            double altura = forma.isAscending() ? 0.5 : 0.0;

            VagonEntity vagon = ModEntidades.porTipo(this.tipo).get().create(servidor);
            if (vagon == null) {
                return InteractionResult.FAIL;
            }
            vagon.moveTo(pos.getX() + 0.5, pos.getY() + 0.0625 + altura, pos.getZ() + 0.5);

            Player jugador = contexto.getPlayer();
            Vec3 mirada = jugador != null
                    ? jugador.getLookAngle()
                    : Vec3.atLowerCornerOf(contexto.getHorizontalDirection().getNormal());
            vagon.orientarSegunDireccion(mirada.x, mirada.z, forma);

            Component nombre = stack.get(DataComponents.CUSTOM_NAME);
            if (nombre != null) {
                vagon.setCustomName(nombre);
            }

            servidor.addFreshEntity(vagon);
            servidor.gameEvent(GameEvent.ENTITY_PLACE, pos,
                    GameEvent.Context.of(jugador, servidor.getBlockState(pos.below())));

            Component aviso = Enganches.engancharAlColocar(vagon);
            if (aviso != null && jugador != null) {
                jugador.displayClientMessage(aviso, true);
            }
        }

        stack.shrink(1);
        return InteractionResult.sidedSuccess(level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext contexto, List<Component> lineas, TooltipFlag opciones) {
        lineas.add(Component.translatable("tooltip.locomotora." + this.tipo.nombreRegistro()).withStyle(ChatFormatting.GOLD));
        lineas.add(Component.translatable("tooltip.locomotora.vagon.colocar").withStyle(ChatFormatting.GRAY));
        if (this.tipo.esCoche()) {
            lineas.add(Component.translatable("tooltip.locomotora.coche.asientos", this.tipo.cantidadAsientos())
                    .withStyle(ChatFormatting.GRAY));
            lineas.add(Component.translatable("tooltip.locomotora.coche.animales").withStyle(ChatFormatting.GRAY));
        } else if (this.tipo.armado()) {
            lineas.add(Component.translatable("tooltip.locomotora.vagon.cabina", this.tipo.cantidadAsientos())
                    .withStyle(ChatFormatting.GRAY));
        } else {
            lineas.add(Component.translatable("tooltip.locomotora.vagon.cofre").withStyle(ChatFormatting.GRAY));
        }
        lineas.add(Component.translatable("tooltip.locomotora.vagon.enganche").withStyle(ChatFormatting.DARK_AQUA));
    }
}
