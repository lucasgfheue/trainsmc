package com.locomotora.registro;

import com.locomotora.LocomotoraMod;
import com.locomotora.entidad.TipoLocomotora;
import com.locomotora.entidad.TipoVagon;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** Pestañas del modo creativo: las locomotoras (con el bidón de diésel) por un lado y los vagones por otro. */
public final class ModPestanas {
    public static final DeferredRegister<CreativeModeTab> PESTANAS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LocomotoraMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> LOCOMOTORAS = PESTANAS.register("locomotoras",
            () -> CreativeModeTab.builder()
                    .withTabsBefore(CreativeModeTabs.SPAWN_EGGS)
                    .title(Component.translatable("itemGroup.locomotora.locomotoras"))
                    .icon(() -> new ItemStack(ModItems.SCOTSMAN.get()))
                    .displayItems((parametros, salida) -> {
                        for (TipoLocomotora tipo : TipoLocomotora.values()) {
                            salida.accept(ModItems.porTipo(tipo).get());
                        }
                        salida.accept(ModItems.BIDON_DIESEL.get());
                    })
                    .build());

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> VAGONES = PESTANAS.register("vagones",
            () -> CreativeModeTab.builder()
                    .withTabsBefore(LOCOMOTORAS.getId())
                    .title(Component.translatable("itemGroup.locomotora.vagones"))
                    .icon(() -> new ItemStack(ModItems.porTipo(TipoVagon.TOLVA).get()))
                    .displayItems((parametros, salida) -> {
                        for (TipoVagon tipo : TipoVagon.values()) {
                            salida.accept(ModItems.porTipo(tipo).get());
                        }
                    })
                    .build());

    private ModPestanas() {
    }
}
