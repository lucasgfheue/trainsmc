package com.locomotora.registro;

import net.minecraft.world.level.GameRules;

/**
 * Reglas del juego del mod (se cambian con /gamerule):
 * <ul>
 *   <li>{@code locomotoraTrenes}: si pasan trenes solos por las vías de la red (sí).</li>
 *   <li>{@code locomotoraMinutosTren}: cada cuántos minutos pasa uno (10).</li>
 *   <li>{@code locomotoraRedDeVias}: si se generan las vías infinitas y las estaciones en lo nuevo del mundo (sí).</li>
 * </ul>
 * Se registran en la preparación común del mod, en el hilo principal (la lista de reglas del juego no es para varios
 * hilos a la vez).
 */
public final class ModReglas {
    public static GameRules.Key<GameRules.BooleanValue> TRENES;
    public static GameRules.Key<GameRules.IntegerValue> MINUTOS_TREN;
    public static GameRules.Key<GameRules.BooleanValue> RED_DE_VIAS;

    private ModReglas() {
    }

    public static void registrar() {
        if (TRENES != null) {
            return;
        }
        TRENES = GameRules.register("locomotoraTrenes", GameRules.Category.MISC, GameRules.BooleanValue.create(true));
        MINUTOS_TREN = GameRules.register("locomotoraMinutosTren", GameRules.Category.MISC, GameRules.IntegerValue.create(10));
        RED_DE_VIAS = GameRules.register("locomotoraRedDeVias", GameRules.Category.MISC, GameRules.BooleanValue.create(true));
    }

    public static boolean trenes(GameRules reglas) {
        return TRENES == null || reglas.getBoolean(TRENES);
    }

    public static int minutosTren(GameRules reglas) {
        return MINUTOS_TREN == null ? 10 : reglas.getInt(MINUTOS_TREN);
    }

    public static boolean redDeVias(GameRules reglas) {
        return RED_DE_VIAS == null || reglas.getBoolean(RED_DE_VIAS);
    }
}
