package com.locomotora.registro;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.saveddata.SavedData;
import net.neoforged.neoforge.event.server.ServerStartedEvent;

/**
 * Reglas del juego del mod (se cambian con /gamerule):
 * <ul>
 *   <li>{@code locomotoraTrenes}: si pasan trenes solos por las vías de la red (sí).</li>
 *   <li>{@code locomotoraMinutosTren}: cada cuántos minutos pasa uno (5).</li>
 *   <li>{@code locomotoraRedDeVias}: si se generan las vías infinitas y las estaciones en lo nuevo del mundo (sí).</li>
 * </ul>
 * Se registran en la preparación común del mod, en el hilo principal (la lista de reglas del juego no es para varios
 * hilos a la vez).
 */
public final class ModReglas {
    /** Antes (hasta la versión 12) pasaba un tren cada 10 minutos. */
    private static final int MINUTOS_ANTES = 10;
    public static final int MINUTOS_DE_FABRICA = 5;
    /** Versión de los ajustes guardados en cada mundo (para pasar los mundos viejos a lo nuevo una sola vez). */
    private static final int VERSION_AJUSTES = 13;

    public static GameRules.Key<GameRules.BooleanValue> TRENES;
    public static GameRules.Key<GameRules.IntegerValue> MINUTOS_TREN;
    public static GameRules.Key<GameRules.BooleanValue> RED_DE_VIAS;

    private ModReglas() {
    }

    public static void registrar() {
        if (TRENES != null) {
            return;
        }
        TRENES = GameRules.register("locomotoraTrenes", GameRules.Category.MISC, GameRules.BooleanValue.create(true));
        MINUTOS_TREN = GameRules.register("locomotoraMinutosTren", GameRules.Category.MISC,
                GameRules.IntegerValue.create(MINUTOS_DE_FABRICA));
        RED_DE_VIAS = GameRules.register("locomotoraRedDeVias", GameRules.Category.MISC, GameRules.BooleanValue.create(true));
    }

    public static boolean trenes(GameRules reglas) {
        return TRENES == null || reglas.getBoolean(TRENES);
    }

    public static int minutosTren(GameRules reglas) {
        return MINUTOS_TREN == null ? MINUTOS_DE_FABRICA : reglas.getInt(MINUTOS_TREN);
    }

    public static boolean redDeVias(GameRules reglas) {
        return RED_DE_VIAS == null || reglas.getBoolean(RED_DE_VIAS);
    }

    /**
     * Al abrir un mundo hecho con una versión anterior del mod: si el tren seguía cada 10 minutos (lo de antes), pasa a
     * cada 5. Si alguien lo había cambiado a otro valor, se respeta. Se hace una sola vez por mundo.
     */
    public static void alArrancar(ServerStartedEvent evento) {
        MinecraftServer servidor = evento.getServer();
        ServerLevel mundo = servidor.overworld();
        if (mundo == null || MINUTOS_TREN == null) {
            return;
        }
        Ajustes ajustes = mundo.getDataStorage().computeIfAbsent(Ajustes.FABRICA, "locomotora_ajustes");
        if (ajustes.version >= VERSION_AJUSTES) {
            return;
        }
        GameRules.IntegerValue minutos = servidor.getGameRules().getRule(MINUTOS_TREN);
        if (minutos.get() == MINUTOS_ANTES) {
            minutos.set(MINUTOS_DE_FABRICA, servidor);
        }
        ajustes.version = VERSION_AJUSTES;
        ajustes.setDirty();
    }

    /** Lo que el mod guarda en cada mundo. */
    public static final class Ajustes extends SavedData {
        static final SavedData.Factory<Ajustes> FABRICA = new SavedData.Factory<>(Ajustes::new, Ajustes::cargar, null);

        int version;

        static Ajustes cargar(CompoundTag tag, HolderLookup.Provider registros) {
            Ajustes a = new Ajustes();
            a.version = tag.getInt("version");
            return a;
        }

        @Override
        public CompoundTag save(CompoundTag tag, HolderLookup.Provider registros) {
            tag.putInt("version", this.version);
            return tag;
        }
    }
}
