package com.locomotora.registro;

import com.locomotora.LocomotoraMod;
import com.locomotora.entidad.LocomotoraEntity;
import com.locomotora.entidad.TipoLocomotora;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntidades {
    public static final DeferredRegister<EntityType<?>> ENTIDADES =
            DeferredRegister.create(Registries.ENTITY_TYPE, LocomotoraMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> SCOTSMAN = registrar(TipoLocomotora.SCOTSMAN);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> F7 = registrar(TipoLocomotora.F7);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> V200 = registrar(TipoLocomotora.V200);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> MALLARD = registrar(TipoLocomotora.MALLARD);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> BIG_BOY = registrar(TipoLocomotora.BIG_BOY);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> GS4 = registrar(TipoLocomotora.GS4);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> BR01 = registrar(TipoLocomotora.BR01);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> PANNIER = registrar(TipoLocomotora.PANNIER);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> HST = registrar(TipoLocomotora.HST);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> DELTIC = registrar(TipoLocomotora.DELTIC);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> SD40 = registrar(TipoLocomotora.SD40);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> ES44 = registrar(TipoLocomotora.ES44);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> DD51 = registrar(TipoLocomotora.DD51);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> CLASS08 = registrar(TipoLocomotora.CLASS08);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> ROCKET = registrar(TipoLocomotora.ROCKET);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> JUPITER = registrar(TipoLocomotora.JUPITER);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> HIAWATHA = registrar(TipoLocomotora.HIAWATHA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> T1 = registrar(TipoLocomotora.T1);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> NWJ = registrar(TipoLocomotora.NWJ);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> MERCHANT = registrar(TipoLocomotora.MERCHANT);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> BR9F = registrar(TipoLocomotora.BR9F);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> D51 = registrar(TipoLocomotora.D51);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> P36 = registrar(TipoLocomotora.P36);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> GARRATT = registrar(TipoLocomotora.GARRATT);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> ZEPHYR = registrar(TipoLocomotora.ZEPHYR);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> HAMBURGER = registrar(TipoLocomotora.HAMBURGER);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> V160 = registrar(TipoLocomotora.V160);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> CC72000 = registrar(TipoLocomotora.CC72000);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> CHME3 = registrar(TipoLocomotora.CHME3);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> DF4 = registrar(TipoLocomotora.DF4);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> WDM2 = registrar(TipoLocomotora.WDM2);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> P42 = registrar(TipoLocomotora.P42);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> DF200 = registrar(TipoLocomotora.DF200);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> GP9_ABANDONADA = registrar(TipoLocomotora.GP9_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> E8_ABANDONADA = registrar(TipoLocomotora.E8_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> RS3_ABANDONADA = registrar(TipoLocomotora.RS3_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> RDC_ABANDONADO = registrar(TipoLocomotora.RDC_ABANDONADO);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> CLASS37_ABANDONADA = registrar(TipoLocomotora.CLASS37_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> CLASS20_ABANDONADA = registrar(TipoLocomotora.CLASS20_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> M62_ABANDONADA = registrar(TipoLocomotora.M62_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> TEP60_ABANDONADA = registrar(TipoLocomotora.TEP60_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> T478_ABANDONADA = registrar(TipoLocomotora.T478_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> KIHA40_ABANDONADO = registrar(TipoLocomotora.KIHA40_ABANDONADO);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> SHARKNOSE_ABANDONADA = registrar(TipoLocomotora.SHARKNOSE_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> LOCOMOTION = registrar(TipoLocomotora.LOCOMOTION);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> BEST_FRIEND = registrar(TipoLocomotora.BEST_FRIEND);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> JOHN_BULL = registrar(TipoLocomotora.JOHN_BULL);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> ADLER = registrar(TipoLocomotora.ADLER);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> COPPERNOB = registrar(TipoLocomotora.COPPERNOB);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> PORTENA = registrar(TipoLocomotora.PORTENA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> SHAY = registrar(TipoLocomotora.SHAY);

    private static DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> registrar(TipoLocomotora tipo) {
        String nombre = "locomotora_" + tipo.id();
        return ENTIDADES.register(nombre, () -> EntityType.Builder
                .<LocomotoraEntity>of((tipoEntidad, level) -> new LocomotoraEntity(tipoEntidad, level, tipo), MobCategory.MISC)
                // Ancho de vagoneta para que encaje en los rieles; necesita 2 bloques de alto libres
                .sized(0.98F, 1.4F)
                // Altura del asiento del maquinista en la cabina
                .passengerAttachments(tipo.alturaAsiento())
                .clientTrackingRange(12)
                .build(LocomotoraMod.id(nombre).toString()));
    }

    public static DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> porTipo(TipoLocomotora tipo) {
        return switch (tipo) {
            case SCOTSMAN -> SCOTSMAN;
            case F7 -> F7;
            case V200 -> V200;
            case MALLARD -> MALLARD;
            case BIG_BOY -> BIG_BOY;
            case GS4 -> GS4;
            case BR01 -> BR01;
            case PANNIER -> PANNIER;
            case HST -> HST;
            case DELTIC -> DELTIC;
            case SD40 -> SD40;
            case ES44 -> ES44;
            case DD51 -> DD51;
            case CLASS08 -> CLASS08;
            case ROCKET -> ROCKET;
            case JUPITER -> JUPITER;
            case HIAWATHA -> HIAWATHA;
            case T1 -> T1;
            case NWJ -> NWJ;
            case MERCHANT -> MERCHANT;
            case BR9F -> BR9F;
            case D51 -> D51;
            case P36 -> P36;
            case GARRATT -> GARRATT;
            case ZEPHYR -> ZEPHYR;
            case HAMBURGER -> HAMBURGER;
            case V160 -> V160;
            case CC72000 -> CC72000;
            case CHME3 -> CHME3;
            case DF4 -> DF4;
            case WDM2 -> WDM2;
            case P42 -> P42;
            case DF200 -> DF200;
            case GP9_ABANDONADA -> GP9_ABANDONADA;
            case E8_ABANDONADA -> E8_ABANDONADA;
            case RS3_ABANDONADA -> RS3_ABANDONADA;
            case RDC_ABANDONADO -> RDC_ABANDONADO;
            case CLASS37_ABANDONADA -> CLASS37_ABANDONADA;
            case CLASS20_ABANDONADA -> CLASS20_ABANDONADA;
            case M62_ABANDONADA -> M62_ABANDONADA;
            case TEP60_ABANDONADA -> TEP60_ABANDONADA;
            case T478_ABANDONADA -> T478_ABANDONADA;
            case KIHA40_ABANDONADO -> KIHA40_ABANDONADO;
            case SHARKNOSE_ABANDONADA -> SHARKNOSE_ABANDONADA;
            case LOCOMOTION -> LOCOMOTION;
            case BEST_FRIEND -> BEST_FRIEND;
            case JOHN_BULL -> JOHN_BULL;
            case ADLER -> ADLER;
            case COPPERNOB -> COPPERNOB;
            case PORTENA -> PORTENA;
            case SHAY -> SHAY;
        };
    }

    private ModEntidades() {
    }
}
