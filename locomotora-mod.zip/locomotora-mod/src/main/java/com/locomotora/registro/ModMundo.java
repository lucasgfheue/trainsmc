package com.locomotora.registro;

import com.locomotora.LocomotoraMod;
import com.locomotora.generacion.EstacionAbandonadaEstructura;
import com.locomotora.generacion.MarcaEstacion;
import com.locomotora.generacion.RedFeature;
import com.locomotora.generacion.UbicacionRed;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraft.world.level.levelgen.structure.placement.StructurePlacementType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * La generación del mundo: la red de vías infinitas con sus estaciones. La "feature" se agrega a todos los biomas del
 * mundo normal con data/locomotora/neoforge/biome_modifier/red_ferroviaria.json.
 * <p>
 * La estación abandonada además es una estructura del juego (sin bloques propios: solo marca el lugar), para que se
 * la encuentre con {@code /locate structure locomotora:estacion_abandonada}; ver
 * data/locomotora/worldgen/structure y structure_set.
 */
public final class ModMundo {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(Registries.FEATURE, LocomotoraMod.MODID);
    public static final DeferredRegister<StructureType<?>> ESTRUCTURAS =
            DeferredRegister.create(Registries.STRUCTURE_TYPE, LocomotoraMod.MODID);
    public static final DeferredRegister<StructurePieceType> PIEZAS =
            DeferredRegister.create(Registries.STRUCTURE_PIECE, LocomotoraMod.MODID);
    public static final DeferredRegister<StructurePlacementType<?>> UBICACIONES =
            DeferredRegister.create(Registries.STRUCTURE_PLACEMENT, LocomotoraMod.MODID);

    public static final DeferredHolder<Feature<?>, RedFeature> RED_FERROVIARIA =
            FEATURES.register("red_ferroviaria", () -> new RedFeature(NoneFeatureConfiguration.CODEC));

    public static final DeferredHolder<StructureType<?>, StructureType<EstacionAbandonadaEstructura>> ESTACION_ABANDONADA =
            ESTRUCTURAS.register("estacion_abandonada", () -> () -> EstacionAbandonadaEstructura.CODEC);

    public static final DeferredHolder<StructurePieceType, StructurePieceType> MARCA_ESTACION =
            PIEZAS.register("marca_estacion", () -> (StructurePieceType.ContextlessType) MarcaEstacion::new);

    public static final DeferredHolder<StructurePlacementType<?>, StructurePlacementType<UbicacionRed>> UBICACION_RED =
            UBICACIONES.register("red_ferroviaria", () -> () -> UbicacionRed.CODEC);

    private ModMundo() {
    }
}
