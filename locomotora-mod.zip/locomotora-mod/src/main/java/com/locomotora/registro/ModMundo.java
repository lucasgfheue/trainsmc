package com.locomotora.registro;

import com.locomotora.LocomotoraMod;
import com.locomotora.generacion.RedFeature;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * La generación del mundo: la red de vías infinitas con sus estaciones. La "feature" se agrega a todos los biomas del
 * mundo normal con data/locomotora/neoforge/biome_modifier/red_ferroviaria.json.
 */
public final class ModMundo {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(Registries.FEATURE, LocomotoraMod.MODID);

    public static final DeferredHolder<Feature<?>, RedFeature> RED_FERROVIARIA =
            FEATURES.register("red_ferroviaria", () -> new RedFeature(NoneFeatureConfiguration.CODEC));

    private ModMundo() {
    }
}
