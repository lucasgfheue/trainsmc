package com.locomotora;

import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModItems;
import com.locomotora.registro.ModPestanas;
import com.locomotora.registro.ModSonidos;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;

/**
 * Clase principal del mod "Locomotora de Vapor".
 * Registra los ítems, las entidades (locomotoras y vagones), los sonidos y las pestañas del modo creativo.
 */
@Mod(LocomotoraMod.MODID)
public class LocomotoraMod {
    public static final String MODID = "locomotora";

    public LocomotoraMod(IEventBus modEventBus, ModContainer modContainer) {
        ModItems.ITEMS.register(modEventBus);
        ModEntidades.ENTIDADES.register(modEventBus);
        ModSonidos.SONIDOS.register(modEventBus);
        // Dos pestañas propias en el modo creativo: "Locomotoras" y "Vagones"
        ModPestanas.PESTANAS.register(modEventBus);
    }

    public static ResourceLocation id(String ruta) {
        return ResourceLocation.fromNamespaceAndPath(MODID, ruta);
    }
}
