package com.locomotora;

import com.locomotora.registro.ModBloques;
import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModItems;
import com.locomotora.registro.ModPestanas;
import com.locomotora.registro.ModSonidos;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;

/**
 * Clase principal del mod "Locomotora de Vapor".
 * Registra los bloques (vías y balasto), los ítems, las entidades (locomotoras y vagones), los sonidos, el menú de las
 * vías y las pestañas del modo creativo.
 */
@Mod(LocomotoraMod.MODID)
public class LocomotoraMod {
    public static final String MODID = "locomotora";

    public LocomotoraMod(IEventBus modEventBus, ModContainer modContainer) {
        ModBloques.BLOQUES.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBloques.ENTIDADES_BLOQUE.register(modEventBus);
        ModBloques.MENUS.register(modEventBus);
        ModEntidades.ENTIDADES.register(modEventBus);
        ModSonidos.SONIDOS.register(modEventBus);
        // Tres pestañas propias en el modo creativo: "Locomotoras", "Vagones" y "Vías"
        ModPestanas.PESTANAS.register(modEventBus);
    }

    public static ResourceLocation id(String ruta) {
        return ResourceLocation.fromNamespaceAndPath(MODID, ruta);
    }
}
