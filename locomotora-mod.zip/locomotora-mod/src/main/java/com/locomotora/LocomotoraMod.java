package com.locomotora;

import com.locomotora.registro.ModBloques;
import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModItems;
import com.locomotora.registro.ModMundo;
import com.locomotora.registro.ModPestanas;
import com.locomotora.registro.ModReglas;
import com.locomotora.registro.ModSonidos;
import com.locomotora.tren.Despachante;

import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;

/**
 * Clase principal del mod "Locomotora de Vapor".
 * Registra los bloques (vías y balasto), los ítems, las entidades (locomotoras y vagones), los sonidos, el menú de las
 * vías, las pestañas del modo creativo, la red de vías del mundo (con sus estaciones) y los trenes que pasan solos.
 */
@Mod(LocomotoraMod.MODID)
public class LocomotoraMod {
    public static final String MODID = "locomotora";

    public LocomotoraMod(IEventBus modEventBus, ModContainer modContainer) {
        ModBloques.BLOQUES.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBloques.ENTIDADES_BLOQUE.register(modEventBus);
        ModBloques.MENUS.register(modEventBus);
        ModEntidades.ENTIDADES.register(modEventBus);
        ModSonidos.SONIDOS.register(modEventBus);
        // La red de vías infinitas con estaciones (se agrega a los biomas con un biome modifier) y sus reglas
        ModMundo.FEATURES.register(modEventBus);
        modEventBus.addListener(LocomotoraMod::preparar);
        // Los trenes que pasan solos cada tantos minutos
        NeoForge.EVENT_BUS.addListener(Despachante::alTick);
        NeoForge.EVENT_BUS.addListener(Despachante::alEntrar);
        // Tres pestañas propias en el modo creativo: "Locomotoras", "Vagones" y "Vías"
        ModPestanas.PESTANAS.register(modEventBus);
    }

    /** Las reglas del juego del mod se registran en el hilo principal. */
    private static void preparar(FMLCommonSetupEvent evento) {
        evento.enqueueWork(ModReglas::registrar);
    }

    public static ResourceLocation id(String ruta) {
        return ResourceLocation.fromNamespaceAndPath(MODID, ruta);
    }
}
