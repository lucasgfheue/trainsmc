package com.locomotora.vehiculo;

import org.jetbrains.annotations.Nullable;

import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * La torreta de un vehículo (el tanque y el camión blindado): gira hacia donde mira el tirador y sube o baja el caño, y
 * lleva la cuenta de la recarga y de las ráfagas. Cada lado tiene la suya: el servidor para tirar, el cliente para
 * dibujarla (giran igual, así que coinciden).
 * <p>
 * El giro es hacia la derecha del frente del vehículo (radianes, 0 = mirando adelante); el alza, cuánto sube el caño.
 */
final class TorretaVehiculo {
    /** Rozamiento del aire y gravedad por tick de los obuses (los de cualquier proyectil que se tira). */
    private static final double ROCE = 0.99;
    private static final double GRAVEDAD = 0.03;
    private static final float PI = (float) Math.PI;

    private final TipoVehiculo tipo;
    private float giro;
    private float giroAnterior;
    private float alza;
    private float alzaAnterior;
    private int espera;
    private int quedan;
    private int entre;

    TorretaVehiculo(TipoVehiculo tipo) {
        this.tipo = tipo;
    }

    // ================================================================= dónde está y hacia dónde mira

    /** El eje de la torreta a la altura del caño, en el mundo. */
    Vec3 eje(VehiculoEntity v) {
        return v.punto(this.tipo.torretaAdelante(), this.tipo.torretaCostado(), this.tipo.torretaAlto());
    }

    /** Hacia dónde apunta el caño (largo 1). */
    Vec3 direccion(VehiculoEntity v) {
        double fx = v.frenteX();
        double fz = v.frenteZ();
        double c = Math.cos(this.giro);
        double s = Math.sin(this.giro);
        // el frente girado hacia la derecha, que es (-frenteZ, frenteX)
        double hx = fx * c - fz * s;
        double hz = fz * c + fx * s;
        double ca = Math.cos(this.alza);
        return new Vec3(hx * ca, Math.sin(this.alza), hz * ca);
    }

    /** La boca del caño, en el mundo: de ahí salen los tiros. */
    Vec3 boca(VehiculoEntity v) {
        Vec3 d = direccion(v);
        double h = Math.sqrt(d.x * d.x + d.z * d.z);
        Vec3 plano = h < 1.0E-6 ? new Vec3(v.frenteX(), 0.0, v.frenteZ()) : new Vec3(d.x / h, 0.0, d.z / h);
        return eje(v).add(plano.scale(this.tipo.munonAdelante())).add(d.scale(this.tipo.largoCano()));
    }

    float giro(float tickParcial) {
        return this.giroAnterior + envolver(this.giro - this.giroAnterior) * tickParcial;
    }

    float alza(float tickParcial) {
        return Mth.lerp(tickParcial, this.alzaAnterior, this.alza);
    }

    // ================================================================= apuntar y tirar

    /** Un tick: gira y sube el caño hacia el blanco (o vuelve de a poco al frente si nadie la maneja). */
    void apuntar(VehiculoEntity v, @Nullable Vec3 blanco) {
        this.giroAnterior = this.giro;
        this.alzaAnterior = this.alza;
        float giroBuscado = 0.0F;
        float alzaBuscada = 0.0F;
        if (blanco != null) {
            Vec3 e = eje(v);
            double dx = blanco.x - e.x;
            double dy = blanco.y - e.y;
            double dz = blanco.z - e.z;
            double adelante = dx * v.frenteX() + dz * v.frenteZ();
            double derecha = -dx * v.frenteZ() + dz * v.frenteX();
            giroBuscado = (float) Math.atan2(derecha, adelante);
            double justa = alzaPara(Math.sqrt(dx * dx + dz * dz), dy, this.tipo.tiro().velocidad());
            alzaBuscada = Double.isNaN(justa) ? this.tipo.alzaMaxima() : (float) justa;
        } else {
            // sin tirador se queda donde estaba
            giroBuscado = this.giro;
            alzaBuscada = this.alza;
        }
        alzaBuscada = Mth.clamp(alzaBuscada, this.tipo.alzaMinima(), this.tipo.alzaMaxima());
        float paso = this.tipo.velocidadTorreta();
        this.giro = envolver(this.giro + Mth.clamp(envolver(giroBuscado - this.giro), -paso, paso));
        this.alza += Mth.clamp(alzaBuscada - this.alza, -paso, paso);
    }

    /** El tirador apretó el gatillo: si ya recargó, tira ahora (y empieza la ráfaga). Devuelve si tiró. */
    boolean gatillo() {
        if (this.espera > 0 || this.quedan > 0) {
            return false;
        }
        this.quedan = this.tipo.rafaga() - 1;
        this.entre = this.tipo.entreTiros();
        this.espera = this.tipo.recarga();
        return true;
    }

    /** Un tick del servidor: cuenta la recarga y dice si sale el próximo tiro de una ráfaga empezada. */
    boolean siguienteDeRafaga() {
        if (this.espera > 0) {
            this.espera--;
        }
        if (this.quedan > 0 && --this.entre <= 0) {
            this.quedan--;
            this.entre = this.tipo.entreTiros();
            return true;
        }
        return false;
    }

    /**
     * La elevación (radianes) para que un tiro que sale a {@code v0} bloques por tick caiga a {@code h} bloques en planta
     * y {@code dy} de altura, o NaN si no llega (la misma cuenta que las torretas del tren artillero).
     */
    private static double alzaPara(double h, double dy, double v0) {
        if (h < 0.5) {
            return dy >= 0.0 ? Math.PI / 2.0 : -Math.PI / 2.0;
        }
        double theta = Math.atan2(dy, h);
        for (int i = 0; i < 5; i++) {
            double vh = v0 * Math.cos(theta);
            double q = (1.0 - ROCE) * h / vh;
            if (vh <= 1.0E-6 || q >= 1.0) {
                return Double.NaN;
            }
            double n = Math.log(1.0 - q) / Math.log(ROCE);
            double caida = GRAVEDAD / (1.0 - ROCE) * (n - h / vh);
            theta = Math.atan2(dy + caida, h);
        }
        return theta;
    }

    /** Un ángulo llevado a (-π, π]. */
    private static float envolver(float a) {
        a = a % (2.0F * PI);
        if (a > PI) {
            a -= 2.0F * PI;
        } else if (a <= -PI) {
            a += 2.0F * PI;
        }
        return a;
    }
}
