package com.locomotora.vehiculo;

import org.jetbrains.annotations.Nullable;

import com.locomotora.artillero.Torreta;

/**
 * Los vehículos de calle: autos, motos, camiones, camionetas y militares. Las medidas, los asientos y las torretas
 * salen del estudio de diseño ({@link DatosVehiculos}); acá van cómo andan y cómo suenan.
 * <p>
 * Velocidades en bloques por tick (1 bloque por tick = 72 km/h) y aceleraciones en bloques por tick por tick.
 */
public enum TipoVehiculo {
    // ------------------------------------------------------------------ autos
    AUTO_CONVERTIBLE("auto_convertible", Clase.AUTO, 1.0F, 0.020F, Bocina.AUTO, 1.05F),
    AUTO_SEDAN("auto_sedan", Clase.AUTO, 0.95F, 0.018F, Bocina.AUTO, 0.95F),
    AUTO_ANTIGUO("auto_antiguo", Clase.AUTO, 0.7F, 0.014F, Bocina.AUTO, 0.75F),
    AUTO_COMPACTO("auto_compacto", Clase.AUTO, 0.9F, 0.019F, Bocina.AUTO, 1.25F),
    AUTO_RURAL("auto_rural", Clase.AUTO, 0.9F, 0.017F, Bocina.AUTO, 0.9F),
    // ------------------------------------------------------------------ motos
    MOTO_CLASICA("moto_clasica", Clase.MOTO, 1.0F, 0.022F, Bocina.AUTO, 1.45F),
    MOTO_SCOOTER("moto_scooter", Clase.MOTO, 0.65F, 0.018F, Bocina.AUTO, 1.7F),
    MOTO_SIDECAR("moto_sidecar", Clase.MOTO, 0.85F, 0.018F, Bocina.AUTO, 1.4F),
    MOTO_RUTA("moto_ruta", Clase.MOTO, 1.1F, 0.022F, Bocina.AUTO, 1.2F),
    MOTO_CALLE("moto_calle", Clase.MOTO, 0.8F, 0.020F, Bocina.AUTO, 1.6F),
    // ------------------------------------------------------------------ camiones, autobús y casa rodante
    CAMION_BARANDAS("camion_barandas", Clase.CAMION, 0.7F, 0.012F, Bocina.CAMION, 1.1F),
    CAMION_CISTERNA("camion_cisterna", Clase.CAMION, 0.75F, 0.011F, Bocina.CAMION, 0.95F),
    CAMION_BOMBEROS("camion_bomberos", Clase.CAMION, 0.85F, 0.013F, Bocina.SIRENA, 1.0F),
    AUTOBUS("autobus", Clase.CAMION, 0.75F, 0.011F, Bocina.CAMION, 1.05F),
    CASA_RODANTE("casa_rodante", Clase.CAMION, 0.7F, 0.012F, Bocina.AUTO, 0.7F),
    // ------------------------------------------------------------------ camionetas
    CAMIONETA_PICKUP("camioneta_pickup", Clase.CAMIONETA, 0.85F, 0.016F, Bocina.AUTO, 0.85F),
    CAMIONETA_DOBLE_CABINA("camioneta_doble_cabina", Clase.CAMIONETA, 0.95F, 0.017F, Bocina.AUTO, 0.9F),
    CAMIONETA_FURGON("camioneta_furgon", Clase.CAMIONETA, 0.85F, 0.015F, Bocina.AUTO, 0.85F),
    CAMIONETA_4X4("camioneta_4x4", Clase.CAMIONETA, 0.9F, 0.017F, Bocina.AUTO, 0.8F),
    // ------------------------------------------------------------------ militares
    MILITAR_JEEP("militar_jeep", Clase.MILITAR, 0.9F, 0.018F, Bocina.AUTO, 0.8F),
    MILITAR_CAMION("militar_camion", Clase.MILITAR, 0.7F, 0.012F, Bocina.CAMION, 0.9F),
    MILITAR_TANQUE("militar_tanque", Clase.MILITAR, 0.45F, 0.008F, Bocina.CAMION, 0.7F),
    MILITAR_BLINDADO("militar_blindado", Clase.MILITAR, 0.75F, 0.012F, Bocina.CAMION, 0.85F);

    /** Para qué grupo de la pestaña y de las recetas es, y cómo dobla y suena el motor. */
    public enum Clase { AUTO, MOTO, CAMION, CAMIONETA, MILITAR }

    /** Lo que suena con el clic izquierdo del que maneja (si no maneja una torreta). */
    public enum Bocina { AUTO, CAMION, SIRENA }

    /** Lo que tira la torreta: el cañón del tanque o la ametralladora del camión blindado. */
    public enum Arma { NINGUNA, CANON, AMETRALLADORA }

    /** El cañón del tanque: lento para girar, pega fuerte y lejos. */
    public static final Torreta.Tiro TIRO_CANON = new Torreta.Tiro(3.0F, 14.0F, 3.0F, 12.0F, 0.5F);
    /** La ametralladora del camión blindado: ráfagas de tiros chicos. */
    public static final Torreta.Tiro TIRO_AMETRALLADORA = new Torreta.Tiro(3.4F, 4.0F, 1.0F, 2.0F, 2.0F);

    private final String id;
    private final Clase clase;
    private final float velocidadMaxima;
    private final float aceleracion;
    private final Bocina bocina;
    private final float tono;
    // del estudio de diseño (se leen la primera vez que hacen falta)
    private float[] medidas;
    private float[][] asientos;
    private float[] torreta;
    private boolean torretaLeida;
    private float[] lazo;
    private boolean lazoLeido;

    TipoVehiculo(String id, Clase clase, float velocidadMaxima, float aceleracion, Bocina bocina, float tono) {
        this.id = id;
        this.clase = clase;
        this.velocidadMaxima = velocidadMaxima;
        this.aceleracion = aceleracion;
        this.bocina = bocina;
        this.tono = tono;
    }

    // ================================================================= identidad
    /** El nombre del ítem y de la entidad (por ejemplo "auto_convertible"). */
    public String nombreRegistro() {
        return this.id;
    }

    public Clase clase() {
        return this.clase;
    }

    public Bocina bocina() {
        return this.bocina;
    }

    /** Tono del motor y de la bocina (1 = normal; más chico, más grave). */
    public float tono() {
        return this.tono;
    }

    // ================================================================= cómo anda
    public float velocidadMaxima() {
        return this.velocidadMaxima;
    }

    public float velocidadAtras() {
        return Math.max(0.15F, this.velocidadMaxima * 0.28F);
    }

    public float aceleracion() {
        return this.aceleracion;
    }

    /** Lo que frena por tick con el freno apretado. */
    public float freno() {
        return this.oruga() ? 0.05F : 0.04F;
    }

    /** ¿Va con orugas? (dobla en el lugar, sin ruedas que doblen) */
    public boolean oruga() {
        return this == MILITAR_TANQUE;
    }

    /** Cuánto doblan las ruedas de adelante como mucho (radianes). */
    public float giroMaximo() {
        return this.clase == Clase.MOTO ? 0.52F : 0.61F;
    }

    /** Distancia entre los ejes (bloques), para cuánto dobla según lo que giran las ruedas. */
    public double distanciaEjes() {
        float[] m = medidas();
        return Math.max(0.8, m[5] - m[4]);
    }

    /** Cuánto hacia adelante del centro está el eje de adelante (bloques). */
    public double adelanteEjeDelantero() {
        return -medidas()[4];
    }

    /** Cuánto hacia adelante del centro está el eje de atrás (bloques; negativo, queda atrás). */
    public double adelanteEjeTrasero() {
        return -medidas()[5];
    }

    /** Cuánto aguanta: los golpes se dividen por esto (el tanque y el blindado casi no se rompen a mano). */
    public float dureza() {
        return switch (this) {
            case MILITAR_TANQUE -> 5.0F;
            case MILITAR_BLINDADO -> 3.5F;
            default -> this.clase == Clase.MOTO ? 1.0F : (this.clase == Clase.AUTO ? 1.5F : 2.0F);
        };
    }

    /** Los militares son de metal grueso: el fuego y la lava no les hacen nada. */
    public boolean aPruebaDeFuego() {
        return this.clase == Clase.MILITAR;
    }

    // ================================================================= medidas y asientos (del estudio)
    private float[] medidas() {
        if (this.medidas == null) {
            this.medidas = DatosVehiculos.medidas(this.id);
        }
        return this.medidas;
    }

    /** Cuánto sobresale el casco hacia adelante del centro (bloques). */
    public double largoFrente() {
        return medidas()[0];
    }

    /** Cuánto sobresale hacia atrás del centro (bloques). */
    public double largoAtras() {
        return medidas()[1];
    }

    /** Ancho del modelo (bloques). */
    public float anchoModelo() {
        return medidas()[2];
    }

    /** Alto del modelo (bloques, sin antenas). */
    public float altoModelo() {
        return medidas()[3];
    }

    /** Radio de la rueda más grande (bloques). */
    public float radioRueda() {
        return medidas()[6];
    }

    /** Hasta dónde llega el modelo desde el centro, en planta (bloques). */
    public double alcance() {
        return medidas()[7];
    }

    /** Ancho de la caja de choque: el del vehículo, pero sin pasarse (para que entre por calles de 3 bloques). */
    public float anchoCaja() {
        return Math.max(0.9F, Math.min(2.4F, anchoModelo() * 0.92F));
    }

    public float altoCaja() {
        return Math.max(1.2F, Math.min(3.6F, altoModelo()));
    }

    private float[][] asientos() {
        if (this.asientos == null) {
            this.asientos = DatosVehiculos.asientos(this.id);
        }
        return this.asientos;
    }

    public int cantidadAsientos() {
        return asientos().length;
    }

    /** Cuánto hacia adelante del centro queda el asiento (bloques; el frente del modelo está hacia -x). */
    public double asientoAdelante(int i) {
        return -asientos()[i][0] / 16.0;
    }

    /** Cuánto hacia la derecha queda el asiento (bloques). */
    public double asientoCostado(int i) {
        return asientos()[i][1] / 16.0;
    }

    /** Altura de la cadera del que va sentado, sobre el suelo (bloques). */
    public double asientoAlto(int i) {
        return asientos()[i][2] / 16.0;
    }

    /**
     * El lazo por donde corren los eslabones de las orugas, o null si no tiene: {x0, y0, x1, y1, ...} en 1/16 de bloque
     * (x del modelo, y = altura), en el sentido en que avanzan cuando va hacia adelante.
     */
    @Nullable
    public float[] lazoOruga() {
        if (!this.lazoLeido) {
            this.lazo = DatosVehiculos.oruga(this.id);
            this.lazoLeido = true;
        }
        return this.lazo;
    }

    // ================================================================= torreta (tanque y camión blindado)
    @Nullable
    private float[] torreta() {
        if (!this.torretaLeida) {
            this.torreta = DatosVehiculos.torreta(this.id);
            this.torretaLeida = true;
        }
        return this.torreta;
    }

    public Arma arma() {
        return switch (this) {
            case MILITAR_TANQUE -> Arma.CANON;
            case MILITAR_BLINDADO -> Arma.AMETRALLADORA;
            default -> Arma.NINGUNA;
        };
    }

    public boolean tieneTorreta() {
        return arma() != Arma.NINGUNA && torreta() != null;
    }

    /** El asiento del tirador (el que apunta la torreta mirando). */
    public int asientoTirador() {
        return (int) torreta()[6];
    }

    /** El eje de giro de la torreta: cuánto hacia adelante del centro (bloques). */
    public double torretaAdelante() {
        return -torreta()[0] / 16.0;
    }

    /** El eje de giro de la torreta: cuánto hacia la derecha (bloques). */
    public double torretaCostado() {
        return torreta()[1] / 16.0;
    }

    /** Alto del caño sobre el suelo (bloques). */
    public double torretaAlto() {
        return torreta()[2] / 16.0;
    }

    /** ¿El caño sube y baja en un muñón? (el del tanque) */
    public boolean tieneMunon() {
        return !Float.isNaN(torreta()[4]);
    }

    /** Del eje de giro al muñón, hacia adelante de la torreta (bloques; 0 si no tiene). */
    public double munonAdelante() {
        return tieneMunon() ? (torreta()[0] - torreta()[4]) / 16.0 : 0.0;
    }

    /** Del muñón (o del eje) a la boca del caño (bloques). */
    public double largoCano() {
        float desde = tieneMunon() ? torreta()[4] : torreta()[0];
        return (desde - torreta()[3]) / 16.0;
    }

    public Torreta.Tiro tiro() {
        return arma() == Arma.CANON ? TIRO_CANON : TIRO_AMETRALLADORA;
    }

    /** Radianes por tick que gira la torreta. */
    public float velocidadTorreta() {
        return arma() == Arma.CANON ? 0.07F : 0.22F;
    }

    public float alzaMinima() {
        return arma() == Arma.CANON ? -0.1F : -0.3F;
    }

    public float alzaMaxima() {
        return arma() == Arma.CANON ? 0.35F : 0.75F;
    }

    /** Ticks entre un tiro (o una ráfaga) y el siguiente. */
    public int recarga() {
        return arma() == Arma.CANON ? 60 : 24;
    }

    public int rafaga() {
        return arma() == Arma.CANON ? 1 : 5;
    }

    public int entreTiros() {
        return 2;
    }
}
