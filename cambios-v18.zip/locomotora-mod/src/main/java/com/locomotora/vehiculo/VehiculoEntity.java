package com.locomotora.vehiculo;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.jetbrains.annotations.Nullable;

import com.locomotora.LocomotoraMod;
import com.locomotora.artillero.ObusEntity;
import com.locomotora.gente.PersonaEntity;
import com.locomotora.registro.ModItems;
import com.locomotora.registro.ModSonidos;
import com.locomotora.transito.Transito;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.vehicle.DismountHelper;
import net.minecraft.world.entity.vehicle.VehicleEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * Un vehículo de calle: auto, moto, camión, camioneta o militar ({@link TipoVehiculo}).
 * <ul>
 *   <li>Clic derecho: subirse. El primero va al volante y maneja; los demás se sientan en el asiento libre más cercano
 *       a donde hicieron clic.</li>
 *   <li>El que maneja: W acelera, S frena y después va marcha atrás, A y D doblan. Clic izquierdo: la bocina (en la
 *       autobomba, la sirena).</li>
 *   <li>Tanque y camión blindado: el que va en la torreta (o el que maneja, si la torreta está libre) la apunta mirando
 *       y tira con clic izquierdo.</li>
 *   <li>Sube escalones de un bloque a cualquier velocidad (y una escalera de a un bloque, uno por uno); mientras sube o
 *       baja se inclina sobre las ruedas. A los golpes se rompe y deja su ítem (en creativo, de un golpe).</li>
 * </ul>
 * Como los botes, lo mueve la computadora del que maneja (así responde al instante) y el servidor lo controla; sin nadie
 * al volante, el servidor lo deja caer y frenar solo. Pasado cierto apuro atropella a los que se le crucen.
 * <p>
 * Los del tránsito los maneja alguien de la carretera ({@link PersonaEntity}): su {@link Conductor} aprieta los
 * pedales y el volante en el servidor. Mientras va gente de la carretera adentro no se puede subir nadie; cuando se
 * bajan todos (o mueren), el vehículo queda libre y, si te subís a manejarlo, es tuyo.
 */
public class VehiculoEntity extends VehicleEntity {
    /** Quién va en cada asiento (id de la entidad; 0 = libre). El asiento 0 es el del que maneja. */
    private static final EntityDataAccessor<CompoundTag> DATA_ASIENTOS =
            SynchedEntityData.defineId(VehiculoEntity.class, EntityDataSerializers.COMPOUND_TAG);
    /** El que va sentado: sus pies quedan este tanto debajo de la cadera. */
    private static final double PIERNAS = 0.6;
    /** Hasta dónde se busca adónde mira el tirador (bloques). */
    private static final double MIRA = 160.0;
    /** Desde esta rapidez (bloques por tick, unos 11 km/h) atropella. */
    private static final float ATROPELLA = 0.16F;
    /** El tipo de daño (data/locomotora/damage_type/atropello_vehiculo.json): "fue atropellado por...". */
    private static final ResourceKey<DamageType> ATROPELLO =
            ResourceKey.create(Registries.DAMAGE_TYPE, LocomotoraMod.id("atropello_vehiculo"));
    /** Cuánto se acerca por tick a cómo tiene que quedar apoyado (así sube el escalón rodando y no de golpe). */
    private static final float SUAVE = 0.6F;
    /** Lo más que se inclina (pendiente 1: 45°, una escalera de a un bloque). */
    private static final double PENDIENTE_MAXIMA = 1.0;
    /** Largo de cada pedazo en que se parte el movimiento de un tick (bloques): en cada uno puede subir un escalón. */
    private static final double PEDAZO = 0.45;

    private final TipoVehiculo tipo;
    @Nullable
    private final ParteVehiculo[] partes;
    @Nullable
    private final TorretaVehiculo torreta;

    // ------------------------------------------------- el que lo mueve (la computadora del que maneja, o el servidor)
    /** Rapidez hacia adelante (bloques por tick; negativa = marcha atrás). */
    private float velocidad;
    /** Cuánto doblan las ruedas de adelante (radianes; positivo = a la derecha). */
    private float direccion;

    // ------------------------------------------------- servidor
    /** El asiento más cercano al clic del próximo que sube, -1 si ninguno. */
    private int asientoPedido = -1;
    private int esperaBocina;
    private int esperaMotor;
    private int esperaEstado;
    private float rapidezSuave;
    /** El que maneja cuando al volante va alguien de la carretera. */
    @Nullable
    private Conductor conductor;
    /** Lo puso el tránsito: se quita cuando queda lejos de todos (y si lo rompen no deja su ítem). */
    private boolean transito;
    /** Ticks con gente de la carretera adentro pero nadie al volante. */
    private int sinChofer;
    /**
     * Dónde estaba en el tick anterior del servidor. Cuando maneja un jugador, la posición llega de su computadora entre
     * un tick y otro (antes de que el servidor guarde la posición "vieja"), así que lo que anduvo se mide contra esto.
     */
    private double antX = Double.NaN;
    private double antZ;

    // ------------------------------------------------- cliente (animación) y los que lo ven moverse de lejos
    private double recorrido;
    private double recorridoAnterior;
    private float direccionVista;
    private float direccionVistaAnterior;
    /** Lo que giró en total (radianes, a la derecha): con esto la oruga de un lado anda distinto que la del otro. */
    private double giroTotal;
    private double giroTotalAnterior;
    private int lerpPasos;
    private double lerpX;
    private double lerpY;
    private double lerpZ;
    private float lerpYRot;
    private float lerpXRot;

    // ------------------------------------------------- cómo queda apoyado (para dibujarlo y sentar a los de arriba)
    /** Cuánto sube la trompa (radianes; negativo = baja). */
    private float cabeceo;
    private float cabeceoAnterior;
    /** Altura del piso del modelo (donde apoyan las ruedas) en el medio entre los ejes; NaN hasta que se calcula. */
    private double apoyo = Double.NaN;
    private double apoyoAnterior = Double.NaN;

    public VehiculoEntity(EntityType<? extends VehiculoEntity> tipoEntidad, Level level, TipoVehiculo tipo) {
        super(tipoEntidad, level);
        this.tipo = tipo;
        this.blocksBuilding = true;
        // los tramos se crean justo después del vehículo: sus números de entidad quedan seguidos al suyo
        double largo = tipo.largoFrente() + tipo.largoAtras();
        float ancho = tipo.anchoCaja();
        int n = (int) Math.ceil(largo / ancho - 0.15);
        if (n >= 2) {
            this.partes = new ParteVehiculo[n];
            for (int i = 0; i < n; i++) {
                this.partes[i] = new ParteVehiculo(this, ancho, tipo.altoCaja());
            }
        } else {
            this.partes = null;
        }
        this.torreta = tipo.tieneTorreta() ? new TorretaVehiculo(tipo) : null;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_ASIENTOS, new CompoundTag());
    }

    // ================================================================= identidad

    public TipoVehiculo getTipo() {
        return this.tipo;
    }

    /** El ítem que deja al romperse (el mismo con que se puso). */
    protected Item getDropItem() {
        return ModItems.porTipo(this.tipo).get();
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(getDropItem());
    }

    /** El modelo es más grande que la caja de choque: así no desaparece al mirarlo de cerca. */
    @Override
    public AABB getBoundingBoxForCulling() {
        double a = this.tipo.alcance() + 1.0;
        return this.getBoundingBox().inflate(a, 0.0, a).expandTowards(0.0, 2.0, 0.0);
    }

    /** Se le puede hacer clic, salvo desde adentro (si no, el que va sentado no podría apuntar a nada). */
    @Override
    public boolean isPickable() {
        return !this.isRemoved() && !(this.level().isClientSide() && com.locomotora.cliente.Local.vaEn(this));
    }

    /** Es sólido para los demás (como un bote): se le puede subir encima y no se mete en otros vehículos. */
    @Override
    public boolean canBeCollidedWith() {
        return true;
    }

    /** No lo empujan los que caminan. */
    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean fireImmune() {
        return this.tipo.aPruebaDeFuego() || super.fireImmune();
    }

    /** Sube escalones de un bloque (los cordones, las lomas del terreno; un poco más, por si tienen alfombra o nieve). */
    @Override
    public float maxUpStep() {
        return 1.1F;
    }

    /** Al andar no hace ruido de pasos (el motor suena aparte), como los botes; sí avisa a los sculk. */
    @Override
    protected Entity.MovementEmission getMovementEmission() {
        return Entity.MovementEmission.EVENTS;
    }

    // ================================================================= dónde queda cada cosa

    /** El frente, en el mundo: con el giro de Minecraft (0 = hacia el sur), (-sin, cos). */
    public double frenteX() {
        return -Math.sin(Math.toRadians(this.getYRot()));
    }

    public double frenteZ() {
        return Math.cos(Math.toRadians(this.getYRot()));
    }

    /** Un punto del vehículo: tanto hacia adelante, tanto hacia la derecha (-frenteZ, frenteX) y tanto de alto. */
    public Vec3 punto(double adelante, double costado, double alto) {
        double fx = frenteX();
        double fz = frenteZ();
        return new Vec3(this.getX() + fx * adelante - fz * costado, this.getY() + alto,
                this.getZ() + fz * adelante + fx * costado);
    }

    /**
     * Un punto del vehículo como queda apoyado sobre el piso (inclinado si está subiendo o bajando un escalón): tanto
     * hacia adelante, tanto hacia la derecha y tanto de alto sobre el piso del modelo.
     */
    public Vec3 puntoApoyado(double adelante, double costado, double alto) {
        if (Double.isNaN(this.apoyo)) {
            return punto(adelante, costado, alto);
        }
        double medio = adelanteMedioEjes();
        double c = Math.cos(this.cabeceo);
        double s = Math.sin(this.cabeceo);
        double d = adelante - medio;
        return punto(medio + d * c - alto * s, costado, d * s + alto * c + (this.apoyo - this.getY()));
    }

    /** Dónde gira cuando se inclina: en el medio entre los ejes (bloques hacia adelante del centro). */
    public double adelanteMedioEjes() {
        return (this.tipo.adelanteEjeDelantero() + this.tipo.adelanteEjeTrasero()) / 2.0;
    }

    private Vec3 puntoAsiento(int i) {
        return puntoApoyado(this.tipo.asientoAdelante(i), this.tipo.asientoCostado(i), this.tipo.asientoAlto(i));
    }

    // ================================================================= para dibujarlo

    /** Distancia recorrida (bloques, interpolada) para girar las ruedas. */
    public double getRecorrido(float tickParcial) {
        return Mth.lerp(tickParcial, this.recorridoAnterior, this.recorrido);
    }

    /** Cuánto doblan las ruedas de adelante (radianes, positivo a la derecha). */
    public float getDireccion(float tickParcial) {
        return Mth.lerp(tickParcial, this.direccionVistaAnterior, this.direccionVista);
    }

    /** Lo que giró en total (radianes, a la derecha; interpolado): para las orugas, que andan distinto de cada lado. */
    public double getGiroTotal(float tickParcial) {
        return Mth.lerp(tickParcial, this.giroTotalAnterior, this.giroTotal);
    }

    /** Cuánto sube la trompa (radianes, negativo si baja; interpolado). */
    public float getCabeceo(float tickParcial) {
        return Mth.lerp(tickParcial, this.cabeceoAnterior, this.cabeceo);
    }

    /**
     * Cuánto más arriba que la caja de choque queda el piso del modelo en el medio entre los ejes (bloques;
     * interpolado). Por ejemplo, con las ruedas de adelante arriba de un escalón y la caja todavía abajo, medio bloque.
     */
    public double getAlzaVista(float tickParcial) {
        if (Double.isNaN(this.apoyo) || Double.isNaN(this.apoyoAnterior)) {
            return 0.0;
        }
        return Mth.lerp(tickParcial, this.apoyoAnterior, this.apoyo) - Mth.lerp(tickParcial, this.yOld, this.getY());
    }

    public float giroTorreta(float tickParcial) {
        return this.torreta == null ? 0.0F : this.torreta.giro(tickParcial);
    }

    public float alzaTorreta(float tickParcial) {
        return this.torreta == null ? 0.0F : this.torreta.alza(tickParcial);
    }

    // ================================================================= tick

    @Override
    public void tick() {
        if (this.getHurtTime() > 0) {
            this.setHurtTime(this.getHurtTime() - 1);
        }
        if (this.getDamage() > 0.0F) {
            this.setDamage(this.getDamage() - 1.0F);
        }
        super.tick();
        this.cabeceoAnterior = this.cabeceo;
        this.apoyoAnterior = this.apoyo;
        tickLerp();
        if (!this.level().isClientSide()) {
            PersonaEntity npc = getChoferNPC();
            if (npc != null) {
                if (this.conductor == null) {
                    this.conductor = new Conductor(this);
                }
                this.conductor.pensar((ServerLevel) this.level(), npc);
            }
            if (this.transito && !Transito.conocido(this.getUUID())) {
                Transito.registrar(this);
            }
            // si el que manejaba se murió (o se bajó), otro de los de adentro pasa al volante
            if (npc == null && getChofer() == null && hayGenteDeLaCarretera()) {
                if (++this.sinChofer > 40) {
                    this.sinChofer = 0;
                    for (Entity e : List.copyOf(this.getPassengers())) {
                        if (e instanceof PersonaEntity p) {
                            p.stopRiding();
                            subirNPC(p);
                            break;
                        }
                    }
                }
            } else {
                this.sinChofer = 0;
            }
        }
        if (this.isControlledByLocalInstance()) {
            manejar();
        } else {
            this.setDeltaMovement(Vec3.ZERO);
        }
        apoyar();
        moverPartes();
        if (this.level().isClientSide()) {
            tickCliente();
        } else {
            tickServidor((ServerLevel) this.level());
        }
    }

    /**
     * El que lo mueve (la computadora del que maneja, o el servidor si nadie maneja): acelera o frena según W y S,
     * dobla con A y D (las ruedas de adelante giran y el vehículo sigue la curva que marcan; el tanque gira en el
     * lugar), cae si no tiene piso y se mueve chocando con los bloques.
     */
    private void manejar() {
        Player chofer = getChofer();
        boolean npc = chofer == null && this.conductor != null && getChoferNPC() != null;
        float acelerador = chofer != null ? chofer.zza : (npc ? this.conductor.acelerador : 0.0F);
        float volante = chofer != null ? chofer.xxa : (npc ? this.conductor.volante : 0.0F);
        boolean alVolante = chofer != null || npc;
        boolean enAgua = this.isInWater();
        float maxima = this.tipo.velocidadMaxima() * (enAgua ? 0.35F : 1.0F);
        if (this.onGround() || enAgua) {
            if (acelerador > 0.1F) {
                this.velocidad = this.velocidad < 0.0F
                        ? Math.min(0.0F, this.velocidad + this.tipo.freno())
                        : Math.min(maxima, this.velocidad + this.tipo.aceleracion());
            } else if (acelerador < -0.1F) {
                this.velocidad = this.velocidad > 0.0F
                        ? Math.max(0.0F, this.velocidad - this.tipo.freno())
                        : Math.max(-this.tipo.velocidadAtras(), this.velocidad - this.tipo.aceleracion() * 0.7F);
            } else {
                // sin acelerar se va frenando solo (y sin nadie al volante, más rápido: freno de mano)
                this.velocidad *= alVolante ? 0.985F : 0.9F;
                this.velocidad -= Math.signum(this.velocidad) * 0.003F;
                if (Math.abs(this.velocidad) < 0.004F) {
                    this.velocidad = 0.0F;
                }
            }
            if (this.velocidad > maxima) {
                this.velocidad = Math.max(maxima, this.velocidad - this.tipo.freno());
            }
        } else {
            this.velocidad *= 0.995F;
        }

        float rumbo = this.getYRot();
        if (this.tipo.oruga()) {
            // orugas: gira en el lugar (una hacia adelante y la otra hacia atrás)
            rumbo -= volante * (Math.abs(this.velocidad) > 0.05F ? 2.2F : 3.0F);
            this.direccion = 0.0F;
        } else {
            // las ruedas doblan menos cuanto más rápido va (si no, a toda velocidad dobla de golpe)
            float limite = this.tipo.giroMaximo() / (1.0F + 2.0F * Math.abs(this.velocidad));
            float buscada = -volante * limite;
            this.direccion += Mth.clamp(buscada - this.direccion, -0.08F, 0.08F);
            // la curva que marcan las ruedas: gira velocidad / distancia entre ejes · tan(dirección) por tick
            double giro = this.velocidad / this.tipo.distanciaEjes() * Math.tan(this.direccion);
            rumbo += (float) Math.toDegrees(giro);
        }
        this.setYRot(Mth.wrapDegrees(rumbo));

        Vec3 antes = this.getDeltaMovement();
        double vy = antes.y;
        if (enAgua) {
            vy = Math.max(vy - 0.02, -0.08);
        } else if (!this.isNoGravity()) {
            vy = (vy - 0.08) * 0.98;
        }
        // la trompa (o la cola, yendo para atrás) no se mete en las paredes: la caja de choque es solo el medio
        if (this.velocidad != 0.0F && chocaria(this.velocidad)) {
            this.velocidad = 0.0F;
        }
        Vec3 mov = new Vec3(frenteX() * this.velocidad, vy, frenteZ() * this.velocidad);
        this.setDeltaMovement(mov);
        // de a pedazos: en cada uno puede subir un escalón, así trepa los escalones (y las escaleras de a un bloque) a
        // cualquier velocidad; de un solo movimiento largo subiría uno solo y se trabaría en el siguiente
        double pedido = Math.abs(this.velocidad);
        int pedazos = Math.max(1, (int) Math.ceil(pedido / PEDAZO));
        double x0 = this.getX();
        double z0 = this.getZ();
        for (int i = 0; i < pedazos; i++) {
            this.move(MoverType.SELF, new Vec3(mov.x / pedazos, mov.y / pedazos, mov.z / pedazos));
        }
        // si chocó de verdad (no pudo avanzar ni la mitad), frena según lo que llegó a avanzar
        if (pedido > 0.02) {
            double hecho = Math.sqrt((this.getX() - x0) * (this.getX() - x0) + (this.getZ() - z0) * (this.getZ() - z0));
            if (hecho < pedido * 0.5) {
                this.velocidad *= (float) (hecho / pedido);
            }
        }
    }

    /**
     * ¿La punta que va adelante se metería en una pared si avanza esto? Se camina por el piso desde el frente de la caja
     * de choque (que ya está donde está) hasta la punta del modelo más lo que va a avanzar, por el medio y por los dos
     * costados de la trompa: si en algún lugar el piso sube más de un escalón de golpe, es una pared. Así una escalera de
     * a un bloque no lo para (sube de a uno), aunque la trompa ya esté arriba de los escalones siguientes.
     */
    private boolean chocaria(float avance) {
        double signo = Math.signum(avance);
        double punta = (avance > 0.0F ? this.tipo.largoFrente() : this.tipo.largoAtras()) - 0.3;
        double desde = this.tipo.anchoCaja() * 0.45;
        double hasta = punta + Math.abs(avance) + 0.2;
        double w = Math.max(0.15, this.tipo.anchoModelo() * 0.38);
        for (int lado = -1; lado <= 1; lado++) {
            double anterior = this.getY();
            for (double d = desde; d <= hasta + 1.0E-6; d += 0.3) {
                Vec3 c = punto(signo * d, lado * w, 0.0);
                double p = piso(c.x, c.z, anterior + this.maxUpStep() + 0.05);
                if (p == Double.POSITIVE_INFINITY) {
                    return true;
                }
                // sin piso cerca (un pozo o un barranco): se puede seguir, cae
                anterior = Double.isNaN(p) ? anterior - 1.0 : p;
            }
        }
        return false;
    }

    /**
     * Lo más alto que se puede pisar en la columna de (x, z), buscando desde la altura {@code desde} hacia abajo hasta
     * 3 bloques. NaN si no hay nada; infinito si a esa altura la columna está tapada (es una pared).
     */
    private double piso(double x, double z, double desde) {
        return piso(x, z, desde, desde - 4.0);
    }

    /** Lo mismo, buscando hacia abajo hasta la altura {@code hasta}. */
    private double piso(double x, double z, double desde, double hasta) {
        Level nivel = this.level();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int bx = Mth.floor(x);
        int bz = Mth.floor(z);
        int arriba = Mth.floor(desde);
        int abajo = Math.min(arriba, Mth.floor(hasta));
        for (int by = arriba; by >= abajo; by--) {
            pos.set(bx, by, bz);
            VoxelShape forma = nivel.getBlockState(pos).getCollisionShape(nivel, pos);
            if (forma.isEmpty()) {
                continue;
            }
            double tope = by + forma.max(Direction.Axis.Y);
            return tope <= desde + 1.0E-4 ? tope : Double.POSITIVE_INFINITY;
        }
        return Double.NaN;
    }

    /** El piso debajo de una sección del vehículo (tanto hacia adelante del centro): lo más alto entre el medio y los costados. */
    private double pisoEn(double adelante, double desde) {
        return pisoEn(adelante, desde, desde - 4.0);
    }

    private double pisoEn(double adelante, double desde, double hasta) {
        double w = Math.max(0.15, this.tipo.anchoModelo() * 0.35);
        double mejor = Double.NaN;
        for (int k = -1; k <= 1; k++) {
            Vec3 p = punto(adelante, k * w, 0.0);
            double y = piso(p.x, p.z, desde, hasta);
            if (Double.isFinite(y) && (Double.isNaN(mejor) || y > mejor)) {
                mejor = y;
            }
        }
        return mejor;
    }

    /**
     * A qué altura está ahora el piso del modelo en una sección (tanto hacia adelante del centro): de ahí se busca el piso
     * de la rueda, así en una escalera cada rueda encuentra el escalón que tiene delante aunque esté lejos de la caja.
     */
    private double alturaRueda(double adelante) {
        if (Double.isNaN(this.apoyo)) {
            return this.getY();
        }
        double h = this.apoyo + (adelante - adelanteMedioEjes()) * Math.sin(this.cabeceo);
        // sin irse demasiado de la caja de choque (por si quedó algo viejo)
        return Mth.clamp(h, this.getY() - 3.0, this.getY() + 3.0);
    }

    /** El piso debajo de una rueda (tanto hacia adelante del centro): lo más alto bajo su frente, su medio y su cola. */
    private double pisoRueda(double adelante, double desde, double hasta) {
        double r = Math.max(0.1, this.tipo.radioRueda() * 0.9);
        double mejor = Double.NaN;
        for (int k = -1; k <= 1; k++) {
            double y = pisoEn(adelante + k * r, desde, hasta);
            if (!Double.isNaN(y) && (Double.isNaN(mejor) || y > mejor)) {
                mejor = y;
            }
        }
        return mejor;
    }

    /**
     * Cómo queda apoyado: sobre las ruedas de adelante y de atrás. Con las de adelante arriba de un escalón la trompa
     * sube y con las de atrás, baja; con una rueda en el aire (o trepado arriba de algo angosto que pasa entre las ruedas)
     * queda derecho sobre la caja de choque. Cada rueda "siente" el escalón desde que lo toca con el frente, y además se
     * suaviza: así sube el escalón rodando y no de golpe.
     */
    private void apoyar() {
        double y = this.getY();
        double aD = this.tipo.adelanteEjeDelantero();
        double aT = this.tipo.adelanteEjeTrasero();
        // cada rueda busca su piso desde donde está ahora (o desde la caja, si el suavizado la dejó atrás), hasta unos
        // bloques más abajo: así sigue una escalera, para arriba o para abajo
        double rD = alturaRueda(aD);
        double rT = alturaRueda(aT);
        double hD = pisoRueda(aD, Math.max(rD, y) + 1.6, Math.min(rD, y) - 2.5);
        double hT = pisoRueda(aT, Math.max(rT, y) + 1.6, Math.min(rT, y) - 2.5);
        boolean conD = !Double.isNaN(hD) && Math.abs(hD - y) <= 3.0;
        boolean conT = !Double.isNaN(hT) && Math.abs(hT - y) <= 3.0;
        double pendiente = 0.0;
        double alto0 = y;
        boolean apoyado = this.onGround();
        if (conD || conT) {
            // una rueda sin piso a la vista (por ejemplo, la de adelante sobre un barranco): a la altura de la caja
            if (!conD) {
                hD = y;
            }
            if (!conT) {
                hT = y;
            }
            pendiente = (hD - hT) / (aD - aT);
            alto0 = hT - pendiente * aT;
            apoyado = true;
            if (this.onGround() && alto0 < y - 0.75) {
                // ¿trepado arriba de algo angosto que pasa entre las ruedas? (la caja apoyada justo en el medio; en una
                // escalera, en cambio, la caja se apoya con el frente y debajo del medio hay un escalón más bajo)
                double medio = pisoEn(0.0, y + 0.2);
                if (Double.isFinite(medio) && medio >= y - 0.06) {
                    pendiente = 0.0;
                    alto0 = y;
                }
            }
        }
        pendiente = Mth.clamp(pendiente, -PENDIENTE_MAXIMA, PENDIENTE_MAXIMA);
        float cab = (float) Math.atan(pendiente);
        double alto = alto0 + pendiente * adelanteMedioEjes();
        if (Double.isNaN(this.apoyo) || Math.abs(this.apoyo - alto) > 2.5) {
            // recién aparecido (o se teletransportó): de una
            this.apoyo = alto;
            this.apoyoAnterior = alto;
            this.cabeceo = cab;
            this.cabeceoAnterior = cab;
            return;
        }
        // en el aire sigue a la caja enseguida, para no quedarse atrás al caer
        float k = apoyado ? SUAVE : 0.85F;
        this.cabeceo += (cab - this.cabeceo) * k;
        this.apoyo += (alto - this.apoyo) * k;
    }

    /** Los tramos acompañan al vehículo (también en el cliente, para poder hacerles clic). */
    private void moverPartes() {
        if (this.partes == null) {
            return;
        }
        double largo = this.tipo.largoFrente() + this.tipo.largoAtras();
        double paso = largo / this.partes.length;
        for (int i = 0; i < this.partes.length; i++) {
            ParteVehiculo p = this.partes[i];
            Vec3 c = puntoApoyado(this.tipo.largoFrente() - (i + 0.5) * paso, 0.0, 0.0);
            p.xo = p.getX();
            p.yo = p.getY();
            p.zo = p.getZ();
            p.xOld = p.xo;
            p.yOld = p.yo;
            p.zOld = p.zo;
            p.setPos(c.x, c.y, c.z);
        }
    }

    private void tickCliente() {
        // las ruedas giran según lo que avanzó
        this.recorridoAnterior = this.recorrido;
        double dx = this.getX() - this.xo;
        double dz = this.getZ() - this.zo;
        double avance = dx * frenteX() + dz * frenteZ();
        if (Math.abs(avance) < 2.0) {
            this.recorrido += avance;
        }
        // y lo que giró (en el tanque, al doblar, una oruga va para adelante y la otra para atrás)
        this.giroTotalAnterior = this.giroTotal;
        this.giroTotal += Math.toRadians(Mth.wrapDegrees(this.getYRot() - this.yRotO));
        // las de adelante doblan: el que maneja ve lo que hace; los demás, lo que dobla al moverse
        this.direccionVistaAnterior = this.direccionVista;
        float buscada;
        if (this.isControlledByLocalInstance()) {
            buscada = this.direccion;
        } else if (Math.abs(avance) > 0.01) {
            float giro = (float) Math.toRadians(Mth.wrapDegrees(this.getYRot() - this.yRotO));
            buscada = (float) Math.atan(this.tipo.distanciaEjes() * giro / avance);
        } else {
            buscada = this.direccionVista;
        }
        buscada = Mth.clamp(buscada, -this.tipo.giroMaximo(), this.tipo.giroMaximo());
        this.direccionVista += (buscada - this.direccionVista) * 0.4F;
        if (this.torreta != null) {
            Player tirador = tirador();
            this.torreta.apuntar(this, tirador == null ? null : miraDe(tirador));
        }
    }

    private void tickServidor(ServerLevel nivel) {
        // lo que anduvo desde el tick anterior (también cuando lo mueve la computadora del que maneja)
        double dx = Double.isNaN(this.antX) ? 0.0 : this.getX() - this.antX;
        double dz = Double.isNaN(this.antX) ? 0.0 : this.getZ() - this.antZ;
        this.antX = this.getX();
        this.antZ = this.getZ();
        float rapidez = (float) Math.sqrt(dx * dx + dz * dz);
        this.rapidezSuave += (Math.min(rapidez, 2.0F) - this.rapidezSuave) * 0.3F;
        if (this.esperaBocina > 0) {
            this.esperaBocina--;
        }
        Player chofer = getChofer();
        if (chofer != null || getChoferNPC() != null) {
            // el motor: más agudo y más seguido cuanto más rápido va
            if (--this.esperaMotor <= 0) {
                float apuro = Math.min(1.0F, this.rapidezSuave / Math.max(0.1F, this.tipo.velocidadMaxima()));
                float tono = this.tipo.tono() * (this.tipo.clase() == TipoVehiculo.Clase.MOTO ? 1.5F : 1.0F)
                        * (0.8F + 0.55F * apuro);
                nivel.playSound(null, this.getX(), this.getY() + 0.8, this.getZ(), ModSonidos.MOTOR.get(),
                        SoundSource.NEUTRAL, 0.55F + 0.35F * apuro, tono);
                this.esperaMotor = apuro > 0.05F ? 9 : 16;
            }
            if (chofer != null && ++this.esperaEstado >= 10) {
                this.esperaEstado = 0;
                if (this.rapidezSuave > 0.01F) {
                    chofer.displayClientMessage(Component.translatable("estado.locomotora.vehiculo",
                            Math.round(this.rapidezSuave * 72.0F)).withStyle(ChatFormatting.GRAY), true);
                }
            }
        } else {
            this.esperaMotor = 0;
        }
        if (rapidez > ATROPELLA && rapidez < 2.5F) {
            atropellar(nivel, rapidez, dx, dz);
        }
        if (this.torreta != null) {
            Player tirador = tirador();
            this.torreta.apuntar(this, tirador == null ? null : miraDe(tirador));
            if (this.torreta.siguienteDeRafaga() && tirador != null) {
                disparar(nivel, tirador);
            }
        }
    }

    // ================================================================= los que lo ven de lejos: movimiento suave

    @Override
    public void lerpTo(double x, double y, double z, float rumbo, float cabeceo, int pasos) {
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYRot = rumbo;
        this.lerpXRot = cabeceo;
        this.lerpPasos = Math.max(1, pasos);
    }

    private void tickLerp() {
        if (this.isControlledByLocalInstance()) {
            this.lerpPasos = 0;
            this.syncPacketPositionCodec(this.getX(), this.getY(), this.getZ());
        }
        if (this.lerpPasos > 0) {
            double f = 1.0 / this.lerpPasos;
            double x = this.getX() + (this.lerpX - this.getX()) * f;
            double y = this.getY() + (this.lerpY - this.getY()) * f;
            double z = this.getZ() + (this.lerpZ - this.getZ()) * f;
            float rumbo = Mth.rotLerp((float) f, this.getYRot(), this.lerpYRot);
            float cabeceo = this.getXRot() + (this.lerpXRot - this.getXRot()) * (float) f;
            this.lerpPasos--;
            this.setPos(x, y, z);
            this.setRot(rumbo, cabeceo);
        }
    }

    // ================================================================= asientos

    /** Quién va en cada asiento (números de entidad; 0 = libre). Es una copia: se cambia y se guarda con guardarAsientos. */
    private int[] asientos() {
        int[] a = this.entityData.get(DATA_ASIENTOS).getIntArray("a");
        return Arrays.copyOf(a, this.tipo.cantidadAsientos());
    }

    private void guardarAsientos(int[] a) {
        CompoundTag tag = new CompoundTag();
        tag.putIntArray("a", a);
        this.entityData.set(DATA_ASIENTOS, tag);
    }

    private boolean vaArriba(int id) {
        if (id == 0) {
            return false;
        }
        for (Entity p : this.getPassengers()) {
            if (p.getId() == id) {
                return true;
            }
        }
        return false;
    }

    /** El asiento de un pasajero (si todavía no llegó el dato, el que le toca por orden de subida). */
    private int asientoDe(Entity pasajero) {
        int[] a = asientos();
        for (int i = 0; i < a.length; i++) {
            if (a[i] == pasajero.getId()) {
                return i;
            }
        }
        int k = this.getPassengers().indexOf(pasajero);
        return Math.max(0, Math.min(a.length - 1, k));
    }

    /** Quién va en un asiento, o null. */
    @Nullable
    public Entity enAsiento(int i) {
        int[] a = asientos();
        if (i < 0 || i >= a.length || a[i] == 0) {
            return null;
        }
        for (Entity p : this.getPassengers()) {
            if (p.getId() == a[i]) {
                return p;
            }
        }
        return null;
    }

    private int asientoLibreMasCercano(Vec3 desde) {
        int[] a = asientos();
        int mejor = -1;
        double distancia = Double.MAX_VALUE;
        for (int i = 0; i < a.length; i++) {
            if (vaArriba(a[i])) {
                continue;
            }
            double d = puntoAsiento(i).distanceToSqr(desde);
            if (d < distancia) {
                distancia = d;
                mejor = i;
            }
        }
        return mejor;
    }

    /** El que maneja: el jugador que va al volante (el primer asiento), o null. */
    @Nullable
    public Player getChofer() {
        return enAsiento(0) instanceof Player p ? p : null;
    }

    /** El que va al volante si es alguien de la carretera, o null. */
    @Nullable
    public PersonaEntity getChoferNPC() {
        return enAsiento(0) instanceof PersonaEntity p ? p : null;
    }

    /**
     * El que maneja es el que lo mueve: un jugador (como en los botes: lo mueve su computadora) o alguien de la
     * carretera (lo mueve el servidor).
     */
    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        Entity e = enAsiento(0);
        return e instanceof Player || e instanceof PersonaEntity ? (LivingEntity) e : null;
    }

    /** El que apunta la torreta: el que va en ella o, si está libre, el que maneja. */
    @Nullable
    public Player tirador() {
        if (this.torreta == null) {
            return null;
        }
        if (enAsiento(this.tipo.asientoTirador()) instanceof Player p) {
            return p;
        }
        return getChofer();
    }

    /** ¿El clic izquierdo de este jugador es para el vehículo (la bocina, o tirar con la torreta)? Sirve en el cliente. */
    public boolean usaClicIzquierdo(Player jugador) {
        return jugador.getVehicle() == this && (getChofer() == jugador || tirador() == jugador);
    }

    @Override
    protected boolean canAddPassenger(Entity pasajero) {
        return this.getPassengers().size() < this.tipo.cantidadAsientos();
    }

    @Override
    protected void addPassenger(Entity pasajero) {
        super.addPassenger(pasajero);
        if (this.level().isClientSide()) {
            return;
        }
        int[] a = asientos();
        for (int i = 0; i < a.length; i++) {
            if (a[i] != 0 && !vaArriba(a[i])) {
                a[i] = 0;
            }
        }
        int elegido = this.asientoPedido >= 0 && this.asientoPedido < a.length && a[this.asientoPedido] == 0
                ? this.asientoPedido : -1;
        if (elegido < 0) {
            elegido = a[0] == 0 && pasajero instanceof Player ? 0 : asientoLibreMasCercano(pasajero.position());
        }
        if (elegido >= 0) {
            a[elegido] = pasajero.getId();
        }
        guardarAsientos(a);
        if (pasajero instanceof Player) {
            // lo agarró un jugador: ahora es suyo (no se quita y, si se rompe, deja su ítem)
            this.transito = false;
        }
    }

    @Override
    protected void removePassenger(Entity pasajero) {
        super.removePassenger(pasajero);
        if (this.level().isClientSide()) {
            return;
        }
        int[] a = asientos();
        for (int i = 0; i < a.length; i++) {
            if (a[i] == pasajero.getId()) {
                a[i] = 0;
            }
        }
        guardarAsientos(a);
    }

    /**
     * Cada uno en su asiento, mirando hacia adelante: cuando el vehículo dobla, el que va sentado dobla con él (menos el
     * de la torreta, que sigue mirando adonde apunta).
     */
    @Override
    protected void positionRider(Entity pasajero, Entity.MoveFunction mover) {
        if (!this.hasPassenger(pasajero)) {
            return;
        }
        int i = asientoDe(pasajero);
        Vec3 p = puntoAsiento(i);
        mover.accept(pasajero, p.x, p.y - PIERNAS, p.z);
        if (esDeLaTorreta(i)) {
            return;
        }
        float giro = Mth.wrapDegrees(this.getYRot() - this.yRotO);
        if (giro != 0.0F && pasajero instanceof Player j && j.isLocalPlayer()) {
            j.setYRot(j.getYRot() + giro);
            j.setYHeadRot(j.getYHeadRot() + giro);
        }
        sujetarGiro(pasajero);
    }

    private boolean esDeLaTorreta(int asiento) {
        return this.torreta != null && asiento == this.tipo.asientoTirador();
    }

    /** El cuerpo mira hacia adelante y la cabeza gira hasta 105° para cada lado (como en los botes). */
    private void sujetarGiro(Entity pasajero) {
        pasajero.setYBodyRot(this.getYRot());
        float f = Mth.wrapDegrees(pasajero.getYRot() - this.getYRot());
        float g = Mth.clamp(f, -105.0F, 105.0F);
        pasajero.yRotO += g - f;
        pasajero.setYRot(pasajero.getYRot() + g - f);
        pasajero.setYHeadRot(pasajero.getYRot());
    }

    @Override
    public void onPassengerTurned(Entity pasajero) {
        if (!esDeLaTorreta(asientoDe(pasajero))) {
            sujetarGiro(pasajero);
        }
    }

    /** Al bajarse, sale por el costado de su asiento (si ahí no se puede, por el otro; si no, por atrás). */
    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity pasajero) {
        int i = asientoDe(pasajero);
        double lado = this.tipo.asientoCostado(i) >= 0.0 ? 1.0 : -1.0;
        double afuera = this.tipo.anchoModelo() / 2.0 + 0.7;
        Vec3[] lugares = {
                punto(this.tipo.asientoAdelante(i), lado * afuera, 0.0),
                punto(this.tipo.asientoAdelante(i), -lado * afuera, 0.0),
                punto(-this.tipo.largoAtras() - 0.8, 0.0, 0.0),
                punto(this.tipo.largoFrente() + 0.8, 0.0, 0.0)};
        for (Vec3 lugar : lugares) {
            BlockPos pos = BlockPos.containing(lugar);
            for (BlockPos q : new BlockPos[]{pos, pos.above(), pos.below()}) {
                Vec3 v = DismountHelper.findSafeDismountLocation(pasajero.getType(), this.level(), q, true);
                if (v != null) {
                    return v;
                }
            }
        }
        return super.getDismountLocationForPassenger(pasajero);
    }

    // ================================================================= interacción

    /** Clic derecho con el lugar donde se hizo: sube al asiento libre más cercano a ese punto (el primero, al volante). */
    @Override
    public InteractionResult interactAt(Player jugador, Vec3 donde, InteractionHand mano) {
        return subir(jugador, this.position().add(donde));
    }

    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        return subir(jugador, null);
    }

    private InteractionResult subir(Player jugador, @Nullable Vec3 clic) {
        if (jugador.isSecondaryUseActive() || jugador.getVehicle() == this) {
            return InteractionResult.PASS;
        }
        if (hayGenteDeLaCarretera()) {
            if (!this.level().isClientSide()) {
                jugador.displayClientMessage(Component.translatable("mensaje.locomotora.vehiculo_ocupado")
                        .withStyle(ChatFormatting.RED), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }
        if (this.getPassengers().size() >= this.tipo.cantidadAsientos()) {
            if (!this.level().isClientSide()) {
                jugador.displayClientMessage(Component.translatable("mensaje.locomotora.vehiculo_lleno")
                        .withStyle(ChatFormatting.RED), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }
        if (this.level().isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        this.asientoPedido = vaArriba(asientos()[0]) ? asientoLibreMasCercano(clic != null ? clic : jugador.position()) : 0;
        boolean subio = jugador.startRiding(this);
        this.asientoPedido = -1;
        if (!subio) {
            return InteractionResult.PASS;
        }
        String aviso;
        if (getChofer() == jugador) {
            aviso = this.torreta != null ? "mensaje.locomotora.vehiculo_manejas_torreta" : "mensaje.locomotora.vehiculo_manejas";
        } else if (tirador() == jugador) {
            aviso = "mensaje.locomotora.vehiculo_tirador";
        } else {
            aviso = "mensaje.locomotora.vehiculo_pasajero";
        }
        jugador.displayClientMessage(Component.translatable(aviso).withStyle(ChatFormatting.YELLOW), true);
        return InteractionResult.CONSUME;
    }

    /** El clic izquierdo de uno que va arriba (llega del cliente): tira con la torreta o toca la bocina. */
    public void clicIzquierdo(ServerPlayer jugador) {
        if (jugador.getVehicle() != this) {
            return;
        }
        if (this.torreta != null && tirador() == jugador) {
            if (this.torreta.gatillo()) {
                disparar(jugador.serverLevel(), jugador);
            } else {
                jugador.displayClientMessage(Component.translatable("mensaje.locomotora.recargando")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (getChofer() == jugador) {
            tocarBocina(jugador.serverLevel());
        }
    }

    private void tocarBocina(ServerLevel nivel) {
        if (this.esperaBocina > 0) {
            return;
        }
        double x = this.getX() + frenteX() * this.tipo.largoFrente() * 0.6;
        double z = this.getZ() + frenteZ() * this.tipo.largoFrente() * 0.6;
        double y = this.getY() + 1.0;
        switch (this.tipo.bocina()) {
            case AUTO -> {
                nivel.playSound(null, x, y, z, ModSonidos.BOCINA_AUTO.get(), SoundSource.NEUTRAL, 2.0F, this.tipo.tono());
                this.esperaBocina = 10;
            }
            case CAMION -> {
                nivel.playSound(null, x, y, z, ModSonidos.BOCINA.get(), SoundSource.NEUTRAL, 3.0F,
                        0.9F + 0.35F * this.tipo.tono());
                this.esperaBocina = 30;
            }
            case SIRENA -> {
                nivel.playSound(null, x, y, z, ModSonidos.SIRENA.get(), SoundSource.NEUTRAL, 4.0F, 1.0F);
                this.esperaBocina = 60;
            }
        }
    }

    // ================================================================= la torreta

    /**
     * Adónde mira el tirador: lo primero que tiene delante (un bloque o algo), sin contar este vehículo ni a los que van
     * en él; si no hay nada, un punto lejos en esa dirección. Se calcula igual en el servidor y en el cliente.
     */
    private Vec3 miraDe(Player tirador) {
        Vec3 ojo = tirador.getEyePosition();
        Vec3 fin = ojo.add(tirador.getViewVector(1.0F).scale(MIRA));
        HitResult bloque = this.level().clip(new ClipContext(ojo, fin, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, tirador));
        if (bloque.getType() != HitResult.Type.MISS) {
            fin = bloque.getLocation();
        }
        AABB zona = new AABB(ojo, fin).inflate(1.0);
        EntityHitResult algo = ProjectileUtil.getEntityHitResult(tirador, ojo, fin, zona,
                e -> e.isPickable() && !e.isSpectator() && e != this && e.getRootVehicle() != this
                        && !(e instanceof ParteVehiculo p && p.getParent() == this),
                ojo.distanceToSqr(fin));
        return algo != null ? algo.getLocation() : fin;
    }

    /** Un tiro de la torreta: el obús (o la bala) sale de la boca, con el fogonazo, el humo y el estampido. */
    private void disparar(ServerLevel nivel, Player tirador) {
        Vec3 boca = this.torreta.boca(this);
        Vec3 direccion = this.torreta.direccion(this);
        ObusEntity.tirar(nivel, this.tipo.tiro(), boca, direccion, this, this.getUUID(), tirador.getUUID(), tirador,
                1.0F);
        boolean chico = this.tipo.arma() == TipoVehiculo.Arma.AMETRALLADORA;
        nivel.sendParticles(ParticleTypes.FLAME, boca.x, boca.y, boca.z, chico ? 2 : 6, 0.08, 0.08, 0.08, 0.02);
        nivel.sendParticles(ParticleTypes.LARGE_SMOKE, boca.x, boca.y, boca.z, chico ? 1 : 7, 0.15, 0.15, 0.15, 0.02);
        if (!chico) {
            nivel.sendParticles(ParticleTypes.EXPLOSION, boca.x, boca.y, boca.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
        nivel.playSound(null, boca.x, boca.y, boca.z, chico ? ModSonidos.RAFAGA.get() : ModSonidos.CANONAZO.get(),
                SoundSource.PLAYERS, chico ? 2.0F : 4.0F, chico ? 1.1F + nivel.getRandom().nextFloat() * 0.2F : 1.2F);
    }

    // ================================================================= atropellar

    /** Los que tiene adelante (o atrás, yendo para atrás) salen despedidos y se lastiman según lo rápido que iba. */
    private void atropellar(ServerLevel nivel, float rapidez, double dx, double dz) {
        boolean haciaElFrente = dx * frenteX() + dz * frenteZ() >= 0.0;
        double punta = haciaElFrente ? this.tipo.largoFrente() - 0.4 : -(this.tipo.largoAtras() - 0.4);
        Vec3 c = punto(punta, 0.0, 0.0);
        double w = this.tipo.anchoModelo() / 2.0 + 0.2;
        AABB zona = new AABB(c.x - w, this.getY(), c.z - w, c.x + w, this.getY() + this.tipo.altoCaja(), c.z + w)
                .expandTowards(dx * 2.0, 0.0, dz * 2.0);
        LivingEntity chofer = getControllingPassenger();
        List<LivingEntity> cerca = nivel.getEntitiesOfClass(LivingEntity.class, zona, e -> sePuedeAtropellar(e, chofer));
        if (cerca.isEmpty()) {
            return;
        }
        DamageSource fuente = fuenteAtropello(nivel, chofer);
        double largo = Math.sqrt(dx * dx + dz * dz);
        float dano = (rapidez - 0.12F) * 30.0F;
        for (LivingEntity e : cerca) {
            double fuerza = 0.5 + rapidez * 1.5;
            e.push(dx / largo * fuerza, 0.25 + rapidez * 0.3, dz / largo * fuerza);
            e.hurtMarked = true;
            e.hurt(fuente, dano);
        }
    }

    /** Ni los que van arriba, ni los espectadores, ni los de creativo, ni las mascotas del que maneja. */
    private boolean sePuedeAtropellar(LivingEntity e, @Nullable LivingEntity chofer) {
        if (!e.isAlive() || e.isSpectator() || e.isInvulnerable() || e instanceof ArmorStand) {
            return false;
        }
        if (e instanceof Player p && p.isCreative()) {
            return false;
        }
        if (chofer instanceof Player && e instanceof OwnableEntity mascota && chofer.getUUID().equals(mascota.getOwnerUUID())) {
            return false;
        }
        return e.getRootVehicle() != this;
    }

    private DamageSource fuenteAtropello(ServerLevel nivel, @Nullable LivingEntity chofer) {
        Optional<Holder.Reference<DamageType>> tipoDano = nivel.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolder(ATROPELLO);
        return tipoDano.<DamageSource>map(t -> new DamageSource(t, this, chofer))
                .orElseGet(() -> nivel.damageSources().generic());
    }

    // ================================================================= golpes y romperlo

    /**
     * Los golpes lo van rompiendo (como a un bote, pero más duro); roto, deja su ítem. En creativo se rompe de un golpe
     * (sin dejar nada). Los que van arriba no le hacen nada.
     */
    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (this.level().isClientSide() || this.isRemoved()) {
            return true;
        }
        if (this.isInvulnerableTo(fuente)) {
            return false;
        }
        Entity quien = fuente.getEntity();
        if (quien != null && quien.getRootVehicle() == this) {
            return false;
        }
        if (quien instanceof LivingEntity atacante) {
            alerta(atacante);
        }
        this.setHurtDir(-this.getHurtDir());
        this.setHurtTime(10);
        this.hurtMarked = true;
        this.setDamage(this.getDamage() + cantidad * 10.0F / this.tipo.dureza());
        if (quien instanceof Player p && p.getAbilities().instabuild) {
            this.discard();
        } else if (this.getDamage() > 40.0F) {
            romper();
        }
        return true;
    }

    /** Roto: deja su ítem (con el nombre que le pusieron) y desaparece. */
    private void romper() {
        if (!this.transito && this.level().getGameRules().getBoolean(GameRules.RULE_DOENTITYDROPS)) {
            ItemStack stack = new ItemStack(getDropItem());
            if (this.hasCustomName()) {
                stack.set(DataComponents.CUSTOM_NAME, this.getCustomName());
            }
            this.spawnAtLocation(stack);
        }
        this.discard();
    }

    // ================================================================= tramos (para el clic en cualquier parte)

    @Override
    public boolean isMultipartEntity() {
        return this.partes != null;
    }

    @Override
    public PartEntity<?>[] getParts() {
        return this.partes;
    }

    /** En el cliente los tramos toman los números de entidad que tienen en el servidor (los que siguen al vehículo). */
    @Override
    public void recreateFromPacket(ClientboundAddEntityPacket paquete) {
        super.recreateFromPacket(paquete);
        if (this.partes != null) {
            for (int i = 0; i < this.partes.length; i++) {
                this.partes[i].setId(paquete.getId() + 1 + i);
            }
        }
    }

    // ================================================================= guardado (el rumbo lo guarda el juego)

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        if (this.transito) {
            tag.putBoolean("Transito", true);
        }
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.transito = tag.getBoolean("Transito");
    }

    // ================================================================= el tránsito (lo usan el Conductor y Transito)

    public boolean isTransito() {
        return this.transito;
    }

    public void setTransito(boolean transito) {
        this.transito = transito;
    }

    /** Rapidez hacia adelante (bloques por tick; negativa = marcha atrás). */
    public float getVelocidad() {
        return this.velocidad;
    }

    /** ¿Va alguien de la carretera adentro? */
    public boolean hayGenteDeLaCarretera() {
        for (Entity e : this.getPassengers()) {
            if (e instanceof PersonaEntity) {
                return true;
            }
        }
        return false;
    }

    /** ¿Puede subir alguien de la carretera? (si hay un jugador adentro, no: el vehículo ya es suyo) */
    public boolean hayLugarParaNPC() {
        if (this.getPassengers().size() >= this.tipo.cantidadAsientos()) {
            return false;
        }
        for (Entity e : this.getPassengers()) {
            if (e instanceof Player) {
                return false;
            }
        }
        return true;
    }

    /** Sube alguien de la carretera: al volante si está libre; si no, al asiento libre más cercano. */
    public boolean subirNPC(PersonaEntity persona) {
        if (!hayLugarParaNPC()) {
            return false;
        }
        this.asientoPedido = enAsiento(0) == null ? 0 : asientoLibreMasCercano(persona.position());
        boolean subio = persona.startRiding(this, true);
        this.asientoPedido = -1;
        return subio;
    }

    /** Lo atacaron (a él o a uno de los de adentro): el que maneja decide qué hacer. */
    public void alerta(LivingEntity atacante) {
        if (this.conductor != null && getChoferNPC() != null) {
            this.conductor.alerta(atacante);
        }
        if (atacante instanceof Player p && (p.isCreative() || p.isSpectator())) {
            return;
        }
        for (Entity e : this.getPassengers()) {
            if (e instanceof PersonaEntity q && q.grupo().hostil && q.getTarget() == null && atacante != q) {
                q.setTarget(atacante);
            }
        }
    }

    void tocarBocinaIA() {
        if (this.level() instanceof ServerLevel nivel) {
            tocarBocina(nivel);
        }
    }

    /** El cambio de luces: un destello en cada faro (se ve también de día). */
    void cambioDeLuces() {
        if (!(this.level() instanceof ServerLevel nivel)) {
            return;
        }
        double alto = Mth.clamp(this.tipo.altoModelo() * 0.4, 0.45, 1.1);
        double adelante = this.tipo.largoFrente() - 0.1;
        double[] costados = this.tipo.clase() == TipoVehiculo.Clase.MOTO ? new double[]{0.0}
                : new double[]{-this.tipo.anchoModelo() * 0.32, this.tipo.anchoModelo() * 0.32};
        for (double c : costados) {
            Vec3 p = puntoApoyado(adelante, c, alto);
            nivel.sendParticles(ParticleTypes.FLASH, p.x, p.y, p.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
    }
}
