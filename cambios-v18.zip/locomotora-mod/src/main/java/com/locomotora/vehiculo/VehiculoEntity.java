package com.locomotora.vehiculo;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.jetbrains.annotations.Nullable;

import com.locomotora.LocomotoraMod;
import com.locomotora.artillero.ObusEntity;
import com.locomotora.registro.ModItems;
import com.locomotora.registro.ModSonidos;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.vehicle.DismountHelper;
import net.minecraft.world.entity.vehicle.VehicleEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * Un vehículo de calle: auto, moto, camión, camioneta o militar ({@link TipoVehiculo}).
 * <ul>
 *   <li>Clic derecho: subirse. El primero va al volante y maneja; los demás se sientan en el asiento libre más cercano
 *       a donde hicieron clic.</li>
 *   <li>El que maneja: W acelera, S frena y después va marcha atrás, A y D doblan. Clic izquierdo: la bocina (en la
 *       autobomba, la sirena).</li>
 *   <li>Tanque y camión blindado: el que va en la torreta (o el que maneja, si la torreta está libre) la apunta mirando
 *       y tira con clic izquierdo.</li>
 *   <li>Sube escalones de un bloque. A los golpes se rompe y deja su ítem (en creativo, de un golpe).</li>
 * </ul>
 * Como los botes, lo mueve la computadora del que maneja (así responde al instante) y el servidor lo controla; sin nadie
 * al volante, el servidor lo deja caer y frenar solo. Pasado cierto apuro atropella a los que se le crucen.
 */
public class VehiculoEntity extends VehicleEntity {
    /** Quién va en cada asiento (id de la entidad; 0 = libre). El asiento 0 es el del que maneja. */
    private static final EntityDataAccessor<CompoundTag> DATA_ASIENTOS =
            SynchedEntityData.defineId(VehiculoEntity.class, EntityDataSerializers.COMPOUND_TAG);
    /** El que va sentado: sus pies quedan este tanto debajo de la cadera. */
    private static final double PIERNAS = 0.6;
    /** Hasta dónde se busca adónde mira el tirador (bloques). */
    private static final double MIRA = 160.0;
    /** Desde esta rapidez (bloques por tick, unos 11 km/h) atropella. */
    private static final float ATROPELLA = 0.16F;
    /** El tipo de daño (data/locomotora/damage_type/atropello_vehiculo.json): "fue atropellado por...". */
    private static final ResourceKey<DamageType> ATROPELLO =
            ResourceKey.create(Registries.DAMAGE_TYPE, LocomotoraMod.id("atropello_vehiculo"));

    private final TipoVehiculo tipo;
    @Nullable
    private final ParteVehiculo[] partes;
    @Nullable
    private final TorretaVehiculo torreta;

    // ------------------------------------------------- el que lo mueve (la computadora del que maneja, o el servidor)
    /** Rapidez hacia adelante (bloques por tick; negativa = marcha atrás). */
    private float velocidad;
    /** Cuánto doblan las ruedas de adelante (radianes; positivo = a la derecha). */
    private float direccion;

    // ------------------------------------------------- servidor
    /** El asiento más cercano al clic del próximo que sube, -1 si ninguno. */
    private int asientoPedido = -1;
    private int esperaBocina;
    private int esperaMotor;
    private int esperaEstado;
    private float rapidezSuave;
    /**
     * Dónde estaba en el tick anterior del servidor. Cuando maneja un jugador, la posición llega de su computadora entre
     * un tick y otro (antes de que el servidor guarde la posición "vieja"), así que lo que anduvo se mide contra esto.
     */
    private double antX = Double.NaN;
    private double antZ;

    // ------------------------------------------------- cliente (animación) y los que lo ven moverse de lejos
    private double recorrido;
    private double recorridoAnterior;
    private float direccionVista;
    private float direccionVistaAnterior;
    private int lerpPasos;
    private double lerpX;
    private double lerpY;
    private double lerpZ;
    private float lerpYRot;
    private float lerpXRot;

    public VehiculoEntity(EntityType<? extends VehiculoEntity> tipoEntidad, Level level, TipoVehiculo tipo) {
        super(tipoEntidad, level);
        this.tipo = tipo;
        this.blocksBuilding = true;
        // los tramos se crean justo después del vehículo: sus números de entidad quedan seguidos al suyo
        double largo = tipo.largoFrente() + tipo.largoAtras();
        float ancho = tipo.anchoCaja();
        int n = (int) Math.ceil(largo / ancho - 0.15);
        if (n >= 2) {
            this.partes = new ParteVehiculo[n];
            for (int i = 0; i < n; i++) {
                this.partes[i] = new ParteVehiculo(this, ancho, tipo.altoCaja());
            }
        } else {
            this.partes = null;
        }
        this.torreta = tipo.tieneTorreta() ? new TorretaVehiculo(tipo) : null;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_ASIENTOS, new CompoundTag());
    }

    // ================================================================= identidad

    public TipoVehiculo getTipo() {
        return this.tipo;
    }

    /** El ítem que deja al romperse (el mismo con que se puso). */
    protected Item getDropItem() {
        return ModItems.porTipo(this.tipo).get();
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(getDropItem());
    }

    /** El modelo es más grande que la caja de choque: así no desaparece al mirarlo de cerca. */
    @Override
    public AABB getBoundingBoxForCulling() {
        double a = this.tipo.alcance() + 1.0;
        return this.getBoundingBox().inflate(a, 0.0, a).expandTowards(0.0, 2.0, 0.0);
    }

    /** Se le puede hacer clic, salvo desde adentro (si no, el que va sentado no podría apuntar a nada). */
    @Override
    public boolean isPickable() {
        return !this.isRemoved() && !(this.level().isClientSide() && com.locomotora.cliente.Local.vaEn(this));
    }

    /** Es sólido para los demás (como un bote): se le puede subir encima y no se mete en otros vehículos. */
    @Override
    public boolean canBeCollidedWith() {
        return true;
    }

    /** No lo empujan los que caminan. */
    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean fireImmune() {
        return this.tipo.aPruebaDeFuego() || super.fireImmune();
    }

    /** Sube escalones de un bloque (los cordones, las lomas del terreno). */
    @Override
    public float maxUpStep() {
        return 1.0F;
    }

    // ================================================================= dónde queda cada cosa

    /** El frente, en el mundo: con el giro de Minecraft (0 = hacia el sur), (-sin, cos). */
    public double frenteX() {
        return -Math.sin(Math.toRadians(this.getYRot()));
    }

    public double frenteZ() {
        return Math.cos(Math.toRadians(this.getYRot()));
    }

    /** Un punto del vehículo: tanto hacia adelante, tanto hacia la derecha (-frenteZ, frenteX) y tanto de alto. */
    public Vec3 punto(double adelante, double costado, double alto) {
        double fx = frenteX();
        double fz = frenteZ();
        return new Vec3(this.getX() + fx * adelante - fz * costado, this.getY() + alto,
                this.getZ() + fz * adelante + fx * costado);
    }

    private Vec3 puntoAsiento(int i) {
        return punto(this.tipo.asientoAdelante(i), this.tipo.asientoCostado(i), this.tipo.asientoAlto(i));
    }

    // ================================================================= para dibujarlo

    /** Distancia recorrida (bloques, interpolada) para girar las ruedas. */
    public double getRecorrido(float tickParcial) {
        return Mth.lerp(tickParcial, this.recorridoAnterior, this.recorrido);
    }

    /** Cuánto doblan las ruedas de adelante (radianes, positivo a la derecha). */
    public float getDireccion(float tickParcial) {
        return Mth.lerp(tickParcial, this.direccionVistaAnterior, this.direccionVista);
    }

    public float giroTorreta(float tickParcial) {
        return this.torreta == null ? 0.0F : this.torreta.giro(tickParcial);
    }

    public float alzaTorreta(float tickParcial) {
        return this.torreta == null ? 0.0F : this.torreta.alza(tickParcial);
    }

    // ================================================================= tick

    @Override
    public void tick() {
        if (this.getHurtTime() > 0) {
            this.setHurtTime(this.getHurtTime() - 1);
        }
        if (this.getDamage() > 0.0F) {
            this.setDamage(this.getDamage() - 1.0F);
        }
        super.tick();
        tickLerp();
        if (this.isControlledByLocalInstance()) {
            manejar();
        } else {
            this.setDeltaMovement(Vec3.ZERO);
        }
        moverPartes();
        if (this.level().isClientSide()) {
            tickCliente();
        } else {
            tickServidor((ServerLevel) this.level());
        }
    }

    /**
     * El que lo mueve (la computadora del que maneja, o el servidor si nadie maneja): acelera o frena según W y S,
     * dobla con A y D (las ruedas de adelante giran y el vehículo sigue la curva que marcan; el tanque gira en el
     * lugar), cae si no tiene piso y se mueve chocando con los bloques.
     */
    private void manejar() {
        Player chofer = getChofer();
        float acelerador = chofer == null ? 0.0F : chofer.zza;
        float volante = chofer == null ? 0.0F : chofer.xxa;
        boolean enAgua = this.isInWater();
        float maxima = this.tipo.velocidadMaxima() * (enAgua ? 0.35F : 1.0F);
        if (this.onGround() || enAgua) {
            if (acelerador > 0.1F) {
                this.velocidad = this.velocidad < 0.0F
                        ? Math.min(0.0F, this.velocidad + this.tipo.freno())
                        : Math.min(maxima, this.velocidad + this.tipo.aceleracion());
            } else if (acelerador < -0.1F) {
                this.velocidad = this.velocidad > 0.0F
                        ? Math.max(0.0F, this.velocidad - this.tipo.freno())
                        : Math.max(-this.tipo.velocidadAtras(), this.velocidad - this.tipo.aceleracion() * 0.7F);
            } else {
                // sin acelerar se va frenando solo (y sin nadie al volante, más rápido: freno de mano)
                this.velocidad *= chofer == null ? 0.9F : 0.985F;
                this.velocidad -= Math.signum(this.velocidad) * 0.003F;
                if (Math.abs(this.velocidad) < 0.004F) {
                    this.velocidad = 0.0F;
                }
            }
            if (this.velocidad > maxima) {
                this.velocidad = Math.max(maxima, this.velocidad - this.tipo.freno());
            }
        } else {
            this.velocidad *= 0.995F;
        }

        float rumbo = this.getYRot();
        if (this.tipo.oruga()) {
            // orugas: gira en el lugar (una hacia adelante y la otra hacia atrás)
            rumbo -= volante * (Math.abs(this.velocidad) > 0.05F ? 2.2F : 3.0F);
            this.direccion = 0.0F;
        } else {
            // las ruedas doblan menos cuanto más rápido va (si no, a toda velocidad dobla de golpe)
            float limite = this.tipo.giroMaximo() / (1.0F + 2.0F * Math.abs(this.velocidad));
            float buscada = -volante * limite;
            this.direccion += Mth.clamp(buscada - this.direccion, -0.08F, 0.08F);
            // la curva que marcan las ruedas: gira velocidad / distancia entre ejes · tan(dirección) por tick
            double giro = this.velocidad / this.tipo.distanciaEjes() * Math.tan(this.direccion);
            rumbo += (float) Math.toDegrees(giro);
        }
        this.setYRot(Mth.wrapDegrees(rumbo));

        Vec3 antes = this.getDeltaMovement();
        double vy = antes.y;
        if (enAgua) {
            vy = Math.max(vy - 0.02, -0.08);
        } else if (!this.isNoGravity()) {
            vy = (vy - 0.08) * 0.98;
        }
        // la trompa (o la cola, yendo para atrás) no se mete en las paredes: la caja de choque es solo el medio
        if (this.velocidad != 0.0F && chocaria(this.velocidad)) {
            this.velocidad = 0.0F;
        }
        this.setDeltaMovement(frenteX() * this.velocidad, vy, frenteZ() * this.velocidad);
        this.move(MoverType.SELF, this.getDeltaMovement());
        if (this.horizontalCollision) {
            this.velocidad *= 0.5F;
        }
    }

    /** ¿La punta que va adelante se metería en un bloque (más alto que un escalón) si avanza esto? */
    private boolean chocaria(float avance) {
        double punta = avance > 0.0F ? this.tipo.largoFrente() - 0.3 : -(this.tipo.largoAtras() - 0.3);
        Vec3 c = punto(punta + avance, 0.0, 0.0);
        double w = Math.max(0.3, this.tipo.anchoModelo() * 0.38);
        double y0 = this.getY() + this.maxUpStep() + 0.1;
        double y1 = this.getY() + Math.max(this.maxUpStep() + 0.35, this.tipo.altoCaja() * 0.85);
        return !this.level().noCollision(this, new AABB(c.x - w, y0, c.z - w, c.x + w, y1, c.z + w));
    }

    /** Los tramos acompañan al vehículo (también en el cliente, para poder hacerles clic). */
    private void moverPartes() {
        if (this.partes == null) {
            return;
        }
        double largo = this.tipo.largoFrente() + this.tipo.largoAtras();
        double paso = largo / this.partes.length;
        for (int i = 0; i < this.partes.length; i++) {
            ParteVehiculo p = this.partes[i];
            Vec3 c = punto(this.tipo.largoFrente() - (i + 0.5) * paso, 0.0, 0.0);
            p.xo = p.getX();
            p.yo = p.getY();
            p.zo = p.getZ();
            p.xOld = p.xo;
            p.yOld = p.yo;
            p.zOld = p.zo;
            p.setPos(c.x, c.y, c.z);
        }
    }

    private void tickCliente() {
        // las ruedas giran según lo que avanzó
        this.recorridoAnterior = this.recorrido;
        double dx = this.getX() - this.xo;
        double dz = this.getZ() - this.zo;
        double avance = dx * frenteX() + dz * frenteZ();
        if (Math.abs(avance) < 2.0) {
            this.recorrido += avance;
        }
        // las de adelante doblan: el que maneja ve lo que hace; los demás, lo que dobla al moverse
        this.direccionVistaAnterior = this.direccionVista;
        float buscada;
        if (this.isControlledByLocalInstance()) {
            buscada = this.direccion;
        } else if (Math.abs(avance) > 0.01) {
            float giro = (float) Math.toRadians(Mth.wrapDegrees(this.getYRot() - this.yRotO));
            buscada = (float) Math.atan(this.tipo.distanciaEjes() * giro / avance);
        } else {
            buscada = this.direccionVista;
        }
        buscada = Mth.clamp(buscada, -this.tipo.giroMaximo(), this.tipo.giroMaximo());
        this.direccionVista += (buscada - this.direccionVista) * 0.4F;
        if (this.torreta != null) {
            Player tirador = tirador();
            this.torreta.apuntar(this, tirador == null ? null : miraDe(tirador));
        }
    }

    private void tickServidor(ServerLevel nivel) {
        // lo que anduvo desde el tick anterior (también cuando lo mueve la computadora del que maneja)
        double dx = Double.isNaN(this.antX) ? 0.0 : this.getX() - this.antX;
        double dz = Double.isNaN(this.antX) ? 0.0 : this.getZ() - this.antZ;
        this.antX = this.getX();
        this.antZ = this.getZ();
        float rapidez = (float) Math.sqrt(dx * dx + dz * dz);
        this.rapidezSuave += (Math.min(rapidez, 2.0F) - this.rapidezSuave) * 0.3F;
        if (this.esperaBocina > 0) {
            this.esperaBocina--;
        }
        Player chofer = getChofer();
        if (chofer != null) {
            // el motor: más agudo y más seguido cuanto más rápido va
            if (--this.esperaMotor <= 0) {
                float apuro = Math.min(1.0F, this.rapidezSuave / Math.max(0.1F, this.tipo.velocidadMaxima()));
                float tono = this.tipo.tono() * (this.tipo.clase() == TipoVehiculo.Clase.MOTO ? 1.5F : 1.0F)
                        * (0.8F + 0.55F * apuro);
                nivel.playSound(null, this.getX(), this.getY() + 0.8, this.getZ(), ModSonidos.MOTOR.get(),
                        SoundSource.NEUTRAL, 0.55F + 0.35F * apuro, tono);
                this.esperaMotor = apuro > 0.05F ? 9 : 16;
            }
            if (++this.esperaEstado >= 10) {
                this.esperaEstado = 0;
                if (this.rapidezSuave > 0.01F) {
                    chofer.displayClientMessage(Component.translatable("estado.locomotora.vehiculo",
                            Math.round(this.rapidezSuave * 72.0F)).withStyle(ChatFormatting.GRAY), true);
                }
            }
        } else {
            this.esperaMotor = 0;
        }
        if (rapidez > ATROPELLA && rapidez < 2.5F) {
            atropellar(nivel, rapidez, dx, dz);
        }
        if (this.torreta != null) {
            Player tirador = tirador();
            this.torreta.apuntar(this, tirador == null ? null : miraDe(tirador));
            if (this.torreta.siguienteDeRafaga() && tirador != null) {
                disparar(nivel, tirador);
            }
        }
    }

    // ================================================================= los que lo ven de lejos: movimiento suave

    @Override
    public void lerpTo(double x, double y, double z, float rumbo, float cabeceo, int pasos) {
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYRot = rumbo;
        this.lerpXRot = cabeceo;
        this.lerpPasos = Math.max(1, pasos);
    }

    private void tickLerp() {
        if (this.isControlledByLocalInstance()) {
            this.lerpPasos = 0;
            this.syncPacketPositionCodec(this.getX(), this.getY(), this.getZ());
        }
        if (this.lerpPasos > 0) {
            double f = 1.0 / this.lerpPasos;
            double x = this.getX() + (this.lerpX - this.getX()) * f;
            double y = this.getY() + (this.lerpY - this.getY()) * f;
            double z = this.getZ() + (this.lerpZ - this.getZ()) * f;
            float rumbo = Mth.rotLerp((float) f, this.getYRot(), this.lerpYRot);
            float cabeceo = this.getXRot() + (this.lerpXRot - this.getXRot()) * (float) f;
            this.lerpPasos--;
            this.setPos(x, y, z);
            this.setRot(rumbo, cabeceo);
        }
    }

    // ================================================================= asientos

    /** Quién va en cada asiento (números de entidad; 0 = libre). Es una copia: se cambia y se guarda con guardarAsientos. */
    private int[] asientos() {
        int[] a = this.entityData.get(DATA_ASIENTOS).getIntArray("a");
        return Arrays.copyOf(a, this.tipo.cantidadAsientos());
    }

    private void guardarAsientos(int[] a) {
        CompoundTag tag = new CompoundTag();
        tag.putIntArray("a", a);
        this.entityData.set(DATA_ASIENTOS, tag);
    }

    private boolean vaArriba(int id) {
        if (id == 0) {
            return false;
        }
        for (Entity p : this.getPassengers()) {
            if (p.getId() == id) {
                return true;
            }
        }
        return false;
    }

    /** El asiento de un pasajero (si todavía no llegó el dato, el que le toca por orden de subida). */
    private int asientoDe(Entity pasajero) {
        int[] a = asientos();
        for (int i = 0; i < a.length; i++) {
            if (a[i] == pasajero.getId()) {
                return i;
            }
        }
        int k = this.getPassengers().indexOf(pasajero);
        return Math.max(0, Math.min(a.length - 1, k));
    }

    /** Quién va en un asiento, o null. */
    @Nullable
    public Entity enAsiento(int i) {
        int[] a = asientos();
        if (i < 0 || i >= a.length || a[i] == 0) {
            return null;
        }
        for (Entity p : this.getPassengers()) {
            if (p.getId() == a[i]) {
                return p;
            }
        }
        return null;
    }

    private int asientoLibreMasCercano(Vec3 desde) {
        int[] a = asientos();
        int mejor = -1;
        double distancia = Double.MAX_VALUE;
        for (int i = 0; i < a.length; i++) {
            if (vaArriba(a[i])) {
                continue;
            }
            double d = puntoAsiento(i).distanceToSqr(desde);
            if (d < distancia) {
                distancia = d;
                mejor = i;
            }
        }
        return mejor;
    }

    /** El que maneja: el jugador que va al volante (el primer asiento), o null. */
    @Nullable
    public Player getChofer() {
        return enAsiento(0) instanceof Player p ? p : null;
    }

    /** El que maneja es el que lo mueve (como en los botes: lo mueve su computadora). */
    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        return getChofer();
    }

    /** El que apunta la torreta: el que va en ella o, si está libre, el que maneja. */
    @Nullable
    public Player tirador() {
        if (this.torreta == null) {
            return null;
        }
        if (enAsiento(this.tipo.asientoTirador()) instanceof Player p) {
            return p;
        }
        return getChofer();
    }

    /** ¿El clic izquierdo de este jugador es para el vehículo (la bocina, o tirar con la torreta)? Sirve en el cliente. */
    public boolean usaClicIzquierdo(Player jugador) {
        return jugador.getVehicle() == this && (getChofer() == jugador || tirador() == jugador);
    }

    @Override
    protected boolean canAddPassenger(Entity pasajero) {
        return this.getPassengers().size() < this.tipo.cantidadAsientos();
    }

    @Override
    protected void addPassenger(Entity pasajero) {
        super.addPassenger(pasajero);
        if (this.level().isClientSide()) {
            return;
        }
        int[] a = asientos();
        for (int i = 0; i < a.length; i++) {
            if (a[i] != 0 && !vaArriba(a[i])) {
                a[i] = 0;
            }
        }
        int elegido = this.asientoPedido >= 0 && this.asientoPedido < a.length && a[this.asientoPedido] == 0
                ? this.asientoPedido : -1;
        if (elegido < 0) {
            elegido = a[0] == 0 && pasajero instanceof Player ? 0 : asientoLibreMasCercano(pasajero.position());
        }
        if (elegido >= 0) {
            a[elegido] = pasajero.getId();
        }
        guardarAsientos(a);
    }

    @Override
    protected void removePassenger(Entity pasajero) {
        super.removePassenger(pasajero);
        if (this.level().isClientSide()) {
            return;
        }
        int[] a = asientos();
        for (int i = 0; i < a.length; i++) {
            if (a[i] == pasajero.getId()) {
                a[i] = 0;
            }
        }
        guardarAsientos(a);
    }

    /**
     * Cada uno en su asiento, mirando hacia adelante: cuando el vehículo dobla, el que va sentado dobla con él (menos el
     * de la torreta, que sigue mirando adonde apunta).
     */
    @Override
    protected void positionRider(Entity pasajero, Entity.MoveFunction mover) {
        if (!this.hasPassenger(pasajero)) {
            return;
        }
        int i = asientoDe(pasajero);
        Vec3 p = puntoAsiento(i);
        mover.accept(pasajero, p.x, p.y - PIERNAS, p.z);
        if (esDeLaTorreta(i)) {
            return;
        }
        float giro = Mth.wrapDegrees(this.getYRot() - this.yRotO);
        if (giro != 0.0F && pasajero instanceof Player j && j.isLocalPlayer()) {
            j.setYRot(j.getYRot() + giro);
            j.setYHeadRot(j.getYHeadRot() + giro);
        }
        sujetarGiro(pasajero);
    }

    private boolean esDeLaTorreta(int asiento) {
        return this.torreta != null && asiento == this.tipo.asientoTirador();
    }

    /** El cuerpo mira hacia adelante y la cabeza gira hasta 105° para cada lado (como en los botes). */
    private void sujetarGiro(Entity pasajero) {
        pasajero.setYBodyRot(this.getYRot());
        float f = Mth.wrapDegrees(pasajero.getYRot() - this.getYRot());
        float g = Mth.clamp(f, -105.0F, 105.0F);
        pasajero.yRotO += g - f;
        pasajero.setYRot(pasajero.getYRot() + g - f);
        pasajero.setYHeadRot(pasajero.getYRot());
    }

    @Override
    public void onPassengerTurned(Entity pasajero) {
        if (!esDeLaTorreta(asientoDe(pasajero))) {
            sujetarGiro(pasajero);
        }
    }

    /** Al bajarse, sale por el costado de su asiento (si ahí no se puede, por el otro; si no, por atrás). */
    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity pasajero) {
        int i = asientoDe(pasajero);
        double lado = this.tipo.asientoCostado(i) >= 0.0 ? 1.0 : -1.0;
        double afuera = this.tipo.anchoModelo() / 2.0 + 0.7;
        Vec3[] lugares = {
                punto(this.tipo.asientoAdelante(i), lado * afuera, 0.0),
                punto(this.tipo.asientoAdelante(i), -lado * afuera, 0.0),
                punto(-this.tipo.largoAtras() - 0.8, 0.0, 0.0),
                punto(this.tipo.largoFrente() + 0.8, 0.0, 0.0)};
        for (Vec3 lugar : lugares) {
            BlockPos pos = BlockPos.containing(lugar);
            for (BlockPos q : new BlockPos[]{pos, pos.above(), pos.below()}) {
                Vec3 v = DismountHelper.findSafeDismountLocation(pasajero.getType(), this.level(), q, true);
                if (v != null) {
                    return v;
                }
            }
        }
        return super.getDismountLocationForPassenger(pasajero);
    }

    // ================================================================= interacción

    /** Clic derecho con el lugar donde se hizo: sube al asiento libre más cercano a ese punto (el primero, al volante). */
    @Override
    public InteractionResult interactAt(Player jugador, Vec3 donde, InteractionHand mano) {
        return subir(jugador, this.position().add(donde));
    }

    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        return subir(jugador, null);
    }

    private InteractionResult subir(Player jugador, @Nullable Vec3 clic) {
        if (jugador.isSecondaryUseActive() || jugador.getVehicle() == this) {
            return InteractionResult.PASS;
        }
        if (this.getPassengers().size() >= this.tipo.cantidadAsientos()) {
            if (!this.level().isClientSide()) {
                jugador.displayClientMessage(Component.translatable("mensaje.locomotora.vehiculo_lleno")
                        .withStyle(ChatFormatting.RED), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }
        if (this.level().isClientSide()) {
            return InteractionResult.SUCCESS;
        }
        this.asientoPedido = vaArriba(asientos()[0]) ? asientoLibreMasCercano(clic != null ? clic : jugador.position()) : 0;
        boolean subio = jugador.startRiding(this);
        this.asientoPedido = -1;
        if (!subio) {
            return InteractionResult.PASS;
        }
        String aviso;
        if (getChofer() == jugador) {
            aviso = this.torreta != null ? "mensaje.locomotora.vehiculo_manejas_torreta" : "mensaje.locomotora.vehiculo_manejas";
        } else if (tirador() == jugador) {
            aviso = "mensaje.locomotora.vehiculo_tirador";
        } else {
            aviso = "mensaje.locomotora.vehiculo_pasajero";
        }
        jugador.displayClientMessage(Component.translatable(aviso).withStyle(ChatFormatting.YELLOW), true);
        return InteractionResult.CONSUME;
    }

    /** El clic izquierdo de uno que va arriba (llega del cliente): tira con la torreta o toca la bocina. */
    public void clicIzquierdo(ServerPlayer jugador) {
        if (jugador.getVehicle() != this) {
            return;
        }
        if (this.torreta != null && tirador() == jugador) {
            if (this.torreta.gatillo()) {
                disparar(jugador.serverLevel(), jugador);
            } else {
                jugador.displayClientMessage(Component.translatable("mensaje.locomotora.recargando")
                        .withStyle(ChatFormatting.GRAY), true);
            }
            return;
        }
        if (getChofer() == jugador) {
            tocarBocina(jugador.serverLevel());
        }
    }

    private void tocarBocina(ServerLevel nivel) {
        if (this.esperaBocina > 0) {
            return;
        }
        double x = this.getX() + frenteX() * this.tipo.largoFrente() * 0.6;
        double z = this.getZ() + frenteZ() * this.tipo.largoFrente() * 0.6;
        double y = this.getY() + 1.0;
        switch (this.tipo.bocina()) {
            case AUTO -> {
                nivel.playSound(null, x, y, z, ModSonidos.BOCINA_AUTO.get(), SoundSource.NEUTRAL, 2.0F, this.tipo.tono());
                this.esperaBocina = 10;
            }
            case CAMION -> {
                nivel.playSound(null, x, y, z, ModSonidos.BOCINA.get(), SoundSource.NEUTRAL, 3.0F,
                        0.9F + 0.35F * this.tipo.tono());
                this.esperaBocina = 30;
            }
            case SIRENA -> {
                nivel.playSound(null, x, y, z, ModSonidos.SIRENA.get(), SoundSource.NEUTRAL, 4.0F, 1.0F);
                this.esperaBocina = 60;
            }
        }
    }

    // ================================================================= la torreta

    /**
     * Adónde mira el tirador: lo primero que tiene delante (un bloque o algo), sin contar este vehículo ni a los que van
     * en él; si no hay nada, un punto lejos en esa dirección. Se calcula igual en el servidor y en el cliente.
     */
    private Vec3 miraDe(Player tirador) {
        Vec3 ojo = tirador.getEyePosition();
        Vec3 fin = ojo.add(tirador.getViewVector(1.0F).scale(MIRA));
        HitResult bloque = this.level().clip(new ClipContext(ojo, fin, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, tirador));
        if (bloque.getType() != HitResult.Type.MISS) {
            fin = bloque.getLocation();
        }
        AABB zona = new AABB(ojo, fin).inflate(1.0);
        EntityHitResult algo = ProjectileUtil.getEntityHitResult(tirador, ojo, fin, zona,
                e -> e.isPickable() && !e.isSpectator() && e != this && e.getRootVehicle() != this
                        && !(e instanceof ParteVehiculo p && p.getParent() == this),
                ojo.distanceToSqr(fin));
        return algo != null ? algo.getLocation() : fin;
    }

    /** Un tiro de la torreta: el obús (o la bala) sale de la boca, con el fogonazo, el humo y el estampido. */
    private void disparar(ServerLevel nivel, Player tirador) {
        Vec3 boca = this.torreta.boca(this);
        Vec3 direccion = this.torreta.direccion(this);
        ObusEntity.tirar(nivel, this.tipo.tiro(), boca, direccion, this, this.getUUID(), tirador.getUUID(), tirador,
                1.0F);
        boolean chico = this.tipo.arma() == TipoVehiculo.Arma.AMETRALLADORA;
        nivel.sendParticles(ParticleTypes.FLAME, boca.x, boca.y, boca.z, chico ? 2 : 6, 0.08, 0.08, 0.08, 0.02);
        nivel.sendParticles(ParticleTypes.LARGE_SMOKE, boca.x, boca.y, boca.z, chico ? 1 : 7, 0.15, 0.15, 0.15, 0.02);
        if (!chico) {
            nivel.sendParticles(ParticleTypes.EXPLOSION, boca.x, boca.y, boca.z, 1, 0.0, 0.0, 0.0, 0.0);
        }
        nivel.playSound(null, boca.x, boca.y, boca.z, chico ? ModSonidos.RAFAGA.get() : ModSonidos.CANONAZO.get(),
                SoundSource.PLAYERS, chico ? 2.0F : 4.0F, chico ? 1.1F + nivel.getRandom().nextFloat() * 0.2F : 1.2F);
    }

    // ================================================================= atropellar

    /** Los que tiene adelante (o atrás, yendo para atrás) salen despedidos y se lastiman según lo rápido que iba. */
    private void atropellar(ServerLevel nivel, float rapidez, double dx, double dz) {
        boolean haciaElFrente = dx * frenteX() + dz * frenteZ() >= 0.0;
        double punta = haciaElFrente ? this.tipo.largoFrente() - 0.4 : -(this.tipo.largoAtras() - 0.4);
        Vec3 c = punto(punta, 0.0, 0.0);
        double w = this.tipo.anchoModelo() / 2.0 + 0.2;
        AABB zona = new AABB(c.x - w, this.getY(), c.z - w, c.x + w, this.getY() + this.tipo.altoCaja(), c.z + w)
                .expandTowards(dx * 2.0, 0.0, dz * 2.0);
        Player chofer = getChofer();
        List<LivingEntity> cerca = nivel.getEntitiesOfClass(LivingEntity.class, zona, e -> sePuedeAtropellar(e, chofer));
        if (cerca.isEmpty()) {
            return;
        }
        DamageSource fuente = fuenteAtropello(nivel, chofer);
        double largo = Math.sqrt(dx * dx + dz * dz);
        float dano = (rapidez - 0.12F) * 30.0F;
        for (LivingEntity e : cerca) {
            double fuerza = 0.5 + rapidez * 1.5;
            e.push(dx / largo * fuerza, 0.25 + rapidez * 0.3, dz / largo * fuerza);
            e.hurtMarked = true;
            e.hurt(fuente, dano);
        }
    }

    /** Ni los que van arriba, ni los espectadores, ni los de creativo, ni las mascotas del que maneja. */
    private boolean sePuedeAtropellar(LivingEntity e, @Nullable Player chofer) {
        if (!e.isAlive() || e.isSpectator() || e.isInvulnerable() || e instanceof ArmorStand) {
            return false;
        }
        if (e instanceof Player p && p.isCreative()) {
            return false;
        }
        if (chofer != null && e instanceof OwnableEntity mascota && chofer.getUUID().equals(mascota.getOwnerUUID())) {
            return false;
        }
        return e.getRootVehicle() != this;
    }

    private DamageSource fuenteAtropello(ServerLevel nivel, @Nullable Player chofer) {
        Optional<Holder.Reference<DamageType>> tipoDano = nivel.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolder(ATROPELLO);
        return tipoDano.<DamageSource>map(t -> new DamageSource(t, this, chofer))
                .orElseGet(() -> nivel.damageSources().generic());
    }

    // ================================================================= golpes y romperlo

    /**
     * Los golpes lo van rompiendo (como a un bote, pero más duro); roto, deja su ítem. En creativo se rompe de un golpe
     * (sin dejar nada). Los que van arriba no le hacen nada.
     */
    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        if (this.level().isClientSide() || this.isRemoved()) {
            return true;
        }
        if (this.isInvulnerableTo(fuente)) {
            return false;
        }
        Entity quien = fuente.getEntity();
        if (quien != null && quien.getRootVehicle() == this) {
            return false;
        }
        this.setHurtDir(-this.getHurtDir());
        this.setHurtTime(10);
        this.hurtMarked = true;
        this.setDamage(this.getDamage() + cantidad * 10.0F / this.tipo.dureza());
        if (quien instanceof Player p && p.getAbilities().instabuild) {
            this.discard();
        } else if (this.getDamage() > 40.0F) {
            romper();
        }
        return true;
    }

    /** Roto: deja su ítem (con el nombre que le pusieron) y desaparece. */
    private void romper() {
        if (this.level().getGameRules().getBoolean(GameRules.RULE_DOENTITYDROPS)) {
            ItemStack stack = new ItemStack(getDropItem());
            if (this.hasCustomName()) {
                stack.set(DataComponents.CUSTOM_NAME, this.getCustomName());
            }
            this.spawnAtLocation(stack);
        }
        this.discard();
    }

    // ================================================================= tramos (para el clic en cualquier parte)

    @Override
    public boolean isMultipartEntity() {
        return this.partes != null;
    }

    @Override
    public PartEntity<?>[] getParts() {
        return this.partes;
    }

    /** En el cliente los tramos toman los números de entidad que tienen en el servidor (los que siguen al vehículo). */
    @Override
    public void recreateFromPacket(ClientboundAddEntityPacket paquete) {
        super.recreateFromPacket(paquete);
        if (this.partes != null) {
            for (int i = 0; i < this.partes.length; i++) {
                this.partes[i].setId(paquete.getId() + 1 + i);
            }
        }
    }

    // ================================================================= guardado (el rumbo lo guarda el juego)

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }
}
