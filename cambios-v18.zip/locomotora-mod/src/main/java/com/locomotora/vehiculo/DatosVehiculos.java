package com.locomotora.vehiculo;

/**
 * Medidas, asientos y torretas de los vehículos de calle (generado por el estudio de diseño junto con los modelos).
 * En el modelo el frente está hacia -x, la z va hacia la derecha del que maneja y la y es la altura sobre el suelo.
 */
final class DatosVehiculos {
    private DatosVehiculos() {
    }

    /**
     * {frente, atrás, ancho, alto, eje delantero, eje trasero, radio de las ruedas, alcance} en bloques: cuánto
     * sobresale el casco hacia adelante y hacia atrás del centro (sin la torreta), su ancho y su alto (sin antenas ni
     * espejos), la x del modelo de los ejes de adelante y de atrás, el radio de la rueda más grande y hasta dónde llega
     * el modelo entero desde el centro (en planta, con la torreta y todo).
     */
    static float[] medidas(String id) {
        return switch (id) {
            case "auto_convertible" -> new float[]{2.8125F, 2.821875F, 2.25F, 1.59375F, -1.5625F, 1.5625F, 0.375F, 2.9261749776799064F};
            case "auto_sedan" -> new float[]{2.9375F, 2.978125F, 2.375F, 1.9379719627047558F, -1.6875F, 1.6875F, 0.375F, 3.087272258807117F};
            case "auto_antiguo" -> new float[]{2.6875F, 2.625F, 2.521875F, 2.125485285709567F, -1.6875F, 1.4375F, 0.4375F, 2.9134655052016663F};
            case "auto_compacto" -> new float[]{2.0625F, 2.0625F, 2.125F, 1.8941101192027026F, -1.1875F, 1.1875F, 0.3125F, 2.1830311495716224F};
            case "auto_rural" -> new float[]{2.9375F, 3.103125F, 2.375F, 2.25625F, -1.6875F, 1.75F, 0.375F, 3.204001404494074F};
            case "moto_clasica" -> new float[]{1.253523315309193F, 1.3156367734026484F, 1.0147456131094983F, 1.377474101265259F, -0.8125F, 0.8125F, 0.375F, 1.3265615797994452F};
            case "moto_scooter" -> new float[]{1.0713180149744386F, 1.15625F, 0.9446261919344282F, 1.28125F, -0.75F, 0.625F, 0.25F, 1.1745012239244368F};
            case "moto_sidecar" -> new float[]{1.253523315309193F, 1.3156367734026484F, 2.556F, 1.377474101265259F, -0.8125F, 0.8125F, 0.375F, 1.4320173979826503F};
            case "moto_ruta" -> new float[]{1.4697850433854092F, 1.3126539226722234F, 1.175F, 1.6394106859920183F, -1.0625F, 0.875F, 0.375F, 1.4754954833599794F};
            case "moto_calle" -> new float[]{1.1390863205437247F, 1.0940555824579945F, 0.9972082786659657F, 1.3514921848239345F, -0.78125F, 0.71875F, 0.3125F, 1.145098491749112F};
            case "camion_barandas" -> new float[]{3.9375F, 2.96875F, 2.5625F, 2.6875F, -3.0F, 1.375F, 0.46875F, 4.112670969090526F};
            case "camion_cisterna" -> new float[]{3.5F, 3.1497899159663865F, 2.625F, 3.228125F, -2.75F, 2.25F, 0.46875F, 3.6959648604931297F};
            case "camion_bomberos" -> new float[]{3.75F, 2.96875F, 2.625F, 3.0625F, -3.0F, 1.5F, 0.46875F, 3.9335297443898907F};
            case "autobus" -> new float[]{4.531788595852826F, 4.625F, 2.5007315887075605F, 3.0F, -3.0F, 2.25F, 0.5F, 4.7909419741842F};
            case "casa_rodante" -> new float[]{3.5F, 4.0F, 2.625F, 3.3125F, -2.5F, 2.375F, 0.4375F, 4.172547932618629F};
            case "camioneta_pickup" -> new float[]{3.3125F, 2.0F, 2.071875F, 2.2504852857095674F, -2.375F, 1.375F, 0.375F, 3.460152633916602F};
            case "camioneta_doble_cabina" -> new float[]{3.125F, 3.0F, 2.384375F, 2.2691896412892167F, -2.0F, 1.75F, 0.4375F, 3.321332563896606F};
            case "camioneta_furgon" -> new float[]{2.625F, 2.875F, 2.375F, 2.275478088363118F, -1.625F, 1.75F, 0.375F, 3.087272258807117F};
            case "camioneta_4x4" -> new float[]{2.5625F, 2.578125F, 2.4F, 3.025F, -1.5625F, 1.4375F, 0.4375F, 2.7164142265125912F};
            case "militar_jeep" -> new float[]{2.125F, 2.134375F, 2.131F, 1.75F, -1.375F, 1.125F, 0.40625F, 2.3226130220077557F};
            case "militar_camion" -> new float[]{4.0895680975442055F, 2.96875F, 2.625F, 3.0F, -2.875F, 2.125F, 0.46875F, 4.232500738334253F};
            case "militar_tanque" -> new float[]{2.9375F, 2.84375F, 2.754087641809737F, 2.84375F, -2.375F, 2.34375F, 0.34375F, 4.167317266914651F};
            case "militar_blindado" -> new float[]{3.871863573158154F, 3.290625F, 2.75F, 3.5025F, -2.25F, 1.5F, 0.53125F, 3.8844541159793646F};
            default -> throw new IllegalArgumentException(id);
        };
    }

    /** Los asientos: {x, z del modelo, altura de la cadera} en 1/16 de bloque. El primero es el del que maneja. */
    static float[][] asientos(String id) {
        return switch (id) {
            case "auto_convertible" -> new float[][]{{-2.0F, -7.5F, 11.4F}, {-2.0F, 7.5F, 11.4F}, {16.0F, -7.5F, 11.4F}, {16.0F, 7.5F, 11.4F}};
            case "auto_sedan" -> new float[][]{{-3.0F, -7.5F, 8.9F}, {-3.0F, 7.5F, 8.9F}, {15.0F, -7.5F, 8.9F}, {15.0F, 7.5F, 8.9F}};
            case "auto_antiguo" -> new float[][]{{-5.0F, -7.0F, 12.9F}, {-5.0F, 7.0F, 12.9F}, {13.0F, -7.0F, 12.9F}, {13.0F, 7.0F, 12.9F}};
            case "auto_compacto" -> new float[][]{{-1.0F, -6.0F, 8.4F}, {-1.0F, 6.0F, 8.4F}, {15.0F, -6.0F, 8.4F}, {15.0F, 6.0F, 8.4F}};
            case "auto_rural" -> new float[][]{{-3.0F, -7.5F, 8.9F}, {-3.0F, 7.5F, 8.9F}, {15.0F, -7.5F, 8.9F}, {15.0F, 7.5F, 8.9F}};
            case "moto_clasica" -> new float[][]{{3.0F, 0.0F, 17.4F}, {11.0F, 0.0F, 18.4F}};
            case "moto_scooter" -> new float[][]{{4.0F, 0.0F, 15.9F}, {11.5F, 0.0F, 16.4F}};
            case "moto_sidecar" -> new float[][]{{3.0F, 0.0F, 17.4F}, {11.0F, 0.0F, 18.4F}, {5.0F, 13.5F, 10.6F}};
            case "moto_ruta" -> new float[][]{{3.0F, 0.0F, 15.4F}, {11.0F, 0.0F, 17.4F}};
            case "moto_calle" -> new float[][]{{2.0F, 0.0F, 17.4F}, {10.0F, 0.0F, 17.4F}};
            case "camion_barandas" -> new float[][]{{-26.0F, -8.0F, 19.9F}, {-26.0F, 8.0F, 19.9F}};
            case "camion_cisterna" -> new float[][]{{-38.0F, -8.5F, 22.4F}, {-38.0F, 8.5F, 22.4F}};
            case "camion_bomberos" -> new float[][]{{-44.0F, -8.5F, 22.4F}, {-44.0F, 8.5F, 22.4F}, {-26.0F, -8.5F, 22.4F}, {-26.0F, 8.5F, 22.4F}};
            case "autobus" -> new float[][]{{-58.0F, -9.0F, 12.9F}, {-38.0F, -9.0F, 12.9F}, {-38.0F, 9.0F, 12.9F}, {-20.0F, -9.0F, 12.9F}, {-20.0F, 9.0F, 12.9F}, {-2.0F, -9.0F, 12.9F}, {-2.0F, 9.0F, 12.9F}, {32.0F, -9.0F, 12.9F}, {32.0F, 9.0F, 12.9F}, {50.0F, -9.0F, 12.9F}, {50.0F, 9.0F, 12.9F}};
            case "casa_rodante" -> new float[][]{{-28.0F, -7.5F, 13.9F}, {-28.0F, 7.5F, 13.9F}, {0.0F, -7.5F, 16.9F}, {0.0F, 7.5F, 16.9F}, {18.0F, -7.5F, 16.9F}, {18.0F, 7.5F, 16.9F}};
            case "camioneta_pickup" -> new float[][]{{-17.0F, -7.0F, 13.9F}, {-17.0F, 7.0F, 13.9F}};
            case "camioneta_doble_cabina" -> new float[][]{{-8.0F, -7.5F, 13.9F}, {-8.0F, 7.5F, 13.9F}, {10.0F, -7.5F, 13.9F}, {10.0F, 7.5F, 13.9F}};
            case "camioneta_furgon" -> new float[][]{{-11.0F, -7.5F, 12.9F}, {-11.0F, 7.5F, 12.9F}, {7.0F, -7.5F, 12.9F}, {7.0F, 7.5F, 12.9F}, {25.0F, -7.5F, 12.9F}, {25.0F, 7.5F, 12.9F}};
            case "camioneta_4x4" -> new float[][]{{-3.0F, -7.0F, 14.9F}, {-3.0F, 7.0F, 14.9F}, {15.0F, -7.0F, 14.9F}, {15.0F, 7.0F, 14.9F}};
            case "militar_jeep" -> new float[][]{{-1.0F, -6.5F, 12.9F}, {-1.0F, 6.5F, 12.9F}, {17.0F, -5.5F, 12.9F}, {17.0F, 5.5F, 12.9F}};
            case "militar_camion" -> new float[][]{{-24.0F, -8.0F, 19.9F}, {-24.0F, 8.0F, 19.9F}, {-2.0F, -8.5F, 23.9F}, {-2.0F, 8.5F, 23.9F}, {16.0F, -8.5F, 23.9F}, {16.0F, 8.5F, 23.9F}, {34.0F, -8.5F, 23.9F}, {34.0F, 8.5F, 23.9F}};
            case "militar_tanque" -> new float[][]{{-24.0F, -9.0F, 13.65F}, {8.0F, 0.0F, 24.15F}};
            case "militar_blindado" -> new float[][]{{-24.0F, -8.5F, 23.9F}, {-24.0F, 8.5F, 23.9F}, {2.0F, -9.0F, 23.9F}, {2.0F, 9.0F, 23.9F}, {20.0F, -9.0F, 23.9F}, {20.0F, 9.0F, 23.9F}, {38.0F, -9.0F, 23.9F}, {38.0F, 9.0F, 23.9F}, {9.0F, 0.0F, 38.15F}};
            default -> throw new IllegalArgumentException(id);
        };
    }

    /**
     * La torreta, o null: {x y z del eje de giro, alto del caño, x de la boca, x e y del muñón (donde sube y baja el
     * caño; NaN si no sube), asiento del tirador}, en 1/16 de bloque salvo el asiento.
     */
    static float[] torreta(String id) {
        return switch (id) {
            case "militar_tanque" -> new float[]{3.0F, 0.0F, 31.0F, -66.0F, -16.0F, 31.0F, 1.0F};
            case "militar_blindado" -> new float[]{8.0F, 0.0F, 53.0F, -9.5F, Float.NaN, Float.NaN, 8.0F};
            default -> null;
        };
    }
}
