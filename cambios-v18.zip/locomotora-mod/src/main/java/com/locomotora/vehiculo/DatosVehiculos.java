package com.locomotora.vehiculo;

/**
 * Medidas, asientos, torretas y orugas de los vehículos de calle (generado por el estudio de diseño junto con los
 * modelos). En el modelo el frente está hacia -x, la z va hacia la derecha del que maneja y la y es la altura sobre el
 * suelo.
 */
final class DatosVehiculos {
    private DatosVehiculos() {
    }

    /**
     * {frente, atrás, ancho, alto, eje delantero, eje trasero, radio de las ruedas, alcance} en bloques: cuánto
     * sobresale el casco hacia adelante y hacia atrás del centro (sin la torreta), su ancho y su alto (sin antenas ni
     * espejos), la x del modelo de los ejes de adelante y de atrás, el radio de la rueda más grande y hasta dónde llega
     * el modelo entero desde el centro (en planta, con la torreta y todo).
     */
    static float[] medidas(String id) {
        return switch (id) {
            case "auto_convertible" -> new float[]{2.8125F, 2.821875F, 2.25F, 1.59375F, -1.5625F, 1.5625F, 0.375F, 2.9261749776799064F};
            case "auto_sedan" -> new float[]{2.9375F, 2.978125F, 2.375F, 1.9379719627047558F, -1.6875F, 1.6875F, 0.375F, 3.087272258807117F};
            case "auto_antiguo" -> new float[]{2.6875F, 2.625F, 2.521875F, 2.125485285709567F, -1.6875F, 1.4375F, 0.4375F, 2.9134655052016663F};
            case "auto_compacto" -> new float[]{2.0625F, 2.0625F, 2.125F, 1.8941101192027026F, -1.1875F, 1.1875F, 0.3125F, 2.1830311495716224F};
            case "auto_rural" -> new float[]{2.9375F, 3.103125F, 2.375F, 2.25625F, -1.6875F, 1.75F, 0.375F, 3.204001404494074F};
            case "moto_clasica" -> new float[]{1.253523315309193F, 1.3156367734026484F, 1.0147456131094983F, 1.377474101265259F, -0.8125F, 0.8125F, 0.375F, 1.3265615797994452F};
            case "moto_scooter" -> new float[]{1.0713180149744386F, 1.15625F, 0.9446261919344282F, 1.28125F, -0.75F, 0.625F, 0.25F, 1.1745012239244368F};
            case "moto_sidecar" -> new float[]{1.253523315309193F, 1.3156367734026484F, 2.7685000000000004F, 1.377474101265259F, -0.8125F, 0.8125F, 0.375F, 1.4901250404556476F};
            case "moto_ruta" -> new float[]{1.4697850433854092F, 1.3126539226722234F, 1.175F, 1.6394106859920183F, -1.0625F, 0.875F, 0.375F, 1.4754954833599794F};
            case "moto_calle" -> new float[]{1.1390863205437247F, 1.0940555824579945F, 0.9972082786659657F, 1.3514921848239345F, -0.78125F, 0.71875F, 0.3125F, 1.145098491749112F};
            case "camion_barandas" -> new float[]{3.9375F, 2.96875F, 2.5625F, 2.6875F, -3.0F, 1.375F, 0.46875F, 4.112670969090526F};
            case "camion_cisterna" -> new float[]{3.5F, 3.1497899159663865F, 2.625F, 3.228125F, -2.75F, 2.25F, 0.46875F, 3.6959648604931297F};
            case "camion_bomberos" -> new float[]{3.75F, 2.96875F, 2.625F, 3.0625F, -3.0F, 1.5F, 0.46875F, 3.9335297443898907F};
            case "autobus" -> new float[]{4.531788595852826F, 4.625F, 2.503048286281502F, 3.0F, -3.0F, 2.25F, 0.5F, 4.7909419741842F};
            case "casa_rodante" -> new float[]{3.5F, 4.0F, 2.625F, 3.3125F, -2.5F, 2.375F, 0.4375F, 4.172547932618629F};
            case "camioneta_pickup" -> new float[]{3.3125F, 2.0F, 2.071875F, 2.2504852857095674F, -2.375F, 1.375F, 0.375F, 3.460152633916602F};
            case "camioneta_doble_cabina" -> new float[]{3.125F, 3.0F, 2.384375F, 2.2691896412892167F, -2.0F, 1.75F, 0.4375F, 3.321332563896606F};
            case "camioneta_furgon" -> new float[]{2.625F, 2.875F, 2.375F, 2.275478088363118F, -1.625F, 1.75F, 0.375F, 3.087272258807117F};
            case "camioneta_4x4" -> new float[]{2.5625F, 2.578125F, 2.4F, 3.025F, -1.5625F, 1.4375F, 0.4375F, 2.7164142265125912F};
            case "militar_jeep" -> new float[]{2.125F, 2.134375F, 2.131F, 1.75F, -1.375F, 1.125F, 0.40625F, 2.3226130220077557F};
            case "militar_camion" -> new float[]{4.0895680975442055F, 2.96875F, 2.625F, 3.0F, -2.875F, 2.125F, 0.46875F, 4.232500738334253F};
            case "militar_tanque" -> new float[]{2.9375F, 2.84375F, 2.7589922514564145F, 2.84375F, -2.375F, 2.34375F, 0.34375F, 4.167317266914651F};
            case "militar_blindado" -> new float[]{3.871863573158154F, 3.290625F, 2.75F, 3.5025F, -2.25F, 1.5F, 0.53125F, 3.8844541159793646F};
            default -> throw new IllegalArgumentException(id);
        };
    }

    /** Los asientos: {x, z del modelo, altura de la cadera} en 1/16 de bloque. El primero es el del que maneja. */
    static float[][] asientos(String id) {
        return switch (id) {
            case "auto_convertible" -> new float[][]{{-2.0F, -7.5F, 11.4F}, {-2.0F, 7.5F, 11.4F}, {16.0F, -7.5F, 11.4F}, {16.0F, 7.5F, 11.4F}};
            case "auto_sedan" -> new float[][]{{-3.0F, -7.5F, 8.9F}, {-3.0F, 7.5F, 8.9F}, {15.0F, -7.5F, 8.9F}, {15.0F, 7.5F, 8.9F}};
            case "auto_antiguo" -> new float[][]{{-5.0F, -7.0F, 12.9F}, {-5.0F, 7.0F, 12.9F}, {13.0F, -7.0F, 12.9F}, {13.0F, 7.0F, 12.9F}};
            case "auto_compacto" -> new float[][]{{-1.0F, -6.0F, 8.4F}, {-1.0F, 6.0F, 8.4F}, {15.0F, -6.0F, 8.4F}, {15.0F, 6.0F, 8.4F}};
            case "auto_rural" -> new float[][]{{-3.0F, -7.5F, 8.9F}, {-3.0F, 7.5F, 8.9F}, {15.0F, -7.5F, 8.9F}, {15.0F, 7.5F, 8.9F}};
            case "moto_clasica" -> new float[][]{{3.0F, 0.0F, 17.4F}, {11.0F, 0.0F, 18.4F}};
            case "moto_scooter" -> new float[][]{{4.0F, 0.0F, 15.9F}, {11.5F, 0.0F, 16.4F}};
            case "moto_sidecar" -> new float[][]{{3.0F, 0.0F, 17.4F}, {11.0F, 0.0F, 18.4F}, {5.0F, 13.5F, 10.6F}};
            case "moto_ruta" -> new float[][]{{3.0F, 0.0F, 15.4F}, {11.0F, 0.0F, 17.4F}};
            case "moto_calle" -> new float[][]{{2.0F, 0.0F, 17.4F}, {10.0F, 0.0F, 17.4F}};
            case "camion_barandas" -> new float[][]{{-26.0F, -8.0F, 19.9F}, {-26.0F, 8.0F, 19.9F}};
            case "camion_cisterna" -> new float[][]{{-38.0F, -8.5F, 22.4F}, {-38.0F, 8.5F, 22.4F}};
            case "camion_bomberos" -> new float[][]{{-44.0F, -8.5F, 22.4F}, {-44.0F, 8.5F, 22.4F}, {-26.0F, -8.5F, 22.4F}, {-26.0F, 8.5F, 22.4F}};
            case "autobus" -> new float[][]{{-58.0F, -9.0F, 12.9F}, {-38.0F, -9.0F, 12.9F}, {-38.0F, 9.0F, 12.9F}, {-20.0F, -9.0F, 12.9F}, {-20.0F, 9.0F, 12.9F}, {-2.0F, -9.0F, 12.9F}, {-2.0F, 9.0F, 12.9F}, {51.0F, -9.0F, 12.9F}, {51.0F, 9.0F, 12.9F}, {63.0F, -9.0F, 12.9F}, {63.0F, 9.0F, 12.9F}};
            case "casa_rodante" -> new float[][]{{-28.0F, -7.5F, 13.9F}, {-28.0F, 7.5F, 13.9F}, {0.0F, -7.5F, 16.9F}, {0.0F, 7.5F, 16.9F}, {18.0F, -7.5F, 16.9F}, {18.0F, 7.5F, 16.9F}};
            case "camioneta_pickup" -> new float[][]{{-17.0F, -7.0F, 13.9F}, {-17.0F, 7.0F, 13.9F}};
            case "camioneta_doble_cabina" -> new float[][]{{-8.0F, -7.5F, 13.9F}, {-8.0F, 7.5F, 13.9F}, {10.0F, -7.5F, 13.9F}, {10.0F, 7.5F, 13.9F}};
            case "camioneta_furgon" -> new float[][]{{-11.0F, -7.5F, 12.9F}, {-11.0F, 7.5F, 12.9F}, {7.0F, -7.5F, 12.9F}, {7.0F, 7.5F, 12.9F}, {25.0F, -7.5F, 12.9F}, {25.0F, 7.5F, 12.9F}};
            case "camioneta_4x4" -> new float[][]{{-3.0F, -7.0F, 14.9F}, {-3.0F, 7.0F, 14.9F}, {15.0F, -7.0F, 14.9F}, {15.0F, 7.0F, 14.9F}};
            case "militar_jeep" -> new float[][]{{-1.0F, -6.5F, 12.9F}, {-1.0F, 6.5F, 12.9F}, {17.0F, -5.5F, 12.9F}, {17.0F, 5.5F, 12.9F}};
            case "militar_camion" -> new float[][]{{-24.0F, -8.0F, 19.9F}, {-24.0F, 8.0F, 19.9F}, {-2.0F, -8.5F, 23.9F}, {-2.0F, 8.5F, 23.9F}, {16.0F, -8.5F, 23.9F}, {16.0F, 8.5F, 23.9F}, {34.0F, -8.5F, 23.9F}, {34.0F, 8.5F, 23.9F}};
            case "militar_tanque" -> new float[][]{{-24.0F, -9.0F, 13.65F}, {8.0F, 0.0F, 24.15F}};
            case "militar_blindado" -> new float[][]{{-24.0F, -8.5F, 23.9F}, {-24.0F, 8.5F, 23.9F}, {2.0F, -9.0F, 23.9F}, {2.0F, 9.0F, 23.9F}, {20.0F, -9.0F, 23.9F}, {20.0F, 9.0F, 23.9F}, {38.0F, -9.0F, 23.9F}, {38.0F, 9.0F, 23.9F}, {9.0F, 0.0F, 38.15F}};
            default -> throw new IllegalArgumentException(id);
        };
    }

    /**
     * La torreta, o null: {x y z del eje de giro, alto del caño, x de la boca, x e y del muñón (donde sube y baja el
     * caño; NaN si no sube), asiento del tirador}, en 1/16 de bloque salvo el asiento.
     */
    static float[] torreta(String id) {
        return switch (id) {
            case "militar_tanque" -> new float[]{3.0F, 0.0F, 31.0F, -66.0F, -16.0F, 31.0F, 1.0F};
            case "militar_blindado" -> new float[]{8.0F, 0.0F, 53.0F, -9.5F, Float.NaN, Float.NaN, 8.0F};
            default -> null;
        };
    }

    /**
     * El lazo por donde corren los eslabones de las orugas, o null: {x0, y0, x1, y1, ...} en 1/16 de bloque (x del
     * modelo, y = altura), dando la vuelta en el sentido en que avanzan los eslabones cuando el vehículo va hacia
     * adelante (por abajo hacia atrás, por arriba hacia adelante). El primer punto no se repite al final.
     */
    static float[] oruga(String id) {
        return switch (id) {
            case "militar_tanque" -> new float[]{
                    -37.8709F, 16.9987F, -38.3657F, 16.9897F, -38.8584F, 16.9431F, -39.3461F, 16.8591F,
                    -39.826F, 16.7383F, -40.2953F, 16.5813F, -40.7513F, 16.389F, -41.1913F, 16.1626F,
                    -41.6129F, 15.9034F, -42.0135F, 15.6129F, -42.3909F, 15.2927F, -42.7428F, 14.9448F,
                    -43.0672F, 14.5711F, -43.3622F, 14.1737F, -43.6262F, 13.7551F, -43.8575F, 13.3177F,
                    -44.0549F, 12.8638F, -44.2172F, 12.3963F, -44.3435F, 11.9178F, -44.433F, 11.4311F,
                    -44.4852F, 10.939F, -44.4998F, 10.4443F, -44.4767F, 9.95F, -44.4161F, 9.4588F,
                    -44.3183F, 8.9737F, -44.1838F, 8.4974F, -44.0136F, 8.0328F, -43.8084F, 7.5824F,
                    -43.5696F, 7.149F, -43.2985F, 6.7349F, -42.9967F, 6.3427F, -42.666F, 5.9746F,
                    -42.3081F, 5.6328F, -41.9254F, 5.3191F, -41.5198F, 5.0355F, -41.0939F, 4.7835F,
                    -40.65F, 4.5647F, -40.1908F, 4.3803F, -28.8537F, 0.3218F, -28.4024F, 0.1818F,
                    -27.9407F, 0.081F, -27.4721F, 0.0203F, -27.0F, 0.0F, 26.0F, 0.0F,
                    26.4034F, 0.0148F, 26.8047F, 0.0592F, 27.2016F, 0.1329F, 27.592F, 0.2355F,
                    39.2367F, 3.7569F, 39.7079F, 3.921F, 40.1638F, 4.1237F, 40.6012F, 4.3636F,
                    41.0173F, 4.639F, 41.409F, 4.9481F, 41.7736F, 5.2886F, 42.1088F, 5.6582F,
                    42.412F, 6.0544F, 42.6813F, 6.4744F, 42.9148F, 6.9153F, 43.1108F, 7.3742F,
                    43.268F, 7.8477F, 43.3853F, 8.3326F, 43.462F, 8.8256F, 43.4974F, 9.3233F,
                    43.4913F, 9.8222F, 43.4439F, 10.3188F, 43.3553F, 10.8098F, 43.2262F, 11.2918F,
                    43.0576F, 11.7613F, 42.8505F, 12.2152F, 42.6064F, 12.6504F, 42.327F, 13.0637F,
                    42.0142F, 13.4525F, 41.6702F, 13.8138F, 41.2974F, 14.1454F, 40.8983F, 14.4448F,
                    40.4757F, 14.7101F, 40.0326F, 14.9393F, 39.5719F, 15.1309F, 39.0969F, 15.2836F,
                    38.6109F, 15.3963F, 38.1172F, 15.4682F, 37.6192F, 15.4988F};
            default -> null;
        };
    }
}
