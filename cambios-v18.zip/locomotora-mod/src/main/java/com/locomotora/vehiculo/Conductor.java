package com.locomotora.vehiculo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import com.locomotora.generacion.Carreteras;
import com.locomotora.gente.Grupo;
import com.locomotora.gente.PersonaEntity;
import com.locomotora.mundo.Carretera;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.Difficulty;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

/**
 * El que maneja un vehículo del tránsito (alguien de la carretera al volante): lo lleva por su carril (el de la
 * derecha), frena si tiene algo adelante y decide qué hacer con los jugadores.
 * <ul>
 *   <li>Gente común: si te paras adelante, la mitad de las veces frena, te hace un cambio de luces y te da 10 segundos
 *       para moverte (si no te movés, te atropella); la otra mitad, te atropella sin frenar.</li>
 *   <li>Bandidos: si te ven cerca (20 bloques), te persiguen para atropellarte. Si se traban, se bajan y te tiran.</li>
 *   <li>Militares: si te ven cerca, paran, se bajan todos y te tiran. Cuando terminan, vuelven y siguen viaje.</li>
 * </ul>
 */
final class Conductor {
    enum Estado { CIRCULAR, FRENAR, AVISAR, ATROPELLAR, PERSEGUIR, DETENERSE, BAJADOS }

    /** A esta distancia (o menos) los bandidos y los militares te ven. */
    private static final double VISTA = 20.0;
    /** Lo que se mira hacia adelante para ver si hay alguien parado en el camino. */
    private static final double ADELANTE = 28.0;
    /** El aviso: 10 segundos para moverse. */
    private static final int AVISO = 200;

    private final VehiculoEntity v;
    Estado estado = Estado.CIRCULAR;
    @Nullable
    private UUID blanco;
    private int ticks;
    /** +1: va hacia el este (por el carril de +z); -1: hacia el oeste. */
    private int sentido;
    /** Lo que la gente común decidió con cada jugador: frenar (true) o atropellarlo (false). */
    private final Map<UUID, Boolean> decision = new HashMap<>();
    private int olvido;
    private int fuera;
    private int quieto;
    // para destrabarse
    private double refX;
    private double refZ;
    private int trabado;
    private int retroceso;
    private float volanteAtras;

    /** Lo que aprieta: acelerador (W/S) y volante (A/D), como un jugador. */
    float acelerador;
    float volante;

    Conductor(VehiculoEntity v) {
        this.v = v;
        this.sentido = v.frenteX() >= 0.0 ? 1 : -1;
        this.refX = v.getX();
        this.refZ = v.getZ();
    }

    private void cambiar(Estado e) {
        this.estado = e;
        this.ticks = 0;
        this.fuera = 0;
        this.quieto = 0;
    }

    void pensar(ServerLevel nivel, PersonaEntity chofer) {
        this.ticks++;
        if (++this.olvido > 2400) {
            this.olvido = 0;
            this.decision.clear();
        }
        if (Math.abs(this.v.frenteX()) > 0.5) {
            this.sentido = this.v.frenteX() > 0.0 ? 1 : -1;
        }
        Grupo g = chofer.grupo();
        boolean hostiles = g.hostil && nivel.getDifficulty() != Difficulty.PEACEFUL;
        switch (this.estado) {
            case CIRCULAR -> circular(nivel, chofer, g, hostiles);
            case FRENAR -> frenar(nivel, g);
            case AVISAR -> avisar(nivel);
            case ATROPELLAR -> atropellar(nivel);
            case PERSEGUIR -> perseguir(nivel);
            case DETENERSE -> detenerse(nivel);
            case BAJADOS -> bajados(nivel, chofer, g, hostiles);
        }
    }

    /** El vehículo fue atacado (o uno de los de adentro): los bandidos lo persiguen y los militares se bajan. */
    void alerta(LivingEntity atacante) {
        if (!(atacante instanceof Player p) || p.isCreative() || p.isSpectator()) {
            return;
        }
        if (!(this.v.getControllingPassenger() instanceof PersonaEntity chofer)
                || chofer.level().getDifficulty() == Difficulty.PEACEFUL) {
            return;
        }
        if (chofer.grupo() == Grupo.BANDIDO && this.estado != Estado.PERSEGUIR) {
            this.blanco = p.getUUID();
            cambiar(Estado.PERSEGUIR);
        } else if (chofer.grupo() == Grupo.MILITAR && this.estado != Estado.DETENERSE && this.estado != Estado.BAJADOS) {
            this.blanco = p.getUUID();
            cambiar(Estado.DETENERSE);
        }
    }

    // ================================================================= estados

    private void circular(ServerLevel nivel, PersonaEntity chofer, Grupo g, boolean hostiles) {
        if (hostiles) {
            Player p = objetivoDeLaGente();
            if (p == null) {
                p = jugadorCerca(nivel, chofer);
            }
            if (p != null) {
                this.blanco = p.getUUID();
                if (g == Grupo.BANDIDO) {
                    cambiar(Estado.PERSEGUIR);
                    this.v.tocarBocinaIA();
                } else {
                    cambiar(Estado.DETENERSE);
                }
                return;
            }
        } else {
            Player p = jugadorDelante(nivel);
            if (p != null) {
                boolean frena = this.decision.computeIfAbsent(p.getUUID(), k -> p.isCreative()
                        || nivel.getDifficulty() == Difficulty.PEACEFUL || !g.equals(Grupo.CIVIL)
                        || nivel.getRandom().nextBoolean());
                this.blanco = p.getUUID();
                cambiar(frena ? Estado.FRENAR : Estado.ATROPELLAR);
                return;
            }
        }
        carril(nivel, crucero(g), g != Grupo.BANDIDO);
        destrabar();
    }

    /** La gente común que decidió frenar: para unos bloques antes del jugador. */
    private void frenar(ServerLevel nivel, Grupo g) {
        Player p = blanco(nivel);
        if (p == null) {
            cambiar(Estado.CIRCULAR);
            return;
        }
        double a = adelanteDe(p);
        if (!enElCamino(p, ADELANTE + 6.0)) {
            if (++this.fuera > 20) {
                cambiar(Estado.CIRCULAR);
            }
        } else {
            this.fuera = 0;
        }
        float buscada = (float) Mth.clamp((a - this.v.getTipo().largoFrente() - 5.0) * 0.05, 0.0, crucero(g));
        carril(nivel, buscada, true);
        if (Math.abs(this.v.getVelocidad()) < 0.03F && a < this.v.getTipo().largoFrente() + 14.0) {
            cambiar(Estado.AVISAR);
            this.v.cambioDeLuces();
            this.v.tocarBocinaIA();
        }
    }

    /** Parado adelante del jugador: cambio de luces y 10 segundos para moverse. */
    private void avisar(ServerLevel nivel) {
        Player p = blanco(nivel);
        parar();
        if (p == null) {
            cambiar(Estado.CIRCULAR);
            return;
        }
        if (this.ticks == 6 || this.ticks == 12 || this.ticks == 18) {
            this.v.cambioDeLuces();
        }
        if (this.ticks == 100) {
            this.v.tocarBocinaIA();
            this.v.cambioDeLuces();
        }
        if (this.ticks % 20 == 1) {
            int s = Math.max(1, 10 - this.ticks / 20);
            p.displayClientMessage(Component.translatable("mensaje.locomotora.cambio_luces", s)
                    .withStyle(ChatFormatting.GOLD), true);
        }
        if (!enElCamino(p, ADELANTE + 6.0)) {
            if (++this.fuera > 30) {
                cambiar(Estado.CIRCULAR);
            }
            return;
        }
        this.fuera = 0;
        if (this.ticks >= AVISO) {
            cambiar(Estado.ATROPELLAR);
            this.v.tocarBocinaIA();
        }
    }

    /** Derecho al jugador, a fondo. */
    private void atropellar(ServerLevel nivel) {
        Player p = blanco(nivel);
        if (p == null || !p.isAlive() || this.ticks > 160 || adelanteDe(p) < -2.0 || distancia(p) > 40.0) {
            cambiar(Estado.CIRCULAR);
            return;
        }
        hacia(p.getX(), p.getZ(), this.v.getTipo().velocidadMaxima());
    }

    /** Los bandidos: tras el jugador a toda velocidad (si se traban, se bajan a pelear). */
    private void perseguir(ServerLevel nivel) {
        Player p = blanco(nivel);
        if (p == null || !p.isAlive() || p.isCreative() || p.isSpectator()) {
            cambiar(Estado.CIRCULAR);
            return;
        }
        if (distancia(p) > 48.0) {
            if (++this.fuera > 100) {
                cambiar(Estado.CIRCULAR);
                return;
            }
        } else {
            this.fuera = 0;
        }
        hacia(p.getX(), p.getZ(), this.v.getTipo().velocidadMaxima());
        if (Math.abs(this.v.getVelocidad()) < 0.04F) {
            if (++this.quieto > 60) {
                bajarTodos(p);
                cambiar(Estado.BAJADOS);
            }
        } else {
            this.quieto = 0;
        }
    }

    /** Los militares: frenan y, ya parados, se bajan todos a pelear. */
    private void detenerse(ServerLevel nivel) {
        Player p = blanco(nivel);
        parar();
        if (Math.abs(this.v.getVelocidad()) < 0.03F || this.ticks > 60) {
            bajarTodos(p);
            cambiar(Estado.BAJADOS);
        }
    }

    /** Volvieron a subir: esperan a los que faltan (hasta 30 segundos) y siguen viaje. */
    private void bajados(ServerLevel nivel, PersonaEntity chofer, Grupo g, boolean hostiles) {
        parar();
        if (hostiles) {
            Player p = objetivoDeLaGente();
            if (p == null) {
                p = jugadorCerca(nivel, chofer);
            }
            if (p != null && this.ticks > 20) {
                this.blanco = p.getUUID();
                bajarTodos(p);
                this.ticks = 0;
                return;
            }
        }
        UUID id = this.v.getUUID();
        List<PersonaEntity> afuera = nivel.getEntitiesOfClass(PersonaEntity.class, this.v.getBoundingBox().inflate(48.0),
                q -> id.equals(q.getVehiculo()) && !q.isPassenger() && q.isAlive());
        if (afuera.isEmpty() || this.ticks > 600 || !this.v.hayLugarParaNPC()) {
            cambiar(Estado.CIRCULAR);
        }
    }

    // ================================================================= manejar

    private float crucero(Grupo g) {
        float max = this.v.getTipo().velocidadMaxima();
        return g == Grupo.BANDIDO ? Math.min(0.85F, max * 0.9F) : Math.min(0.62F, max * 0.7F);
    }

    /** Por el carril de la derecha de la carretera más cercana, a esa rapidez (frenando si hay algo adelante). */
    private void carril(ServerLevel nivel, float rapidez, boolean cuidar) {
        Carretera c = Carreteras.de(nivel);
        int fila = Carretera.fila(this.v.getZ());
        double[] l = c.lugar(fila, this.v.getX(), this.v.getZ());
        if (Math.abs(l[0]) > 60.0) {
            // lejos de toda carretera: no sabe adónde ir
            parar();
            return;
        }
        double adelante = 5.0 + 9.0 * Math.abs(this.v.getVelocidad()) + this.v.getTipo().largoFrente();
        double x = l[1] + this.sentido * adelante;
        double zm = c.centro(fila, x);
        double p = c.pendiente(fila, x);
        double n = Math.sqrt(1.0 + p * p);
        double d = Carretera.CARRIL * this.sentido;
        float buscada = rapidez;
        if (cuidar) {
            buscada = Math.min(buscada, libreAdelante(nivel));
        }
        hacia(x - d * p / n, zm + d / n, buscada);
    }

    /** Dobla hacia el punto (como un jugador con A y D) y acelera o frena hasta ir a esa rapidez. */
    private void hacia(double tx, double tz, float rapidez) {
        double hx = this.v.frenteX();
        double hz = this.v.frenteZ();
        double wx = tx - this.v.getX();
        double wz = tz - this.v.getZ();
        double f = wx * hx + wz * hz;
        double lat = -wx * hz + wz * hx;
        double alfa = Math.atan2(lat, f);
        TipoVehiculo t = this.v.getTipo();
        if (t.oruga()) {
            this.volante = (float) Mth.clamp(-alfa * 3.0, -1.0, 1.0);
        } else {
            double dist = Math.max(1.0, Math.sqrt(wx * wx + wz * wz));
            double delta = Math.atan(2.0 * t.distanciaEjes() * Math.sin(alfa) / dist);
            float limite = t.giroMaximo() / (1.0F + 2.0F * Math.abs(this.v.getVelocidad()));
            this.volante = (float) Mth.clamp(-delta / limite, -1.0, 1.0);
            if (f < 0.0) {
                this.volante = alfa > 0.0 ? -1.0F : 1.0F;
            }
        }
        if (Math.abs(alfa) > 0.7) {
            rapidez = Math.min(rapidez, 0.3F);
        }
        acelerar(rapidez);
    }

    private void acelerar(float buscada) {
        float vel = this.v.getVelocidad();
        if (vel < buscada - 0.015F) {
            this.acelerador = 1.0F;
        } else if (vel > buscada + 0.04F) {
            this.acelerador = -1.0F;
        } else {
            this.acelerador = 0.0F;
        }
        // frenar nunca lo pone en marcha atrás
        if (this.acelerador < 0.0F && vel <= 0.02F) {
            this.acelerador = 0.0F;
        }
    }

    private void parar() {
        this.volante = 0.0F;
        acelerar(0.0F);
    }

    /** Si apretando el acelerador no avanza (se trabó contra algo), da marcha atrás un poco doblando. */
    private void destrabar() {
        if (this.retroceso > 0) {
            this.retroceso--;
            this.acelerador = -1.0F;
            this.volante = this.volanteAtras;
            return;
        }
        if (this.acelerador > 0.5F) {
            if (++this.trabado >= 60) {
                double dx = this.v.getX() - this.refX;
                double dz = this.v.getZ() - this.refZ;
                if (dx * dx + dz * dz < 0.36) {
                    this.retroceso = 30;
                    this.volanteAtras = this.v.level().getRandom().nextBoolean() ? 1.0F : -1.0F;
                }
                this.trabado = 0;
                this.refX = this.v.getX();
                this.refZ = this.v.getZ();
            }
        } else {
            this.trabado = 0;
            this.refX = this.v.getX();
            this.refZ = this.v.getZ();
        }
    }

    /** Hasta qué rapidez puede ir según lo que tiene adelante (otro vehículo, un animal...): frena a tiempo. */
    private float libreAdelante(ServerLevel nivel) {
        TipoVehiculo t = this.v.getTipo();
        double alcance = 16.0 + t.largoFrente();
        double hx = this.v.frenteX();
        double hz = this.v.frenteZ();
        AABB zona = this.v.getBoundingBox().inflate(alcance, 2.0, alcance);
        double mejor = Double.MAX_VALUE;
        for (Entity e : nivel.getEntities(this.v, zona, e -> e.isAlive()
                && (e instanceof VehiculoEntity || (e instanceof LivingEntity && !(e instanceof Player)))
                && e.getRootVehicle() != this.v && !(e.getVehicle() instanceof VehiculoEntity))) {
            double wx = e.getX() - this.v.getX();
            double wz = e.getZ() - this.v.getZ();
            double a = wx * hx + wz * hz;
            double l = -wx * hz + wz * hx;
            double suyo = e instanceof VehiculoEntity o ? o.getTipo().anchoModelo() / 2.0 : e.getBbWidth() / 2.0;
            if (a > 0.0 && Math.abs(l) < t.anchoModelo() / 2.0 + suyo + 0.3) {
                double atras = e instanceof VehiculoEntity o ? o.getTipo().largoAtras() : e.getBbWidth() / 2.0;
                mejor = Math.min(mejor, a - t.largoFrente() - atras);
            }
        }
        // los jugadores que van en otro vehículo cuentan como ese vehículo; los de a pie, aparte
        if (mejor == Double.MAX_VALUE) {
            return Float.MAX_VALUE;
        }
        return (float) Mth.clamp((mejor - 3.0) * 0.06, 0.0, 10.0);
    }

    // ================================================================= los jugadores

    @Nullable
    private Player blanco(ServerLevel nivel) {
        return this.blanco == null ? null : nivel.getPlayerByUUID(this.blanco);
    }

    private double adelanteDe(Entity e) {
        return (e.getX() - this.v.getX()) * this.v.frenteX() + (e.getZ() - this.v.getZ()) * this.v.frenteZ();
    }

    private double costadoDe(Entity e) {
        return -(e.getX() - this.v.getX()) * this.v.frenteZ() + (e.getZ() - this.v.getZ()) * this.v.frenteX();
    }

    private double distancia(Entity e) {
        double dx = e.getX() - this.v.getX();
        double dz = e.getZ() - this.v.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }

    /** ¿Está parado en el camino, adelante (a menos de {@code alcance})? */
    private boolean enElCamino(Player p, double alcance) {
        double a = adelanteDe(p);
        return a > this.v.getTipo().largoFrente() - 0.8 && a < alcance && Math.abs(p.getY() - this.v.getY()) < 4.0
                && Math.abs(costadoDe(p)) < this.v.getTipo().anchoModelo() / 2.0 + 1.0;
    }

    /** El jugador a pie más cercano que está parado en el camino, adelante. */
    @Nullable
    private Player jugadorDelante(ServerLevel nivel) {
        Player mejor = null;
        double ma = ADELANTE;
        for (Player p : nivel.players()) {
            if (p.isSpectator() || !p.isAlive() || p.isPassenger()) {
                continue;
            }
            if (enElCamino(p, ma)) {
                ma = adelanteDe(p);
                mejor = p;
            }
        }
        return mejor;
    }

    /** El jugador más cercano que ven (a menos de 20 bloques; sin contar los de creativo). */
    @Nullable
    private Player jugadorCerca(ServerLevel nivel, PersonaEntity chofer) {
        Player mejor = null;
        double md = VISTA * VISTA;
        for (Player p : nivel.players()) {
            if (p.isSpectator() || p.isCreative() || !p.isAlive() || p.getRootVehicle() == this.v) {
                continue;
            }
            double d = p.distanceToSqr(this.v);
            if (d < md && chofer.hasLineOfSight(p)) {
                md = d;
                mejor = p;
            }
        }
        return mejor;
    }

    /** El jugador al que le quiere tirar alguien de adentro (si lo atacó a él). */
    @Nullable
    private Player objetivoDeLaGente() {
        for (Entity e : this.v.getPassengers()) {
            if (e instanceof PersonaEntity q && q.getTarget() instanceof Player p && p.isAlive() && !p.isCreative()
                    && !p.isSpectator()) {
                return p;
            }
        }
        return null;
    }

    /** Se bajan todos los armados y van por el jugador. */
    private void bajarTodos(@Nullable Player p) {
        for (Entity e : List.copyOf(this.v.getPassengers())) {
            if (e instanceof PersonaEntity q && q.grupo().hostil) {
                q.stopRiding();
                if (p != null) {
                    q.setTarget(p);
                }
            }
        }
    }
}
