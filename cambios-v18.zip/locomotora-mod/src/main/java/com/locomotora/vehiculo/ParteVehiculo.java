package com.locomotora.vehiculo;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerEntity;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * Un tramo de un vehículo largo (un auto mide hasta 6 bloques, el autobús 9, y su caja de choque apenas el ancho), para
 * poder hacerle clic en cualquier parte. Lo que le pase a un tramo (clic derecho, golpes) le pasa al vehículo. No se
 * guarda ni se manda a los clientes: cada lado arma los suyos.
 */
public class ParteVehiculo extends PartEntity<VehiculoEntity> {
    private final EntityDimensions medida;

    public ParteVehiculo(VehiculoEntity vehiculo, float ancho, float alto) {
        super(vehiculo);
        this.medida = EntityDimensions.scalable(ancho, alto);
        this.refreshDimensions();
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder datos) {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    /** Se le puede apuntar, salvo desde adentro del mismo vehículo (si no, el que va sentado no podría apuntar a nada). */
    @Override
    public boolean isPickable() {
        VehiculoEntity v = this.getParent();
        if (v.isRemoved()) {
            return false;
        }
        return !(this.level().isClientSide() && com.locomotora.cliente.Local.vaEn(v));
    }

    @Override
    public boolean canBeHitByProjectile() {
        return !this.getParent().isRemoved();
    }

    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        return !this.isInvulnerableTo(fuente) && this.getParent().hurt(fuente, cantidad);
    }

    @Override
    public InteractionResult interact(Player jugador, InteractionHand mano) {
        return this.getParent().interact(jugador, mano);
    }

    /** El clic con el lugar donde se hizo: el vehículo elige el asiento más cercano a ese punto. */
    @Override
    public InteractionResult interactAt(Player jugador, Vec3 donde, InteractionHand mano) {
        VehiculoEntity v = this.getParent();
        return v.interactAt(jugador, donde.add(this.position()).subtract(v.position()), mano);
    }

    @Override
    public ItemStack getPickResult() {
        return this.getParent().getPickResult();
    }

    @Override
    public boolean is(Entity otra) {
        return this == otra || this.getParent() == otra;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket(ServerEntity entidad) {
        throw new UnsupportedOperationException();
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return this.medida;
    }

    @Override
    public boolean shouldBeSaved() {
        return false;
    }
}
