package com.locomotora.generacion;

import java.util.Map;
import java.util.WeakHashMap;

import com.locomotora.mundo.Carretera;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.RandomState;

/** Las carreteras de cada mundo (una por nivel; se arman la primera vez que se piden). */
public final class Carreteras {
    private static final Map<ServerLevel, Carretera> CARRETERAS = new WeakHashMap<>();

    private Carreteras() {
    }

    public static Carretera de(ServerLevel nivel) {
        synchronized (CARRETERAS) {
            Carretera c = CARRETERAS.get(nivel);
            if (c == null) {
                ChunkGenerator generador = nivel.getChunkSource().getGenerator();
                RandomState azar = nivel.getChunkSource().randomState();
                TerrenoMC terreno = new TerrenoMC(generador, azar, nivel);
                c = new Carretera(nivel.getSeed(), terreno, new AldeasMC(nivel, terreno));
                CARRETERAS.put(nivel, c);
            }
            return c;
        }
    }
}
