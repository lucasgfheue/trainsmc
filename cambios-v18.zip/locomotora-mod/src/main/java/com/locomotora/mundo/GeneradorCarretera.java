package com.locomotora.mundo;

/**
 * Pone en un chunk lo que le toca de la carretera: el asfalto con sus líneas (la amarilla discontinua al medio y las
 * blancas a los costados, que siguen las curvas), las banquinas, los terraplenes y los cortes con sus taludes, los
 * puentes de hormigón con baranda y pilares, y los túneles revestidos y con luces. Escribe en su chunk y, para sacar
 * ramas de árboles que se metieron sobre la carretera, también en los 8 vecinos.
 */
public final class GeneradorCarretera {
    public static final String AIRE = Bloque.AIRE;
    public static final String ASFALTO = "locomotora:asfalto";
    public static final String LINEA_BLANCA = "locomotora:linea_blanca";
    public static final String LINEA_AMARILLA = "locomotora:linea_amarilla";
    public static final String HORMIGON = "locomotora:hormigon";
    public static final String BARANDA = "locomotora:baranda";
    public static final String LUZ = "minecraft:sea_lantern";
    public static final String ROCA = "minecraft:stone";
    /** Ancho de la raya (en téxeles de 16 por bloque): igual que en las texturas. */
    private static final double ANCHO_RAYA = 2.6;
    /** Las rayas de la línea amarilla: 3 bloques pintados y 3 sin pintar. */
    private static final int TRAZO = 3;
    /** Cada cuántos bloques hay un pilar bajo el puente (de 2 de ancho). */
    private static final int ENTRE_PILARES = 16;
    /** Cada cuántos bloques hay una luz en el túnel. */
    private static final int ENTRE_LUCES = 8;

    private GeneradorCarretera() {
    }

    /** ¿La carretera de esa fila llega (con sus taludes) a la franja de z entre z0 y z1? */
    public static boolean toca(int fila, int z0, int z1) {
        int b = Carretera.borde(fila);
        double margen = Carretera.MEDIO + Carretera.TALUD + 3;
        return z1 >= b + Carretera.DESVIO_MIN - margen && z0 <= b + Carretera.DESVIO_MAX + margen;
    }

    public static void generar(Carretera c, Mundo m, int chunkX, int chunkZ) {
        int x0 = chunkX << 4;
        int z0 = chunkZ << 4;
        int fila = Carretera.fila(z0 + 8);
        if (toca(fila, z0, z0 + 15)) {
            chunk(c, m, fila, x0, z0);
        }
        if (toca(fila, z0 - 16, z0 + 31)) {
            arbolesVecinos(c, m, fila, chunkX, chunkZ);
        }
    }

    // ================================================================= el chunk

    private static void chunk(Carretera c, Mundo m, int fila, int x0, int z0) {
        // distancia al centro (con signo) y x del pie, para el chunk y un borde de un bloque
        double[] d = new double[18 * 18];
        double[] pie = new double[18 * 18];
        double[] zm = new double[18];
        double[] pend = new double[18];
        for (int ix = -1; ix <= 16; ix++) {
            double xc = x0 + ix + 0.5;
            zm[ix + 1] = c.centro(fila, xc);
            pend[ix + 1] = c.pendiente(fila, xc);
            double norma = Math.sqrt(1.0 + pend[ix + 1] * pend[ix + 1]);
            for (int iz = -1; iz <= 16; iz++) {
                double dd = (z0 + iz + 0.5 - zm[ix + 1]) / norma;
                d[(ix + 1) * 18 + iz + 1] = dd;
                pie[(ix + 1) * 18 + iz + 1] = xc + dd * pend[ix + 1] / norma;
            }
        }
        for (int ix = 0; ix < 16; ix++) {
            for (int iz = 0; iz < 16; iz++) {
                int i = (ix + 1) * 18 + iz + 1;
                double s = Math.abs(d[i]) - Carretera.MEDIO;
                if (s > Carretera.TALUD) {
                    continue;
                }
                int x = x0 + ix;
                int z = z0 + iz;
                int xf = (int) Math.floor(pie[i]);
                int alto = c.alto(fila, xf);
                byte modo = c.modo(fila, xf);
                if (s <= 0.0) {
                    String marca = marca(x, x + 0.5, z + 0.5, zm[ix + 1], pend[ix + 1]);
                    via(m, x, z, alto, modo, marca, xf, Math.abs(d[i]));
                } else if (borde(d, ix, iz)) {
                    borde(c, m, fila, x, z, alto, modo, xf);
                } else {
                    talud(m, x, z, alto, modo, Math.max(1, (int) Math.floor(s)));
                }
            }
        }
    }

    /** ¿Algún vecino (también en diagonal) es de la carretera? */
    private static boolean borde(double[] d, int ix, int iz) {
        for (int a = -1; a <= 1; a++) {
            for (int b = -1; b <= 1; b++) {
                if ((a != 0 || b != 0) && Math.abs(d[(ix + 1 + a) * 18 + iz + 1 + b]) <= Carretera.MEDIO) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Lo que se pinta en un bloque de la carretera: null (asfalto) o el id de la línea con su ángulo y posición (sin la
     * losa). La raya va en una de 8 direcciones (de a 22,5°) y corrida de a 1/8 de bloque, así sigue las curvas.
     */
    static String marca(int x, double xc, double zc, double zm, double pend) {
        double norma = Math.sqrt(1.0 + pend * pend);
        double ang = Math.toDegrees(Math.atan(pend));
        if (ang < 0.0) {
            ang += 180.0;
        }
        int a = (int) Math.round(ang / 22.5) % 8;
        double phi = Math.toRadians(a * 22.5);
        double nx = -Math.sin(phi);
        double nz = Math.cos(phi);
        double alcance = 0.5 * (Math.abs(nx) + Math.abs(nz)) + ANCHO_RAYA / 32.0;
        for (int l = 0; l < 3; l++) {
            double linea = l == 0 ? 0.0 : (l == 1 ? -4.0 : 4.0);
            double qx = xc - pend / norma * linea;
            double qz = zm + linea / norma;
            double off = (qx - xc) * nx + (qz - zc) * nz;
            if (Math.abs(off) < alcance) {
                if (l == 0 && Math.floorMod(Math.floorDiv(x, TRAZO), 2) == 1) {
                    return null;
                }
                int pos = (int) Math.round((off + 0.6875) / 0.125);
                pos = Math.max(0, Math.min(11, pos));
                return (l == 0 ? LINEA_AMARILLA : LINEA_BLANCA) + "[angulo=" + a + ",pos=" + pos + ",";
            }
        }
        return null;
    }

    private static String firme(String marca, boolean losa) {
        return (marca == null ? ASFALTO + "[" : marca) + "losa=" + losa + "]";
    }

    /** Un bloque de la carretera: el firme (con su losa si va a media altura), lo de arriba libre y lo de abajo. */
    private static void via(Mundo m, int x, int z, int alto, byte modo, String marca, int xf, double d) {
        int piso = alto >> 1;
        boolean losa = (alto & 1) != 0;
        int libre = losa ? piso + 1 : piso;
        if (modo == Carretera.TUNEL) {
            for (int y = libre; y < piso + Carretera.ALTO_LIBRE; y++) {
                limpiar(m, x, y, z);
            }
            boolean luz = Math.floorMod(xf, ENTRE_LUCES) == 0 && Math.abs(d - 2.5) < 0.75;
            m.poner(x, piso + Carretera.ALTO_LIBRE, z, luz ? LUZ : HORMIGON);
        } else {
            despejar(m, x, z, libre);
        }
        if (losa) {
            m.poner(x, piso - 1, z, firme(null, false));
            m.poner(x, piso, z, firme(marca, true));
        } else {
            m.poner(x, piso - 1, z, firme(marca, false));
        }
        if (modo == Carretera.PUENTE) {
            m.poner(x, piso - 2, z, HORMIGON);
            if (Math.floorMod(xf, ENTRE_PILARES) < 2) {
                pilar(m, x, z, piso - 3);
            }
        } else {
            rellenarDebajo(m, x, z, piso - 2, modo == Carretera.TUNEL);
        }
    }

    /** El costado de la carretera: banquina, el borde del puente con su baranda o la pared del túnel. */
    private static void borde(Carretera c, Mundo m, int fila, int x, int z, int alto, byte modo, int xf) {
        int piso = alto >> 1;
        switch (modo) {
            case Carretera.PUENTE -> {
                despejar(m, x, z, piso);
                m.poner(x, piso - 1, z, HORMIGON);
                m.poner(x, piso - 2, z, HORMIGON);
                if (Math.floorMod(xf, ENTRE_PILARES) < 2) {
                    pilar(m, x, z, piso - 3);
                }
                m.poner(x, piso, z, baranda(c, fila, x, z, piso));
            }
            case Carretera.TUNEL -> {
                boolean luz = Math.floorMod(xf, ENTRE_LUCES) == 0;
                for (int y = piso - 1; y <= piso + Carretera.ALTO_LIBRE; y++) {
                    m.poner(x, y, z, luz && y == piso + 2 ? LUZ : HORMIGON);
                }
            }
            default -> {
                despejar(m, x, z, piso);
                rellenarHasta(m, x, z, piso - 1);
                pasto(m, x, z, piso - 1);
            }
        }
    }

    /** Más allá del borde: los taludes del terraplén (hacia abajo) y del corte (hacia arriba), a 45°. */
    private static void talud(Mundo m, int x, int z, int alto, byte modo, int k) {
        if (modo == Carretera.TUNEL) {
            return;
        }
        int piso = alto >> 1;
        cortar(m, x, z, piso + k, piso + Carretera.TALUD + 6);
        if (modo != Carretera.PUENTE) {
            rellenarHasta(m, x, z, piso - 1 - k);
        }
    }

    // ================================================================= la baranda

    /** La baranda en el borde del puente, unida con las de al lado (las que están a la misma altura). */
    private static String baranda(Carretera c, int fila, int x, int z, int piso) {
        return BARANDA + "[east=" + hayBaranda(c, fila, x + 1, z, piso)
                + ",north=" + hayBaranda(c, fila, x, z - 1, piso)
                + ",south=" + hayBaranda(c, fila, x, z + 1, piso)
                + ",waterlogged=false,west=" + hayBaranda(c, fila, x - 1, z, piso) + "]";
    }

    private static boolean esVia(Carretera c, int fila, int x, int z) {
        return Math.abs(c.lugar(fila, x + 0.5, z + 0.5)[0]) <= Carretera.MEDIO;
    }

    private static boolean hayBaranda(Carretera c, int fila, int x, int z, int piso) {
        if (esVia(c, fila, x, z)) {
            return false;
        }
        boolean junto = false;
        for (int a = -1; a <= 1 && !junto; a++) {
            for (int b = -1; b <= 1 && !junto; b++) {
                junto = (a != 0 || b != 0) && esVia(c, fila, x + a, z + b);
            }
        }
        if (!junto) {
            return false;
        }
        int xf = (int) Math.floor(c.lugar(fila, x + 0.5, z + 0.5)[1]);
        return c.modo(fila, xf) == Carretera.PUENTE && (c.alto(fila, xf) >> 1) == piso;
    }

    // ================================================================= los árboles de los vecinos

    /** Ramas y troncos de los árboles de los chunks vecinos que quedaron sobre la carretera. */
    private static void arbolesVecinos(Carretera c, Mundo m, int fila, int chunkX, int chunkZ) {
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) {
                    continue;
                }
                int x0 = (chunkX + dx) << 4;
                int z0 = (chunkZ + dz) << 4;
                if (!toca(fila, z0, z0 + 15)) {
                    continue;
                }
                for (int ix = 0; ix < 16; ix++) {
                    int x = x0 + ix;
                    for (int iz = 0; iz < 16; iz++) {
                        int z = z0 + iz;
                        double[] l = c.lugar(fila, x + 0.5, z + 0.5);
                        if (Math.abs(l[0]) > Carretera.MEDIO + 1.5) {
                            continue;
                        }
                        int xf = (int) Math.floor(l[1]);
                        if (c.modo(fila, xf) == Carretera.TUNEL) {
                            continue;
                        }
                        int piso = c.alto(fila, xf) >> 1;
                        int cima = m.cima(x, z);
                        for (int y = piso; y <= cima; y++) {
                            if (m.tipo(x, y, z) == Mundo.ARBOL) {
                                m.poner(x, y, z, AIRE);
                            }
                        }
                    }
                }
            }
        }
    }

    // ================================================================= ayudas

    private static void limpiar(Mundo m, int x, int y, int z) {
        if (m.tipo(x, y, z) != Mundo.AIRE) {
            m.poner(x, y, z, AIRE);
        }
    }

    /** Todo lo que hay de {@code y0} para arriba (también los árboles y el cerro, que queda cortado). */
    private static void despejar(Mundo m, int x, int z, int y0) {
        int cima = m.cima(x, z);
        for (int y = y0; y <= cima; y++) {
            limpiar(m, x, y, z);
        }
    }

    /** Primer bloque firme bajo y0 (inclusive). */
    private static int suelo(Mundo m, int x, int z, int y0) {
        int g = y0;
        int limite = Math.max(m.minY(), y0 - 120);
        while (g > limite && m.tipo(x, g, z) != Mundo.SOLIDO) {
            g--;
        }
        return g;
    }

    /** Bajo la carretera: tierra (o roca, en el túnel) hasta el suelo, si el hueco no es muy hondo. */
    private static void rellenarDebajo(Mundo m, int x, int z, int tope, boolean roca) {
        int g = suelo(m, x, z, tope);
        if (g >= tope || tope - g > 24) {
            return;
        }
        String mat = roca ? ROCA : Generador.relleno(m.id(x, g, z))[1];
        for (int y = g + 1; y <= tope; y++) {
            m.poner(x, y, z, mat);
        }
    }

    /** El pilar del puente: hormigón hasta el suelo (también bajo el agua). */
    private static void pilar(Mundo m, int x, int z, int tope) {
        int g = suelo(m, x, z, tope);
        for (int y = g + 1; y <= tope; y++) {
            m.poner(x, y, z, HORMIGON);
        }
    }

    /** Rellena la columna desde el suelo hasta {@code tope} (con pasto o lo que haya arriba del lugar). */
    private static void rellenarHasta(Mundo m, int x, int z, int tope) {
        int g = suelo(m, x, z, tope);
        if (g >= tope) {
            return;
        }
        String[] mat = Generador.relleno(m.id(x, g, z));
        for (int y = g + 1; y < tope; y++) {
            m.poner(x, y, z, mat[1]);
        }
        m.poner(x, tope, z, mat[0]);
        if (m.tipo(x, tope + 1, z) == Mundo.PLANTA) {
            m.poner(x, tope + 1, z, AIRE);
        }
        if (Bloque.id(mat[0]).equals("minecraft:grass_block") && m.id(x, g, z).equals("minecraft:grass_block")) {
            m.poner(x, g, z, "minecraft:dirt");
        }
    }

    /** Si arriba quedó tierra pelada (después de cortar), vuelve a ser pasto. */
    private static void pasto(Mundo m, int x, int z, int y) {
        String id = m.id(x, y, z);
        if ((id.equals("minecraft:dirt") || id.equals("minecraft:coarse_dirt")) && m.tipo(x, y + 1, z) == Mundo.AIRE) {
            m.poner(x, y, z, "minecraft:grass_block[snowy=false]");
        }
    }

    /** Talud de un corte: saca lo que haya de {@code desde} para arriba (si no es una montaña) y deja pasto. */
    private static void cortar(Mundo m, int x, int z, int desde, int maximo) {
        int cima = m.cima(x, z);
        if (cima < desde) {
            return;
        }
        int tierra = cima;
        while (tierra >= desde && m.tipo(x, tierra, z) != Mundo.SOLIDO) {
            tierra--;
        }
        if (tierra > maximo) {
            return;
        }
        for (int y = desde; y <= cima; y++) {
            limpiar(m, x, y, z);
        }
        if (tierra >= desde) {
            pasto(m, x, z, desde - 1);
        }
    }
}
