package com.locomotora.mundo;

import java.util.Arrays;

/**
 * Las carreteras del mundo. Hay una por cada borde entre dos filas de regiones (cada 544 bloques en z), de oeste a
 * este y sin fin: no van a ningún lado, simplemente están. Corren por la franja que dejan libre las vías de las dos
 * filas (que siempre van a más de 96 bloques del borde), así nunca se cruzan con un tren.
 * <p>
 * El trazado sale de puntos de control cada {@link #PASO} bloques en x: en cada uno el centro de la carretera queda
 * corrido en z (al azar, pero lejos de las aldeas) y entre dos puntos va en una S suave. La altura sigue el terreno
 * de a media losa, con pendientes suaves (programación dinámica, como las vías): donde el terreno baja mucho o hay
 * agua va en puente, donde sube va en corte y, si el cerro es alto, en túnel.
 * <p>
 * Todo sale de la semilla y del terreno que va a tener el mundo: cada chunk calcula lo mismo sin importar en qué
 * orden se genere. El tránsito usa el mismo trazado para saber por dónde manejar.
 */
public final class Carretera {
    public static final int REGION = Red.REGION;
    /** Cada cuántos bloques (en x) hay un punto de control del trazado. */
    public static final int PASO = 192;
    /** El centro va entre estos corrimientos del borde de las filas (en z). */
    public static final int DESVIO_MIN = -64;
    public static final int DESVIO_MAX = 48;
    public static final int PASO_Z = 8;
    /** Media carretera: 9 bloques de ancho. */
    public static final double MEDIO = 4.5;
    /** El centro de cada carril, a cada lado de la línea amarilla. */
    public static final double CARRIL = 2.0;
    /** Bloques libres sobre la carretera (pasa el autobús). */
    public static final int ALTO_LIBRE = 5;
    /** Hasta dónde llegan los taludes de los terraplenes y los cortes, más allá del borde. */
    public static final int TALUD = 12;
    /** La carretera nunca va a menos de esto sobre el nivel del mar (deja pasar botes bajo los puentes). */
    public static final int SOBRE_MAR = 3;
    /** La carretera pasa a esto (o más) del centro de una aldea. */
    private static final int LEJOS_DE_ALDEA = 86;
    /** Las aldeas que están a menos de esto en x de un punto de control lo corren. */
    private static final int ALDEA_EN_X = 230;

    // cómo va la carretera en cada lugar
    public static final byte LLANO = 0;
    public static final byte TERRAPLEN = 1;
    public static final byte PUENTE = 2;
    public static final byte CORTE = 3;
    public static final byte TUNEL = 4;

    private final long semilla;
    private final Terreno terreno;
    private final Aldeas aldeas;
    private final boolean conAldeas;
    /** {z del centro, altura} de cada punto de control. */
    private final Memo<int[]> puntos = new Memo<>(8192);
    private final Memo<Tramo> tramos = new Memo<>(512);

    public Carretera(long semilla, Terreno terreno, Aldeas aldeas) {
        this.semilla = semilla;
        this.terreno = terreno;
        this.aldeas = aldeas;
        this.conAldeas = aldeas != null && aldeas.region() == REGION;
    }

    public Terreno terreno() {
        return this.terreno;
    }

    private static long clave(int a, int b) {
        return ((long) a << 32) | (b & 0xFFFFFFFFL);
    }

    /** La fila de la carretera más cercana a esta z (la carretera de la fila f va cerca de z = f · 544). */
    public static int fila(double z) {
        return (int) Math.floor(z / REGION + 0.5);
    }

    /** El borde entre filas por donde va la carretera de la fila f. */
    public static int borde(int fila) {
        return fila * REGION;
    }

    private int alMar() {
        return this.terreno.nivelMar() + SOBRE_MAR;
    }

    // ================================================================= el trazado

    private int[] punto(int fila, int k) {
        return this.puntos.obtener(clave(fila, k), () -> calcularPunto(fila, k));
    }

    /** {z, altura} del punto de control k de la fila: corrido al azar en z, pero sin meterse en una aldea. */
    private int[] calcularPunto(int fila, int k) {
        int b = borde(fila);
        int x = k * PASO;
        int opciones = (DESVIO_MAX - DESVIO_MIN) / PASO_Z + 1;
        int deseo = DESVIO_MIN + PASO_Z * Ruido.entero(this.semilla, fila, k, 0xCA77E7AL, opciones);
        // a veces sigue derecho (el mismo corrimiento que el punto anterior): tramos rectos largos
        if (Ruido.valor(this.semilla, fila, k, 0x5EC7AL) < 0.3) {
            deseo = DESVIO_MIN + PASO_Z * Ruido.entero(this.semilla, fila, k - 1, 0xCA77E7AL, opciones);
        }
        int lo = DESVIO_MIN;
        int hi = DESVIO_MAX;
        if (this.conAldeas) {
            for (int rx = Math.floorDiv(x - ALDEA_EN_X, REGION); rx <= Math.floorDiv(x + ALDEA_EN_X, REGION); rx++) {
                // las aldeas de la fila de "abajo" (más z) empujan la carretera hacia -z y las de arriba hacia +z
                Aldeas.Aldea a = this.aldeas.aldea(rx, fila);
                if (a != null && Math.abs(a.x() + 8 - x) < ALDEA_EN_X) {
                    hi = Math.min(hi, a.z() + 8 - b - LEJOS_DE_ALDEA);
                }
                Aldeas.Aldea c = this.aldeas.aldea(rx, fila - 1);
                if (c != null && Math.abs(c.x() + 8 - x) < ALDEA_EN_X) {
                    lo = Math.max(lo, c.z() + 8 - b + LEJOS_DE_ALDEA);
                }
            }
        }
        int corrimiento = lo <= hi ? Math.max(lo, Math.min(hi, deseo))
                : Math.max(DESVIO_MIN, Math.min(DESVIO_MAX, (lo + hi) / 2));
        int z = b + corrimiento;
        // la altura: la mediana del terreno a lo largo (nunca bajo el mar)
        int[] alturas = new int[7];
        for (int i = 0; i < alturas.length; i++) {
            alturas[i] = this.terreno.altura(x + (i - 3) * 8, z);
        }
        Arrays.sort(alturas);
        int y = Math.max(alMar(), Math.min(this.terreno.maxY() - 24, alturas[3]));
        return new int[]{z, y};
    }

    /** z del centro de la carretera de la fila en x. */
    public double centro(int fila, double x) {
        int k = (int) Math.floor(x / PASO);
        double t = (x - k * PASO) / PASO;
        int z0 = punto(fila, k)[0];
        int z1 = punto(fila, k + 1)[0];
        return z0 + (z1 - z0) * (1.0 - Math.cos(Math.PI * t)) * 0.5;
    }

    /** Cuánto cambia z del centro por cada bloque en x (la tangente del rumbo de la carretera). */
    public double pendiente(int fila, double x) {
        int k = (int) Math.floor(x / PASO);
        double t = (x - k * PASO) / PASO;
        int z0 = punto(fila, k)[0];
        int z1 = punto(fila, k + 1)[0];
        return (z1 - z0) * Math.PI * Math.sin(Math.PI * t) / (2.0 * PASO);
    }

    /**
     * Un lugar respecto de la carretera de la fila: {distancia con signo al centro (positiva hacia +z), x del pie (el
     * punto del centro más cercano)}.
     */
    public double[] lugar(int fila, double x, double z) {
        double zm = centro(fila, x);
        double p = pendiente(fila, x);
        double norma = Math.sqrt(1.0 + p * p);
        double d = (z - zm) / norma;
        return new double[]{d, x + d * p / norma};
    }

    // ================================================================= el perfil

    /** Un tramo de carretera entre dos puntos de control: la altura y cómo va en cada bloque de x. */
    public static final class Tramo {
        public final int fila;
        public final int k;
        public final int x0;
        /** Altura de la carretera en medios bloques (2 · piso + 1 si arriba va una losa), para x0 + i. */
        public final short[] alto;
        public final byte[] modo;
        /** El terreno (primera altura libre) sobre el centro, para x0 + i. */
        public final short[] terreno;

        Tramo(int fila, int k, short[] alto, byte[] modo, short[] terreno) {
            this.fila = fila;
            this.k = k;
            this.x0 = k * PASO;
            this.alto = alto;
            this.modo = modo;
            this.terreno = terreno;
        }
    }

    public Tramo tramo(int fila, int k) {
        return this.tramos.obtener(clave(fila, k), () -> calcularTramo(fila, k));
    }

    /** El tramo si ya está calculado (para no frenar el juego); si no, null. */
    public Tramo tramoSiEsta(int fila, int k) {
        return this.tramos.mirar(clave(fila, k));
    }

    /** Altura de la carretera (en medios bloques) en el bloque x del centro. */
    public int alto(int fila, int x) {
        int k = Math.floorDiv(x, PASO);
        return tramo(fila, k).alto[x - k * PASO];
    }

    public byte modo(int fila, int x) {
        int k = Math.floorDiv(x, PASO);
        return tramo(fila, k).modo[x - k * PASO];
    }

    private Tramo calcularTramo(int fila, int k) {
        int x0 = k * PASO;
        int n = PASO + 1;
        // el terreno sobre el centro, cada 4 bloques (interpolado)
        int muestras = PASO / 4 + 1;
        int[] m = new int[muestras];
        for (int j = 0; j < muestras; j++) {
            int x = x0 + 4 * j;
            m[j] = this.terreno.altura(x, (int) Math.floor(centro(fila, x + 0.5)));
        }
        short[] terr = new short[n];
        for (int i = 0; i < n; i++) {
            int j = i / 4;
            double t = (i % 4) / 4.0;
            terr[i] = (short) (j + 1 < muestras ? Math.round(m[j] + (m[j + 1] - m[j]) * t) : m[j]);
        }
        int[] deseo = suavizar(terr, alMar());
        int[] a = punto(fila, k);
        int[] b = punto(fila, k + 1);
        short[] alto = perfil(n, deseo, 2 * a[1], 2 * b[1]);
        return new Tramo(fila, k, alto, modos(alto, terr), terr);
    }

    /** El terreno sin lomitas ni pozos (mediana y después promedio, de a 13 bloques), nunca bajo el mar. */
    private static int[] suavizar(short[] t, int minimo) {
        int n = t.length;
        int[] med = new int[n];
        int[] buf = new int[13];
        for (int i = 0; i < n; i++) {
            int c = 0;
            for (int j = i - 6; j <= i + 6; j++) {
                buf[c++] = t[Math.max(0, Math.min(n - 1, j))];
            }
            Arrays.sort(buf, 0, c);
            med[i] = buf[c / 2];
        }
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            int suma = 0;
            int c = 0;
            for (int j = i - 6; j <= i + 6; j++) {
                suma += med[Math.max(0, Math.min(n - 1, j))];
                c++;
            }
            out[i] = Math.max(minimo, Math.round(suma / (float) c));
        }
        return out;
    }

    // lo que cuesta cada media losa que sube o baja, según cuán seguidas van
    private static final float PASO_BASE = 0.25F;
    /** Dos medias losas en columnas seguidas: pendiente del 50 %. */
    private static final float PASO_SEGUIDO = 3.0F;
    /** Con una columna plana entre medio: pendiente del 25 %. */
    private static final float PASO_CERCA = 0.8F;
    /** Subir y enseguida bajar (o al revés): un serrucho. */
    private static final float PASO_VUELTA = 1.5F;
    /** Un bloque entero de golpe (solo si no queda otra). */
    private static final float SALTO = 12.0F;
    /** Sub-estados: el último paso fue para arriba (0, 1, 2) o para abajo (3, 4, 5) hace 0, 1 o más columnas. */
    private static final int Q = 6;

    /**
     * Lo que cuesta que la carretera quede {@code e2} medios bloques por encima (positivo) o por debajo de lo que se
     * quiere seguir: hasta un bloque no importa; muy arriba es un puente y muy abajo un túnel (lo hondo casi no suma).
     */
    private static float desvio(int e2) {
        float e = e2 * 0.5F;
        if (e >= 0.0F) {
            float d = Math.max(0.0F, e - 1.0F);
            return d <= 6.0F ? 0.5F * d : 3.0F + 0.2F * (d - 6.0F);
        }
        float d = Math.max(0.0F, -e - 1.0F);
        return d <= 8.0F ? 0.6F * d : 4.8F + 0.05F * (d - 8.0F);
    }

    /**
     * La altura de cada columna (medios bloques), de {@code h0} en la primera a {@code h1} en la última. Sube o baja de
     * a media losa; las pendientes suaves (una media losa cada 3 columnas o más) casi no cuestan, las fuertes sí: así
     * prefiere cortar una loma, cruzar un valle por un puente o meterse en un túnel antes que trepar un cerro.
     */
    private short[] perfil(int n, int[] deseo, int h0, int h1) {
        int lo = Math.min(h0, h1);
        int hi = Math.max(h0, h1);
        for (int d : deseo) {
            lo = Math.min(lo, 2 * d);
            hi = Math.max(hi, 2 * d);
        }
        lo = Math.max(2 * alMar(), lo - 40);
        hi = Math.min(2 * (this.terreno.maxY() - 24), hi + 40);
        lo = Math.min(lo, Math.min(h0, h1));
        hi = Math.max(hi, Math.max(h0, h1));
        int alto = hi - lo + 1;
        int estados = alto * Q;
        float inf = Float.POSITIVE_INFINITY;
        float[] costo = new float[estados];
        float[] nuevo = new float[estados];
        // de dónde vino cada estado: el sub-estado anterior · 5 + (el movimiento + 2)
        byte[] previo = new byte[n * estados];
        Arrays.fill(costo, inf);
        costo[(h0 - lo) * Q + 2] = 0.0F;
        float[] celda = new float[alto];
        for (int i = 1; i < n; i++) {
            for (int h = 0; h < alto; h++) {
                celda[h] = desvio(lo + h - 2 * deseo[i]);
            }
            Arrays.fill(nuevo, inf);
            int base = i * estados;
            for (int h = 0; h < alto; h++) {
                for (int q = 0; q < Q; q++) {
                    float c = costo[h * Q + q];
                    if (c == inf) {
                        continue;
                    }
                    int signo = q < 3 ? 1 : -1;
                    int r = q % 3;
                    // plano
                    int q2 = (signo > 0 ? 0 : 3) + Math.min(r + 1, 2);
                    float c2 = c + celda[h];
                    int s2 = h * Q + q2;
                    if (c2 < nuevo[s2]) {
                        nuevo[s2] = c2;
                        previo[base + s2] = (byte) (q * 5 + 2);
                    }
                    for (int sg = -1; sg <= 1; sg += 2) {
                        // media losa
                        int h2 = h + sg;
                        if (h2 >= 0 && h2 < alto) {
                            float k = PASO_BASE + (r == 0 ? PASO_SEGUIDO : (r == 1 ? PASO_CERCA : 0.0F))
                                    + (sg != signo && r < 2 ? PASO_VUELTA : 0.0F);
                            c2 = c + k + celda[h2];
                            s2 = h2 * Q + (sg > 0 ? 0 : 3);
                            if (c2 < nuevo[s2]) {
                                nuevo[s2] = c2;
                                previo[base + s2] = (byte) (q * 5 + 2 + sg);
                            }
                        }
                        // un bloque entero
                        h2 = h + 2 * sg;
                        if (h2 >= 0 && h2 < alto) {
                            c2 = c + SALTO + celda[h2];
                            s2 = h2 * Q + (sg > 0 ? 0 : 3);
                            if (c2 < nuevo[s2]) {
                                nuevo[s2] = c2;
                                previo[base + s2] = (byte) (q * 5 + 2 + 2 * sg);
                            }
                        }
                    }
                }
            }
            float[] t = costo;
            costo = nuevo;
            nuevo = t;
        }
        int h = h1 - lo;
        int q = 0;
        for (int k = 1; k < Q; k++) {
            if (costo[h * Q + k] < costo[h * Q + q]) {
                q = k;
            }
        }
        short[] res = new short[n];
        for (int i = n - 1; i >= 1; i--) {
            res[i] = (short) (lo + h);
            int p = previo[i * estados + h * Q + q];
            int mov = p % 5 - 2;
            h -= mov;
            q = p / 5;
        }
        res[0] = (short) (lo + h);
        return res;
    }

    /** Cómo va cada columna según lo que queda la carretera sobre el terreno. */
    private byte[] modos(short[] alto, short[] terr) {
        int n = alto.length;
        byte[] mo = new byte[n];
        boolean[] agua = new boolean[n];
        for (int i = 0; i < n; i++) {
            double e = alto[i] * 0.5 - terr[i];
            agua[i] = terr[i] <= this.terreno.nivelMar();
            if (agua[i] || e >= 7.0) {
                mo[i] = PUENTE;
            } else if (e >= 1.5) {
                mo[i] = TERRAPLEN;
            } else if (e > -2.5) {
                mo[i] = LLANO;
            } else if (e > -11.0) {
                mo[i] = CORTE;
            } else {
                mo[i] = TUNEL;
            }
        }
        // un túnel cortito es un corte; un puente cortito (en tierra) es un terraplén
        corridas(mo, TUNEL, CORTE, 10, null);
        corridas(mo, PUENTE, TERRAPLEN, 6, agua);
        return mo;
    }

    private static void corridas(byte[] mo, byte cual, byte por, int minimo, boolean[] respetar) {
        int n = mo.length;
        int i = 0;
        while (i < n) {
            if (mo[i] != cual) {
                i++;
                continue;
            }
            int j = i;
            boolean fijo = false;
            while (j < n && mo[j] == cual) {
                fijo |= respetar != null && respetar[j];
                j++;
            }
            if (j - i < minimo && !fijo) {
                for (int q = i; q < j; q++) {
                    mo[q] = por;
                }
            }
            i = j;
        }
    }
}
