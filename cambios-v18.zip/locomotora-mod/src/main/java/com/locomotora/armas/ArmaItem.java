package com.locomotora.armas;

import java.util.List;

import com.locomotora.registro.ModItems;
import com.locomotora.registro.ModSonidos;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Las armas: pistola, rifle y ametralladora. Solo se consiguen como botín (las dejan los militares y los bandidos al
 * morir). Con clic derecho apretado se tira (cada arma a su ritmo) mientras haya munición en el inventario; cada tiro
 * gasta una (en creativo, ninguna).
 */
public class ArmaItem extends Item {
    /**
     * Cómo es cada arma.
     *
     * @param dano       daño de cada bala
     * @param cadencia   ticks entre tiro y tiro (el jugador)
     * @param velocidad  bloques por tick de la bala
     * @param imprecision cuánto se desvía
     * @param alcance    hasta dónde tiran los que la usan (bloques)
     * @param rafaga     tiros seguidos de los que la usan
     * @param pausa      ticks entre ráfagas de los que la usan
     */
    public enum Tipo {
        PISTOLA(5.0F, 6, 3.6F, 1.0F, 16.0, 2, 22),
        RIFLE(8.0F, 10, 4.6F, 0.35F, 28.0, 1, 30),
        AMETRALLADORA(4.0F, 3, 4.2F, 1.8F, 24.0, 6, 36);

        public final float dano;
        public final int cadencia;
        public final float velocidad;
        public final float imprecision;
        public final double alcance;
        public final int rafaga;
        public final int pausa;

        Tipo(float dano, int cadencia, float velocidad, float imprecision, double alcance, int rafaga, int pausa) {
            this.dano = dano;
            this.cadencia = cadencia;
            this.velocidad = velocidad;
            this.imprecision = imprecision;
            this.alcance = alcance;
            this.rafaga = rafaga;
            this.pausa = pausa;
        }

        SoundEvent sonido() {
            return switch (this) {
                case PISTOLA -> ModSonidos.DISPARO_PISTOLA.get();
                case RIFLE -> ModSonidos.DISPARO_RIFLE.get();
                case AMETRALLADORA -> ModSonidos.DISPARO_AMETRALLADORA.get();
            };
        }
    }

    private final Tipo tipo;

    public ArmaItem(Tipo tipo, Properties propiedades) {
        super(propiedades.stacksTo(1));
        this.tipo = tipo;
    }

    public Tipo tipo() {
        return this.tipo;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player jugador, InteractionHand mano) {
        ItemStack stack = jugador.getItemInHand(mano);
        if (!jugador.getAbilities().instabuild && municion(jugador).isEmpty()) {
            if (!level.isClientSide()) {
                sinMunicion(level, jugador);
            }
            return InteractionResultHolder.fail(stack);
        }
        jugador.startUsingItem(mano);
        if (level instanceof ServerLevel nivel) {
            tirar(nivel, jugador);
        }
        return InteractionResultHolder.consume(stack);
    }

    /** Mientras se tiene apretado: un tiro cada tantos ticks (si se acaba la munición, para). */
    @Override
    public void onUseTick(Level level, LivingEntity quien, ItemStack stack, int restantes) {
        if (!(level instanceof ServerLevel nivel) || !(quien instanceof Player jugador)) {
            return;
        }
        int usado = this.getUseDuration(stack, quien) - restantes;
        if (usado <= 0 || usado % this.tipo.cadencia != 0) {
            return;
        }
        if (jugador.getAbilities().instabuild || !municion(jugador).isEmpty()) {
            tirar(nivel, jugador);
        } else {
            sinMunicion(level, jugador);
            jugador.releaseUsingItem();
        }
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity quien) {
        return 72000;
    }

    /** Al tirar, los brazos van adelante (como con el arco). */
    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BOW;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext contexto, List<Component> lineas, TooltipFlag opciones) {
        lineas.add(Component.translatable("tooltip.locomotora.arma", fmt(this.tipo.dano),
                Math.round(20.0F / this.tipo.cadencia * 10.0F) / 10.0F).withStyle(ChatFormatting.GRAY));
        lineas.add(Component.translatable("tooltip.locomotora.arma_uso").withStyle(ChatFormatting.DARK_GRAY));
    }

    private static String fmt(float v) {
        return v == Math.floor(v) ? String.valueOf((int) v) : String.valueOf(v);
    }

    private void sinMunicion(Level level, Player jugador) {
        level.playSound(null, jugador.getX(), jugador.getY(), jugador.getZ(), ModSonidos.SIN_MUNICION.get(),
                SoundSource.PLAYERS, 0.8F, 1.3F);
        jugador.displayClientMessage(Component.translatable("mensaje.locomotora.sin_municion")
                .withStyle(ChatFormatting.RED), true);
    }

    /** La munición que va a usar (primero la de la otra mano), o vacío si no tiene. */
    public static ItemStack municion(Player jugador) {
        for (InteractionHand mano : InteractionHand.values()) {
            ItemStack s = jugador.getItemInHand(mano);
            if (s.is(ModItems.MUNICION.get())) {
                return s;
            }
        }
        for (int i = 0; i < jugador.getInventory().getContainerSize(); i++) {
            ItemStack s = jugador.getInventory().getItem(i);
            if (s.is(ModItems.MUNICION.get())) {
                return s;
            }
        }
        return ItemStack.EMPTY;
    }

    /** Un tiro del jugador: gasta una bala y sale de la boca, hacia donde mira. */
    private void tirar(ServerLevel nivel, Player jugador) {
        if (!jugador.getAbilities().instabuild) {
            municion(jugador).shrink(1);
        }
        Vec3 mira = jugador.getViewVector(1.0F);
        Vec3 derecha = new Vec3(-mira.z, 0.0, mira.x).normalize();
        Vec3 boca = jugador.getEyePosition().add(mira.scale(0.6)).add(derecha.scale(0.22)).add(0.0, -0.12, 0.0);
        disparar(nivel, jugador, this.tipo, boca, mira, this.tipo.imprecision, this.tipo.dano);
    }

    /** Un tiro (de un jugador o de alguien de la carretera): la bala, el fogonazo y el estampido. */
    public static void disparar(ServerLevel nivel, LivingEntity tirador, Tipo tipo, Vec3 boca, Vec3 direccion,
                                float imprecision, float dano) {
        BalaEntity.tirar(nivel, tirador, boca, direccion, tipo.velocidad, imprecision, dano);
        nivel.sendParticles(ParticleTypes.SMOKE, boca.x, boca.y, boca.z, 2, 0.03, 0.03, 0.03, 0.01);
        nivel.sendParticles(ParticleTypes.SMALL_FLAME, boca.x, boca.y, boca.z, 1, 0.02, 0.02, 0.02, 0.0);
        float tono = switch (tipo) {
            case PISTOLA -> 1.55F;
            case RIFLE -> 1.05F;
            case AMETRALLADORA -> 1.25F;
        };
        nivel.playSound(null, boca.x, boca.y, boca.z, tipo.sonido(),
                tirador instanceof Player ? SoundSource.PLAYERS : SoundSource.HOSTILE,
                tipo == Tipo.RIFLE ? 3.0F : 2.2F, tono + (nivel.getRandom().nextFloat() - 0.5F) * 0.12F);
    }
}
