package com.locomotora.armas;

import java.util.Optional;

import org.jetbrains.annotations.Nullable;

import com.locomotora.LocomotoraMod;
import com.locomotora.gente.PersonaEntity;
import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModItems;

import net.minecraft.core.Holder;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.entity.PartEntity;

/**
 * Una bala: vuela derecho y muy rápido (casi no cae) y lastima a lo primero que toca. No le pega a quien la tiró, ni a
 * los que van en su mismo vehículo, ni a los de su mismo bando (un militar no le pega a otro militar).
 */
public class BalaEntity extends ThrowableItemProjectile {
    /** Si en 2 segundos no tocó nada, se deshace. */
    private static final int VIDA = 40;
    /** El tipo de daño (data/locomotora/damage_type/bala.json): "fue baleado por...". */
    private static final ResourceKey<DamageType> BALA = ResourceKey.create(Registries.DAMAGE_TYPE, LocomotoraMod.id("bala"));

    private float dano = 5.0F;

    public BalaEntity(EntityType<? extends BalaEntity> tipo, Level level) {
        super(tipo, level);
    }

    public static BalaEntity tirar(ServerLevel nivel, LivingEntity tirador, Vec3 boca, Vec3 direccion, float velocidad,
                                   float imprecision, float dano) {
        BalaEntity b = new BalaEntity(ModEntidades.BALA.get(), nivel);
        b.setPos(boca.x, boca.y, boca.z);
        b.setOwner(tirador);
        b.dano = dano;
        b.shoot(direccion.x, direccion.y, direccion.z, velocidad, imprecision);
        nivel.addFreshEntity(b);
        return b;
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.BALA.get();
    }

    @Override
    public double getDefaultGravity() {
        return 0.004;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.isRemoved()) {
            return;
        }
        if (this.level().isClientSide()) {
            if (this.tickCount > 1) {
                this.level().addParticle(ParticleTypes.CRIT, this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
            }
        } else if (this.tickCount > VIDA) {
            this.discard();
        }
    }

    @Override
    protected boolean canHitEntity(Entity otra) {
        if (!super.canHitEntity(otra)) {
            return false;
        }
        Entity tirador = this.getOwner();
        if (tirador == null) {
            return true;
        }
        Entity blanco = otra instanceof PartEntity<?> parte ? parte.getParent() : otra;
        if (tirador.getRootVehicle() == blanco.getRootVehicle() && tirador.isPassenger()) {
            return false;
        }
        if (tirador instanceof PersonaEntity p && blanco instanceof PersonaEntity q && p.grupo() == q.grupo()) {
            return false;
        }
        return true;
    }

    @Override
    protected void onHitEntity(EntityHitResult resultado) {
        super.onHitEntity(resultado);
        if (!(this.level() instanceof ServerLevel nivel)) {
            return;
        }
        Entity e = resultado.getEntity();
        Entity tirador = this.getOwner();
        e.hurt(fuente(nivel, tirador), this.dano);
        if (e instanceof LivingEntity vivo) {
            // las balas casi no empujan
            vivo.setDeltaMovement(vivo.getDeltaMovement().multiply(0.6, 1.0, 0.6));
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult resultado) {
        super.onHitBlock(resultado);
        if (this.level() instanceof ServerLevel nivel) {
            BlockState estado = nivel.getBlockState(resultado.getBlockPos());
            Vec3 p = resultado.getLocation();
            if (!estado.isAir()) {
                nivel.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, estado), p.x, p.y, p.z, 4, 0.05, 0.05,
                        0.05, 0.05);
            }
        }
    }

    @Override
    protected void onHit(HitResult resultado) {
        super.onHit(resultado);
        if (!this.level().isClientSide()) {
            this.discard();
        }
    }

    private DamageSource fuente(ServerLevel nivel, @Nullable Entity tirador) {
        Optional<Holder.Reference<DamageType>> tipo = nivel.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE)
                .getHolder(BALA);
        return tipo.<DamageSource>map(t -> new DamageSource(t, this, tirador))
                .orElseGet(() -> nivel.damageSources().thrown(this, tirador));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putFloat("Dano", this.dano);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.dano = tag.contains("Dano") ? tag.getFloat("Dano") : 5.0F;
    }
}
