package com.locomotora.gente;

import java.util.EnumSet;

import org.jetbrains.annotations.Nullable;

import com.locomotora.vehiculo.VehiculoEntity;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.goal.Goal;

/** Cuando ya no hay a quién tirarle, vuelve caminando a su vehículo y se sube (el primero que llega, al volante). */
public class VolverAlVehiculoGoal extends Goal {
    /** Ticks sin blanco antes de volver. */
    private static final int ESPERA = 120;
    private static final double LEJOS = 64.0;

    private final PersonaEntity persona;
    @Nullable
    private VehiculoEntity vehiculo;
    private int camino;

    public VolverAlVehiculoGoal(PersonaEntity persona) {
        this.persona = persona;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE));
    }

    @Nullable
    private VehiculoEntity buscar() {
        if (this.persona.getVehiculo() == null || !(this.persona.level() instanceof ServerLevel nivel)) {
            return null;
        }
        Entity e = nivel.getEntity(this.persona.getVehiculo());
        if (e instanceof VehiculoEntity v && v.isAlive() && v.hayLugarParaNPC() && this.persona.distanceTo(v) < LEJOS) {
            return v;
        }
        return null;
    }

    @Override
    public boolean canUse() {
        if (this.persona.isPassenger() || this.persona.getTarget() != null || this.persona.sinObjetivo() < ESPERA) {
            return false;
        }
        this.vehiculo = buscar();
        return this.vehiculo != null;
    }

    @Override
    public boolean canContinueToUse() {
        return !this.persona.isPassenger() && this.persona.getTarget() == null && this.vehiculo != null
                && this.vehiculo.isAlive() && this.vehiculo.hayLugarParaNPC()
                && this.persona.distanceTo(this.vehiculo) < LEJOS;
    }

    @Override
    public void start() {
        this.camino = 0;
    }

    @Override
    public void stop() {
        this.vehiculo = null;
        this.persona.getNavigation().stop();
    }

    @Override
    public void tick() {
        VehiculoEntity v = this.vehiculo;
        if (v == null) {
            return;
        }
        if (this.persona.distanceTo(v) < v.getTipo().alcance() + 1.2) {
            v.subirNPC(this.persona);
            return;
        }
        if (--this.camino <= 0) {
            this.camino = 20;
            this.persona.getNavigation().moveTo(v, 1.1);
        }
    }
}
