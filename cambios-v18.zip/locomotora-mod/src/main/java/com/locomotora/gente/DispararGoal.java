package com.locomotora.gente;

import java.util.EnumSet;

import com.locomotora.armas.ArmaItem;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

/**
 * Tirarle al blanco: se acerca hasta tenerlo a tiro y a la vista, apunta (con los brazos adelante) y tira ráfagas al
 * ritmo de su arma, moviéndose de costado de a ratos. Desde un vehículo también tira, pero sin moverse (y el que
 * maneja, no).
 */
public class DispararGoal extends Goal {
    private final PersonaEntity persona;
    private int espera = 20;
    private int visto;
    private int rafaga;
    private int costado;
    private boolean izquierda;

    public DispararGoal(PersonaEntity persona) {
        this.persona = persona;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity t = this.persona.getTarget();
        return t != null && t.isAlive() && this.persona.arma() != null && !this.persona.esConductor();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        this.persona.setAggressive(true);
        this.visto = 0;
        this.espera = 10 + this.persona.getRandom().nextInt(15);
    }

    @Override
    public void stop() {
        this.persona.setAggressive(false);
        this.persona.setApunta(false);
        this.persona.getNavigation().stop();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        LivingEntity t = this.persona.getTarget();
        ArmaItem.Tipo arma = this.persona.arma();
        if (t == null || arma == null) {
            return;
        }
        double d2 = this.persona.distanceToSqr(t);
        boolean ve = this.persona.getSensing().hasLineOfSight(t);
        this.visto = ve ? Math.min(this.visto + 1, 200) : 0;
        double alcance = arma.alcance;
        boolean aTiro = ve && d2 < alcance * alcance;
        if (!this.persona.isPassenger()) {
            if (!ve || d2 > alcance * alcance * 0.55) {
                this.persona.getNavigation().moveTo(t, 1.0);
            } else {
                this.persona.getNavigation().stop();
                if (++this.costado >= 30) {
                    this.costado = 0;
                    this.izquierda = this.persona.getRandom().nextBoolean();
                }
                float adelante = d2 < 36.0 ? -0.4F : 0.0F;
                this.persona.getMoveControl().strafe(adelante, this.izquierda ? 0.35F : -0.35F);
                this.persona.lookAt(t, 30.0F, 30.0F);
            }
        }
        this.persona.getLookControl().setLookAt(t, 30.0F, 30.0F);
        this.persona.setApunta(aTiro);
        if (--this.espera <= 0 && aTiro && this.visto >= 8) {
            this.persona.dispararA(t);
            if (this.rafaga <= 0) {
                this.rafaga = arma.rafaga;
            }
            if (--this.rafaga > 0) {
                this.espera = Math.max(2, arma.cadencia);
            } else {
                this.espera = arma.pausa + this.persona.getRandom().nextInt(12);
            }
        }
    }
}
