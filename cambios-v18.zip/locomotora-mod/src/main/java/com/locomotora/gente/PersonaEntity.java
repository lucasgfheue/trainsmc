package com.locomotora.gente;

import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import com.locomotora.armas.ArmaItem;
import com.locomotora.registro.ModItems;
import com.locomotora.transito.Transito;
import com.locomotora.vehiculo.VehiculoEntity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.AvoidEntityGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;

/**
 * La gente de las carreteras: personas comunes (10 caras distintas), bandidos y militares (3 cada uno). Van en los
 * vehículos del tránsito; el que va al volante maneja (ver {@code Conductor}).
 * <ul>
 *   <li>Las personas no pelean: si las lastiman o ven a alguien armado peleando, se escapan.</li>
 *   <li>Los bandidos y los militares andan armados (pistola, rifle o ametralladora) y te tiran si te ven cerca; se
 *       pelean entre ellos. Cuando ya no tienen a quién tirarle, vuelven a su vehículo y siguen viaje.</li>
 *   <li>Al morir, los bandidos y los militares a veces dejan su arma, y munición.</li>
 * </ul>
 */
public class PersonaEntity extends PathfinderMob {
    private static final EntityDataAccessor<Integer> DATA_SKIN =
            SynchedEntityData.defineId(PersonaEntity.class, EntityDataSerializers.INT);
    /** Apunta con los brazos adelante (se ve en el cliente). */
    private static final EntityDataAccessor<Boolean> DATA_APUNTA =
            SynchedEntityData.defineId(PersonaEntity.class, EntityDataSerializers.BOOLEAN);

    /** El vehículo en el que vino (para volver a subirse). */
    @Nullable
    private UUID vehiculo;
    /** Lo puso el tránsito: se quita cuando queda lejos de todos. */
    private boolean transito;
    /** Ticks sin a quién tirarle. */
    private int sinObjetivo;

    public PersonaEntity(EntityType<? extends PersonaEntity> tipo, Level level) {
        super(tipo, level);
        this.xpReward = Grupo.de(tipo).hostil ? 5 : 1;
    }

    public static AttributeSupplier.Builder atributos(Grupo g) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, g == Grupo.MILITAR ? 24.0 : 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.FOLLOW_RANGE, g.hostil ? 24.0 : 16.0)
                .add(Attributes.ATTACK_DAMAGE, 2.0)
                .add(Attributes.ARMOR, g == Grupo.MILITAR ? 6.0 : 0.0);
    }

    public Grupo grupo() {
        return Grupo.de(this.getType());
    }

    @Override
    public void registerGoals() {
        Grupo g = grupo();
        this.goalSelector.addGoal(0, new FloatGoal(this));
        if (g.hostil) {
            this.goalSelector.addGoal(2, new DispararGoal(this));
            this.goalSelector.addGoal(4, new VolverAlVehiculoGoal(this));
            this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.7));
            this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
            this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false,
                    this::puedeAtacar));
            this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, PersonaEntity.class, 10, true, false,
                    e -> e instanceof PersonaEntity p && g.enemigoDe(p.grupo())));
        } else {
            this.goalSelector.addGoal(1, new PanicGoal(this, 1.4));
            this.goalSelector.addGoal(2, new AvoidEntityGoal<>(this, PersonaEntity.class, 10.0F, 1.0, 1.35,
                    e -> e instanceof PersonaEntity p && p.grupo().hostil && p.getTarget() != null));
            this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.6));
        }
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
    }

    /** A los jugadores solo les tiran si el mundo no está en pacífico. */
    private boolean puedeAtacar(LivingEntity e) {
        return this.level().getDifficulty() != Difficulty.PEACEFUL;
    }

    @Override
    public void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_SKIN, 0);
        builder.define(DATA_APUNTA, false);
    }

    // ================================================================= aparecer

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor nivel, DifficultyInstance dificultad, MobSpawnType razon,
                                        @Nullable SpawnGroupData datos) {
        Grupo g = grupo();
        this.setSkin(this.random.nextInt(g.skins));
        Item arma = switch (g) {
            case MILITAR -> this.random.nextFloat() < 0.3F ? ModItems.AMETRALLADORA.get() : ModItems.RIFLE.get();
            case BANDIDO -> this.random.nextFloat() < 0.6F ? ModItems.PISTOLA.get() : ModItems.RIFLE.get();
            default -> null;
        };
        if (arma != null) {
            this.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(arma));
            // el arma la deja el botín (data/locomotora/loot_table/entities), no el equipo
            this.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        }
        if (razon == MobSpawnType.SPAWN_EGG) {
            this.setPersistenceRequired();
        }
        return super.finalizeSpawn(nivel, dificultad, razon, datos);
    }

    // ================================================================= estado

    public int getSkin() {
        return this.entityData.get(DATA_SKIN);
    }

    public void setSkin(int skin) {
        this.entityData.set(DATA_SKIN, Math.max(0, Math.min(grupo().skins - 1, skin)));
    }

    public boolean apunta() {
        return this.entityData.get(DATA_APUNTA);
    }

    public void setApunta(boolean apunta) {
        if (apunta != apunta()) {
            this.entityData.set(DATA_APUNTA, apunta);
        }
    }

    @Nullable
    public ArmaItem.Tipo arma() {
        return this.getMainHandItem().getItem() instanceof ArmaItem a ? a.tipo() : null;
    }

    @Nullable
    public UUID getVehiculo() {
        return this.vehiculo;
    }

    public void setVehiculo(@Nullable UUID vehiculo) {
        this.vehiculo = vehiculo;
    }

    public boolean isTransito() {
        return this.transito;
    }

    public void setTransito(boolean transito) {
        this.transito = transito;
    }

    public int sinObjetivo() {
        return this.sinObjetivo;
    }

    /** ¿Va al volante de un vehículo? */
    public boolean esConductor() {
        return this.getVehicle() instanceof VehiculoEntity v && v.getControllingPassenger() == this;
    }

    /** El nombre: las personas comunes tienen el suyo (Carlos, Lucía...); los demás, "Bandido" o "Militar". */
    @Override
    public Component getTypeName() {
        if (grupo() == Grupo.CIVIL) {
            return Component.translatable("entity.locomotora.persona." + (getSkin() + 1));
        }
        return super.getTypeName();
    }

    // ================================================================= tick

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide()) {
            this.sinObjetivo = this.getTarget() == null ? this.sinObjetivo + 1 : 0;
            if (this.transito && !Transito.conocido(this.getUUID())) {
                Transito.registrar(this);
            }
            if (this.getTarget() == null) {
                setApunta(false);
            }
        }
    }

    /** Un tiro hacia el blanco (con la puntería según la dificultad). */
    public void dispararA(LivingEntity blanco) {
        ArmaItem.Tipo arma = arma();
        if (arma == null || !(this.level() instanceof ServerLevel nivel)) {
            return;
        }
        Vec3 ojo = this.getEyePosition();
        Vec3 punto = new Vec3(blanco.getX(), blanco.getY() + blanco.getBbHeight() * 0.62, blanco.getZ());
        Vec3 mira = punto.subtract(ojo).normalize();
        Vec3 derecha = new Vec3(-mira.z, 0.0, mira.x).normalize();
        Vec3 boca = ojo.add(mira.scale(0.7)).add(derecha.scale(0.25)).add(0.0, -0.2, 0.0);
        Vec3 direccion = punto.subtract(boca).normalize();
        float k = switch (nivel.getDifficulty()) {
            case EASY -> 3.0F;
            case HARD -> 1.4F;
            default -> 2.0F;
        };
        ArmaItem.disparar(nivel, this, arma, boca, direccion, arma.imprecision * k + 0.6F, arma.dano * 0.6F);
    }

    /** Si los lastiman, los de su bando que estén cerca también van por el que fue (y su vehículo se entera). */
    @Override
    public boolean hurt(DamageSource fuente, float cantidad) {
        boolean lastimado = super.hurt(fuente, cantidad);
        if (lastimado && !this.level().isClientSide() && grupo().hostil
                && fuente.getEntity() instanceof LivingEntity atacante && atacante != this && atacante.isAlive()) {
            if (atacante instanceof Player j && (j.isCreative() || j.isSpectator())) {
                return true;
            }
            if (atacante instanceof PersonaEntity p && p.grupo() == grupo()) {
                return true;
            }
            for (PersonaEntity p : this.level().getEntitiesOfClass(PersonaEntity.class, this.getBoundingBox().inflate(24.0),
                    q -> q != this && q.grupo() == grupo() && q.getTarget() == null)) {
                p.setTarget(atacante);
            }
            if (this.getVehicle() instanceof VehiculoEntity v) {
                v.alerta(atacante);
            }
        }
        return lastimado;
    }

    @Override
    public SoundEvent getHurtSound(DamageSource fuente) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    public SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }

    @Override
    public boolean shouldDespawnInPeaceful() {
        return grupo().hostil && this.transito;
    }

    // ================================================================= guardado

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Skin", getSkin());
        tag.putBoolean("Transito", this.transito);
        if (this.vehiculo != null) {
            tag.putUUID("Vehiculo", this.vehiculo);
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setSkin(tag.getInt("Skin"));
        this.transito = tag.getBoolean("Transito");
        this.vehiculo = tag.hasUUID("Vehiculo") ? tag.getUUID("Vehiculo") : null;
    }
}
