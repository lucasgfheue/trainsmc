package com.locomotora.gente;

import com.locomotora.registro.ModEntidades;

import net.minecraft.world.entity.EntityType;

/** La gente de las carreteras: la de todos los días, los bandidos y los militares. */
public enum Grupo {
    /** Gente común: maneja cualquier vehículo menos los militares. Si te paras adelante, la mitad frena. */
    CIVIL(10, false),
    /** Bandidos: manejan cualquier cosa; si te ven cerca te persiguen para atropellarte, y a pie te tiran. */
    BANDIDO(3, true),
    /** Militares: solo vehículos militares; si te ven cerca paran, se bajan y te tiran. */
    MILITAR(3, true);

    public final int skins;
    public final boolean hostil;

    Grupo(int skins, boolean hostil) {
        this.skins = skins;
        this.hostil = hostil;
    }

    public static Grupo de(EntityType<?> tipo) {
        if (tipo == ModEntidades.BANDIDO.get()) {
            return BANDIDO;
        }
        if (tipo == ModEntidades.MILITAR.get()) {
            return MILITAR;
        }
        return CIVIL;
    }

    /** ¿Estos dos se pelean? (los militares y los bandidos) */
    public boolean enemigoDe(Grupo otro) {
        return (this == MILITAR && otro == BANDIDO) || (this == BANDIDO && otro == MILITAR);
    }
}
