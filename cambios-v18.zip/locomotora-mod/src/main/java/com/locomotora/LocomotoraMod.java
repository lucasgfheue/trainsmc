package com.locomotora;

import com.locomotora.aereo.DespachanteAereo;
import com.locomotora.gente.Grupo;
import com.locomotora.gente.PersonaEntity;
import com.locomotora.artillero.DisparoPayload;
import com.locomotora.artillero.TrenArtillero;
import com.locomotora.registro.ModBloques;
import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModItems;
import com.locomotora.registro.ModMundo;
import com.locomotora.registro.ModPestanas;
import com.locomotora.registro.ModReglas;
import com.locomotora.registro.ModSonidos;
import com.locomotora.transito.Transito;
import com.locomotora.tren.Despachante;
import com.locomotora.vehiculo.VehiculoEntity;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

/**
 * Clase principal del mod "Locomotora de Vapor".
 * Registra los bloques (vías y balasto), los ítems, las entidades (locomotoras y vagones), los sonidos, el menú de las
 * vías, las pestañas del modo creativo, la red de vías del mundo (con sus estaciones), los trenes que pasan solos,
 * los globos y zeppelines que pasan por el cielo, los vehículos de calle (autos, motos, camiones y militares) y las
 * carreteras con su tránsito: gente común, bandidos y militares (y las armas que dejan).
 */
@Mod(LocomotoraMod.MODID)
public class LocomotoraMod {
    public static final String MODID = "locomotora";

    public LocomotoraMod(IEventBus modEventBus, ModContainer modContainer) {
        ModBloques.BLOQUES.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModBloques.ENTIDADES_BLOQUE.register(modEventBus);
        ModBloques.MENUS.register(modEventBus);
        ModEntidades.ENTIDADES.register(modEventBus);
        ModSonidos.SONIDOS.register(modEventBus);
        // La red de vías infinitas con estaciones (se agrega a los biomas con un biome modifier) y sus reglas
        ModMundo.FEATURES.register(modEventBus);
        // La estación abandonada como estructura (para encontrarla con /locate structure)
        ModMundo.ESTRUCTURAS.register(modEventBus);
        ModMundo.PIEZAS.register(modEventBus);
        ModMundo.UBICACIONES.register(modEventBus);
        modEventBus.addListener(LocomotoraMod::preparar);
        // El clic izquierdo de los tiradores del tren artillero y de los que van en un vehículo (del cliente al servidor)
        modEventBus.addListener(LocomotoraMod::registrarPaquetes);
        // Los mundos de antes pasan del tren cada 10 minutos al de cada 5
        NeoForge.EVENT_BUS.addListener(ModReglas::alArrancar);
        // Los trenes que pasan solos cada tantos minutos
        NeoForge.EVENT_BUS.addListener(Despachante::alTick);
        NeoForge.EVENT_BUS.addListener(Despachante::alEntrar);
        // Los globos y zeppelines que pasan por el cielo (y de noche, a veces, los bombarderos)
        NeoForge.EVENT_BUS.addListener(DespachanteAereo::alTick);
        // Los vehículos con gente que pasan por las carreteras (gente común, bandidos y militares)
        NeoForge.EVENT_BUS.addListener(Transito::alTick);
        modEventBus.addListener(LocomotoraMod::atributos);
        // Pestañas propias en el modo creativo: "Locomotoras", "Vagones", "Coches de pasajeros", "Vías", "Globos y
        // zeppelines" y "Vehículos"
        ModPestanas.PESTANAS.register(modEventBus);
    }

    /** La vida, la rapidez y lo demás de la gente de las carreteras. */
    private static void atributos(EntityAttributeCreationEvent evento) {
        evento.put(ModEntidades.PERSONA.get(), PersonaEntity.atributos(Grupo.CIVIL).build());
        evento.put(ModEntidades.BANDIDO.get(), PersonaEntity.atributos(Grupo.BANDIDO).build());
        evento.put(ModEntidades.MILITAR.get(), PersonaEntity.atributos(Grupo.MILITAR).build());
    }

    private static void registrarPaquetes(RegisterPayloadHandlersEvent evento) {
        evento.registrar("1").playToServer(DisparoPayload.TIPO, DisparoPayload.CODEC, (paquete, contexto) -> {
            if (contexto.player() instanceof ServerPlayer jugador) {
                // en un vehículo de calle: la torreta o la bocina; en el tren artillero, sus torretas
                if (jugador.getVehicle() instanceof VehiculoEntity vehiculo) {
                    vehiculo.clicIzquierdo(jugador);
                } else {
                    TrenArtillero.disparoManual(jugador);
                }
            }
        });
    }

    /** Las reglas del juego del mod se registran en el hilo principal. */
    private static void preparar(FMLCommonSetupEvent evento) {
        evento.enqueueWork(ModReglas::registrar);
    }

    public static ResourceLocation id(String ruta) {
        return ResourceLocation.fromNamespaceAndPath(MODID, ruta);
    }
}
