package com.locomotora.cliente;

import com.locomotora.LocomotoraMod;
import com.locomotora.gente.PersonaEntity;
import com.mojang.blaze3d.vertex.PoseStack;

import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** La gente de las carreteras: el muñeco del jugador con su skin (textures/entity/persona/grupo_n.png). */
public class PersonaRenderer extends HumanoidMobRenderer<PersonaEntity, ModeloPersona> {
    private static final ResourceLocation[] CIVIL = skins("civil", 10);
    private static final ResourceLocation[] BANDIDO = skins("bandido", 3);
    private static final ResourceLocation[] MILITAR = skins("militar", 3);

    public PersonaRenderer(EntityRendererProvider.Context contexto) {
        super(contexto, new ModeloPersona(contexto.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    private static ResourceLocation[] skins(String grupo, int n) {
        ResourceLocation[] r = new ResourceLocation[n];
        for (int i = 0; i < n; i++) {
            r[i] = LocomotoraMod.id("textures/entity/persona/" + grupo + "_" + (i + 1) + ".png");
        }
        return r;
    }

    @Override
    public ResourceLocation getTextureLocation(PersonaEntity persona) {
        ResourceLocation[] lista = switch (persona.grupo()) {
            case BANDIDO -> BANDIDO;
            case MILITAR -> MILITAR;
            default -> CIVIL;
        };
        return lista[Math.floorMod(persona.getSkin(), lista.length)];
    }

    /** Del tamaño de un jugador (que se dibuja un poco más chico que el muñeco). */
    @Override
    public void scale(PersonaEntity persona, PoseStack pose, float tickParcial) {
        pose.scale(0.9375F, 0.9375F, 0.9375F);
    }
}
