package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D del vehículo "militar_tanque" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, suelo en Y = 0, Z hacia la derecha del que maneja.
 * Las superficies curvas están hechas con placas finas giradas y estiradas a medida (escala de cada pieza).
 */
public final class ModeloMilitarTanque {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("militar_tanque"), "main"),
            LocomotoraMod.id("textures/entity/militar_tanque.png"),
            List.of(
                new DatosModelo.Animada("rodillo_i0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i0_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i0_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i1_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i1_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i2_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i2_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i3_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i3_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i4_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i4_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i5_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i5_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_i_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_i_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_i_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_i_3", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_i_cara", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_i_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_i_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_i_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_i_3", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_i_cara", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i0_0", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i0_1", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i0_2", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i0_3", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i0_cara", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i1_0", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i1_1", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i1_2", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i1_3", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i1_cara", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d0_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d0_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d1_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d1_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d2_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d2_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d3_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d3_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d4_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d4_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d5_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d5_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_d_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_d_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_d_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_d_3", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_d_cara", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_d_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_d_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_d_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_d_3", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_d_cara", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d0_0", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d0_1", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d0_2", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d0_3", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d0_cara", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d1_0", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d1_1", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.39269908169872414F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d1_2", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.7853981633974483F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d1_3", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 1.1780972450961724F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d1_cara", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_0", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_1", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_2", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_3", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_4", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_5", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_6", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_7", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_8", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_9", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_10", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_11", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_12", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_13", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_14", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_15", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_16", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_17", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_18", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_19", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_20", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_21", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_22", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_23", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_24", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_25", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_26", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_27", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_28", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_29", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_30", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_31", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_32", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_33", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_34", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_35", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_36", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_37", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_38", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_39", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_40", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_41", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_42", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_43", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_44", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_45", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_46", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_47", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_48", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_49", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_50", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_51", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_52", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_53", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_54", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_55", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_56", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_57", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_58", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_59", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_60", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_61", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_62", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_63", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_64", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_65", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_66", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_67", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_68", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_69", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_70", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_71", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_72", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_73", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_74", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_75", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_76", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_77", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_78", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_79", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_80", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_81", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_82", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_83", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_84", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_85", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_86", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_87", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_88", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_89", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_90", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_91", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_92", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_93", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_94", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_95", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_96", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_97", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_98", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_99", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_100", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_101", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_102", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_103", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_104", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_105", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_106", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_107", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_108", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_109", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_110", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_111", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_112", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_113", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_114", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_115", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_116", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_117", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_118", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_119", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_120", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_121", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_122", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_123", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_124", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_125", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_126", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_127", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_128", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_129", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_130", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_131", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_132", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_133", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_134", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_135", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_136", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_137", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_138", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_139", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_140", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_141", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_142", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_143", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_144", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_145", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_146", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_147", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_148", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_149", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_150", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_151", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_152", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_153", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_154", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_155", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_156", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_157", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_158", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_159", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_160", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_161", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_162", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_163", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_164", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_165", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_166", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_167", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_168", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_169", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_170", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_171", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_172", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_173", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_174", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_175", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_176", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_177", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_178", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_179", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_180", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_181", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_182", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_183", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_184", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_185", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_186", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_187", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_188", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_189", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_190", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_191", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_0", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_1", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_2", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_3", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_4", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_5", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_6", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_7", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_8", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_9", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_10", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_11", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_12", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_13", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_14", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_15", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_16", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_17", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_18", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_19", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_20", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_21", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_22", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_23", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_24", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_25", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_26", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_27", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_28", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_29", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_30", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_31", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_32", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_33", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_34", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_35", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_36", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_37", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_38", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_39", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_40", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_41", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_42", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_43", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_44", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_45", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_46", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_47", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_48", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_49", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_50", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_51", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_52", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_53", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_54", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_55", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_56", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_57", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_58", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_59", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_60", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_61", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_62", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_63", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_64", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_65", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_66", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_67", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_68", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_69", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_70", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_71", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_72", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_73", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_74", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_75", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_76", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_77", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_78", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_79", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_80", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_81", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_82", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_83", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_84", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_85", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_86", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_87", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_88", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_89", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_90", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_91", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_92", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_93", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_94", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_95", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_96", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_97", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_98", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_99", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_100", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_101", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_102", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_103", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_104", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_105", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_106", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_107", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_108", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_109", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_110", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_111", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_112", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_113", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_114", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_115", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_116", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_117", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_118", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_119", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_120", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_121", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_122", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_123", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_124", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_125", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_126", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_127", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_128", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_129", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_130", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_131", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_132", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_133", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_134", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_135", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_136", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_137", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_138", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_139", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_140", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_141", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_142", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_143", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_144", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_145", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_146", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_147", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_148", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_149", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_150", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_151", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_152", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_153", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_154", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_155", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_156", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_157", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_158", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_159", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_160", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_161", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_162", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_163", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_164", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_165", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_166", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_167", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_168", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_169", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_170", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_171", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_172", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_173", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_174", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_175", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_176", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_177", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_178", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_179", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_180", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_181", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_182", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_183", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_184", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_185", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_186", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_187", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_188", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_189", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_190", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_191", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_0", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_1", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_2", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_3", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_4", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_5", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_6", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_7", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_8", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_9", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_10", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_11", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_12", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_13", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_14", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_15", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_16", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_17", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_18", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_19", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_20", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_21", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_22", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_23", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_24", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_25", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_26", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_27", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_28", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_29", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_30", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_31", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_32", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_33", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_34", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_35", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_36", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_37", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_38", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_39", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_40", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_41", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_42", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_43", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_44", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_45", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_46", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_47", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_48", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_49", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_50", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_51", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_52", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_53", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_54", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_55", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_56", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_57", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_58", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_59", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_60", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_61", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_62", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_63", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_64", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_65", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_66", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_67", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_68", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_69", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_70", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_71", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_72", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_73", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_74", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_75", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_76", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_77", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_78", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_79", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_80", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_81", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_82", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_83", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_84", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_85", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_86", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_87", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_88", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_89", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_90", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_91", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_92", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_93", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_94", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_95", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_96", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_97", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_98", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_99", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_100", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_101", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_102", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_103", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_104", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_105", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_106", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_107", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_108", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_109", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_110", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_111", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_112", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_113", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_114", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_115", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_116", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_117", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_118", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_119", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_120", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_121", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_122", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_123", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_124", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_125", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_126", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_127", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_128", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_129", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_130", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_131", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_132", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_133", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_134", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_135", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_136", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_137", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_138", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_139", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_140", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_141", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_142", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_143", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_trompa", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_cola", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_brocal", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_tapa_i", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_tapa_d", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_mantelete", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_0", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_1", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_2", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_3", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_4", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_5", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_6", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_7", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_8", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_9", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_10", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_11", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_ta", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_tb", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_0", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_1", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_2", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_3", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_4", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_5", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_6", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_7", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_8", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_9", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_10", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_11", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_ta", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_tb", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_0", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_1", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_2", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_3", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_4", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_5", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_6", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_7", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_8", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_9", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_10", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_11", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_ta", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_tb", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_antena", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F)),
            ModeloMilitarTanque::crearCapa,
            16.0F,
            ModeloMilitarTanque::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", 0.0F, 0.0F)));

    private ModeloMilitarTanque() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        piezas5(g0);
        piezas6(g0);
        piezas7(g0);
        piezas8(g0);
        piezas9(g0);
        piezas10(g0);
        piezas11(g0);
        piezas12(g0);
        piezas13(g0);
        piezas14(g0);
        piezas15(g0);
        piezas16(g0);
        piezas17(g0);
        piezas18(g0);
        piezas19(g0);
        piezas20(g0);
        piezas21(g0);
        piezas22(g0);
        piezas23(g0);
        piezas24(g0);
        piezas25(g0);
        piezas26(g0);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        escalas0(g0);
        escalas1(g0);
        escalas2(g0);
        escalas3(g0);
        escalas4(g0);
        escalas5(g0);
        escalas6(g0);
        escalas7(g0);
        escalas8(g0);
        escalas9(g0);
        escalas10(g0);
        escalas11(g0);
        escalas12(g0);
        escalas13(g0);
        escalas14(g0);
        escalas15(g0);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("oruga_i_0", CubeListBuilder.create().texOffs(718, 146).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-39.08869134326942F, -16.78765806715918F, -15.0F, 0.0F, 0.0F, 2.969987190077298F));
        g.addOrReplaceChild("oruga_i_1", CubeListBuilder.create().texOffs(744, 146).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-41.357407719937626F, -15.92617378184169F, -15.0F, 0.0F, 0.0F, 2.5873773377070064F));
        g.addOrReplaceChild("oruga_i_2", CubeListBuilder.create().texOffs(770, 146).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.14036379656061F, -14.280049665786313F, -15.0F, 0.0F, 0.0F, 2.204767813461447F));
        g.addOrReplaceChild("oruga_i_3", CubeListBuilder.create().texOffs(796, 146).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.179791616025554F, -12.087378082688517F, -15.0F, 0.0F, 0.0F, 1.8221585404947997F));
        g.addOrReplaceChild("oruga_i_4", CubeListBuilder.create().texOffs(822, 146).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.3254388275073F, -9.665250563104115F, -15.0F, 0.0F, 0.0F, 1.4395494419268904F));
        g.addOrReplaceChild("oruga_i_5", CubeListBuilder.create().texOffs(848, 146).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.55628113046316F, -7.363915881203536F, -15.0F, 0.0F, 0.0F, 1.056940440853727F));
        g.addOrReplaceChild("oruga_i_6", CubeListBuilder.create().texOffs(874, 146).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-41.9835560146648F, -5.516148384346913F, -15.0F, 0.0F, 0.0F, 0.6743314603579577F));
        g.addOrReplaceChild("oruga_i_7", CubeListBuilder.create().texOffs(900, 146).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-39.859734155488965F, -4.295816625931476F, -15.0F, 0.0F, 0.0F, 0.3695451984390541F));
        g.addOrReplaceChild("oruga_i_8", CubeListBuilder.create().texOffs(926, 146).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-37.53046695935565F, -3.4279633074808222F, -15.0F, 0.0F, 0.0F, 0.3437721363240487F));
        g.addOrReplaceChild("oruga_i_9", CubeListBuilder.create().texOffs(952, 146).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-35.18898648722155F, -2.5897444124160076F, -15.0F, 0.0F, 0.0F, 0.3437721363240479F));
        g.addOrReplaceChild("oruga_i_10", CubeListBuilder.create().texOffs(978, 146).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-32.84750601508744F, -1.7515255173511919F, -15.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_i_11", CubeListBuilder.create().texOffs(0, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-30.50602554295333F, -0.9133066222863764F, -15.0F, 0.0F, 0.0F, 0.3437721363240479F));
        g.addOrReplaceChild("oruga_i_12", CubeListBuilder.create().texOffs(26, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-28.125167485093982F, -0.24709858737698442F, -15.0F, 0.0F, 0.0F, 0.20142481296552456F));
        g.addOrReplaceChild("oruga_i_13", CubeListBuilder.create().texOffs(52, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-25.6715524058229F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_14", CubeListBuilder.create().texOffs(78, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-23.184557890865328F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_15", CubeListBuilder.create().texOffs(104, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-20.697563375907762F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_16", CubeListBuilder.create().texOffs(130, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-18.21056886095019F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_17", CubeListBuilder.create().texOffs(156, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-15.72357434599262F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_18", CubeListBuilder.create().texOffs(182, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-13.236579831035051F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_19", CubeListBuilder.create().texOffs(208, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-10.749585316077482F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_20", CubeListBuilder.create().texOffs(234, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-8.262590801119913F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_21", CubeListBuilder.create().texOffs(260, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-5.77559628616234F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_22", CubeListBuilder.create().texOffs(286, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-3.2886017712047675F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_23", CubeListBuilder.create().texOffs(312, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-0.8016072562471983F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_24", CubeListBuilder.create().texOffs(338, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(1.6853872587103709F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_25", CubeListBuilder.create().texOffs(364, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(4.172381773667944F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_26", CubeListBuilder.create().texOffs(390, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(6.659376288625516F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_27", CubeListBuilder.create().texOffs(416, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(9.146370803583089F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_28", CubeListBuilder.create().texOffs(442, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(11.633365318540655F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_29", CubeListBuilder.create().texOffs(468, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(14.12035983349822F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_30", CubeListBuilder.create().texOffs(494, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(16.607354348455793F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_31", CubeListBuilder.create().texOffs(520, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(19.094348863413366F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_32", CubeListBuilder.create().texOffs(546, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(21.58134337837094F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_33", CubeListBuilder.create().texOffs(572, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(24.06833789332851F, 0.0F, -15.0F));
        g.addOrReplaceChild("oruga_i_34", CubeListBuilder.create().texOffs(598, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(26.539920597581805F, -0.14433506453679645F, -15.0F, 0.0F, 0.0F, -0.11699182204664443F));
        g.addOrReplaceChild("oruga_i_35", CubeListBuilder.create().texOffs(624, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(28.95827019662835F, -0.6486099534517458F, -15.0F, 0.0F, 0.0F, -0.2936602088136012F));
        g.addOrReplaceChild("oruga_i_36", CubeListBuilder.create().texOffs(650, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(31.338798501172434F, -1.3684896022080535F, -15.0F, 0.0F, 0.0F, -0.2936602088136007F));
        g.addOrReplaceChild("oruga_i_37", CubeListBuilder.create().texOffs(676, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(33.71932680571652F, -2.088369250964363F, -15.0F, 0.0F, 0.0F, -0.29366020881360116F));
        g.addOrReplaceChild("oruga_i_38", CubeListBuilder.create().texOffs(702, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(36.099855110260606F, -2.8082488997206703F, -15.0F, 0.0F, 0.0F, -0.2936602088136001F));
        g.addOrReplaceChild("oruga_i_39", CubeListBuilder.create().texOffs(728, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(38.477559016857825F, -3.536678505654626F, -15.0F, 0.0F, 0.0F, -0.3009002587142602F));
        g.addOrReplaceChild("oruga_i_40", CubeListBuilder.create().texOffs(754, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(40.699866820577725F, -4.578215200041898F, -15.0F, 0.0F, 0.0F, -0.5766351323615191F));
        g.addOrReplaceChild("oruga_i_41", CubeListBuilder.create().texOffs(780, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(42.41099621827497F, -6.283978376701335F, -15.0F, 0.0F, 0.0F, -0.9910279087100904F));
        g.addOrReplaceChild("oruga_i_42", CubeListBuilder.create().texOffs(806, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.29047870466738F, -8.53431639891876F, -15.0F, 0.0F, 0.0F, -1.405420577720842F));
        g.addOrReplaceChild("oruga_i_43", CubeListBuilder.create().texOffs(832, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.18943858645101F, -10.948423413591168F, -15.0F, 0.0F, 0.0F, -1.8198140547763124F));
        g.addOrReplaceChild("oruga_i_44", CubeListBuilder.create().texOffs(858, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(42.12444763181553F, -13.117316772463848F, -15.0F, 0.0F, 0.0F, -2.234660485900944F));
        g.addOrReplaceChild("oruga_i_45", CubeListBuilder.create().texOffs(884, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(40.27574029066581F, -14.673158913115241F, -15.0F, 0.0F, 0.0F, -2.649363014232945F));
        g.addOrReplaceChild("oruga_i_46", CubeListBuilder.create().texOffs(910, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(37.95599881137115F, -15.386595356429966F, -15.0F, 0.0F, 0.0F, -3.0364402686314595F));
        g.addOrReplaceChild("oruga_i_47", CubeListBuilder.create().texOffs(936, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(35.48098309338874F, -15.541299755196246F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_48", CubeListBuilder.create().texOffs(962, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(32.9944793303723F, -15.590703742222672F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_49", CubeListBuilder.create().texOffs(988, 159).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(30.507975567355857F, -15.640107729249099F, -15.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_50", CubeListBuilder.create().texOffs(0, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(28.021471804339413F, -15.689511716275526F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_51", CubeListBuilder.create().texOffs(26, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(25.534968041322966F, -15.738915703301954F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_52", CubeListBuilder.create().texOffs(52, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(23.048464278306525F, -15.788319690328382F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_53", CubeListBuilder.create().texOffs(78, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(20.56196051529008F, -15.837723677354807F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_54", CubeListBuilder.create().texOffs(104, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(18.075456752273638F, -15.887127664381232F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_55", CubeListBuilder.create().texOffs(130, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(15.58895298925719F, -15.93653165140766F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_56", CubeListBuilder.create().texOffs(156, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(13.102449226240747F, -15.98593563843409F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_57", CubeListBuilder.create().texOffs(182, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(10.615945463224316F, -16.035339625460516F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_58", CubeListBuilder.create().texOffs(208, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(8.12944170020787F, -16.08474361248694F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_59", CubeListBuilder.create().texOffs(234, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(5.642937937191427F, -16.13414759951337F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_60", CubeListBuilder.create().texOffs(260, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(3.1564341741749793F, -16.183551586539796F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_61", CubeListBuilder.create().texOffs(286, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(0.669930411158532F, -16.232955573566223F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_62", CubeListBuilder.create().texOffs(312, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-1.8165733518579206F, -16.282359560592646F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_63", CubeListBuilder.create().texOffs(338, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-4.303077114874364F, -16.331763547619076F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_64", CubeListBuilder.create().texOffs(364, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-6.7895808778907885F, -16.381167534645503F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_65", CubeListBuilder.create().texOffs(390, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-9.276084640907236F, -16.43057152167193F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_66", CubeListBuilder.create().texOffs(416, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-11.76258840392368F, -16.479975508698352F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_67", CubeListBuilder.create().texOffs(442, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-14.249092166940123F, -16.529379495724783F, -15.0F, 0.0F, 0.0F, -3.1217264107930744F));
        g.addOrReplaceChild("oruga_i_68", CubeListBuilder.create().texOffs(468, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-16.735595929956567F, -16.578783482751213F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_69", CubeListBuilder.create().texOffs(494, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-19.222099692973014F, -16.628187469777636F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_70", CubeListBuilder.create().texOffs(520, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-21.70860345598946F, -16.677591456804066F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_71", CubeListBuilder.create().texOffs(546, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-24.19510721900589F, -16.726995443830493F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_72", CubeListBuilder.create().texOffs(572, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-26.681610982022335F, -16.77639943085692F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_73", CubeListBuilder.create().texOffs(598, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-29.168114745038785F, -16.825803417883343F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_74", CubeListBuilder.create().texOffs(624, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-31.65461850805523F, -16.875207404909773F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_75", CubeListBuilder.create().texOffs(650, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-34.14112227107167F, -16.9246113919362F, -15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_76", CubeListBuilder.create().texOffs(676, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-36.62762603408812F, -16.974015378962626F, -15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_77", CubeListBuilder.create().texOffs(702, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-39.08869134326942F, -16.78765806715918F, -19.0F, 0.0F, 0.0F, 2.969987190077298F));
        g.addOrReplaceChild("oruga_i_78", CubeListBuilder.create().texOffs(728, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-41.357407719937626F, -15.92617378184169F, -19.0F, 0.0F, 0.0F, 2.5873773377070064F));
        g.addOrReplaceChild("oruga_i_79", CubeListBuilder.create().texOffs(754, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.14036379656061F, -14.280049665786313F, -19.0F, 0.0F, 0.0F, 2.204767813461447F));
        g.addOrReplaceChild("oruga_i_80", CubeListBuilder.create().texOffs(780, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.179791616025554F, -12.087378082688517F, -19.0F, 0.0F, 0.0F, 1.8221585404947997F));
        g.addOrReplaceChild("oruga_i_81", CubeListBuilder.create().texOffs(806, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.3254388275073F, -9.665250563104115F, -19.0F, 0.0F, 0.0F, 1.4395494419268904F));
        g.addOrReplaceChild("oruga_i_82", CubeListBuilder.create().texOffs(832, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.55628113046316F, -7.363915881203536F, -19.0F, 0.0F, 0.0F, 1.056940440853727F));
        g.addOrReplaceChild("oruga_i_83", CubeListBuilder.create().texOffs(858, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-41.9835560146648F, -5.516148384346913F, -19.0F, 0.0F, 0.0F, 0.6743314603579577F));
        g.addOrReplaceChild("oruga_i_84", CubeListBuilder.create().texOffs(884, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-39.859734155488965F, -4.295816625931476F, -19.0F, 0.0F, 0.0F, 0.3695451984390541F));
        g.addOrReplaceChild("oruga_i_85", CubeListBuilder.create().texOffs(910, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-37.53046695935565F, -3.4279633074808222F, -19.0F, 0.0F, 0.0F, 0.3437721363240487F));
        g.addOrReplaceChild("oruga_i_86", CubeListBuilder.create().texOffs(936, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-35.18898648722155F, -2.5897444124160076F, -19.0F, 0.0F, 0.0F, 0.3437721363240479F));
        g.addOrReplaceChild("oruga_i_87", CubeListBuilder.create().texOffs(962, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-32.84750601508744F, -1.7515255173511919F, -19.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_i_88", CubeListBuilder.create().texOffs(988, 168).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-30.50602554295333F, -0.9133066222863764F, -19.0F, 0.0F, 0.0F, 0.3437721363240479F));
        g.addOrReplaceChild("oruga_i_89", CubeListBuilder.create().texOffs(0, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-28.125167485093982F, -0.24709858737698442F, -19.0F, 0.0F, 0.0F, 0.20142481296552456F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("oruga_i_90", CubeListBuilder.create().texOffs(26, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-25.6715524058229F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_91", CubeListBuilder.create().texOffs(52, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-23.184557890865328F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_92", CubeListBuilder.create().texOffs(78, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-20.697563375907762F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_93", CubeListBuilder.create().texOffs(104, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-18.21056886095019F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_94", CubeListBuilder.create().texOffs(130, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-15.72357434599262F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_95", CubeListBuilder.create().texOffs(156, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-13.236579831035051F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_96", CubeListBuilder.create().texOffs(182, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-10.749585316077482F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_97", CubeListBuilder.create().texOffs(208, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-8.262590801119913F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_98", CubeListBuilder.create().texOffs(234, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-5.77559628616234F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_99", CubeListBuilder.create().texOffs(260, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-3.2886017712047675F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_100", CubeListBuilder.create().texOffs(286, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-0.8016072562471983F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_101", CubeListBuilder.create().texOffs(312, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(1.6853872587103709F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_102", CubeListBuilder.create().texOffs(338, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(4.172381773667944F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_103", CubeListBuilder.create().texOffs(364, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(6.659376288625516F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_104", CubeListBuilder.create().texOffs(390, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(9.146370803583089F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_105", CubeListBuilder.create().texOffs(416, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(11.633365318540655F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_106", CubeListBuilder.create().texOffs(442, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(14.12035983349822F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_107", CubeListBuilder.create().texOffs(468, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(16.607354348455793F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_108", CubeListBuilder.create().texOffs(494, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(19.094348863413366F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_109", CubeListBuilder.create().texOffs(520, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(21.58134337837094F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_110", CubeListBuilder.create().texOffs(546, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(24.06833789332851F, 0.0F, -19.0F));
        g.addOrReplaceChild("oruga_i_111", CubeListBuilder.create().texOffs(572, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(26.539920597581805F, -0.14433506453679645F, -19.0F, 0.0F, 0.0F, -0.11699182204664443F));
        g.addOrReplaceChild("oruga_i_112", CubeListBuilder.create().texOffs(598, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(28.95827019662835F, -0.6486099534517458F, -19.0F, 0.0F, 0.0F, -0.2936602088136012F));
        g.addOrReplaceChild("oruga_i_113", CubeListBuilder.create().texOffs(624, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(31.338798501172434F, -1.3684896022080535F, -19.0F, 0.0F, 0.0F, -0.2936602088136007F));
        g.addOrReplaceChild("oruga_i_114", CubeListBuilder.create().texOffs(650, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(33.71932680571652F, -2.088369250964363F, -19.0F, 0.0F, 0.0F, -0.29366020881360116F));
        g.addOrReplaceChild("oruga_i_115", CubeListBuilder.create().texOffs(676, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(36.099855110260606F, -2.8082488997206703F, -19.0F, 0.0F, 0.0F, -0.2936602088136001F));
        g.addOrReplaceChild("oruga_i_116", CubeListBuilder.create().texOffs(702, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(38.477559016857825F, -3.536678505654626F, -19.0F, 0.0F, 0.0F, -0.3009002587142602F));
        g.addOrReplaceChild("oruga_i_117", CubeListBuilder.create().texOffs(728, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(40.699866820577725F, -4.578215200041898F, -19.0F, 0.0F, 0.0F, -0.5766351323615191F));
        g.addOrReplaceChild("oruga_i_118", CubeListBuilder.create().texOffs(754, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(42.41099621827497F, -6.283978376701335F, -19.0F, 0.0F, 0.0F, -0.9910279087100904F));
        g.addOrReplaceChild("oruga_i_119", CubeListBuilder.create().texOffs(780, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.29047870466738F, -8.53431639891876F, -19.0F, 0.0F, 0.0F, -1.405420577720842F));
        g.addOrReplaceChild("oruga_i_120", CubeListBuilder.create().texOffs(806, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.18943858645101F, -10.948423413591168F, -19.0F, 0.0F, 0.0F, -1.8198140547763124F));
        g.addOrReplaceChild("oruga_i_121", CubeListBuilder.create().texOffs(832, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(42.12444763181553F, -13.117316772463848F, -19.0F, 0.0F, 0.0F, -2.234660485900944F));
        g.addOrReplaceChild("oruga_i_122", CubeListBuilder.create().texOffs(858, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(40.27574029066581F, -14.673158913115241F, -19.0F, 0.0F, 0.0F, -2.649363014232945F));
        g.addOrReplaceChild("oruga_i_123", CubeListBuilder.create().texOffs(884, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(37.95599881137115F, -15.386595356429966F, -19.0F, 0.0F, 0.0F, -3.0364402686314595F));
        g.addOrReplaceChild("oruga_i_124", CubeListBuilder.create().texOffs(910, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(35.48098309338874F, -15.541299755196246F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_125", CubeListBuilder.create().texOffs(936, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(32.9944793303723F, -15.590703742222672F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_126", CubeListBuilder.create().texOffs(962, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(30.507975567355857F, -15.640107729249099F, -19.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_127", CubeListBuilder.create().texOffs(988, 177).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(28.021471804339413F, -15.689511716275526F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_128", CubeListBuilder.create().texOffs(0, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(25.534968041322966F, -15.738915703301954F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_129", CubeListBuilder.create().texOffs(26, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(23.048464278306525F, -15.788319690328382F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_130", CubeListBuilder.create().texOffs(52, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(20.56196051529008F, -15.837723677354807F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_131", CubeListBuilder.create().texOffs(78, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(18.075456752273638F, -15.887127664381232F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_132", CubeListBuilder.create().texOffs(104, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(15.58895298925719F, -15.93653165140766F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_133", CubeListBuilder.create().texOffs(130, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(13.102449226240747F, -15.98593563843409F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_134", CubeListBuilder.create().texOffs(156, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(10.615945463224316F, -16.035339625460516F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_135", CubeListBuilder.create().texOffs(182, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(8.12944170020787F, -16.08474361248694F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_136", CubeListBuilder.create().texOffs(208, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(5.642937937191427F, -16.13414759951337F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_137", CubeListBuilder.create().texOffs(234, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(3.1564341741749793F, -16.183551586539796F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_138", CubeListBuilder.create().texOffs(260, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(0.669930411158532F, -16.232955573566223F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_139", CubeListBuilder.create().texOffs(286, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-1.8165733518579206F, -16.282359560592646F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_140", CubeListBuilder.create().texOffs(312, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-4.303077114874364F, -16.331763547619076F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_141", CubeListBuilder.create().texOffs(338, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-6.7895808778907885F, -16.381167534645503F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_142", CubeListBuilder.create().texOffs(364, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-9.276084640907236F, -16.43057152167193F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_143", CubeListBuilder.create().texOffs(390, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-11.76258840392368F, -16.479975508698352F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_144", CubeListBuilder.create().texOffs(416, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-14.249092166940123F, -16.529379495724783F, -19.0F, 0.0F, 0.0F, -3.1217264107930744F));
        g.addOrReplaceChild("oruga_i_145", CubeListBuilder.create().texOffs(442, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-16.735595929956567F, -16.578783482751213F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_146", CubeListBuilder.create().texOffs(468, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-19.222099692973014F, -16.628187469777636F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_147", CubeListBuilder.create().texOffs(494, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-21.70860345598946F, -16.677591456804066F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_148", CubeListBuilder.create().texOffs(520, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-24.19510721900589F, -16.726995443830493F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_149", CubeListBuilder.create().texOffs(546, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-26.681610982022335F, -16.77639943085692F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_150", CubeListBuilder.create().texOffs(572, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-29.168114745038785F, -16.825803417883343F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_151", CubeListBuilder.create().texOffs(598, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-31.65461850805523F, -16.875207404909773F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_i_152", CubeListBuilder.create().texOffs(624, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-34.14112227107167F, -16.9246113919362F, -19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_153", CubeListBuilder.create().texOffs(650, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-36.62762603408812F, -16.974015378962626F, -19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("rodillo_i0_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-27.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i0_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i0_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_i0_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i0_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-27.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i1_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-16.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i1_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i1_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_i1_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i1_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-16.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i2_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-5.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i2_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i2_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_i2_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i2_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-5.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i3_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(4.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i3_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i3_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_i3_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i3_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(4.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i4_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(15.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i4_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i4_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_i4_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i4_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(15.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i5_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(26.0F, -5.5F, 0.0F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("rodillo_i5_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i5_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_i5_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i5_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(26.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("motriz_i_0", CubeListBuilder.create().texOffs(624, 256).addBox(-5.5F, -1.0F, -19.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(900, 109).addBox(-1.0F, -5.5F, -19.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(-38.0F, -10.5F, 0.0F));
        g.addOrReplaceChild("motriz_i_1", CubeListBuilder.create().texOffs(654, 256).addBox(-5.5F, -1.0F, -19.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(912, 109).addBox(-1.0F, -5.5F, -19.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("motriz_i_2", CubeListBuilder.create().texOffs(684, 256).addBox(-5.5F, -1.0F, -19.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(924, 109).addBox(-1.0F, -5.5F, -19.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("motriz_i_3", CubeListBuilder.create().texOffs(714, 256).addBox(-5.5F, -1.0F, -19.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(936, 109).addBox(-1.0F, -5.5F, -19.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("motriz_i_cara", CubeListBuilder.create().texOffs(0, 109).addBox(-16.5F, -16.5F, -19.0F, 33.0F, 33.0F, 4.0F), PartPose.offset(-38.0F, -10.5F, 0.0F));
        g.addOrReplaceChild("tensora_i_0", CubeListBuilder.create().texOffs(744, 256).addBox(-5.0F, -1.0F, -19.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(948, 109).addBox(-1.0F, -5.0F, -19.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(684, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(298, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(37.5F, -9.5F, 0.0F));
        g.addOrReplaceChild("tensora_i_1", CubeListBuilder.create().texOffs(772, 256).addBox(-5.0F, -1.0F, -19.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(960, 109).addBox(-1.0F, -5.0F, -19.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(690, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(302, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("tensora_i_2", CubeListBuilder.create().texOffs(800, 256).addBox(-5.0F, -1.0F, -19.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(972, 109).addBox(-1.0F, -5.0F, -19.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(306, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("tensora_i_3", CubeListBuilder.create().texOffs(828, 256).addBox(-5.0F, -1.0F, -19.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(984, 109).addBox(-1.0F, -5.0F, -19.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(702, 334).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(310, 327).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("tensora_i_cara", CubeListBuilder.create().texOffs(74, 109).addBox(-15.0F, -15.0F, -19.0F, 30.0F, 30.0F, 4.0F), PartPose.offset(37.5F, -9.5F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_i0_0", CubeListBuilder.create().texOffs(360, 315).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1004, 289).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(-12.0F, -13.983443708609272F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_i0_1", CubeListBuilder.create().texOffs(370, 315).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 289).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_alto_i0_2", CubeListBuilder.create().texOffs(380, 315).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1016, 289).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_alto_i0_3", CubeListBuilder.create().texOffs(390, 315).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 294).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_alto_i0_cara", CubeListBuilder.create().texOffs(616, 146).addBox(-4.5F, -4.5F, -18.0F, 9.0F, 9.0F, 2.0F), PartPose.offset(-12.0F, -13.983443708609272F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_i1_0", CubeListBuilder.create().texOffs(360, 315).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1004, 289).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(12.0F, -13.506622516556291F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_i1_1", CubeListBuilder.create().texOffs(370, 315).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 289).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_alto_i1_2", CubeListBuilder.create().texOffs(380, 315).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1016, 289).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_alto_i1_3", CubeListBuilder.create().texOffs(390, 315).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 294).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_alto_i1_cara", CubeListBuilder.create().texOffs(616, 146).addBox(-4.5F, -4.5F, -18.0F, 9.0F, 9.0F, 2.0F), PartPose.offset(12.0F, -13.506622516556291F, 0.0F));
        g.addOrReplaceChild("oruga_d_0", CubeListBuilder.create().texOffs(676, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-39.08869134326942F, -16.78765806715918F, 15.0F, 0.0F, 0.0F, 2.969987190077298F));
        g.addOrReplaceChild("oruga_d_1", CubeListBuilder.create().texOffs(702, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-41.357407719937626F, -15.92617378184169F, 15.0F, 0.0F, 0.0F, 2.5873773377070064F));
        g.addOrReplaceChild("oruga_d_2", CubeListBuilder.create().texOffs(728, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.14036379656061F, -14.280049665786313F, 15.0F, 0.0F, 0.0F, 2.204767813461447F));
        g.addOrReplaceChild("oruga_d_3", CubeListBuilder.create().texOffs(754, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.179791616025554F, -12.087378082688517F, 15.0F, 0.0F, 0.0F, 1.8221585404947997F));
        g.addOrReplaceChild("oruga_d_4", CubeListBuilder.create().texOffs(780, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.3254388275073F, -9.665250563104115F, 15.0F, 0.0F, 0.0F, 1.4395494419268904F));
        g.addOrReplaceChild("oruga_d_5", CubeListBuilder.create().texOffs(806, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.55628113046316F, -7.363915881203536F, 15.0F, 0.0F, 0.0F, 1.056940440853727F));
        g.addOrReplaceChild("oruga_d_6", CubeListBuilder.create().texOffs(832, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-41.9835560146648F, -5.516148384346913F, 15.0F, 0.0F, 0.0F, 0.6743314603579577F));
        g.addOrReplaceChild("oruga_d_7", CubeListBuilder.create().texOffs(858, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-39.859734155488965F, -4.295816625931476F, 15.0F, 0.0F, 0.0F, 0.3695451984390541F));
        g.addOrReplaceChild("oruga_d_8", CubeListBuilder.create().texOffs(884, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-37.53046695935565F, -3.4279633074808222F, 15.0F, 0.0F, 0.0F, 0.3437721363240487F));
        g.addOrReplaceChild("oruga_d_9", CubeListBuilder.create().texOffs(910, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-35.18898648722155F, -2.5897444124160076F, 15.0F, 0.0F, 0.0F, 0.3437721363240479F));
        g.addOrReplaceChild("oruga_d_10", CubeListBuilder.create().texOffs(936, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-32.84750601508744F, -1.7515255173511919F, 15.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_d_11", CubeListBuilder.create().texOffs(962, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-30.50602554295333F, -0.9133066222863764F, 15.0F, 0.0F, 0.0F, 0.3437721363240479F));
        g.addOrReplaceChild("oruga_d_12", CubeListBuilder.create().texOffs(988, 186).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-28.125167485093982F, -0.24709858737698442F, 15.0F, 0.0F, 0.0F, 0.20142481296552456F));
        g.addOrReplaceChild("oruga_d_13", CubeListBuilder.create().texOffs(0, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-25.6715524058229F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_14", CubeListBuilder.create().texOffs(26, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-23.184557890865328F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_15", CubeListBuilder.create().texOffs(52, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-20.697563375907762F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_16", CubeListBuilder.create().texOffs(78, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-18.21056886095019F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_17", CubeListBuilder.create().texOffs(104, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-15.72357434599262F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_18", CubeListBuilder.create().texOffs(130, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-13.236579831035051F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_19", CubeListBuilder.create().texOffs(156, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-10.749585316077482F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_20", CubeListBuilder.create().texOffs(182, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-8.262590801119913F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_21", CubeListBuilder.create().texOffs(208, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-5.77559628616234F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_22", CubeListBuilder.create().texOffs(234, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-3.2886017712047675F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_23", CubeListBuilder.create().texOffs(260, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-0.8016072562471983F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_24", CubeListBuilder.create().texOffs(286, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(1.6853872587103709F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_25", CubeListBuilder.create().texOffs(312, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(4.172381773667944F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_26", CubeListBuilder.create().texOffs(338, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(6.659376288625516F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_27", CubeListBuilder.create().texOffs(364, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(9.146370803583089F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_28", CubeListBuilder.create().texOffs(390, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(11.633365318540655F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_29", CubeListBuilder.create().texOffs(416, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(14.12035983349822F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_30", CubeListBuilder.create().texOffs(442, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(16.607354348455793F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_31", CubeListBuilder.create().texOffs(468, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(19.094348863413366F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_32", CubeListBuilder.create().texOffs(494, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(21.58134337837094F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_33", CubeListBuilder.create().texOffs(520, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(24.06833789332851F, 0.0F, 15.0F));
        g.addOrReplaceChild("oruga_d_34", CubeListBuilder.create().texOffs(546, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(26.539920597581805F, -0.14433506453679645F, 15.0F, 0.0F, 0.0F, -0.11699182204664443F));
        g.addOrReplaceChild("oruga_d_35", CubeListBuilder.create().texOffs(572, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(28.95827019662835F, -0.6486099534517458F, 15.0F, 0.0F, 0.0F, -0.2936602088136012F));
        g.addOrReplaceChild("oruga_d_36", CubeListBuilder.create().texOffs(598, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(31.338798501172434F, -1.3684896022080535F, 15.0F, 0.0F, 0.0F, -0.2936602088136007F));
        g.addOrReplaceChild("oruga_d_37", CubeListBuilder.create().texOffs(624, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(33.71932680571652F, -2.088369250964363F, 15.0F, 0.0F, 0.0F, -0.29366020881360116F));
        g.addOrReplaceChild("oruga_d_38", CubeListBuilder.create().texOffs(650, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(36.099855110260606F, -2.8082488997206703F, 15.0F, 0.0F, 0.0F, -0.2936602088136001F));
        g.addOrReplaceChild("oruga_d_39", CubeListBuilder.create().texOffs(676, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(38.477559016857825F, -3.536678505654626F, 15.0F, 0.0F, 0.0F, -0.3009002587142602F));
        g.addOrReplaceChild("oruga_d_40", CubeListBuilder.create().texOffs(702, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(40.699866820577725F, -4.578215200041898F, 15.0F, 0.0F, 0.0F, -0.5766351323615191F));
        g.addOrReplaceChild("oruga_d_41", CubeListBuilder.create().texOffs(728, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(42.41099621827497F, -6.283978376701335F, 15.0F, 0.0F, 0.0F, -0.9910279087100904F));
        g.addOrReplaceChild("oruga_d_42", CubeListBuilder.create().texOffs(754, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.29047870466738F, -8.53431639891876F, 15.0F, 0.0F, 0.0F, -1.405420577720842F));
        g.addOrReplaceChild("oruga_d_43", CubeListBuilder.create().texOffs(780, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.18943858645101F, -10.948423413591168F, 15.0F, 0.0F, 0.0F, -1.8198140547763124F));
        g.addOrReplaceChild("oruga_d_44", CubeListBuilder.create().texOffs(806, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(42.12444763181553F, -13.117316772463848F, 15.0F, 0.0F, 0.0F, -2.234660485900944F));
        g.addOrReplaceChild("oruga_d_45", CubeListBuilder.create().texOffs(832, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(40.27574029066581F, -14.673158913115241F, 15.0F, 0.0F, 0.0F, -2.649363014232945F));
        g.addOrReplaceChild("oruga_d_46", CubeListBuilder.create().texOffs(858, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(37.95599881137115F, -15.386595356429966F, 15.0F, 0.0F, 0.0F, -3.0364402686314595F));
        g.addOrReplaceChild("oruga_d_47", CubeListBuilder.create().texOffs(884, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(35.48098309338874F, -15.541299755196246F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_48", CubeListBuilder.create().texOffs(910, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(32.9944793303723F, -15.590703742222672F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_49", CubeListBuilder.create().texOffs(936, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(30.507975567355857F, -15.640107729249099F, 15.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_50", CubeListBuilder.create().texOffs(962, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(28.021471804339413F, -15.689511716275526F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_51", CubeListBuilder.create().texOffs(988, 195).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(25.534968041322966F, -15.738915703301954F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_52", CubeListBuilder.create().texOffs(0, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(23.048464278306525F, -15.788319690328382F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_53", CubeListBuilder.create().texOffs(26, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(20.56196051529008F, -15.837723677354807F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_54", CubeListBuilder.create().texOffs(52, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(18.075456752273638F, -15.887127664381232F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_55", CubeListBuilder.create().texOffs(78, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(15.58895298925719F, -15.93653165140766F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_56", CubeListBuilder.create().texOffs(104, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(13.102449226240747F, -15.98593563843409F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_57", CubeListBuilder.create().texOffs(130, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(10.615945463224316F, -16.035339625460516F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_58", CubeListBuilder.create().texOffs(156, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(8.12944170020787F, -16.08474361248694F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_59", CubeListBuilder.create().texOffs(182, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(5.642937937191427F, -16.13414759951337F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_60", CubeListBuilder.create().texOffs(208, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(3.1564341741749793F, -16.183551586539796F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_61", CubeListBuilder.create().texOffs(234, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(0.669930411158532F, -16.232955573566223F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_62", CubeListBuilder.create().texOffs(260, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-1.8165733518579206F, -16.282359560592646F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_63", CubeListBuilder.create().texOffs(286, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-4.303077114874364F, -16.331763547619076F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_64", CubeListBuilder.create().texOffs(312, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-6.7895808778907885F, -16.381167534645503F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_65", CubeListBuilder.create().texOffs(338, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-9.276084640907236F, -16.43057152167193F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("oruga_d_66", CubeListBuilder.create().texOffs(364, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-11.76258840392368F, -16.479975508698352F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_67", CubeListBuilder.create().texOffs(390, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-14.249092166940123F, -16.529379495724783F, 15.0F, 0.0F, 0.0F, -3.1217264107930744F));
        g.addOrReplaceChild("oruga_d_68", CubeListBuilder.create().texOffs(416, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-16.735595929956567F, -16.578783482751213F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_69", CubeListBuilder.create().texOffs(442, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-19.222099692973014F, -16.628187469777636F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_70", CubeListBuilder.create().texOffs(468, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-21.70860345598946F, -16.677591456804066F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_71", CubeListBuilder.create().texOffs(494, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-24.19510721900589F, -16.726995443830493F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_72", CubeListBuilder.create().texOffs(520, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-26.681610982022335F, -16.77639943085692F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_73", CubeListBuilder.create().texOffs(546, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-29.168114745038785F, -16.825803417883343F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_74", CubeListBuilder.create().texOffs(572, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-31.65461850805523F, -16.875207404909773F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_75", CubeListBuilder.create().texOffs(598, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-34.14112227107167F, -16.9246113919362F, 15.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_76", CubeListBuilder.create().texOffs(624, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-36.62762603408812F, -16.974015378962626F, 15.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_77", CubeListBuilder.create().texOffs(650, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-39.08869134326942F, -16.78765806715918F, 19.0F, 0.0F, 0.0F, 2.969987190077298F));
        g.addOrReplaceChild("oruga_d_78", CubeListBuilder.create().texOffs(676, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-41.357407719937626F, -15.92617378184169F, 19.0F, 0.0F, 0.0F, 2.5873773377070064F));
        g.addOrReplaceChild("oruga_d_79", CubeListBuilder.create().texOffs(702, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.14036379656061F, -14.280049665786313F, 19.0F, 0.0F, 0.0F, 2.204767813461447F));
        g.addOrReplaceChild("oruga_d_80", CubeListBuilder.create().texOffs(728, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.179791616025554F, -12.087378082688517F, 19.0F, 0.0F, 0.0F, 1.8221585404947997F));
        g.addOrReplaceChild("oruga_d_81", CubeListBuilder.create().texOffs(754, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.3254388275073F, -9.665250563104115F, 19.0F, 0.0F, 0.0F, 1.4395494419268904F));
        g.addOrReplaceChild("oruga_d_82", CubeListBuilder.create().texOffs(780, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.55628113046316F, -7.363915881203536F, 19.0F, 0.0F, 0.0F, 1.056940440853727F));
        g.addOrReplaceChild("oruga_d_83", CubeListBuilder.create().texOffs(806, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-41.9835560146648F, -5.516148384346913F, 19.0F, 0.0F, 0.0F, 0.6743314603579577F));
        g.addOrReplaceChild("oruga_d_84", CubeListBuilder.create().texOffs(832, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-39.859734155488965F, -4.295816625931476F, 19.0F, 0.0F, 0.0F, 0.3695451984390541F));
        g.addOrReplaceChild("oruga_d_85", CubeListBuilder.create().texOffs(858, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-37.53046695935565F, -3.4279633074808222F, 19.0F, 0.0F, 0.0F, 0.3437721363240487F));
        g.addOrReplaceChild("oruga_d_86", CubeListBuilder.create().texOffs(884, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-35.18898648722155F, -2.5897444124160076F, 19.0F, 0.0F, 0.0F, 0.3437721363240479F));
        g.addOrReplaceChild("oruga_d_87", CubeListBuilder.create().texOffs(910, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-32.84750601508744F, -1.7515255173511919F, 19.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_d_88", CubeListBuilder.create().texOffs(936, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-30.50602554295333F, -0.9133066222863764F, 19.0F, 0.0F, 0.0F, 0.3437721363240479F));
        g.addOrReplaceChild("oruga_d_89", CubeListBuilder.create().texOffs(962, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-28.125167485093982F, -0.24709858737698442F, 19.0F, 0.0F, 0.0F, 0.20142481296552456F));
        g.addOrReplaceChild("oruga_d_90", CubeListBuilder.create().texOffs(988, 204).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-25.6715524058229F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_91", CubeListBuilder.create().texOffs(0, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-23.184557890865328F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_92", CubeListBuilder.create().texOffs(26, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-20.697563375907762F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_93", CubeListBuilder.create().texOffs(52, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-18.21056886095019F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_94", CubeListBuilder.create().texOffs(78, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-15.72357434599262F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_95", CubeListBuilder.create().texOffs(104, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-13.236579831035051F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_96", CubeListBuilder.create().texOffs(130, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-10.749585316077482F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_97", CubeListBuilder.create().texOffs(156, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-8.262590801119913F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_98", CubeListBuilder.create().texOffs(182, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-5.77559628616234F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_99", CubeListBuilder.create().texOffs(208, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-3.2886017712047675F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_100", CubeListBuilder.create().texOffs(234, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(-0.8016072562471983F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_101", CubeListBuilder.create().texOffs(260, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(1.6853872587103709F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_102", CubeListBuilder.create().texOffs(286, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(4.172381773667944F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_103", CubeListBuilder.create().texOffs(312, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(6.659376288625516F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_104", CubeListBuilder.create().texOffs(338, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(9.146370803583089F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_105", CubeListBuilder.create().texOffs(364, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(11.633365318540655F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_106", CubeListBuilder.create().texOffs(390, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(14.12035983349822F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_107", CubeListBuilder.create().texOffs(416, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(16.607354348455793F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_108", CubeListBuilder.create().texOffs(442, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(19.094348863413366F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_109", CubeListBuilder.create().texOffs(468, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(21.58134337837094F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_110", CubeListBuilder.create().texOffs(494, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offset(24.06833789332851F, 0.0F, 19.0F));
        g.addOrReplaceChild("oruga_d_111", CubeListBuilder.create().texOffs(520, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(26.539920597581805F, -0.14433506453679645F, 19.0F, 0.0F, 0.0F, -0.11699182204664443F));
        g.addOrReplaceChild("oruga_d_112", CubeListBuilder.create().texOffs(546, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(28.95827019662835F, -0.6486099534517458F, 19.0F, 0.0F, 0.0F, -0.2936602088136012F));
        g.addOrReplaceChild("oruga_d_113", CubeListBuilder.create().texOffs(572, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(31.338798501172434F, -1.3684896022080535F, 19.0F, 0.0F, 0.0F, -0.2936602088136007F));
        g.addOrReplaceChild("oruga_d_114", CubeListBuilder.create().texOffs(598, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(33.71932680571652F, -2.088369250964363F, 19.0F, 0.0F, 0.0F, -0.29366020881360116F));
        g.addOrReplaceChild("oruga_d_115", CubeListBuilder.create().texOffs(624, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(36.099855110260606F, -2.8082488997206703F, 19.0F, 0.0F, 0.0F, -0.2936602088136001F));
        g.addOrReplaceChild("oruga_d_116", CubeListBuilder.create().texOffs(650, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(38.477559016857825F, -3.536678505654626F, 19.0F, 0.0F, 0.0F, -0.3009002587142602F));
        g.addOrReplaceChild("oruga_d_117", CubeListBuilder.create().texOffs(676, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(40.699866820577725F, -4.578215200041898F, 19.0F, 0.0F, 0.0F, -0.5766351323615191F));
        g.addOrReplaceChild("oruga_d_118", CubeListBuilder.create().texOffs(702, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(42.41099621827497F, -6.283978376701335F, 19.0F, 0.0F, 0.0F, -0.9910279087100904F));
        g.addOrReplaceChild("oruga_d_119", CubeListBuilder.create().texOffs(728, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.29047870466738F, -8.53431639891876F, 19.0F, 0.0F, 0.0F, -1.405420577720842F));
        g.addOrReplaceChild("oruga_d_120", CubeListBuilder.create().texOffs(754, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.18943858645101F, -10.948423413591168F, 19.0F, 0.0F, 0.0F, -1.8198140547763124F));
        g.addOrReplaceChild("oruga_d_121", CubeListBuilder.create().texOffs(780, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(42.12444763181553F, -13.117316772463848F, 19.0F, 0.0F, 0.0F, -2.234660485900944F));
        g.addOrReplaceChild("oruga_d_122", CubeListBuilder.create().texOffs(806, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(40.27574029066581F, -14.673158913115241F, 19.0F, 0.0F, 0.0F, -2.649363014232945F));
        g.addOrReplaceChild("oruga_d_123", CubeListBuilder.create().texOffs(832, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(37.95599881137115F, -15.386595356429966F, 19.0F, 0.0F, 0.0F, -3.0364402686314595F));
        g.addOrReplaceChild("oruga_d_124", CubeListBuilder.create().texOffs(858, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(35.48098309338874F, -15.541299755196246F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_125", CubeListBuilder.create().texOffs(884, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(32.9944793303723F, -15.590703742222672F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_126", CubeListBuilder.create().texOffs(910, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(30.507975567355857F, -15.640107729249099F, 19.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_127", CubeListBuilder.create().texOffs(936, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(28.021471804339413F, -15.689511716275526F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_128", CubeListBuilder.create().texOffs(962, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(25.534968041322966F, -15.738915703301954F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_129", CubeListBuilder.create().texOffs(988, 213).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(23.048464278306525F, -15.788319690328382F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_130", CubeListBuilder.create().texOffs(0, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(20.56196051529008F, -15.837723677354807F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_131", CubeListBuilder.create().texOffs(26, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(18.075456752273638F, -15.887127664381232F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_132", CubeListBuilder.create().texOffs(52, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(15.58895298925719F, -15.93653165140766F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_133", CubeListBuilder.create().texOffs(78, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(13.102449226240747F, -15.98593563843409F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_134", CubeListBuilder.create().texOffs(104, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(10.615945463224316F, -16.035339625460516F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_135", CubeListBuilder.create().texOffs(130, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(8.12944170020787F, -16.08474361248694F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_136", CubeListBuilder.create().texOffs(156, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(5.642937937191427F, -16.13414759951337F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_137", CubeListBuilder.create().texOffs(182, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(3.1564341741749793F, -16.183551586539796F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_138", CubeListBuilder.create().texOffs(208, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(0.669930411158532F, -16.232955573566223F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_139", CubeListBuilder.create().texOffs(234, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-1.8165733518579206F, -16.282359560592646F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_140", CubeListBuilder.create().texOffs(260, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-4.303077114874364F, -16.331763547619076F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_141", CubeListBuilder.create().texOffs(286, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-6.7895808778907885F, -16.381167534645503F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_142", CubeListBuilder.create().texOffs(312, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-9.276084640907236F, -16.43057152167193F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_143", CubeListBuilder.create().texOffs(338, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-11.76258840392368F, -16.479975508698352F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_144", CubeListBuilder.create().texOffs(364, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-14.249092166940123F, -16.529379495724783F, 19.0F, 0.0F, 0.0F, -3.1217264107930744F));
        g.addOrReplaceChild("oruga_d_145", CubeListBuilder.create().texOffs(390, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-16.735595929956567F, -16.578783482751213F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_146", CubeListBuilder.create().texOffs(416, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-19.222099692973014F, -16.628187469777636F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_147", CubeListBuilder.create().texOffs(442, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-21.70860345598946F, -16.677591456804066F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_148", CubeListBuilder.create().texOffs(468, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-24.19510721900589F, -16.726995443830493F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_149", CubeListBuilder.create().texOffs(494, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-26.681610982022335F, -16.77639943085692F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_150", CubeListBuilder.create().texOffs(520, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-29.168114745038785F, -16.825803417883343F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_151", CubeListBuilder.create().texOffs(546, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-31.65461850805523F, -16.875207404909773F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("oruga_d_152", CubeListBuilder.create().texOffs(572, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-34.14112227107167F, -16.9246113919362F, 19.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_153", CubeListBuilder.create().texOffs(598, 222).addBox(-2.5F, -1.0F, -4.0F, 5.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-36.62762603408812F, -16.974015378962626F, 19.0F, 0.0F, 0.0F, -3.121726410793076F));
        g.addOrReplaceChild("rodillo_d0_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-27.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d0_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("rodillo_d0_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d0_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d0_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-27.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d1_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-16.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d1_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_d1_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d1_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d1_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-16.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d2_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-5.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d2_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_d2_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d2_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d2_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-5.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d3_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(4.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d3_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_d3_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d3_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d3_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(4.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d4_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(15.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d4_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_d4_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d4_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d4_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(15.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d5_0", CubeListBuilder.create().texOffs(856, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(26.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d5_1", CubeListBuilder.create().texOffs(882, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_d5_2", CubeListBuilder.create().texOffs(908, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d5_3", CubeListBuilder.create().texOffs(934, 256).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d5_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(26.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("motriz_d_0", CubeListBuilder.create().texOffs(624, 256).addBox(-5.5F, -1.0F, 15.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(900, 109).addBox(-1.0F, -5.5F, 15.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(-38.0F, -10.5F, 0.0F));
        g.addOrReplaceChild("motriz_d_1", CubeListBuilder.create().texOffs(654, 256).addBox(-5.5F, -1.0F, 15.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(912, 109).addBox(-1.0F, -5.5F, 15.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("motriz_d_2", CubeListBuilder.create().texOffs(684, 256).addBox(-5.5F, -1.0F, 15.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(924, 109).addBox(-1.0F, -5.5F, 15.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("motriz_d_3", CubeListBuilder.create().texOffs(714, 256).addBox(-5.5F, -1.0F, 15.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(936, 109).addBox(-1.0F, -5.5F, 15.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("motriz_d_cara", CubeListBuilder.create().texOffs(0, 109).addBox(-16.5F, -16.5F, 15.0F, 33.0F, 33.0F, 4.0F), PartPose.offset(-38.0F, -10.5F, 0.0F));
        g.addOrReplaceChild("tensora_d_0", CubeListBuilder.create().texOffs(744, 256).addBox(-5.0F, -1.0F, 15.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(948, 109).addBox(-1.0F, -5.0F, 15.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(732, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(330, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(37.5F, -9.5F, 0.0F));
        g.addOrReplaceChild("tensora_d_1", CubeListBuilder.create().texOffs(772, 256).addBox(-5.0F, -1.0F, 15.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(960, 109).addBox(-1.0F, -5.0F, 15.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(738, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(334, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("tensora_d_2", CubeListBuilder.create().texOffs(800, 256).addBox(-5.0F, -1.0F, 15.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(972, 109).addBox(-1.0F, -5.0F, 15.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(744, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(338, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("tensora_d_3", CubeListBuilder.create().texOffs(828, 256).addBox(-5.0F, -1.0F, 15.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(984, 109).addBox(-1.0F, -5.0F, 15.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(750, 334).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(342, 327).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("tensora_d_cara", CubeListBuilder.create().texOffs(74, 109).addBox(-15.0F, -15.0F, 15.0F, 30.0F, 30.0F, 4.0F), PartPose.offset(37.5F, -9.5F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_d0_0", CubeListBuilder.create().texOffs(360, 315).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1004, 289).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(-12.0F, -13.983443708609272F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_d0_1", CubeListBuilder.create().texOffs(370, 315).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 289).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_alto_d0_2", CubeListBuilder.create().texOffs(380, 315).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1016, 289).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_alto_d0_3", CubeListBuilder.create().texOffs(390, 315).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 294).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_alto_d0_cara", CubeListBuilder.create().texOffs(616, 146).addBox(-4.5F, -4.5F, 16.0F, 9.0F, 9.0F, 2.0F), PartPose.offset(-12.0F, -13.983443708609272F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_d1_0", CubeListBuilder.create().texOffs(360, 315).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1004, 289).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(12.0F, -13.506622516556291F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_d1_1", CubeListBuilder.create().texOffs(370, 315).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1010, 289).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_alto_d1_2", CubeListBuilder.create().texOffs(380, 315).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(1016, 289).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_alto_d1_3", CubeListBuilder.create().texOffs(390, 315).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(0, 294).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_alto_d1_cara", CubeListBuilder.create().texOffs(616, 146).addBox(-4.5F, -4.5F, 16.0F, 9.0F, 9.0F, 2.0F), PartPose.offset(12.0F, -13.506622516556291F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_0", CubeListBuilder.create().texOffs(824, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.875F, -11.826562500000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_1", CubeListBuilder.create().texOffs(830, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -11.649375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_2", CubeListBuilder.create().texOffs(836, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -11.334375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_3", CubeListBuilder.create().texOffs(842, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -10.861875F, -12.5F, -1.5707963267948966F, 0.0F, 0.33353619044595795F));
        g.addOrReplaceChild("casco_bajo_ladoi_4", CubeListBuilder.create().texOffs(198, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -10.231874999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.3335361904459575F));
        g.addOrReplaceChild("casco_bajo_ladoi_5", CubeListBuilder.create().texOffs(208, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -9.444374999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.3335361904459579F));
        g.addOrReplaceChild("casco_bajo_ladoi_6", CubeListBuilder.create().texOffs(218, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -8.499374999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.33353619044595756F));
        g.addOrReplaceChild("casco_bajo_ladoi_7", CubeListBuilder.create().texOffs(960, 256).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -6.80625F, -12.5F, -1.5707963267948966F, 0.0F, 0.266748799411795F));
        g.addOrReplaceChild("casco_bajo_ladoi_8", CubeListBuilder.create().texOffs(234, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_9", CubeListBuilder.create().texOffs(250, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_10", CubeListBuilder.create().texOffs(266, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_11", CubeListBuilder.create().texOffs(282, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_12", CubeListBuilder.create().texOffs(298, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_13", CubeListBuilder.create().texOffs(314, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_14", CubeListBuilder.create().texOffs(330, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_15", CubeListBuilder.create().texOffs(346, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_16", CubeListBuilder.create().texOffs(362, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_17", CubeListBuilder.create().texOffs(378, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_18", CubeListBuilder.create().texOffs(394, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_19", CubeListBuilder.create().texOffs(410, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_20", CubeListBuilder.create().texOffs(426, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_21", CubeListBuilder.create().texOffs(442, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_22", CubeListBuilder.create().texOffs(458, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_23", CubeListBuilder.create().texOffs(474, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_24", CubeListBuilder.create().texOffs(490, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_25", CubeListBuilder.create().texOffs(978, 256).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -6.01875F, -12.5F, -1.5707963267948966F, 0.0F, -0.09719447717873991F));
        g.addOrReplaceChild("casco_bajo_ladoi_26", CubeListBuilder.create().texOffs(140, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -6.9243749999999995F, -12.5F, -1.5707963267948966F, 0.0F, -0.33353619044595756F));
        g.addOrReplaceChild("casco_bajo_ladoi_27", CubeListBuilder.create().texOffs(228, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -7.869375000000002F, -12.5F, -1.5707963267948966F, 0.0F, -0.33353619044595784F));
        g.addOrReplaceChild("casco_bajo_ladoi_28", CubeListBuilder.create().texOffs(238, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -8.656875000000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_29", CubeListBuilder.create().texOffs(758, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -9.286874999999998F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_30", CubeListBuilder.create().texOffs(766, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -9.759374999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_31", CubeListBuilder.create().texOffs(774, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -10.074375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_32", CubeListBuilder.create().texOffs(848, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(41.875F, -10.251562500000002F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_33", CubeListBuilder.create().texOffs(854, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -13.178125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_34", CubeListBuilder.create().texOffs(860, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -12.953125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_35", CubeListBuilder.create().texOffs(866, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -12.615625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_36", CubeListBuilder.create().texOffs(248, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -12.165625F, -12.5F, -1.5707963267948966F, 0.0F, 0.25619473015536864F));
        g.addOrReplaceChild("casco_bajo_ladoi_37", CubeListBuilder.create().texOffs(258, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -11.603124999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.2561947301553689F));
        g.addOrReplaceChild("casco_bajo_ladoi_38", CubeListBuilder.create().texOffs(268, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -10.928125F, -12.5F, -1.5707963267948966F, 0.0F, 0.25619473015536864F));
        g.addOrReplaceChild("casco_bajo_ladoi_39", CubeListBuilder.create().texOffs(996, 256).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -9.71875F, -12.5F, -1.5707963267948966F, 0.0F, 0.19961038478762638F));
        g.addOrReplaceChild("casco_bajo_ladoi_40", CubeListBuilder.create().texOffs(506, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_41", CubeListBuilder.create().texOffs(522, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladoi_42", CubeListBuilder.create().texOffs(538, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_43", CubeListBuilder.create().texOffs(554, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_44", CubeListBuilder.create().texOffs(570, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_45", CubeListBuilder.create().texOffs(586, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_46", CubeListBuilder.create().texOffs(602, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_47", CubeListBuilder.create().texOffs(618, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_48", CubeListBuilder.create().texOffs(634, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_49", CubeListBuilder.create().texOffs(650, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_50", CubeListBuilder.create().texOffs(666, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_51", CubeListBuilder.create().texOffs(682, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_52", CubeListBuilder.create().texOffs(698, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_53", CubeListBuilder.create().texOffs(714, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_54", CubeListBuilder.create().texOffs(730, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_55", CubeListBuilder.create().texOffs(746, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_56", CubeListBuilder.create().texOffs(762, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_57", CubeListBuilder.create().texOffs(0, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -9.15625F, -12.5F, -1.5707963267948966F, 0.0F, -0.06985443714458175F));
        g.addOrReplaceChild("casco_bajo_ladoi_58", CubeListBuilder.create().texOffs(152, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -9.803125F, -12.5F, -1.5707963267948966F, 0.0F, -0.2561947301553691F));
        g.addOrReplaceChild("casco_bajo_ladoi_59", CubeListBuilder.create().texOffs(278, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -10.478125000000002F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_60", CubeListBuilder.create().texOffs(288, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -11.040625000000002F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_61", CubeListBuilder.create().texOffs(782, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -11.490625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_62", CubeListBuilder.create().texOffs(790, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -11.828125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_63", CubeListBuilder.create().texOffs(798, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -12.053125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_64", CubeListBuilder.create().texOffs(872, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -14.706875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_65", CubeListBuilder.create().texOffs(878, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -14.571874999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_66", CubeListBuilder.create().texOffs(884, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -14.369375000000002F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_67", CubeListBuilder.create().texOffs(806, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -14.099374999999998F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_68", CubeListBuilder.create().texOffs(298, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -13.761875F, -12.5F, -1.5707963267948966F, 0.0F, 0.16274792761823909F));
        g.addOrReplaceChild("casco_bajo_ladoi_69", CubeListBuilder.create().texOffs(308, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -13.356874999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.16274792761823867F));
        g.addOrReplaceChild("casco_bajo_ladoi_70", CubeListBuilder.create().texOffs(18, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -12.631250000000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.1239588350472593F));
        g.addOrReplaceChild("casco_bajo_ladoi_71", CubeListBuilder.create().texOffs(778, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_72", CubeListBuilder.create().texOffs(794, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_73", CubeListBuilder.create().texOffs(810, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_74", CubeListBuilder.create().texOffs(826, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_75", CubeListBuilder.create().texOffs(842, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_76", CubeListBuilder.create().texOffs(858, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_77", CubeListBuilder.create().texOffs(874, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_78", CubeListBuilder.create().texOffs(890, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_79", CubeListBuilder.create().texOffs(906, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_80", CubeListBuilder.create().texOffs(922, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_81", CubeListBuilder.create().texOffs(938, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_82", CubeListBuilder.create().texOffs(954, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_83", CubeListBuilder.create().texOffs(970, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_84", CubeListBuilder.create().texOffs(986, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_85", CubeListBuilder.create().texOffs(1002, 264).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_86", CubeListBuilder.create().texOffs(0, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_87", CubeListBuilder.create().texOffs(16, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_88", CubeListBuilder.create().texOffs(36, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -12.293750000000001F, -12.5F, -1.5707963267948966F, 0.0F, -0.04208781255313887F));
        g.addOrReplaceChild("casco_bajo_ladoi_89", CubeListBuilder.create().texOffs(164, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -12.681874999999998F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_90", CubeListBuilder.create().texOffs(318, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -13.086875000000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_91", CubeListBuilder.create().texOffs(814, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -13.424375000000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_92", CubeListBuilder.create().texOffs(822, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -13.694374999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_93", CubeListBuilder.create().texOffs(830, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -13.896875000000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_94", CubeListBuilder.create().texOffs(838, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -14.031875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_95", CubeListBuilder.create().texOffs(890, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -16.235625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_96", CubeListBuilder.create().texOffs(896, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -16.190625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_97", CubeListBuilder.create().texOffs(902, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -16.123125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_98", CubeListBuilder.create().texOffs(846, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -16.033125000000002F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_99", CubeListBuilder.create().texOffs(328, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -15.920625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_100", CubeListBuilder.create().texOffs(338, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -15.785625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0560144812129938F));
        g.addOrReplaceChild("casco_bajo_ladoi_101", CubeListBuilder.create().texOffs(54, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -15.54375F, -12.5F, -1.5707963267948966F, 0.0F, 0.04208781255313902F));
        g.addOrReplaceChild("casco_bajo_ladoi_102", CubeListBuilder.create().texOffs(32, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_103", CubeListBuilder.create().texOffs(48, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_104", CubeListBuilder.create().texOffs(64, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_105", CubeListBuilder.create().texOffs(80, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_106", CubeListBuilder.create().texOffs(96, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_107", CubeListBuilder.create().texOffs(112, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_108", CubeListBuilder.create().texOffs(128, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_109", CubeListBuilder.create().texOffs(144, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_110", CubeListBuilder.create().texOffs(160, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_111", CubeListBuilder.create().texOffs(176, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_112", CubeListBuilder.create().texOffs(192, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_113", CubeListBuilder.create().texOffs(208, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_114", CubeListBuilder.create().texOffs(224, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_115", CubeListBuilder.create().texOffs(240, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_116", CubeListBuilder.create().texOffs(256, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_117", CubeListBuilder.create().texOffs(272, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_118", CubeListBuilder.create().texOffs(288, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_119", CubeListBuilder.create().texOffs(72, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -15.43125F, -12.5F, -1.5707963267948966F, 0.0F, -0.014058793873061365F));
        g.addOrReplaceChild("casco_bajo_ladoi_120", CubeListBuilder.create().texOffs(176, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -15.560625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_121", CubeListBuilder.create().texOffs(348, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -15.695625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_122", CubeListBuilder.create().texOffs(854, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -15.808125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_123", CubeListBuilder.create().texOffs(862, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -15.898125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_124", CubeListBuilder.create().texOffs(870, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -15.965625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_125", CubeListBuilder.create().texOffs(878, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -16.010625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_126", CubeListBuilder.create().texOffs(288, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_127", CubeListBuilder.create().texOffs(292, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_128", CubeListBuilder.create().texOffs(296, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_129", CubeListBuilder.create().texOffs(300, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_130", CubeListBuilder.create().texOffs(756, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_131", CubeListBuilder.create().texOffs(762, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
    }

    private static void piezas6(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladoi_132", CubeListBuilder.create().texOffs(838, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_133", CubeListBuilder.create().texOffs(848, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_134", CubeListBuilder.create().texOffs(858, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_135", CubeListBuilder.create().texOffs(868, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_136", CubeListBuilder.create().texOffs(878, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_137", CubeListBuilder.create().texOffs(888, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_138", CubeListBuilder.create().texOffs(898, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_139", CubeListBuilder.create().texOffs(908, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_140", CubeListBuilder.create().texOffs(918, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_141", CubeListBuilder.create().texOffs(928, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_142", CubeListBuilder.create().texOffs(938, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_143", CubeListBuilder.create().texOffs(948, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_144", CubeListBuilder.create().texOffs(958, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_145", CubeListBuilder.create().texOffs(968, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_146", CubeListBuilder.create().texOffs(978, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_147", CubeListBuilder.create().texOffs(988, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_148", CubeListBuilder.create().texOffs(998, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_149", CubeListBuilder.create().texOffs(1008, 327).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_150", CubeListBuilder.create().texOffs(0, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_151", CubeListBuilder.create().texOffs(768, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_152", CubeListBuilder.create().texOffs(774, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_153", CubeListBuilder.create().texOffs(304, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_154", CubeListBuilder.create().texOffs(308, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_155", CubeListBuilder.create().texOffs(312, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_156", CubeListBuilder.create().texOffs(316, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_157", CubeListBuilder.create().texOffs(320, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_158", CubeListBuilder.create().texOffs(324, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_159", CubeListBuilder.create().texOffs(328, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_160", CubeListBuilder.create().texOffs(332, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_161", CubeListBuilder.create().texOffs(780, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_162", CubeListBuilder.create().texOffs(786, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_163", CubeListBuilder.create().texOffs(10, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_164", CubeListBuilder.create().texOffs(20, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_165", CubeListBuilder.create().texOffs(30, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_166", CubeListBuilder.create().texOffs(40, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_167", CubeListBuilder.create().texOffs(50, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_168", CubeListBuilder.create().texOffs(60, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_169", CubeListBuilder.create().texOffs(70, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_170", CubeListBuilder.create().texOffs(80, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_171", CubeListBuilder.create().texOffs(90, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_172", CubeListBuilder.create().texOffs(100, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_173", CubeListBuilder.create().texOffs(110, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_174", CubeListBuilder.create().texOffs(120, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_175", CubeListBuilder.create().texOffs(130, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_176", CubeListBuilder.create().texOffs(140, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_177", CubeListBuilder.create().texOffs(150, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_178", CubeListBuilder.create().texOffs(160, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_179", CubeListBuilder.create().texOffs(170, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_180", CubeListBuilder.create().texOffs(180, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_181", CubeListBuilder.create().texOffs(190, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_182", CubeListBuilder.create().texOffs(792, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_183", CubeListBuilder.create().texOffs(798, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_184", CubeListBuilder.create().texOffs(336, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_185", CubeListBuilder.create().texOffs(340, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_186", CubeListBuilder.create().texOffs(344, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_187", CubeListBuilder.create().texOffs(348, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_188", CubeListBuilder.create().texOffs(352, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_189", CubeListBuilder.create().texOffs(356, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_190", CubeListBuilder.create().texOffs(360, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_191", CubeListBuilder.create().texOffs(364, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_192", CubeListBuilder.create().texOffs(804, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_193", CubeListBuilder.create().texOffs(810, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_194", CubeListBuilder.create().texOffs(200, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_195", CubeListBuilder.create().texOffs(210, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_196", CubeListBuilder.create().texOffs(220, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_197", CubeListBuilder.create().texOffs(230, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_198", CubeListBuilder.create().texOffs(240, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_199", CubeListBuilder.create().texOffs(250, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_200", CubeListBuilder.create().texOffs(260, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_201", CubeListBuilder.create().texOffs(270, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_202", CubeListBuilder.create().texOffs(280, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_203", CubeListBuilder.create().texOffs(290, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_204", CubeListBuilder.create().texOffs(300, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_205", CubeListBuilder.create().texOffs(310, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_206", CubeListBuilder.create().texOffs(320, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_207", CubeListBuilder.create().texOffs(330, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_208", CubeListBuilder.create().texOffs(340, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_209", CubeListBuilder.create().texOffs(350, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_210", CubeListBuilder.create().texOffs(360, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_211", CubeListBuilder.create().texOffs(370, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_212", CubeListBuilder.create().texOffs(380, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_213", CubeListBuilder.create().texOffs(816, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_214", CubeListBuilder.create().texOffs(822, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_215", CubeListBuilder.create().texOffs(368, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_216", CubeListBuilder.create().texOffs(372, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_217", CubeListBuilder.create().texOffs(376, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_218", CubeListBuilder.create().texOffs(380, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_219", CubeListBuilder.create().texOffs(384, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_220", CubeListBuilder.create().texOffs(388, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_221", CubeListBuilder.create().texOffs(392, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
    }

    private static void piezas7(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladoi_222", CubeListBuilder.create().texOffs(396, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_223", CubeListBuilder.create().texOffs(828, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_224", CubeListBuilder.create().texOffs(834, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_225", CubeListBuilder.create().texOffs(390, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_226", CubeListBuilder.create().texOffs(400, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_227", CubeListBuilder.create().texOffs(410, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_228", CubeListBuilder.create().texOffs(420, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_229", CubeListBuilder.create().texOffs(430, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_230", CubeListBuilder.create().texOffs(440, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_231", CubeListBuilder.create().texOffs(450, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_232", CubeListBuilder.create().texOffs(460, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_233", CubeListBuilder.create().texOffs(470, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_234", CubeListBuilder.create().texOffs(480, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_235", CubeListBuilder.create().texOffs(490, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_236", CubeListBuilder.create().texOffs(500, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_237", CubeListBuilder.create().texOffs(510, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_238", CubeListBuilder.create().texOffs(520, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_239", CubeListBuilder.create().texOffs(530, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_240", CubeListBuilder.create().texOffs(540, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_241", CubeListBuilder.create().texOffs(550, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_242", CubeListBuilder.create().texOffs(560, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_243", CubeListBuilder.create().texOffs(570, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_244", CubeListBuilder.create().texOffs(840, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_245", CubeListBuilder.create().texOffs(846, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_246", CubeListBuilder.create().texOffs(400, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_247", CubeListBuilder.create().texOffs(404, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_248", CubeListBuilder.create().texOffs(408, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_249", CubeListBuilder.create().texOffs(412, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_0", CubeListBuilder.create().texOffs(908, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.875F, -11.826562500000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_1", CubeListBuilder.create().texOffs(914, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -11.649375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_2", CubeListBuilder.create().texOffs(920, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -11.334375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_3", CubeListBuilder.create().texOffs(926, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -10.861875F, 12.5F, 1.5707963267948966F, 0.0F, 0.33353619044595795F));
        g.addOrReplaceChild("casco_bajo_ladod_4", CubeListBuilder.create().texOffs(358, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -10.231874999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.3335361904459575F));
        g.addOrReplaceChild("casco_bajo_ladod_5", CubeListBuilder.create().texOffs(368, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -9.444374999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.3335361904459579F));
        g.addOrReplaceChild("casco_bajo_ladod_6", CubeListBuilder.create().texOffs(378, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -8.499374999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.33353619044595756F));
        g.addOrReplaceChild("casco_bajo_ladod_7", CubeListBuilder.create().texOffs(90, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -6.80625F, 12.5F, 1.5707963267948966F, 0.0F, 0.266748799411795F));
        g.addOrReplaceChild("casco_bajo_ladod_8", CubeListBuilder.create().texOffs(304, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_9", CubeListBuilder.create().texOffs(320, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_10", CubeListBuilder.create().texOffs(336, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_11", CubeListBuilder.create().texOffs(352, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_12", CubeListBuilder.create().texOffs(368, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_13", CubeListBuilder.create().texOffs(384, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_14", CubeListBuilder.create().texOffs(400, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_15", CubeListBuilder.create().texOffs(416, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_16", CubeListBuilder.create().texOffs(432, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_17", CubeListBuilder.create().texOffs(448, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_18", CubeListBuilder.create().texOffs(464, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_19", CubeListBuilder.create().texOffs(480, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_20", CubeListBuilder.create().texOffs(496, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_21", CubeListBuilder.create().texOffs(512, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_22", CubeListBuilder.create().texOffs(528, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_23", CubeListBuilder.create().texOffs(544, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_24", CubeListBuilder.create().texOffs(560, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_25", CubeListBuilder.create().texOffs(108, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -6.01875F, 12.5F, 1.5707963267948966F, 0.0F, -0.09719447717873991F));
        g.addOrReplaceChild("casco_bajo_ladod_26", CubeListBuilder.create().texOffs(188, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -6.9243749999999995F, 12.5F, 1.5707963267948966F, 0.0F, -0.33353619044595756F));
        g.addOrReplaceChild("casco_bajo_ladod_27", CubeListBuilder.create().texOffs(388, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -7.869375000000002F, 12.5F, 1.5707963267948966F, 0.0F, -0.33353619044595784F));
        g.addOrReplaceChild("casco_bajo_ladod_28", CubeListBuilder.create().texOffs(398, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -8.656875000000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_29", CubeListBuilder.create().texOffs(886, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -9.286874999999998F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_30", CubeListBuilder.create().texOffs(894, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -9.759374999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_31", CubeListBuilder.create().texOffs(902, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -10.074375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_32", CubeListBuilder.create().texOffs(932, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(41.875F, -10.251562500000002F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_33", CubeListBuilder.create().texOffs(938, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -13.178125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_34", CubeListBuilder.create().texOffs(944, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -12.953125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_35", CubeListBuilder.create().texOffs(950, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -12.615625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_36", CubeListBuilder.create().texOffs(408, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -12.165625F, 12.5F, 1.5707963267948966F, 0.0F, 0.25619473015536864F));
        g.addOrReplaceChild("casco_bajo_ladod_37", CubeListBuilder.create().texOffs(418, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -11.603124999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.2561947301553689F));
        g.addOrReplaceChild("casco_bajo_ladod_38", CubeListBuilder.create().texOffs(428, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -10.928125F, 12.5F, 1.5707963267948966F, 0.0F, 0.25619473015536864F));
        g.addOrReplaceChild("casco_bajo_ladod_39", CubeListBuilder.create().texOffs(126, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -9.71875F, 12.5F, 1.5707963267948966F, 0.0F, 0.19961038478762638F));
        g.addOrReplaceChild("casco_bajo_ladod_40", CubeListBuilder.create().texOffs(576, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_41", CubeListBuilder.create().texOffs(592, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_42", CubeListBuilder.create().texOffs(608, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_43", CubeListBuilder.create().texOffs(624, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_44", CubeListBuilder.create().texOffs(640, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_45", CubeListBuilder.create().texOffs(656, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_46", CubeListBuilder.create().texOffs(672, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_47", CubeListBuilder.create().texOffs(688, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_48", CubeListBuilder.create().texOffs(704, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_49", CubeListBuilder.create().texOffs(720, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_50", CubeListBuilder.create().texOffs(736, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_51", CubeListBuilder.create().texOffs(752, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_52", CubeListBuilder.create().texOffs(768, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_53", CubeListBuilder.create().texOffs(784, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_54", CubeListBuilder.create().texOffs(800, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_55", CubeListBuilder.create().texOffs(816, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_56", CubeListBuilder.create().texOffs(832, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_57", CubeListBuilder.create().texOffs(144, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -9.15625F, 12.5F, 1.5707963267948966F, 0.0F, -0.06985443714458175F));
        g.addOrReplaceChild("casco_bajo_ladod_58", CubeListBuilder.create().texOffs(200, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -9.803125F, 12.5F, 1.5707963267948966F, 0.0F, -0.2561947301553691F));
        g.addOrReplaceChild("casco_bajo_ladod_59", CubeListBuilder.create().texOffs(438, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -10.478125000000002F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_60", CubeListBuilder.create().texOffs(448, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -11.040625000000002F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_61", CubeListBuilder.create().texOffs(910, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -11.490625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
    }

    private static void piezas8(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladod_62", CubeListBuilder.create().texOffs(918, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -11.828125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_63", CubeListBuilder.create().texOffs(926, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -12.053125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_64", CubeListBuilder.create().texOffs(956, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -14.706875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_65", CubeListBuilder.create().texOffs(962, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -14.571874999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_66", CubeListBuilder.create().texOffs(968, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -14.369375000000002F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_67", CubeListBuilder.create().texOffs(934, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -14.099374999999998F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_68", CubeListBuilder.create().texOffs(458, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -13.761875F, 12.5F, 1.5707963267948966F, 0.0F, 0.16274792761823909F));
        g.addOrReplaceChild("casco_bajo_ladod_69", CubeListBuilder.create().texOffs(468, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -13.356874999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.16274792761823867F));
        g.addOrReplaceChild("casco_bajo_ladod_70", CubeListBuilder.create().texOffs(162, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -12.631250000000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.1239588350472593F));
        g.addOrReplaceChild("casco_bajo_ladod_71", CubeListBuilder.create().texOffs(848, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_72", CubeListBuilder.create().texOffs(864, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_73", CubeListBuilder.create().texOffs(880, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_74", CubeListBuilder.create().texOffs(896, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_75", CubeListBuilder.create().texOffs(912, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_76", CubeListBuilder.create().texOffs(928, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_77", CubeListBuilder.create().texOffs(944, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_78", CubeListBuilder.create().texOffs(960, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_79", CubeListBuilder.create().texOffs(976, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_80", CubeListBuilder.create().texOffs(992, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_81", CubeListBuilder.create().texOffs(1008, 269).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_82", CubeListBuilder.create().texOffs(0, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_83", CubeListBuilder.create().texOffs(16, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_84", CubeListBuilder.create().texOffs(32, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_85", CubeListBuilder.create().texOffs(48, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_86", CubeListBuilder.create().texOffs(64, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_87", CubeListBuilder.create().texOffs(80, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_88", CubeListBuilder.create().texOffs(180, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -12.293750000000001F, 12.5F, 1.5707963267948966F, 0.0F, -0.04208781255313887F));
        g.addOrReplaceChild("casco_bajo_ladod_89", CubeListBuilder.create().texOffs(212, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -12.681874999999998F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_90", CubeListBuilder.create().texOffs(478, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -13.086875000000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_91", CubeListBuilder.create().texOffs(942, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -13.424375000000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_92", CubeListBuilder.create().texOffs(950, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -13.694374999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_93", CubeListBuilder.create().texOffs(958, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -13.896875000000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_94", CubeListBuilder.create().texOffs(966, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -14.031875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_95", CubeListBuilder.create().texOffs(974, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -16.235625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_96", CubeListBuilder.create().texOffs(980, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -16.190625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_97", CubeListBuilder.create().texOffs(986, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -16.123125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_98", CubeListBuilder.create().texOffs(974, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -16.033125000000002F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_99", CubeListBuilder.create().texOffs(488, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -15.920625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_100", CubeListBuilder.create().texOffs(498, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -15.785625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0560144812129938F));
        g.addOrReplaceChild("casco_bajo_ladod_101", CubeListBuilder.create().texOffs(198, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -15.54375F, 12.5F, 1.5707963267948966F, 0.0F, 0.04208781255313902F));
        g.addOrReplaceChild("casco_bajo_ladod_102", CubeListBuilder.create().texOffs(96, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_103", CubeListBuilder.create().texOffs(112, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_104", CubeListBuilder.create().texOffs(128, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_105", CubeListBuilder.create().texOffs(144, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_106", CubeListBuilder.create().texOffs(160, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_107", CubeListBuilder.create().texOffs(176, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_108", CubeListBuilder.create().texOffs(192, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_109", CubeListBuilder.create().texOffs(208, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_110", CubeListBuilder.create().texOffs(224, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_111", CubeListBuilder.create().texOffs(240, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_112", CubeListBuilder.create().texOffs(256, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_113", CubeListBuilder.create().texOffs(272, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_114", CubeListBuilder.create().texOffs(288, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_115", CubeListBuilder.create().texOffs(304, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_116", CubeListBuilder.create().texOffs(320, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_117", CubeListBuilder.create().texOffs(336, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_118", CubeListBuilder.create().texOffs(352, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_119", CubeListBuilder.create().texOffs(216, 264).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -15.43125F, 12.5F, 1.5707963267948966F, 0.0F, -0.014058793873061365F));
        g.addOrReplaceChild("casco_bajo_ladod_120", CubeListBuilder.create().texOffs(224, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -15.560625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_121", CubeListBuilder.create().texOffs(508, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -15.695625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_122", CubeListBuilder.create().texOffs(982, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -15.808125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_123", CubeListBuilder.create().texOffs(990, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -15.898125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_124", CubeListBuilder.create().texOffs(998, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -15.965625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_125", CubeListBuilder.create().texOffs(1006, 294).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -16.010625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_126", CubeListBuilder.create().texOffs(416, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_127", CubeListBuilder.create().texOffs(420, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_128", CubeListBuilder.create().texOffs(424, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_129", CubeListBuilder.create().texOffs(428, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_130", CubeListBuilder.create().texOffs(852, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_131", CubeListBuilder.create().texOffs(858, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_132", CubeListBuilder.create().texOffs(580, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_133", CubeListBuilder.create().texOffs(590, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_134", CubeListBuilder.create().texOffs(600, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_135", CubeListBuilder.create().texOffs(610, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_136", CubeListBuilder.create().texOffs(620, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_137", CubeListBuilder.create().texOffs(630, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_138", CubeListBuilder.create().texOffs(640, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_139", CubeListBuilder.create().texOffs(650, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_140", CubeListBuilder.create().texOffs(660, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_141", CubeListBuilder.create().texOffs(670, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_142", CubeListBuilder.create().texOffs(680, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_143", CubeListBuilder.create().texOffs(690, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_144", CubeListBuilder.create().texOffs(700, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_145", CubeListBuilder.create().texOffs(710, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_146", CubeListBuilder.create().texOffs(720, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_147", CubeListBuilder.create().texOffs(730, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_148", CubeListBuilder.create().texOffs(740, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_149", CubeListBuilder.create().texOffs(750, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_150", CubeListBuilder.create().texOffs(760, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_151", CubeListBuilder.create().texOffs(864, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
    }

    private static void piezas9(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladod_152", CubeListBuilder.create().texOffs(870, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_153", CubeListBuilder.create().texOffs(432, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_154", CubeListBuilder.create().texOffs(436, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_155", CubeListBuilder.create().texOffs(440, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_156", CubeListBuilder.create().texOffs(444, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_157", CubeListBuilder.create().texOffs(448, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_158", CubeListBuilder.create().texOffs(452, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_159", CubeListBuilder.create().texOffs(456, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_160", CubeListBuilder.create().texOffs(460, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_161", CubeListBuilder.create().texOffs(876, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_162", CubeListBuilder.create().texOffs(882, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_163", CubeListBuilder.create().texOffs(770, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_164", CubeListBuilder.create().texOffs(780, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_165", CubeListBuilder.create().texOffs(790, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_166", CubeListBuilder.create().texOffs(800, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_167", CubeListBuilder.create().texOffs(810, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_168", CubeListBuilder.create().texOffs(820, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_169", CubeListBuilder.create().texOffs(830, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_170", CubeListBuilder.create().texOffs(840, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_171", CubeListBuilder.create().texOffs(850, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_172", CubeListBuilder.create().texOffs(860, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_173", CubeListBuilder.create().texOffs(870, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_174", CubeListBuilder.create().texOffs(880, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_175", CubeListBuilder.create().texOffs(890, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_176", CubeListBuilder.create().texOffs(900, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_177", CubeListBuilder.create().texOffs(910, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_178", CubeListBuilder.create().texOffs(920, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_179", CubeListBuilder.create().texOffs(930, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_180", CubeListBuilder.create().texOffs(940, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_181", CubeListBuilder.create().texOffs(950, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_182", CubeListBuilder.create().texOffs(888, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_183", CubeListBuilder.create().texOffs(894, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_184", CubeListBuilder.create().texOffs(464, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_185", CubeListBuilder.create().texOffs(468, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_186", CubeListBuilder.create().texOffs(472, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_187", CubeListBuilder.create().texOffs(476, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_188", CubeListBuilder.create().texOffs(480, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_189", CubeListBuilder.create().texOffs(484, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_190", CubeListBuilder.create().texOffs(488, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_191", CubeListBuilder.create().texOffs(492, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_192", CubeListBuilder.create().texOffs(900, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_193", CubeListBuilder.create().texOffs(906, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_194", CubeListBuilder.create().texOffs(960, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_195", CubeListBuilder.create().texOffs(970, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_196", CubeListBuilder.create().texOffs(980, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_197", CubeListBuilder.create().texOffs(990, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_198", CubeListBuilder.create().texOffs(1000, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_199", CubeListBuilder.create().texOffs(1010, 330).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_200", CubeListBuilder.create().texOffs(0, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_201", CubeListBuilder.create().texOffs(10, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_202", CubeListBuilder.create().texOffs(20, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_203", CubeListBuilder.create().texOffs(30, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_204", CubeListBuilder.create().texOffs(40, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_205", CubeListBuilder.create().texOffs(50, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_206", CubeListBuilder.create().texOffs(60, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_207", CubeListBuilder.create().texOffs(70, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_208", CubeListBuilder.create().texOffs(80, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_209", CubeListBuilder.create().texOffs(90, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_210", CubeListBuilder.create().texOffs(100, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_211", CubeListBuilder.create().texOffs(110, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_212", CubeListBuilder.create().texOffs(120, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_213", CubeListBuilder.create().texOffs(912, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_214", CubeListBuilder.create().texOffs(918, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_215", CubeListBuilder.create().texOffs(496, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_216", CubeListBuilder.create().texOffs(500, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_217", CubeListBuilder.create().texOffs(504, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_218", CubeListBuilder.create().texOffs(508, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_219", CubeListBuilder.create().texOffs(512, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_220", CubeListBuilder.create().texOffs(516, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_221", CubeListBuilder.create().texOffs(520, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_222", CubeListBuilder.create().texOffs(524, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_223", CubeListBuilder.create().texOffs(924, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_224", CubeListBuilder.create().texOffs(930, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_225", CubeListBuilder.create().texOffs(130, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_226", CubeListBuilder.create().texOffs(140, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_227", CubeListBuilder.create().texOffs(150, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_228", CubeListBuilder.create().texOffs(160, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_229", CubeListBuilder.create().texOffs(170, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_230", CubeListBuilder.create().texOffs(180, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_231", CubeListBuilder.create().texOffs(190, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_232", CubeListBuilder.create().texOffs(200, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_233", CubeListBuilder.create().texOffs(210, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_234", CubeListBuilder.create().texOffs(220, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_235", CubeListBuilder.create().texOffs(230, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_236", CubeListBuilder.create().texOffs(240, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_237", CubeListBuilder.create().texOffs(250, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_238", CubeListBuilder.create().texOffs(260, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_239", CubeListBuilder.create().texOffs(270, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_240", CubeListBuilder.create().texOffs(280, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_241", CubeListBuilder.create().texOffs(290, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
    }

    private static void piezas10(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladod_242", CubeListBuilder.create().texOffs(300, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_243", CubeListBuilder.create().texOffs(310, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_244", CubeListBuilder.create().texOffs(936, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_245", CubeListBuilder.create().texOffs(942, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_246", CubeListBuilder.create().texOffs(528, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_247", CubeListBuilder.create().texOffs(532, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_248", CubeListBuilder.create().texOffs(536, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_249", CubeListBuilder.create().texOffs(540, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_0", CubeListBuilder.create().texOffs(524, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_1", CubeListBuilder.create().texOffs(534, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_2", CubeListBuilder.create().texOffs(544, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_3", CubeListBuilder.create().texOffs(554, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_4", CubeListBuilder.create().texOffs(236, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_5", CubeListBuilder.create().texOffs(248, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_6", CubeListBuilder.create().texOffs(368, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_7", CubeListBuilder.create().texOffs(384, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_8", CubeListBuilder.create().texOffs(400, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_9", CubeListBuilder.create().texOffs(416, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_10", CubeListBuilder.create().texOffs(432, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_11", CubeListBuilder.create().texOffs(448, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_12", CubeListBuilder.create().texOffs(464, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_13", CubeListBuilder.create().texOffs(480, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_14", CubeListBuilder.create().texOffs(496, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_15", CubeListBuilder.create().texOffs(512, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_16", CubeListBuilder.create().texOffs(528, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_17", CubeListBuilder.create().texOffs(544, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_18", CubeListBuilder.create().texOffs(560, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_19", CubeListBuilder.create().texOffs(576, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_20", CubeListBuilder.create().texOffs(592, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_21", CubeListBuilder.create().texOffs(608, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_22", CubeListBuilder.create().texOffs(624, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_23", CubeListBuilder.create().texOffs(640, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_24", CubeListBuilder.create().texOffs(656, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_25", CubeListBuilder.create().texOffs(260, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_26", CubeListBuilder.create().texOffs(272, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_27", CubeListBuilder.create().texOffs(564, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_28", CubeListBuilder.create().texOffs(574, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_29", CubeListBuilder.create().texOffs(584, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_30", CubeListBuilder.create().texOffs(594, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_31", CubeListBuilder.create().texOffs(604, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_32", CubeListBuilder.create().texOffs(614, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_33", CubeListBuilder.create().texOffs(624, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_34", CubeListBuilder.create().texOffs(634, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_35", CubeListBuilder.create().texOffs(284, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_36", CubeListBuilder.create().texOffs(296, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_37", CubeListBuilder.create().texOffs(672, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_38", CubeListBuilder.create().texOffs(688, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_39", CubeListBuilder.create().texOffs(704, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_40", CubeListBuilder.create().texOffs(720, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_41", CubeListBuilder.create().texOffs(736, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_42", CubeListBuilder.create().texOffs(752, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_43", CubeListBuilder.create().texOffs(768, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_44", CubeListBuilder.create().texOffs(784, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_45", CubeListBuilder.create().texOffs(800, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_46", CubeListBuilder.create().texOffs(816, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_47", CubeListBuilder.create().texOffs(832, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_48", CubeListBuilder.create().texOffs(848, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_49", CubeListBuilder.create().texOffs(864, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_50", CubeListBuilder.create().texOffs(880, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_51", CubeListBuilder.create().texOffs(896, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_52", CubeListBuilder.create().texOffs(912, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_53", CubeListBuilder.create().texOffs(928, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_54", CubeListBuilder.create().texOffs(944, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_55", CubeListBuilder.create().texOffs(960, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_56", CubeListBuilder.create().texOffs(308, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_57", CubeListBuilder.create().texOffs(320, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_58", CubeListBuilder.create().texOffs(644, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_59", CubeListBuilder.create().texOffs(654, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_60", CubeListBuilder.create().texOffs(664, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_61", CubeListBuilder.create().texOffs(674, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_62", CubeListBuilder.create().texOffs(684, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_63", CubeListBuilder.create().texOffs(694, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_64", CubeListBuilder.create().texOffs(704, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_65", CubeListBuilder.create().texOffs(714, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_66", CubeListBuilder.create().texOffs(332, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_67", CubeListBuilder.create().texOffs(344, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_68", CubeListBuilder.create().texOffs(976, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_69", CubeListBuilder.create().texOffs(992, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_70", CubeListBuilder.create().texOffs(1008, 274).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_71", CubeListBuilder.create().texOffs(0, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_72", CubeListBuilder.create().texOffs(16, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_73", CubeListBuilder.create().texOffs(32, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_74", CubeListBuilder.create().texOffs(48, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_75", CubeListBuilder.create().texOffs(64, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_76", CubeListBuilder.create().texOffs(80, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_77", CubeListBuilder.create().texOffs(96, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_78", CubeListBuilder.create().texOffs(112, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_79", CubeListBuilder.create().texOffs(128, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_80", CubeListBuilder.create().texOffs(144, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_81", CubeListBuilder.create().texOffs(160, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
    }

    private static void piezas11(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_arriba0_82", CubeListBuilder.create().texOffs(176, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_83", CubeListBuilder.create().texOffs(192, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_84", CubeListBuilder.create().texOffs(208, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_85", CubeListBuilder.create().texOffs(224, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_86", CubeListBuilder.create().texOffs(240, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_87", CubeListBuilder.create().texOffs(356, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_88", CubeListBuilder.create().texOffs(368, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_89", CubeListBuilder.create().texOffs(724, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_90", CubeListBuilder.create().texOffs(734, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_91", CubeListBuilder.create().texOffs(744, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_92", CubeListBuilder.create().texOffs(754, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_93", CubeListBuilder.create().texOffs(764, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_94", CubeListBuilder.create().texOffs(774, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_95", CubeListBuilder.create().texOffs(784, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_96", CubeListBuilder.create().texOffs(794, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_97", CubeListBuilder.create().texOffs(380, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_98", CubeListBuilder.create().texOffs(392, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_99", CubeListBuilder.create().texOffs(256, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_100", CubeListBuilder.create().texOffs(272, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_101", CubeListBuilder.create().texOffs(288, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_102", CubeListBuilder.create().texOffs(304, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_103", CubeListBuilder.create().texOffs(320, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_104", CubeListBuilder.create().texOffs(336, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_105", CubeListBuilder.create().texOffs(352, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_106", CubeListBuilder.create().texOffs(368, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_107", CubeListBuilder.create().texOffs(384, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_108", CubeListBuilder.create().texOffs(400, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_109", CubeListBuilder.create().texOffs(416, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_110", CubeListBuilder.create().texOffs(432, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_111", CubeListBuilder.create().texOffs(448, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_112", CubeListBuilder.create().texOffs(464, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_113", CubeListBuilder.create().texOffs(480, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_114", CubeListBuilder.create().texOffs(496, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_115", CubeListBuilder.create().texOffs(512, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_116", CubeListBuilder.create().texOffs(528, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_117", CubeListBuilder.create().texOffs(544, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_118", CubeListBuilder.create().texOffs(404, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_119", CubeListBuilder.create().texOffs(416, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_120", CubeListBuilder.create().texOffs(804, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_121", CubeListBuilder.create().texOffs(814, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_122", CubeListBuilder.create().texOffs(824, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_123", CubeListBuilder.create().texOffs(834, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_124", CubeListBuilder.create().texOffs(844, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_125", CubeListBuilder.create().texOffs(854, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_126", CubeListBuilder.create().texOffs(864, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_127", CubeListBuilder.create().texOffs(874, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_128", CubeListBuilder.create().texOffs(428, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_129", CubeListBuilder.create().texOffs(440, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_130", CubeListBuilder.create().texOffs(560, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_131", CubeListBuilder.create().texOffs(576, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_132", CubeListBuilder.create().texOffs(592, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_133", CubeListBuilder.create().texOffs(608, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_134", CubeListBuilder.create().texOffs(624, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_135", CubeListBuilder.create().texOffs(640, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_136", CubeListBuilder.create().texOffs(656, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_137", CubeListBuilder.create().texOffs(672, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_138", CubeListBuilder.create().texOffs(688, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_139", CubeListBuilder.create().texOffs(704, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_140", CubeListBuilder.create().texOffs(720, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_141", CubeListBuilder.create().texOffs(736, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_142", CubeListBuilder.create().texOffs(752, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_143", CubeListBuilder.create().texOffs(768, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_144", CubeListBuilder.create().texOffs(784, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_145", CubeListBuilder.create().texOffs(800, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_146", CubeListBuilder.create().texOffs(816, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_147", CubeListBuilder.create().texOffs(832, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_148", CubeListBuilder.create().texOffs(848, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_149", CubeListBuilder.create().texOffs(452, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_150", CubeListBuilder.create().texOffs(464, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_151", CubeListBuilder.create().texOffs(884, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_152", CubeListBuilder.create().texOffs(894, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_153", CubeListBuilder.create().texOffs(904, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_154", CubeListBuilder.create().texOffs(914, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_155", CubeListBuilder.create().texOffs(924, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_156", CubeListBuilder.create().texOffs(934, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_157", CubeListBuilder.create().texOffs(944, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_158", CubeListBuilder.create().texOffs(954, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_159", CubeListBuilder.create().texOffs(476, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_160", CubeListBuilder.create().texOffs(488, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_161", CubeListBuilder.create().texOffs(864, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_162", CubeListBuilder.create().texOffs(880, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_163", CubeListBuilder.create().texOffs(896, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_164", CubeListBuilder.create().texOffs(912, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_165", CubeListBuilder.create().texOffs(928, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_166", CubeListBuilder.create().texOffs(944, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_167", CubeListBuilder.create().texOffs(960, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_168", CubeListBuilder.create().texOffs(976, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_169", CubeListBuilder.create().texOffs(992, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_170", CubeListBuilder.create().texOffs(1008, 279).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_171", CubeListBuilder.create().texOffs(0, 284).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
    }

    private static void piezas12(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_arriba0_172", CubeListBuilder.create().texOffs(16, 284).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_173", CubeListBuilder.create().texOffs(32, 284).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_174", CubeListBuilder.create().texOffs(48, 284).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_175", CubeListBuilder.create().texOffs(64, 284).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_176", CubeListBuilder.create().texOffs(80, 284).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_177", CubeListBuilder.create().texOffs(96, 284).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_178", CubeListBuilder.create().texOffs(112, 284).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_179", CubeListBuilder.create().texOffs(128, 284).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_180", CubeListBuilder.create().texOffs(500, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_181", CubeListBuilder.create().texOffs(512, 289).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_182", CubeListBuilder.create().texOffs(964, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_183", CubeListBuilder.create().texOffs(974, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_184", CubeListBuilder.create().texOffs(984, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_185", CubeListBuilder.create().texOffs(994, 289).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_trompa", CubeListBuilder.create().texOffs(600, 0).addBox(0.0F, -32.0F, 0.0F, 1.0F, 32.0F, 52.0F), PartPose.offset(-44.0F, -3.0F, -13.0F));
        g.addOrReplaceChild("casco_bajo_cola", CubeListBuilder.create().texOffs(706, 0).addBox(0.0F, -32.0F, 0.0F, 1.0F, 32.0F, 52.0F), PartPose.offset(41.0F, -3.0F, -13.0F));
        g.addOrReplaceChild("casco_ladoi_0", CubeListBuilder.create().texOffs(948, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -17.60458984375F, -22.0F, -1.5707963267948966F, 0.0F, -0.033190931497111234F));
        g.addOrReplaceChild("casco_ladoi_1", CubeListBuilder.create().texOffs(954, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -17.64443359375F, -22.0F, -1.5707963267948966F, 0.0F, -0.03319093149711221F));
        g.addOrReplaceChild("casco_ladoi_2", CubeListBuilder.create().texOffs(454, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -17.7880859375F, -22.0F, -1.5707963267948966F, 0.0F, -0.060959533981966185F));
        g.addOrReplaceChild("casco_ladoi_3", CubeListBuilder.create().texOffs(548, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -18.04296875F, -22.0F, -1.5707963267948966F, 0.0F, -0.06630889491982349F));
        g.addOrReplaceChild("casco_ladoi_4", CubeListBuilder.create().texOffs(772, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -18.275390625F, -22.0F, -1.5707963267948966F, 0.0F, -0.03315444745991172F));
        g.addOrReplaceChild("casco_ladoi_5", CubeListBuilder.create().texOffs(992, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_6", CubeListBuilder.create().texOffs(784, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_7", CubeListBuilder.create().texOffs(796, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_8", CubeListBuilder.create().texOffs(808, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_9", CubeListBuilder.create().texOffs(820, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_10", CubeListBuilder.create().texOffs(832, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_11", CubeListBuilder.create().texOffs(844, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_12", CubeListBuilder.create().texOffs(856, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_13", CubeListBuilder.create().texOffs(868, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_14", CubeListBuilder.create().texOffs(880, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_15", CubeListBuilder.create().texOffs(892, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_16", CubeListBuilder.create().texOffs(904, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_17", CubeListBuilder.create().texOffs(916, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_18", CubeListBuilder.create().texOffs(928, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_19", CubeListBuilder.create().texOffs(940, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_20", CubeListBuilder.create().texOffs(952, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_21", CubeListBuilder.create().texOffs(964, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_22", CubeListBuilder.create().texOffs(562, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -18.26388888888889F, -22.0F, -1.5707963267948966F, 0.0F, 0.05549850524571664F));
        g.addOrReplaceChild("casco_ladoi_23", CubeListBuilder.create().texOffs(280, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -18.116666666666667F, -22.0F, -1.5707963267948966F, 0.0F, 0.02774925262285877F));
        g.addOrReplaceChild("casco_ladoi_24", CubeListBuilder.create().texOffs(288, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -18.05F, -22.0F, -1.5707963267948966F, 0.0F, 0.027749252622858458F));
        g.addOrReplaceChild("casco_ladoi_25", CubeListBuilder.create().texOffs(998, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -17.994444444444447F, -22.0F, -1.5707963267948966F, 0.0F, 0.02774925262285814F));
        g.addOrReplaceChild("casco_ladoi_26", CubeListBuilder.create().texOffs(544, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.95F, -22.0F, -1.5707963267948966F, 0.0F, 0.02774925262285877F));
        g.addOrReplaceChild("casco_ladoi_27", CubeListBuilder.create().texOffs(548, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -17.916666666666668F, -22.0F, -1.5707963267948966F, 0.0F, 0.027749252622857355F));
        g.addOrReplaceChild("casco_ladoi_28", CubeListBuilder.create().texOffs(552, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -17.894444444444446F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_29", CubeListBuilder.create().texOffs(960, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -17.81376953125F, -22.0F, -1.5707963267948966F, 0.0F, -0.09928188012599692F));
        g.addOrReplaceChild("casco_ladoi_30", CubeListBuilder.create().texOffs(966, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -17.93330078125F, -22.0F, -1.5707963267948966F, 0.0F, -0.0992818801259969F));
        g.addOrReplaceChild("casco_ladoi_31", CubeListBuilder.create().texOffs(466, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -18.3642578125F, -22.0F, -1.5707963267948966F, 0.0F, -0.18109931064379278F));
        g.addOrReplaceChild("casco_ladoi_32", CubeListBuilder.create().texOffs(576, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -19.12890625F, -22.0F, -1.5707963267948966F, 0.0F, -0.196644245190345F));
        g.addOrReplaceChild("casco_ladoi_33", CubeListBuilder.create().texOffs(976, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -19.826171875F, -22.0F, -1.5707963267948966F, 0.0F, -0.09832212259517253F));
        g.addOrReplaceChild("casco_ladoi_34", CubeListBuilder.create().texOffs(1004, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_35", CubeListBuilder.create().texOffs(988, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_36", CubeListBuilder.create().texOffs(1000, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_37", CubeListBuilder.create().texOffs(1012, 309).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_38", CubeListBuilder.create().texOffs(0, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_39", CubeListBuilder.create().texOffs(12, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_40", CubeListBuilder.create().texOffs(24, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_41", CubeListBuilder.create().texOffs(36, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_42", CubeListBuilder.create().texOffs(48, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_43", CubeListBuilder.create().texOffs(60, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_44", CubeListBuilder.create().texOffs(72, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_45", CubeListBuilder.create().texOffs(84, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_46", CubeListBuilder.create().texOffs(96, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_47", CubeListBuilder.create().texOffs(108, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_48", CubeListBuilder.create().texOffs(120, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_49", CubeListBuilder.create().texOffs(132, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_50", CubeListBuilder.create().texOffs(144, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_51", CubeListBuilder.create().texOffs(590, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -19.791666666666668F, -22.0F, -1.5707963267948966F, 0.0F, 0.1651486774146267F));
        g.addOrReplaceChild("casco_ladoi_52", CubeListBuilder.create().texOffs(296, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -19.35F, -22.0F, -1.5707963267948966F, 0.0F, 0.08257433870731362F));
        g.addOrReplaceChild("casco_ladoi_53", CubeListBuilder.create().texOffs(304, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -19.15F, -22.0F, -1.5707963267948966F, 0.0F, 0.08257433870731362F));
        g.addOrReplaceChild("casco_ladoi_54", CubeListBuilder.create().texOffs(1010, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -18.983333333333334F, -22.0F, -1.5707963267948966F, 0.0F, 0.08257433870731246F));
        g.addOrReplaceChild("casco_ladoi_55", CubeListBuilder.create().texOffs(556, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -18.85F, -22.0F, -1.5707963267948966F, 0.0F, 0.08257433870731465F));
        g.addOrReplaceChild("casco_ladoi_56", CubeListBuilder.create().texOffs(560, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -18.75F, -22.0F, -1.5707963267948966F, 0.0F, 0.08257433870731229F));
        g.addOrReplaceChild("casco_ladoi_57", CubeListBuilder.create().texOffs(564, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -18.683333333333337F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_58", CubeListBuilder.create().texOffs(972, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.02294921875F, -22.0F, -1.5707963267948966F, 0.0F, -0.16451516467074442F));
        g.addOrReplaceChild("casco_ladoi_59", CubeListBuilder.create().texOffs(978, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.22216796875F, -22.0F, -1.5707963267948966F, 0.0F, -0.1645151646707421F));
        g.addOrReplaceChild("casco_ladoi_60", CubeListBuilder.create().texOffs(478, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -18.9404296875F, -22.0F, -1.5707963267948966F, 0.0F, -0.29619842747256747F));
        g.addOrReplaceChild("casco_ladoi_61", CubeListBuilder.create().texOffs(604, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -20.21484375F, -22.0F, -1.5707963267948966F, 0.0F, -0.320578221991157F));
        g.addOrReplaceChild("casco_ladoi_62", CubeListBuilder.create().texOffs(156, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -21.376953125F, -22.0F, -1.5707963267948966F, 0.0F, -0.16028911099557858F));
        g.addOrReplaceChild("casco_ladoi_63", CubeListBuilder.create().texOffs(1016, 324).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_64", CubeListBuilder.create().texOffs(168, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_65", CubeListBuilder.create().texOffs(180, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_66", CubeListBuilder.create().texOffs(192, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_67", CubeListBuilder.create().texOffs(204, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_68", CubeListBuilder.create().texOffs(216, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_69", CubeListBuilder.create().texOffs(228, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_70", CubeListBuilder.create().texOffs(240, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_71", CubeListBuilder.create().texOffs(252, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_72", CubeListBuilder.create().texOffs(264, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_73", CubeListBuilder.create().texOffs(276, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
    }

    private static void piezas13(PartDefinition g) {
        g.addOrReplaceChild("casco_ladoi_74", CubeListBuilder.create().texOffs(288, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_75", CubeListBuilder.create().texOffs(300, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_76", CubeListBuilder.create().texOffs(312, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_77", CubeListBuilder.create().texOffs(324, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_78", CubeListBuilder.create().texOffs(336, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_79", CubeListBuilder.create().texOffs(348, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_80", CubeListBuilder.create().texOffs(618, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -21.319444444444443F, -22.0F, -1.5707963267948966F, 0.0F, 0.27094685033842086F));
        g.addOrReplaceChild("casco_ladoi_81", CubeListBuilder.create().texOffs(312, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -20.583333333333332F, -22.0F, -1.5707963267948966F, 0.0F, 0.13547342516920977F));
        g.addOrReplaceChild("casco_ladoi_82", CubeListBuilder.create().texOffs(320, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -20.25F, -22.0F, -1.5707963267948966F, 0.0F, 0.13547342516921063F));
        g.addOrReplaceChild("casco_ladoi_83", CubeListBuilder.create().texOffs(0, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -19.97222222222222F, -22.0F, -1.5707963267948966F, 0.0F, 0.13547342516920965F));
        g.addOrReplaceChild("casco_ladoi_84", CubeListBuilder.create().texOffs(568, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -19.75F, -22.0F, -1.5707963267948966F, 0.0F, 0.13547342516921104F));
        g.addOrReplaceChild("casco_ladoi_85", CubeListBuilder.create().texOffs(572, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -19.583333333333336F, -22.0F, -1.5707963267948966F, 0.0F, 0.13547342516921065F));
        g.addOrReplaceChild("casco_ladoi_86", CubeListBuilder.create().texOffs(576, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -19.47222222222222F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_87", CubeListBuilder.create().texOffs(984, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.232128906250004F, -22.0F, -1.5707963267948966F, 0.0F, -0.22836736238143945F));
        g.addOrReplaceChild("casco_ladoi_88", CubeListBuilder.create().texOffs(990, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.511035156250003F, -22.0F, -1.5707963267948966F, 0.0F, -0.22836736238143773F));
        g.addOrReplaceChild("casco_ladoi_89", CubeListBuilder.create().texOffs(490, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -19.5166015625F, -22.0F, -1.5707963267948966F, 0.0F, -0.4037715697853255F));
        g.addOrReplaceChild("casco_ladoi_90", CubeListBuilder.create().texOffs(632, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -21.30078125F, -22.0F, -1.5707963267948966F, 0.0F, -0.43512919388924687F));
        g.addOrReplaceChild("casco_ladoi_91", CubeListBuilder.create().texOffs(360, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -22.927734375F, -22.0F, -1.5707963267948966F, 0.0F, -0.21756459694462352F));
        g.addOrReplaceChild("casco_ladoi_92", CubeListBuilder.create().texOffs(6, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_93", CubeListBuilder.create().texOffs(372, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_94", CubeListBuilder.create().texOffs(384, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_95", CubeListBuilder.create().texOffs(396, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_96", CubeListBuilder.create().texOffs(408, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_97", CubeListBuilder.create().texOffs(420, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_98", CubeListBuilder.create().texOffs(432, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_99", CubeListBuilder.create().texOffs(444, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_100", CubeListBuilder.create().texOffs(456, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_101", CubeListBuilder.create().texOffs(468, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_102", CubeListBuilder.create().texOffs(480, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_103", CubeListBuilder.create().texOffs(492, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_104", CubeListBuilder.create().texOffs(504, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_105", CubeListBuilder.create().texOffs(516, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_106", CubeListBuilder.create().texOffs(528, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_107", CubeListBuilder.create().texOffs(540, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_108", CubeListBuilder.create().texOffs(552, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_109", CubeListBuilder.create().texOffs(646, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -22.84722222222222F, -22.0F, -1.5707963267948966F, 0.0F, 0.3708912888126627F));
        g.addOrReplaceChild("casco_ladoi_110", CubeListBuilder.create().texOffs(328, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -21.816666666666666F, -22.0F, -1.5707963267948966F, 0.0F, 0.1854456444063307F));
        g.addOrReplaceChild("casco_ladoi_111", CubeListBuilder.create().texOffs(336, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -21.349999999999998F, -22.0F, -1.5707963267948966F, 0.0F, 0.18544564440633182F));
        g.addOrReplaceChild("casco_ladoi_112", CubeListBuilder.create().texOffs(12, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -20.96111111111111F, -22.0F, -1.5707963267948966F, 0.0F, 0.1854456444063309F));
        g.addOrReplaceChild("casco_ladoi_113", CubeListBuilder.create().texOffs(580, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -20.65F, -22.0F, -1.5707963267948966F, 0.0F, 0.18544564440633143F));
        g.addOrReplaceChild("casco_ladoi_114", CubeListBuilder.create().texOffs(584, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -20.416666666666664F, -22.0F, -1.5707963267948966F, 0.0F, 0.1854456444063313F));
        g.addOrReplaceChild("casco_ladoi_115", CubeListBuilder.create().texOffs(588, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -20.26111111111111F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_116", CubeListBuilder.create().texOffs(592, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.180367808226126F, -21.97826403838506F, -1.7735463742713533F, -0.009638353161039436F, -0.3064795174657339F));
        g.addOrReplaceChild("casco_ladoi_117", CubeListBuilder.create().texOffs(996, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.496817951587115F, -21.968154288796715F, -1.7735463742713498F, -0.009638353161041288F, -0.3064795174657344F));
        g.addOrReplaceChild("casco_ladoi_118", CubeListBuilder.create().texOffs(1002, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.8765581236203F, -21.9560225892907F, -1.7735463742713529F, -0.009638353161041323F, -0.30647951746573376F));
        g.addOrReplaceChild("casco_ladoi_119", CubeListBuilder.create().texOffs(502, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.07525664553938F, -21.94618045072087F, -1.7886368652024789F, -0.0014647890075800583F, -0.46084606897965286F));
        g.addOrReplaceChild("casco_ladoi_120", CubeListBuilder.create().texOffs(514, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -22.130762574273817F, -21.942909649383466F, -1.7923385276323984F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_121", CubeListBuilder.create().texOffs(320, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -23.990137574273817F, -21.942909649383466F, -1.7923385276323986F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_122", CubeListBuilder.create().texOffs(596, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_123", CubeListBuilder.create().texOffs(330, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_124", CubeListBuilder.create().texOffs(340, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_125", CubeListBuilder.create().texOffs(350, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_126", CubeListBuilder.create().texOffs(360, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_127", CubeListBuilder.create().texOffs(370, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_128", CubeListBuilder.create().texOffs(380, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_129", CubeListBuilder.create().texOffs(390, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_130", CubeListBuilder.create().texOffs(400, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_131", CubeListBuilder.create().texOffs(410, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_132", CubeListBuilder.create().texOffs(420, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_133", CubeListBuilder.create().texOffs(430, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_134", CubeListBuilder.create().texOffs(440, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_135", CubeListBuilder.create().texOffs(450, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_136", CubeListBuilder.create().texOffs(460, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_137", CubeListBuilder.create().texOffs(470, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_138", CubeListBuilder.create().texOffs(480, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_139", CubeListBuilder.create().texOffs(526, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -23.89812368538493F, -21.942909649383466F, -1.785126256462946F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladoi_140", CubeListBuilder.create().texOffs(1008, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -22.72034590760715F, -21.942909649383466F, -1.785126256462946F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladoi_141", CubeListBuilder.create().texOffs(1014, 334).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -22.187012574273815F, -21.942909649383466F, -1.7851262564629462F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladoi_142", CubeListBuilder.create().texOffs(600, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -21.742568129829372F, -21.942909649383466F, -1.7807768282625926F, -0.043279581922705194F, 0.21793548935718107F));
        g.addOrReplaceChild("casco_ladoi_143", CubeListBuilder.create().texOffs(604, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -21.387012574273815F, -21.942909649383466F, -1.7807768282625926F, -0.0432795819227055F, 0.2179354893571824F));
        g.addOrReplaceChild("casco_ladoi_144", CubeListBuilder.create().texOffs(608, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -21.12034590760715F, -21.942909649383466F, -1.7807768282625926F, -0.04327958192270517F, 0.21793548935718102F));
        g.addOrReplaceChild("casco_ladoi_145", CubeListBuilder.create().texOffs(612, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -20.94256812982937F, -21.942909649383466F, -1.7807768282625929F, -0.04327958192270562F, 0.2179354893571827F));
        g.addOrReplaceChild("casco_ladoi_146", CubeListBuilder.create().texOffs(616, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.382279939885255F, -21.894629295044187F, -2.183480950305094F, -0.04530944696258163F, -0.3894077494538908F));
        g.addOrReplaceChild("casco_ladoi_147", CubeListBuilder.create().texOffs(0, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.79264270262258F, -21.84561966483218F, -2.1834809503051F, -0.045309446962581615F, -0.3894077494538931F));
        g.addOrReplaceChild("casco_ladoi_148", CubeListBuilder.create().texOffs(6, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.285078017907374F, -21.786808108577773F, -2.1834809503050985F, -0.04530944696258319F, -0.38940774945389084F));
        g.addOrReplaceChild("casco_ladoi_149", CubeListBuilder.create().texOffs(538, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.575203236925184F, -21.739095792106674F, -2.212338445519162F, -0.0070576043602407585F, -0.4729595476997946F));
        g.addOrReplaceChild("casco_ladoi_150", CubeListBuilder.create().texOffs(550, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -22.66109266016373F, -21.723239735273374F, -2.2185176378058538F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_151", CubeListBuilder.create().texOffs(490, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -24.52046766016373F, -21.723239735273374F, -2.2185176378058538F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_152", CubeListBuilder.create().texOffs(620, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_153", CubeListBuilder.create().texOffs(500, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_154", CubeListBuilder.create().texOffs(510, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_155", CubeListBuilder.create().texOffs(520, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_156", CubeListBuilder.create().texOffs(530, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_157", CubeListBuilder.create().texOffs(540, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_158", CubeListBuilder.create().texOffs(550, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_159", CubeListBuilder.create().texOffs(560, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_160", CubeListBuilder.create().texOffs(570, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_161", CubeListBuilder.create().texOffs(580, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_162", CubeListBuilder.create().texOffs(590, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_163", CubeListBuilder.create().texOffs(600, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
    }

    private static void piezas14(PartDefinition g) {
        g.addOrReplaceChild("casco_ladoi_164", CubeListBuilder.create().texOffs(610, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_165", CubeListBuilder.create().texOffs(620, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_166", CubeListBuilder.create().texOffs(630, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_167", CubeListBuilder.create().texOffs(640, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_168", CubeListBuilder.create().texOffs(650, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_169", CubeListBuilder.create().texOffs(562, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -24.42845377127484F, -21.723239735273374F, -2.202156205383196F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladoi_170", CubeListBuilder.create().texOffs(12, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.25067599349706F, -21.723239735273374F, -2.202156205383196F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladoi_171", CubeListBuilder.create().texOffs(18, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -22.717342660163723F, -21.723239735273374F, -2.2021562053831962F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladoi_172", CubeListBuilder.create().texOffs(624, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.27289821571928F, -21.723239735273374F, -2.1950704588806107F, -0.1013300717166445F, 0.2787153807148607F));
        g.addOrReplaceChild("casco_ladoi_173", CubeListBuilder.create().texOffs(628, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -21.917342660163726F, -21.723239735273374F, -2.1950704588806116F, -0.10133007171664508F, 0.2787153807148624F));
        g.addOrReplaceChild("casco_ladoi_174", CubeListBuilder.create().texOffs(632, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -21.65067599349706F, -21.723239735273374F, -2.1950704588806107F, -0.10133007171664438F, 0.27871538071486057F));
        g.addOrReplaceChild("casco_ladoi_175", CubeListBuilder.create().texOffs(636, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -21.472898215719283F, -21.723239735273374F, -2.1950704588806116F, -0.10133007171664528F, 0.27871538071486296F));
        g.addOrReplaceChild("casco_ladoi_176", CubeListBuilder.create().texOffs(24, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.53681679504419F, -21.740092439885252F, -2.582873959244832F, -0.10845998036298939F, -0.4493392298148658F));
        g.addOrReplaceChild("casco_ladoi_177", CubeListBuilder.create().texOffs(30, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.019057164832184F, -21.61920520262258F, -2.5828739592448273F, -0.10845998036298805F, -0.44933922981486685F));
        g.addOrReplaceChild("casco_ladoi_178", CubeListBuilder.create().texOffs(36, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.597745608577775F, -21.474140517907372F, -2.5828739592448273F, -0.10845998036298911F, -0.4493392298148642F));
        g.addOrReplaceChild("casco_ladoi_179", CubeListBuilder.create().texOffs(574, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.95784579210667F, -21.356453236925184F, -2.6046386885488584F, -0.01732442858115882F, -0.4821306373393771F));
        g.addOrReplaceChild("casco_ladoi_180", CubeListBuilder.create().texOffs(586, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -23.066989735273374F, -21.317342660163728F, -2.608499901014315F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_181", CubeListBuilder.create().texOffs(660, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -24.926364735273374F, -21.317342660163728F, -2.608499901014315F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_182", CubeListBuilder.create().texOffs(640, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_183", CubeListBuilder.create().texOffs(670, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_184", CubeListBuilder.create().texOffs(680, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_185", CubeListBuilder.create().texOffs(690, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_186", CubeListBuilder.create().texOffs(700, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_187", CubeListBuilder.create().texOffs(710, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_188", CubeListBuilder.create().texOffs(720, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_189", CubeListBuilder.create().texOffs(730, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_190", CubeListBuilder.create().texOffs(740, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_191", CubeListBuilder.create().texOffs(750, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_192", CubeListBuilder.create().texOffs(760, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_193", CubeListBuilder.create().texOffs(770, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_194", CubeListBuilder.create().texOffs(780, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_195", CubeListBuilder.create().texOffs(790, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_196", CubeListBuilder.create().texOffs(800, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_197", CubeListBuilder.create().texOffs(810, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_198", CubeListBuilder.create().texOffs(820, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_199", CubeListBuilder.create().texOffs(598, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -24.834350846384485F, -21.317342660163728F, -2.5934232240457846F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladoi_200", CubeListBuilder.create().texOffs(42, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.65657306860671F, -21.317342660163728F, -2.5934232240457846F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladoi_201", CubeListBuilder.create().texOffs(48, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -23.123239735273376F, -21.317342660163728F, -2.593423224045785F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladoi_202", CubeListBuilder.create().texOffs(644, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.67879529082893F, -21.317342660163728F, -2.5905327765359143F, -0.09706816482927975F, 0.35873360420314093F));
        g.addOrReplaceChild("casco_ladoi_203", CubeListBuilder.create().texOffs(648, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -22.32323973527338F, -21.317342660163728F, -2.5905327765359147F, -0.09706816482928023F, 0.35873360420314304F));
        g.addOrReplaceChild("casco_ladoi_204", CubeListBuilder.create().texOffs(652, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -22.056573068606706F, -21.317342660163728F, -2.590532776535914F, -0.09706816482927975F, 0.3587336042031406F));
        g.addOrReplaceChild("casco_ladoi_205", CubeListBuilder.create().texOffs(656, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -21.87879529082893F, -21.317342660163728F, -2.5905327765359147F, -0.09706816482928046F, 0.35873360420314365F));
        g.addOrReplaceChild("casco_ladoi_206", CubeListBuilder.create().texOffs(54, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.620451538385062F, -21.538180308226124F, -2.9608197790121387F, -0.18823006473349232F, -0.48041642531146883F));
        g.addOrReplaceChild("casco_ladoi_207", CubeListBuilder.create().texOffs(60, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.141591788796717F, -21.323380451587113F, -2.9608197790121413F, -0.18823006473349305F, -0.48041642531146833F));
        g.addOrReplaceChild("casco_ladoi_208", CubeListBuilder.create().texOffs(66, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.766960089290702F, -21.065620623620298F, -2.960819779012138F, -0.18823006473349232F, -0.480416425311467F));
        g.addOrReplaceChild("casco_ladoi_209", CubeListBuilder.create().texOffs(610, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -21.16493045072087F, -20.85650664553938F, -2.9670193348032075F, -0.030696788914183027F, -0.4870576488112398F));
        g.addOrReplaceChild("casco_ladoi_210", CubeListBuilder.create().texOffs(622, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -23.286659649383466F, -20.787012574273817F, -2.967704111419101F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_211", CubeListBuilder.create().texOffs(830, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -25.146034649383466F, -20.787012574273817F, -2.967704111419101F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_212", CubeListBuilder.create().texOffs(660, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_213", CubeListBuilder.create().texOffs(840, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_214", CubeListBuilder.create().texOffs(850, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_215", CubeListBuilder.create().texOffs(860, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_216", CubeListBuilder.create().texOffs(870, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_217", CubeListBuilder.create().texOffs(880, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_218", CubeListBuilder.create().texOffs(890, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_219", CubeListBuilder.create().texOffs(900, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_220", CubeListBuilder.create().texOffs(910, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_221", CubeListBuilder.create().texOffs(920, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_222", CubeListBuilder.create().texOffs(930, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_223", CubeListBuilder.create().texOffs(940, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_224", CubeListBuilder.create().texOffs(950, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_225", CubeListBuilder.create().texOffs(960, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_226", CubeListBuilder.create().texOffs(970, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_227", CubeListBuilder.create().texOffs(980, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_228", CubeListBuilder.create().texOffs(990, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_229", CubeListBuilder.create().texOffs(634, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -25.054020760494573F, -20.787012574273817F, -2.961787325135448F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladoi_230", CubeListBuilder.create().texOffs(72, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.8762429827168F, -20.787012574273817F, -2.961787325135448F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladoi_231", CubeListBuilder.create().texOffs(78, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -23.342909649383465F, -20.787012574273817F, -2.961787325135448F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladoi_232", CubeListBuilder.create().texOffs(664, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.898465204939022F, -20.787012574273817F, -2.9616488678553012F, -0.03901873250032806F, 0.4111282952483033F));
        g.addOrReplaceChild("casco_ladoi_233", CubeListBuilder.create().texOffs(668, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -22.542909649383464F, -20.787012574273817F, -2.9616488678553017F, -0.03901873250032821F, 0.41112829524830585F));
        g.addOrReplaceChild("casco_ladoi_234", CubeListBuilder.create().texOffs(672, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -22.276242982716795F, -20.787012574273817F, -2.9616488678553012F, -0.03901873250032806F, 0.4111282952483032F));
        g.addOrReplaceChild("casco_ladoi_235", CubeListBuilder.create().texOffs(676, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -22.09846520493902F, -20.787012574273817F, -2.9616488678553017F, -0.03901873250032829F, 0.4111282952483067F));
        g.addOrReplaceChild("casco_ladod_0", CubeListBuilder.create().texOffs(84, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -17.60458984375F, 22.0F, 1.5707963267948966F, 0.0F, -0.033190931497111234F));
        g.addOrReplaceChild("casco_ladod_1", CubeListBuilder.create().texOffs(90, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -17.64443359375F, 22.0F, 1.5707963267948966F, 0.0F, -0.03319093149711221F));
        g.addOrReplaceChild("casco_ladod_2", CubeListBuilder.create().texOffs(646, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -17.7880859375F, 22.0F, 1.5707963267948966F, 0.0F, -0.060959533981966185F));
        g.addOrReplaceChild("casco_ladod_3", CubeListBuilder.create().texOffs(660, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -18.04296875F, 22.0F, 1.5707963267948966F, 0.0F, -0.06630889491982349F));
        g.addOrReplaceChild("casco_ladod_4", CubeListBuilder.create().texOffs(564, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -18.275390625F, 22.0F, 1.5707963267948966F, 0.0F, -0.03315444745991172F));
        g.addOrReplaceChild("casco_ladod_5", CubeListBuilder.create().texOffs(18, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_6", CubeListBuilder.create().texOffs(576, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_7", CubeListBuilder.create().texOffs(588, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_8", CubeListBuilder.create().texOffs(600, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_9", CubeListBuilder.create().texOffs(612, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_10", CubeListBuilder.create().texOffs(624, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_11", CubeListBuilder.create().texOffs(636, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_12", CubeListBuilder.create().texOffs(648, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_13", CubeListBuilder.create().texOffs(660, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_14", CubeListBuilder.create().texOffs(672, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_15", CubeListBuilder.create().texOffs(684, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_16", CubeListBuilder.create().texOffs(696, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_17", CubeListBuilder.create().texOffs(708, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
    }

    private static void piezas15(PartDefinition g) {
        g.addOrReplaceChild("casco_ladod_18", CubeListBuilder.create().texOffs(720, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_19", CubeListBuilder.create().texOffs(732, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_20", CubeListBuilder.create().texOffs(744, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_21", CubeListBuilder.create().texOffs(756, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_22", CubeListBuilder.create().texOffs(674, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -18.26388888888889F, 22.0F, 1.5707963267948966F, 0.0F, 0.05549850524571664F));
        g.addOrReplaceChild("casco_ladod_23", CubeListBuilder.create().texOffs(344, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -18.116666666666667F, 22.0F, 1.5707963267948966F, 0.0F, 0.02774925262285877F));
        g.addOrReplaceChild("casco_ladod_24", CubeListBuilder.create().texOffs(352, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -18.05F, 22.0F, 1.5707963267948966F, 0.0F, 0.027749252622858458F));
        g.addOrReplaceChild("casco_ladod_25", CubeListBuilder.create().texOffs(24, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -17.994444444444447F, 22.0F, 1.5707963267948966F, 0.0F, 0.02774925262285814F));
        g.addOrReplaceChild("casco_ladod_26", CubeListBuilder.create().texOffs(680, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.95F, 22.0F, 1.5707963267948966F, 0.0F, 0.02774925262285877F));
        g.addOrReplaceChild("casco_ladod_27", CubeListBuilder.create().texOffs(684, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -17.916666666666668F, 22.0F, 1.5707963267948966F, 0.0F, 0.027749252622857355F));
        g.addOrReplaceChild("casco_ladod_28", CubeListBuilder.create().texOffs(688, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -17.894444444444446F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_29", CubeListBuilder.create().texOffs(96, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -17.81376953125F, 22.0F, 1.5707963267948966F, 0.0F, -0.09928188012599692F));
        g.addOrReplaceChild("casco_ladod_30", CubeListBuilder.create().texOffs(102, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -17.93330078125F, 22.0F, 1.5707963267948966F, 0.0F, -0.0992818801259969F));
        g.addOrReplaceChild("casco_ladod_31", CubeListBuilder.create().texOffs(658, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -18.3642578125F, 22.0F, 1.5707963267948966F, 0.0F, -0.18109931064379278F));
        g.addOrReplaceChild("casco_ladod_32", CubeListBuilder.create().texOffs(688, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -19.12890625F, 22.0F, 1.5707963267948966F, 0.0F, -0.196644245190345F));
        g.addOrReplaceChild("casco_ladod_33", CubeListBuilder.create().texOffs(768, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -19.826171875F, 22.0F, 1.5707963267948966F, 0.0F, -0.09832212259517253F));
        g.addOrReplaceChild("casco_ladod_34", CubeListBuilder.create().texOffs(30, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_35", CubeListBuilder.create().texOffs(780, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_36", CubeListBuilder.create().texOffs(792, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_37", CubeListBuilder.create().texOffs(804, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_38", CubeListBuilder.create().texOffs(816, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_39", CubeListBuilder.create().texOffs(828, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_40", CubeListBuilder.create().texOffs(840, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_41", CubeListBuilder.create().texOffs(852, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_42", CubeListBuilder.create().texOffs(864, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_43", CubeListBuilder.create().texOffs(876, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_44", CubeListBuilder.create().texOffs(888, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_45", CubeListBuilder.create().texOffs(900, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_46", CubeListBuilder.create().texOffs(912, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_47", CubeListBuilder.create().texOffs(924, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_48", CubeListBuilder.create().texOffs(936, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_49", CubeListBuilder.create().texOffs(948, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_50", CubeListBuilder.create().texOffs(960, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_51", CubeListBuilder.create().texOffs(702, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -19.791666666666668F, 22.0F, 1.5707963267948966F, 0.0F, 0.1651486774146267F));
        g.addOrReplaceChild("casco_ladod_52", CubeListBuilder.create().texOffs(360, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -19.35F, 22.0F, 1.5707963267948966F, 0.0F, 0.08257433870731362F));
        g.addOrReplaceChild("casco_ladod_53", CubeListBuilder.create().texOffs(368, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -19.15F, 22.0F, 1.5707963267948966F, 0.0F, 0.08257433870731362F));
        g.addOrReplaceChild("casco_ladod_54", CubeListBuilder.create().texOffs(36, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -18.983333333333334F, 22.0F, 1.5707963267948966F, 0.0F, 0.08257433870731246F));
        g.addOrReplaceChild("casco_ladod_55", CubeListBuilder.create().texOffs(692, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -18.85F, 22.0F, 1.5707963267948966F, 0.0F, 0.08257433870731465F));
        g.addOrReplaceChild("casco_ladod_56", CubeListBuilder.create().texOffs(696, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -18.75F, 22.0F, 1.5707963267948966F, 0.0F, 0.08257433870731229F));
        g.addOrReplaceChild("casco_ladod_57", CubeListBuilder.create().texOffs(700, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -18.683333333333337F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_58", CubeListBuilder.create().texOffs(108, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.02294921875F, 22.0F, 1.5707963267948966F, 0.0F, -0.16451516467074442F));
        g.addOrReplaceChild("casco_ladod_59", CubeListBuilder.create().texOffs(114, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.22216796875F, 22.0F, 1.5707963267948966F, 0.0F, -0.1645151646707421F));
        g.addOrReplaceChild("casco_ladod_60", CubeListBuilder.create().texOffs(670, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -18.9404296875F, 22.0F, 1.5707963267948966F, 0.0F, -0.29619842747256747F));
        g.addOrReplaceChild("casco_ladod_61", CubeListBuilder.create().texOffs(716, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -20.21484375F, 22.0F, 1.5707963267948966F, 0.0F, -0.320578221991157F));
        g.addOrReplaceChild("casco_ladod_62", CubeListBuilder.create().texOffs(972, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -21.376953125F, 22.0F, 1.5707963267948966F, 0.0F, -0.16028911099557858F));
        g.addOrReplaceChild("casco_ladod_63", CubeListBuilder.create().texOffs(42, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_64", CubeListBuilder.create().texOffs(984, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_65", CubeListBuilder.create().texOffs(996, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_66", CubeListBuilder.create().texOffs(1008, 312).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_67", CubeListBuilder.create().texOffs(0, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_68", CubeListBuilder.create().texOffs(12, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_69", CubeListBuilder.create().texOffs(24, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_70", CubeListBuilder.create().texOffs(36, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_71", CubeListBuilder.create().texOffs(48, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_72", CubeListBuilder.create().texOffs(60, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_73", CubeListBuilder.create().texOffs(72, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_74", CubeListBuilder.create().texOffs(84, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_75", CubeListBuilder.create().texOffs(96, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_76", CubeListBuilder.create().texOffs(108, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_77", CubeListBuilder.create().texOffs(120, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_78", CubeListBuilder.create().texOffs(132, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_79", CubeListBuilder.create().texOffs(144, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_80", CubeListBuilder.create().texOffs(730, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -21.319444444444443F, 22.0F, 1.5707963267948966F, 0.0F, 0.27094685033842086F));
        g.addOrReplaceChild("casco_ladod_81", CubeListBuilder.create().texOffs(376, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -20.583333333333332F, 22.0F, 1.5707963267948966F, 0.0F, 0.13547342516920977F));
        g.addOrReplaceChild("casco_ladod_82", CubeListBuilder.create().texOffs(384, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -20.25F, 22.0F, 1.5707963267948966F, 0.0F, 0.13547342516921063F));
        g.addOrReplaceChild("casco_ladod_83", CubeListBuilder.create().texOffs(48, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -19.97222222222222F, 22.0F, 1.5707963267948966F, 0.0F, 0.13547342516920965F));
        g.addOrReplaceChild("casco_ladod_84", CubeListBuilder.create().texOffs(704, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -19.75F, 22.0F, 1.5707963267948966F, 0.0F, 0.13547342516921104F));
        g.addOrReplaceChild("casco_ladod_85", CubeListBuilder.create().texOffs(708, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -19.583333333333336F, 22.0F, 1.5707963267948966F, 0.0F, 0.13547342516921065F));
        g.addOrReplaceChild("casco_ladod_86", CubeListBuilder.create().texOffs(712, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -19.47222222222222F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_87", CubeListBuilder.create().texOffs(120, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.232128906250004F, 22.0F, 1.5707963267948966F, 0.0F, -0.22836736238143945F));
        g.addOrReplaceChild("casco_ladod_88", CubeListBuilder.create().texOffs(126, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.511035156250003F, 22.0F, 1.5707963267948966F, 0.0F, -0.22836736238143773F));
        g.addOrReplaceChild("casco_ladod_89", CubeListBuilder.create().texOffs(682, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -19.5166015625F, 22.0F, 1.5707963267948966F, 0.0F, -0.4037715697853255F));
        g.addOrReplaceChild("casco_ladod_90", CubeListBuilder.create().texOffs(744, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -21.30078125F, 22.0F, 1.5707963267948966F, 0.0F, -0.43512919388924687F));
        g.addOrReplaceChild("casco_ladod_91", CubeListBuilder.create().texOffs(156, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -22.927734375F, 22.0F, 1.5707963267948966F, 0.0F, -0.21756459694462352F));
        g.addOrReplaceChild("casco_ladod_92", CubeListBuilder.create().texOffs(54, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_93", CubeListBuilder.create().texOffs(168, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_94", CubeListBuilder.create().texOffs(180, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_95", CubeListBuilder.create().texOffs(192, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_96", CubeListBuilder.create().texOffs(204, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_97", CubeListBuilder.create().texOffs(216, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_98", CubeListBuilder.create().texOffs(228, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_99", CubeListBuilder.create().texOffs(240, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_100", CubeListBuilder.create().texOffs(252, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_101", CubeListBuilder.create().texOffs(264, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_102", CubeListBuilder.create().texOffs(276, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_103", CubeListBuilder.create().texOffs(288, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_104", CubeListBuilder.create().texOffs(300, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_105", CubeListBuilder.create().texOffs(312, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_106", CubeListBuilder.create().texOffs(324, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_107", CubeListBuilder.create().texOffs(336, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
    }

    private static void piezas16(PartDefinition g) {
        g.addOrReplaceChild("casco_ladod_108", CubeListBuilder.create().texOffs(348, 315).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_109", CubeListBuilder.create().texOffs(758, 309).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -22.84722222222222F, 22.0F, 1.5707963267948966F, 0.0F, 0.3708912888126627F));
        g.addOrReplaceChild("casco_ladod_110", CubeListBuilder.create().texOffs(392, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -21.816666666666666F, 22.0F, 1.5707963267948966F, 0.0F, 0.1854456444063307F));
        g.addOrReplaceChild("casco_ladod_111", CubeListBuilder.create().texOffs(400, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -21.349999999999998F, 22.0F, 1.5707963267948966F, 0.0F, 0.18544564440633182F));
        g.addOrReplaceChild("casco_ladod_112", CubeListBuilder.create().texOffs(60, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -20.96111111111111F, 22.0F, 1.5707963267948966F, 0.0F, 0.1854456444063309F));
        g.addOrReplaceChild("casco_ladod_113", CubeListBuilder.create().texOffs(716, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -20.65F, 22.0F, 1.5707963267948966F, 0.0F, 0.18544564440633143F));
        g.addOrReplaceChild("casco_ladod_114", CubeListBuilder.create().texOffs(720, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -20.416666666666664F, 22.0F, 1.5707963267948966F, 0.0F, 0.1854456444063313F));
        g.addOrReplaceChild("casco_ladod_115", CubeListBuilder.create().texOffs(724, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -20.26111111111111F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_116", CubeListBuilder.create().texOffs(728, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.180367808226126F, 21.97826403838506F, 1.7735463742713533F, 0.009638353161039436F, -0.3064795174657339F));
        g.addOrReplaceChild("casco_ladod_117", CubeListBuilder.create().texOffs(132, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.496817951587115F, 21.968154288796715F, 1.7735463742713498F, 0.009638353161041288F, -0.3064795174657344F));
        g.addOrReplaceChild("casco_ladod_118", CubeListBuilder.create().texOffs(138, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.8765581236203F, 21.9560225892907F, 1.7735463742713529F, 0.009638353161041323F, -0.30647951746573376F));
        g.addOrReplaceChild("casco_ladod_119", CubeListBuilder.create().texOffs(694, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.07525664553938F, 21.94618045072087F, 1.7886368652024789F, 0.0014647890075800583F, -0.46084606897965286F));
        g.addOrReplaceChild("casco_ladod_120", CubeListBuilder.create().texOffs(706, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -22.130762574273817F, 21.942909649383466F, 1.7923385276323984F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_121", CubeListBuilder.create().texOffs(1000, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -23.990137574273817F, 21.942909649383466F, 1.7923385276323986F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_122", CubeListBuilder.create().texOffs(732, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_123", CubeListBuilder.create().texOffs(1010, 332).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_124", CubeListBuilder.create().texOffs(0, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_125", CubeListBuilder.create().texOffs(10, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_126", CubeListBuilder.create().texOffs(20, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_127", CubeListBuilder.create().texOffs(30, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_128", CubeListBuilder.create().texOffs(40, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_129", CubeListBuilder.create().texOffs(50, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_130", CubeListBuilder.create().texOffs(60, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_131", CubeListBuilder.create().texOffs(70, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_132", CubeListBuilder.create().texOffs(80, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_133", CubeListBuilder.create().texOffs(90, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_134", CubeListBuilder.create().texOffs(100, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_135", CubeListBuilder.create().texOffs(110, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_136", CubeListBuilder.create().texOffs(120, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_137", CubeListBuilder.create().texOffs(130, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_138", CubeListBuilder.create().texOffs(140, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_139", CubeListBuilder.create().texOffs(718, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -23.89812368538493F, 21.942909649383466F, 1.785126256462946F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladod_140", CubeListBuilder.create().texOffs(144, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -22.72034590760715F, 21.942909649383466F, 1.785126256462946F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladod_141", CubeListBuilder.create().texOffs(150, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -22.187012574273815F, 21.942909649383466F, 1.7851262564629462F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladod_142", CubeListBuilder.create().texOffs(736, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -21.742568129829372F, 21.942909649383466F, 1.7807768282625926F, 0.043279581922705194F, 0.21793548935718107F));
        g.addOrReplaceChild("casco_ladod_143", CubeListBuilder.create().texOffs(740, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -21.387012574273815F, 21.942909649383466F, 1.7807768282625926F, 0.0432795819227055F, 0.2179354893571824F));
        g.addOrReplaceChild("casco_ladod_144", CubeListBuilder.create().texOffs(744, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -21.12034590760715F, 21.942909649383466F, 1.7807768282625926F, 0.04327958192270517F, 0.21793548935718102F));
        g.addOrReplaceChild("casco_ladod_145", CubeListBuilder.create().texOffs(748, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -20.94256812982937F, 21.942909649383466F, 1.7807768282625929F, 0.04327958192270562F, 0.2179354893571827F));
        g.addOrReplaceChild("casco_ladod_146", CubeListBuilder.create().texOffs(752, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.382279939885255F, 21.894629295044187F, 2.183480950305094F, 0.04530944696258163F, -0.3894077494538908F));
        g.addOrReplaceChild("casco_ladod_147", CubeListBuilder.create().texOffs(156, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.79264270262258F, 21.84561966483218F, 2.1834809503051F, 0.045309446962581615F, -0.3894077494538931F));
        g.addOrReplaceChild("casco_ladod_148", CubeListBuilder.create().texOffs(162, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.285078017907374F, 21.786808108577773F, 2.1834809503050985F, 0.04530944696258319F, -0.38940774945389084F));
        g.addOrReplaceChild("casco_ladod_149", CubeListBuilder.create().texOffs(730, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.575203236925184F, 21.739095792106674F, 2.212338445519162F, 0.0070576043602407585F, -0.4729595476997946F));
        g.addOrReplaceChild("casco_ladod_150", CubeListBuilder.create().texOffs(742, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -22.66109266016373F, 21.723239735273374F, 2.2185176378058538F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_151", CubeListBuilder.create().texOffs(150, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -24.52046766016373F, 21.723239735273374F, 2.2185176378058538F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_152", CubeListBuilder.create().texOffs(756, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_153", CubeListBuilder.create().texOffs(160, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_154", CubeListBuilder.create().texOffs(170, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_155", CubeListBuilder.create().texOffs(180, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_156", CubeListBuilder.create().texOffs(190, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_157", CubeListBuilder.create().texOffs(200, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_158", CubeListBuilder.create().texOffs(210, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_159", CubeListBuilder.create().texOffs(220, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_160", CubeListBuilder.create().texOffs(230, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_161", CubeListBuilder.create().texOffs(240, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_162", CubeListBuilder.create().texOffs(250, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_163", CubeListBuilder.create().texOffs(260, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_164", CubeListBuilder.create().texOffs(270, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_165", CubeListBuilder.create().texOffs(280, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_166", CubeListBuilder.create().texOffs(290, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_167", CubeListBuilder.create().texOffs(300, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_168", CubeListBuilder.create().texOffs(310, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_169", CubeListBuilder.create().texOffs(754, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -24.42845377127484F, 21.723239735273374F, 2.202156205383196F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladod_170", CubeListBuilder.create().texOffs(168, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.25067599349706F, 21.723239735273374F, 2.202156205383196F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladod_171", CubeListBuilder.create().texOffs(174, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -22.717342660163723F, 21.723239735273374F, 2.2021562053831962F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladod_172", CubeListBuilder.create().texOffs(760, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.27289821571928F, 21.723239735273374F, 2.1950704588806107F, 0.1013300717166445F, 0.2787153807148607F));
        g.addOrReplaceChild("casco_ladod_173", CubeListBuilder.create().texOffs(764, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -21.917342660163726F, 21.723239735273374F, 2.1950704588806116F, 0.10133007171664508F, 0.2787153807148624F));
        g.addOrReplaceChild("casco_ladod_174", CubeListBuilder.create().texOffs(768, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -21.65067599349706F, 21.723239735273374F, 2.1950704588806107F, 0.10133007171664438F, 0.27871538071486057F));
        g.addOrReplaceChild("casco_ladod_175", CubeListBuilder.create().texOffs(772, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -21.472898215719283F, 21.723239735273374F, 2.1950704588806116F, 0.10133007171664528F, 0.27871538071486296F));
        g.addOrReplaceChild("casco_ladod_176", CubeListBuilder.create().texOffs(180, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.53681679504419F, 21.740092439885252F, 2.582873959244832F, 0.10845998036298939F, -0.4493392298148658F));
        g.addOrReplaceChild("casco_ladod_177", CubeListBuilder.create().texOffs(186, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.019057164832184F, 21.61920520262258F, 2.5828739592448273F, 0.10845998036298805F, -0.44933922981486685F));
        g.addOrReplaceChild("casco_ladod_178", CubeListBuilder.create().texOffs(192, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.597745608577775F, 21.474140517907372F, 2.5828739592448273F, 0.10845998036298911F, -0.4493392298148642F));
        g.addOrReplaceChild("casco_ladod_179", CubeListBuilder.create().texOffs(766, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.95784579210667F, 21.356453236925184F, 2.6046386885488584F, 0.01732442858115882F, -0.4821306373393771F));
        g.addOrReplaceChild("casco_ladod_180", CubeListBuilder.create().texOffs(778, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -23.066989735273374F, 21.317342660163728F, 2.608499901014315F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_181", CubeListBuilder.create().texOffs(320, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -24.926364735273374F, 21.317342660163728F, 2.608499901014315F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_182", CubeListBuilder.create().texOffs(776, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_183", CubeListBuilder.create().texOffs(330, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_184", CubeListBuilder.create().texOffs(340, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_185", CubeListBuilder.create().texOffs(350, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_186", CubeListBuilder.create().texOffs(360, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_187", CubeListBuilder.create().texOffs(370, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_188", CubeListBuilder.create().texOffs(380, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_189", CubeListBuilder.create().texOffs(390, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_190", CubeListBuilder.create().texOffs(400, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_191", CubeListBuilder.create().texOffs(410, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_192", CubeListBuilder.create().texOffs(420, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_193", CubeListBuilder.create().texOffs(430, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_194", CubeListBuilder.create().texOffs(440, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_195", CubeListBuilder.create().texOffs(450, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_196", CubeListBuilder.create().texOffs(460, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_197", CubeListBuilder.create().texOffs(470, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
    }

    private static void piezas17(PartDefinition g) {
        g.addOrReplaceChild("casco_ladod_198", CubeListBuilder.create().texOffs(480, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_199", CubeListBuilder.create().texOffs(790, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -24.834350846384485F, 21.317342660163728F, 2.5934232240457846F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladod_200", CubeListBuilder.create().texOffs(198, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.65657306860671F, 21.317342660163728F, 2.5934232240457846F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladod_201", CubeListBuilder.create().texOffs(204, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -23.123239735273376F, 21.317342660163728F, 2.593423224045785F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladod_202", CubeListBuilder.create().texOffs(780, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.67879529082893F, 21.317342660163728F, 2.5905327765359143F, 0.09706816482927975F, 0.35873360420314093F));
        g.addOrReplaceChild("casco_ladod_203", CubeListBuilder.create().texOffs(784, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -22.32323973527338F, 21.317342660163728F, 2.5905327765359147F, 0.09706816482928023F, 0.35873360420314304F));
        g.addOrReplaceChild("casco_ladod_204", CubeListBuilder.create().texOffs(788, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -22.056573068606706F, 21.317342660163728F, 2.590532776535914F, 0.09706816482927975F, 0.3587336042031406F));
        g.addOrReplaceChild("casco_ladod_205", CubeListBuilder.create().texOffs(792, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -21.87879529082893F, 21.317342660163728F, 2.5905327765359147F, 0.09706816482928046F, 0.35873360420314365F));
        g.addOrReplaceChild("casco_ladod_206", CubeListBuilder.create().texOffs(210, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.620451538385062F, 21.538180308226124F, 2.9608197790121387F, 0.18823006473349232F, -0.48041642531146883F));
        g.addOrReplaceChild("casco_ladod_207", CubeListBuilder.create().texOffs(216, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.141591788796717F, 21.323380451587113F, 2.9608197790121413F, 0.18823006473349305F, -0.48041642531146833F));
        g.addOrReplaceChild("casco_ladod_208", CubeListBuilder.create().texOffs(222, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.766960089290702F, 21.065620623620298F, 2.960819779012138F, 0.18823006473349232F, -0.480416425311467F));
        g.addOrReplaceChild("casco_ladod_209", CubeListBuilder.create().texOffs(802, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -21.16493045072087F, 20.85650664553938F, 2.9670193348032075F, 0.030696788914183027F, -0.4870576488112398F));
        g.addOrReplaceChild("casco_ladod_210", CubeListBuilder.create().texOffs(814, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -23.286659649383466F, 20.787012574273817F, 2.967704111419101F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_211", CubeListBuilder.create().texOffs(490, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -25.146034649383466F, 20.787012574273817F, 2.967704111419101F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_212", CubeListBuilder.create().texOffs(796, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_213", CubeListBuilder.create().texOffs(500, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_214", CubeListBuilder.create().texOffs(510, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_215", CubeListBuilder.create().texOffs(520, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_216", CubeListBuilder.create().texOffs(530, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_217", CubeListBuilder.create().texOffs(540, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_218", CubeListBuilder.create().texOffs(550, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_219", CubeListBuilder.create().texOffs(560, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_220", CubeListBuilder.create().texOffs(570, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_221", CubeListBuilder.create().texOffs(580, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_222", CubeListBuilder.create().texOffs(590, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_223", CubeListBuilder.create().texOffs(600, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_224", CubeListBuilder.create().texOffs(610, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_225", CubeListBuilder.create().texOffs(620, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_226", CubeListBuilder.create().texOffs(630, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_227", CubeListBuilder.create().texOffs(640, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_228", CubeListBuilder.create().texOffs(650, 334).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_229", CubeListBuilder.create().texOffs(826, 327).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -25.054020760494573F, 20.787012574273817F, 2.961787325135448F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladod_230", CubeListBuilder.create().texOffs(228, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.8762429827168F, 20.787012574273817F, 2.961787325135448F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladod_231", CubeListBuilder.create().texOffs(234, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -23.342909649383465F, 20.787012574273817F, 2.961787325135448F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladod_232", CubeListBuilder.create().texOffs(800, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.898465204939022F, 20.787012574273817F, 2.9616488678553012F, 0.03901873250032806F, 0.4111282952483033F));
        g.addOrReplaceChild("casco_ladod_233", CubeListBuilder.create().texOffs(804, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -22.542909649383464F, 20.787012574273817F, 2.9616488678553017F, 0.03901873250032821F, 0.41112829524830585F));
        g.addOrReplaceChild("casco_ladod_234", CubeListBuilder.create().texOffs(808, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -22.276242982716795F, 20.787012574273817F, 2.9616488678553012F, 0.03901873250032806F, 0.4111282952483032F));
        g.addOrReplaceChild("casco_ladod_235", CubeListBuilder.create().texOffs(812, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -22.09846520493902F, 20.787012574273817F, 2.9616488678553017F, 0.03901873250032829F, 0.4111282952483067F));
        g.addOrReplaceChild("casco_arriba0_0", CubeListBuilder.create().texOffs(984, 222).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, -18.255859375F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_1", CubeListBuilder.create().texOffs(1002, 222).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, -18.167317708333332F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_2", CubeListBuilder.create().texOffs(0, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, -18.034505208333332F, -3.141592653589793F, 0.0F, -0.48833395105640703F));
        g.addOrReplaceChild("casco_arriba0_3", CubeListBuilder.create().texOffs(624, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, -17.857421875F, -3.141592653589793F, 0.0F, -0.48833395105640487F));
        g.addOrReplaceChild("casco_arriba0_4", CubeListBuilder.create().texOffs(644, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, -17.636067708333332F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_5", CubeListBuilder.create().texOffs(664, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, -17.370442708333332F, -3.141592653589793F, 0.0F, -0.48833395105640476F));
        g.addOrReplaceChild("casco_arriba0_6", CubeListBuilder.create().texOffs(288, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, -17.154947916666668F, 3.141592653589793F, -0.015805724165091586F, -0.4883339510564056F));
        g.addOrReplaceChild("casco_arriba0_7", CubeListBuilder.create().texOffs(312, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, -17.083333333333336F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_8", CubeListBuilder.create().texOffs(720, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, -17.083333333333336F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_9", CubeListBuilder.create().texOffs(144, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_10", CubeListBuilder.create().texOffs(742, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_11", CubeListBuilder.create().texOffs(764, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_12", CubeListBuilder.create().texOffs(786, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_13", CubeListBuilder.create().texOffs(808, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_14", CubeListBuilder.create().texOffs(830, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_15", CubeListBuilder.create().texOffs(852, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_16", CubeListBuilder.create().texOffs(874, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_17", CubeListBuilder.create().texOffs(896, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_18", CubeListBuilder.create().texOffs(918, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_19", CubeListBuilder.create().texOffs(940, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_20", CubeListBuilder.create().texOffs(962, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_21", CubeListBuilder.create().texOffs(984, 231).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_22", CubeListBuilder.create().texOffs(0, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_23", CubeListBuilder.create().texOffs(22, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_24", CubeListBuilder.create().texOffs(44, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_25", CubeListBuilder.create().texOffs(66, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_26", CubeListBuilder.create().texOffs(336, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_27", CubeListBuilder.create().texOffs(946, 248).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_28", CubeListBuilder.create().texOffs(964, 248).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_29", CubeListBuilder.create().texOffs(160, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_30", CubeListBuilder.create().texOffs(176, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_31", CubeListBuilder.create().texOffs(192, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_32", CubeListBuilder.create().texOffs(208, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_arriba0_33", CubeListBuilder.create().texOffs(18, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, -10.953515625F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_34", CubeListBuilder.create().texOffs(36, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, -10.900390625F, -3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_35", CubeListBuilder.create().texOffs(54, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, -10.820703125000001F, -3.141592653589793F, 0.0F, -0.488333951056407F));
        g.addOrReplaceChild("casco_arriba0_36", CubeListBuilder.create().texOffs(684, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, -10.714453125F, -3.141592653589793F, 0.0F, -0.4883339510564049F));
        g.addOrReplaceChild("casco_arriba0_37", CubeListBuilder.create().texOffs(704, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, -10.581640625000002F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_38", CubeListBuilder.create().texOffs(724, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, -10.422265625F, -3.141592653589793F, 0.0F, -0.4883339510564047F));
        g.addOrReplaceChild("casco_arriba0_39", CubeListBuilder.create().texOffs(360, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, -10.292968750000002F, -3.141592653589793F, -0.009485456554255301F, -0.4883339510564056F));
        g.addOrReplaceChild("casco_arriba0_40", CubeListBuilder.create().texOffs(384, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, -10.250000000000002F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_41", CubeListBuilder.create().texOffs(88, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, -10.250000000000002F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_42", CubeListBuilder.create().texOffs(224, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_43", CubeListBuilder.create().texOffs(110, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_44", CubeListBuilder.create().texOffs(132, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_45", CubeListBuilder.create().texOffs(154, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_46", CubeListBuilder.create().texOffs(176, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_47", CubeListBuilder.create().texOffs(198, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_48", CubeListBuilder.create().texOffs(220, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_49", CubeListBuilder.create().texOffs(242, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_50", CubeListBuilder.create().texOffs(264, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_51", CubeListBuilder.create().texOffs(286, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
    }

    private static void piezas18(PartDefinition g) {
        g.addOrReplaceChild("casco_arriba0_52", CubeListBuilder.create().texOffs(308, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_53", CubeListBuilder.create().texOffs(330, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_54", CubeListBuilder.create().texOffs(352, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_55", CubeListBuilder.create().texOffs(374, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_56", CubeListBuilder.create().texOffs(396, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_57", CubeListBuilder.create().texOffs(418, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_58", CubeListBuilder.create().texOffs(440, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_59", CubeListBuilder.create().texOffs(408, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_60", CubeListBuilder.create().texOffs(982, 248).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_61", CubeListBuilder.create().texOffs(1000, 248).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_62", CubeListBuilder.create().texOffs(240, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_63", CubeListBuilder.create().texOffs(256, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_64", CubeListBuilder.create().texOffs(272, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_65", CubeListBuilder.create().texOffs(288, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_arriba0_66", CubeListBuilder.create().texOffs(72, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, -3.651171875F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_67", CubeListBuilder.create().texOffs(90, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, -3.633463541666667F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_68", CubeListBuilder.create().texOffs(108, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, -3.606901041666667F, -3.141592653589793F, 0.0F, -0.488333951056407F));
        g.addOrReplaceChild("casco_arriba0_69", CubeListBuilder.create().texOffs(744, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, -3.5714843750000003F, -3.141592653589793F, 0.0F, -0.4883339510564049F));
        g.addOrReplaceChild("casco_arriba0_70", CubeListBuilder.create().texOffs(764, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, -3.527213541666667F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_71", CubeListBuilder.create().texOffs(784, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, -3.4740885416666667F, -3.141592653589793F, 0.0F, -0.48833395105640476F));
        g.addOrReplaceChild("casco_arriba0_72", CubeListBuilder.create().texOffs(432, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, -3.4309895833333335F, 3.141592653589793F, -0.00316215605469034F, -0.4883339510564054F));
        g.addOrReplaceChild("casco_arriba0_73", CubeListBuilder.create().texOffs(456, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, -3.416666666666667F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_74", CubeListBuilder.create().texOffs(462, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, -3.416666666666667F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_75", CubeListBuilder.create().texOffs(304, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_76", CubeListBuilder.create().texOffs(484, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_77", CubeListBuilder.create().texOffs(506, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_78", CubeListBuilder.create().texOffs(528, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_79", CubeListBuilder.create().texOffs(550, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_80", CubeListBuilder.create().texOffs(572, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_81", CubeListBuilder.create().texOffs(594, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_82", CubeListBuilder.create().texOffs(616, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_83", CubeListBuilder.create().texOffs(638, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_84", CubeListBuilder.create().texOffs(660, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_85", CubeListBuilder.create().texOffs(682, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_86", CubeListBuilder.create().texOffs(704, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_87", CubeListBuilder.create().texOffs(726, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_88", CubeListBuilder.create().texOffs(748, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_89", CubeListBuilder.create().texOffs(770, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_90", CubeListBuilder.create().texOffs(792, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_91", CubeListBuilder.create().texOffs(814, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_92", CubeListBuilder.create().texOffs(480, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_93", CubeListBuilder.create().texOffs(0, 256).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_94", CubeListBuilder.create().texOffs(18, 256).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_95", CubeListBuilder.create().texOffs(320, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_96", CubeListBuilder.create().texOffs(336, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_97", CubeListBuilder.create().texOffs(352, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_98", CubeListBuilder.create().texOffs(368, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_arriba0_99", CubeListBuilder.create().texOffs(126, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, 3.6511718749999993F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_100", CubeListBuilder.create().texOffs(144, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, 3.633463541666666F, -3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_101", CubeListBuilder.create().texOffs(162, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, 3.6069010416666654F, -3.141592653589793F, 0.0F, -0.488333951056407F));
        g.addOrReplaceChild("casco_arriba0_102", CubeListBuilder.create().texOffs(804, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, 3.571484374999999F, -3.141592653589793F, 0.0F, -0.4883339510564049F));
        g.addOrReplaceChild("casco_arriba0_103", CubeListBuilder.create().texOffs(824, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, 3.527213541666666F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_104", CubeListBuilder.create().texOffs(844, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, 3.4740885416666663F, -3.141592653589793F, 0.0F, -0.48833395105640476F));
        g.addOrReplaceChild("casco_arriba0_105", CubeListBuilder.create().texOffs(504, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, 3.430989583333333F, -3.141592653589793F, 0.0031621560546904186F, -0.4883339510564054F));
        g.addOrReplaceChild("casco_arriba0_106", CubeListBuilder.create().texOffs(528, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, 3.416666666666666F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_107", CubeListBuilder.create().texOffs(836, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, 3.416666666666666F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_108", CubeListBuilder.create().texOffs(384, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_109", CubeListBuilder.create().texOffs(858, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_110", CubeListBuilder.create().texOffs(880, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_111", CubeListBuilder.create().texOffs(902, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_112", CubeListBuilder.create().texOffs(924, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_113", CubeListBuilder.create().texOffs(946, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_114", CubeListBuilder.create().texOffs(968, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_115", CubeListBuilder.create().texOffs(990, 240).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_116", CubeListBuilder.create().texOffs(0, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_117", CubeListBuilder.create().texOffs(22, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_118", CubeListBuilder.create().texOffs(44, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_119", CubeListBuilder.create().texOffs(66, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_120", CubeListBuilder.create().texOffs(88, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_121", CubeListBuilder.create().texOffs(110, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_122", CubeListBuilder.create().texOffs(132, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_123", CubeListBuilder.create().texOffs(154, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_124", CubeListBuilder.create().texOffs(176, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_125", CubeListBuilder.create().texOffs(552, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_126", CubeListBuilder.create().texOffs(36, 256).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_127", CubeListBuilder.create().texOffs(54, 256).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_128", CubeListBuilder.create().texOffs(400, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_129", CubeListBuilder.create().texOffs(416, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_130", CubeListBuilder.create().texOffs(432, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_131", CubeListBuilder.create().texOffs(448, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_arriba0_132", CubeListBuilder.create().texOffs(180, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, 10.953515624999998F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_133", CubeListBuilder.create().texOffs(198, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, 10.900390624999998F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_134", CubeListBuilder.create().texOffs(216, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, 10.820703124999996F, -3.141592653589793F, 0.0F, -0.488333951056407F));
        g.addOrReplaceChild("casco_arriba0_135", CubeListBuilder.create().texOffs(864, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, 10.714453124999995F, -3.141592653589793F, 0.0F, -0.4883339510564049F));
        g.addOrReplaceChild("casco_arriba0_136", CubeListBuilder.create().texOffs(884, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, 10.581640624999997F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_137", CubeListBuilder.create().texOffs(904, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, 10.422265624999998F, -3.141592653589793F, 0.0F, -0.4883339510564047F));
        g.addOrReplaceChild("casco_arriba0_138", CubeListBuilder.create().texOffs(576, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, 10.29296875F, 3.141592653589793F, 0.009485456554255537F, -0.4883339510564056F));
        g.addOrReplaceChild("casco_arriba0_139", CubeListBuilder.create().texOffs(600, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, 10.249999999999998F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_140", CubeListBuilder.create().texOffs(198, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, 10.249999999999998F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_141", CubeListBuilder.create().texOffs(464, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.0F));
    }

    private static void piezas19(PartDefinition g) {
        g.addOrReplaceChild("casco_arriba0_142", CubeListBuilder.create().texOffs(220, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_143", CubeListBuilder.create().texOffs(242, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_144", CubeListBuilder.create().texOffs(264, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_145", CubeListBuilder.create().texOffs(286, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_146", CubeListBuilder.create().texOffs(308, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_147", CubeListBuilder.create().texOffs(330, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_148", CubeListBuilder.create().texOffs(352, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_149", CubeListBuilder.create().texOffs(374, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_150", CubeListBuilder.create().texOffs(396, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_151", CubeListBuilder.create().texOffs(418, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_152", CubeListBuilder.create().texOffs(440, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_153", CubeListBuilder.create().texOffs(462, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_154", CubeListBuilder.create().texOffs(484, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_155", CubeListBuilder.create().texOffs(506, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_156", CubeListBuilder.create().texOffs(528, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_157", CubeListBuilder.create().texOffs(550, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_158", CubeListBuilder.create().texOffs(624, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_159", CubeListBuilder.create().texOffs(72, 256).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_160", CubeListBuilder.create().texOffs(90, 256).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_161", CubeListBuilder.create().texOffs(480, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_162", CubeListBuilder.create().texOffs(496, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_163", CubeListBuilder.create().texOffs(512, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_164", CubeListBuilder.create().texOffs(528, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_arriba0_165", CubeListBuilder.create().texOffs(234, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, 18.255859375F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_166", CubeListBuilder.create().texOffs(252, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, 18.167317708333332F, -3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_167", CubeListBuilder.create().texOffs(270, 231).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, 18.03450520833333F, -3.141592653589793F, 0.0F, -0.48833395105640703F));
        g.addOrReplaceChild("casco_arriba0_168", CubeListBuilder.create().texOffs(924, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, 17.857421874999996F, -3.141592653589793F, 0.0F, -0.488333951056405F));
        g.addOrReplaceChild("casco_arriba0_169", CubeListBuilder.create().texOffs(944, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, 17.63606770833333F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_170", CubeListBuilder.create().texOffs(964, 222).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, 17.370442708333332F, -3.141592653589793F, 0.0F, -0.4883339510564048F));
        g.addOrReplaceChild("casco_arriba0_171", CubeListBuilder.create().texOffs(648, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, 17.154947916666664F, -3.141592653589793F, 0.015805724165091743F, -0.4883339510564056F));
        g.addOrReplaceChild("casco_arriba0_172", CubeListBuilder.create().texOffs(672, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, 17.083333333333332F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_173", CubeListBuilder.create().texOffs(572, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, 17.083333333333332F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_174", CubeListBuilder.create().texOffs(544, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_175", CubeListBuilder.create().texOffs(594, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_176", CubeListBuilder.create().texOffs(616, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_177", CubeListBuilder.create().texOffs(638, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_178", CubeListBuilder.create().texOffs(660, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_179", CubeListBuilder.create().texOffs(682, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_180", CubeListBuilder.create().texOffs(704, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_181", CubeListBuilder.create().texOffs(726, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_182", CubeListBuilder.create().texOffs(748, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_183", CubeListBuilder.create().texOffs(770, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_184", CubeListBuilder.create().texOffs(792, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_185", CubeListBuilder.create().texOffs(814, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_186", CubeListBuilder.create().texOffs(836, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_187", CubeListBuilder.create().texOffs(858, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_188", CubeListBuilder.create().texOffs(880, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_189", CubeListBuilder.create().texOffs(902, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_190", CubeListBuilder.create().texOffs(924, 248).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_191", CubeListBuilder.create().texOffs(696, 231).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_192", CubeListBuilder.create().texOffs(108, 256).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_193", CubeListBuilder.create().texOffs(126, 256).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_194", CubeListBuilder.create().texOffs(560, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_195", CubeListBuilder.create().texOffs(576, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_196", CubeListBuilder.create().texOffs(592, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_197", CubeListBuilder.create().texOffs(608, 256).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_trompa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -21.0F, 0.0F, 1.0F, 21.0F, 88.0F), PartPose.offset(-47.0F, -16.5F, -22.0F));
        g.addOrReplaceChild("casco_cola", CubeListBuilder.create().texOffs(178, 0).addBox(0.0F, -21.0F, 0.0F, 1.0F, 21.0F, 88.0F), PartPose.offset(42.0F, -16.5F, -22.0F));
        g.addOrReplaceChild("brocal_conductor", CubeListBuilder.create().texOffs(832, 109).addBox(-31.0F, -27.0F, -17.0F, 1.0F, 1.0F, 16.0F).texOffs(866, 109).addBox(-18.0F, -27.0F, -17.0F, 1.0F, 1.0F, 16.0F).texOffs(402, 327).addBox(-30.0F, -27.0F, -18.0F, 12.0F, 1.0F, 1.0F).texOffs(428, 327).addBox(-30.0F, -27.0F, -1.0F, 12.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tapa_conductor", CubeListBuilder.create().texOffs(812, 0).addBox(-18.0F, 0.0F, -18.0F, 36.0F, 1.0F, 36.0F), PartPose.offsetAndRotation(-24.0F, -29.0F, -19.5F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("torreta_ladoi_0", CubeListBuilder.create().texOffs(66, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -27.0F, -3.4826435063320007F, -1.5707963267948966F, 0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_1", CubeListBuilder.create().texOffs(408, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -27.0F, -4.339958396679818F, -1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_2", CubeListBuilder.create().texOffs(416, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -27.0F, -5.803540081128164F, -1.5707963267948966F, 1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_3", CubeListBuilder.create().texOffs(424, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -27.0F, -7.255417854035452F, -1.5707963267948966F, 1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_4", CubeListBuilder.create().texOffs(432, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -27.0F, -8.65750878476372F, -1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_5", CubeListBuilder.create().texOffs(440, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -27.0F, -9.983733334909786F, -1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_6", CubeListBuilder.create().texOffs(400, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -27.0F, -11.377641910438154F, -1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_7", CubeListBuilder.create().texOffs(410, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -27.0F, -12.68282077273567F, -1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_8", CubeListBuilder.create().texOffs(420, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -27.0F, -13.634988406141265F, -1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_9", CubeListBuilder.create().texOffs(430, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -27.0F, -14.306772954019928F, -1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_10", CubeListBuilder.create().texOffs(440, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -27.0F, -14.737347643231958F, -1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_11", CubeListBuilder.create().texOffs(450, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -27.0F, -14.947916036529765F, -1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_12", CubeListBuilder.create().texOffs(460, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -27.0F, -14.947916036529765F, -1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_13", CubeListBuilder.create().texOffs(470, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -27.0F, -14.737347643231958F, -1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_14", CubeListBuilder.create().texOffs(480, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -27.0F, -14.306772954019928F, -1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_15", CubeListBuilder.create().texOffs(490, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -27.0F, -13.634988406141265F, -1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_16", CubeListBuilder.create().texOffs(500, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -27.0F, -12.68282077273567F, -1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_17", CubeListBuilder.create().texOffs(510, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -27.0F, -11.377641910438154F, -1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_18", CubeListBuilder.create().texOffs(448, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -27.0F, -9.983733334909786F, -1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_19", CubeListBuilder.create().texOffs(456, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -27.0F, -8.657508784763722F, -1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_20", CubeListBuilder.create().texOffs(464, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -27.0F, -7.255417854035457F, -1.5707963267948966F, -1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_21", CubeListBuilder.create().texOffs(472, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -27.0F, -5.803540081128168F, -1.5707963267948966F, -1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_22", CubeListBuilder.create().texOffs(480, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -27.0F, -4.339958396679818F, -1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_23", CubeListBuilder.create().texOffs(72, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -27.0F, -3.482643506332001F, -1.5707963267948966F, -0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_24", CubeListBuilder.create().texOffs(78, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -29.0F, -3.4826435063320007F, -1.5707963267948966F, 0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_25", CubeListBuilder.create().texOffs(488, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -29.0F, -4.339958396679818F, -1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_26", CubeListBuilder.create().texOffs(496, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -29.0F, -5.803540081128164F, -1.5707963267948966F, 1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_27", CubeListBuilder.create().texOffs(504, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -29.0F, -7.255417854035452F, -1.5707963267948966F, 1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_28", CubeListBuilder.create().texOffs(512, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -29.0F, -8.65750878476372F, -1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_29", CubeListBuilder.create().texOffs(520, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -29.0F, -9.983733334909786F, -1.5707963267948966F, 0.7785852878410321F, 0.0F));
    }

    private static void piezas20(PartDefinition g) {
        g.addOrReplaceChild("torreta_ladoi_30", CubeListBuilder.create().texOffs(520, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -29.0F, -11.377641910438154F, -1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_31", CubeListBuilder.create().texOffs(530, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -29.0F, -12.68282077273567F, -1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_32", CubeListBuilder.create().texOffs(540, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -29.0F, -13.634988406141265F, -1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_33", CubeListBuilder.create().texOffs(550, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -29.0F, -14.306772954019928F, -1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_34", CubeListBuilder.create().texOffs(560, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -29.0F, -14.737347643231958F, -1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_35", CubeListBuilder.create().texOffs(570, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -29.0F, -14.947916036529765F, -1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_36", CubeListBuilder.create().texOffs(580, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -29.0F, -14.947916036529765F, -1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_37", CubeListBuilder.create().texOffs(590, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -29.0F, -14.737347643231958F, -1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_38", CubeListBuilder.create().texOffs(600, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -29.0F, -14.306772954019928F, -1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_39", CubeListBuilder.create().texOffs(610, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -29.0F, -13.634988406141265F, -1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_40", CubeListBuilder.create().texOffs(620, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -29.0F, -12.68282077273567F, -1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_41", CubeListBuilder.create().texOffs(630, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -29.0F, -11.377641910438154F, -1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_42", CubeListBuilder.create().texOffs(528, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -29.0F, -9.983733334909786F, -1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_43", CubeListBuilder.create().texOffs(536, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -29.0F, -8.657508784763722F, -1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_44", CubeListBuilder.create().texOffs(544, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -29.0F, -7.255417854035457F, -1.5707963267948966F, -1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_45", CubeListBuilder.create().texOffs(552, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -29.0F, -5.803540081128168F, -1.5707963267948966F, -1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_46", CubeListBuilder.create().texOffs(560, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -29.0F, -4.339958396679818F, -1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_47", CubeListBuilder.create().texOffs(84, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -29.0F, -3.482643506332001F, -1.5707963267948966F, -0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_48", CubeListBuilder.create().texOffs(90, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -31.0F, -3.4826435063320007F, -1.5707963267948966F, 0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_49", CubeListBuilder.create().texOffs(568, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -31.0F, -4.339958396679818F, -1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_50", CubeListBuilder.create().texOffs(576, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -31.0F, -5.803540081128164F, -1.5707963267948966F, 1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_51", CubeListBuilder.create().texOffs(584, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -31.0F, -7.255417854035452F, -1.5707963267948966F, 1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_52", CubeListBuilder.create().texOffs(592, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -31.0F, -8.65750878476372F, -1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_53", CubeListBuilder.create().texOffs(600, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -31.0F, -9.983733334909786F, -1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_54", CubeListBuilder.create().texOffs(640, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -31.0F, -11.377641910438154F, -1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_55", CubeListBuilder.create().texOffs(650, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -31.0F, -12.68282077273567F, -1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_56", CubeListBuilder.create().texOffs(660, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -31.0F, -13.634988406141265F, -1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_57", CubeListBuilder.create().texOffs(670, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -31.0F, -14.306772954019928F, -1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_58", CubeListBuilder.create().texOffs(680, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -31.0F, -14.737347643231958F, -1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_59", CubeListBuilder.create().texOffs(690, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -31.0F, -14.947916036529765F, -1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_60", CubeListBuilder.create().texOffs(700, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -31.0F, -14.947916036529765F, -1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_61", CubeListBuilder.create().texOffs(710, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -31.0F, -14.737347643231958F, -1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_62", CubeListBuilder.create().texOffs(720, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -31.0F, -14.306772954019928F, -1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_63", CubeListBuilder.create().texOffs(730, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -31.0F, -13.634988406141265F, -1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_64", CubeListBuilder.create().texOffs(740, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -31.0F, -12.68282077273567F, -1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_65", CubeListBuilder.create().texOffs(750, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -31.0F, -11.377641910438154F, -1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_66", CubeListBuilder.create().texOffs(608, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -31.0F, -9.983733334909786F, -1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_67", CubeListBuilder.create().texOffs(616, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -31.0F, -8.657508784763722F, -1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_68", CubeListBuilder.create().texOffs(624, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -31.0F, -7.255417854035457F, -1.5707963267948966F, -1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_69", CubeListBuilder.create().texOffs(632, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -31.0F, -5.803540081128168F, -1.5707963267948966F, -1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_70", CubeListBuilder.create().texOffs(640, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -31.0F, -4.339958396679818F, -1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_71", CubeListBuilder.create().texOffs(96, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -31.0F, -3.482643506332001F, -1.5707963267948966F, -0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_72", CubeListBuilder.create().texOffs(102, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -33.0F, -3.4826435063320007F, -1.5707963267948966F, 0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_73", CubeListBuilder.create().texOffs(648, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -33.0F, -4.339958396679818F, -1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_74", CubeListBuilder.create().texOffs(656, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -33.0F, -5.803540081128164F, -1.5707963267948966F, 1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_75", CubeListBuilder.create().texOffs(664, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -33.0F, -7.255417854035452F, -1.5707963267948966F, 1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_76", CubeListBuilder.create().texOffs(672, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -33.0F, -8.65750878476372F, -1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_77", CubeListBuilder.create().texOffs(680, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -33.0F, -9.983733334909786F, -1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_78", CubeListBuilder.create().texOffs(760, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -33.0F, -11.377641910438154F, -1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_79", CubeListBuilder.create().texOffs(770, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -33.0F, -12.68282077273567F, -1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_80", CubeListBuilder.create().texOffs(780, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -33.0F, -13.634988406141265F, -1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_81", CubeListBuilder.create().texOffs(790, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -33.0F, -14.306772954019928F, -1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_82", CubeListBuilder.create().texOffs(800, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -33.0F, -14.737347643231958F, -1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_83", CubeListBuilder.create().texOffs(810, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -33.0F, -14.947916036529765F, -1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_84", CubeListBuilder.create().texOffs(820, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -33.0F, -14.947916036529765F, -1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_85", CubeListBuilder.create().texOffs(830, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -33.0F, -14.737347643231958F, -1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_86", CubeListBuilder.create().texOffs(840, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -33.0F, -14.306772954019928F, -1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_87", CubeListBuilder.create().texOffs(850, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -33.0F, -13.634988406141265F, -1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_88", CubeListBuilder.create().texOffs(860, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -33.0F, -12.68282077273567F, -1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_89", CubeListBuilder.create().texOffs(870, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -33.0F, -11.377641910438154F, -1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_90", CubeListBuilder.create().texOffs(688, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -33.0F, -9.983733334909786F, -1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_91", CubeListBuilder.create().texOffs(696, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -33.0F, -8.657508784763722F, -1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_92", CubeListBuilder.create().texOffs(704, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -33.0F, -7.255417854035457F, -1.5707963267948966F, -1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_93", CubeListBuilder.create().texOffs(712, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -33.0F, -5.803540081128168F, -1.5707963267948966F, -1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_94", CubeListBuilder.create().texOffs(720, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -33.0F, -4.339958396679818F, -1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_95", CubeListBuilder.create().texOffs(108, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -33.0F, -3.482643506332001F, -1.5707963267948966F, -0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_96", CubeListBuilder.create().texOffs(114, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -34.57402514854763F, -3.3684628050989307F, -1.8250125743264949F, 0.6828977330950954F, -0.16252283561685563F));
        g.addOrReplaceChild("torreta_ladoi_97", CubeListBuilder.create().texOffs(728, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -34.57402514854763F, -4.225777695446748F, -1.8940078886793636F, 1.2222952223879582F, -0.274218461605764F));
        g.addOrReplaceChild("torreta_ladoi_98", CubeListBuilder.create().texOffs(736, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -34.57402514854763F, -5.689359379895094F, -1.8359021474358057F, 1.110771209834459F, -0.19973945437795396F));
        g.addOrReplaceChild("torreta_ladoi_99", CubeListBuilder.create().texOffs(744, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -34.57402514854763F, -7.141237152802382F, -1.8046564746427858F, 0.9963153976068317F, -0.15231653509744F));
        g.addOrReplaceChild("torreta_ladoi_100", CubeListBuilder.create().texOffs(752, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -34.57402514854763F, -8.543328083530652F, -1.7872668221271308F, 0.8813405994108005F, -0.11928590581640346F));
        g.addOrReplaceChild("torreta_ladoi_101", CubeListBuilder.create().texOffs(760, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -34.57402514854763F, -9.869552633676715F, -1.7774867102570833F, 0.7666989132568279F, -0.0945404819847156F));
        g.addOrReplaceChild("torreta_ladoi_102", CubeListBuilder.create().texOffs(880, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -34.57402514854763F, -11.263461209205083F, -1.7284015597582516F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_103", CubeListBuilder.create().texOffs(890, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -34.57402514854763F, -12.5686400715026F, -1.7685726602340672F, 0.49604440927838767F, -0.052924265248671616F));
        g.addOrReplaceChild("torreta_ladoi_104", CubeListBuilder.create().texOffs(900, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -34.57402514854763F, -13.520807704908194F, -1.7675268706013907F, 0.3734096587135649F, -0.03827065184366676F));
        g.addOrReplaceChild("torreta_ladoi_105", CubeListBuilder.create().texOffs(910, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -34.57402514854763F, -14.19259225278686F, -1.7672005563238273F, 0.26074408856128006F, -0.026042315212402013F));
        g.addOrReplaceChild("torreta_ladoi_106", CubeListBuilder.create().texOffs(920, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -34.57402514854763F, -14.623166941998889F, -1.7671377204012728F, 0.15421558868568414F, -0.015164715370441974F));
        g.addOrReplaceChild("torreta_ladoi_107", CubeListBuilder.create().texOffs(930, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -34.57402514854763F, -14.833735335296694F, -1.767143573659609F, 0.051047752130763846F, -0.004983004511430807F));
        g.addOrReplaceChild("torreta_ladoi_108", CubeListBuilder.create().texOffs(940, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -34.57402514854763F, -14.833735335296694F, -1.767143573659609F, -0.051047752130763846F, 0.004983004511430807F));
        g.addOrReplaceChild("torreta_ladoi_109", CubeListBuilder.create().texOffs(950, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -34.57402514854763F, -14.623166941998889F, -1.7671377204012728F, -0.15421558868568414F, 0.015164715370441974F));
        g.addOrReplaceChild("torreta_ladoi_110", CubeListBuilder.create().texOffs(960, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -34.57402514854763F, -14.19259225278686F, -1.7672005563238273F, -0.26074408856128006F, 0.026042315212402013F));
        g.addOrReplaceChild("torreta_ladoi_111", CubeListBuilder.create().texOffs(970, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -34.57402514854763F, -13.520807704908194F, -1.7675268706013907F, -0.3734096587135649F, 0.03827065184366676F));
        g.addOrReplaceChild("torreta_ladoi_112", CubeListBuilder.create().texOffs(980, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -34.57402514854763F, -12.5686400715026F, -1.7685726602340672F, -0.49604440927838767F, 0.052924265248671616F));
        g.addOrReplaceChild("torreta_ladoi_113", CubeListBuilder.create().texOffs(990, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -34.57402514854763F, -11.263461209205083F, -1.7284015597582516F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_114", CubeListBuilder.create().texOffs(768, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -34.57402514854763F, -9.869552633676715F, -1.7774867102570833F, -0.7666989132568279F, 0.0945404819847156F));
        g.addOrReplaceChild("torreta_ladoi_115", CubeListBuilder.create().texOffs(776, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -34.57402514854763F, -8.543328083530652F, -1.7872668221271308F, -0.8813405994108003F, 0.11928590581640343F));
        g.addOrReplaceChild("torreta_ladoi_116", CubeListBuilder.create().texOffs(784, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -34.57402514854763F, -7.141237152802388F, -1.8046564746427853F, -0.9963153976068305F, 0.1523165350974396F));
        g.addOrReplaceChild("torreta_ladoi_117", CubeListBuilder.create().texOffs(792, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -34.57402514854763F, -5.689359379895098F, -1.835902147435806F, -1.1107712098344598F, 0.19973945437795393F));
        g.addOrReplaceChild("torreta_ladoi_118", CubeListBuilder.create().texOffs(800, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -34.57402514854763F, -4.225777695446748F, -1.8940078886793636F, -1.2222952223879582F, 0.274218461605764F));
        g.addOrReplaceChild("torreta_ladoi_119", CubeListBuilder.create().texOffs(120, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -34.57402514854763F, -3.368462805098931F, -1.8250125743264962F, -0.6828977330951009F, 0.16252283561685757F));
    }

    private static void piezas21(PartDefinition g) {
        g.addOrReplaceChild("torreta_ladoi_120", CubeListBuilder.create().texOffs(126, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -35.634685320327456F, -2.929122976878752F, -2.2578787740092774F, 0.5034964075333622F, -0.37692914871594485F));
        g.addOrReplaceChild("torreta_ladoi_121", CubeListBuilder.create().texOffs(808, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -35.634685320327456F, -3.7864378672265695F, -2.3677090703253425F, 1.0998607686473072F, -0.628997744924369F));
        g.addOrReplaceChild("torreta_ladoi_122", CubeListBuilder.create().texOffs(816, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -35.634685320327456F, -5.250019551674915F, -2.272241936664782F, 0.9991290541514302F, -0.47950331969790666F));
        g.addOrReplaceChild("torreta_ladoi_123", CubeListBuilder.create().texOffs(824, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -35.634685320327456F, -6.7018973245822036F, -2.217294122847617F, 0.8924117308485013F, -0.3727670399277488F));
        g.addOrReplaceChild("torreta_ladoi_124", CubeListBuilder.create().texOffs(832, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -35.634685320327456F, -8.103988255310473F, -2.1867420482879956F, 0.7846873388092357F, -0.2938464331408857F));
        g.addOrReplaceChild("torreta_ladoi_125", CubeListBuilder.create().texOffs(840, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -35.634685320327456F, -9.430212805456538F, -2.1704422095415867F, 0.6781360126157805F, -0.23293867028232346F));
        g.addOrReplaceChild("torreta_ladoi_126", CubeListBuilder.create().texOffs(1000, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -35.634685320327456F, -10.824121380984906F, -2.06115490473932F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_127", CubeListBuilder.create().texOffs(1010, 315).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -35.634685320327456F, -12.129300243282422F, -2.158498621692187F, 0.4325648064011882F, -0.12926946651335153F));
        g.addOrReplaceChild("torreta_ladoi_128", CubeListBuilder.create().texOffs(0, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -35.634685320327456F, -13.081467876688016F, -2.158246782790705F, 0.32404121878210596F, -0.09305056010223281F));
        g.addOrReplaceChild("torreta_ladoi_129", CubeListBuilder.create().texOffs(10, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -35.634685320327456F, -13.753252424566682F, -2.1588127735603417F, 0.22551326293700594F, -0.06309865243197618F));
        g.addOrReplaceChild("torreta_ladoi_130", CubeListBuilder.create().texOffs(20, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -35.634685320327456F, -14.183827113778708F, -2.159431746276033F, 0.13309768150826223F, -0.03665817218397761F));
        g.addOrReplaceChild("torreta_ladoi_131", CubeListBuilder.create().texOffs(30, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -35.634685320327456F, -14.394395507076517F, -2.159797010769914F, 0.044012582320067606F, -0.012031758744915015F));
        g.addOrReplaceChild("torreta_ladoi_132", CubeListBuilder.create().texOffs(40, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -35.634685320327456F, -14.394395507076517F, -2.159797010769914F, -0.044012582320067606F, 0.012031758744915015F));
        g.addOrReplaceChild("torreta_ladoi_133", CubeListBuilder.create().texOffs(50, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -35.634685320327456F, -14.183827113778712F, -2.159431746276033F, -0.13309768150826223F, 0.03665817218397761F));
        g.addOrReplaceChild("torreta_ladoi_134", CubeListBuilder.create().texOffs(60, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -35.634685320327456F, -13.753252424566679F, -2.1588127735603417F, -0.22551326293700594F, 0.06309865243197618F));
        g.addOrReplaceChild("torreta_ladoi_135", CubeListBuilder.create().texOffs(70, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -35.634685320327456F, -13.081467876688016F, -2.158246782790705F, -0.32404121878210596F, 0.09305056010223281F));
        g.addOrReplaceChild("torreta_ladoi_136", CubeListBuilder.create().texOffs(80, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -35.634685320327456F, -12.129300243282422F, -2.158498621692187F, -0.4325648064011882F, 0.12926946651335153F));
        g.addOrReplaceChild("torreta_ladoi_137", CubeListBuilder.create().texOffs(90, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -35.634685320327456F, -10.824121380984906F, -2.06115490473932F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_138", CubeListBuilder.create().texOffs(848, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -35.634685320327456F, -9.430212805456538F, -2.1704422095415867F, -0.6781360126157805F, 0.23293867028232346F));
        g.addOrReplaceChild("torreta_ladoi_139", CubeListBuilder.create().texOffs(856, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -35.634685320327456F, -8.103988255310474F, -2.1867420482879956F, -0.7846873388092352F, 0.29384643314088565F));
        g.addOrReplaceChild("torreta_ladoi_140", CubeListBuilder.create().texOffs(864, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -35.634685320327456F, -6.701897324582209F, -2.217294122847617F, -0.8924117308485006F, 0.3727670399277477F));
        g.addOrReplaceChild("torreta_ladoi_141", CubeListBuilder.create().texOffs(872, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -35.634685320327456F, -5.250019551674919F, -2.272241936664782F, -0.9991290541514304F, 0.4795033196979071F));
        g.addOrReplaceChild("torreta_ladoi_142", CubeListBuilder.create().texOffs(880, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -35.634685320327456F, -3.7864378672265695F, -2.3677090703253425F, -1.0998607686473072F, 0.628997744924369F));
        g.addOrReplaceChild("torreta_ladoi_143", CubeListBuilder.create().texOffs(132, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -35.634685320327456F, -2.929122976878752F, -2.257878774009279F, -0.5034964075333667F, 0.3769291487159489F));
        g.addOrReplaceChild("torreta_ladoi_144", CubeListBuilder.create().texOffs(138, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -36.44647947054675F, -2.117328826659457F, -2.598753816470744F, 0.24114862991549302F, -0.3769291487159447F));
        g.addOrReplaceChild("torreta_ladoi_145", CubeListBuilder.create().texOffs(888, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -36.44647947054675F, -2.9746437170072744F, -2.646882197954851F, 0.908687319993922F, -0.6942218599571065F));
        g.addOrReplaceChild("torreta_ladoi_146", CubeListBuilder.create().texOffs(896, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -36.44647947054675F, -4.43822540145562F, -2.5871272189455237F, 0.8136757082360025F, -0.5285634441564314F));
        g.addOrReplaceChild("torreta_ladoi_147", CubeListBuilder.create().texOffs(904, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -36.44647947054675F, -5.890103174362908F, -2.5569704520961185F, 0.7170542132884095F, -0.40650598371549607F));
        g.addOrReplaceChild("torreta_ladoi_148", CubeListBuilder.create().texOffs(912, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -36.44647947054675F, -7.292194105091178F, -2.543881142271684F, 0.6235142236609884F, -0.3157241341686806F));
        g.addOrReplaceChild("torreta_ladoi_149", CubeListBuilder.create().texOffs(920, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -36.44647947054675F, -8.618418655237242F, -2.5398491770032026F, 0.5342425053943934F, -0.24639886855663043F));
        g.addOrReplaceChild("torreta_ladoi_150", CubeListBuilder.create().texOffs(100, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -36.44647947054675F, -10.01232723076561F, -2.445100691176939F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_151", CubeListBuilder.create().texOffs(110, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -36.44647947054675F, -11.317506093063127F, -2.5439383439483017F, 0.33666875908037247F, -0.13244668739919516F));
        g.addOrReplaceChild("torreta_ladoi_152", CubeListBuilder.create().texOffs(120, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -36.44647947054675F, -12.269673726468719F, -2.5472378250725027F, 0.2514883403020788F, -0.09434563473580541F));
        g.addOrReplaceChild("torreta_ladoi_153", CubeListBuilder.create().texOffs(130, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -36.44647947054675F, -12.941458274347385F, -2.5498319804829115F, 0.17473151157429553F, -0.06352615433750113F));
        g.addOrReplaceChild("torreta_ladoi_154", CubeListBuilder.create().texOffs(140, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -36.44647947054675F, -13.372032963559414F, -2.5515703188345538F, 0.10303102981314574F, -0.03674492596973931F));
        g.addOrReplaceChild("torreta_ladoi_155", CubeListBuilder.create().texOffs(150, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -36.44647947054675F, -13.58260135685722F, -2.552436082334609F, 0.034055989131097086F, -0.012034876166478066F));
        g.addOrReplaceChild("torreta_ladoi_156", CubeListBuilder.create().texOffs(160, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -36.44647947054675F, -13.58260135685722F, -2.552436082334609F, -0.034055989131097086F, 0.012034876166478066F));
        g.addOrReplaceChild("torreta_ladoi_157", CubeListBuilder.create().texOffs(170, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -36.44647947054675F, -13.372032963559414F, -2.5515703188345538F, -0.10303102981314574F, 0.03674492596973931F));
        g.addOrReplaceChild("torreta_ladoi_158", CubeListBuilder.create().texOffs(180, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -36.44647947054675F, -12.941458274347385F, -2.5498319804829115F, -0.17473151157429553F, 0.06352615433750113F));
        g.addOrReplaceChild("torreta_ladoi_159", CubeListBuilder.create().texOffs(190, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -36.44647947054675F, -12.269673726468719F, -2.5472378250725027F, -0.2514883403020788F, 0.09434563473580541F));
        g.addOrReplaceChild("torreta_ladoi_160", CubeListBuilder.create().texOffs(200, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -36.44647947054675F, -11.317506093063125F, -2.5439383439483017F, -0.33666875908037247F, 0.13244668739919516F));
        g.addOrReplaceChild("torreta_ladoi_161", CubeListBuilder.create().texOffs(210, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -36.44647947054675F, -10.01232723076561F, -2.445100691176939F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_162", CubeListBuilder.create().texOffs(928, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -36.44647947054675F, -8.618418655237242F, -2.5398491770032026F, -0.5342425053943934F, 0.24639886855663043F));
        g.addOrReplaceChild("torreta_ladoi_163", CubeListBuilder.create().texOffs(936, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -36.44647947054675F, -7.292194105091179F, -2.5438811422716845F, -0.6235142236609883F, 0.31572413416868056F));
        g.addOrReplaceChild("torreta_ladoi_164", CubeListBuilder.create().texOffs(944, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -36.44647947054675F, -5.890103174362913F, -2.556970452096118F, -0.7170542132884088F, 0.40650598371549507F));
        g.addOrReplaceChild("torreta_ladoi_165", CubeListBuilder.create().texOffs(952, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -36.44647947054675F, -4.438225401455624F, -2.5871272189455237F, -0.8136757082360025F, 0.5285634441564321F));
        g.addOrReplaceChild("torreta_ladoi_166", CubeListBuilder.create().texOffs(960, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -36.44647947054675F, -2.9746437170072744F, -2.646882197954851F, -0.908687319993922F, 0.6942218599571065F));
        g.addOrReplaceChild("torreta_ladoi_167", CubeListBuilder.create().texOffs(144, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -36.44647947054675F, -2.117328826659457F, -2.5987538164707455F, -0.24114862991549538F, 0.3769291487159488F));
        g.addOrReplaceChild("torreta_ladoi_168", CubeListBuilder.create().texOffs(150, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -36.88581929876693F, -1.0566686548796358F, -2.947863658461724F, 0.03217456682924971F, -0.16252283561685643F));
        g.addOrReplaceChild("torreta_ladoi_169", CubeListBuilder.create().texOffs(968, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -36.88581929876693F, -1.913983545227453F, -2.9216958215217677F, 0.6801952653702865F, -0.38580917103667633F));
        g.addOrReplaceChild("torreta_ladoi_170", CubeListBuilder.create().texOffs(976, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -36.88581929876693F, -3.377565229675799F, -2.919931134485137F, 0.6073442168413676F, -0.26768124806761245F));
        g.addOrReplaceChild("torreta_ladoi_171", CubeListBuilder.create().texOffs(984, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -36.88581929876693F, -4.829443002583086F, -2.92284177961434F, 0.5385273383226048F, -0.19342140698198523F));
        g.addOrReplaceChild("torreta_ladoi_172", CubeListBuilder.create().texOffs(992, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -36.88581929876693F, -6.231533933311356F, -2.92701445852671F, 0.47281417535162973F, -0.14393282897091594F));
        g.addOrReplaceChild("torreta_ladoi_173", CubeListBuilder.create().texOffs(1000, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -36.88581929876693F, -7.557758483457421F, -2.931222914888397F, 0.4092743848412544F, -0.1089897339038653F));
        g.addOrReplaceChild("torreta_ladoi_174", CubeListBuilder.create().texOffs(220, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -36.88581929876693F, -8.951667058985787F, -2.8975895428459117F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_175", CubeListBuilder.create().texOffs(230, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -36.88581929876693F, -10.256845921283304F, -2.939333107103145F, 0.26317062304347216F, -0.05615919251254702F));
        g.addOrReplaceChild("torreta_ladoi_176", CubeListBuilder.create().texOffs(240, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -36.88581929876693F, -11.209013554688898F, -2.941898454257198F, 0.1978450531091149F, -0.03957674369467329F));
        g.addOrReplaceChild("torreta_ladoi_177", CubeListBuilder.create().texOffs(250, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -36.88581929876693F, -11.880798102567564F, -2.943614700534786F, 0.13804632169691153F, -0.026471359478096767F));
        g.addOrReplaceChild("torreta_ladoi_178", CubeListBuilder.create().texOffs(260, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -36.88581929876693F, -12.311372791779593F, -2.9446741260086937F, 0.08161247516690207F, -0.015251568973517744F));
        g.addOrReplaceChild("torreta_ladoi_179", CubeListBuilder.create().texOffs(270, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -36.88581929876693F, -12.521941185077399F, -2.9451808049999286F, 0.027009920152967524F, -0.004986122308240523F));
        g.addOrReplaceChild("torreta_ladoi_180", CubeListBuilder.create().texOffs(280, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -36.88581929876693F, -12.521941185077399F, -2.9451808049999286F, -0.027009920152967524F, 0.004986122308240523F));
        g.addOrReplaceChild("torreta_ladoi_181", CubeListBuilder.create().texOffs(290, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -36.88581929876693F, -12.311372791779593F, -2.9446741260086937F, -0.08161247516690207F, 0.015251568973517744F));
        g.addOrReplaceChild("torreta_ladoi_182", CubeListBuilder.create().texOffs(300, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -36.88581929876693F, -11.880798102567564F, -2.943614700534786F, -0.13804632169691153F, 0.026471359478096767F));
        g.addOrReplaceChild("torreta_ladoi_183", CubeListBuilder.create().texOffs(310, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -36.88581929876693F, -11.209013554688898F, -2.941898454257198F, -0.1978450531091149F, 0.03957674369467329F));
        g.addOrReplaceChild("torreta_ladoi_184", CubeListBuilder.create().texOffs(320, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -36.88581929876693F, -10.256845921283304F, -2.939333107103145F, -0.26317062304347216F, 0.05615919251254702F));
        g.addOrReplaceChild("torreta_ladoi_185", CubeListBuilder.create().texOffs(330, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -36.88581929876693F, -8.951667058985787F, -2.8975895428459117F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_186", CubeListBuilder.create().texOffs(1008, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -36.88581929876693F, -7.5577584834574205F, -2.931222914888397F, -0.4092743848412544F, 0.1089897339038653F));
        g.addOrReplaceChild("torreta_ladoi_187", CubeListBuilder.create().texOffs(1016, 321).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -36.88581929876693F, -6.231533933311358F, -2.92701445852671F, -0.47281417535162956F, 0.1439328289709159F));
        g.addOrReplaceChild("torreta_ladoi_188", CubeListBuilder.create().texOffs(0, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -36.88581929876693F, -4.829443002583092F, -2.92284177961434F, -0.5385273383226046F, 0.19342140698198468F));
        g.addOrReplaceChild("torreta_ladoi_189", CubeListBuilder.create().texOffs(8, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -36.88581929876693F, -3.3775652296758025F, -2.919931134485137F, -0.607344216841368F, 0.2676812480676127F));
        g.addOrReplaceChild("torreta_ladoi_190", CubeListBuilder.create().texOffs(16, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -36.88581929876693F, -1.913983545227453F, -2.9216958215217677F, -0.6801952653702865F, 0.38580917103667633F));
        g.addOrReplaceChild("torreta_ladoi_191", CubeListBuilder.create().texOffs(156, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -36.88581929876693F, -1.0566686548796358F, -2.9478636584617246F, -0.032174566829250004F, 0.16252283561685835F));
        g.addOrReplaceChild("torreta_ladod_0", CubeListBuilder.create().texOffs(162, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -27.0F, 3.4826435063320007F, 1.5707963267948966F, -0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_1", CubeListBuilder.create().texOffs(24, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -27.0F, 4.339958396679818F, 1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_2", CubeListBuilder.create().texOffs(32, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -27.0F, 5.803540081128164F, 1.5707963267948966F, -1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_3", CubeListBuilder.create().texOffs(40, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -27.0F, 7.255417854035452F, 1.5707963267948966F, -1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_4", CubeListBuilder.create().texOffs(48, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -27.0F, 8.65750878476372F, 1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_5", CubeListBuilder.create().texOffs(56, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -27.0F, 9.983733334909786F, 1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_6", CubeListBuilder.create().texOffs(340, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -27.0F, 11.377641910438154F, 1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_7", CubeListBuilder.create().texOffs(350, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -27.0F, 12.68282077273567F, 1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_8", CubeListBuilder.create().texOffs(360, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -27.0F, 13.634988406141265F, 1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_9", CubeListBuilder.create().texOffs(370, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -27.0F, 14.306772954019928F, 1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_10", CubeListBuilder.create().texOffs(380, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -27.0F, 14.737347643231958F, 1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_11", CubeListBuilder.create().texOffs(390, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -27.0F, 14.947916036529765F, 1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_12", CubeListBuilder.create().texOffs(400, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -27.0F, 14.947916036529765F, 1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_13", CubeListBuilder.create().texOffs(410, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -27.0F, 14.737347643231958F, 1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_14", CubeListBuilder.create().texOffs(420, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -27.0F, 14.306772954019928F, 1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_15", CubeListBuilder.create().texOffs(430, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -27.0F, 13.634988406141265F, 1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_16", CubeListBuilder.create().texOffs(440, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -27.0F, 12.68282077273567F, 1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_17", CubeListBuilder.create().texOffs(450, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -27.0F, 11.377641910438154F, 1.5707963267948966F, 0.6452303924630274F, 0.0F));
    }

    private static void piezas22(PartDefinition g) {
        g.addOrReplaceChild("torreta_ladod_18", CubeListBuilder.create().texOffs(64, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -27.0F, 9.983733334909786F, 1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_19", CubeListBuilder.create().texOffs(72, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -27.0F, 8.657508784763722F, 1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_20", CubeListBuilder.create().texOffs(80, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -27.0F, 7.255417854035457F, 1.5707963267948966F, 1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_21", CubeListBuilder.create().texOffs(88, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -27.0F, 5.803540081128168F, 1.5707963267948966F, 1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_22", CubeListBuilder.create().texOffs(96, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -27.0F, 4.339958396679818F, 1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_23", CubeListBuilder.create().texOffs(168, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -27.0F, 3.482643506332001F, 1.5707963267948966F, 0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_24", CubeListBuilder.create().texOffs(174, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -29.0F, 3.4826435063320007F, 1.5707963267948966F, -0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_25", CubeListBuilder.create().texOffs(104, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -29.0F, 4.339958396679818F, 1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_26", CubeListBuilder.create().texOffs(112, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -29.0F, 5.803540081128164F, 1.5707963267948966F, -1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_27", CubeListBuilder.create().texOffs(120, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -29.0F, 7.255417854035452F, 1.5707963267948966F, -1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_28", CubeListBuilder.create().texOffs(128, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -29.0F, 8.65750878476372F, 1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_29", CubeListBuilder.create().texOffs(136, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -29.0F, 9.983733334909786F, 1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_30", CubeListBuilder.create().texOffs(460, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -29.0F, 11.377641910438154F, 1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_31", CubeListBuilder.create().texOffs(470, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -29.0F, 12.68282077273567F, 1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_32", CubeListBuilder.create().texOffs(480, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -29.0F, 13.634988406141265F, 1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_33", CubeListBuilder.create().texOffs(490, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -29.0F, 14.306772954019928F, 1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_34", CubeListBuilder.create().texOffs(500, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 14.737347643231958F, 1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_35", CubeListBuilder.create().texOffs(510, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -29.0F, 14.947916036529765F, 1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_36", CubeListBuilder.create().texOffs(520, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -29.0F, 14.947916036529765F, 1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_37", CubeListBuilder.create().texOffs(530, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -29.0F, 14.737347643231958F, 1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_38", CubeListBuilder.create().texOffs(540, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -29.0F, 14.306772954019928F, 1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_39", CubeListBuilder.create().texOffs(550, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -29.0F, 13.634988406141265F, 1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_40", CubeListBuilder.create().texOffs(560, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -29.0F, 12.68282077273567F, 1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_41", CubeListBuilder.create().texOffs(570, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -29.0F, 11.377641910438154F, 1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_42", CubeListBuilder.create().texOffs(144, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -29.0F, 9.983733334909786F, 1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_43", CubeListBuilder.create().texOffs(152, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -29.0F, 8.657508784763722F, 1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_44", CubeListBuilder.create().texOffs(160, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -29.0F, 7.255417854035457F, 1.5707963267948966F, 1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_45", CubeListBuilder.create().texOffs(168, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -29.0F, 5.803540081128168F, 1.5707963267948966F, 1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_46", CubeListBuilder.create().texOffs(176, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -29.0F, 4.339958396679818F, 1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_47", CubeListBuilder.create().texOffs(180, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -29.0F, 3.482643506332001F, 1.5707963267948966F, 0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_48", CubeListBuilder.create().texOffs(186, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -31.0F, 3.4826435063320007F, 1.5707963267948966F, -0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_49", CubeListBuilder.create().texOffs(184, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -31.0F, 4.339958396679818F, 1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_50", CubeListBuilder.create().texOffs(192, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -31.0F, 5.803540081128164F, 1.5707963267948966F, -1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_51", CubeListBuilder.create().texOffs(200, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -31.0F, 7.255417854035452F, 1.5707963267948966F, -1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_52", CubeListBuilder.create().texOffs(208, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -31.0F, 8.65750878476372F, 1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_53", CubeListBuilder.create().texOffs(216, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -31.0F, 9.983733334909786F, 1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_54", CubeListBuilder.create().texOffs(580, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -31.0F, 11.377641910438154F, 1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_55", CubeListBuilder.create().texOffs(590, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -31.0F, 12.68282077273567F, 1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_56", CubeListBuilder.create().texOffs(600, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -31.0F, 13.634988406141265F, 1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_57", CubeListBuilder.create().texOffs(610, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -31.0F, 14.306772954019928F, 1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_58", CubeListBuilder.create().texOffs(620, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -31.0F, 14.737347643231958F, 1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_59", CubeListBuilder.create().texOffs(630, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -31.0F, 14.947916036529765F, 1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_60", CubeListBuilder.create().texOffs(640, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -31.0F, 14.947916036529765F, 1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_61", CubeListBuilder.create().texOffs(650, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -31.0F, 14.737347643231958F, 1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_62", CubeListBuilder.create().texOffs(660, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -31.0F, 14.306772954019928F, 1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_63", CubeListBuilder.create().texOffs(670, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -31.0F, 13.634988406141265F, 1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_64", CubeListBuilder.create().texOffs(680, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -31.0F, 12.68282077273567F, 1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_65", CubeListBuilder.create().texOffs(690, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -31.0F, 11.377641910438154F, 1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_66", CubeListBuilder.create().texOffs(224, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -31.0F, 9.983733334909786F, 1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_67", CubeListBuilder.create().texOffs(232, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -31.0F, 8.657508784763722F, 1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_68", CubeListBuilder.create().texOffs(240, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -31.0F, 7.255417854035457F, 1.5707963267948966F, 1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_69", CubeListBuilder.create().texOffs(248, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -31.0F, 5.803540081128168F, 1.5707963267948966F, 1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_70", CubeListBuilder.create().texOffs(256, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -31.0F, 4.339958396679818F, 1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_71", CubeListBuilder.create().texOffs(192, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -31.0F, 3.482643506332001F, 1.5707963267948966F, 0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_72", CubeListBuilder.create().texOffs(198, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -33.0F, 3.4826435063320007F, 1.5707963267948966F, -0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_73", CubeListBuilder.create().texOffs(264, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -33.0F, 4.339958396679818F, 1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_74", CubeListBuilder.create().texOffs(272, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -33.0F, 5.803540081128164F, 1.5707963267948966F, -1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_75", CubeListBuilder.create().texOffs(280, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -33.0F, 7.255417854035452F, 1.5707963267948966F, -1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_76", CubeListBuilder.create().texOffs(288, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -33.0F, 8.65750878476372F, 1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_77", CubeListBuilder.create().texOffs(296, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -33.0F, 9.983733334909786F, 1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_78", CubeListBuilder.create().texOffs(700, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -33.0F, 11.377641910438154F, 1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_79", CubeListBuilder.create().texOffs(710, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -33.0F, 12.68282077273567F, 1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_80", CubeListBuilder.create().texOffs(720, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -33.0F, 13.634988406141265F, 1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_81", CubeListBuilder.create().texOffs(730, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -33.0F, 14.306772954019928F, 1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_82", CubeListBuilder.create().texOffs(740, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -33.0F, 14.737347643231958F, 1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_83", CubeListBuilder.create().texOffs(750, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -33.0F, 14.947916036529765F, 1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_84", CubeListBuilder.create().texOffs(760, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -33.0F, 14.947916036529765F, 1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_85", CubeListBuilder.create().texOffs(770, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -33.0F, 14.737347643231958F, 1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_86", CubeListBuilder.create().texOffs(780, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -33.0F, 14.306772954019928F, 1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_87", CubeListBuilder.create().texOffs(790, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -33.0F, 13.634988406141265F, 1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_88", CubeListBuilder.create().texOffs(800, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -33.0F, 12.68282077273567F, 1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_89", CubeListBuilder.create().texOffs(810, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -33.0F, 11.377641910438154F, 1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_90", CubeListBuilder.create().texOffs(304, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -33.0F, 9.983733334909786F, 1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_91", CubeListBuilder.create().texOffs(312, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -33.0F, 8.657508784763722F, 1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_92", CubeListBuilder.create().texOffs(320, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -33.0F, 7.255417854035457F, 1.5707963267948966F, 1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_93", CubeListBuilder.create().texOffs(328, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -33.0F, 5.803540081128168F, 1.5707963267948966F, 1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_94", CubeListBuilder.create().texOffs(336, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -33.0F, 4.339958396679818F, 1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_95", CubeListBuilder.create().texOffs(204, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -33.0F, 3.482643506332001F, 1.5707963267948966F, 0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_96", CubeListBuilder.create().texOffs(210, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -34.57402514854763F, 3.3684628050989307F, 1.8250125743264949F, -0.6828977330950954F, -0.16252283561685563F));
        g.addOrReplaceChild("torreta_ladod_97", CubeListBuilder.create().texOffs(344, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -34.57402514854763F, 4.225777695446748F, 1.8940078886793636F, -1.2222952223879582F, -0.274218461605764F));
        g.addOrReplaceChild("torreta_ladod_98", CubeListBuilder.create().texOffs(352, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -34.57402514854763F, 5.689359379895094F, 1.8359021474358057F, -1.110771209834459F, -0.19973945437795396F));
        g.addOrReplaceChild("torreta_ladod_99", CubeListBuilder.create().texOffs(360, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -34.57402514854763F, 7.141237152802382F, 1.8046564746427858F, -0.9963153976068317F, -0.15231653509744F));
        g.addOrReplaceChild("torreta_ladod_100", CubeListBuilder.create().texOffs(368, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -34.57402514854763F, 8.543328083530652F, 1.7872668221271308F, -0.8813405994108005F, -0.11928590581640346F));
        g.addOrReplaceChild("torreta_ladod_101", CubeListBuilder.create().texOffs(376, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -34.57402514854763F, 9.869552633676715F, 1.7774867102570833F, -0.7666989132568279F, -0.0945404819847156F));
        g.addOrReplaceChild("torreta_ladod_102", CubeListBuilder.create().texOffs(820, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -34.57402514854763F, 11.263461209205083F, 1.7284015597582516F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_103", CubeListBuilder.create().texOffs(830, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -34.57402514854763F, 12.5686400715026F, 1.7685726602340672F, -0.49604440927838767F, -0.052924265248671616F));
        g.addOrReplaceChild("torreta_ladod_104", CubeListBuilder.create().texOffs(840, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -34.57402514854763F, 13.520807704908194F, 1.7675268706013907F, -0.3734096587135649F, -0.03827065184366676F));
        g.addOrReplaceChild("torreta_ladod_105", CubeListBuilder.create().texOffs(850, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -34.57402514854763F, 14.19259225278686F, 1.7672005563238273F, -0.26074408856128006F, -0.026042315212402013F));
        g.addOrReplaceChild("torreta_ladod_106", CubeListBuilder.create().texOffs(860, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -34.57402514854763F, 14.623166941998889F, 1.7671377204012728F, -0.15421558868568414F, -0.015164715370441974F));
        g.addOrReplaceChild("torreta_ladod_107", CubeListBuilder.create().texOffs(870, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -34.57402514854763F, 14.833735335296694F, 1.767143573659609F, -0.051047752130763846F, -0.004983004511430807F));
    }

    private static void piezas23(PartDefinition g) {
        g.addOrReplaceChild("torreta_ladod_108", CubeListBuilder.create().texOffs(880, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -34.57402514854763F, 14.833735335296694F, 1.767143573659609F, 0.051047752130763846F, 0.004983004511430807F));
        g.addOrReplaceChild("torreta_ladod_109", CubeListBuilder.create().texOffs(890, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -34.57402514854763F, 14.623166941998889F, 1.7671377204012728F, 0.15421558868568414F, 0.015164715370441974F));
        g.addOrReplaceChild("torreta_ladod_110", CubeListBuilder.create().texOffs(900, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -34.57402514854763F, 14.19259225278686F, 1.7672005563238273F, 0.26074408856128006F, 0.026042315212402013F));
        g.addOrReplaceChild("torreta_ladod_111", CubeListBuilder.create().texOffs(910, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -34.57402514854763F, 13.520807704908194F, 1.7675268706013907F, 0.3734096587135649F, 0.03827065184366676F));
        g.addOrReplaceChild("torreta_ladod_112", CubeListBuilder.create().texOffs(920, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -34.57402514854763F, 12.5686400715026F, 1.7685726602340672F, 0.49604440927838767F, 0.052924265248671616F));
        g.addOrReplaceChild("torreta_ladod_113", CubeListBuilder.create().texOffs(930, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -34.57402514854763F, 11.263461209205083F, 1.7284015597582516F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_114", CubeListBuilder.create().texOffs(384, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -34.57402514854763F, 9.869552633676715F, 1.7774867102570833F, 0.7666989132568279F, 0.0945404819847156F));
        g.addOrReplaceChild("torreta_ladod_115", CubeListBuilder.create().texOffs(392, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -34.57402514854763F, 8.543328083530652F, 1.7872668221271308F, 0.8813405994108003F, 0.11928590581640343F));
        g.addOrReplaceChild("torreta_ladod_116", CubeListBuilder.create().texOffs(400, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -34.57402514854763F, 7.141237152802388F, 1.8046564746427853F, 0.9963153976068305F, 0.1523165350974396F));
        g.addOrReplaceChild("torreta_ladod_117", CubeListBuilder.create().texOffs(408, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -34.57402514854763F, 5.689359379895098F, 1.835902147435806F, 1.1107712098344598F, 0.19973945437795393F));
        g.addOrReplaceChild("torreta_ladod_118", CubeListBuilder.create().texOffs(416, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -34.57402514854763F, 4.225777695446748F, 1.8940078886793636F, 1.2222952223879582F, 0.274218461605764F));
        g.addOrReplaceChild("torreta_ladod_119", CubeListBuilder.create().texOffs(216, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -34.57402514854763F, 3.368462805098931F, 1.8250125743264962F, 0.6828977330951009F, 0.16252283561685757F));
        g.addOrReplaceChild("torreta_ladod_120", CubeListBuilder.create().texOffs(222, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -35.634685320327456F, 2.929122976878752F, 2.2578787740092774F, -0.5034964075333622F, -0.37692914871594485F));
        g.addOrReplaceChild("torreta_ladod_121", CubeListBuilder.create().texOffs(424, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -35.634685320327456F, 3.7864378672265695F, 2.3677090703253425F, -1.0998607686473072F, -0.628997744924369F));
        g.addOrReplaceChild("torreta_ladod_122", CubeListBuilder.create().texOffs(432, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -35.634685320327456F, 5.250019551674915F, 2.272241936664782F, -0.9991290541514302F, -0.47950331969790666F));
        g.addOrReplaceChild("torreta_ladod_123", CubeListBuilder.create().texOffs(440, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -35.634685320327456F, 6.7018973245822036F, 2.217294122847617F, -0.8924117308485013F, -0.3727670399277488F));
        g.addOrReplaceChild("torreta_ladod_124", CubeListBuilder.create().texOffs(448, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -35.634685320327456F, 8.103988255310473F, 2.1867420482879956F, -0.7846873388092357F, -0.2938464331408857F));
        g.addOrReplaceChild("torreta_ladod_125", CubeListBuilder.create().texOffs(456, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -35.634685320327456F, 9.430212805456538F, 2.1704422095415867F, -0.6781360126157805F, -0.23293867028232346F));
        g.addOrReplaceChild("torreta_ladod_126", CubeListBuilder.create().texOffs(940, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -35.634685320327456F, 10.824121380984906F, 2.06115490473932F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_127", CubeListBuilder.create().texOffs(950, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -35.634685320327456F, 12.129300243282422F, 2.158498621692187F, -0.4325648064011882F, -0.12926946651335153F));
        g.addOrReplaceChild("torreta_ladod_128", CubeListBuilder.create().texOffs(960, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -35.634685320327456F, 13.081467876688016F, 2.158246782790705F, -0.32404121878210596F, -0.09305056010223281F));
        g.addOrReplaceChild("torreta_ladod_129", CubeListBuilder.create().texOffs(970, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -35.634685320327456F, 13.753252424566682F, 2.1588127735603417F, -0.22551326293700594F, -0.06309865243197618F));
        g.addOrReplaceChild("torreta_ladod_130", CubeListBuilder.create().texOffs(980, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -35.634685320327456F, 14.183827113778708F, 2.159431746276033F, -0.13309768150826223F, -0.03665817218397761F));
        g.addOrReplaceChild("torreta_ladod_131", CubeListBuilder.create().texOffs(990, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -35.634685320327456F, 14.394395507076517F, 2.159797010769914F, -0.044012582320067606F, -0.012031758744915015F));
        g.addOrReplaceChild("torreta_ladod_132", CubeListBuilder.create().texOffs(1000, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -35.634685320327456F, 14.394395507076517F, 2.159797010769914F, 0.044012582320067606F, 0.012031758744915015F));
        g.addOrReplaceChild("torreta_ladod_133", CubeListBuilder.create().texOffs(1010, 318).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -35.634685320327456F, 14.183827113778712F, 2.159431746276033F, 0.13309768150826223F, 0.03665817218397761F));
        g.addOrReplaceChild("torreta_ladod_134", CubeListBuilder.create().texOffs(0, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -35.634685320327456F, 13.753252424566679F, 2.1588127735603417F, 0.22551326293700594F, 0.06309865243197618F));
        g.addOrReplaceChild("torreta_ladod_135", CubeListBuilder.create().texOffs(10, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -35.634685320327456F, 13.081467876688016F, 2.158246782790705F, 0.32404121878210596F, 0.09305056010223281F));
        g.addOrReplaceChild("torreta_ladod_136", CubeListBuilder.create().texOffs(20, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -35.634685320327456F, 12.129300243282422F, 2.158498621692187F, 0.4325648064011882F, 0.12926946651335153F));
        g.addOrReplaceChild("torreta_ladod_137", CubeListBuilder.create().texOffs(30, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -35.634685320327456F, 10.824121380984906F, 2.06115490473932F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_138", CubeListBuilder.create().texOffs(464, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -35.634685320327456F, 9.430212805456538F, 2.1704422095415867F, 0.6781360126157805F, 0.23293867028232346F));
        g.addOrReplaceChild("torreta_ladod_139", CubeListBuilder.create().texOffs(472, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -35.634685320327456F, 8.103988255310474F, 2.1867420482879956F, 0.7846873388092352F, 0.29384643314088565F));
        g.addOrReplaceChild("torreta_ladod_140", CubeListBuilder.create().texOffs(480, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -35.634685320327456F, 6.701897324582209F, 2.217294122847617F, 0.8924117308485006F, 0.3727670399277477F));
        g.addOrReplaceChild("torreta_ladod_141", CubeListBuilder.create().texOffs(488, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -35.634685320327456F, 5.250019551674919F, 2.272241936664782F, 0.9991290541514304F, 0.4795033196979071F));
        g.addOrReplaceChild("torreta_ladod_142", CubeListBuilder.create().texOffs(496, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -35.634685320327456F, 3.7864378672265695F, 2.3677090703253425F, 1.0998607686473072F, 0.628997744924369F));
        g.addOrReplaceChild("torreta_ladod_143", CubeListBuilder.create().texOffs(228, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -35.634685320327456F, 2.929122976878752F, 2.257878774009279F, 0.5034964075333667F, 0.3769291487159489F));
        g.addOrReplaceChild("torreta_ladod_144", CubeListBuilder.create().texOffs(234, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -36.44647947054675F, 2.117328826659457F, 2.598753816470744F, -0.24114862991549302F, -0.3769291487159447F));
        g.addOrReplaceChild("torreta_ladod_145", CubeListBuilder.create().texOffs(504, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -36.44647947054675F, 2.9746437170072744F, 2.646882197954851F, -0.908687319993922F, -0.6942218599571065F));
        g.addOrReplaceChild("torreta_ladod_146", CubeListBuilder.create().texOffs(512, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -36.44647947054675F, 4.43822540145562F, 2.5871272189455237F, -0.8136757082360025F, -0.5285634441564314F));
        g.addOrReplaceChild("torreta_ladod_147", CubeListBuilder.create().texOffs(520, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -36.44647947054675F, 5.890103174362908F, 2.5569704520961185F, -0.7170542132884095F, -0.40650598371549607F));
        g.addOrReplaceChild("torreta_ladod_148", CubeListBuilder.create().texOffs(528, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -36.44647947054675F, 7.292194105091178F, 2.543881142271684F, -0.6235142236609884F, -0.3157241341686806F));
        g.addOrReplaceChild("torreta_ladod_149", CubeListBuilder.create().texOffs(536, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -36.44647947054675F, 8.618418655237242F, 2.5398491770032026F, -0.5342425053943934F, -0.24639886855663043F));
        g.addOrReplaceChild("torreta_ladod_150", CubeListBuilder.create().texOffs(40, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -36.44647947054675F, 10.01232723076561F, 2.445100691176939F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_151", CubeListBuilder.create().texOffs(50, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -36.44647947054675F, 11.317506093063127F, 2.5439383439483017F, -0.33666875908037247F, -0.13244668739919516F));
        g.addOrReplaceChild("torreta_ladod_152", CubeListBuilder.create().texOffs(60, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -36.44647947054675F, 12.269673726468719F, 2.5472378250725027F, -0.2514883403020788F, -0.09434563473580541F));
        g.addOrReplaceChild("torreta_ladod_153", CubeListBuilder.create().texOffs(70, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -36.44647947054675F, 12.941458274347385F, 2.5498319804829115F, -0.17473151157429553F, -0.06352615433750113F));
        g.addOrReplaceChild("torreta_ladod_154", CubeListBuilder.create().texOffs(80, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -36.44647947054675F, 13.372032963559414F, 2.5515703188345538F, -0.10303102981314574F, -0.03674492596973931F));
        g.addOrReplaceChild("torreta_ladod_155", CubeListBuilder.create().texOffs(90, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -36.44647947054675F, 13.58260135685722F, 2.552436082334609F, -0.034055989131097086F, -0.012034876166478066F));
        g.addOrReplaceChild("torreta_ladod_156", CubeListBuilder.create().texOffs(100, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -36.44647947054675F, 13.58260135685722F, 2.552436082334609F, 0.034055989131097086F, 0.012034876166478066F));
        g.addOrReplaceChild("torreta_ladod_157", CubeListBuilder.create().texOffs(110, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -36.44647947054675F, 13.372032963559414F, 2.5515703188345538F, 0.10303102981314574F, 0.03674492596973931F));
        g.addOrReplaceChild("torreta_ladod_158", CubeListBuilder.create().texOffs(120, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -36.44647947054675F, 12.941458274347385F, 2.5498319804829115F, 0.17473151157429553F, 0.06352615433750113F));
        g.addOrReplaceChild("torreta_ladod_159", CubeListBuilder.create().texOffs(130, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -36.44647947054675F, 12.269673726468719F, 2.5472378250725027F, 0.2514883403020788F, 0.09434563473580541F));
        g.addOrReplaceChild("torreta_ladod_160", CubeListBuilder.create().texOffs(140, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -36.44647947054675F, 11.317506093063125F, 2.5439383439483017F, 0.33666875908037247F, 0.13244668739919516F));
        g.addOrReplaceChild("torreta_ladod_161", CubeListBuilder.create().texOffs(150, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -36.44647947054675F, 10.01232723076561F, 2.445100691176939F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_162", CubeListBuilder.create().texOffs(544, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -36.44647947054675F, 8.618418655237242F, 2.5398491770032026F, 0.5342425053943934F, 0.24639886855663043F));
        g.addOrReplaceChild("torreta_ladod_163", CubeListBuilder.create().texOffs(552, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -36.44647947054675F, 7.292194105091179F, 2.5438811422716845F, 0.6235142236609883F, 0.31572413416868056F));
        g.addOrReplaceChild("torreta_ladod_164", CubeListBuilder.create().texOffs(560, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -36.44647947054675F, 5.890103174362913F, 2.556970452096118F, 0.7170542132884088F, 0.40650598371549507F));
        g.addOrReplaceChild("torreta_ladod_165", CubeListBuilder.create().texOffs(568, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -36.44647947054675F, 4.438225401455624F, 2.5871272189455237F, 0.8136757082360025F, 0.5285634441564321F));
        g.addOrReplaceChild("torreta_ladod_166", CubeListBuilder.create().texOffs(576, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -36.44647947054675F, 2.9746437170072744F, 2.646882197954851F, 0.908687319993922F, 0.6942218599571065F));
        g.addOrReplaceChild("torreta_ladod_167", CubeListBuilder.create().texOffs(240, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -36.44647947054675F, 2.117328826659457F, 2.5987538164707455F, 0.24114862991549538F, 0.3769291487159488F));
        g.addOrReplaceChild("torreta_ladod_168", CubeListBuilder.create().texOffs(246, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -36.88581929876693F, 1.0566686548796358F, 2.947863658461724F, -0.03217456682924971F, -0.16252283561685643F));
        g.addOrReplaceChild("torreta_ladod_169", CubeListBuilder.create().texOffs(584, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -36.88581929876693F, 1.913983545227453F, 2.9216958215217677F, -0.6801952653702865F, -0.38580917103667633F));
        g.addOrReplaceChild("torreta_ladod_170", CubeListBuilder.create().texOffs(592, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -36.88581929876693F, 3.377565229675799F, 2.919931134485137F, -0.6073442168413676F, -0.26768124806761245F));
        g.addOrReplaceChild("torreta_ladod_171", CubeListBuilder.create().texOffs(600, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -36.88581929876693F, 4.829443002583086F, 2.92284177961434F, -0.5385273383226048F, -0.19342140698198523F));
        g.addOrReplaceChild("torreta_ladod_172", CubeListBuilder.create().texOffs(608, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -36.88581929876693F, 6.231533933311356F, 2.92701445852671F, -0.47281417535162973F, -0.14393282897091594F));
        g.addOrReplaceChild("torreta_ladod_173", CubeListBuilder.create().texOffs(616, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -36.88581929876693F, 7.557758483457421F, 2.931222914888397F, -0.4092743848412544F, -0.1089897339038653F));
        g.addOrReplaceChild("torreta_ladod_174", CubeListBuilder.create().texOffs(160, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -36.88581929876693F, 8.951667058985787F, 2.8975895428459117F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_175", CubeListBuilder.create().texOffs(170, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -36.88581929876693F, 10.256845921283304F, 2.939333107103145F, -0.26317062304347216F, -0.05615919251254702F));
        g.addOrReplaceChild("torreta_ladod_176", CubeListBuilder.create().texOffs(180, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -36.88581929876693F, 11.209013554688898F, 2.941898454257198F, -0.1978450531091149F, -0.03957674369467329F));
        g.addOrReplaceChild("torreta_ladod_177", CubeListBuilder.create().texOffs(190, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -36.88581929876693F, 11.880798102567564F, 2.943614700534786F, -0.13804632169691153F, -0.026471359478096767F));
        g.addOrReplaceChild("torreta_ladod_178", CubeListBuilder.create().texOffs(200, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -36.88581929876693F, 12.311372791779593F, 2.9446741260086937F, -0.08161247516690207F, -0.015251568973517744F));
        g.addOrReplaceChild("torreta_ladod_179", CubeListBuilder.create().texOffs(210, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -36.88581929876693F, 12.521941185077399F, 2.9451808049999286F, -0.027009920152967524F, -0.004986122308240523F));
        g.addOrReplaceChild("torreta_ladod_180", CubeListBuilder.create().texOffs(220, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -36.88581929876693F, 12.521941185077399F, 2.9451808049999286F, 0.027009920152967524F, 0.004986122308240523F));
        g.addOrReplaceChild("torreta_ladod_181", CubeListBuilder.create().texOffs(230, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -36.88581929876693F, 12.311372791779593F, 2.9446741260086937F, 0.08161247516690207F, 0.015251568973517744F));
        g.addOrReplaceChild("torreta_ladod_182", CubeListBuilder.create().texOffs(240, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -36.88581929876693F, 11.880798102567564F, 2.943614700534786F, 0.13804632169691153F, 0.026471359478096767F));
        g.addOrReplaceChild("torreta_ladod_183", CubeListBuilder.create().texOffs(250, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -36.88581929876693F, 11.209013554688898F, 2.941898454257198F, 0.1978450531091149F, 0.03957674369467329F));
        g.addOrReplaceChild("torreta_ladod_184", CubeListBuilder.create().texOffs(260, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -36.88581929876693F, 10.256845921283304F, 2.939333107103145F, 0.26317062304347216F, 0.05615919251254702F));
        g.addOrReplaceChild("torreta_ladod_185", CubeListBuilder.create().texOffs(270, 321).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -36.88581929876693F, 8.951667058985787F, 2.8975895428459117F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_186", CubeListBuilder.create().texOffs(624, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -36.88581929876693F, 7.5577584834574205F, 2.931222914888397F, 0.4092743848412544F, 0.1089897339038653F));
        g.addOrReplaceChild("torreta_ladod_187", CubeListBuilder.create().texOffs(632, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -36.88581929876693F, 6.231533933311358F, 2.92701445852671F, 0.47281417535162956F, 0.1439328289709159F));
        g.addOrReplaceChild("torreta_ladod_188", CubeListBuilder.create().texOffs(640, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -36.88581929876693F, 4.829443002583092F, 2.92284177961434F, 0.5385273383226046F, 0.19342140698198468F));
        g.addOrReplaceChild("torreta_ladod_189", CubeListBuilder.create().texOffs(648, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -36.88581929876693F, 3.3775652296758025F, 2.919931134485137F, 0.607344216841368F, 0.2676812480676127F));
        g.addOrReplaceChild("torreta_ladod_190", CubeListBuilder.create().texOffs(656, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -36.88581929876693F, 1.913983545227453F, 2.9216958215217677F, 0.6801952653702865F, 0.38580917103667633F));
        g.addOrReplaceChild("torreta_ladod_191", CubeListBuilder.create().texOffs(252, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -36.88581929876693F, 1.0566686548796358F, 2.9478636584617246F, 0.032174566829250004F, 0.16252283561685835F));
        g.addOrReplaceChild("torreta_arriba0_0", CubeListBuilder.create().texOffs(816, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, -0.4022029219433341F, 3.141592653589793F, 0.3100697635999632F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_1", CubeListBuilder.create().texOffs(240, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, -1.1166319972331817F, -3.141592653589793F, 1.1802868355520546F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_2", CubeListBuilder.create().texOffs(664, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, -2.3362834009401365F, 3.141592653589793F, 0.525768929423935F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_3", CubeListBuilder.create().texOffs(672, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, -3.546181545029543F, 3.141592653589793F, 0.4626682052002364F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_4", CubeListBuilder.create().texOffs(518, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, -4.7145906539697675F, 3.141592653589793F, 0.4019995301782599F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_5", CubeListBuilder.create().texOffs(528, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, -5.819777779091488F, 3.141592653589793F, 0.3440226531458383F, 0.0F));
    }

    private static void piezas24(PartDefinition g) {
        g.addOrReplaceChild("torreta_arriba0_6", CubeListBuilder.create().texOffs(144, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, -6.9813682586984624F, 3.141592653589793F, 0.28010947828323F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_7", CubeListBuilder.create().texOffs(158, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, -8.06901731061306F, 3.141592653589793F, 0.21573212828874144F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_8", CubeListBuilder.create().texOffs(172, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, -8.862490338451053F, 3.141592653589793F, 0.16076062662315743F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_9", CubeListBuilder.create().texOffs(186, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, -9.422310795016607F, 3.141592653589793F, 0.11148588586348276F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_10", CubeListBuilder.create().texOffs(200, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, -9.781123036026631F, 3.141592653589793F, 0.06565520657082505F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_11", CubeListBuilder.create().texOffs(214, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, -9.956596697108136F, 3.141592653589793F, 0.021688039300371963F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_12", CubeListBuilder.create().texOffs(228, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, -9.956596697108138F, -3.141592653589793F, -0.021688039300371963F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_13", CubeListBuilder.create().texOffs(242, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, -9.781123036026631F, -3.141592653589793F, -0.06565520657082505F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_14", CubeListBuilder.create().texOffs(256, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, -9.422310795016607F, -3.141592653589793F, -0.11148588586348276F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_15", CubeListBuilder.create().texOffs(270, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, -8.862490338451053F, -3.141592653589793F, -0.16076062662315743F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_16", CubeListBuilder.create().texOffs(284, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, -8.06901731061306F, -3.141592653589793F, -0.21573212828874144F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_17", CubeListBuilder.create().texOffs(298, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, -6.981368258698462F, -3.141592653589793F, -0.28010947828323F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_18", CubeListBuilder.create().texOffs(538, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, -5.819777779091489F, -3.141592653589793F, -0.3440226531458383F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_19", CubeListBuilder.create().texOffs(548, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, -4.714590653969769F, -3.141592653589793F, -0.40199953017825985F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_20", CubeListBuilder.create().texOffs(680, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, -3.546181545029548F, -3.141592653589793F, -0.46266820520023566F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_21", CubeListBuilder.create().texOffs(688, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, -2.33628340094014F, -3.141592653589793F, -0.5257689294239354F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_22", CubeListBuilder.create().texOffs(246, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, -1.1166319972331817F, -3.141592653589793F, -1.1802868355520546F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_23", CubeListBuilder.create().texOffs(820, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, -0.4022029219433341F, -3.141592653589793F, -0.310069763599966F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_24", CubeListBuilder.create().texOffs(824, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, -0.24132175316600046F, 3.141592653589793F, 0.2024038072576524F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_25", CubeListBuilder.create().texOffs(252, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, -0.669979198339909F, 3.141592653589793F, 0.4847354486182298F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_26", CubeListBuilder.create().texOffs(696, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, -1.4017700405640818F, 3.141592653589793F, 0.4048266624432964F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_27", CubeListBuilder.create().texOffs(704, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, -2.127708927017726F, 3.141592653589793F, 0.3363761555098401F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_28", CubeListBuilder.create().texOffs(558, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, -2.8287543923818608F, 3.141592653589793F, 0.2784887017498119F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_29", CubeListBuilder.create().texOffs(568, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, -3.491866667454894F, 3.141592653589793F, 0.22910973342865612F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_30", CubeListBuilder.create().texOffs(312, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, -4.188820955219077F, 3.141592653589793F, 0.17997806135894623F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_31", CubeListBuilder.create().texOffs(326, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, -4.841410386367835F, 3.141592653589793F, 0.1347577857694709F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_32", CubeListBuilder.create().texOffs(340, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, -5.317494203070632F, 3.141592653589793F, 0.09862428942245241F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_33", CubeListBuilder.create().texOffs(354, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, -5.653386477009965F, 3.141592653589793F, 0.06760750425699437F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_34", CubeListBuilder.create().texOffs(368, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, -5.86867382161598F, 3.141592653589793F, 0.03953848719601994F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_35", CubeListBuilder.create().texOffs(382, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, -5.973958018264883F, 3.141592653589793F, 0.013018048518655675F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_36", CubeListBuilder.create().texOffs(396, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, -5.973958018264883F, -3.141592653589793F, -0.013018048518655675F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_37", CubeListBuilder.create().texOffs(410, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, -5.86867382161598F, -3.141592653589793F, -0.03953848719601994F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_38", CubeListBuilder.create().texOffs(424, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, -5.653386477009965F, -3.141592653589793F, -0.06760750425699437F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_39", CubeListBuilder.create().texOffs(438, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, -5.317494203070632F, -3.141592653589793F, -0.09862428942245241F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_40", CubeListBuilder.create().texOffs(452, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, -4.841410386367835F, -3.141592653589793F, -0.1347577857694709F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_41", CubeListBuilder.create().texOffs(466, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, -4.188820955219077F, -3.141592653589793F, -0.17997806135894623F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_42", CubeListBuilder.create().texOffs(578, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, -3.4918666674548935F, -3.141592653589793F, -0.22910973342865612F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_43", CubeListBuilder.create().texOffs(588, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, -2.8287543923818617F, -3.141592653589793F, -0.2784887017498119F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_44", CubeListBuilder.create().texOffs(712, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, -2.1277089270177285F, -3.141592653589793F, -0.33637615550983957F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_45", CubeListBuilder.create().texOffs(720, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, -1.401770040564084F, -3.141592653589793F, -0.4048266624432964F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_46", CubeListBuilder.create().texOffs(258, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, -0.669979198339909F, -3.141592653589793F, -0.4847354486182298F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_47", CubeListBuilder.create().texOffs(828, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, -0.2413217531660005F, -3.141592653589793F, -0.2024038072576547F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_48", CubeListBuilder.create().texOffs(832, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, -0.08044058438866683F, 3.141592653589793F, 0.0709322546045808F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_49", CubeListBuilder.create().texOffs(836, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, -0.22332639944663635F, 3.141592653589793F, 0.226131387547358F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_50", CubeListBuilder.create().texOffs(258, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, -0.46725668018802735F, 3.141592653589793F, 0.16829675399894287F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_51", CubeListBuilder.create().texOffs(728, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, -0.7092363090059087F, 3.141592653589793F, 0.1297943922103165F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_52", CubeListBuilder.create().texOffs(598, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, -0.9429181307939537F, 3.141592653589793F, 0.10233773027253709F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_53", CubeListBuilder.create().texOffs(608, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, -1.163955555818298F, 3.141592653589793F, 0.08147660732059007F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_54", CubeListBuilder.create().texOffs(480, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, -1.3962736517396925F, 3.141592653589793F, 0.062399476109604606F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_55", CubeListBuilder.create().texOffs(494, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, -1.613803462122612F, 3.141592653589793F, 0.045909987853499166F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_56", CubeListBuilder.create().texOffs(508, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, -1.772498067690211F, 3.141592653589793F, 0.03325871856882619F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_57", CubeListBuilder.create().texOffs(522, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, -1.8844621590033217F, 3.141592653589793F, 0.022658664463092667F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_58", CubeListBuilder.create().texOffs(536, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, -1.9562246072053266F, 3.141592653589793F, 0.01320396557383507F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_59", CubeListBuilder.create().texOffs(550, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, -1.9913193394216275F, 3.141592653589793F, 0.0043402212738897555F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_60", CubeListBuilder.create().texOffs(564, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, -1.9913193394216275F, -3.141592653589793F, -0.0043402212738897555F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_61", CubeListBuilder.create().texOffs(578, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, -1.9562246072053266F, -3.141592653589793F, -0.01320396557383507F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_62", CubeListBuilder.create().texOffs(592, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, -1.8844621590033217F, -3.141592653589793F, -0.022658664463092667F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_63", CubeListBuilder.create().texOffs(606, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, -1.772498067690211F, -3.141592653589793F, -0.03325871856882619F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_64", CubeListBuilder.create().texOffs(620, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, -1.613803462122612F, -3.141592653589793F, -0.045909987853499166F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_65", CubeListBuilder.create().texOffs(634, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, -1.3962736517396925F, -3.141592653589793F, -0.062399476109604606F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_66", CubeListBuilder.create().texOffs(618, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, -1.163955555818298F, -3.141592653589793F, -0.08147660732059007F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_67", CubeListBuilder.create().texOffs(628, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, -0.9429181307939539F, -3.141592653589793F, -0.10233773027253709F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_68", CubeListBuilder.create().texOffs(736, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, -0.7092363090059096F, -3.141592653589793F, -0.12979439221031625F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_69", CubeListBuilder.create().texOffs(264, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, -0.467256680188028F, -3.141592653589793F, -0.16829675399894287F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_70", CubeListBuilder.create().texOffs(840, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, -0.22332639944663635F, -3.141592653589793F, -0.226131387547358F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_71", CubeListBuilder.create().texOffs(844, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, -0.08044058438866683F, -3.141592653589793F, -0.07093225460458151F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_72", CubeListBuilder.create().texOffs(848, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, 0.08044058438866682F, -3.141592653589793F, -0.0709322546045808F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_73", CubeListBuilder.create().texOffs(852, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, 0.22332639944663635F, -3.141592653589793F, -0.226131387547358F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_74", CubeListBuilder.create().texOffs(270, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, 0.46725668018802713F, -3.141592653589793F, -0.1682967539989426F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_75", CubeListBuilder.create().texOffs(744, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, 0.7092363090059084F, -3.141592653589793F, -0.12979439221031658F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_76", CubeListBuilder.create().texOffs(638, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, 0.9429181307939531F, -3.141592653589793F, -0.10233773027253677F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_77", CubeListBuilder.create().texOffs(648, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, 1.1639555558182972F, -3.141592653589793F, -0.08147660732059007F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_78", CubeListBuilder.create().texOffs(648, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, 1.3962736517396919F, -3.141592653589793F, -0.062399476109604446F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_79", CubeListBuilder.create().texOffs(662, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, 1.6138034621226112F, -3.141592653589793F, -0.045909987853499166F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_80", CubeListBuilder.create().texOffs(676, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, 1.77249806769021F, -3.141592653589793F, -0.03325871856882619F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_81", CubeListBuilder.create().texOffs(690, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, 1.8844621590033208F, -3.141592653589793F, -0.022658664463092667F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_82", CubeListBuilder.create().texOffs(704, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, 1.9562246072053258F, -3.141592653589793F, -0.01320396557383507F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_83", CubeListBuilder.create().texOffs(718, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, 1.991319339421627F, -3.141592653589793F, -0.0043402212738899125F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_84", CubeListBuilder.create().texOffs(732, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, 1.991319339421627F, 3.141592653589793F, 0.0043402212738899125F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_85", CubeListBuilder.create().texOffs(746, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, 1.9562246072053258F, 3.141592653589793F, 0.01320396557383507F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_86", CubeListBuilder.create().texOffs(760, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, 1.8844621590033208F, 3.141592653589793F, 0.022658664463092667F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_87", CubeListBuilder.create().texOffs(774, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, 1.77249806769021F, 3.141592653589793F, 0.03325871856882619F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_88", CubeListBuilder.create().texOffs(788, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, 1.6138034621226112F, 3.141592653589793F, 0.045909987853499166F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_89", CubeListBuilder.create().texOffs(802, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, 1.3962736517396919F, 3.141592653589793F, 0.062399476109604446F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_90", CubeListBuilder.create().texOffs(658, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, 1.1639555558182972F, 3.141592653589793F, 0.08147660732059007F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_91", CubeListBuilder.create().texOffs(668, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, 0.9429181307939534F, 3.141592653589793F, 0.10233773027253686F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_92", CubeListBuilder.create().texOffs(752, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, 0.7092363090059095F, 3.141592653589793F, 0.1297943922103161F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_93", CubeListBuilder.create().texOffs(276, 327).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, 0.467256680188028F, 3.141592653589793F, 0.16829675399894287F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_94", CubeListBuilder.create().texOffs(856, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, 0.22332639944663635F, 3.141592653589793F, 0.226131387547358F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_95", CubeListBuilder.create().texOffs(860, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, 0.08044058438866682F, 3.141592653589793F, 0.07093225460458151F, 0.0F));
    }

    private static void piezas25(PartDefinition g) {
        g.addOrReplaceChild("torreta_arriba0_96", CubeListBuilder.create().texOffs(864, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, 0.24132175316600046F, -3.141592653589793F, -0.20240380725765253F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_97", CubeListBuilder.create().texOffs(264, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, 0.6699791983399089F, -3.141592653589793F, -0.4847354486182298F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_98", CubeListBuilder.create().texOffs(760, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, 1.4017700405640814F, -3.141592653589793F, -0.4048266624432962F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_99", CubeListBuilder.create().texOffs(768, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, 2.127708927017725F, -3.141592653589793F, -0.3363761555098399F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_100", CubeListBuilder.create().texOffs(678, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, 2.8287543923818594F, -3.141592653589793F, -0.2784887017498119F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_101", CubeListBuilder.create().texOffs(688, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, 3.491866667454892F, -3.141592653589793F, -0.22910973342865612F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_102", CubeListBuilder.create().texOffs(816, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, 4.188820955219076F, -3.141592653589793F, -0.17997806135894623F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_103", CubeListBuilder.create().texOffs(830, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, 4.8414103863678335F, -3.141592653589793F, -0.13475778576947076F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_104", CubeListBuilder.create().texOffs(844, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, 5.3174942030706305F, -3.141592653589793F, -0.09862428942245273F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_105", CubeListBuilder.create().texOffs(858, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, 5.653386477009963F, -3.141592653589793F, -0.06760750425699437F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_106", CubeListBuilder.create().texOffs(872, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, 5.868673821615978F, -3.141592653589793F, -0.03953848719601994F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_107", CubeListBuilder.create().texOffs(886, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, 5.973958018264882F, -3.141592653589793F, -0.013018048518655989F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_108", CubeListBuilder.create().texOffs(900, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, 5.973958018264882F, 3.141592653589793F, 0.013018048518655989F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_109", CubeListBuilder.create().texOffs(914, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, 5.868673821615978F, 3.141592653589793F, 0.03953848719601994F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_110", CubeListBuilder.create().texOffs(928, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, 5.653386477009963F, 3.141592653589793F, 0.06760750425699437F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_111", CubeListBuilder.create().texOffs(942, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, 5.3174942030706305F, 3.141592653589793F, 0.09862428942245273F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_112", CubeListBuilder.create().texOffs(956, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, 4.8414103863678335F, 3.141592653589793F, 0.13475778576947076F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_113", CubeListBuilder.create().texOffs(970, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, 4.188820955219076F, 3.141592653589793F, 0.17997806135894623F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_114", CubeListBuilder.create().texOffs(698, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, 3.491866667454892F, 3.141592653589793F, 0.22910973342865612F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_115", CubeListBuilder.create().texOffs(708, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, 2.8287543923818608F, 3.141592653589793F, 0.2784887017498117F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_116", CubeListBuilder.create().texOffs(776, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, 2.1277089270177285F, 3.141592653589793F, 0.3363761555098396F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_117", CubeListBuilder.create().texOffs(784, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, 1.4017700405640836F, 3.141592653589793F, 0.4048266624432964F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_118", CubeListBuilder.create().texOffs(270, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, 0.6699791983399089F, 3.141592653589793F, 0.4847354486182298F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_119", CubeListBuilder.create().texOffs(868, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, 0.24132175316600044F, 3.141592653589793F, 0.2024038072576546F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_120", CubeListBuilder.create().texOffs(872, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, 0.40220292194333407F, -3.141592653589793F, -0.31006976359996324F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_121", CubeListBuilder.create().texOffs(276, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, 1.1166319972331817F, -3.141592653589793F, -1.1802868355520546F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_122", CubeListBuilder.create().texOffs(792, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, 2.336283400940136F, -3.141592653589793F, -0.525768929423935F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_123", CubeListBuilder.create().texOffs(800, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, 3.546181545029542F, -3.141592653589793F, -0.4626682052002364F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_124", CubeListBuilder.create().texOffs(718, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, 4.714590653969767F, -3.141592653589793F, -0.40199953017826007F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_125", CubeListBuilder.create().texOffs(728, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, 5.819777779091488F, -3.141592653589793F, -0.3440226531458382F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_126", CubeListBuilder.create().texOffs(984, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, 6.981368258698462F, -3.141592653589793F, -0.28010947828323F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_127", CubeListBuilder.create().texOffs(998, 284).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, 8.069017310613058F, -3.141592653589793F, -0.21573212828874122F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_128", CubeListBuilder.create().texOffs(0, 289).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, 8.862490338451053F, -3.141592653589793F, -0.16076062662315765F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_129", CubeListBuilder.create().texOffs(14, 289).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, 9.422310795016607F, -3.141592653589793F, -0.11148588586348276F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_130", CubeListBuilder.create().texOffs(28, 289).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, 9.781123036026631F, -3.141592653589793F, -0.06565520657082505F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_131", CubeListBuilder.create().texOffs(42, 289).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, 9.956596697108136F, -3.141592653589793F, -0.021688039300371963F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_132", CubeListBuilder.create().texOffs(56, 289).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, 9.956596697108138F, 3.141592653589793F, 0.021688039300371963F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_133", CubeListBuilder.create().texOffs(70, 289).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, 9.781123036026631F, 3.141592653589793F, 0.06565520657082505F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_134", CubeListBuilder.create().texOffs(84, 289).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, 9.422310795016607F, 3.141592653589793F, 0.11148588586348276F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_135", CubeListBuilder.create().texOffs(98, 289).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, 8.862490338451053F, 3.141592653589793F, 0.16076062662315765F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_136", CubeListBuilder.create().texOffs(112, 289).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, 8.069017310613058F, 3.141592653589793F, 0.21573212828874122F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_137", CubeListBuilder.create().texOffs(126, 289).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, 6.981368258698462F, 3.141592653589793F, 0.28010947828323F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_138", CubeListBuilder.create().texOffs(738, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, 5.819777779091488F, 3.141592653589793F, 0.3440226531458382F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_139", CubeListBuilder.create().texOffs(748, 294).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, 4.714590653969768F, 3.141592653589793F, 0.40199953017825985F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_140", CubeListBuilder.create().texOffs(808, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, 3.5461815450295475F, 3.141592653589793F, 0.46266820520023566F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_141", CubeListBuilder.create().texOffs(816, 324).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, 2.3362834009401396F, 3.141592653589793F, 0.5257689294239353F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_142", CubeListBuilder.create().texOffs(282, 336).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, 1.1166319972331817F, -3.141592653589793F, 1.1802868355520546F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_143", CubeListBuilder.create().texOffs(876, 336).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, 0.40220292194333407F, 3.141592653589793F, 0.31006976359996596F, 0.0F));
        g.addOrReplaceChild("torreta_trompa", CubeListBuilder.create().texOffs(356, 0).addBox(0.0F, -26.0F, 0.0F, 1.0F, 26.0F, 60.0F), PartPose.offset(-14.0F, -25.0F, -15.0F));
        g.addOrReplaceChild("torreta_cola", CubeListBuilder.create().texOffs(478, 0).addBox(0.0F, -26.0F, 0.0F, 1.0F, 26.0F, 60.0F), PartPose.offset(19.0F, -25.0F, -15.0F));
        g.addOrReplaceChild("torreta_brocal", CubeListBuilder.create().texOffs(500, 109).addBox(1.0F, -38.0F, -9.0F, 1.0F, 1.0F, 18.0F).texOffs(538, 109).addBox(15.0F, -38.0F, -9.0F, 1.0F, 1.0F, 18.0F).texOffs(346, 327).addBox(2.0F, -38.0F, -10.0F, 13.0F, 1.0F, 1.0F).texOffs(374, 327).addBox(2.0F, -38.0F, 9.0F, 13.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("torreta_tapa_i", CubeListBuilder.create().texOffs(142, 109).addBox(-16.0F, 0.0F, -16.0F, 32.0F, 1.0F, 32.0F), PartPose.offsetAndRotation(8.5F, -41.5F, -10.6F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("torreta_tapa_d", CubeListBuilder.create().texOffs(270, 109).addBox(-16.0F, 0.0F, -16.0F, 32.0F, 1.0F, 32.0F), PartPose.offsetAndRotation(8.5F, -41.5F, 10.6F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("torreta_mantelete", CubeListBuilder.create().texOffs(464, 109).addBox(-19.0F, -35.0F, -6.0F, 6.0F, 8.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("torreta_canon_0", CubeListBuilder.create().texOffs(8, 299).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -31.325000000000003F, 1.212916512459885F, 1.3089969389957468F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_1", CubeListBuilder.create().texOffs(184, 299).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -31.887916512459885F, 0.8879165124598853F, 0.7853981633974508F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_2", CubeListBuilder.create().texOffs(360, 299).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -32.212916512459884F, 0.32500000000000007F, 0.26179938779914397F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_3", CubeListBuilder.create().texOffs(536, 299).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -32.212916512459884F, -0.3249999999999998F, -0.261799387799144F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_4", CubeListBuilder.create().texOffs(712, 299).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -31.88791651245989F, -0.8879165124598849F, -0.785398163397447F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_5", CubeListBuilder.create().texOffs(0, 303).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -31.325000000000003F, -1.212916512459885F, -1.3089969389957476F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_6", CubeListBuilder.create().texOffs(176, 303).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -30.674999999999997F, -1.2129165124598855F, -1.832595714594046F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_7", CubeListBuilder.create().texOffs(352, 303).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -30.112083487540115F, -0.8879165124598856F, -2.3561944901923426F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_8", CubeListBuilder.create().texOffs(528, 303).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -29.787083487540116F, -0.3250000000000004F, -2.8797932657906444F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_9", CubeListBuilder.create().texOffs(704, 303).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -29.787083487540116F, 0.32499999999999946F, 2.879793265790644F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_10", CubeListBuilder.create().texOffs(0, 306).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -30.11208348754011F, 0.8879165124598845F, 2.3561944901923466F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_11", CubeListBuilder.create().texOffs(176, 306).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -30.674999999999997F, 1.212916512459885F, 1.832595714594046F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_ta", CubeListBuilder.create().texOffs(336, 146).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-18.95F, -31.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("torreta_canon_tb", CubeListBuilder.create().texOffs(380, 146).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-62.05F, -31.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("torreta_evacuador_0", CubeListBuilder.create().texOffs(992, 306).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -31.475F, 1.7727241335952169F, 1.3089969389957472F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_1", CubeListBuilder.create().texOffs(0, 309).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -32.29772413359522F, 1.2977241335952168F, 0.7853981633974475F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_2", CubeListBuilder.create().texOffs(28, 309).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -32.77272413359522F, 0.47500000000000014F, 0.26179938779914985F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_3", CubeListBuilder.create().texOffs(56, 309).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -32.77272413359522F, -0.4749999999999997F, -0.26179938779914996F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_4", CubeListBuilder.create().texOffs(84, 309).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -32.29772413359522F, -1.2977241335952163F, -0.7853981633974474F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_5", CubeListBuilder.create().texOffs(112, 309).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -31.475F, -1.7727241335952164F, -1.3089969389957468F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_6", CubeListBuilder.create().texOffs(140, 309).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -30.525F, -1.772724133595217F, -1.8325957145940455F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_7", CubeListBuilder.create().texOffs(168, 309).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -29.702275866404783F, -1.2977241335952174F, -2.3561944901923457F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_8", CubeListBuilder.create().texOffs(196, 309).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -29.22727586640478F, -0.47500000000000064F, -2.8797932657906435F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_9", CubeListBuilder.create().texOffs(224, 309).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -29.22727586640478F, 0.4749999999999992F, 2.8797932657906467F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_10", CubeListBuilder.create().texOffs(252, 309).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -29.702275866404783F, 1.2977241335952159F, 2.356194490192344F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_11", CubeListBuilder.create().texOffs(280, 309).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -30.525F, 1.7727241335952164F, 1.8325957145940466F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_ta", CubeListBuilder.create().texOffs(576, 109).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-37.95F, -31.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("torreta_evacuador_tb", CubeListBuilder.create().texOffs(640, 109).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-44.05F, -31.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("torreta_boca_0", CubeListBuilder.create().texOffs(308, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -31.475F, 1.7727241335952169F, 1.3089969389957472F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_1", CubeListBuilder.create().texOffs(328, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -32.29772413359522F, 1.2977241335952168F, 0.7853981633974475F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_2", CubeListBuilder.create().texOffs(348, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -32.77272413359522F, 0.47500000000000014F, 0.26179938779914985F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_3", CubeListBuilder.create().texOffs(368, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -32.77272413359522F, -0.4749999999999997F, -0.26179938779914996F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_4", CubeListBuilder.create().texOffs(388, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -32.29772413359522F, -1.2977241335952163F, -0.7853981633974474F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_5", CubeListBuilder.create().texOffs(408, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -31.475F, -1.7727241335952164F, -1.3089969389957468F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_6", CubeListBuilder.create().texOffs(428, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -30.525F, -1.772724133595217F, -1.8325957145940455F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_7", CubeListBuilder.create().texOffs(448, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -29.702275866404783F, -1.2977241335952174F, -2.3561944901923457F, 0.0F, -3.141592653589793F));
    }

    private static void piezas26(PartDefinition g) {
        g.addOrReplaceChild("torreta_boca_8", CubeListBuilder.create().texOffs(468, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -29.22727586640478F, -0.47500000000000064F, -2.8797932657906435F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_9", CubeListBuilder.create().texOffs(488, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -29.22727586640478F, 0.4749999999999992F, 2.8797932657906467F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_10", CubeListBuilder.create().texOffs(508, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -29.702275866404783F, 1.2977241335952159F, 2.356194490192344F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_11", CubeListBuilder.create().texOffs(528, 309).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -30.525F, 1.7727241335952164F, 1.8325957145940466F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_ta", CubeListBuilder.create().texOffs(704, 109).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-61.95F, -31.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("torreta_boca_tb", CubeListBuilder.create().texOffs(768, 109).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-66.05F, -31.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("torreta_antena", CubeListBuilder.create().texOffs(460, 109).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 28.0F, 1.0F), PartPose.offsetAndRotation(14.0F, -37.0F, -10.0F, 0.0F, 0.0F, -3.067653615931853F));
        g.addOrReplaceChild("faro_i_0", CubeListBuilder.create().texOffs(6, 294).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(424, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, -17.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_1", CubeListBuilder.create().texOffs(30, 294).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(448, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, -17.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_2", CubeListBuilder.create().texOffs(54, 294).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(472, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, -17.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_3", CubeListBuilder.create().texOffs(78, 294).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(496, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, -17.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_vidrio", CubeListBuilder.create().texOffs(0, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-44.82F, -21.5F, -17.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("caja_herramientas_i", CubeListBuilder.create().texOffs(638, 146).addBox(16.0F, -30.0F, -21.0F, 14.0F, 4.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("escape_i_0", CubeListBuilder.create().texOffs(352, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(45.35676274578121F, -19.559161060780646F, -7.5F, 0.0F, 1.5707963267948966F, -1.2566370614359172F));
        g.addOrReplaceChild("escape_i_1", CubeListBuilder.create().texOffs(384, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.83852549156242F, -18.84586867355928F, -7.5F, 0.0F, 1.5707963267948966F, -0.62831853071796F));
        g.addOrReplaceChild("escape_i_2", CubeListBuilder.create().texOffs(416, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.0F, -18.57341522555727F, -7.5F, 0.0F, 1.5707963267948966F, 0.0F));
        g.addOrReplaceChild("escape_i_3", CubeListBuilder.create().texOffs(448, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(43.16147450843758F, -18.84586867355928F, -7.5F, 0.0F, 1.5707963267948966F, 0.62831853071796F));
        g.addOrReplaceChild("escape_i_4", CubeListBuilder.create().texOffs(480, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(42.64323725421879F, -19.559161060780646F, -7.5F, 0.0F, 1.5707963267948966F, 1.2566370614359172F));
        g.addOrReplaceChild("escape_i_5", CubeListBuilder.create().texOffs(512, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(42.64323725421879F, -20.440838939219354F, -7.5F, 0.0F, 1.5707963267948966F, 1.8849555921538759F));
        g.addOrReplaceChild("escape_i_6", CubeListBuilder.create().texOffs(544, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(43.16147450843758F, -21.15413132644072F, -7.5F, 0.0F, 1.5707963267948966F, 2.513274122871833F));
        g.addOrReplaceChild("escape_i_7", CubeListBuilder.create().texOffs(576, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.0F, -21.42658477444273F, -7.5F, 0.0F, 1.5707963267948966F, 3.141592653589793F));
        g.addOrReplaceChild("escape_i_8", CubeListBuilder.create().texOffs(608, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.83852549156242F, -21.15413132644072F, -7.5F, 0.0F, 1.5707963267948966F, -2.513274122871833F));
        g.addOrReplaceChild("escape_i_9", CubeListBuilder.create().texOffs(640, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(45.35676274578121F, -20.440838939219354F, -7.5F, 0.0F, 1.5707963267948966F, -1.8849555921538759F));
        g.addOrReplaceChild("escape_i_ta", CubeListBuilder.create().texOffs(48, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(44.0F, -20.0F, -3.95F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escape_i_tb", CubeListBuilder.create().texOffs(96, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(44.0F, -20.0F, -11.05F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("gancho_i", CubeListBuilder.create().texOffs(1014, 294).addBox(-46.0F, -16.0F, -9.0F, 2.0F, 2.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("faro_d_0", CubeListBuilder.create().texOffs(102, 294).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(520, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, 17.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_1", CubeListBuilder.create().texOffs(126, 294).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(544, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, 17.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_2", CubeListBuilder.create().texOffs(150, 294).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(568, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, 17.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_3", CubeListBuilder.create().texOffs(174, 294).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(592, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, 17.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_vidrio", CubeListBuilder.create().texOffs(144, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-44.82F, -21.5F, 17.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("caja_herramientas_d", CubeListBuilder.create().texOffs(678, 146).addBox(16.0F, -30.0F, 15.0F, 14.0F, 4.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("escape_d_0", CubeListBuilder.create().texOffs(672, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(45.35676274578121F, -20.440838939219354F, 7.5F, 0.0F, -1.5707963267948966F, -1.8849555921538759F));
        g.addOrReplaceChild("escape_d_1", CubeListBuilder.create().texOffs(704, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.83852549156242F, -21.15413132644072F, 7.5F, 0.0F, -1.5707963267948966F, -2.513274122871833F));
        g.addOrReplaceChild("escape_d_2", CubeListBuilder.create().texOffs(736, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.0F, -21.42658477444273F, 7.5F, 0.0F, -1.5707963267948966F, 3.141592653589793F));
        g.addOrReplaceChild("escape_d_3", CubeListBuilder.create().texOffs(768, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(43.16147450843758F, -21.15413132644072F, 7.5F, 0.0F, -1.5707963267948966F, 2.513274122871833F));
        g.addOrReplaceChild("escape_d_4", CubeListBuilder.create().texOffs(800, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(42.64323725421879F, -20.440838939219354F, 7.5F, 0.0F, -1.5707963267948966F, 1.8849555921538759F));
        g.addOrReplaceChild("escape_d_5", CubeListBuilder.create().texOffs(832, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(42.64323725421879F, -19.559161060780646F, 7.5F, 0.0F, -1.5707963267948966F, 1.2566370614359172F));
        g.addOrReplaceChild("escape_d_6", CubeListBuilder.create().texOffs(864, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(43.16147450843758F, -18.84586867355928F, 7.5F, 0.0F, -1.5707963267948966F, 0.62831853071796F));
        g.addOrReplaceChild("escape_d_7", CubeListBuilder.create().texOffs(896, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.0F, -18.57341522555727F, 7.5F, 0.0F, -1.5707963267948966F, 0.0F));
        g.addOrReplaceChild("escape_d_8", CubeListBuilder.create().texOffs(928, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.83852549156242F, -18.84586867355928F, 7.5F, 0.0F, -1.5707963267948966F, -0.62831853071796F));
        g.addOrReplaceChild("escape_d_9", CubeListBuilder.create().texOffs(960, 306).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(45.35676274578121F, -19.559161060780646F, 7.5F, 0.0F, -1.5707963267948966F, -1.2566370614359172F));
        g.addOrReplaceChild("escape_d_ta", CubeListBuilder.create().texOffs(192, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(44.0F, -20.0F, 3.95F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escape_d_tb", CubeListBuilder.create().texOffs(240, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(44.0F, -20.0F, 11.05F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("gancho_d", CubeListBuilder.create().texOffs(0, 299).addBox(-46.0F, -16.0F, 7.0F, 2.0F, 2.0F, 2.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0) {
        escalar(g0, "oruga_i_0", 0.5063869860716943F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_1", 0.5063601380072248F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_2", 0.5063389203709479F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_3", 0.5063233338878793F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_4", 0.5063133790906962F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_5", 0.5063090563196445F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_6", 0.5063103657224831F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_7", 0.5089596810828121F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_8", 0.5093989029915129F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_9", 0.5093989029915142F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_10", 0.5093989029915144F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_11", 0.5093989029915142F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_12", 0.5060352788217506F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_13", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_14", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_15", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_16", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_17", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_18", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_19", 0.5093989029915128F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_20", 0.5093989029915149F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_21", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_22", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_23", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_24", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_25", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_26", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_27", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_28", 0.5093989029915117F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_29", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_30", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_31", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_32", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_33", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_34", 0.5066152404338851F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_35", 0.5093989029915115F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_36", 0.5093989029915151F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_37", 0.5093989029915144F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_38", 0.5093989029915128F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_39", 0.5093204824678594F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_40", 0.5057925113291981F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_41", 0.5057744088602023F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_42", 0.5057856340510483F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_43", 0.5058261849017773F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_44", 0.5058481048909312F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_45", 0.505816261870119F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_46", 0.5074420691410381F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_47", 0.5093989029915127F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_48", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_49", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_50", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_51", 0.5093989029915148F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_52", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_53", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_54", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_55", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_56", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_57", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_58", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_59", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_60", 0.5093989029915184F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_61", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_62", 0.5093989029915205F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_63", 0.5093989029915077F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_64", 0.5093989029915127F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_65", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_66", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_67", 0.509398902991517F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_68", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_69", 0.5093989029915184F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_70", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_71", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_72", 0.5093989029915184F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_73", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_74", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_75", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_76", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_77", 0.5063869860716943F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_78", 0.5063601380072248F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_79", 0.5063389203709479F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_80", 0.5063233338878793F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_81", 0.5063133790906962F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_82", 0.5063090563196445F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_83", 0.5063103657224831F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_84", 0.5089596810828121F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_85", 0.5093989029915129F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_86", 0.5093989029915142F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_87", 0.5093989029915144F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_88", 0.5093989029915142F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_89", 0.5060352788217506F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_90", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_91", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_92", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_93", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_94", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_95", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_96", 0.5093989029915128F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_97", 0.5093989029915149F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_98", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_99", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_100", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_101", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_102", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_103", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_104", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_105", 0.5093989029915117F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_106", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_107", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_108", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_109", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_110", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_111", 0.5066152404338851F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_112", 0.5093989029915115F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_113", 0.5093989029915151F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_114", 0.5093989029915144F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_115", 0.5093989029915128F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_116", 0.5093204824678594F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_117", 0.5057925113291981F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_118", 0.5057744088602023F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_119", 0.5057856340510483F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_120", 0.5058261849017773F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_121", 0.5058481048909312F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_122", 0.505816261870119F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_123", 0.5074420691410381F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_124", 0.5093989029915127F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_125", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_126", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_127", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_128", 0.5093989029915148F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_129", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_130", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_131", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_132", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_133", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_134", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_135", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_136", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_137", 0.5093989029915184F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_138", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_139", 0.5093989029915205F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_140", 0.5093989029915077F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_141", 0.5093989029915127F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_142", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_143", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_144", 0.509398902991517F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_145", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_146", 0.5093989029915184F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_147", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_148", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_149", 0.5093989029915184F, 1.0F, 0.5075F);
    }

    private static void escalas1(ModelPart g0) {
        escalar(g0, "oruga_i_150", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_151", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_152", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_i_153", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "rodillo_i0_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_i1_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_i2_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_i3_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_i4_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_i5_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "motriz_i_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "tensora_i_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_alto_i0_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_alto_i1_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "oruga_d_0", 0.5063869860716943F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_1", 0.5063601380072248F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_2", 0.5063389203709479F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_3", 0.5063233338878793F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_4", 0.5063133790906962F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_5", 0.5063090563196445F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_6", 0.5063103657224831F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_7", 0.5089596810828121F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_8", 0.5093989029915129F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_9", 0.5093989029915142F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_10", 0.5093989029915144F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_11", 0.5093989029915142F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_12", 0.5060352788217506F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_13", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_14", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_15", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_16", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_17", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_18", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_19", 0.5093989029915128F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_20", 0.5093989029915149F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_21", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_22", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_23", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_24", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_25", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_26", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_27", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_28", 0.5093989029915117F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_29", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_30", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_31", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_32", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_33", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_34", 0.5066152404338851F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_35", 0.5093989029915115F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_36", 0.5093989029915151F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_37", 0.5093989029915144F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_38", 0.5093989029915128F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_39", 0.5093204824678594F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_40", 0.5057925113291981F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_41", 0.5057744088602023F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_42", 0.5057856340510483F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_43", 0.5058261849017773F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_44", 0.5058481048909312F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_45", 0.505816261870119F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_46", 0.5074420691410381F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_47", 0.5093989029915127F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_48", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_49", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_50", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_51", 0.5093989029915148F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_52", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_53", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_54", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_55", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_56", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_57", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_58", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_59", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_60", 0.5093989029915184F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_61", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_62", 0.5093989029915205F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_63", 0.5093989029915077F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_64", 0.5093989029915127F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_65", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_66", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_67", 0.509398902991517F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_68", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_69", 0.5093989029915184F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_70", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_71", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_72", 0.5093989029915184F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_73", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_74", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_75", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_76", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_77", 0.5063869860716943F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_78", 0.5063601380072248F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_79", 0.5063389203709479F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_80", 0.5063233338878793F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_81", 0.5063133790906962F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_82", 0.5063090563196445F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_83", 0.5063103657224831F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_84", 0.5089596810828121F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_85", 0.5093989029915129F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_86", 0.5093989029915142F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_87", 0.5093989029915144F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_88", 0.5093989029915142F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_89", 0.5060352788217506F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_90", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_91", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_92", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_93", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_94", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_95", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_96", 0.5093989029915128F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_97", 0.5093989029915149F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_98", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_99", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_100", 0.5093989029915131F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_101", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_102", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_103", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_104", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_105", 0.5093989029915117F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_106", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_107", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_108", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_109", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_110", 0.5093989029915146F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_111", 0.5066152404338851F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_112", 0.5093989029915115F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_113", 0.5093989029915151F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_114", 0.5093989029915144F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_115", 0.5093989029915128F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_116", 0.5093204824678594F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_117", 0.5057925113291981F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_118", 0.5057744088602023F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_119", 0.5057856340510483F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_120", 0.5058261849017773F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_121", 0.5058481048909312F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_122", 0.505816261870119F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_123", 0.5074420691410381F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_124", 0.5093989029915127F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_125", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_126", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_127", 0.5093989029915141F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_128", 0.5093989029915148F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_129", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_130", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_131", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_132", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_133", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_134", 0.509398902991512F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_135", 0.5093989029915169F, 1.0F, 0.5075F);
    }

    private static void escalas2(ModelPart g0) {
        escalar(g0, "oruga_d_136", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_137", 0.5093989029915184F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_138", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_139", 0.5093989029915205F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_140", 0.5093989029915077F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_141", 0.5093989029915127F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_142", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_143", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_144", 0.509398902991517F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_145", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_146", 0.5093989029915184F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_147", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_148", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_149", 0.5093989029915184F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_150", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_151", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_152", 0.5093989029915112F, 1.0F, 0.5075F);
        escalar(g0, "oruga_d_153", 0.5093989029915169F, 1.0F, 0.5075F);
        escalar(g0, "rodillo_d0_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_d1_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_d2_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_d3_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_d4_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_d5_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "motriz_d_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "tensora_d_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_alto_d0_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_alto_d1_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "casco_bajo_ladoi_0", 0.2618043607061133F, 1.0F, 0.7775000000000005F);
        escalar(g0, "casco_bajo_ladoi_1", 0.4636087214122077F, 1.0F, 0.81125F);
        escalar(g0, "casco_bajo_ladoi_2", 0.7326812023536851F, 1.0F, 0.8675000000000004F);
        escalar(g0, "casco_bajo_ladoi_3", 1.0017536832951635F, 1.0F, 0.9462499999999998F);
        escalar(g0, "casco_bajo_ladoi_4", 0.635413082118316F, 1.0F, 0.6983333333333334F);
        escalar(g0, "casco_bajo_ladoi_5", 0.7699493225890552F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladoi_6", 0.9044855630597892F, 1.0F, 0.8783333333333334F);
        escalar(g0, "casco_bajo_ladoi_7", 0.9771942809610923F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_8", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_9", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_10", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_11", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_12", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_13", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_14", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_15", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_16", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_17", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_18", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_19", 1.0149999999999981F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_20", 1.0150000000000017F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_21", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_22", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_23", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_24", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_25", 0.8320000000000001F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_26", 0.9044855630597892F, 1.0F, 0.7712500000000001F);
        escalar(g0, "casco_bajo_ladoi_27", 0.76994932258906F, 1.0F, 0.9308333333333336F);
        escalar(g0, "casco_bajo_ladoi_28", 0.635413082118311F, 1.0F, 0.8483333333333332F);
        escalar(g0, "casco_bajo_ladoi_29", 1.0017536832951635F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladoi_30", 0.7326812023536851F, 1.0F, 0.7283333333333334F);
        escalar(g0, "casco_bajo_ladoi_31", 0.4636087214122089F, 1.0F, 0.6908333333333331F);
        escalar(g0, "casco_bajo_ladoi_32", 0.2618043607061133F, 1.0F, 1.0025000000000002F);
        escalar(g0, "casco_bajo_ladoi_33", 0.4219478553604066F, 1.0F, 0.81125F);
        escalar(g0, "casco_bajo_ladoi_34", 0.6632464256006818F, 1.0F, 0.8674999999999995F);
        escalar(g0, "casco_bajo_ladoi_35", 0.9045449958409602F, 1.0F, 0.9462500000000007F);
        escalar(g0, "casco_bajo_ladoi_36", 0.5729217830406134F, 1.0F, 0.6983333333333334F);
        escalar(g0, "casco_bajo_ladoi_37", 0.693571068160752F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladoi_38", 0.8142203532808857F, 1.0F, 0.8783333333333337F);
        escalar(g0, "casco_bajo_ladoi_39", 0.9086744113668015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_40", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_41", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_42", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_43", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_44", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_45", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_46", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_47", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_48", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_49", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_50", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_51", 1.0149999999999981F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_52", 1.0150000000000017F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_53", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_54", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_55", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_56", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_57", 0.8233106679934634F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_58", 0.8142203532808857F, 1.0F, 0.7712499999999997F);
        escalar(g0, "casco_bajo_ladoi_59", 0.6935710681607564F, 1.0F, 0.930833333333334F);
        escalar(g0, "casco_bajo_ladoi_60", 0.5729217830406089F, 1.0F, 0.8483333333333326F);
        escalar(g0, "casco_bajo_ladoi_61", 0.9045449958409593F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladoi_62", 0.6632464256006818F, 1.0F, 0.7283333333333334F);
        escalar(g0, "casco_bajo_ladoi_63", 0.4219478553604076F, 1.0F, 0.6908333333333337F);
        escalar(g0, "casco_bajo_ladoi_64", 0.3889756829919162F, 1.0F, 0.81125F);
        escalar(g0, "casco_bajo_ladoi_65", 0.6082928049865326F, 1.0F, 0.8674999999999995F);
        escalar(g0, "casco_bajo_ladoi_66", 0.827609926981149F, 1.0F, 0.9462500000000007F);
        escalar(g0, "casco_bajo_ladoi_67", 1.0469270489757574F, 1.0F, 0.6983333333333334F);
        escalar(g0, "casco_bajo_ladoi_68", 0.6331220854851869F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladoi_69", 0.7427806464824906F, 1.0F, 0.8783333333333331F);
        escalar(g0, "casco_bajo_ladoi_70", 0.8563340571124678F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_71", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_72", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_73", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_74", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_75", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_76", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_77", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_78", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_79", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_80", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_81", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_82", 1.0149999999999981F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_83", 1.0150000000000017F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_84", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_85", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_86", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_87", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_88", 0.8170465825031492F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_89", 0.7427806464824914F, 1.0F, 0.7712500000000001F);
        escalar(g0, "casco_bajo_ladoi_90", 0.6331220854851904F, 1.0F, 0.9308333333333327F);
        escalar(g0, "casco_bajo_ladoi_91", 1.0469270489757494F, 1.0F, 0.8483333333333326F);
        escalar(g0, "casco_bajo_ladoi_92", 0.827609926981149F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladoi_93", 0.6082928049865326F, 1.0F, 0.7283333333333334F);
        escalar(g0, "casco_bajo_ladoi_94", 0.3889756829919169F, 1.0F, 0.6908333333333337F);
        escalar(g0, "casco_bajo_ladoi_95", 0.367499999999997F, 1.0F, 0.81125F);
        escalar(g0, "casco_bajo_ladoi_96", 0.5725000000000002F, 1.0F, 0.8675000000000004F);
        escalar(g0, "casco_bajo_ladoi_97", 0.7775000000000025F, 1.0F, 0.9462499999999998F);
        escalar(g0, "casco_bajo_ladoi_98", 0.9824999999999988F, 1.0F, 0.6983333333333334F);
        escalar(g0, "casco_bajo_ladoi_99", 0.5937500000000008F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladoi_100", 0.6962499999999985F, 1.0F, 0.8783333333333331F);
        escalar(g0, "casco_bajo_ladoi_101", 0.8233106679934634F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_102", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_103", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_104", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_105", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_106", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_107", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_108", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_109", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_110", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_111", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_112", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_113", 1.0149999999999981F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_114", 1.0150000000000017F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_115", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_116", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_117", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_118", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_119", 0.813264625451542F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladoi_120", 0.6962499999999985F, 1.0F, 0.7712500000000001F);
        escalar(g0, "casco_bajo_ladoi_121", 0.5937500000000044F, 1.0F, 0.930833333333334F);
    }

    private static void escalas3(ModelPart g0) {
        escalar(g0, "casco_bajo_ladoi_122", 0.9824999999999913F, 1.0F, 0.8483333333333332F);
        escalar(g0, "casco_bajo_ladoi_123", 0.777500000000003F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladoi_124", 0.5725000000000002F, 1.0F, 0.7283333333333334F);
        escalar(g0, "casco_bajo_ladoi_125", 0.367499999999997F, 1.0F, 0.6908333333333331F);
        escalar(g0, "casco_bajo_ladoi_126", 0.35999999999999716F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_127", 0.56F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_128", 0.7600000000000029F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_129", 0.9599999999999986F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_130", 0.5800000000000007F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_131", 0.6799999999999986F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_132", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_133", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_134", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_135", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_136", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_137", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_138", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_139", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_140", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_141", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_142", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_143", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_144", 1.0149999999999981F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_145", 1.0150000000000017F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_146", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_147", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_148", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_149", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_150", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_151", 0.6799999999999986F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_152", 0.5800000000000043F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_153", 0.9599999999999915F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_154", 0.7600000000000029F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_155", 0.56F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_156", 0.35999999999999716F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladoi_157", 0.35999999999999716F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_158", 0.56F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_159", 0.7600000000000029F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_160", 0.9599999999999986F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_161", 0.5800000000000007F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_162", 0.6799999999999986F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_163", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_164", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_165", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_166", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_167", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_168", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_169", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_170", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_171", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_172", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_173", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_174", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_175", 1.0149999999999981F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_176", 1.0150000000000017F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_177", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_178", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_179", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_180", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_181", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_182", 0.6799999999999986F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_183", 0.5800000000000043F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_184", 0.9599999999999915F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_185", 0.7600000000000029F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_186", 0.56F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_187", 0.35999999999999716F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladoi_188", 0.35999999999999716F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_189", 0.56F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_190", 0.7600000000000029F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_191", 0.9599999999999986F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_192", 0.5800000000000007F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_193", 0.6799999999999986F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_194", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_195", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_196", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_197", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_198", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_199", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_200", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_201", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_202", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_203", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_204", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_205", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_206", 1.0149999999999981F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_207", 1.0150000000000017F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_208", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_209", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_210", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_211", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_212", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_213", 0.6799999999999986F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_214", 0.5800000000000043F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_215", 0.9599999999999915F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_216", 0.7600000000000029F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_217", 0.56F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_218", 0.35999999999999716F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladoi_219", 0.35999999999999716F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_220", 0.56F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_221", 0.7600000000000029F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_222", 0.9599999999999986F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_223", 0.5800000000000007F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_224", 0.6799999999999986F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_225", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_226", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_227", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_228", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_229", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_230", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_231", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_232", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_233", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_234", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_235", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_236", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_237", 1.0149999999999981F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_238", 1.0150000000000017F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_239", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_240", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_241", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_242", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_243", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_244", 0.6799999999999986F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_245", 0.5800000000000043F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_246", 0.9599999999999915F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_247", 0.7600000000000029F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_248", 0.56F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladoi_249", 0.35999999999999716F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_0", 0.2618043607061133F, 1.0F, 0.7775000000000005F);
        escalar(g0, "casco_bajo_ladod_1", 0.4636087214122077F, 1.0F, 0.81125F);
        escalar(g0, "casco_bajo_ladod_2", 0.7326812023536851F, 1.0F, 0.8675000000000004F);
        escalar(g0, "casco_bajo_ladod_3", 1.0017536832951635F, 1.0F, 0.9462499999999998F);
        escalar(g0, "casco_bajo_ladod_4", 0.635413082118316F, 1.0F, 0.6983333333333334F);
        escalar(g0, "casco_bajo_ladod_5", 0.7699493225890552F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladod_6", 0.9044855630597892F, 1.0F, 0.8783333333333334F);
        escalar(g0, "casco_bajo_ladod_7", 0.9771942809610923F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_8", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_9", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_10", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_11", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_12", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_13", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_14", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_15", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_16", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_17", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_18", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_19", 1.0149999999999981F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_20", 1.0150000000000017F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_21", 1.015F, 1.0F, 0.8275F);
    }

    private static void escalas4(ModelPart g0) {
        escalar(g0, "casco_bajo_ladod_22", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_23", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_24", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_25", 0.8320000000000001F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_26", 0.9044855630597892F, 1.0F, 0.7712500000000001F);
        escalar(g0, "casco_bajo_ladod_27", 0.76994932258906F, 1.0F, 0.9308333333333336F);
        escalar(g0, "casco_bajo_ladod_28", 0.635413082118311F, 1.0F, 0.8483333333333332F);
        escalar(g0, "casco_bajo_ladod_29", 1.0017536832951635F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladod_30", 0.7326812023536851F, 1.0F, 0.7283333333333334F);
        escalar(g0, "casco_bajo_ladod_31", 0.4636087214122089F, 1.0F, 0.6908333333333331F);
        escalar(g0, "casco_bajo_ladod_32", 0.2618043607061133F, 1.0F, 1.0025000000000002F);
        escalar(g0, "casco_bajo_ladod_33", 0.4219478553604066F, 1.0F, 0.81125F);
        escalar(g0, "casco_bajo_ladod_34", 0.6632464256006818F, 1.0F, 0.8674999999999995F);
        escalar(g0, "casco_bajo_ladod_35", 0.9045449958409602F, 1.0F, 0.9462500000000007F);
        escalar(g0, "casco_bajo_ladod_36", 0.5729217830406134F, 1.0F, 0.6983333333333334F);
        escalar(g0, "casco_bajo_ladod_37", 0.693571068160752F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladod_38", 0.8142203532808857F, 1.0F, 0.8783333333333337F);
        escalar(g0, "casco_bajo_ladod_39", 0.9086744113668015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_40", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_41", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_42", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_43", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_44", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_45", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_46", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_47", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_48", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_49", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_50", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_51", 1.0149999999999981F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_52", 1.0150000000000017F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_53", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_54", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_55", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_56", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_57", 0.8233106679934634F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_58", 0.8142203532808857F, 1.0F, 0.7712499999999997F);
        escalar(g0, "casco_bajo_ladod_59", 0.6935710681607564F, 1.0F, 0.930833333333334F);
        escalar(g0, "casco_bajo_ladod_60", 0.5729217830406089F, 1.0F, 0.8483333333333326F);
        escalar(g0, "casco_bajo_ladod_61", 0.9045449958409593F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladod_62", 0.6632464256006818F, 1.0F, 0.7283333333333334F);
        escalar(g0, "casco_bajo_ladod_63", 0.4219478553604076F, 1.0F, 0.6908333333333337F);
        escalar(g0, "casco_bajo_ladod_64", 0.3889756829919162F, 1.0F, 0.81125F);
        escalar(g0, "casco_bajo_ladod_65", 0.6082928049865326F, 1.0F, 0.8674999999999995F);
        escalar(g0, "casco_bajo_ladod_66", 0.827609926981149F, 1.0F, 0.9462500000000007F);
        escalar(g0, "casco_bajo_ladod_67", 1.0469270489757574F, 1.0F, 0.6983333333333334F);
        escalar(g0, "casco_bajo_ladod_68", 0.6331220854851869F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladod_69", 0.7427806464824906F, 1.0F, 0.8783333333333331F);
        escalar(g0, "casco_bajo_ladod_70", 0.8563340571124678F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_71", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_72", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_73", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_74", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_75", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_76", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_77", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_78", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_79", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_80", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_81", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_82", 1.0149999999999981F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_83", 1.0150000000000017F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_84", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_85", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_86", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_87", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_88", 0.8170465825031492F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_89", 0.7427806464824914F, 1.0F, 0.7712500000000001F);
        escalar(g0, "casco_bajo_ladod_90", 0.6331220854851904F, 1.0F, 0.9308333333333327F);
        escalar(g0, "casco_bajo_ladod_91", 1.0469270489757494F, 1.0F, 0.8483333333333326F);
        escalar(g0, "casco_bajo_ladod_92", 0.827609926981149F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladod_93", 0.6082928049865326F, 1.0F, 0.7283333333333334F);
        escalar(g0, "casco_bajo_ladod_94", 0.3889756829919169F, 1.0F, 0.6908333333333337F);
        escalar(g0, "casco_bajo_ladod_95", 0.367499999999997F, 1.0F, 0.81125F);
        escalar(g0, "casco_bajo_ladod_96", 0.5725000000000002F, 1.0F, 0.8675000000000004F);
        escalar(g0, "casco_bajo_ladod_97", 0.7775000000000025F, 1.0F, 0.9462499999999998F);
        escalar(g0, "casco_bajo_ladod_98", 0.9824999999999988F, 1.0F, 0.6983333333333334F);
        escalar(g0, "casco_bajo_ladod_99", 0.5937500000000008F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladod_100", 0.6962499999999985F, 1.0F, 0.8783333333333331F);
        escalar(g0, "casco_bajo_ladod_101", 0.8233106679934634F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_102", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_103", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_104", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_105", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_106", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_107", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_108", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_109", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_110", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_111", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_112", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_113", 1.0149999999999981F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_114", 1.0150000000000017F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_115", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_116", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_117", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_118", 1.015F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_119", 0.813264625451542F, 1.0F, 0.8275F);
        escalar(g0, "casco_bajo_ladod_120", 0.6962499999999985F, 1.0F, 0.7712500000000001F);
        escalar(g0, "casco_bajo_ladod_121", 0.5937500000000044F, 1.0F, 0.930833333333334F);
        escalar(g0, "casco_bajo_ladod_122", 0.9824999999999913F, 1.0F, 0.8483333333333332F);
        escalar(g0, "casco_bajo_ladod_123", 0.777500000000003F, 1.0F, 0.7808333333333336F);
        escalar(g0, "casco_bajo_ladod_124", 0.5725000000000002F, 1.0F, 0.7283333333333334F);
        escalar(g0, "casco_bajo_ladod_125", 0.367499999999997F, 1.0F, 0.6908333333333331F);
        escalar(g0, "casco_bajo_ladod_126", 0.35999999999999716F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_127", 0.56F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_128", 0.7600000000000029F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_129", 0.9599999999999986F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_130", 0.5800000000000007F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_131", 0.6799999999999986F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_132", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_133", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_134", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_135", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_136", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_137", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_138", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_139", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_140", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_141", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_142", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_143", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_144", 1.0149999999999981F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_145", 1.0150000000000017F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_146", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_147", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_148", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_149", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_150", 1.015F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_151", 0.6799999999999986F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_152", 0.5800000000000043F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_153", 0.9599999999999915F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_154", 0.7600000000000029F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_155", 0.56F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_156", 0.35999999999999716F, 1.0F, 0.45018064403225827F);
        escalar(g0, "casco_bajo_ladod_157", 0.35999999999999716F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_158", 0.56F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_159", 0.7600000000000029F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_160", 0.9599999999999986F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_161", 0.5800000000000007F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_162", 0.6799999999999986F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_163", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_164", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_165", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_166", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_167", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_168", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_169", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_170", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_171", 1.015F, 1.0F, 0.45018064403225344F);
    }

    private static void escalas5(ModelPart g0) {
        escalar(g0, "casco_bajo_ladod_172", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_173", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_174", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_175", 1.0149999999999981F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_176", 1.0150000000000017F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_177", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_178", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_179", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_180", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_181", 1.015F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_182", 0.6799999999999986F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_183", 0.5800000000000043F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_184", 0.9599999999999915F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_185", 0.7600000000000029F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_186", 0.56F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_187", 0.35999999999999716F, 1.0F, 0.45018064403225344F);
        escalar(g0, "casco_bajo_ladod_188", 0.35999999999999716F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_189", 0.56F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_190", 0.7600000000000029F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_191", 0.9599999999999986F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_192", 0.5800000000000007F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_193", 0.6799999999999986F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_194", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_195", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_196", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_197", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_198", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_199", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_200", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_201", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_202", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_203", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_204", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_205", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_206", 1.0149999999999981F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_207", 1.0150000000000017F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_208", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_209", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_210", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_211", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_212", 1.015F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_213", 0.6799999999999986F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_214", 0.5800000000000043F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_215", 0.9599999999999915F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_216", 0.7600000000000029F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_217", 0.56F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_218", 0.35999999999999716F, 1.0F, 0.4501806440322574F);
        escalar(g0, "casco_bajo_ladod_219", 0.35999999999999716F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_220", 0.56F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_221", 0.7600000000000029F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_222", 0.9599999999999986F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_223", 0.5800000000000007F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_224", 0.6799999999999986F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_225", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_226", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_227", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_228", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_229", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_230", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_231", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_232", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_233", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_234", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_235", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_236", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_237", 1.0149999999999981F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_238", 1.0150000000000017F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_239", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_240", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_241", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_242", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_243", 1.015F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_244", 0.6799999999999986F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_245", 0.5800000000000043F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_246", 0.9599999999999915F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_247", 0.7600000000000029F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_248", 0.56F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_ladod_249", 0.35999999999999716F, 1.0F, 0.4501806440322565F);
        escalar(g0, "casco_bajo_arriba0_0", 0.35999999999999716F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_1", 0.56F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_2", 0.7600000000000029F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_3", 0.9599999999999986F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_4", 0.5800000000000007F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_5", 0.6799999999999986F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_6", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_7", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_8", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_9", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_10", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_11", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_12", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_13", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_14", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_15", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_16", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_17", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_18", 1.0149999999999981F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_19", 1.0150000000000017F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_20", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_21", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_22", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_23", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_24", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_25", 0.6799999999999986F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_26", 0.5800000000000043F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_27", 0.9599999999999915F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_28", 0.7600000000000029F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_29", 0.56F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_30", 0.35999999999999716F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_31", 0.35999999999999716F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_32", 0.56F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_33", 0.7600000000000029F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_34", 0.9599999999999986F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_35", 0.5800000000000007F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_36", 0.6799999999999986F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_37", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_38", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_39", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_40", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_41", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_42", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_43", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_44", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_45", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_46", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_47", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_48", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_49", 1.0149999999999981F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_50", 1.0150000000000017F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_51", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_52", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_53", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_54", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_55", 1.015F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_56", 0.6799999999999986F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_57", 0.5800000000000043F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_58", 0.9599999999999915F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_59", 0.7600000000000029F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_60", 0.56F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_61", 0.35999999999999716F, 1.0F, 0.9733333333333333F);
        escalar(g0, "casco_bajo_arriba0_62", 0.35999999999999716F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_63", 0.56F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_64", 0.7600000000000029F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_65", 0.9599999999999986F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_66", 0.5800000000000007F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_67", 0.6799999999999986F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_68", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_69", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_70", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_71", 1.015F, 1.0F, 0.9733333333333335F);
    }

    private static void escalas6(ModelPart g0) {
        escalar(g0, "casco_bajo_arriba0_72", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_73", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_74", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_75", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_76", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_77", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_78", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_79", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_80", 1.0149999999999981F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_81", 1.0150000000000017F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_82", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_83", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_84", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_85", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_86", 1.015F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_87", 0.6799999999999986F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_88", 0.5800000000000043F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_89", 0.9599999999999915F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_90", 0.7600000000000029F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_91", 0.56F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_92", 0.35999999999999716F, 1.0F, 0.9733333333333335F);
        escalar(g0, "casco_bajo_arriba0_93", 0.35999999999999716F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_94", 0.56F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_95", 0.7600000000000029F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_96", 0.9599999999999986F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_97", 0.5800000000000007F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_98", 0.6799999999999986F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_99", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_100", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_101", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_102", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_103", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_104", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_105", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_106", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_107", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_108", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_109", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_110", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_111", 1.0149999999999981F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_112", 1.0150000000000017F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_113", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_114", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_115", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_116", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_117", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_118", 0.6799999999999986F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_119", 0.5800000000000043F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_120", 0.9599999999999915F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_121", 0.7600000000000029F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_122", 0.56F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_123", 0.35999999999999716F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_124", 0.35999999999999716F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_125", 0.56F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_126", 0.7600000000000029F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_127", 0.9599999999999986F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_128", 0.5800000000000007F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_129", 0.6799999999999986F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_130", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_131", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_132", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_133", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_134", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_135", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_136", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_137", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_138", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_139", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_140", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_141", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_142", 1.0149999999999981F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_143", 1.0150000000000017F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_144", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_145", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_146", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_147", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_148", 1.015F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_149", 0.6799999999999986F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_150", 0.5800000000000043F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_151", 0.9599999999999915F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_152", 0.7600000000000029F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_153", 0.56F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_154", 0.35999999999999716F, 1.0F, 0.973333333333333F);
        escalar(g0, "casco_bajo_arriba0_155", 0.35999999999999716F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_156", 0.56F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_157", 0.7600000000000029F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_158", 0.9599999999999986F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_159", 0.5800000000000007F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_160", 0.6799999999999986F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_161", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_162", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_163", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_164", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_165", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_166", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_167", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_168", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_169", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_170", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_171", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_172", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_173", 1.0149999999999981F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_174", 1.0150000000000017F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_175", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_176", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_177", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_178", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_179", 1.015F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_180", 0.6799999999999986F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_181", 0.5800000000000043F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_182", 0.9599999999999915F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_183", 0.7600000000000029F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_184", 0.56F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_arriba0_185", 0.35999999999999716F, 1.0F, 0.9733333333333339F);
        escalar(g0, "casco_bajo_trompa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "casco_bajo_cola", 1.0F, 0.5F, 0.5F);
        escalar(g0, "casco_ladoi_0", 0.5812113582708698F, 1.0F, 0.3057031249999986F);
        escalar(g0, "casco_ladoi_1", 0.6814316052292075F, 1.0F, 0.39203125F);
        escalar(g0, "casco_ladoi_2", 0.8179384239283187F, 1.0F, 0.8803125F);
        escalar(g0, "casco_ladoi_3", 0.8190248214894013F, 1.0F, 0.70578125F);
        escalar(g0, "casco_ladoi_4", 0.7715857701463137F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_5", 1.06F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_6", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_7", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_8", 1.0150000000000008F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_9", 1.014999999999999F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_10", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_11", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_12", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_13", 1.0149999999999981F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_14", 1.0150000000000017F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_15", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_16", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_17", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_18", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_19", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_20", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_21", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_22", 0.8169231233899925F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_23", 0.6840000377543677F, 1.0F, 0.6827777777777786F);
        escalar(g0, "casco_ladoi_24", 0.5833846473306242F, 1.0F, 0.6105555555555557F);
        escalar(g0, "casco_ladoi_25", 0.9655385138137329F, 1.0F, 0.549444444444444F);
        escalar(g0, "casco_ladoi_26", 0.7643077329662464F, 1.0F, 0.99888888888889F);
        escalar(g0, "casco_ladoi_27", 0.5630769521187451F, 1.0F, 0.9211111111111108F);
        escalar(g0, "casco_ladoi_28", 0.3618461712712446F, 1.0F, 0.8655555555555572F);
        escalar(g0, "casco_ladoi_29", 0.5848295647739642F, 1.0F, 0.30570312500000213F);
        escalar(g0, "casco_ladoi_30", 0.6857076674601371F, 1.0F, 0.39203125F);
        escalar(g0, "casco_ladoi_31", 0.8354967957777675F, 1.0F, 0.8803125F);
        escalar(g0, "casco_ladoi_32", 0.8397416565571652F, 1.0F, 0.70578125F);
        escalar(g0, "casco_ladoi_33", 0.7910078030223424F, 1.0F, 0.905F);
    }

    private static void escalas7(ModelPart g0) {
        escalar(g0, "casco_ladoi_34", 1.06F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_35", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_36", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_37", 1.0150000000000008F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_38", 1.014999999999999F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_39", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_40", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_41", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_42", 1.0149999999999981F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_43", 1.0150000000000017F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_44", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_45", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_46", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_47", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_48", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_49", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_50", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_51", 0.8315150628704788F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_52", 0.6958559885822626F, 1.0F, 0.6827777777777768F);
        escalar(g0, "casco_ladoi_53", 0.5934166057234588F, 1.0F, 0.6105555555555557F);
        escalar(g0, "casco_ladoi_54", 0.9819544457292795F, 1.0F, 0.549444444444444F);
        escalar(g0, "casco_ladoi_55", 0.7770756800116725F, 1.0F, 0.99888888888889F);
        escalar(g0, "casco_ladoi_56", 0.5721969142940493F, 1.0F, 0.9211111111111108F);
        escalar(g0, "casco_ladoi_57", 0.36731814857642675F, 1.0F, 0.8655555555555536F);
        escalar(g0, "casco_ladoi_58", 0.5908080361240811F, 1.0F, 0.30570312500000213F);
        escalar(g0, "casco_ladoi_59", 0.6927731336011841F, 1.0F, 0.39203125F);
        escalar(g0, "casco_ladoi_60", 0.8639569757191747F, 1.0F, 0.8803125F);
        escalar(g0, "casco_ladoi_61", 0.8731629128684071F, 1.0F, 0.70578125F);
        escalar(g0, "casco_ladoi_62", 0.8223402308141318F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_63", 1.06F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_64", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_65", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_66", 1.0150000000000008F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_67", 1.014999999999999F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_68", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_69", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_70", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_71", 1.0149999999999981F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_72", 1.0150000000000017F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_73", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_74", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_75", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_76", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_77", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_78", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_79", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_80", 0.8552740427115679F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_81", 0.7151601597031471F, 1.0F, 0.6827777777777768F);
        escalar(g0, "casco_ladoi_82", 0.6097509043642076F, 1.0F, 0.6105555555555557F);
        escalar(g0, "casco_ladoi_83", 1.0086832980505047F, 1.0F, 0.549444444444444F);
        escalar(g0, "casco_ladoi_84", 0.7978647873726248F, 1.0F, 0.9988888888888865F);
        escalar(g0, "casco_ladoi_85", 0.5870462766947302F, 1.0F, 0.9211111111111108F);
        escalar(g0, "casco_ladoi_86", 0.37622776601683455F, 1.0F, 0.8655555555555536F);
        escalar(g0, "casco_ladoi_87", 0.5990723888830518F, 1.0F, 0.3057031249999986F);
        escalar(g0, "casco_ladoi_88", 0.7025400959526952F, 1.0F, 0.39203125F);
        escalar(g0, "casco_ladoi_89", 0.9022740536626909F, 1.0F, 0.8803125F);
        escalar(g0, "casco_ladoi_90", 0.9178835465996718F, 1.0F, 0.70578125F);
        escalar(g0, "casco_ladoi_91", 0.8642658249371925F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_92", 1.06F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_93", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_94", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_95", 1.0150000000000008F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_96", 1.014999999999999F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_97", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_98", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_99", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_100", 1.0149999999999981F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_101", 1.0150000000000017F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_102", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_103", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_104", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_105", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_106", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_107", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_108", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_109", 0.8874540268263204F, 1.0F, 0.905F);
        escalar(g0, "casco_ladoi_110", 0.7413063967963837F, 1.0F, 0.6827777777777786F);
        escalar(g0, "casco_ladoi_111", 0.6318746434431003F, 1.0F, 0.6105555555555557F);
        escalar(g0, "casco_ladoi_112", 1.0448857801796005F, 1.0F, 0.549444444444444F);
        escalar(g0, "casco_ladoi_113", 0.826022273473034F, 1.0F, 0.99888888888889F);
        escalar(g0, "casco_ladoi_114", 0.60715876676645F, 1.0F, 0.9211111111111108F);
        escalar(g0, "casco_ladoi_115", 0.38829526005986736F, 1.0F, 0.8655555555555572F);
        escalar(g0, "casco_ladoi_116", 1.0189541027342064F, 1.0F, 0.3294685072847771F);
        escalar(g0, "casco_ladoi_117", 0.6160275072264613F, 1.0F, 0.44347441421295236F);
        escalar(g0, "casco_ladoi_118", 0.7225779630858153F, 1.0F, 0.5782086678553413F);
        escalar(g0, "casco_ladoi_119", 0.9081277407030652F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_120", 0.9178835465996718F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_121", 0.8642658249371925F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_122", 1.06F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_123", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_124", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_125", 1.0150000000000008F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_126", 1.014999999999999F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_127", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_128", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_129", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_130", 1.0149999999999981F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_131", 1.0150000000000017F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_132", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_133", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_134", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_135", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_136", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_137", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_138", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_139", 0.8874540268263204F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_140", 0.7413063967963837F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_141", 0.6318746434431003F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_142", 1.0448857801796005F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_143", 0.826022273473034F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_144", 0.60715876676645F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_145", 0.38829526005986736F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_146", 1.0506829143165561F, 1.0F, 0.3294685072847783F);
        escalar(g0, "casco_ladoi_147", 0.6354173365267871F, 1.0F, 0.4434744142129537F);
        escalar(g0, "casco_ladoi_148", 0.7454932158952903F, 1.0F, 0.57820866785534F);
        escalar(g0, "casco_ladoi_149", 0.9132600977200436F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_150", 0.9178835465996718F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_151", 0.8642658249371925F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_152", 1.06F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_153", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_154", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_155", 1.0150000000000008F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_156", 1.014999999999999F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_157", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_158", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_159", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_160", 1.0149999999999981F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_161", 1.0150000000000017F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_162", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_163", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_164", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_165", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_166", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_167", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_168", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_169", 0.8874540268263204F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_170", 0.7413063967963837F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_171", 0.6318746434431003F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_172", 1.0448857801796005F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_173", 0.826022273473034F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_174", 0.60715876676645F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_175", 0.38829526005986736F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_176", 0.5407133007585393F, 1.0F, 0.3294685072847783F);
        escalar(g0, "casco_ladoi_177", 0.6542051453715492F, 1.0F, 0.4434744142129537F);
        escalar(g0, "casco_ladoi_178", 0.767696989984555F, 1.0F, 0.57820866785534F);
        escalar(g0, "casco_ladoi_179", 0.9169077307707825F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_180", 0.9178835465996718F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_181", 0.8642658249371925F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_182", 1.06F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_183", 1.015F, 1.0F, 0.6452709660483855F);
    }

    private static void escalas8(ModelPart g0) {
        escalar(g0, "casco_ladoi_184", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_185", 1.0150000000000008F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_186", 1.014999999999999F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_187", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_188", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_189", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_190", 1.0149999999999981F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_191", 1.0150000000000017F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_192", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_193", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_194", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_195", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_196", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_197", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_198", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_199", 0.8874540268263204F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_200", 0.7413063967963837F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_201", 0.6318746434431003F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_202", 1.0448857801796005F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_203", 0.826022273473034F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_204", 0.60715876676645F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_205", 0.38829526005986736F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladoi_206", 0.5533914392047423F, 1.0F, 0.3294685072847771F);
        escalar(g0, "casco_ladoi_207", 0.6697006479169095F, 1.0F, 0.4434744142129523F);
        escalar(g0, "casco_ladoi_208", 0.7860098566290716F, 1.0F, 0.5782086678553413F);
        escalar(g0, "casco_ladoi_209", 0.9185355153688132F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_210", 0.9178835465996718F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_211", 0.8642658249371925F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_212", 1.06F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_213", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_214", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_215", 1.0150000000000008F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_216", 1.014999999999999F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_217", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_218", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_219", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_220", 1.0149999999999981F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_221", 1.0150000000000017F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_222", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_223", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_224", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_225", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_226", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_227", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_228", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_229", 0.8874540268263204F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_230", 0.7413063967963837F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_231", 0.6318746434431003F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_232", 1.0448857801796005F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_233", 0.826022273473034F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_234", 0.60715876676645F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladoi_235", 0.38829526005986736F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_0", 0.5812113582708698F, 1.0F, 0.3057031249999986F);
        escalar(g0, "casco_ladod_1", 0.6814316052292075F, 1.0F, 0.39203125F);
        escalar(g0, "casco_ladod_2", 0.8179384239283187F, 1.0F, 0.8803125F);
        escalar(g0, "casco_ladod_3", 0.8190248214894013F, 1.0F, 0.70578125F);
        escalar(g0, "casco_ladod_4", 0.7715857701463137F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_5", 1.06F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_6", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_7", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_8", 1.0150000000000008F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_9", 1.014999999999999F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_10", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_11", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_12", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_13", 1.0149999999999981F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_14", 1.0150000000000017F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_15", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_16", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_17", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_18", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_19", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_20", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_21", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_22", 0.8169231233899925F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_23", 0.6840000377543677F, 1.0F, 0.6827777777777786F);
        escalar(g0, "casco_ladod_24", 0.5833846473306242F, 1.0F, 0.6105555555555557F);
        escalar(g0, "casco_ladod_25", 0.9655385138137329F, 1.0F, 0.549444444444444F);
        escalar(g0, "casco_ladod_26", 0.7643077329662464F, 1.0F, 0.99888888888889F);
        escalar(g0, "casco_ladod_27", 0.5630769521187451F, 1.0F, 0.9211111111111108F);
        escalar(g0, "casco_ladod_28", 0.3618461712712446F, 1.0F, 0.8655555555555572F);
        escalar(g0, "casco_ladod_29", 0.5848295647739642F, 1.0F, 0.30570312500000213F);
        escalar(g0, "casco_ladod_30", 0.6857076674601371F, 1.0F, 0.39203125F);
        escalar(g0, "casco_ladod_31", 0.8354967957777675F, 1.0F, 0.8803125F);
        escalar(g0, "casco_ladod_32", 0.8397416565571652F, 1.0F, 0.70578125F);
        escalar(g0, "casco_ladod_33", 0.7910078030223424F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_34", 1.06F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_35", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_36", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_37", 1.0150000000000008F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_38", 1.014999999999999F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_39", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_40", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_41", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_42", 1.0149999999999981F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_43", 1.0150000000000017F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_44", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_45", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_46", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_47", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_48", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_49", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_50", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_51", 0.8315150628704788F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_52", 0.6958559885822626F, 1.0F, 0.6827777777777768F);
        escalar(g0, "casco_ladod_53", 0.5934166057234588F, 1.0F, 0.6105555555555557F);
        escalar(g0, "casco_ladod_54", 0.9819544457292795F, 1.0F, 0.549444444444444F);
        escalar(g0, "casco_ladod_55", 0.7770756800116725F, 1.0F, 0.99888888888889F);
        escalar(g0, "casco_ladod_56", 0.5721969142940493F, 1.0F, 0.9211111111111108F);
        escalar(g0, "casco_ladod_57", 0.36731814857642675F, 1.0F, 0.8655555555555536F);
        escalar(g0, "casco_ladod_58", 0.5908080361240811F, 1.0F, 0.30570312500000213F);
        escalar(g0, "casco_ladod_59", 0.6927731336011841F, 1.0F, 0.39203125F);
        escalar(g0, "casco_ladod_60", 0.8639569757191747F, 1.0F, 0.8803125F);
        escalar(g0, "casco_ladod_61", 0.8731629128684071F, 1.0F, 0.70578125F);
        escalar(g0, "casco_ladod_62", 0.8223402308141318F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_63", 1.06F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_64", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_65", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_66", 1.0150000000000008F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_67", 1.014999999999999F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_68", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_69", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_70", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_71", 1.0149999999999981F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_72", 1.0150000000000017F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_73", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_74", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_75", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_76", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_77", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_78", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_79", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_80", 0.8552740427115679F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_81", 0.7151601597031471F, 1.0F, 0.6827777777777768F);
        escalar(g0, "casco_ladod_82", 0.6097509043642076F, 1.0F, 0.6105555555555557F);
        escalar(g0, "casco_ladod_83", 1.0086832980505047F, 1.0F, 0.549444444444444F);
        escalar(g0, "casco_ladod_84", 0.7978647873726248F, 1.0F, 0.9988888888888865F);
        escalar(g0, "casco_ladod_85", 0.5870462766947302F, 1.0F, 0.9211111111111108F);
        escalar(g0, "casco_ladod_86", 0.37622776601683455F, 1.0F, 0.8655555555555536F);
        escalar(g0, "casco_ladod_87", 0.5990723888830518F, 1.0F, 0.3057031249999986F);
        escalar(g0, "casco_ladod_88", 0.7025400959526952F, 1.0F, 0.39203125F);
        escalar(g0, "casco_ladod_89", 0.9022740536626909F, 1.0F, 0.8803125F);
        escalar(g0, "casco_ladod_90", 0.9178835465996718F, 1.0F, 0.70578125F);
        escalar(g0, "casco_ladod_91", 0.8642658249371925F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_92", 1.06F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_93", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_94", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_95", 1.0150000000000008F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_96", 1.014999999999999F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_97", 1.015F, 1.0F, 0.905F);
    }

    private static void escalas9(ModelPart g0) {
        escalar(g0, "casco_ladod_98", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_99", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_100", 1.0149999999999981F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_101", 1.0150000000000017F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_102", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_103", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_104", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_105", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_106", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_107", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_108", 1.015F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_109", 0.8874540268263204F, 1.0F, 0.905F);
        escalar(g0, "casco_ladod_110", 0.7413063967963837F, 1.0F, 0.6827777777777786F);
        escalar(g0, "casco_ladod_111", 0.6318746434431003F, 1.0F, 0.6105555555555557F);
        escalar(g0, "casco_ladod_112", 1.0448857801796005F, 1.0F, 0.549444444444444F);
        escalar(g0, "casco_ladod_113", 0.826022273473034F, 1.0F, 0.99888888888889F);
        escalar(g0, "casco_ladod_114", 0.60715876676645F, 1.0F, 0.9211111111111108F);
        escalar(g0, "casco_ladod_115", 0.38829526005986736F, 1.0F, 0.8655555555555572F);
        escalar(g0, "casco_ladod_116", 1.0189541027342064F, 1.0F, 0.3294685072847771F);
        escalar(g0, "casco_ladod_117", 0.6160275072264613F, 1.0F, 0.44347441421295236F);
        escalar(g0, "casco_ladod_118", 0.7225779630858153F, 1.0F, 0.5782086678553413F);
        escalar(g0, "casco_ladod_119", 0.9081277407030652F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_120", 0.9178835465996718F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_121", 0.8642658249371925F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_122", 1.06F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_123", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_124", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_125", 1.0150000000000008F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_126", 1.014999999999999F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_127", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_128", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_129", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_130", 1.0149999999999981F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_131", 1.0150000000000017F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_132", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_133", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_134", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_135", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_136", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_137", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_138", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_139", 0.8874540268263204F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_140", 0.7413063967963837F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_141", 0.6318746434431003F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_142", 1.0448857801796005F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_143", 0.826022273473034F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_144", 0.60715876676645F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_145", 0.38829526005986736F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_146", 1.0506829143165561F, 1.0F, 0.3294685072847783F);
        escalar(g0, "casco_ladod_147", 0.6354173365267871F, 1.0F, 0.4434744142129537F);
        escalar(g0, "casco_ladod_148", 0.7454932158952903F, 1.0F, 0.57820866785534F);
        escalar(g0, "casco_ladod_149", 0.9132600977200436F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_150", 0.9178835465996718F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_151", 0.8642658249371925F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_152", 1.06F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_153", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_154", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_155", 1.0150000000000008F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_156", 1.014999999999999F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_157", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_158", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_159", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_160", 1.0149999999999981F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_161", 1.0150000000000017F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_162", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_163", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_164", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_165", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_166", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_167", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_168", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_169", 0.8874540268263204F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_170", 0.7413063967963837F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_171", 0.6318746434431003F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_172", 1.0448857801796005F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_173", 0.826022273473034F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_174", 0.60715876676645F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_175", 0.38829526005986736F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_176", 0.5407133007585393F, 1.0F, 0.3294685072847783F);
        escalar(g0, "casco_ladod_177", 0.6542051453715492F, 1.0F, 0.4434744142129537F);
        escalar(g0, "casco_ladod_178", 0.767696989984555F, 1.0F, 0.57820866785534F);
        escalar(g0, "casco_ladod_179", 0.9169077307707825F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_180", 0.9178835465996718F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_181", 0.8642658249371925F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_182", 1.06F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_183", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_184", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_185", 1.0150000000000008F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_186", 1.014999999999999F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_187", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_188", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_189", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_190", 1.0149999999999981F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_191", 1.0150000000000017F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_192", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_193", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_194", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_195", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_196", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_197", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_198", 1.015F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_199", 0.8874540268263204F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_200", 0.7413063967963837F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_201", 0.6318746434431003F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_202", 1.0448857801796005F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_203", 0.826022273473034F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_204", 0.60715876676645F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_205", 0.38829526005986736F, 1.0F, 0.6452709660483855F);
        escalar(g0, "casco_ladod_206", 0.5533914392047423F, 1.0F, 0.3294685072847771F);
        escalar(g0, "casco_ladod_207", 0.6697006479169095F, 1.0F, 0.4434744142129523F);
        escalar(g0, "casco_ladod_208", 0.7860098566290716F, 1.0F, 0.5782086678553413F);
        escalar(g0, "casco_ladod_209", 0.9185355153688132F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_210", 0.9178835465996718F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_211", 0.8642658249371925F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_212", 1.06F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_213", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_214", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_215", 1.0150000000000008F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_216", 1.014999999999999F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_217", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_218", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_219", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_220", 1.0149999999999981F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_221", 1.0150000000000017F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_222", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_223", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_224", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_225", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_226", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_227", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_228", 1.015F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_229", 0.8874540268263204F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_230", 0.7413063967963837F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_231", 0.6318746434431003F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_232", 1.0448857801796005F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_233", 0.826022273473034F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_234", 0.60715876676645F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_ladod_235", 0.38829526005986736F, 1.0F, 0.645270966048384F);
        escalar(g0, "casco_arriba0_0", 0.4089276261364915F, 1.0F, 0.9219531249999998F);
        escalar(g0, "casco_arriba0_1", 0.6415460435608258F, 1.0F, 0.9186328125F);
        escalar(g0, "casco_arriba0_2", 0.8741644609851602F, 1.0F, 0.9130989583333332F);
        escalar(g0, "casco_arriba0_3", 0.5533914392047423F, 1.0F, 0.9053515624999998F);
        escalar(g0, "casco_arriba0_4", 0.6697006479169095F, 1.0F, 0.8953906249999998F);
        escalar(g0, "casco_arriba0_5", 0.7860098566290716F, 1.0F, 0.8832161458333331F);
        escalar(g0, "casco_arriba0_6", 0.9185355153688132F, 1.0F, 0.9929464285714286F);
        escalar(g0, "casco_arriba0_7", 0.9178835465996718F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_8", 0.8642658249371925F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_9", 1.06F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_10", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_11", 1.015F, 1.0F, 0.9847619047619045F);
    }

    private static void escalas10(ModelPart g0) {
        escalar(g0, "casco_arriba0_12", 1.0150000000000008F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_13", 1.014999999999999F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_14", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_15", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_16", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_17", 1.0149999999999981F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_18", 1.0150000000000017F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_19", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_20", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_21", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_22", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_23", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_24", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_25", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_26", 0.8874540268263204F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_27", 0.7413063967963837F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_28", 0.6318746434431003F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_29", 1.0448857801796005F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_30", 0.826022273473034F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_31", 0.60715876676645F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_32", 0.38829526005986736F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_33", 0.4038352167099777F, 1.0F, 0.9219531249999998F);
        escalar(g0, "casco_arriba0_34", 0.6330586945166359F, 1.0F, 0.9186328125F);
        escalar(g0, "casco_arriba0_35", 0.8622821723232943F, 1.0F, 0.9130989583333332F);
        escalar(g0, "casco_arriba0_36", 0.5457528250649714F, 1.0F, 0.9053515624999998F);
        escalar(g0, "casco_arriba0_37", 0.6603645639683006F, 1.0F, 0.895390625F);
        escalar(g0, "casco_arriba0_38", 0.774976302871625F, 1.0F, 0.8832161458333333F);
        escalar(g0, "casco_arriba0_39", 0.9181733684075641F, 1.0F, 0.9929464285714286F);
        escalar(g0, "casco_arriba0_40", 0.9178835465996718F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_41", 0.8642658249371925F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_42", 1.06F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_43", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_44", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_45", 1.0150000000000008F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_46", 1.014999999999999F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_47", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_48", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_49", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_50", 1.0149999999999981F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_51", 1.0150000000000017F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_52", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_53", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_54", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_55", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_56", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_57", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_58", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_59", 0.8874540268263204F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_60", 0.7413063967963837F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_61", 0.6318746434431003F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_62", 1.0448857801796005F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_63", 0.826022273473034F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_64", 0.60715876676645F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_65", 0.38829526005986736F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_66", 0.40074324209182405F, 1.0F, 0.921953125F);
        escalar(g0, "casco_arriba0_67", 0.6279054034863796F, 1.0F, 0.9186328125F);
        escalar(g0, "casco_arriba0_68", 0.8550675648809356F, 1.0F, 0.9130989583333334F);
        escalar(g0, "casco_arriba0_69", 0.5411148631377408F, 1.0F, 0.9053515625F);
        escalar(g0, "casco_arriba0_70", 0.6546959438350187F, 1.0F, 0.895390625F);
        escalar(g0, "casco_arriba0_71", 0.7682770245322917F, 1.0F, 0.8832161458333333F);
        escalar(g0, "casco_arriba0_72", 0.9179560107437764F, 1.0F, 0.9929464285714286F);
        escalar(g0, "casco_arriba0_73", 0.9178835465996718F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_74", 0.8642658249371925F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_75", 1.06F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_76", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_77", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_78", 1.0150000000000008F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_79", 1.014999999999999F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_80", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_81", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_82", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_83", 1.0149999999999981F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_84", 1.0150000000000017F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_85", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_86", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_87", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_88", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_89", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_90", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_91", 1.015F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_92", 0.8874540268263204F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_93", 0.7413063967963837F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_94", 0.6318746434431003F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_95", 1.0448857801796005F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_96", 0.826022273473034F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_97", 0.60715876676645F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_98", 0.38829526005986736F, 1.0F, 0.9847619047619048F);
        escalar(g0, "casco_arriba0_99", 0.40074324209182377F, 1.0F, 0.9219531249999996F);
        escalar(g0, "casco_arriba0_100", 0.62790540348638F, 1.0F, 0.9186328125F);
        escalar(g0, "casco_arriba0_101", 0.8550675648809356F, 1.0F, 0.913098958333333F);
        escalar(g0, "casco_arriba0_102", 0.5411148631377408F, 1.0F, 0.9053515624999996F);
        escalar(g0, "casco_arriba0_103", 0.6546959438350187F, 1.0F, 0.8953906249999998F);
        escalar(g0, "casco_arriba0_104", 0.7682770245322916F, 1.0F, 0.8832161458333331F);
        escalar(g0, "casco_arriba0_105", 0.9179560107437764F, 1.0F, 0.9929464285714286F);
        escalar(g0, "casco_arriba0_106", 0.9178835465996718F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_107", 0.8642658249371925F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_108", 1.06F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_109", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_110", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_111", 1.0150000000000008F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_112", 1.014999999999999F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_113", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_114", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_115", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_116", 1.0149999999999981F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_117", 1.0150000000000017F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_118", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_119", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_120", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_121", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_122", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_123", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_124", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_125", 0.8874540268263204F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_126", 0.7413063967963837F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_127", 0.6318746434431003F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_128", 1.0448857801796005F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_129", 0.826022273473034F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_130", 0.60715876676645F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_131", 0.38829526005986736F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_132", 0.4038352167099769F, 1.0F, 0.9219531249999996F);
        escalar(g0, "casco_arriba0_133", 0.6330586945166368F, 1.0F, 0.9186328125F);
        escalar(g0, "casco_arriba0_134", 0.8622821723232943F, 1.0F, 0.913098958333333F);
        escalar(g0, "casco_arriba0_135", 0.5457528250649715F, 1.0F, 0.9053515624999996F);
        escalar(g0, "casco_arriba0_136", 0.6603645639683003F, 1.0F, 0.8953906249999993F);
        escalar(g0, "casco_arriba0_137", 0.7749763028716247F, 1.0F, 0.8832161458333331F);
        escalar(g0, "casco_arriba0_138", 0.9181733684075641F, 1.0F, 0.9929464285714286F);
        escalar(g0, "casco_arriba0_139", 0.9178835465996718F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_140", 0.8642658249371925F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_141", 1.06F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_142", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_143", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_144", 1.0150000000000008F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_145", 1.014999999999999F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_146", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_147", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_148", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_149", 1.0149999999999981F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_150", 1.0150000000000017F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_151", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_152", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_153", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_154", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_155", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_156", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_157", 1.015F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_158", 0.8874540268263204F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_159", 0.7413063967963837F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_160", 0.6318746434431003F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_161", 1.0448857801796005F, 1.0F, 0.9847619047619045F);
    }

    private static void escalas11(ModelPart g0) {
        escalar(g0, "casco_arriba0_162", 0.826022273473034F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_163", 0.60715876676645F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_164", 0.38829526005986736F, 1.0F, 0.9847619047619045F);
        escalar(g0, "casco_arriba0_165", 0.4089276261364915F, 1.0F, 0.9219531250000005F);
        escalar(g0, "casco_arriba0_166", 0.6415460435608258F, 1.0F, 0.9186328125F);
        escalar(g0, "casco_arriba0_167", 0.8741644609851602F, 1.0F, 0.9130989583333339F);
        escalar(g0, "casco_arriba0_168", 0.5533914392047423F, 1.0F, 0.9053515625000005F);
        escalar(g0, "casco_arriba0_169", 0.6697006479169095F, 1.0F, 0.8953906250000007F);
        escalar(g0, "casco_arriba0_170", 0.7860098566290716F, 1.0F, 0.8832161458333335F);
        escalar(g0, "casco_arriba0_171", 0.9185355153688132F, 1.0F, 0.9929464285714286F);
        escalar(g0, "casco_arriba0_172", 0.9178835465996718F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_173", 0.8642658249371925F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_174", 1.06F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_175", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_176", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_177", 1.0150000000000008F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_178", 1.014999999999999F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_179", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_180", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_181", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_182", 1.0149999999999981F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_183", 1.0150000000000017F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_184", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_185", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_186", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_187", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_188", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_189", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_190", 1.015F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_191", 0.8874540268263204F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_192", 0.7413063967963837F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_193", 0.6318746434431003F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_194", 1.0448857801796005F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_195", 0.826022273473034F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_196", 0.60715876676645F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_arriba0_197", 0.38829526005986736F, 1.0F, 0.9847619047619051F);
        escalar(g0, "casco_trompa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "casco_cola", 1.0F, 0.5F, 0.5F);
        escalar(g0, "tapa_conductor", 0.25F, 0.8F, 0.25F);
        escalar(g0, "torreta_ladoi_0", 0.4550844341491268F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_1", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_2", 0.8439061911452496F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_3", 0.8765746157029444F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_4", 0.908495557477184F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_5", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_6", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_7", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_8", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_9", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_10", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_11", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_12", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_13", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_14", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_15", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_16", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_17", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_18", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_19", 0.9084955574771825F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_20", 0.8765746157029412F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_21", 0.8439061911452543F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_22", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_23", 0.4550844341491241F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_24", 0.4550844341491268F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_25", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_26", 0.8439061911452496F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_27", 0.8765746157029444F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_28", 0.908495557477184F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_29", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_30", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_31", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_32", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_33", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_34", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_35", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_36", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_37", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_38", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_39", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_40", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_41", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_42", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_43", 0.9084955574771825F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_44", 0.8765746157029412F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_45", 0.8439061911452543F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_46", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_47", 0.4550844341491241F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_48", 0.4550844341491268F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_49", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_50", 0.8439061911452496F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_51", 0.8765746157029444F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_52", 0.908495557477184F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_53", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_54", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_55", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_56", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_57", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_58", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_59", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_60", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_61", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_62", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_63", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_64", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_65", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_66", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_67", 0.9084955574771825F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_68", 0.8765746157029412F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_69", 0.8439061911452543F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_70", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_71", 0.4550844341491241F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_72", 0.4550844341491268F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_73", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_74", 0.8439061911452496F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_75", 0.8765746157029444F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_76", 0.908495557477184F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_77", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_78", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_79", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_80", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_81", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_82", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_83", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_84", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_85", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_86", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_87", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_88", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_89", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_90", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_91", 0.9084955574771825F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_92", 0.8765746157029412F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_93", 0.8439061911452543F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_94", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_95", 0.4550844341491241F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladoi_96", 0.4550844341491268F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_97", 0.8004612878381379F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_98", 0.8439061911452496F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_99", 0.8765746157029444F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_100", 0.908495557477184F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_101", 0.9430396277111741F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_102", 0.8544167879166383F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_103", 0.7816434852307729F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_104", 0.737946306953967F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_105", 0.7109037911000352F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_106", 0.6949871816059489F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_107", 0.6875703006677837F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_108", 0.6875703006677837F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_109", 0.6949871816059489F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_110", 0.7109037911000352F, 1.0F, 0.6152709660483837F);
    }

    private static void escalas12(ModelPart g0) {
        escalar(g0, "torreta_ladoi_111", 0.737946306953967F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_112", 0.7816434852307729F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_113", 0.8544167879166383F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_114", 0.9430396277111741F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_115", 0.9084955574771825F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_116", 0.8765746157029412F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_117", 0.8439061911452543F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_118", 0.8004612878381379F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_119", 0.4550844341491241F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladoi_120", 0.4550844341491268F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladoi_121", 0.8004612878381379F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladoi_122", 0.8439061911452496F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladoi_123", 0.8765746157029444F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladoi_124", 0.908495557477184F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_125", 0.9430396277111741F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_126", 0.8544167879166383F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_127", 0.7816434852307729F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_128", 0.7379463069539671F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_129", 0.7109037911000352F, 1.0F, 0.6152709660483866F);
        escalar(g0, "torreta_ladoi_130", 0.6949871816059489F, 1.0F, 0.6152709660483866F);
        escalar(g0, "torreta_ladoi_131", 0.6875703006677837F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_132", 0.6875703006677837F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_133", 0.6949871816059489F, 1.0F, 0.6152709660483866F);
        escalar(g0, "torreta_ladoi_134", 0.7109037911000352F, 1.0F, 0.6152709660483866F);
        escalar(g0, "torreta_ladoi_135", 0.7379463069539671F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_136", 0.7816434852307729F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_137", 0.8544167879166383F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_138", 0.9430396277111741F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_139", 0.9084955574771825F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladoi_140", 0.8765746157029412F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladoi_141", 0.8439061911452543F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladoi_142", 0.8004612878381379F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladoi_143", 0.4550844341491241F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladoi_144", 0.4550844341491268F, 1.0F, 0.6152709660483835F);
        escalar(g0, "torreta_ladoi_145", 0.800461287838138F, 1.0F, 0.6152709660483835F);
        escalar(g0, "torreta_ladoi_146", 0.8439061911452496F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_147", 0.8765746157029444F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_148", 0.908495557477184F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_149", 0.9430396277111741F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_150", 0.8544167879166383F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_151", 0.7816434852307729F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_152", 0.7379463069539671F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladoi_153", 0.7109037911000352F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladoi_154", 0.6949871816059489F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladoi_155", 0.6875703006677837F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladoi_156", 0.6875703006677837F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladoi_157", 0.6949871816059489F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladoi_158", 0.7109037911000352F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladoi_159", 0.7379463069539671F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladoi_160", 0.7816434852307729F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_161", 0.8544167879166383F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_162", 0.9430396277111741F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_163", 0.9084955574771825F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_164", 0.8765746157029412F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_165", 0.8439061911452543F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladoi_166", 0.800461287838138F, 1.0F, 0.6152709660483835F);
        escalar(g0, "torreta_ladoi_167", 0.4550844341491241F, 1.0F, 0.6152709660483835F);
        escalar(g0, "torreta_ladoi_168", 0.4550844341491268F, 1.0F, 0.615270966048385F);
        escalar(g0, "torreta_ladoi_169", 0.800461287838138F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladoi_170", 0.8439061911452496F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladoi_171", 0.8765746157029444F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladoi_172", 0.908495557477184F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladoi_173", 0.9430396277111741F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladoi_174", 0.8544167879166383F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_175", 0.7816434852307729F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_176", 0.737946306953967F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_177", 0.7109037911000352F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_178", 0.6949871816059489F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_179", 0.6875703006677837F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_180", 0.6875703006677837F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_181", 0.6949871816059489F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_182", 0.7109037911000352F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_183", 0.737946306953967F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_184", 0.7816434852307729F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_185", 0.8544167879166383F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladoi_186", 0.9430396277111741F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladoi_187", 0.9084955574771825F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladoi_188", 0.8765746157029412F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladoi_189", 0.8439061911452543F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladoi_190", 0.800461287838138F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladoi_191", 0.45508443414912414F, 1.0F, 0.615270966048385F);
        escalar(g0, "torreta_ladod_0", 0.4550844341491268F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_1", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_2", 0.8439061911452496F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_3", 0.8765746157029444F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_4", 0.908495557477184F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_5", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_6", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_7", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_8", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_9", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_10", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_11", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_12", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_13", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_14", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_15", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_16", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_17", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_18", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_19", 0.9084955574771825F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_20", 0.8765746157029412F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_21", 0.8439061911452543F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_22", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_23", 0.4550844341491241F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_24", 0.4550844341491268F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_25", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_26", 0.8439061911452496F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_27", 0.8765746157029444F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_28", 0.908495557477184F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_29", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_30", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_31", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_32", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_33", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_34", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_35", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_36", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_37", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_38", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_39", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_40", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_41", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_42", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_43", 0.9084955574771825F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_44", 0.8765746157029412F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_45", 0.8439061911452543F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_46", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_47", 0.4550844341491241F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_48", 0.4550844341491268F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_49", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_50", 0.8439061911452496F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_51", 0.8765746157029444F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_52", 0.908495557477184F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_53", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_54", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_55", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_56", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_57", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_58", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_59", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_60", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_61", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_62", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_63", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_64", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_65", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_66", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_67", 0.9084955574771825F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_68", 0.8765746157029412F, 1.0F, 1.03F);
    }

    private static void escalas13(ModelPart g0) {
        escalar(g0, "torreta_ladod_69", 0.8439061911452543F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_70", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_71", 0.4550844341491241F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_72", 0.4550844341491268F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_73", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_74", 0.8439061911452496F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_75", 0.8765746157029444F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_76", 0.908495557477184F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_77", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_78", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_79", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_80", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_81", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_82", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_83", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_84", 0.6875703006677837F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_85", 0.6949871816059489F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_86", 0.7109037911000352F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_87", 0.737946306953967F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_88", 0.7816434852307729F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_89", 0.8544167879166383F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_90", 0.9430396277111741F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_91", 0.9084955574771825F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_92", 0.8765746157029412F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_93", 0.8439061911452543F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_94", 0.8004612878381379F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_95", 0.4550844341491241F, 1.0F, 1.03F);
        escalar(g0, "torreta_ladod_96", 0.4550844341491268F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_97", 0.8004612878381379F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_98", 0.8439061911452496F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_99", 0.8765746157029444F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_100", 0.908495557477184F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_101", 0.9430396277111741F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_102", 0.8544167879166383F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_103", 0.7816434852307729F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_104", 0.737946306953967F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_105", 0.7109037911000352F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_106", 0.6949871816059489F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_107", 0.6875703006677837F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_108", 0.6875703006677837F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_109", 0.6949871816059489F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_110", 0.7109037911000352F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_111", 0.737946306953967F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_112", 0.7816434852307729F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_113", 0.8544167879166383F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_114", 0.9430396277111741F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_115", 0.9084955574771825F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_116", 0.8765746157029412F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_117", 0.8439061911452543F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_118", 0.8004612878381379F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_119", 0.4550844341491241F, 1.0F, 0.6152709660483837F);
        escalar(g0, "torreta_ladod_120", 0.4550844341491268F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladod_121", 0.8004612878381379F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladod_122", 0.8439061911452496F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladod_123", 0.8765746157029444F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladod_124", 0.908495557477184F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_125", 0.9430396277111741F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_126", 0.8544167879166383F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_127", 0.7816434852307729F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_128", 0.7379463069539671F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_129", 0.7109037911000352F, 1.0F, 0.6152709660483866F);
        escalar(g0, "torreta_ladod_130", 0.6949871816059489F, 1.0F, 0.6152709660483866F);
        escalar(g0, "torreta_ladod_131", 0.6875703006677837F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_132", 0.6875703006677837F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_133", 0.6949871816059489F, 1.0F, 0.6152709660483866F);
        escalar(g0, "torreta_ladod_134", 0.7109037911000352F, 1.0F, 0.6152709660483866F);
        escalar(g0, "torreta_ladod_135", 0.7379463069539671F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_136", 0.7816434852307729F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_137", 0.8544167879166383F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_138", 0.9430396277111741F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_139", 0.9084955574771825F, 1.0F, 0.615270966048387F);
        escalar(g0, "torreta_ladod_140", 0.8765746157029412F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladod_141", 0.8439061911452543F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladod_142", 0.8004612878381379F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladod_143", 0.4550844341491241F, 1.0F, 0.6152709660483868F);
        escalar(g0, "torreta_ladod_144", 0.4550844341491268F, 1.0F, 0.6152709660483835F);
        escalar(g0, "torreta_ladod_145", 0.800461287838138F, 1.0F, 0.6152709660483835F);
        escalar(g0, "torreta_ladod_146", 0.8439061911452496F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_147", 0.8765746157029444F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_148", 0.908495557477184F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_149", 0.9430396277111741F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_150", 0.8544167879166383F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_151", 0.7816434852307729F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_152", 0.7379463069539671F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladod_153", 0.7109037911000352F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladod_154", 0.6949871816059489F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladod_155", 0.6875703006677837F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladod_156", 0.6875703006677837F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladod_157", 0.6949871816059489F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladod_158", 0.7109037911000352F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladod_159", 0.7379463069539671F, 1.0F, 0.6152709660483842F);
        escalar(g0, "torreta_ladod_160", 0.7816434852307729F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_161", 0.8544167879166383F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_162", 0.9430396277111741F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_163", 0.9084955574771825F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_164", 0.8765746157029412F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_165", 0.8439061911452543F, 1.0F, 0.6152709660483834F);
        escalar(g0, "torreta_ladod_166", 0.800461287838138F, 1.0F, 0.6152709660483835F);
        escalar(g0, "torreta_ladod_167", 0.4550844341491241F, 1.0F, 0.6152709660483835F);
        escalar(g0, "torreta_ladod_168", 0.4550844341491268F, 1.0F, 0.615270966048385F);
        escalar(g0, "torreta_ladod_169", 0.800461287838138F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladod_170", 0.8439061911452496F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladod_171", 0.8765746157029444F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladod_172", 0.908495557477184F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladod_173", 0.9430396277111741F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladod_174", 0.8544167879166383F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_175", 0.7816434852307729F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_176", 0.737946306953967F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_177", 0.7109037911000352F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_178", 0.6949871816059489F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_179", 0.6875703006677837F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_180", 0.6875703006677837F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_181", 0.6949871816059489F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_182", 0.7109037911000352F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_183", 0.737946306953967F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_184", 0.7816434852307729F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_185", 0.8544167879166383F, 1.0F, 0.6152709660483848F);
        escalar(g0, "torreta_ladod_186", 0.9430396277111741F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladod_187", 0.9084955574771825F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladod_188", 0.8765746157029412F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladod_189", 0.8439061911452543F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladod_190", 0.800461287838138F, 1.0F, 0.6152709660483853F);
        escalar(g0, "torreta_ladod_191", 0.45508443414912414F, 1.0F, 0.615270966048385F);
        escalar(g0, "torreta_arriba0_0", 0.4550844341491268F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_arriba0_1", 0.8004612878381379F, 1.0F, 0.7495772489817729F);
        escalar(g0, "torreta_arriba0_2", 0.8439061911452496F, 1.0F, 0.6197247358851681F);
        escalar(g0, "torreta_arriba0_3", 0.8765746157029444F, 1.0F, 0.858747882126649F);
        escalar(g0, "torreta_arriba0_4", 0.908495557477184F, 1.0F, 0.7247255863075052F);
        escalar(g0, "torreta_arriba0_5", 0.9430396277111741F, 1.0F, 0.8672151547835582F);
        escalar(g0, "torreta_arriba0_6", 0.8544167879166383F, 1.0F, 0.7758622856520235F);
        escalar(g0, "torreta_arriba0_7", 0.7816434852307729F, 1.0F, 0.8679411764705881F);
        escalar(g0, "torreta_arriba0_8", 0.737946306953967F, 1.0F, 0.9345568912196224F);
        escalar(g0, "torreta_arriba0_9", 0.7109037911000352F, 1.0F, 0.9799052677836989F);
        escalar(g0, "torreta_arriba0_10", 0.6949871816059489F, 1.0F, 1.0063193394216272F);
        escalar(g0, "torreta_arriba0_11", 0.6875703006677837F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_12", 0.6875703006677837F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_13", 0.6949871816059489F, 1.0F, 1.0063193394216272F);
        escalar(g0, "torreta_arriba0_14", 0.7109037911000352F, 1.0F, 0.9799052677836989F);
        escalar(g0, "torreta_arriba0_15", 0.737946306953967F, 1.0F, 0.9345568912196224F);
        escalar(g0, "torreta_arriba0_16", 0.7816434852307729F, 1.0F, 0.8679411764705881F);
        escalar(g0, "torreta_arriba0_17", 0.8544167879166383F, 1.0F, 0.7758622856520235F);
        escalar(g0, "torreta_arriba0_18", 0.9430396277111741F, 1.0F, 0.8672151547835582F);
        escalar(g0, "torreta_arriba0_19", 0.9084955574771825F, 1.0F, 0.7247255863075052F);
        escalar(g0, "torreta_arriba0_20", 0.8765746157029412F, 1.0F, 0.8587478821266494F);
        escalar(g0, "torreta_arriba0_21", 0.8439061911452543F, 1.0F, 0.6197247358851696F);
        escalar(g0, "torreta_arriba0_22", 0.8004612878381379F, 1.0F, 0.7495772489817729F);
        escalar(g0, "torreta_arriba0_23", 0.4550844341491241F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_arriba0_24", 0.40550556201146826F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_arriba0_25", 0.5763965170123259F, 1.0F, 0.7495772489817729F);
        escalar(g0, "torreta_arriba0_26", 0.6320587966800317F, 1.0F, 0.6197247358851681F);
    }

    private static void escalas14(ModelPart g0) {
        escalar(g0, "torreta_arriba0_27", 0.6865274234612793F, 1.0F, 0.8587478821266492F);
        escalar(g0, "torreta_arriba0_28", 0.7448828791431964F, 1.0F, 0.7247255863075052F);
        escalar(g0, "torreta_arriba0_29", 0.8079649697257756F, 1.0F, 0.8672151547835584F);
        escalar(g0, "torreta_arriba0_30", 0.7658945208458472F, 1.0F, 0.7758622856520235F);
        escalar(g0, "torreta_arriba0_31", 0.7304478569184477F, 1.0F, 0.8679411764705881F);
        escalar(g0, "torreta_arriba0_32", 0.7099283232415106F, 1.0F, 0.9345568912196224F);
        escalar(g0, "torreta_arriba0_33", 0.6975457685604737F, 1.0F, 0.9799052677836989F);
        escalar(g0, "torreta_arriba0_34", 0.6903774230114781F, 1.0F, 1.0063193394216272F);
        escalar(g0, "torreta_arriba0_35", 0.6870684329009967F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_36", 0.6870684329009967F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_37", 0.6903774230114781F, 1.0F, 1.0063193394216272F);
        escalar(g0, "torreta_arriba0_38", 0.6975457685604737F, 1.0F, 0.9799052677836989F);
        escalar(g0, "torreta_arriba0_39", 0.7099283232415106F, 1.0F, 0.9345568912196224F);
        escalar(g0, "torreta_arriba0_40", 0.7304478569184477F, 1.0F, 0.8679411764705881F);
        escalar(g0, "torreta_arriba0_41", 0.7658945208458472F, 1.0F, 0.7758622856520235F);
        escalar(g0, "torreta_arriba0_42", 0.8079649697257756F, 1.0F, 0.8672151547835584F);
        escalar(g0, "torreta_arriba0_43", 0.7448828791431951F, 1.0F, 0.7247255863075052F);
        escalar(g0, "torreta_arriba0_44", 0.6865274234612772F, 1.0F, 0.8587478821266497F);
        escalar(g0, "torreta_arriba0_45", 0.6320587966800351F, 1.0F, 0.6197247358851696F);
        escalar(g0, "torreta_arriba0_46", 0.5763965170123259F, 1.0F, 0.7495772489817729F);
        escalar(g0, "torreta_arriba0_47", 0.4055055620114652F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_arriba0_48", 0.37199923612921787F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_arriba0_49", 0.7571722554743561F, 1.0F, 0.7495772489817729F);
        escalar(g0, "torreta_arriba0_50", 0.9143856240947685F, 1.0F, 0.6197247358851683F);
        escalar(g0, "torreta_arriba0_51", 0.5395410331260639F, 1.0F, 0.8587478821266492F);
        escalar(g0, "torreta_arriba0_52", 0.6255160642023155F, 1.0F, 0.7247255863075055F);
        escalar(g0, "torreta_arriba0_53", 0.7142385355489027F, 1.0F, 0.8672151547835584F);
        escalar(g0, "torreta_arriba0_54", 0.7073303371671421F, 1.0F, 0.7758622856520238F);
        escalar(g0, "torreta_arriba0_55", 0.697877107360425F, 1.0F, 0.8679411764705883F);
        escalar(g0, "torreta_arriba0_56", 0.6925575113966418F, 1.0F, 0.9345568912196226F);
        escalar(g0, "torreta_arriba0_57", 0.689403017962187F, 1.0F, 0.9799052677836991F);
        escalar(g0, "torreta_arriba0_58", 0.6875962894251367F, 1.0F, 1.0063193394216274F);
        escalar(g0, "torreta_arriba0_59", 0.6867671309209694F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_60", 0.6867671309209694F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_61", 0.6875962894251367F, 1.0F, 1.0063193394216274F);
        escalar(g0, "torreta_arriba0_62", 0.689403017962187F, 1.0F, 0.9799052677836991F);
        escalar(g0, "torreta_arriba0_63", 0.6925575113966418F, 1.0F, 0.9345568912196226F);
        escalar(g0, "torreta_arriba0_64", 0.697877107360425F, 1.0F, 0.8679411764705883F);
        escalar(g0, "torreta_arriba0_65", 0.7073303371671421F, 1.0F, 0.7758622856520238F);
        escalar(g0, "torreta_arriba0_66", 0.7142385355489027F, 1.0F, 0.8672151547835584F);
        escalar(g0, "torreta_arriba0_67", 0.6255160642023145F, 1.0F, 0.7247255863075055F);
        escalar(g0, "torreta_arriba0_68", 0.5395410331260627F, 1.0F, 0.8587478821266497F);
        escalar(g0, "torreta_arriba0_69", 0.914385624094773F, 1.0F, 0.6197247358851696F);
        escalar(g0, "torreta_arriba0_70", 0.7571722554743561F, 1.0F, 0.7495772489817729F);
        escalar(g0, "torreta_arriba0_71", 0.37199923612921443F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_arriba0_72", 0.3719992361292179F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_arriba0_73", 0.7571722554743561F, 1.0F, 0.7495772489817729F);
        escalar(g0, "torreta_arriba0_74", 0.9143856240947681F, 1.0F, 0.6197247358851679F);
        escalar(g0, "torreta_arriba0_75", 0.539541033126064F, 1.0F, 0.858747882126649F);
        escalar(g0, "torreta_arriba0_76", 0.6255160642023153F, 1.0F, 0.7247255863075049F);
        escalar(g0, "torreta_arriba0_77", 0.7142385355489028F, 1.0F, 0.8672151547835582F);
        escalar(g0, "torreta_arriba0_78", 0.7073303371671421F, 1.0F, 0.7758622856520233F);
        escalar(g0, "torreta_arriba0_79", 0.697877107360425F, 1.0F, 0.8679411764705879F);
        escalar(g0, "torreta_arriba0_80", 0.6925575113966418F, 1.0F, 0.9345568912196222F);
        escalar(g0, "torreta_arriba0_81", 0.689403017962187F, 1.0F, 0.9799052677836987F);
        escalar(g0, "torreta_arriba0_82", 0.6875962894251367F, 1.0F, 1.006319339421627F);
        escalar(g0, "torreta_arriba0_83", 0.6867671309209694F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_84", 0.6867671309209694F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_85", 0.6875962894251367F, 1.0F, 1.006319339421627F);
        escalar(g0, "torreta_arriba0_86", 0.689403017962187F, 1.0F, 0.9799052677836987F);
        escalar(g0, "torreta_arriba0_87", 0.6925575113966418F, 1.0F, 0.9345568912196222F);
        escalar(g0, "torreta_arriba0_88", 0.697877107360425F, 1.0F, 0.8679411764705879F);
        escalar(g0, "torreta_arriba0_89", 0.7073303371671421F, 1.0F, 0.7758622856520233F);
        escalar(g0, "torreta_arriba0_90", 0.7142385355489028F, 1.0F, 0.8672151547835582F);
        escalar(g0, "torreta_arriba0_91", 0.6255160642023143F, 1.0F, 0.7247255863075049F);
        escalar(g0, "torreta_arriba0_92", 0.5395410331260626F, 1.0F, 0.8587478821266494F);
        escalar(g0, "torreta_arriba0_93", 0.914385624094773F, 1.0F, 0.6197247358851696F);
        escalar(g0, "torreta_arriba0_94", 0.7571722554743561F, 1.0F, 0.7495772489817729F);
        escalar(g0, "torreta_arriba0_95", 0.3719992361292145F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_arriba0_96", 0.4055055620114683F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_arriba0_97", 0.5763965170123256F, 1.0F, 0.7495772489817725F);
        escalar(g0, "torreta_arriba0_98", 0.6320587966800317F, 1.0F, 0.6197247358851683F);
        escalar(g0, "torreta_arriba0_99", 0.6865274234612788F, 1.0F, 0.8587478821266485F);
        escalar(g0, "torreta_arriba0_100", 0.7448828791431966F, 1.0F, 0.7247255863075055F);
        escalar(g0, "torreta_arriba0_101", 0.8079649697257754F, 1.0F, 0.8672151547835582F);
        escalar(g0, "torreta_arriba0_102", 0.7658945208458472F, 1.0F, 0.7758622856520238F);
        escalar(g0, "torreta_arriba0_103", 0.7304478569184476F, 1.0F, 0.8679411764705879F);
        escalar(g0, "torreta_arriba0_104", 0.7099283232415107F, 1.0F, 0.9345568912196226F);
        escalar(g0, "torreta_arriba0_105", 0.6975457685604737F, 1.0F, 0.9799052677836991F);
        escalar(g0, "torreta_arriba0_106", 0.6903774230114781F, 1.0F, 1.0063193394216274F);
        escalar(g0, "torreta_arriba0_107", 0.6870684329009967F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_108", 0.6870684329009967F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_109", 0.6903774230114781F, 1.0F, 1.0063193394216274F);
        escalar(g0, "torreta_arriba0_110", 0.6975457685604737F, 1.0F, 0.9799052677836991F);
        escalar(g0, "torreta_arriba0_111", 0.7099283232415107F, 1.0F, 0.9345568912196226F);
        escalar(g0, "torreta_arriba0_112", 0.7304478569184476F, 1.0F, 0.8679411764705879F);
        escalar(g0, "torreta_arriba0_113", 0.7658945208458472F, 1.0F, 0.7758622856520238F);
        escalar(g0, "torreta_arriba0_114", 0.8079649697257754F, 1.0F, 0.8672151547835582F);
        escalar(g0, "torreta_arriba0_115", 0.7448828791431951F, 1.0F, 0.7247255863075055F);
        escalar(g0, "torreta_arriba0_116", 0.6865274234612772F, 1.0F, 0.8587478821266494F);
        escalar(g0, "torreta_arriba0_117", 0.632058796680035F, 1.0F, 0.6197247358851692F);
        escalar(g0, "torreta_arriba0_118", 0.5763965170123256F, 1.0F, 0.7495772489817725F);
        escalar(g0, "torreta_arriba0_119", 0.4055055620114652F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_arriba0_120", 0.4550844341491268F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_arriba0_121", 0.8004612878381379F, 1.0F, 0.7495772489817734F);
        escalar(g0, "torreta_arriba0_122", 0.8439061911452496F, 1.0F, 0.6197247358851683F);
        escalar(g0, "torreta_arriba0_123", 0.8765746157029444F, 1.0F, 0.8587478821266499F);
        escalar(g0, "torreta_arriba0_124", 0.908495557477184F, 1.0F, 0.7247255863075055F);
        escalar(g0, "torreta_arriba0_125", 0.9430396277111741F, 1.0F, 0.8672151547835587F);
        escalar(g0, "torreta_arriba0_126", 0.8544167879166383F, 1.0F, 0.7758622856520238F);
        escalar(g0, "torreta_arriba0_127", 0.7816434852307729F, 1.0F, 0.8679411764705888F);
        escalar(g0, "torreta_arriba0_128", 0.737946306953967F, 1.0F, 0.9345568912196226F);
        escalar(g0, "torreta_arriba0_129", 0.7109037911000352F, 1.0F, 0.9799052677836991F);
        escalar(g0, "torreta_arriba0_130", 0.6949871816059489F, 1.0F, 1.0063193394216274F);
        escalar(g0, "torreta_arriba0_131", 0.6875703006677837F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_132", 0.6875703006677837F, 1.0F, 1.015F);
        escalar(g0, "torreta_arriba0_133", 0.6949871816059489F, 1.0F, 1.0063193394216274F);
        escalar(g0, "torreta_arriba0_134", 0.7109037911000352F, 1.0F, 0.9799052677836991F);
        escalar(g0, "torreta_arriba0_135", 0.737946306953967F, 1.0F, 0.9345568912196226F);
        escalar(g0, "torreta_arriba0_136", 0.7816434852307729F, 1.0F, 0.8679411764705888F);
        escalar(g0, "torreta_arriba0_137", 0.8544167879166383F, 1.0F, 0.7758622856520238F);
        escalar(g0, "torreta_arriba0_138", 0.9430396277111741F, 1.0F, 0.8672151547835587F);
        escalar(g0, "torreta_arriba0_139", 0.9084955574771825F, 1.0F, 0.7247255863075055F);
        escalar(g0, "torreta_arriba0_140", 0.8765746157029412F, 1.0F, 0.8587478821266499F);
        escalar(g0, "torreta_arriba0_141", 0.8439061911452543F, 1.0F, 0.6197247358851701F);
        escalar(g0, "torreta_arriba0_142", 0.8004612878381379F, 1.0F, 0.7495772489817734F);
        escalar(g0, "torreta_arriba0_143", 0.4550844341491241F, 1.0F, 0.2637283488047725F);
        escalar(g0, "torreta_trompa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "torreta_cola", 1.0F, 0.5F, 0.5F);
        escalar(g0, "torreta_tapa_i", 0.25F, 0.8F, 0.25F);
        escalar(g0, "torreta_tapa_d", 0.25F, 0.8F, 0.25F);
        escalar(g0, "torreta_canon_0", 0.5F, 1.0F, 0.3364647586332763F);
        escalar(g0, "torreta_canon_1", 0.5F, 1.0F, 0.3364647586332778F);
        escalar(g0, "torreta_canon_2", 0.5F, 1.0F, 0.3364647586332765F);
        escalar(g0, "torreta_canon_3", 0.5F, 1.0F, 0.3364647586332764F);
        escalar(g0, "torreta_canon_4", 0.5F, 1.0F, 0.33646475863327663F);
        escalar(g0, "torreta_canon_5", 0.5F, 1.0F, 0.33646475863327807F);
        escalar(g0, "torreta_canon_6", 0.5F, 1.0F, 0.33646475863327624F);
        escalar(g0, "torreta_canon_7", 0.5F, 1.0F, 0.3364647586332778F);
        escalar(g0, "torreta_canon_8", 0.5F, 1.0F, 0.33646475863327713F);
        escalar(g0, "torreta_canon_9", 0.5F, 1.0F, 0.33646475863327663F);
        escalar(g0, "torreta_canon_10", 0.5F, 1.0F, 0.3364647586332768F);
        escalar(g0, "torreta_canon_11", 0.5F, 1.0F, 0.33646475863327807F);
        escalar(g0, "torreta_canon_ta", 0.23636363636363636F, 0.6F, 0.23636363636363636F);
        escalar(g0, "torreta_canon_tb", 0.23636363636363636F, 0.6F, 0.23636363636363636F);
        escalar(g0, "torreta_evacuador_0", 0.5F, 1.0F, 0.49175618569478907F);
        escalar(g0, "torreta_evacuador_1", 0.5F, 1.0F, 0.491756185694789F);
        escalar(g0, "torreta_evacuador_2", 0.5F, 1.0F, 0.4917561856947895F);
        escalar(g0, "torreta_evacuador_3", 0.5F, 1.0F, 0.49175618569478935F);
        escalar(g0, "torreta_evacuador_4", 0.5F, 1.0F, 0.4917561856947891F);
        escalar(g0, "torreta_evacuador_5", 0.5F, 1.0F, 0.4917561856947891F);
        escalar(g0, "torreta_evacuador_6", 0.5F, 1.0F, 0.491756185694789F);
        escalar(g0, "torreta_evacuador_7", 0.5F, 1.0F, 0.49175618569478896F);
        escalar(g0, "torreta_evacuador_8", 0.5F, 1.0F, 0.49175618569478974F);
        escalar(g0, "torreta_evacuador_9", 0.5F, 1.0F, 0.4917561856947886F);
        escalar(g0, "torreta_evacuador_10", 0.5F, 1.0F, 0.49175618569479057F);
        escalar(g0, "torreta_evacuador_11", 0.5F, 1.0F, 0.4917561856947892F);
        escalar(g0, "torreta_evacuador_ta", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "torreta_evacuador_tb", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "torreta_boca_0", 0.5F, 1.0F, 0.49175618569478907F);
    }

    private static void escalas15(ModelPart g0) {
        escalar(g0, "torreta_boca_1", 0.5F, 1.0F, 0.491756185694789F);
        escalar(g0, "torreta_boca_2", 0.5F, 1.0F, 0.4917561856947895F);
        escalar(g0, "torreta_boca_3", 0.5F, 1.0F, 0.49175618569478935F);
        escalar(g0, "torreta_boca_4", 0.5F, 1.0F, 0.4917561856947891F);
        escalar(g0, "torreta_boca_5", 0.5F, 1.0F, 0.4917561856947891F);
        escalar(g0, "torreta_boca_6", 0.5F, 1.0F, 0.491756185694789F);
        escalar(g0, "torreta_boca_7", 0.5F, 1.0F, 0.49175618569478896F);
        escalar(g0, "torreta_boca_8", 0.5F, 1.0F, 0.49175618569478974F);
        escalar(g0, "torreta_boca_9", 0.5F, 1.0F, 0.4917561856947886F);
        escalar(g0, "torreta_boca_10", 0.5F, 1.0F, 0.49175618569479057F);
        escalar(g0, "torreta_boca_11", 0.5F, 1.0F, 0.4917561856947892F);
        escalar(g0, "torreta_boca_ta", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "torreta_boca_tb", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "torreta_antena", 0.4F, 0.9669275979057774F, 0.4F);
        escalar(g0, "faro_i_0", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_i_1", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_i_2", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_i_3", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_i_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "escape_i_0", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_i_1", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_i_2", 0.5F, 1.0F, 0.4635254915624216F);
        escalar(g0, "escape_i_3", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_i_4", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_i_5", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_i_6", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_i_7", 0.5F, 1.0F, 0.4635254915624216F);
        escalar(g0, "escape_i_8", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_i_9", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_i_ta", 0.25F, 0.6F, 0.25F);
        escalar(g0, "escape_i_tb", 0.25F, 0.6F, 0.25F);
        escalar(g0, "faro_d_0", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_d_1", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_d_2", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_d_3", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_d_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "escape_d_0", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_d_1", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_d_2", 0.5F, 1.0F, 0.4635254915624216F);
        escalar(g0, "escape_d_3", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_d_4", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_d_5", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_d_6", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_d_7", 0.5F, 1.0F, 0.4635254915624216F);
        escalar(g0, "escape_d_8", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_d_9", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_d_ta", 0.25F, 0.6F, 0.25F);
        escalar(g0, "escape_d_tb", 0.25F, 0.6F, 0.25F);
    }
}
