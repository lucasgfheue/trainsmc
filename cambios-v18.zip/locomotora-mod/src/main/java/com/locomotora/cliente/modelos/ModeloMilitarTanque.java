package com.locomotora.cliente.modelos;

import java.util.List;

import org.joml.Vector3f;

import com.locomotora.LocomotoraMod;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * Modelo 3D del vehículo "militar_tanque" (generado por el estudio de diseño, estilo Traincraft).
 * Unidades de 1/16 de bloque. Frente en -X, Y hacia abajo, suelo en Y = 0, Z hacia la derecha del que maneja.
 * Las superficies curvas están hechas con placas finas giradas y estiradas a medida (escala de cada pieza).
 */
public final class ModeloMilitarTanque {
    public static final DatosModelo DATOS = new DatosModelo(
            new ModelLayerLocation(LocomotoraMod.id("militar_tanque"), "main"),
            LocomotoraMod.id("textures/entity/militar_tanque.png"),
            List.of(
                new DatosModelo.Animada("oruga_i_0", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 0.0F, 0.0F, -37.870877915596346F, -16.998717372475838F, 3.115720150292878F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_1", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 2.4868969399957854F, 0.0F, -40.30678826556819F, -16.57640504204073F, 2.778611114731445F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_2", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 4.973793879991571F, 0.0F, -42.40866186855317F, -15.275139128283897F, 2.3957633510558995F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_3", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 7.460690819987356F, 0.0F, -43.87250040701619F, -13.283269202825922F, 2.0129156233384577F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_4", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 9.947587759983142F, 0.0F, -44.486634275546876F, -10.889014232011396F, 1.6300679495558374F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_5", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 12.434484699978928F, 0.0F, -44.16232709839016F, -8.438762184279533F, 1.2472203476819619F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_6", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 14.921381639974712F, 0.0F, -42.946596315471766F, -6.2869613950410885F, 0.8643728356870348F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_7", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 17.4082785799705F, 0.0F, -41.01539766125712F, -4.744851728608403F, 0.4855178011865842F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_8", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 19.895175519966283F, 0.0F, -38.6988461118527F, -3.846227518469617F, 0.3437721363240482F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_9", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 22.382072459962068F, 0.0F, -36.35745750556961F, -3.008041510158738F, 0.3437721363240482F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_10", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 24.868969399957855F, 0.0F, -34.01606889928652F, -2.1698555018478576F, 0.3437721363240482F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_11", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 27.35586633995364F, 0.0F, -31.67468029300343F, -1.3316694935369786F, 0.3437721363240482F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_12", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 29.842763279949423F, 0.0F, -29.33329168672034F, -0.4934834852261001F, 0.325781570694527F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_13", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 32.32966021994521F, 0.0F, -26.91263788279508F, 0.0F, 0.04592386344824236F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_14", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 34.816557159941F, 0.0F, -24.425740942799294F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_15", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 37.30345409993678F, 0.0F, -21.938844002803513F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_16", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 39.79035103993257F, 0.0F, -19.451947062807726F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_17", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 42.277247979928354F, 0.0F, -16.965050122811938F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_18", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 44.764144919924135F, 0.0F, -14.478153182816158F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_19", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 47.25104185991992F, 0.0F, -11.99125624282037F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_20", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 49.73793879991571F, 0.0F, -9.504359302824582F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_21", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 52.22483573991149F, 0.0F, -7.017462362828802F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_22", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 54.71173267990728F, 0.0F, -4.530565422833014F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_23", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 57.198629619903066F, 0.0F, -2.0436684828372265F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_24", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 59.68552655989885F, 0.0F, 0.4432284571585541F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_25", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 62.172423499894634F, 0.0F, 2.9301253971543417F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_26", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 64.65932043989042F, 0.0F, 5.417022337150129F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_27", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 67.14621737988621F, 0.0F, 7.903919277145917F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_28", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 69.633114319882F, 0.0F, 10.390816217141705F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_29", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 72.12001125987777F, 0.0F, 12.877713157137478F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_30", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 74.60690819987356F, 0.0F, 15.364610097133266F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_31", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 77.09380513986935F, 0.0F, 17.851507037129053F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_32", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 79.58070207986513F, 0.0F, 20.33840397712484F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_33", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 82.06759901986092F, 0.0F, 22.82530091712063F, 0.0F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_34", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 84.55449595985671F, 0.0F, 25.312197857116416F, 0.0F, -0.008998178557776555F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_35", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 87.0413928998525F, 0.0F, 27.768452689361492F, -0.28880519600341337F, -0.2555784273446928F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_36", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 89.52828983984827F, 0.0F, 30.148887596048453F, -1.0086566009381928F, -0.29366020881360094F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_37", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 92.01518677984406F, 0.0F, 32.52932250273543F, -1.7285080058729763F, -0.29366020881360133F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_38", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 94.50208371983985F, 0.0F, 34.909757409422404F, -2.4483594108077598F, -0.29366020881360144F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_39", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 96.98898065983563F, 0.0F, 37.29019231610938F, -3.1682108157425435F, -0.29366020881360033F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_40", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 99.47587759983142F, 0.0F, 39.66479681614288F, -3.9059883384371696F, -0.38800634341643897F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_41", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 101.96277453982721F, 0.0F, 41.73462195897388F, -5.252154101997459F, -0.7830349663750497F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_42", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 104.44967147982298F, 0.0F, 43.08676336449564F, -7.317955339105367F, -1.1975218898148323F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_43", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 106.93656841981877F, 0.0F, 43.492180109317665F, -9.753311893931029F, -1.6120088570922866F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_44", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 109.42346535981456F, 0.0F, 42.88225591682236F, -12.145557769116133F, -2.026495873753517F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_45", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 111.91036229981034F, 0.0F, 41.36041175403498F, -14.089363870918339F, -2.4409829453434715F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_46", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 114.39725923980613F, 0.0F, 39.18456991638542F, -15.25541210812608F, -2.8554700774057964F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_47", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 116.88415617980192F, 0.0F, 36.721308303669566F, -15.516655911294347F, -3.1172572015550166F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_48", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 119.3710531197977F, 0.0F, 34.23490209636071F, -15.566057960000396F, -3.1217264107930753F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_49", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 121.85795005979348F, 0.0F, 31.748495889051846F, -15.615460008706446F, -3.1217264107930753F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_50", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 124.34484699978927F, 0.0F, 29.26208968174298F, -15.664862057412495F, -3.1217264107930753F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_51", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 126.83174393978506F, 0.0F, 26.775683474434118F, -15.714264106118545F, -3.1217264107930753F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_52", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 129.31864087978084F, 0.0F, 24.28927726712525F, -15.763666154824595F, -3.1217264107930762F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_53", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 131.80553781977662F, 0.0F, 21.802871059816397F, -15.813068203530644F, -3.1217264107930762F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_54", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 134.29243475977242F, 0.0F, 19.31646485250752F, -15.862470252236694F, -3.1217264107930753F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_55", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 136.7793316997682F, 0.0F, 16.83005864519867F, -15.911872300942743F, -3.1217264107930753F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_56", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 139.266228639764F, 0.0F, 14.343652437889787F, -15.961274349648793F, -3.1217264107930753F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_57", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 141.75312557975977F, 0.0F, 11.857246230580937F, -16.010676398354843F, -3.1217264107930762F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_58", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 144.24002251975554F, 0.0F, 9.370840023272088F, -16.060078447060892F, -3.1217264107930762F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_59", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 146.72691945975134F, 0.0F, 6.884433815963206F, -16.10948049576694F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_60", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 149.21381639974712F, 0.0F, 4.398027608654353F, -16.15888254447299F, -3.1217264107930762F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_61", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 151.70071333974292F, 0.0F, 1.911621401345478F, -16.20828459317904F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_62", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 154.1876102797387F, 0.0F, -0.5747848059633753F, -16.25768664188509F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_63", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 156.6745072197345F, 0.0F, -3.061191013272257F, -16.30708869059114F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_64", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 159.16140415973027F, 0.0F, -5.547597220581103F, -16.35649073929719F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_65", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 161.64830109972604F, 0.0F, -8.034003427889957F, -16.40589278800324F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_66", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 164.13519803972184F, 0.0F, -10.520409635198838F, -16.455294836709292F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_67", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 166.62209497971762F, 0.0F, -13.006815842507685F, -16.504696885415342F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_68", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 169.10899191971342F, 0.0F, -15.493222049816566F, -16.55409893412139F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_69", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 171.5958888597092F, 0.0F, -17.97962825712542F, -16.60350098282744F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_70", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 174.082785799705F, 0.0F, -20.4660344644343F, -16.65290303153349F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_71", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 176.56968273970077F, 0.0F, -22.952440671743148F, -16.70230508023954F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_72", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 179.05657967969654F, 0.0F, -25.438846879052F, -16.75170712894559F, -3.121726410793075F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_73", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 181.54347661969234F, 0.0F, -27.925253086360875F, -16.80110917765164F, -3.1217264107930762F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_74", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 184.03037355968812F, 0.0F, -30.411659293669736F, -16.85051122635769F, -3.1217264107930762F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_75", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 186.51727049968392F, 0.0F, -32.89806550097861F, -16.89991327506374F, -3.1217264107930762F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_i_76", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 189.0041674396797F, 0.0F, -35.38447170828746F, -16.949315323769788F, -3.1217264107930762F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i0_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i0_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i1_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i1_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i2_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i2_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i3_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i3_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i4_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i4_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i5_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_i5_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_i_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_i_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.39269908169872414F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_i_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.7853981633974483F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_i_3", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 1.1780972450961724F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_i_cara", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_i_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_i_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.39269908169872414F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_i_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.7853981633974483F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_i_3", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 1.1780972450961724F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_i_cara", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i0_0", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i0_1", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.39269908169872414F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i0_2", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.7853981633974483F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i0_3", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 1.1780972450961724F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i0_cara", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i1_0", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i1_1", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.39269908169872414F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i1_2", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.7853981633974483F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i1_3", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 1.1780972450961724F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_i1_cara", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.0F, "cuerpo", 0.0F, -17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_0", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 0.0F, 0.0F, -37.870877915596346F, -16.998717372475838F, 3.115720150292878F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_1", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 2.4868969399957854F, 0.0F, -40.30678826556819F, -16.57640504204073F, 2.778611114731445F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_2", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 4.973793879991571F, 0.0F, -42.40866186855317F, -15.275139128283897F, 2.3957633510558995F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_3", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 7.460690819987356F, 0.0F, -43.87250040701619F, -13.283269202825922F, 2.0129156233384577F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_4", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 9.947587759983142F, 0.0F, -44.486634275546876F, -10.889014232011396F, 1.6300679495558374F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_5", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 12.434484699978928F, 0.0F, -44.16232709839016F, -8.438762184279533F, 1.2472203476819619F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_6", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 14.921381639974712F, 0.0F, -42.946596315471766F, -6.2869613950410885F, 0.8643728356870348F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_7", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 17.4082785799705F, 0.0F, -41.01539766125712F, -4.744851728608403F, 0.4855178011865842F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_8", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 19.895175519966283F, 0.0F, -38.6988461118527F, -3.846227518469617F, 0.3437721363240482F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_9", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 22.382072459962068F, 0.0F, -36.35745750556961F, -3.008041510158738F, 0.3437721363240482F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_10", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 24.868969399957855F, 0.0F, -34.01606889928652F, -2.1698555018478576F, 0.3437721363240482F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_11", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 27.35586633995364F, 0.0F, -31.67468029300343F, -1.3316694935369786F, 0.3437721363240482F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_12", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 29.842763279949423F, 0.0F, -29.33329168672034F, -0.4934834852261001F, 0.325781570694527F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_13", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 32.32966021994521F, 0.0F, -26.91263788279508F, 0.0F, 0.04592386344824236F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_14", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 34.816557159941F, 0.0F, -24.425740942799294F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_15", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 37.30345409993678F, 0.0F, -21.938844002803513F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_16", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 39.79035103993257F, 0.0F, -19.451947062807726F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_17", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 42.277247979928354F, 0.0F, -16.965050122811938F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_18", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 44.764144919924135F, 0.0F, -14.478153182816158F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_19", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 47.25104185991992F, 0.0F, -11.99125624282037F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_20", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 49.73793879991571F, 0.0F, -9.504359302824582F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_21", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 52.22483573991149F, 0.0F, -7.017462362828802F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_22", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 54.71173267990728F, 0.0F, -4.530565422833014F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_23", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 57.198629619903066F, 0.0F, -2.0436684828372265F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_24", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 59.68552655989885F, 0.0F, 0.4432284571585541F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_25", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 62.172423499894634F, 0.0F, 2.9301253971543417F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_26", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 64.65932043989042F, 0.0F, 5.417022337150129F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_27", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 67.14621737988621F, 0.0F, 7.903919277145917F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_28", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 69.633114319882F, 0.0F, 10.390816217141705F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_29", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 72.12001125987777F, 0.0F, 12.877713157137478F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_30", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 74.60690819987356F, 0.0F, 15.364610097133266F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_31", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 77.09380513986935F, 0.0F, 17.851507037129053F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_32", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 79.58070207986513F, 0.0F, 20.33840397712484F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_33", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 82.06759901986092F, 0.0F, 22.82530091712063F, 0.0F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_34", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 84.55449595985671F, 0.0F, 25.312197857116416F, 0.0F, -0.008998178557776555F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_35", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 87.0413928998525F, 0.0F, 27.768452689361492F, -0.28880519600341337F, -0.2555784273446928F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_36", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 89.52828983984827F, 0.0F, 30.148887596048453F, -1.0086566009381928F, -0.29366020881360094F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_37", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 92.01518677984406F, 0.0F, 32.52932250273543F, -1.7285080058729763F, -0.29366020881360133F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_38", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 94.50208371983985F, 0.0F, 34.909757409422404F, -2.4483594108077598F, -0.29366020881360144F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_39", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 96.98898065983563F, 0.0F, 37.29019231610938F, -3.1682108157425435F, -0.29366020881360033F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_40", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 99.47587759983142F, 0.0F, 39.66479681614288F, -3.9059883384371696F, -0.38800634341643897F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_41", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 101.96277453982721F, 0.0F, 41.73462195897388F, -5.252154101997459F, -0.7830349663750497F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_42", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 104.44967147982298F, 0.0F, 43.08676336449564F, -7.317955339105367F, -1.1975218898148323F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_43", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 106.93656841981877F, 0.0F, 43.492180109317665F, -9.753311893931029F, -1.6120088570922866F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_44", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 109.42346535981456F, 0.0F, 42.88225591682236F, -12.145557769116133F, -2.026495873753517F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_45", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 111.91036229981034F, 0.0F, 41.36041175403498F, -14.089363870918339F, -2.4409829453434715F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_46", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 114.39725923980613F, 0.0F, 39.18456991638542F, -15.25541210812608F, -2.8554700774057964F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_47", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 116.88415617980192F, 0.0F, 36.721308303669566F, -15.516655911294347F, -3.1172572015550166F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_48", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 119.3710531197977F, 0.0F, 34.23490209636071F, -15.566057960000396F, -3.1217264107930753F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_49", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 121.85795005979348F, 0.0F, 31.748495889051846F, -15.615460008706446F, -3.1217264107930753F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_50", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 124.34484699978927F, 0.0F, 29.26208968174298F, -15.664862057412495F, -3.1217264107930753F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_51", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 126.83174393978506F, 0.0F, 26.775683474434118F, -15.714264106118545F, -3.1217264107930753F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_52", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 129.31864087978084F, 0.0F, 24.28927726712525F, -15.763666154824595F, -3.1217264107930762F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_53", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 131.80553781977662F, 0.0F, 21.802871059816397F, -15.813068203530644F, -3.1217264107930762F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_54", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 134.29243475977242F, 0.0F, 19.31646485250752F, -15.862470252236694F, -3.1217264107930753F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_55", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 136.7793316997682F, 0.0F, 16.83005864519867F, -15.911872300942743F, -3.1217264107930753F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_56", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 139.266228639764F, 0.0F, 14.343652437889787F, -15.961274349648793F, -3.1217264107930753F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_57", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 141.75312557975977F, 0.0F, 11.857246230580937F, -16.010676398354843F, -3.1217264107930762F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_58", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 144.24002251975554F, 0.0F, 9.370840023272088F, -16.060078447060892F, -3.1217264107930762F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_59", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 146.72691945975134F, 0.0F, 6.884433815963206F, -16.10948049576694F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_60", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 149.21381639974712F, 0.0F, 4.398027608654353F, -16.15888254447299F, -3.1217264107930762F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_61", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 151.70071333974292F, 0.0F, 1.911621401345478F, -16.20828459317904F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_62", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 154.1876102797387F, 0.0F, -0.5747848059633753F, -16.25768664188509F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_63", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 156.6745072197345F, 0.0F, -3.061191013272257F, -16.30708869059114F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_64", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 159.16140415973027F, 0.0F, -5.547597220581103F, -16.35649073929719F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_65", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 161.64830109972604F, 0.0F, -8.034003427889957F, -16.40589278800324F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_66", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 164.13519803972184F, 0.0F, -10.520409635198838F, -16.455294836709292F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_67", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 166.62209497971762F, 0.0F, -13.006815842507685F, -16.504696885415342F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_68", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 169.10899191971342F, 0.0F, -15.493222049816566F, -16.55409893412139F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_69", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 171.5958888597092F, 0.0F, -17.97962825712542F, -16.60350098282744F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_70", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 174.082785799705F, 0.0F, -20.4660344644343F, -16.65290303153349F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_71", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 176.56968273970077F, 0.0F, -22.952440671743148F, -16.70230508023954F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_72", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 179.05657967969654F, 0.0F, -25.438846879052F, -16.75170712894559F, -3.121726410793075F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_73", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 181.54347661969234F, 0.0F, -27.925253086360875F, -16.80110917765164F, -3.1217264107930762F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_74", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 184.03037355968812F, 0.0F, -30.411659293669736F, -16.85051122635769F, -3.1217264107930762F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_75", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 186.51727049968392F, 0.0F, -32.89806550097861F, -16.89991327506374F, -3.1217264107930762F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("oruga_d_76", DatosModelo.ESLABON, 2.2879451847961225F, 0.0F, 189.0041674396797F, 0.0F, -35.38447170828746F, -16.949315323769788F, -3.1217264107930762F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d0_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d0_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d0_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d0_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d0_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -27.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d1_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d1_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d1_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d1_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d1_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -16.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d2_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d2_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d2_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d2_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d2_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, -5.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d3_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d3_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d3_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d3_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d3_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 4.8F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d4_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d4_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d4_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d4_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d4_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 15.4F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d5_0", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d5_1", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.39269908169872414F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d5_2", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.7853981633974483F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d5_3", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 1.1780972450961724F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_d5_cara", DatosModelo.RUEDA, 4.5F, 0.0F, 0.0F, 0.0F, 26.0F, -5.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_d_0", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_d_1", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.39269908169872414F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_d_2", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.7853981633974483F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_d_3", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 1.1780972450961724F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("motriz_d_cara", DatosModelo.RUEDA, 5.5F, 0.0F, 0.0F, 0.0F, -38.0F, -10.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_d_0", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_d_1", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.39269908169872414F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_d_2", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.7853981633974483F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_d_3", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 1.1780972450961724F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("tensora_d_cara", DatosModelo.RUEDA, 5.0F, 0.0F, 0.0F, 0.0F, 37.5F, -9.5F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d0_0", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d0_1", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.39269908169872414F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d0_2", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.7853981633974483F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d0_3", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 1.1780972450961724F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d0_cara", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, -12.0F, -13.983443708609272F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d1_0", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d1_1", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.39269908169872414F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d1_2", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.7853981633974483F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d1_3", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 1.1780972450961724F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("rodillo_alto_d1_cara", DatosModelo.RUEDA, 1.5F, 0.0F, 0.0F, 0.0F, 12.0F, -13.506622516556291F, 0.0F, "cuerpo", 0.0F, 17.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_0", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_1", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_2", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_3", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_4", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_5", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_6", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_7", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_8", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_9", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_10", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_11", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_12", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_13", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_14", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_15", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_16", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_17", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_18", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_19", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_20", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_21", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_22", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_23", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_24", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_25", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_26", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_27", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_28", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_29", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_30", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_31", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_32", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_33", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_34", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_35", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_36", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_37", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_38", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_39", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_40", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_41", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_42", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_43", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_44", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_45", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_46", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_47", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_48", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_49", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_50", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_51", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_52", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_53", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_54", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_55", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_56", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_57", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_58", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_59", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_60", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_61", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_62", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_63", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_64", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_65", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_66", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_67", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_68", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_69", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_70", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_71", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_72", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_73", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_74", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_75", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_76", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_77", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_78", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_79", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_80", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_81", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_82", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_83", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_84", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_85", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_86", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_87", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_88", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_89", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_90", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_91", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_92", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_93", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_94", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_95", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_96", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_97", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_98", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_99", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_100", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_101", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_102", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_103", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_104", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_105", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_106", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_107", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_108", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_109", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_110", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_111", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_112", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_113", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_114", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_115", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_116", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_117", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_118", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_119", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_120", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_121", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_122", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_123", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_124", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_125", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_126", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_127", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_128", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_129", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_130", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_131", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_132", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_133", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_134", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_135", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_136", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_137", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_138", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_139", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_140", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_141", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_142", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_143", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_144", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_145", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_146", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_147", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_148", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_149", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_150", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_151", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_152", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_153", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_154", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_155", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_156", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_157", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_158", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_159", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_160", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_161", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_162", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_163", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_164", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_165", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_166", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_167", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_168", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_169", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_170", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_171", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_172", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_173", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_174", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_175", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_176", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_177", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_178", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_179", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_180", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_181", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_182", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_183", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_184", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_185", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_186", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_187", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_188", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_189", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_190", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladoi_191", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_0", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_1", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_2", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_3", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_4", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_5", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_6", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_7", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_8", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_9", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_10", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_11", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_12", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_13", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_14", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_15", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_16", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_17", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_18", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_19", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_20", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_21", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_22", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_23", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_24", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_25", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_26", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_27", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_28", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_29", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_30", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_31", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_32", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_33", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_34", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_35", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_36", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_37", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_38", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_39", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_40", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_41", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_42", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_43", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_44", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_45", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_46", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_47", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_48", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_49", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_50", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_51", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_52", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_53", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_54", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_55", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_56", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_57", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_58", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_59", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_60", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_61", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_62", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_63", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_64", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_65", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_66", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_67", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_68", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_69", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_70", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_71", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_72", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_73", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_74", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_75", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_76", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_77", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_78", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_79", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_80", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_81", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_82", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_83", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_84", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_85", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_86", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_87", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_88", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_89", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_90", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_91", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_92", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_93", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_94", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_95", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_96", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_97", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_98", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_99", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_100", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_101", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_102", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_103", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_104", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_105", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_106", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_107", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_108", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_109", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_110", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_111", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_112", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_113", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_114", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_115", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_116", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_117", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_118", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_119", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_120", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_121", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_122", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_123", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_124", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_125", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_126", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_127", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_128", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_129", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_130", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_131", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_132", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_133", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_134", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_135", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_136", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_137", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_138", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_139", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_140", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_141", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_142", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_143", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_144", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_145", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_146", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_147", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_148", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_149", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_150", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_151", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_152", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_153", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_154", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_155", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_156", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_157", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_158", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_159", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_160", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_161", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_162", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_163", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_164", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_165", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_166", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_167", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_168", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_169", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_170", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_171", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_172", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_173", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_174", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_175", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_176", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_177", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_178", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_179", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_180", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_181", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_182", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_183", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_184", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_185", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_186", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_187", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_188", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_189", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_190", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_ladod_191", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_0", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_1", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_2", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_3", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_4", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_5", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_6", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_7", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_8", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_9", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_10", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_11", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_12", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_13", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_14", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_15", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_16", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_17", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_18", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_19", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_20", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_21", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_22", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_23", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_24", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_25", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_26", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_27", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_28", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_29", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_30", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_31", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_32", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_33", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_34", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_35", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_36", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_37", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_38", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_39", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_40", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_41", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_42", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_43", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_44", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_45", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_46", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_47", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_48", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_49", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_50", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_51", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_52", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_53", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_54", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_55", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_56", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_57", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_58", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_59", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_60", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_61", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_62", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_63", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_64", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_65", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_66", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_67", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_68", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_69", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_70", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_71", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_72", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_73", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_74", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_75", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_76", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_77", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_78", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_79", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_80", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_81", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_82", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_83", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_84", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_85", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_86", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_87", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_88", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_89", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_90", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_91", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_92", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_93", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_94", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_95", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_96", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_97", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_98", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_99", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_100", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_101", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_102", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_103", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_104", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_105", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_106", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_107", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_108", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_109", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_110", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_111", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_112", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_113", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_114", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_115", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_116", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_117", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_118", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_119", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_120", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_121", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_122", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_123", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_124", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_125", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_126", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_127", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_128", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_129", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_130", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_131", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_132", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_133", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_134", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_135", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_136", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_137", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_138", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_139", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_140", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_141", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_142", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_arriba0_143", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_trompa", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_cola", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_brocal", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_tapa_i", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_tapa_d", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_mantelete", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_0", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_1", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_2", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_3", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_4", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_5", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_6", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_7", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_8", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_9", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_10", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_11", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_ta", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_canon_tb", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_0", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_1", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_2", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_3", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_4", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_5", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_6", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_7", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_8", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_9", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_10", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_11", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_ta", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_evacuador_tb", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_0", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_1", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_2", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_3", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_4", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_5", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_6", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_7", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_8", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_9", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_10", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_11", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_ta", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_boca_tb", DatosModelo.CANON, 1.0F, -16.0F, 0.0F, 0.0F, 3.0F, -31.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F),
                new DatosModelo.Animada("torreta_antena", DatosModelo.TORRETA, 1.0F, 0.0F, 0.0F, 0.0F, 3.0F, 0.0F, 0.0F, "cuerpo", 0.0F, 0.0F, 0.0F, 0.0F)),
            ModeloMilitarTanque::crearCapa,
            16.0F,
            ModeloMilitarTanque::preparar,
            List.of(
                new DatosModelo.Segmento("cuerpo", 0.0F, 0.0F)));

    private ModeloMilitarTanque() {
    }

    public static LayerDefinition crearCapa() {
        MeshDefinition malla = new MeshDefinition();
        PartDefinition raiz = malla.getRoot();
        PartDefinition g0 = raiz.addOrReplaceChild("cuerpo", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g1 = raiz.addOrReplaceChild("direccion", CubeListBuilder.create(), PartPose.ZERO);
        PartDefinition g2 = raiz.addOrReplaceChild("volante", CubeListBuilder.create(), PartPose.ZERO);
        piezas0(g0);
        piezas1(g0);
        piezas2(g0);
        piezas3(g0);
        piezas4(g0);
        piezas5(g0);
        piezas6(g0);
        piezas7(g0);
        piezas8(g0);
        piezas9(g0);
        piezas10(g0);
        piezas11(g0);
        piezas12(g0);
        piezas13(g0);
        piezas14(g0);
        piezas15(g0);
        piezas16(g0);
        piezas17(g0);
        piezas18(g0);
        piezas19(g0);
        piezas20(g0);
        piezas21(g0);
        piezas22(g0);
        piezas23(g0);
        piezas24(g0);
        return LayerDefinition.create(malla, 1024, 512);
    }

    /** Aplica a cada placa su escala (se llama una vez, recién horneado el modelo). */
    public static void preparar(ModelPart raiz) {
        ModelPart g0 = raiz.getChild("cuerpo");
        ModelPart g1 = raiz.getChild("direccion");
        ModelPart g2 = raiz.getChild("volante");
        escalas0(g0, g1, g2);
        escalas1(g0, g1, g2);
        escalas2(g0, g1, g2);
        escalas3(g0, g1, g2);
        escalas4(g0, g1, g2);
        escalas5(g0, g1, g2);
        escalas6(g0, g1, g2);
        escalas7(g0, g1, g2);
        escalas8(g0, g1, g2);
        escalas9(g0, g1, g2);
        escalas10(g0, g1, g2);
        escalas11(g0, g1, g2);
        escalas12(g0, g1, g2);
        escalas13(g0, g1, g2);
        escalas14(g0, g1, g2);
    }

    private static void escalar(ModelPart grupo, String nombre, float x, float y, float z) {
        grupo.getChild(nombre).offsetScale(new Vector3f(x - 1.0F, y - 1.0F, z - 1.0F));
    }

    private static void piezas0(PartDefinition g) {
        g.addOrReplaceChild("oruga_i_0", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-37.870877915596346F, -16.998717372475838F, -17.0F, 0.0F, 0.0F, 3.115720150292878F));
        g.addOrReplaceChild("oruga_i_1", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-40.30678826556819F, -16.57640504204073F, -17.0F, 0.0F, 0.0F, 2.778611114731445F));
        g.addOrReplaceChild("oruga_i_2", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.40866186855317F, -15.275139128283897F, -17.0F, 0.0F, 0.0F, 2.3957633510558995F));
        g.addOrReplaceChild("oruga_i_3", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.87250040701619F, -13.283269202825922F, -17.0F, 0.0F, 0.0F, 2.0129156233384577F));
        g.addOrReplaceChild("oruga_i_4", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.486634275546876F, -10.889014232011396F, -17.0F, 0.0F, 0.0F, 1.6300679495558374F));
        g.addOrReplaceChild("oruga_i_5", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.16232709839016F, -8.438762184279533F, -17.0F, 0.0F, 0.0F, 1.2472203476819619F));
        g.addOrReplaceChild("oruga_i_6", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.946596315471766F, -6.2869613950410885F, -17.0F, 0.0F, 0.0F, 0.8643728356870348F));
        g.addOrReplaceChild("oruga_i_7", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-41.01539766125712F, -4.744851728608403F, -17.0F, 0.0F, 0.0F, 0.4855178011865842F));
        g.addOrReplaceChild("oruga_i_8", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-38.6988461118527F, -3.846227518469617F, -17.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_i_9", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-36.35745750556961F, -3.008041510158738F, -17.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_i_10", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-34.01606889928652F, -2.1698555018478576F, -17.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_i_11", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-31.67468029300343F, -1.3316694935369786F, -17.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_i_12", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-29.33329168672034F, -0.4934834852261001F, -17.0F, 0.0F, 0.0F, 0.325781570694527F));
        g.addOrReplaceChild("oruga_i_13", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-26.91263788279508F, 0.0F, -17.0F, 0.0F, 0.0F, 0.04592386344824236F));
        g.addOrReplaceChild("oruga_i_14", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-24.425740942799294F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_15", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-21.938844002803513F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_16", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-19.451947062807726F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_17", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-16.965050122811938F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_18", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-14.478153182816158F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_19", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-11.99125624282037F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_20", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-9.504359302824582F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_21", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-7.017462362828802F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_22", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-4.530565422833014F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_23", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-2.0436684828372265F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_24", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(0.4432284571585541F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_25", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(2.9301253971543417F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_26", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(5.417022337150129F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_27", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(7.903919277145917F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_28", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(10.390816217141705F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_29", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(12.877713157137478F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_30", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(15.364610097133266F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_31", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(17.851507037129053F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_32", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(20.33840397712484F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_33", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(22.82530091712063F, 0.0F, -17.0F));
        g.addOrReplaceChild("oruga_i_34", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(25.312197857116416F, 0.0F, -17.0F, 0.0F, 0.0F, -0.008998178557776555F));
        g.addOrReplaceChild("oruga_i_35", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(27.768452689361492F, -0.28880519600341337F, -17.0F, 0.0F, 0.0F, -0.2555784273446928F));
        g.addOrReplaceChild("oruga_i_36", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(30.148887596048453F, -1.0086566009381928F, -17.0F, 0.0F, 0.0F, -0.29366020881360094F));
        g.addOrReplaceChild("oruga_i_37", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(32.52932250273543F, -1.7285080058729763F, -17.0F, 0.0F, 0.0F, -0.29366020881360133F));
        g.addOrReplaceChild("oruga_i_38", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(34.909757409422404F, -2.4483594108077598F, -17.0F, 0.0F, 0.0F, -0.29366020881360144F));
        g.addOrReplaceChild("oruga_i_39", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(37.29019231610938F, -3.1682108157425435F, -17.0F, 0.0F, 0.0F, -0.29366020881360033F));
        g.addOrReplaceChild("oruga_i_40", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(39.66479681614288F, -3.9059883384371696F, -17.0F, 0.0F, 0.0F, -0.38800634341643897F));
        g.addOrReplaceChild("oruga_i_41", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(41.73462195897388F, -5.252154101997459F, -17.0F, 0.0F, 0.0F, -0.7830349663750497F));
        g.addOrReplaceChild("oruga_i_42", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.08676336449564F, -7.317955339105367F, -17.0F, 0.0F, 0.0F, -1.1975218898148323F));
        g.addOrReplaceChild("oruga_i_43", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.492180109317665F, -9.753311893931029F, -17.0F, 0.0F, 0.0F, -1.6120088570922866F));
        g.addOrReplaceChild("oruga_i_44", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(42.88225591682236F, -12.145557769116133F, -17.0F, 0.0F, 0.0F, -2.026495873753517F));
        g.addOrReplaceChild("oruga_i_45", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(41.36041175403498F, -14.089363870918339F, -17.0F, 0.0F, 0.0F, -2.4409829453434715F));
        g.addOrReplaceChild("oruga_i_46", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(39.18456991638542F, -15.25541210812608F, -17.0F, 0.0F, 0.0F, -2.8554700774057964F));
        g.addOrReplaceChild("oruga_i_47", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(36.721308303669566F, -15.516655911294347F, -17.0F, 0.0F, 0.0F, -3.1172572015550166F));
        g.addOrReplaceChild("oruga_i_48", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(34.23490209636071F, -15.566057960000396F, -17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_49", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(31.748495889051846F, -15.615460008706446F, -17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_50", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(29.26208968174298F, -15.664862057412495F, -17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_51", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(26.775683474434118F, -15.714264106118545F, -17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_52", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(24.28927726712525F, -15.763666154824595F, -17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_i_53", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(21.802871059816397F, -15.813068203530644F, -17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_i_54", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(19.31646485250752F, -15.862470252236694F, -17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_55", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(16.83005864519867F, -15.911872300942743F, -17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_56", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(14.343652437889787F, -15.961274349648793F, -17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_i_57", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(11.857246230580937F, -16.010676398354843F, -17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_i_58", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(9.370840023272088F, -16.060078447060892F, -17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_i_59", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(6.884433815963206F, -16.10948049576694F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_60", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(4.398027608654353F, -16.15888254447299F, -17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_i_61", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(1.911621401345478F, -16.20828459317904F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_62", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-0.5747848059633753F, -16.25768664188509F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_63", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-3.061191013272257F, -16.30708869059114F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_64", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-5.547597220581103F, -16.35649073929719F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_65", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-8.034003427889957F, -16.40589278800324F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_66", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-10.520409635198838F, -16.455294836709292F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_67", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-13.006815842507685F, -16.504696885415342F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_68", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-15.493222049816566F, -16.55409893412139F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_69", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-17.97962825712542F, -16.60350098282744F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_70", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-20.4660344644343F, -16.65290303153349F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_71", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-22.952440671743148F, -16.70230508023954F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_72", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-25.438846879052F, -16.75170712894559F, -17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_i_73", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-27.925253086360875F, -16.80110917765164F, -17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_i_74", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-30.411659293669736F, -16.85051122635769F, -17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_i_75", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-32.89806550097861F, -16.89991327506374F, -17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_i_76", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-35.38447170828746F, -16.949315323769788F, -17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("rodillo_i0_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-27.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i0_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i0_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_i0_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i0_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-27.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i1_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-16.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i1_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i1_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_i1_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i1_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-16.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i2_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-5.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i2_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i2_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
    }

    private static void piezas1(PartDefinition g) {
        g.addOrReplaceChild("rodillo_i2_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i2_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-5.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i3_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(4.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i3_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i3_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_i3_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i3_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(4.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i4_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(15.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i4_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i4_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_i4_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i4_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(15.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i5_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(660, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(282, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(26.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_i5_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(666, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(286, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_i5_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(672, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(290, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_i5_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, -19.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, -19.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(678, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(294, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_i5_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, -19.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(26.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("motriz_i_0", CubeListBuilder.create().texOffs(740, 184).addBox(-5.5F, -1.0F, -19.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(900, 109).addBox(-1.0F, -5.5F, -19.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(-38.0F, -10.5F, 0.0F));
        g.addOrReplaceChild("motriz_i_1", CubeListBuilder.create().texOffs(770, 184).addBox(-5.5F, -1.0F, -19.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(912, 109).addBox(-1.0F, -5.5F, -19.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("motriz_i_2", CubeListBuilder.create().texOffs(800, 184).addBox(-5.5F, -1.0F, -19.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(924, 109).addBox(-1.0F, -5.5F, -19.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("motriz_i_3", CubeListBuilder.create().texOffs(830, 184).addBox(-5.5F, -1.0F, -19.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(936, 109).addBox(-1.0F, -5.5F, -19.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("motriz_i_cara", CubeListBuilder.create().texOffs(0, 109).addBox(-16.5F, -16.5F, -19.0F, 33.0F, 33.0F, 4.0F), PartPose.offset(-38.0F, -10.5F, 0.0F));
        g.addOrReplaceChild("tensora_i_0", CubeListBuilder.create().texOffs(860, 184).addBox(-5.0F, -1.0F, -19.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(948, 109).addBox(-1.0F, -5.0F, -19.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(684, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(298, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(37.5F, -9.5F, 0.0F));
        g.addOrReplaceChild("tensora_i_1", CubeListBuilder.create().texOffs(888, 184).addBox(-5.0F, -1.0F, -19.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(960, 109).addBox(-1.0F, -5.0F, -19.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(690, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(302, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("tensora_i_2", CubeListBuilder.create().texOffs(916, 184).addBox(-5.0F, -1.0F, -19.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(972, 109).addBox(-1.0F, -5.0F, -19.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(696, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(306, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("tensora_i_3", CubeListBuilder.create().texOffs(944, 184).addBox(-5.0F, -1.0F, -19.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(984, 109).addBox(-1.0F, -5.0F, -19.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(702, 263).addBox(-1.0F, -0.5F, -20.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(310, 256).addBox(-0.5F, -1.0F, -20.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("tensora_i_cara", CubeListBuilder.create().texOffs(74, 109).addBox(-15.0F, -15.0F, -19.0F, 30.0F, 30.0F, 4.0F), PartPose.offset(37.5F, -9.5F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_i0_0", CubeListBuilder.create().texOffs(360, 244).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(100, 223).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(-12.0F, -13.983443708609272F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_i0_1", CubeListBuilder.create().texOffs(370, 244).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(106, 223).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_alto_i0_2", CubeListBuilder.create().texOffs(380, 244).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(112, 223).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_alto_i0_3", CubeListBuilder.create().texOffs(390, 244).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(118, 223).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_alto_i0_cara", CubeListBuilder.create().texOffs(616, 146).addBox(-4.5F, -4.5F, -18.0F, 9.0F, 9.0F, 2.0F), PartPose.offset(-12.0F, -13.983443708609272F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_i1_0", CubeListBuilder.create().texOffs(360, 244).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(100, 223).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(12.0F, -13.506622516556291F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_i1_1", CubeListBuilder.create().texOffs(370, 244).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(106, 223).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_alto_i1_2", CubeListBuilder.create().texOffs(380, 244).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(112, 223).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_alto_i1_3", CubeListBuilder.create().texOffs(390, 244).addBox(-1.5F, -0.5F, -18.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(118, 223).addBox(-0.5F, -1.5F, -18.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_alto_i1_cara", CubeListBuilder.create().texOffs(616, 146).addBox(-4.5F, -4.5F, -18.0F, 9.0F, 9.0F, 2.0F), PartPose.offset(12.0F, -13.506622516556291F, 0.0F));
        g.addOrReplaceChild("oruga_d_0", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-37.870877915596346F, -16.998717372475838F, 17.0F, 0.0F, 0.0F, 3.115720150292878F));
        g.addOrReplaceChild("oruga_d_1", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-40.30678826556819F, -16.57640504204073F, 17.0F, 0.0F, 0.0F, 2.778611114731445F));
        g.addOrReplaceChild("oruga_d_2", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.40866186855317F, -15.275139128283897F, 17.0F, 0.0F, 0.0F, 2.3957633510558995F));
        g.addOrReplaceChild("oruga_d_3", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.87250040701619F, -13.283269202825922F, 17.0F, 0.0F, 0.0F, 2.0129156233384577F));
        g.addOrReplaceChild("oruga_d_4", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.486634275546876F, -10.889014232011396F, 17.0F, 0.0F, 0.0F, 1.6300679495558374F));
        g.addOrReplaceChild("oruga_d_5", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.16232709839016F, -8.438762184279533F, 17.0F, 0.0F, 0.0F, 1.2472203476819619F));
        g.addOrReplaceChild("oruga_d_6", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.946596315471766F, -6.2869613950410885F, 17.0F, 0.0F, 0.0F, 0.8643728356870348F));
        g.addOrReplaceChild("oruga_d_7", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-41.01539766125712F, -4.744851728608403F, 17.0F, 0.0F, 0.0F, 0.4855178011865842F));
        g.addOrReplaceChild("oruga_d_8", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-38.6988461118527F, -3.846227518469617F, 17.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_d_9", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-36.35745750556961F, -3.008041510158738F, 17.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_d_10", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-34.01606889928652F, -2.1698555018478576F, 17.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_d_11", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-31.67468029300343F, -1.3316694935369786F, 17.0F, 0.0F, 0.0F, 0.3437721363240482F));
        g.addOrReplaceChild("oruga_d_12", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-29.33329168672034F, -0.4934834852261001F, 17.0F, 0.0F, 0.0F, 0.325781570694527F));
        g.addOrReplaceChild("oruga_d_13", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-26.91263788279508F, 0.0F, 17.0F, 0.0F, 0.0F, 0.04592386344824236F));
        g.addOrReplaceChild("oruga_d_14", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-24.425740942799294F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_15", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-21.938844002803513F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_16", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-19.451947062807726F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_17", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-16.965050122811938F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_18", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-14.478153182816158F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_19", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-11.99125624282037F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_20", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-9.504359302824582F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_21", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-7.017462362828802F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_22", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-4.530565422833014F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_23", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(-2.0436684828372265F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_24", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(0.4432284571585541F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_25", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(2.9301253971543417F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_26", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(5.417022337150129F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_27", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(7.903919277145917F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_28", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(10.390816217141705F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_29", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(12.877713157137478F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_30", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(15.364610097133266F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_31", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(17.851507037129053F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_32", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(20.33840397712484F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_33", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offset(22.82530091712063F, 0.0F, 17.0F));
        g.addOrReplaceChild("oruga_d_34", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(25.312197857116416F, 0.0F, 17.0F, 0.0F, 0.0F, -0.008998178557776555F));
        g.addOrReplaceChild("oruga_d_35", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(27.768452689361492F, -0.28880519600341337F, 17.0F, 0.0F, 0.0F, -0.2555784273446928F));
        g.addOrReplaceChild("oruga_d_36", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(30.148887596048453F, -1.0086566009381928F, 17.0F, 0.0F, 0.0F, -0.29366020881360094F));
        g.addOrReplaceChild("oruga_d_37", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(32.52932250273543F, -1.7285080058729763F, 17.0F, 0.0F, 0.0F, -0.29366020881360133F));
        g.addOrReplaceChild("oruga_d_38", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(34.909757409422404F, -2.4483594108077598F, 17.0F, 0.0F, 0.0F, -0.29366020881360144F));
        g.addOrReplaceChild("oruga_d_39", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(37.29019231610938F, -3.1682108157425435F, 17.0F, 0.0F, 0.0F, -0.29366020881360033F));
        g.addOrReplaceChild("oruga_d_40", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(39.66479681614288F, -3.9059883384371696F, 17.0F, 0.0F, 0.0F, -0.38800634341643897F));
        g.addOrReplaceChild("oruga_d_41", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(41.73462195897388F, -5.252154101997459F, 17.0F, 0.0F, 0.0F, -0.7830349663750497F));
        g.addOrReplaceChild("oruga_d_42", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.08676336449564F, -7.317955339105367F, 17.0F, 0.0F, 0.0F, -1.1975218898148323F));
        g.addOrReplaceChild("oruga_d_43", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(43.492180109317665F, -9.753311893931029F, 17.0F, 0.0F, 0.0F, -1.6120088570922866F));
        g.addOrReplaceChild("oruga_d_44", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(42.88225591682236F, -12.145557769116133F, 17.0F, 0.0F, 0.0F, -2.026495873753517F));
        g.addOrReplaceChild("oruga_d_45", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(41.36041175403498F, -14.089363870918339F, 17.0F, 0.0F, 0.0F, -2.4409829453434715F));
        g.addOrReplaceChild("oruga_d_46", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(39.18456991638542F, -15.25541210812608F, 17.0F, 0.0F, 0.0F, -2.8554700774057964F));
        g.addOrReplaceChild("oruga_d_47", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(36.721308303669566F, -15.516655911294347F, 17.0F, 0.0F, 0.0F, -3.1172572015550166F));
        g.addOrReplaceChild("oruga_d_48", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(34.23490209636071F, -15.566057960000396F, 17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_49", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(31.748495889051846F, -15.615460008706446F, 17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_50", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(29.26208968174298F, -15.664862057412495F, 17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_51", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(26.775683474434118F, -15.714264106118545F, 17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_52", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(24.28927726712525F, -15.763666154824595F, 17.0F, 0.0F, 0.0F, -3.1217264107930762F));
    }

    private static void piezas2(PartDefinition g) {
        g.addOrReplaceChild("oruga_d_53", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(21.802871059816397F, -15.813068203530644F, 17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_d_54", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(19.31646485250752F, -15.862470252236694F, 17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_55", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(16.83005864519867F, -15.911872300942743F, 17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_56", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(14.343652437889787F, -15.961274349648793F, 17.0F, 0.0F, 0.0F, -3.1217264107930753F));
        g.addOrReplaceChild("oruga_d_57", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(11.857246230580937F, -16.010676398354843F, 17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_d_58", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(9.370840023272088F, -16.060078447060892F, 17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_d_59", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(6.884433815963206F, -16.10948049576694F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_60", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(4.398027608654353F, -16.15888254447299F, 17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_d_61", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(1.911621401345478F, -16.20828459317904F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_62", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-0.5747848059633753F, -16.25768664188509F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_63", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-3.061191013272257F, -16.30708869059114F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_64", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-5.547597220581103F, -16.35649073929719F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_65", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-8.034003427889957F, -16.40589278800324F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_66", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-10.520409635198838F, -16.455294836709292F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_67", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-13.006815842507685F, -16.504696885415342F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_68", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-15.493222049816566F, -16.55409893412139F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_69", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-17.97962825712542F, -16.60350098282744F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_70", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-20.4660344644343F, -16.65290303153349F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_71", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-22.952440671743148F, -16.70230508023954F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_72", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-25.438846879052F, -16.75170712894559F, 17.0F, 0.0F, 0.0F, -3.121726410793075F));
        g.addOrReplaceChild("oruga_d_73", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-27.925253086360875F, -16.80110917765164F, 17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_d_74", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-30.411659293669736F, -16.85051122635769F, 17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_d_75", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-32.89806550097861F, -16.89991327506374F, 17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("oruga_d_76", CubeListBuilder.create().texOffs(718, 146).addBox(-1.5F, -1.0F, -4.0F, 3.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-35.38447170828746F, -16.949315323769788F, 17.0F, 0.0F, 0.0F, -3.1217264107930762F));
        g.addOrReplaceChild("rodillo_d0_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-27.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d0_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_d0_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d0_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-27.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d0_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-27.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d1_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-16.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d1_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_d1_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d1_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-16.4F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d1_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-16.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d2_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(-5.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d2_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_d2_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d2_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(-5.8F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d2_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(-5.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d3_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(4.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d3_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_d3_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d3_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(4.8F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d3_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(4.8F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d4_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(15.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d4_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_d4_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d4_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(15.4F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d4_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(15.4F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d5_0", CubeListBuilder.create().texOffs(972, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(288, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(708, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(314, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(26.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("rodillo_d5_1", CubeListBuilder.create().texOffs(998, 184).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(300, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(714, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(318, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_d5_2", CubeListBuilder.create().texOffs(0, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(312, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(720, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(322, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_d5_3", CubeListBuilder.create().texOffs(26, 192).addBox(-4.5F, -1.0F, 15.0F, 9.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(324, 146).addBox(-1.0F, -4.5F, 15.0F, 2.0F, 9.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(726, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(326, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(26.0F, -5.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_d5_cara", CubeListBuilder.create().texOffs(398, 109).addBox(-13.5F, -13.5F, 15.0F, 27.0F, 27.0F, 4.0F), PartPose.offset(26.0F, -5.5F, 0.0F));
        g.addOrReplaceChild("motriz_d_0", CubeListBuilder.create().texOffs(740, 184).addBox(-5.5F, -1.0F, 15.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(900, 109).addBox(-1.0F, -5.5F, 15.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(-38.0F, -10.5F, 0.0F));
        g.addOrReplaceChild("motriz_d_1", CubeListBuilder.create().texOffs(770, 184).addBox(-5.5F, -1.0F, 15.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(912, 109).addBox(-1.0F, -5.5F, 15.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("motriz_d_2", CubeListBuilder.create().texOffs(800, 184).addBox(-5.5F, -1.0F, 15.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(924, 109).addBox(-1.0F, -5.5F, 15.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("motriz_d_3", CubeListBuilder.create().texOffs(830, 184).addBox(-5.5F, -1.0F, 15.0F, 11.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(936, 109).addBox(-1.0F, -5.5F, 15.0F, 2.0F, 11.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-38.0F, -10.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("motriz_d_cara", CubeListBuilder.create().texOffs(0, 109).addBox(-16.5F, -16.5F, 15.0F, 33.0F, 33.0F, 4.0F), PartPose.offset(-38.0F, -10.5F, 0.0F));
        g.addOrReplaceChild("tensora_d_0", CubeListBuilder.create().texOffs(860, 184).addBox(-5.0F, -1.0F, 15.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(948, 109).addBox(-1.0F, -5.0F, 15.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(732, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.027F)).texOffs(330, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.03F)), PartPose.offset(37.5F, -9.5F, 0.0F));
        g.addOrReplaceChild("tensora_d_1", CubeListBuilder.create().texOffs(888, 184).addBox(-5.0F, -1.0F, 15.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(960, 109).addBox(-1.0F, -5.0F, 15.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(738, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.033F)).texOffs(334, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.036000000000000004F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("tensora_d_2", CubeListBuilder.create().texOffs(916, 184).addBox(-5.0F, -1.0F, 15.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(972, 109).addBox(-1.0F, -5.0F, 15.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(744, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.039F)).texOffs(338, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.042F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("tensora_d_3", CubeListBuilder.create().texOffs(944, 184).addBox(-5.0F, -1.0F, 15.0F, 10.0F, 2.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(984, 109).addBox(-1.0F, -5.0F, 15.0F, 2.0F, 10.0F, 4.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(750, 263).addBox(-1.0F, -0.5F, 19.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.045F)).texOffs(342, 256).addBox(-0.5F, -1.0F, 19.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F, 0.0F, 0.048F)), PartPose.offsetAndRotation(37.5F, -9.5F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("tensora_d_cara", CubeListBuilder.create().texOffs(74, 109).addBox(-15.0F, -15.0F, 15.0F, 30.0F, 30.0F, 4.0F), PartPose.offset(37.5F, -9.5F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_d0_0", CubeListBuilder.create().texOffs(360, 244).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(100, 223).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(-12.0F, -13.983443708609272F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_d0_1", CubeListBuilder.create().texOffs(370, 244).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(106, 223).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_alto_d0_2", CubeListBuilder.create().texOffs(380, 244).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(112, 223).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_alto_d0_3", CubeListBuilder.create().texOffs(390, 244).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(118, 223).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(-12.0F, -13.983443708609272F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_alto_d0_cara", CubeListBuilder.create().texOffs(616, 146).addBox(-4.5F, -4.5F, 16.0F, 9.0F, 9.0F, 2.0F), PartPose.offset(-12.0F, -13.983443708609272F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_d1_0", CubeListBuilder.create().texOffs(360, 244).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(100, 223).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offset(12.0F, -13.506622516556291F, 0.0F));
        g.addOrReplaceChild("rodillo_alto_d1_1", CubeListBuilder.create().texOffs(370, 244).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(106, 223).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 0.39269908169872414F));
        g.addOrReplaceChild("rodillo_alto_d1_2", CubeListBuilder.create().texOffs(380, 244).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(112, 223).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 0.7853981633974483F));
        g.addOrReplaceChild("rodillo_alto_d1_3", CubeListBuilder.create().texOffs(390, 244).addBox(-1.5F, -0.5F, 16.0F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)).texOffs(118, 223).addBox(-0.5F, -1.5F, 16.0F, 1.0F, 3.0F, 2.0F, new CubeDeformation(0.0F, 0.0F, -0.08F)), PartPose.offsetAndRotation(12.0F, -13.506622516556291F, 0.0F, 0.0F, 0.0F, 1.1780972450961724F));
        g.addOrReplaceChild("rodillo_alto_d1_cara", CubeListBuilder.create().texOffs(616, 146).addBox(-4.5F, -4.5F, 16.0F, 9.0F, 9.0F, 2.0F), PartPose.offset(12.0F, -13.506622516556291F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_0", CubeListBuilder.create().texOffs(824, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.875F, -11.826562500000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_1", CubeListBuilder.create().texOffs(830, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -11.649375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_2", CubeListBuilder.create().texOffs(836, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -11.334375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_3", CubeListBuilder.create().texOffs(842, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -10.861875F, -12.5F, -1.5707963267948966F, 0.0F, 0.33353619044595795F));
        g.addOrReplaceChild("casco_bajo_ladoi_4", CubeListBuilder.create().texOffs(316, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -10.231874999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.3335361904459575F));
        g.addOrReplaceChild("casco_bajo_ladoi_5", CubeListBuilder.create().texOffs(326, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -9.444374999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.3335361904459579F));
        g.addOrReplaceChild("casco_bajo_ladoi_6", CubeListBuilder.create().texOffs(336, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -8.499374999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.33353619044595756F));
        g.addOrReplaceChild("casco_bajo_ladoi_7", CubeListBuilder.create().texOffs(52, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -6.80625F, -12.5F, -1.5707963267948966F, 0.0F, 0.266748799411795F));
        g.addOrReplaceChild("casco_bajo_ladoi_8", CubeListBuilder.create().texOffs(340, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_9", CubeListBuilder.create().texOffs(356, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_10", CubeListBuilder.create().texOffs(372, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_11", CubeListBuilder.create().texOffs(388, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_12", CubeListBuilder.create().texOffs(404, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_13", CubeListBuilder.create().texOffs(420, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_14", CubeListBuilder.create().texOffs(436, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_15", CubeListBuilder.create().texOffs(452, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
    }

    private static void piezas3(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladoi_16", CubeListBuilder.create().texOffs(468, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_17", CubeListBuilder.create().texOffs(484, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_18", CubeListBuilder.create().texOffs(500, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_19", CubeListBuilder.create().texOffs(516, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_20", CubeListBuilder.create().texOffs(532, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_21", CubeListBuilder.create().texOffs(548, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_22", CubeListBuilder.create().texOffs(564, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_23", CubeListBuilder.create().texOffs(580, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_24", CubeListBuilder.create().texOffs(596, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -5.625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_25", CubeListBuilder.create().texOffs(70, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -6.01875F, -12.5F, -1.5707963267948966F, 0.0F, -0.09719447717873991F));
        g.addOrReplaceChild("casco_bajo_ladoi_26", CubeListBuilder.create().texOffs(252, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -6.9243749999999995F, -12.5F, -1.5707963267948966F, 0.0F, -0.33353619044595756F));
        g.addOrReplaceChild("casco_bajo_ladoi_27", CubeListBuilder.create().texOffs(346, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -7.869375000000002F, -12.5F, -1.5707963267948966F, 0.0F, -0.33353619044595784F));
        g.addOrReplaceChild("casco_bajo_ladoi_28", CubeListBuilder.create().texOffs(356, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -8.656875000000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_29", CubeListBuilder.create().texOffs(876, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -9.286874999999998F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_30", CubeListBuilder.create().texOffs(884, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -9.759374999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_31", CubeListBuilder.create().texOffs(892, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -10.074375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_32", CubeListBuilder.create().texOffs(848, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(41.875F, -10.251562500000002F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_33", CubeListBuilder.create().texOffs(854, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -13.178125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_34", CubeListBuilder.create().texOffs(860, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -12.953125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_35", CubeListBuilder.create().texOffs(866, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -12.615625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_36", CubeListBuilder.create().texOffs(366, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -12.165625F, -12.5F, -1.5707963267948966F, 0.0F, 0.25619473015536864F));
        g.addOrReplaceChild("casco_bajo_ladoi_37", CubeListBuilder.create().texOffs(376, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -11.603124999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.2561947301553689F));
        g.addOrReplaceChild("casco_bajo_ladoi_38", CubeListBuilder.create().texOffs(386, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -10.928125F, -12.5F, -1.5707963267948966F, 0.0F, 0.25619473015536864F));
        g.addOrReplaceChild("casco_bajo_ladoi_39", CubeListBuilder.create().texOffs(88, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -9.71875F, -12.5F, -1.5707963267948966F, 0.0F, 0.19961038478762638F));
        g.addOrReplaceChild("casco_bajo_ladoi_40", CubeListBuilder.create().texOffs(612, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_41", CubeListBuilder.create().texOffs(628, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_42", CubeListBuilder.create().texOffs(644, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_43", CubeListBuilder.create().texOffs(660, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_44", CubeListBuilder.create().texOffs(676, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_45", CubeListBuilder.create().texOffs(692, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_46", CubeListBuilder.create().texOffs(708, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_47", CubeListBuilder.create().texOffs(724, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_48", CubeListBuilder.create().texOffs(740, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_49", CubeListBuilder.create().texOffs(756, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_50", CubeListBuilder.create().texOffs(772, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_51", CubeListBuilder.create().texOffs(788, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_52", CubeListBuilder.create().texOffs(804, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_53", CubeListBuilder.create().texOffs(820, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_54", CubeListBuilder.create().texOffs(836, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_55", CubeListBuilder.create().texOffs(852, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_56", CubeListBuilder.create().texOffs(868, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -8.875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_57", CubeListBuilder.create().texOffs(106, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -9.15625F, -12.5F, -1.5707963267948966F, 0.0F, -0.06985443714458175F));
        g.addOrReplaceChild("casco_bajo_ladoi_58", CubeListBuilder.create().texOffs(264, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -9.803125F, -12.5F, -1.5707963267948966F, 0.0F, -0.2561947301553691F));
        g.addOrReplaceChild("casco_bajo_ladoi_59", CubeListBuilder.create().texOffs(396, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -10.478125000000002F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_60", CubeListBuilder.create().texOffs(406, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -11.040625000000002F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_61", CubeListBuilder.create().texOffs(900, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -11.490625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_62", CubeListBuilder.create().texOffs(908, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -11.828125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_63", CubeListBuilder.create().texOffs(916, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -12.053125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_64", CubeListBuilder.create().texOffs(872, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -14.706875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_65", CubeListBuilder.create().texOffs(878, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -14.571874999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_66", CubeListBuilder.create().texOffs(884, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -14.369375000000002F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_67", CubeListBuilder.create().texOffs(924, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -14.099374999999998F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_68", CubeListBuilder.create().texOffs(416, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -13.761875F, -12.5F, -1.5707963267948966F, 0.0F, 0.16274792761823909F));
        g.addOrReplaceChild("casco_bajo_ladoi_69", CubeListBuilder.create().texOffs(426, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -13.356874999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.16274792761823867F));
        g.addOrReplaceChild("casco_bajo_ladoi_70", CubeListBuilder.create().texOffs(124, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -12.631250000000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.1239588350472593F));
        g.addOrReplaceChild("casco_bajo_ladoi_71", CubeListBuilder.create().texOffs(884, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_72", CubeListBuilder.create().texOffs(900, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_73", CubeListBuilder.create().texOffs(916, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_74", CubeListBuilder.create().texOffs(932, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_75", CubeListBuilder.create().texOffs(948, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_76", CubeListBuilder.create().texOffs(964, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_77", CubeListBuilder.create().texOffs(980, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_78", CubeListBuilder.create().texOffs(996, 192).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_79", CubeListBuilder.create().texOffs(0, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_80", CubeListBuilder.create().texOffs(16, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_81", CubeListBuilder.create().texOffs(32, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_82", CubeListBuilder.create().texOffs(48, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_83", CubeListBuilder.create().texOffs(64, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_84", CubeListBuilder.create().texOffs(80, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_85", CubeListBuilder.create().texOffs(96, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_86", CubeListBuilder.create().texOffs(112, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_87", CubeListBuilder.create().texOffs(128, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -12.125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_88", CubeListBuilder.create().texOffs(142, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -12.293750000000001F, -12.5F, -1.5707963267948966F, 0.0F, -0.04208781255313887F));
        g.addOrReplaceChild("casco_bajo_ladoi_89", CubeListBuilder.create().texOffs(276, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -12.681874999999998F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_90", CubeListBuilder.create().texOffs(436, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -13.086875000000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_91", CubeListBuilder.create().texOffs(932, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -13.424375000000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_92", CubeListBuilder.create().texOffs(940, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -13.694374999999999F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_93", CubeListBuilder.create().texOffs(948, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -13.896875000000001F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_94", CubeListBuilder.create().texOffs(956, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -14.031875F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_95", CubeListBuilder.create().texOffs(890, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -16.235625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_96", CubeListBuilder.create().texOffs(896, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -16.190625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_97", CubeListBuilder.create().texOffs(902, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -16.123125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_98", CubeListBuilder.create().texOffs(964, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -16.033125000000002F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_99", CubeListBuilder.create().texOffs(446, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -15.920625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_100", CubeListBuilder.create().texOffs(456, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -15.785625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0560144812129938F));
        g.addOrReplaceChild("casco_bajo_ladoi_101", CubeListBuilder.create().texOffs(160, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -15.54375F, -12.5F, -1.5707963267948966F, 0.0F, 0.04208781255313902F));
        g.addOrReplaceChild("casco_bajo_ladoi_102", CubeListBuilder.create().texOffs(144, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_103", CubeListBuilder.create().texOffs(160, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_104", CubeListBuilder.create().texOffs(176, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_105", CubeListBuilder.create().texOffs(192, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
    }

    private static void piezas4(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladoi_106", CubeListBuilder.create().texOffs(208, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_107", CubeListBuilder.create().texOffs(224, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_108", CubeListBuilder.create().texOffs(240, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_109", CubeListBuilder.create().texOffs(256, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_110", CubeListBuilder.create().texOffs(272, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_111", CubeListBuilder.create().texOffs(288, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_112", CubeListBuilder.create().texOffs(304, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_113", CubeListBuilder.create().texOffs(320, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_114", CubeListBuilder.create().texOffs(336, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_115", CubeListBuilder.create().texOffs(352, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_116", CubeListBuilder.create().texOffs(368, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_117", CubeListBuilder.create().texOffs(384, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_118", CubeListBuilder.create().texOffs(400, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -15.375F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_119", CubeListBuilder.create().texOffs(178, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -15.43125F, -12.5F, -1.5707963267948966F, 0.0F, -0.014058793873061365F));
        g.addOrReplaceChild("casco_bajo_ladoi_120", CubeListBuilder.create().texOffs(288, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -15.560625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_121", CubeListBuilder.create().texOffs(466, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -15.695625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_122", CubeListBuilder.create().texOffs(972, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -15.808125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_123", CubeListBuilder.create().texOffs(980, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -15.898125F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_124", CubeListBuilder.create().texOffs(988, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -15.965625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_125", CubeListBuilder.create().texOffs(996, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -16.010625F, -12.5F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_126", CubeListBuilder.create().texOffs(288, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_127", CubeListBuilder.create().texOffs(292, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_128", CubeListBuilder.create().texOffs(296, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_129", CubeListBuilder.create().texOffs(300, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_130", CubeListBuilder.create().texOffs(756, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_131", CubeListBuilder.create().texOffs(762, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_132", CubeListBuilder.create().texOffs(838, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_133", CubeListBuilder.create().texOffs(848, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_134", CubeListBuilder.create().texOffs(858, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_135", CubeListBuilder.create().texOffs(868, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_136", CubeListBuilder.create().texOffs(878, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_137", CubeListBuilder.create().texOffs(888, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_138", CubeListBuilder.create().texOffs(898, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_139", CubeListBuilder.create().texOffs(908, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_140", CubeListBuilder.create().texOffs(918, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_141", CubeListBuilder.create().texOffs(928, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_142", CubeListBuilder.create().texOffs(938, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_143", CubeListBuilder.create().texOffs(948, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_144", CubeListBuilder.create().texOffs(958, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_145", CubeListBuilder.create().texOffs(968, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_146", CubeListBuilder.create().texOffs(978, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_147", CubeListBuilder.create().texOffs(988, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_148", CubeListBuilder.create().texOffs(998, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_149", CubeListBuilder.create().texOffs(1008, 256).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_150", CubeListBuilder.create().texOffs(0, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_151", CubeListBuilder.create().texOffs(768, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_152", CubeListBuilder.create().texOffs(774, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_153", CubeListBuilder.create().texOffs(304, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_154", CubeListBuilder.create().texOffs(308, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_155", CubeListBuilder.create().texOffs(312, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_156", CubeListBuilder.create().texOffs(316, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.191341716182546F, -12.461939766255643F, -1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_157", CubeListBuilder.create().texOffs(320, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_158", CubeListBuilder.create().texOffs(324, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_159", CubeListBuilder.create().texOffs(328, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_160", CubeListBuilder.create().texOffs(332, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_161", CubeListBuilder.create().texOffs(780, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_162", CubeListBuilder.create().texOffs(786, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_163", CubeListBuilder.create().texOffs(10, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_164", CubeListBuilder.create().texOffs(20, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_165", CubeListBuilder.create().texOffs(30, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_166", CubeListBuilder.create().texOffs(40, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_167", CubeListBuilder.create().texOffs(50, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_168", CubeListBuilder.create().texOffs(60, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_169", CubeListBuilder.create().texOffs(70, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_170", CubeListBuilder.create().texOffs(80, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_171", CubeListBuilder.create().texOffs(90, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_172", CubeListBuilder.create().texOffs(100, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_173", CubeListBuilder.create().texOffs(110, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_174", CubeListBuilder.create().texOffs(120, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_175", CubeListBuilder.create().texOffs(130, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_176", CubeListBuilder.create().texOffs(140, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_177", CubeListBuilder.create().texOffs(150, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_178", CubeListBuilder.create().texOffs(160, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_179", CubeListBuilder.create().texOffs(170, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_180", CubeListBuilder.create().texOffs(180, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_181", CubeListBuilder.create().texOffs(190, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_182", CubeListBuilder.create().texOffs(792, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_183", CubeListBuilder.create().texOffs(798, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_184", CubeListBuilder.create().texOffs(336, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_185", CubeListBuilder.create().texOffs(340, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_186", CubeListBuilder.create().texOffs(344, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_187", CubeListBuilder.create().texOffs(348, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.54489510677582F, -12.315493156848916F, -2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_188", CubeListBuilder.create().texOffs(352, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_189", CubeListBuilder.create().texOffs(356, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_190", CubeListBuilder.create().texOffs(360, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_191", CubeListBuilder.create().texOffs(364, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_192", CubeListBuilder.create().texOffs(804, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_193", CubeListBuilder.create().texOffs(810, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_194", CubeListBuilder.create().texOffs(200, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_195", CubeListBuilder.create().texOffs(210, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
    }

    private static void piezas5(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladoi_196", CubeListBuilder.create().texOffs(220, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_197", CubeListBuilder.create().texOffs(230, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_198", CubeListBuilder.create().texOffs(240, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_199", CubeListBuilder.create().texOffs(250, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_200", CubeListBuilder.create().texOffs(260, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_201", CubeListBuilder.create().texOffs(270, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_202", CubeListBuilder.create().texOffs(280, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_203", CubeListBuilder.create().texOffs(290, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_204", CubeListBuilder.create().texOffs(300, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_205", CubeListBuilder.create().texOffs(310, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_206", CubeListBuilder.create().texOffs(320, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_207", CubeListBuilder.create().texOffs(330, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_208", CubeListBuilder.create().texOffs(340, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_209", CubeListBuilder.create().texOffs(350, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_210", CubeListBuilder.create().texOffs(360, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_211", CubeListBuilder.create().texOffs(370, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_212", CubeListBuilder.create().texOffs(380, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_213", CubeListBuilder.create().texOffs(816, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_214", CubeListBuilder.create().texOffs(822, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_215", CubeListBuilder.create().texOffs(368, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_216", CubeListBuilder.create().texOffs(372, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_217", CubeListBuilder.create().texOffs(376, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_218", CubeListBuilder.create().texOffs(380, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.815493156848916F, -12.044895106775819F, -2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_219", CubeListBuilder.create().texOffs(384, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_220", CubeListBuilder.create().texOffs(388, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_221", CubeListBuilder.create().texOffs(392, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_222", CubeListBuilder.create().texOffs(396, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_223", CubeListBuilder.create().texOffs(828, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_224", CubeListBuilder.create().texOffs(834, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_225", CubeListBuilder.create().texOffs(390, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_226", CubeListBuilder.create().texOffs(400, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_227", CubeListBuilder.create().texOffs(410, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_228", CubeListBuilder.create().texOffs(420, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_229", CubeListBuilder.create().texOffs(430, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_230", CubeListBuilder.create().texOffs(440, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_231", CubeListBuilder.create().texOffs(450, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_232", CubeListBuilder.create().texOffs(460, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_233", CubeListBuilder.create().texOffs(470, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_234", CubeListBuilder.create().texOffs(480, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_235", CubeListBuilder.create().texOffs(490, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_236", CubeListBuilder.create().texOffs(500, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_237", CubeListBuilder.create().texOffs(510, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_238", CubeListBuilder.create().texOffs(520, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_239", CubeListBuilder.create().texOffs(530, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_240", CubeListBuilder.create().texOffs(540, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_241", CubeListBuilder.create().texOffs(550, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_242", CubeListBuilder.create().texOffs(560, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_243", CubeListBuilder.create().texOffs(570, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_244", CubeListBuilder.create().texOffs(840, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_245", CubeListBuilder.create().texOffs(846, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_246", CubeListBuilder.create().texOffs(400, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_247", CubeListBuilder.create().texOffs(404, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_248", CubeListBuilder.create().texOffs(408, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladoi_249", CubeListBuilder.create().texOffs(412, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.961939766255643F, -11.691341716182546F, -2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_0", CubeListBuilder.create().texOffs(908, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.875F, -11.826562500000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_1", CubeListBuilder.create().texOffs(914, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -11.649375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_2", CubeListBuilder.create().texOffs(920, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -11.334375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_3", CubeListBuilder.create().texOffs(926, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -10.861875F, 12.5F, 1.5707963267948966F, 0.0F, 0.33353619044595795F));
        g.addOrReplaceChild("casco_bajo_ladod_4", CubeListBuilder.create().texOffs(476, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -10.231874999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.3335361904459575F));
        g.addOrReplaceChild("casco_bajo_ladod_5", CubeListBuilder.create().texOffs(486, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -9.444374999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.3335361904459579F));
        g.addOrReplaceChild("casco_bajo_ladod_6", CubeListBuilder.create().texOffs(496, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -8.499374999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.33353619044595756F));
        g.addOrReplaceChild("casco_bajo_ladod_7", CubeListBuilder.create().texOffs(196, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -6.80625F, 12.5F, 1.5707963267948966F, 0.0F, 0.266748799411795F));
        g.addOrReplaceChild("casco_bajo_ladod_8", CubeListBuilder.create().texOffs(416, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_9", CubeListBuilder.create().texOffs(432, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_10", CubeListBuilder.create().texOffs(448, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_11", CubeListBuilder.create().texOffs(464, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_12", CubeListBuilder.create().texOffs(480, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_13", CubeListBuilder.create().texOffs(496, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_14", CubeListBuilder.create().texOffs(512, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_15", CubeListBuilder.create().texOffs(528, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_16", CubeListBuilder.create().texOffs(544, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_17", CubeListBuilder.create().texOffs(560, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_18", CubeListBuilder.create().texOffs(576, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_19", CubeListBuilder.create().texOffs(592, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_20", CubeListBuilder.create().texOffs(608, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_21", CubeListBuilder.create().texOffs(624, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_22", CubeListBuilder.create().texOffs(640, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_23", CubeListBuilder.create().texOffs(656, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_24", CubeListBuilder.create().texOffs(672, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -5.625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_25", CubeListBuilder.create().texOffs(214, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -6.01875F, 12.5F, 1.5707963267948966F, 0.0F, -0.09719447717873991F));
        g.addOrReplaceChild("casco_bajo_ladod_26", CubeListBuilder.create().texOffs(300, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -6.9243749999999995F, 12.5F, 1.5707963267948966F, 0.0F, -0.33353619044595756F));
        g.addOrReplaceChild("casco_bajo_ladod_27", CubeListBuilder.create().texOffs(506, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -7.869375000000002F, 12.5F, 1.5707963267948966F, 0.0F, -0.33353619044595784F));
        g.addOrReplaceChild("casco_bajo_ladod_28", CubeListBuilder.create().texOffs(516, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -8.656875000000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_29", CubeListBuilder.create().texOffs(1004, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -9.286874999999998F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_30", CubeListBuilder.create().texOffs(1012, 223).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -9.759374999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_31", CubeListBuilder.create().texOffs(0, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -10.074375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_32", CubeListBuilder.create().texOffs(932, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(41.875F, -10.251562500000002F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_33", CubeListBuilder.create().texOffs(938, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -13.178125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_34", CubeListBuilder.create().texOffs(944, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -12.953125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_35", CubeListBuilder.create().texOffs(950, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -12.615625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
    }

    private static void piezas6(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladod_36", CubeListBuilder.create().texOffs(526, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -12.165625F, 12.5F, 1.5707963267948966F, 0.0F, 0.25619473015536864F));
        g.addOrReplaceChild("casco_bajo_ladod_37", CubeListBuilder.create().texOffs(536, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -11.603124999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.2561947301553689F));
        g.addOrReplaceChild("casco_bajo_ladod_38", CubeListBuilder.create().texOffs(546, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -10.928125F, 12.5F, 1.5707963267948966F, 0.0F, 0.25619473015536864F));
        g.addOrReplaceChild("casco_bajo_ladod_39", CubeListBuilder.create().texOffs(232, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -9.71875F, 12.5F, 1.5707963267948966F, 0.0F, 0.19961038478762638F));
        g.addOrReplaceChild("casco_bajo_ladod_40", CubeListBuilder.create().texOffs(688, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_41", CubeListBuilder.create().texOffs(704, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_42", CubeListBuilder.create().texOffs(720, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_43", CubeListBuilder.create().texOffs(736, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_44", CubeListBuilder.create().texOffs(752, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_45", CubeListBuilder.create().texOffs(768, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_46", CubeListBuilder.create().texOffs(784, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_47", CubeListBuilder.create().texOffs(800, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_48", CubeListBuilder.create().texOffs(816, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_49", CubeListBuilder.create().texOffs(832, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_50", CubeListBuilder.create().texOffs(848, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_51", CubeListBuilder.create().texOffs(864, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_52", CubeListBuilder.create().texOffs(880, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_53", CubeListBuilder.create().texOffs(896, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_54", CubeListBuilder.create().texOffs(912, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_55", CubeListBuilder.create().texOffs(928, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_56", CubeListBuilder.create().texOffs(944, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -8.875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_57", CubeListBuilder.create().texOffs(250, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -9.15625F, 12.5F, 1.5707963267948966F, 0.0F, -0.06985443714458175F));
        g.addOrReplaceChild("casco_bajo_ladod_58", CubeListBuilder.create().texOffs(312, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -9.803125F, 12.5F, 1.5707963267948966F, 0.0F, -0.2561947301553691F));
        g.addOrReplaceChild("casco_bajo_ladod_59", CubeListBuilder.create().texOffs(556, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -10.478125000000002F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_60", CubeListBuilder.create().texOffs(566, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -11.040625000000002F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_61", CubeListBuilder.create().texOffs(8, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -11.490625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_62", CubeListBuilder.create().texOffs(16, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -11.828125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_63", CubeListBuilder.create().texOffs(24, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -12.053125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_64", CubeListBuilder.create().texOffs(956, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -14.706875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_65", CubeListBuilder.create().texOffs(962, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -14.571874999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_66", CubeListBuilder.create().texOffs(968, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -14.369375000000002F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_67", CubeListBuilder.create().texOffs(32, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -14.099374999999998F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_68", CubeListBuilder.create().texOffs(576, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -13.761875F, 12.5F, 1.5707963267948966F, 0.0F, 0.16274792761823909F));
        g.addOrReplaceChild("casco_bajo_ladod_69", CubeListBuilder.create().texOffs(586, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -13.356874999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.16274792761823867F));
        g.addOrReplaceChild("casco_bajo_ladod_70", CubeListBuilder.create().texOffs(268, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -12.631250000000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.1239588350472593F));
        g.addOrReplaceChild("casco_bajo_ladod_71", CubeListBuilder.create().texOffs(960, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_72", CubeListBuilder.create().texOffs(976, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_73", CubeListBuilder.create().texOffs(992, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_74", CubeListBuilder.create().texOffs(1008, 198).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_75", CubeListBuilder.create().texOffs(0, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_76", CubeListBuilder.create().texOffs(16, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_77", CubeListBuilder.create().texOffs(32, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_78", CubeListBuilder.create().texOffs(48, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_79", CubeListBuilder.create().texOffs(64, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_80", CubeListBuilder.create().texOffs(80, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_81", CubeListBuilder.create().texOffs(96, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_82", CubeListBuilder.create().texOffs(112, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_83", CubeListBuilder.create().texOffs(128, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_84", CubeListBuilder.create().texOffs(144, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_85", CubeListBuilder.create().texOffs(160, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_86", CubeListBuilder.create().texOffs(176, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_87", CubeListBuilder.create().texOffs(192, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -12.125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_88", CubeListBuilder.create().texOffs(286, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -12.293750000000001F, 12.5F, 1.5707963267948966F, 0.0F, -0.04208781255313887F));
        g.addOrReplaceChild("casco_bajo_ladod_89", CubeListBuilder.create().texOffs(324, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -12.681874999999998F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_90", CubeListBuilder.create().texOffs(596, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -13.086875000000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_91", CubeListBuilder.create().texOffs(40, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -13.424375000000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_92", CubeListBuilder.create().texOffs(48, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -13.694374999999999F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_93", CubeListBuilder.create().texOffs(56, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -13.896875000000001F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_94", CubeListBuilder.create().texOffs(64, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -14.031875F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_95", CubeListBuilder.create().texOffs(974, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.65F, -16.235625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_96", CubeListBuilder.create().texOffs(980, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-43.25F, -16.190625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_97", CubeListBuilder.create().texOffs(986, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-42.650000000000006F, -16.123125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_98", CubeListBuilder.create().texOffs(72, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-41.85F, -16.033125000000002F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_99", CubeListBuilder.create().texOffs(606, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-40.849999999999994F, -15.920625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_100", CubeListBuilder.create().texOffs(616, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-39.65F, -15.785625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0560144812129938F));
        g.addOrReplaceChild("casco_bajo_ladod_101", CubeListBuilder.create().texOffs(304, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -15.54375F, 12.5F, 1.5707963267948966F, 0.0F, 0.04208781255313902F));
        g.addOrReplaceChild("casco_bajo_ladod_102", CubeListBuilder.create().texOffs(208, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_103", CubeListBuilder.create().texOffs(224, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_104", CubeListBuilder.create().texOffs(240, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_105", CubeListBuilder.create().texOffs(256, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_106", CubeListBuilder.create().texOffs(272, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_107", CubeListBuilder.create().texOffs(288, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_108", CubeListBuilder.create().texOffs(304, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_109", CubeListBuilder.create().texOffs(320, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_110", CubeListBuilder.create().texOffs(336, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_111", CubeListBuilder.create().texOffs(352, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_112", CubeListBuilder.create().texOffs(368, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_113", CubeListBuilder.create().texOffs(384, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_114", CubeListBuilder.create().texOffs(400, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_115", CubeListBuilder.create().texOffs(416, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_116", CubeListBuilder.create().texOffs(432, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_117", CubeListBuilder.create().texOffs(448, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_118", CubeListBuilder.create().texOffs(464, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -15.375F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_119", CubeListBuilder.create().texOffs(322, 192).addBox(-2.5F, -1.0F, -2.0F, 5.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -15.43125F, 12.5F, 1.5707963267948966F, 0.0F, -0.014058793873061365F));
        g.addOrReplaceChild("casco_bajo_ladod_120", CubeListBuilder.create().texOffs(336, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -15.560625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_121", CubeListBuilder.create().texOffs(626, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(38.85F, -15.695625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_122", CubeListBuilder.create().texOffs(80, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(39.85F, -15.808125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_123", CubeListBuilder.create().texOffs(88, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(40.65F, -15.898125F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_124", CubeListBuilder.create().texOffs(96, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.25F, -15.965625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_125", CubeListBuilder.create().texOffs(104, 228).addBox(-0.5F, -1.0F, -1.5F, 1.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(41.65F, -16.010625F, 12.5F, 1.5707963267948966F, 0.0F, 0.0F));
    }

    private static void piezas7(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladod_126", CubeListBuilder.create().texOffs(416, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_127", CubeListBuilder.create().texOffs(420, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_128", CubeListBuilder.create().texOffs(424, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_129", CubeListBuilder.create().texOffs(428, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_130", CubeListBuilder.create().texOffs(852, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_131", CubeListBuilder.create().texOffs(858, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_132", CubeListBuilder.create().texOffs(580, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_133", CubeListBuilder.create().texOffs(590, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_134", CubeListBuilder.create().texOffs(600, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_135", CubeListBuilder.create().texOffs(610, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_136", CubeListBuilder.create().texOffs(620, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_137", CubeListBuilder.create().texOffs(630, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_138", CubeListBuilder.create().texOffs(640, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_139", CubeListBuilder.create().texOffs(650, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_140", CubeListBuilder.create().texOffs(660, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_141", CubeListBuilder.create().texOffs(670, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_142", CubeListBuilder.create().texOffs(680, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_143", CubeListBuilder.create().texOffs(690, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_144", CubeListBuilder.create().texOffs(700, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_145", CubeListBuilder.create().texOffs(710, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_146", CubeListBuilder.create().texOffs(720, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_147", CubeListBuilder.create().texOffs(730, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_148", CubeListBuilder.create().texOffs(740, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_149", CubeListBuilder.create().texOffs(750, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_150", CubeListBuilder.create().texOffs(760, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_151", CubeListBuilder.create().texOffs(864, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_152", CubeListBuilder.create().texOffs(870, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_153", CubeListBuilder.create().texOffs(432, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442597F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_154", CubeListBuilder.create().texOffs(436, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_155", CubeListBuilder.create().texOffs(440, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_156", CubeListBuilder.create().texOffs(444, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.191341716182546F, 12.461939766255643F, 1.7671458676442595F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_157", CubeListBuilder.create().texOffs(448, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_158", CubeListBuilder.create().texOffs(452, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_159", CubeListBuilder.create().texOffs(456, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_160", CubeListBuilder.create().texOffs(460, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_161", CubeListBuilder.create().texOffs(876, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_162", CubeListBuilder.create().texOffs(882, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_163", CubeListBuilder.create().texOffs(770, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_164", CubeListBuilder.create().texOffs(780, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_165", CubeListBuilder.create().texOffs(790, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_166", CubeListBuilder.create().texOffs(800, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_167", CubeListBuilder.create().texOffs(810, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_168", CubeListBuilder.create().texOffs(820, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_169", CubeListBuilder.create().texOffs(830, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_170", CubeListBuilder.create().texOffs(840, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_171", CubeListBuilder.create().texOffs(850, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_172", CubeListBuilder.create().texOffs(860, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_173", CubeListBuilder.create().texOffs(870, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_174", CubeListBuilder.create().texOffs(880, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_175", CubeListBuilder.create().texOffs(890, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_176", CubeListBuilder.create().texOffs(900, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_177", CubeListBuilder.create().texOffs(910, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_178", CubeListBuilder.create().texOffs(920, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_179", CubeListBuilder.create().texOffs(930, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_180", CubeListBuilder.create().texOffs(940, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_181", CubeListBuilder.create().texOffs(950, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_182", CubeListBuilder.create().texOffs(888, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_183", CubeListBuilder.create().texOffs(894, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_184", CubeListBuilder.create().texOffs(464, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_185", CubeListBuilder.create().texOffs(468, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_186", CubeListBuilder.create().texOffs(472, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_187", CubeListBuilder.create().texOffs(476, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.54489510677582F, 12.315493156848916F, 2.1598449493429848F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_188", CubeListBuilder.create().texOffs(480, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_189", CubeListBuilder.create().texOffs(484, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_190", CubeListBuilder.create().texOffs(488, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_191", CubeListBuilder.create().texOffs(492, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_192", CubeListBuilder.create().texOffs(900, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_193", CubeListBuilder.create().texOffs(906, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_194", CubeListBuilder.create().texOffs(960, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_195", CubeListBuilder.create().texOffs(970, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_196", CubeListBuilder.create().texOffs(980, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_197", CubeListBuilder.create().texOffs(990, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_198", CubeListBuilder.create().texOffs(1000, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_199", CubeListBuilder.create().texOffs(1010, 259).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_200", CubeListBuilder.create().texOffs(0, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_201", CubeListBuilder.create().texOffs(10, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_202", CubeListBuilder.create().texOffs(20, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_203", CubeListBuilder.create().texOffs(30, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_204", CubeListBuilder.create().texOffs(40, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_205", CubeListBuilder.create().texOffs(50, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_206", CubeListBuilder.create().texOffs(60, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_207", CubeListBuilder.create().texOffs(70, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_208", CubeListBuilder.create().texOffs(80, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_209", CubeListBuilder.create().texOffs(90, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_210", CubeListBuilder.create().texOffs(100, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_211", CubeListBuilder.create().texOffs(110, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_212", CubeListBuilder.create().texOffs(120, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_213", CubeListBuilder.create().texOffs(912, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_214", CubeListBuilder.create().texOffs(918, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_215", CubeListBuilder.create().texOffs(496, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
    }

    private static void piezas8(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_ladod_216", CubeListBuilder.create().texOffs(500, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_217", CubeListBuilder.create().texOffs(504, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_218", CubeListBuilder.create().texOffs(508, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.815493156848916F, 12.044895106775819F, 2.5525440310417062F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_219", CubeListBuilder.create().texOffs(512, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.65F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_220", CubeListBuilder.create().texOffs(516, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.25F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_221", CubeListBuilder.create().texOffs(520, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.650000000000006F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_222", CubeListBuilder.create().texOffs(524, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-41.85F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_223", CubeListBuilder.create().texOffs(924, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.849999999999994F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_224", CubeListBuilder.create().texOffs(930, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-39.65F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_225", CubeListBuilder.create().texOffs(130, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-37.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_226", CubeListBuilder.create().texOffs(140, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-33.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_227", CubeListBuilder.create().texOffs(150, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-29.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_228", CubeListBuilder.create().texOffs(160, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-25.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_229", CubeListBuilder.create().texOffs(170, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-21.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_230", CubeListBuilder.create().texOffs(180, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-17.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_231", CubeListBuilder.create().texOffs(190, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_232", CubeListBuilder.create().texOffs(200, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-9.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_233", CubeListBuilder.create().texOffs(210, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-5.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_234", CubeListBuilder.create().texOffs(220, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-1.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_235", CubeListBuilder.create().texOffs(230, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_236", CubeListBuilder.create().texOffs(240, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(7.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_237", CubeListBuilder.create().texOffs(250, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(10.999999999999996F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_238", CubeListBuilder.create().texOffs(260, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(14.999999999999996F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_239", CubeListBuilder.create().texOffs(270, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_240", CubeListBuilder.create().texOffs(280, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(23.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_241", CubeListBuilder.create().texOffs(290, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(27.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_242", CubeListBuilder.create().texOffs(300, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(31.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_243", CubeListBuilder.create().texOffs(310, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(35.0F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_244", CubeListBuilder.create().texOffs(936, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(37.65F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_245", CubeListBuilder.create().texOffs(942, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.85F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_246", CubeListBuilder.create().texOffs(528, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_247", CubeListBuilder.create().texOffs(532, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.65F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_248", CubeListBuilder.create().texOffs(536, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.25F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_ladod_249", CubeListBuilder.create().texOffs(540, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.961939766255643F, 11.691341716182546F, 2.9452431127404295F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_0", CubeListBuilder.create().texOffs(636, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_1", CubeListBuilder.create().texOffs(646, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_2", CubeListBuilder.create().texOffs(656, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_3", CubeListBuilder.create().texOffs(666, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_4", CubeListBuilder.create().texOffs(348, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_5", CubeListBuilder.create().texOffs(360, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_6", CubeListBuilder.create().texOffs(480, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_7", CubeListBuilder.create().texOffs(496, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_8", CubeListBuilder.create().texOffs(512, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_9", CubeListBuilder.create().texOffs(528, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_10", CubeListBuilder.create().texOffs(544, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_11", CubeListBuilder.create().texOffs(560, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_12", CubeListBuilder.create().texOffs(576, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_13", CubeListBuilder.create().texOffs(592, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_14", CubeListBuilder.create().texOffs(608, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_15", CubeListBuilder.create().texOffs(624, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_16", CubeListBuilder.create().texOffs(640, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_17", CubeListBuilder.create().texOffs(656, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_18", CubeListBuilder.create().texOffs(672, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_19", CubeListBuilder.create().texOffs(688, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_20", CubeListBuilder.create().texOffs(704, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_21", CubeListBuilder.create().texOffs(720, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_22", CubeListBuilder.create().texOffs(736, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_23", CubeListBuilder.create().texOffs(752, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_24", CubeListBuilder.create().texOffs(768, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, -9.583333333333334F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_25", CubeListBuilder.create().texOffs(372, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_26", CubeListBuilder.create().texOffs(384, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_27", CubeListBuilder.create().texOffs(676, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_28", CubeListBuilder.create().texOffs(686, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_29", CubeListBuilder.create().texOffs(696, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_30", CubeListBuilder.create().texOffs(706, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, -9.583333333333334F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_31", CubeListBuilder.create().texOffs(716, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_32", CubeListBuilder.create().texOffs(726, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_33", CubeListBuilder.create().texOffs(736, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_34", CubeListBuilder.create().texOffs(746, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_35", CubeListBuilder.create().texOffs(396, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_36", CubeListBuilder.create().texOffs(408, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_37", CubeListBuilder.create().texOffs(784, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_38", CubeListBuilder.create().texOffs(800, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_39", CubeListBuilder.create().texOffs(816, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_40", CubeListBuilder.create().texOffs(832, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_41", CubeListBuilder.create().texOffs(848, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_42", CubeListBuilder.create().texOffs(864, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_43", CubeListBuilder.create().texOffs(880, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_44", CubeListBuilder.create().texOffs(896, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_45", CubeListBuilder.create().texOffs(912, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_46", CubeListBuilder.create().texOffs(928, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_47", CubeListBuilder.create().texOffs(944, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_48", CubeListBuilder.create().texOffs(960, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_49", CubeListBuilder.create().texOffs(976, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_50", CubeListBuilder.create().texOffs(992, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_51", CubeListBuilder.create().texOffs(1008, 203).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_52", CubeListBuilder.create().texOffs(0, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_53", CubeListBuilder.create().texOffs(16, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_54", CubeListBuilder.create().texOffs(32, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_55", CubeListBuilder.create().texOffs(48, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, -5.75F, 3.141592653589793F, 0.0F, 0.0F));
    }

    private static void piezas9(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_arriba0_56", CubeListBuilder.create().texOffs(420, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_57", CubeListBuilder.create().texOffs(432, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_58", CubeListBuilder.create().texOffs(756, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_59", CubeListBuilder.create().texOffs(766, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_60", CubeListBuilder.create().texOffs(776, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_61", CubeListBuilder.create().texOffs(786, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, -5.75F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_62", CubeListBuilder.create().texOffs(796, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_63", CubeListBuilder.create().texOffs(806, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_64", CubeListBuilder.create().texOffs(816, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_65", CubeListBuilder.create().texOffs(826, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_66", CubeListBuilder.create().texOffs(444, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_67", CubeListBuilder.create().texOffs(456, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_68", CubeListBuilder.create().texOffs(64, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_69", CubeListBuilder.create().texOffs(80, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_70", CubeListBuilder.create().texOffs(96, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_71", CubeListBuilder.create().texOffs(112, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_72", CubeListBuilder.create().texOffs(128, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_73", CubeListBuilder.create().texOffs(144, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_74", CubeListBuilder.create().texOffs(160, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_75", CubeListBuilder.create().texOffs(176, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_76", CubeListBuilder.create().texOffs(192, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_77", CubeListBuilder.create().texOffs(208, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_78", CubeListBuilder.create().texOffs(224, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_79", CubeListBuilder.create().texOffs(240, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_80", CubeListBuilder.create().texOffs(256, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_81", CubeListBuilder.create().texOffs(272, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_82", CubeListBuilder.create().texOffs(288, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_83", CubeListBuilder.create().texOffs(304, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_84", CubeListBuilder.create().texOffs(320, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_85", CubeListBuilder.create().texOffs(336, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_86", CubeListBuilder.create().texOffs(352, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, -1.916666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_87", CubeListBuilder.create().texOffs(468, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_88", CubeListBuilder.create().texOffs(480, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_89", CubeListBuilder.create().texOffs(836, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_90", CubeListBuilder.create().texOffs(846, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_91", CubeListBuilder.create().texOffs(856, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_92", CubeListBuilder.create().texOffs(866, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, -1.916666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_93", CubeListBuilder.create().texOffs(876, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_94", CubeListBuilder.create().texOffs(886, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_95", CubeListBuilder.create().texOffs(896, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_96", CubeListBuilder.create().texOffs(906, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_97", CubeListBuilder.create().texOffs(492, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_98", CubeListBuilder.create().texOffs(504, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_99", CubeListBuilder.create().texOffs(368, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_100", CubeListBuilder.create().texOffs(384, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_101", CubeListBuilder.create().texOffs(400, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_102", CubeListBuilder.create().texOffs(416, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_103", CubeListBuilder.create().texOffs(432, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_104", CubeListBuilder.create().texOffs(448, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_105", CubeListBuilder.create().texOffs(464, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_106", CubeListBuilder.create().texOffs(480, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_107", CubeListBuilder.create().texOffs(496, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_108", CubeListBuilder.create().texOffs(512, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_109", CubeListBuilder.create().texOffs(528, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_110", CubeListBuilder.create().texOffs(544, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_111", CubeListBuilder.create().texOffs(560, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_112", CubeListBuilder.create().texOffs(576, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_113", CubeListBuilder.create().texOffs(592, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_114", CubeListBuilder.create().texOffs(608, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_115", CubeListBuilder.create().texOffs(624, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_116", CubeListBuilder.create().texOffs(640, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_117", CubeListBuilder.create().texOffs(656, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, 1.916666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_118", CubeListBuilder.create().texOffs(516, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_119", CubeListBuilder.create().texOffs(528, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_120", CubeListBuilder.create().texOffs(916, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_121", CubeListBuilder.create().texOffs(926, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_122", CubeListBuilder.create().texOffs(936, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_123", CubeListBuilder.create().texOffs(946, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, 1.916666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_124", CubeListBuilder.create().texOffs(956, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_125", CubeListBuilder.create().texOffs(966, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_126", CubeListBuilder.create().texOffs(976, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_127", CubeListBuilder.create().texOffs(986, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_128", CubeListBuilder.create().texOffs(540, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_129", CubeListBuilder.create().texOffs(552, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_130", CubeListBuilder.create().texOffs(672, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_131", CubeListBuilder.create().texOffs(688, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_132", CubeListBuilder.create().texOffs(704, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_133", CubeListBuilder.create().texOffs(720, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_134", CubeListBuilder.create().texOffs(736, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_135", CubeListBuilder.create().texOffs(752, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_136", CubeListBuilder.create().texOffs(768, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_137", CubeListBuilder.create().texOffs(784, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_138", CubeListBuilder.create().texOffs(800, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_139", CubeListBuilder.create().texOffs(816, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_140", CubeListBuilder.create().texOffs(832, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_141", CubeListBuilder.create().texOffs(848, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_142", CubeListBuilder.create().texOffs(864, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_143", CubeListBuilder.create().texOffs(880, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_144", CubeListBuilder.create().texOffs(896, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_145", CubeListBuilder.create().texOffs(912, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
    }

    private static void piezas10(PartDefinition g) {
        g.addOrReplaceChild("casco_bajo_arriba0_146", CubeListBuilder.create().texOffs(928, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_147", CubeListBuilder.create().texOffs(944, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_148", CubeListBuilder.create().texOffs(960, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, 5.749999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_149", CubeListBuilder.create().texOffs(564, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_150", CubeListBuilder.create().texOffs(576, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_151", CubeListBuilder.create().texOffs(996, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_152", CubeListBuilder.create().texOffs(1006, 218).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_153", CubeListBuilder.create().texOffs(0, 223).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_154", CubeListBuilder.create().texOffs(10, 223).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, 5.749999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_155", CubeListBuilder.create().texOffs(20, 223).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.65F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_156", CubeListBuilder.create().texOffs(30, 223).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-43.25F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_157", CubeListBuilder.create().texOffs(40, 223).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-42.650000000000006F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_158", CubeListBuilder.create().texOffs(50, 223).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-41.85F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_159", CubeListBuilder.create().texOffs(588, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-40.849999999999994F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_160", CubeListBuilder.create().texOffs(600, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-39.65F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_161", CubeListBuilder.create().texOffs(976, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-37.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_162", CubeListBuilder.create().texOffs(992, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-33.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_163", CubeListBuilder.create().texOffs(1008, 208).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-29.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_164", CubeListBuilder.create().texOffs(0, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-25.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_165", CubeListBuilder.create().texOffs(16, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-21.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_166", CubeListBuilder.create().texOffs(32, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-17.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_167", CubeListBuilder.create().texOffs(48, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-13.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_168", CubeListBuilder.create().texOffs(64, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-9.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_169", CubeListBuilder.create().texOffs(80, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-5.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_170", CubeListBuilder.create().texOffs(96, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-1.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_171", CubeListBuilder.create().texOffs(112, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(3.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_172", CubeListBuilder.create().texOffs(128, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(7.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_173", CubeListBuilder.create().texOffs(144, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.999999999999996F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_174", CubeListBuilder.create().texOffs(160, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.999999999999996F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_175", CubeListBuilder.create().texOffs(176, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(19.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_176", CubeListBuilder.create().texOffs(192, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(23.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_177", CubeListBuilder.create().texOffs(208, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(27.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_178", CubeListBuilder.create().texOffs(224, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(31.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_179", CubeListBuilder.create().texOffs(240, 213).addBox(-2.0F, -1.0F, -2.0F, 4.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(35.0F, -18.0F, 9.583333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_180", CubeListBuilder.create().texOffs(612, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(37.65F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_181", CubeListBuilder.create().texOffs(624, 218).addBox(-1.0F, -1.0F, -2.0F, 2.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(38.85F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_182", CubeListBuilder.create().texOffs(60, 223).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(39.85F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_183", CubeListBuilder.create().texOffs(70, 223).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(40.65F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_184", CubeListBuilder.create().texOffs(80, 223).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.25F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_arriba0_185", CubeListBuilder.create().texOffs(90, 223).addBox(-0.5F, -1.0F, -2.0F, 1.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(41.65F, -18.0F, 9.583333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_bajo_trompa", CubeListBuilder.create().texOffs(600, 0).addBox(0.0F, -32.0F, 0.0F, 1.0F, 32.0F, 52.0F), PartPose.offset(-44.0F, -3.0F, -13.0F));
        g.addOrReplaceChild("casco_bajo_cola", CubeListBuilder.create().texOffs(706, 0).addBox(0.0F, -32.0F, 0.0F, 1.0F, 32.0F, 52.0F), PartPose.offset(41.0F, -3.0F, -13.0F));
        g.addOrReplaceChild("casco_ladoi_0", CubeListBuilder.create().texOffs(948, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -17.60458984375F, -22.0F, -1.5707963267948966F, 0.0F, -0.033190931497111234F));
        g.addOrReplaceChild("casco_ladoi_1", CubeListBuilder.create().texOffs(954, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -17.64443359375F, -22.0F, -1.5707963267948966F, 0.0F, -0.03319093149711221F));
        g.addOrReplaceChild("casco_ladoi_2", CubeListBuilder.create().texOffs(454, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -17.7880859375F, -22.0F, -1.5707963267948966F, 0.0F, -0.060959533981966185F));
        g.addOrReplaceChild("casco_ladoi_3", CubeListBuilder.create().texOffs(548, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -18.04296875F, -22.0F, -1.5707963267948966F, 0.0F, -0.06630889491982349F));
        g.addOrReplaceChild("casco_ladoi_4", CubeListBuilder.create().texOffs(772, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -18.275390625F, -22.0F, -1.5707963267948966F, 0.0F, -0.03315444745991172F));
        g.addOrReplaceChild("casco_ladoi_5", CubeListBuilder.create().texOffs(992, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_6", CubeListBuilder.create().texOffs(784, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_7", CubeListBuilder.create().texOffs(796, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_8", CubeListBuilder.create().texOffs(808, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_9", CubeListBuilder.create().texOffs(820, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_10", CubeListBuilder.create().texOffs(832, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_11", CubeListBuilder.create().texOffs(844, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_12", CubeListBuilder.create().texOffs(856, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_13", CubeListBuilder.create().texOffs(868, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_14", CubeListBuilder.create().texOffs(880, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_15", CubeListBuilder.create().texOffs(892, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_16", CubeListBuilder.create().texOffs(904, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_17", CubeListBuilder.create().texOffs(916, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_18", CubeListBuilder.create().texOffs(928, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_19", CubeListBuilder.create().texOffs(940, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_20", CubeListBuilder.create().texOffs(952, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_21", CubeListBuilder.create().texOffs(964, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -18.375F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_22", CubeListBuilder.create().texOffs(562, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -18.26388888888889F, -22.0F, -1.5707963267948966F, 0.0F, 0.05549850524571664F));
        g.addOrReplaceChild("casco_ladoi_23", CubeListBuilder.create().texOffs(280, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -18.116666666666667F, -22.0F, -1.5707963267948966F, 0.0F, 0.02774925262285877F));
        g.addOrReplaceChild("casco_ladoi_24", CubeListBuilder.create().texOffs(288, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -18.05F, -22.0F, -1.5707963267948966F, 0.0F, 0.027749252622858458F));
        g.addOrReplaceChild("casco_ladoi_25", CubeListBuilder.create().texOffs(998, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -17.994444444444447F, -22.0F, -1.5707963267948966F, 0.0F, 0.02774925262285814F));
        g.addOrReplaceChild("casco_ladoi_26", CubeListBuilder.create().texOffs(544, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.95F, -22.0F, -1.5707963267948966F, 0.0F, 0.02774925262285877F));
        g.addOrReplaceChild("casco_ladoi_27", CubeListBuilder.create().texOffs(548, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -17.916666666666668F, -22.0F, -1.5707963267948966F, 0.0F, 0.027749252622857355F));
        g.addOrReplaceChild("casco_ladoi_28", CubeListBuilder.create().texOffs(552, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -17.894444444444446F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_29", CubeListBuilder.create().texOffs(960, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -17.81376953125F, -22.0F, -1.5707963267948966F, 0.0F, -0.09928188012599692F));
        g.addOrReplaceChild("casco_ladoi_30", CubeListBuilder.create().texOffs(966, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -17.93330078125F, -22.0F, -1.5707963267948966F, 0.0F, -0.0992818801259969F));
        g.addOrReplaceChild("casco_ladoi_31", CubeListBuilder.create().texOffs(466, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -18.3642578125F, -22.0F, -1.5707963267948966F, 0.0F, -0.18109931064379278F));
        g.addOrReplaceChild("casco_ladoi_32", CubeListBuilder.create().texOffs(576, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -19.12890625F, -22.0F, -1.5707963267948966F, 0.0F, -0.196644245190345F));
        g.addOrReplaceChild("casco_ladoi_33", CubeListBuilder.create().texOffs(976, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -19.826171875F, -22.0F, -1.5707963267948966F, 0.0F, -0.09832212259517253F));
        g.addOrReplaceChild("casco_ladoi_34", CubeListBuilder.create().texOffs(1004, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_35", CubeListBuilder.create().texOffs(988, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_36", CubeListBuilder.create().texOffs(1000, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_37", CubeListBuilder.create().texOffs(1012, 238).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_38", CubeListBuilder.create().texOffs(0, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_39", CubeListBuilder.create().texOffs(12, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_40", CubeListBuilder.create().texOffs(24, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_41", CubeListBuilder.create().texOffs(36, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_42", CubeListBuilder.create().texOffs(48, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_43", CubeListBuilder.create().texOffs(60, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_44", CubeListBuilder.create().texOffs(72, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_45", CubeListBuilder.create().texOffs(84, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_46", CubeListBuilder.create().texOffs(96, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_47", CubeListBuilder.create().texOffs(108, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
    }

    private static void piezas11(PartDefinition g) {
        g.addOrReplaceChild("casco_ladoi_48", CubeListBuilder.create().texOffs(120, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_49", CubeListBuilder.create().texOffs(132, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_50", CubeListBuilder.create().texOffs(144, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -20.125F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_51", CubeListBuilder.create().texOffs(590, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -19.791666666666668F, -22.0F, -1.5707963267948966F, 0.0F, 0.1651486774146267F));
        g.addOrReplaceChild("casco_ladoi_52", CubeListBuilder.create().texOffs(296, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -19.35F, -22.0F, -1.5707963267948966F, 0.0F, 0.08257433870731362F));
        g.addOrReplaceChild("casco_ladoi_53", CubeListBuilder.create().texOffs(304, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -19.15F, -22.0F, -1.5707963267948966F, 0.0F, 0.08257433870731362F));
        g.addOrReplaceChild("casco_ladoi_54", CubeListBuilder.create().texOffs(1010, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -18.983333333333334F, -22.0F, -1.5707963267948966F, 0.0F, 0.08257433870731246F));
        g.addOrReplaceChild("casco_ladoi_55", CubeListBuilder.create().texOffs(556, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -18.85F, -22.0F, -1.5707963267948966F, 0.0F, 0.08257433870731465F));
        g.addOrReplaceChild("casco_ladoi_56", CubeListBuilder.create().texOffs(560, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -18.75F, -22.0F, -1.5707963267948966F, 0.0F, 0.08257433870731229F));
        g.addOrReplaceChild("casco_ladoi_57", CubeListBuilder.create().texOffs(564, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -18.683333333333337F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_58", CubeListBuilder.create().texOffs(972, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.02294921875F, -22.0F, -1.5707963267948966F, 0.0F, -0.16451516467074442F));
        g.addOrReplaceChild("casco_ladoi_59", CubeListBuilder.create().texOffs(978, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.22216796875F, -22.0F, -1.5707963267948966F, 0.0F, -0.1645151646707421F));
        g.addOrReplaceChild("casco_ladoi_60", CubeListBuilder.create().texOffs(478, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -18.9404296875F, -22.0F, -1.5707963267948966F, 0.0F, -0.29619842747256747F));
        g.addOrReplaceChild("casco_ladoi_61", CubeListBuilder.create().texOffs(604, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -20.21484375F, -22.0F, -1.5707963267948966F, 0.0F, -0.320578221991157F));
        g.addOrReplaceChild("casco_ladoi_62", CubeListBuilder.create().texOffs(156, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -21.376953125F, -22.0F, -1.5707963267948966F, 0.0F, -0.16028911099557858F));
        g.addOrReplaceChild("casco_ladoi_63", CubeListBuilder.create().texOffs(1016, 253).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_64", CubeListBuilder.create().texOffs(168, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_65", CubeListBuilder.create().texOffs(180, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_66", CubeListBuilder.create().texOffs(192, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_67", CubeListBuilder.create().texOffs(204, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_68", CubeListBuilder.create().texOffs(216, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_69", CubeListBuilder.create().texOffs(228, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_70", CubeListBuilder.create().texOffs(240, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_71", CubeListBuilder.create().texOffs(252, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_72", CubeListBuilder.create().texOffs(264, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_73", CubeListBuilder.create().texOffs(276, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_74", CubeListBuilder.create().texOffs(288, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_75", CubeListBuilder.create().texOffs(300, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_76", CubeListBuilder.create().texOffs(312, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_77", CubeListBuilder.create().texOffs(324, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_78", CubeListBuilder.create().texOffs(336, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_79", CubeListBuilder.create().texOffs(348, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -21.875F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_80", CubeListBuilder.create().texOffs(618, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -21.319444444444443F, -22.0F, -1.5707963267948966F, 0.0F, 0.27094685033842086F));
        g.addOrReplaceChild("casco_ladoi_81", CubeListBuilder.create().texOffs(312, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -20.583333333333332F, -22.0F, -1.5707963267948966F, 0.0F, 0.13547342516920977F));
        g.addOrReplaceChild("casco_ladoi_82", CubeListBuilder.create().texOffs(320, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -20.25F, -22.0F, -1.5707963267948966F, 0.0F, 0.13547342516921063F));
        g.addOrReplaceChild("casco_ladoi_83", CubeListBuilder.create().texOffs(0, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -19.97222222222222F, -22.0F, -1.5707963267948966F, 0.0F, 0.13547342516920965F));
        g.addOrReplaceChild("casco_ladoi_84", CubeListBuilder.create().texOffs(568, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -19.75F, -22.0F, -1.5707963267948966F, 0.0F, 0.13547342516921104F));
        g.addOrReplaceChild("casco_ladoi_85", CubeListBuilder.create().texOffs(572, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -19.583333333333336F, -22.0F, -1.5707963267948966F, 0.0F, 0.13547342516921065F));
        g.addOrReplaceChild("casco_ladoi_86", CubeListBuilder.create().texOffs(576, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -19.47222222222222F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_87", CubeListBuilder.create().texOffs(984, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.232128906250004F, -22.0F, -1.5707963267948966F, 0.0F, -0.22836736238143945F));
        g.addOrReplaceChild("casco_ladoi_88", CubeListBuilder.create().texOffs(990, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.511035156250003F, -22.0F, -1.5707963267948966F, 0.0F, -0.22836736238143773F));
        g.addOrReplaceChild("casco_ladoi_89", CubeListBuilder.create().texOffs(490, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -19.5166015625F, -22.0F, -1.5707963267948966F, 0.0F, -0.4037715697853255F));
        g.addOrReplaceChild("casco_ladoi_90", CubeListBuilder.create().texOffs(632, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -21.30078125F, -22.0F, -1.5707963267948966F, 0.0F, -0.43512919388924687F));
        g.addOrReplaceChild("casco_ladoi_91", CubeListBuilder.create().texOffs(360, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -22.927734375F, -22.0F, -1.5707963267948966F, 0.0F, -0.21756459694462352F));
        g.addOrReplaceChild("casco_ladoi_92", CubeListBuilder.create().texOffs(6, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_93", CubeListBuilder.create().texOffs(372, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_94", CubeListBuilder.create().texOffs(384, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_95", CubeListBuilder.create().texOffs(396, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_96", CubeListBuilder.create().texOffs(408, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_97", CubeListBuilder.create().texOffs(420, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_98", CubeListBuilder.create().texOffs(432, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_99", CubeListBuilder.create().texOffs(444, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_100", CubeListBuilder.create().texOffs(456, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_101", CubeListBuilder.create().texOffs(468, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_102", CubeListBuilder.create().texOffs(480, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_103", CubeListBuilder.create().texOffs(492, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_104", CubeListBuilder.create().texOffs(504, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_105", CubeListBuilder.create().texOffs(516, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_106", CubeListBuilder.create().texOffs(528, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_107", CubeListBuilder.create().texOffs(540, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_108", CubeListBuilder.create().texOffs(552, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -23.625F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_109", CubeListBuilder.create().texOffs(646, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -22.84722222222222F, -22.0F, -1.5707963267948966F, 0.0F, 0.3708912888126627F));
        g.addOrReplaceChild("casco_ladoi_110", CubeListBuilder.create().texOffs(328, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -21.816666666666666F, -22.0F, -1.5707963267948966F, 0.0F, 0.1854456444063307F));
        g.addOrReplaceChild("casco_ladoi_111", CubeListBuilder.create().texOffs(336, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -21.349999999999998F, -22.0F, -1.5707963267948966F, 0.0F, 0.18544564440633182F));
        g.addOrReplaceChild("casco_ladoi_112", CubeListBuilder.create().texOffs(12, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -20.96111111111111F, -22.0F, -1.5707963267948966F, 0.0F, 0.1854456444063309F));
        g.addOrReplaceChild("casco_ladoi_113", CubeListBuilder.create().texOffs(580, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -20.65F, -22.0F, -1.5707963267948966F, 0.0F, 0.18544564440633143F));
        g.addOrReplaceChild("casco_ladoi_114", CubeListBuilder.create().texOffs(584, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -20.416666666666664F, -22.0F, -1.5707963267948966F, 0.0F, 0.1854456444063313F));
        g.addOrReplaceChild("casco_ladoi_115", CubeListBuilder.create().texOffs(588, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -20.26111111111111F, -22.0F, -1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_116", CubeListBuilder.create().texOffs(592, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.180367808226126F, -21.97826403838506F, -1.7735463742713533F, -0.009638353161039436F, -0.3064795174657339F));
        g.addOrReplaceChild("casco_ladoi_117", CubeListBuilder.create().texOffs(996, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.496817951587115F, -21.968154288796715F, -1.7735463742713498F, -0.009638353161041288F, -0.3064795174657344F));
        g.addOrReplaceChild("casco_ladoi_118", CubeListBuilder.create().texOffs(1002, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.8765581236203F, -21.9560225892907F, -1.7735463742713529F, -0.009638353161041323F, -0.30647951746573376F));
        g.addOrReplaceChild("casco_ladoi_119", CubeListBuilder.create().texOffs(502, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.07525664553938F, -21.94618045072087F, -1.7886368652024789F, -0.0014647890075800583F, -0.46084606897965286F));
        g.addOrReplaceChild("casco_ladoi_120", CubeListBuilder.create().texOffs(514, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -22.130762574273817F, -21.942909649383466F, -1.7923385276323984F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_121", CubeListBuilder.create().texOffs(320, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -23.990137574273817F, -21.942909649383466F, -1.7923385276323986F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_122", CubeListBuilder.create().texOffs(596, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_123", CubeListBuilder.create().texOffs(330, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_124", CubeListBuilder.create().texOffs(340, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_125", CubeListBuilder.create().texOffs(350, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_126", CubeListBuilder.create().texOffs(360, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_127", CubeListBuilder.create().texOffs(370, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_128", CubeListBuilder.create().texOffs(380, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_129", CubeListBuilder.create().texOffs(390, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_130", CubeListBuilder.create().texOffs(400, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_131", CubeListBuilder.create().texOffs(410, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_132", CubeListBuilder.create().texOffs(420, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_133", CubeListBuilder.create().texOffs(430, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_134", CubeListBuilder.create().texOffs(440, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_135", CubeListBuilder.create().texOffs(450, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_136", CubeListBuilder.create().texOffs(460, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_137", CubeListBuilder.create().texOffs(470, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
    }

    private static void piezas12(PartDefinition g) {
        g.addOrReplaceChild("casco_ladoi_138", CubeListBuilder.create().texOffs(480, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -24.787012574273817F, -21.942909649383466F, -1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_139", CubeListBuilder.create().texOffs(526, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -23.89812368538493F, -21.942909649383466F, -1.785126256462946F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladoi_140", CubeListBuilder.create().texOffs(1008, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -22.72034590760715F, -21.942909649383466F, -1.785126256462946F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladoi_141", CubeListBuilder.create().texOffs(1014, 263).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -22.187012574273815F, -21.942909649383466F, -1.7851262564629462F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladoi_142", CubeListBuilder.create().texOffs(600, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -21.742568129829372F, -21.942909649383466F, -1.7807768282625926F, -0.043279581922705194F, 0.21793548935718107F));
        g.addOrReplaceChild("casco_ladoi_143", CubeListBuilder.create().texOffs(604, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -21.387012574273815F, -21.942909649383466F, -1.7807768282625926F, -0.0432795819227055F, 0.2179354893571824F));
        g.addOrReplaceChild("casco_ladoi_144", CubeListBuilder.create().texOffs(608, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -21.12034590760715F, -21.942909649383466F, -1.7807768282625926F, -0.04327958192270517F, 0.21793548935718102F));
        g.addOrReplaceChild("casco_ladoi_145", CubeListBuilder.create().texOffs(612, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -20.94256812982937F, -21.942909649383466F, -1.7807768282625929F, -0.04327958192270562F, 0.2179354893571827F));
        g.addOrReplaceChild("casco_ladoi_146", CubeListBuilder.create().texOffs(616, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.382279939885255F, -21.894629295044187F, -2.183480950305094F, -0.04530944696258163F, -0.3894077494538908F));
        g.addOrReplaceChild("casco_ladoi_147", CubeListBuilder.create().texOffs(0, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.79264270262258F, -21.84561966483218F, -2.1834809503051F, -0.045309446962581615F, -0.3894077494538931F));
        g.addOrReplaceChild("casco_ladoi_148", CubeListBuilder.create().texOffs(6, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.285078017907374F, -21.786808108577773F, -2.1834809503050985F, -0.04530944696258319F, -0.38940774945389084F));
        g.addOrReplaceChild("casco_ladoi_149", CubeListBuilder.create().texOffs(538, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.575203236925184F, -21.739095792106674F, -2.212338445519162F, -0.0070576043602407585F, -0.4729595476997946F));
        g.addOrReplaceChild("casco_ladoi_150", CubeListBuilder.create().texOffs(550, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -22.66109266016373F, -21.723239735273374F, -2.2185176378058538F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_151", CubeListBuilder.create().texOffs(490, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -24.52046766016373F, -21.723239735273374F, -2.2185176378058538F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_152", CubeListBuilder.create().texOffs(620, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_153", CubeListBuilder.create().texOffs(500, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_154", CubeListBuilder.create().texOffs(510, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_155", CubeListBuilder.create().texOffs(520, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_156", CubeListBuilder.create().texOffs(530, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_157", CubeListBuilder.create().texOffs(540, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_158", CubeListBuilder.create().texOffs(550, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_159", CubeListBuilder.create().texOffs(560, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_160", CubeListBuilder.create().texOffs(570, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_161", CubeListBuilder.create().texOffs(580, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_162", CubeListBuilder.create().texOffs(590, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_163", CubeListBuilder.create().texOffs(600, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_164", CubeListBuilder.create().texOffs(610, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_165", CubeListBuilder.create().texOffs(620, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_166", CubeListBuilder.create().texOffs(630, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_167", CubeListBuilder.create().texOffs(640, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_168", CubeListBuilder.create().texOffs(650, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.31734266016373F, -21.723239735273374F, -2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_169", CubeListBuilder.create().texOffs(562, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -24.42845377127484F, -21.723239735273374F, -2.202156205383196F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladoi_170", CubeListBuilder.create().texOffs(12, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.25067599349706F, -21.723239735273374F, -2.202156205383196F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladoi_171", CubeListBuilder.create().texOffs(18, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -22.717342660163723F, -21.723239735273374F, -2.2021562053831962F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladoi_172", CubeListBuilder.create().texOffs(624, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.27289821571928F, -21.723239735273374F, -2.1950704588806107F, -0.1013300717166445F, 0.2787153807148607F));
        g.addOrReplaceChild("casco_ladoi_173", CubeListBuilder.create().texOffs(628, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -21.917342660163726F, -21.723239735273374F, -2.1950704588806116F, -0.10133007171664508F, 0.2787153807148624F));
        g.addOrReplaceChild("casco_ladoi_174", CubeListBuilder.create().texOffs(632, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -21.65067599349706F, -21.723239735273374F, -2.1950704588806107F, -0.10133007171664438F, 0.27871538071486057F));
        g.addOrReplaceChild("casco_ladoi_175", CubeListBuilder.create().texOffs(636, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -21.472898215719283F, -21.723239735273374F, -2.1950704588806116F, -0.10133007171664528F, 0.27871538071486296F));
        g.addOrReplaceChild("casco_ladoi_176", CubeListBuilder.create().texOffs(24, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.53681679504419F, -21.740092439885252F, -2.582873959244832F, -0.10845998036298939F, -0.4493392298148658F));
        g.addOrReplaceChild("casco_ladoi_177", CubeListBuilder.create().texOffs(30, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.019057164832184F, -21.61920520262258F, -2.5828739592448273F, -0.10845998036298805F, -0.44933922981486685F));
        g.addOrReplaceChild("casco_ladoi_178", CubeListBuilder.create().texOffs(36, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.597745608577775F, -21.474140517907372F, -2.5828739592448273F, -0.10845998036298911F, -0.4493392298148642F));
        g.addOrReplaceChild("casco_ladoi_179", CubeListBuilder.create().texOffs(574, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.95784579210667F, -21.356453236925184F, -2.6046386885488584F, -0.01732442858115882F, -0.4821306373393771F));
        g.addOrReplaceChild("casco_ladoi_180", CubeListBuilder.create().texOffs(586, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -23.066989735273374F, -21.317342660163728F, -2.608499901014315F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_181", CubeListBuilder.create().texOffs(660, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -24.926364735273374F, -21.317342660163728F, -2.608499901014315F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_182", CubeListBuilder.create().texOffs(640, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_183", CubeListBuilder.create().texOffs(670, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_184", CubeListBuilder.create().texOffs(680, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_185", CubeListBuilder.create().texOffs(690, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_186", CubeListBuilder.create().texOffs(700, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_187", CubeListBuilder.create().texOffs(710, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_188", CubeListBuilder.create().texOffs(720, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_189", CubeListBuilder.create().texOffs(730, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_190", CubeListBuilder.create().texOffs(740, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_191", CubeListBuilder.create().texOffs(750, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_192", CubeListBuilder.create().texOffs(760, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_193", CubeListBuilder.create().texOffs(770, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_194", CubeListBuilder.create().texOffs(780, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_195", CubeListBuilder.create().texOffs(790, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_196", CubeListBuilder.create().texOffs(800, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_197", CubeListBuilder.create().texOffs(810, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_198", CubeListBuilder.create().texOffs(820, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.723239735273374F, -21.317342660163728F, -2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_199", CubeListBuilder.create().texOffs(598, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -24.834350846384485F, -21.317342660163728F, -2.5934232240457846F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladoi_200", CubeListBuilder.create().texOffs(42, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.65657306860671F, -21.317342660163728F, -2.5934232240457846F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladoi_201", CubeListBuilder.create().texOffs(48, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -23.123239735273376F, -21.317342660163728F, -2.593423224045785F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladoi_202", CubeListBuilder.create().texOffs(644, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.67879529082893F, -21.317342660163728F, -2.5905327765359143F, -0.09706816482927975F, 0.35873360420314093F));
        g.addOrReplaceChild("casco_ladoi_203", CubeListBuilder.create().texOffs(648, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -22.32323973527338F, -21.317342660163728F, -2.5905327765359147F, -0.09706816482928023F, 0.35873360420314304F));
        g.addOrReplaceChild("casco_ladoi_204", CubeListBuilder.create().texOffs(652, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -22.056573068606706F, -21.317342660163728F, -2.590532776535914F, -0.09706816482927975F, 0.3587336042031406F));
        g.addOrReplaceChild("casco_ladoi_205", CubeListBuilder.create().texOffs(656, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -21.87879529082893F, -21.317342660163728F, -2.5905327765359147F, -0.09706816482928046F, 0.35873360420314365F));
        g.addOrReplaceChild("casco_ladoi_206", CubeListBuilder.create().texOffs(54, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.620451538385062F, -21.538180308226124F, -2.9608197790121387F, -0.18823006473349232F, -0.48041642531146883F));
        g.addOrReplaceChild("casco_ladoi_207", CubeListBuilder.create().texOffs(60, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.141591788796717F, -21.323380451587113F, -2.9608197790121413F, -0.18823006473349305F, -0.48041642531146833F));
        g.addOrReplaceChild("casco_ladoi_208", CubeListBuilder.create().texOffs(66, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.766960089290702F, -21.065620623620298F, -2.960819779012138F, -0.18823006473349232F, -0.480416425311467F));
        g.addOrReplaceChild("casco_ladoi_209", CubeListBuilder.create().texOffs(610, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -21.16493045072087F, -20.85650664553938F, -2.9670193348032075F, -0.030696788914183027F, -0.4870576488112398F));
        g.addOrReplaceChild("casco_ladoi_210", CubeListBuilder.create().texOffs(622, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -23.286659649383466F, -20.787012574273817F, -2.967704111419101F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_211", CubeListBuilder.create().texOffs(830, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -25.146034649383466F, -20.787012574273817F, -2.967704111419101F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladoi_212", CubeListBuilder.create().texOffs(660, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_213", CubeListBuilder.create().texOffs(840, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_214", CubeListBuilder.create().texOffs(850, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_215", CubeListBuilder.create().texOffs(860, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_216", CubeListBuilder.create().texOffs(870, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_217", CubeListBuilder.create().texOffs(880, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_218", CubeListBuilder.create().texOffs(890, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_219", CubeListBuilder.create().texOffs(900, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_220", CubeListBuilder.create().texOffs(910, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_221", CubeListBuilder.create().texOffs(920, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_222", CubeListBuilder.create().texOffs(930, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_223", CubeListBuilder.create().texOffs(940, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_224", CubeListBuilder.create().texOffs(950, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_225", CubeListBuilder.create().texOffs(960, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_226", CubeListBuilder.create().texOffs(970, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_227", CubeListBuilder.create().texOffs(980, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
    }

    private static void piezas13(PartDefinition g) {
        g.addOrReplaceChild("casco_ladoi_228", CubeListBuilder.create().texOffs(990, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.942909649383466F, -20.787012574273817F, -2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladoi_229", CubeListBuilder.create().texOffs(634, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -25.054020760494573F, -20.787012574273817F, -2.961787325135448F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladoi_230", CubeListBuilder.create().texOffs(72, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.8762429827168F, -20.787012574273817F, -2.961787325135448F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladoi_231", CubeListBuilder.create().texOffs(78, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -23.342909649383465F, -20.787012574273817F, -2.961787325135448F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladoi_232", CubeListBuilder.create().texOffs(664, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.898465204939022F, -20.787012574273817F, -2.9616488678553012F, -0.03901873250032806F, 0.4111282952483033F));
        g.addOrReplaceChild("casco_ladoi_233", CubeListBuilder.create().texOffs(668, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -22.542909649383464F, -20.787012574273817F, -2.9616488678553017F, -0.03901873250032821F, 0.41112829524830585F));
        g.addOrReplaceChild("casco_ladoi_234", CubeListBuilder.create().texOffs(672, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -22.276242982716795F, -20.787012574273817F, -2.9616488678553012F, -0.03901873250032806F, 0.4111282952483032F));
        g.addOrReplaceChild("casco_ladoi_235", CubeListBuilder.create().texOffs(676, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -22.09846520493902F, -20.787012574273817F, -2.9616488678553017F, -0.03901873250032829F, 0.4111282952483067F));
        g.addOrReplaceChild("casco_ladod_0", CubeListBuilder.create().texOffs(84, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -17.60458984375F, 22.0F, 1.5707963267948966F, 0.0F, -0.033190931497111234F));
        g.addOrReplaceChild("casco_ladod_1", CubeListBuilder.create().texOffs(90, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -17.64443359375F, 22.0F, 1.5707963267948966F, 0.0F, -0.03319093149711221F));
        g.addOrReplaceChild("casco_ladod_2", CubeListBuilder.create().texOffs(646, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -17.7880859375F, 22.0F, 1.5707963267948966F, 0.0F, -0.060959533981966185F));
        g.addOrReplaceChild("casco_ladod_3", CubeListBuilder.create().texOffs(660, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -18.04296875F, 22.0F, 1.5707963267948966F, 0.0F, -0.06630889491982349F));
        g.addOrReplaceChild("casco_ladod_4", CubeListBuilder.create().texOffs(564, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -18.275390625F, 22.0F, 1.5707963267948966F, 0.0F, -0.03315444745991172F));
        g.addOrReplaceChild("casco_ladod_5", CubeListBuilder.create().texOffs(18, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_6", CubeListBuilder.create().texOffs(576, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_7", CubeListBuilder.create().texOffs(588, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_8", CubeListBuilder.create().texOffs(600, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_9", CubeListBuilder.create().texOffs(612, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_10", CubeListBuilder.create().texOffs(624, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_11", CubeListBuilder.create().texOffs(636, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_12", CubeListBuilder.create().texOffs(648, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_13", CubeListBuilder.create().texOffs(660, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_14", CubeListBuilder.create().texOffs(672, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_15", CubeListBuilder.create().texOffs(684, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_16", CubeListBuilder.create().texOffs(696, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_17", CubeListBuilder.create().texOffs(708, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_18", CubeListBuilder.create().texOffs(720, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_19", CubeListBuilder.create().texOffs(732, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_20", CubeListBuilder.create().texOffs(744, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_21", CubeListBuilder.create().texOffs(756, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -18.375F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_22", CubeListBuilder.create().texOffs(674, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -18.26388888888889F, 22.0F, 1.5707963267948966F, 0.0F, 0.05549850524571664F));
        g.addOrReplaceChild("casco_ladod_23", CubeListBuilder.create().texOffs(344, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -18.116666666666667F, 22.0F, 1.5707963267948966F, 0.0F, 0.02774925262285877F));
        g.addOrReplaceChild("casco_ladod_24", CubeListBuilder.create().texOffs(352, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -18.05F, 22.0F, 1.5707963267948966F, 0.0F, 0.027749252622858458F));
        g.addOrReplaceChild("casco_ladod_25", CubeListBuilder.create().texOffs(24, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -17.994444444444447F, 22.0F, 1.5707963267948966F, 0.0F, 0.02774925262285814F));
        g.addOrReplaceChild("casco_ladod_26", CubeListBuilder.create().texOffs(680, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -17.95F, 22.0F, 1.5707963267948966F, 0.0F, 0.02774925262285877F));
        g.addOrReplaceChild("casco_ladod_27", CubeListBuilder.create().texOffs(684, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -17.916666666666668F, 22.0F, 1.5707963267948966F, 0.0F, 0.027749252622857355F));
        g.addOrReplaceChild("casco_ladod_28", CubeListBuilder.create().texOffs(688, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -17.894444444444446F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_29", CubeListBuilder.create().texOffs(96, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -17.81376953125F, 22.0F, 1.5707963267948966F, 0.0F, -0.09928188012599692F));
        g.addOrReplaceChild("casco_ladod_30", CubeListBuilder.create().texOffs(102, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -17.93330078125F, 22.0F, 1.5707963267948966F, 0.0F, -0.0992818801259969F));
        g.addOrReplaceChild("casco_ladod_31", CubeListBuilder.create().texOffs(658, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -18.3642578125F, 22.0F, 1.5707963267948966F, 0.0F, -0.18109931064379278F));
        g.addOrReplaceChild("casco_ladod_32", CubeListBuilder.create().texOffs(688, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -19.12890625F, 22.0F, 1.5707963267948966F, 0.0F, -0.196644245190345F));
        g.addOrReplaceChild("casco_ladod_33", CubeListBuilder.create().texOffs(768, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -19.826171875F, 22.0F, 1.5707963267948966F, 0.0F, -0.09832212259517253F));
        g.addOrReplaceChild("casco_ladod_34", CubeListBuilder.create().texOffs(30, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_35", CubeListBuilder.create().texOffs(780, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_36", CubeListBuilder.create().texOffs(792, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_37", CubeListBuilder.create().texOffs(804, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_38", CubeListBuilder.create().texOffs(816, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_39", CubeListBuilder.create().texOffs(828, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_40", CubeListBuilder.create().texOffs(840, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_41", CubeListBuilder.create().texOffs(852, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_42", CubeListBuilder.create().texOffs(864, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_43", CubeListBuilder.create().texOffs(876, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_44", CubeListBuilder.create().texOffs(888, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_45", CubeListBuilder.create().texOffs(900, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_46", CubeListBuilder.create().texOffs(912, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_47", CubeListBuilder.create().texOffs(924, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_48", CubeListBuilder.create().texOffs(936, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_49", CubeListBuilder.create().texOffs(948, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_50", CubeListBuilder.create().texOffs(960, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -20.125F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_51", CubeListBuilder.create().texOffs(702, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -19.791666666666668F, 22.0F, 1.5707963267948966F, 0.0F, 0.1651486774146267F));
        g.addOrReplaceChild("casco_ladod_52", CubeListBuilder.create().texOffs(360, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -19.35F, 22.0F, 1.5707963267948966F, 0.0F, 0.08257433870731362F));
        g.addOrReplaceChild("casco_ladod_53", CubeListBuilder.create().texOffs(368, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -19.15F, 22.0F, 1.5707963267948966F, 0.0F, 0.08257433870731362F));
        g.addOrReplaceChild("casco_ladod_54", CubeListBuilder.create().texOffs(36, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -18.983333333333334F, 22.0F, 1.5707963267948966F, 0.0F, 0.08257433870731246F));
        g.addOrReplaceChild("casco_ladod_55", CubeListBuilder.create().texOffs(692, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -18.85F, 22.0F, 1.5707963267948966F, 0.0F, 0.08257433870731465F));
        g.addOrReplaceChild("casco_ladod_56", CubeListBuilder.create().texOffs(696, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -18.75F, 22.0F, 1.5707963267948966F, 0.0F, 0.08257433870731229F));
        g.addOrReplaceChild("casco_ladod_57", CubeListBuilder.create().texOffs(700, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -18.683333333333337F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_58", CubeListBuilder.create().texOffs(108, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.02294921875F, 22.0F, 1.5707963267948966F, 0.0F, -0.16451516467074442F));
        g.addOrReplaceChild("casco_ladod_59", CubeListBuilder.create().texOffs(114, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.22216796875F, 22.0F, 1.5707963267948966F, 0.0F, -0.1645151646707421F));
        g.addOrReplaceChild("casco_ladod_60", CubeListBuilder.create().texOffs(670, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -18.9404296875F, 22.0F, 1.5707963267948966F, 0.0F, -0.29619842747256747F));
        g.addOrReplaceChild("casco_ladod_61", CubeListBuilder.create().texOffs(716, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -20.21484375F, 22.0F, 1.5707963267948966F, 0.0F, -0.320578221991157F));
        g.addOrReplaceChild("casco_ladod_62", CubeListBuilder.create().texOffs(972, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -21.376953125F, 22.0F, 1.5707963267948966F, 0.0F, -0.16028911099557858F));
        g.addOrReplaceChild("casco_ladod_63", CubeListBuilder.create().texOffs(42, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_64", CubeListBuilder.create().texOffs(984, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_65", CubeListBuilder.create().texOffs(996, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_66", CubeListBuilder.create().texOffs(1008, 241).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_67", CubeListBuilder.create().texOffs(0, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_68", CubeListBuilder.create().texOffs(12, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_69", CubeListBuilder.create().texOffs(24, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_70", CubeListBuilder.create().texOffs(36, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_71", CubeListBuilder.create().texOffs(48, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_72", CubeListBuilder.create().texOffs(60, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_73", CubeListBuilder.create().texOffs(72, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_74", CubeListBuilder.create().texOffs(84, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_75", CubeListBuilder.create().texOffs(96, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_76", CubeListBuilder.create().texOffs(108, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_77", CubeListBuilder.create().texOffs(120, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_78", CubeListBuilder.create().texOffs(132, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_79", CubeListBuilder.create().texOffs(144, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -21.875F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_80", CubeListBuilder.create().texOffs(730, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -21.319444444444443F, 22.0F, 1.5707963267948966F, 0.0F, 0.27094685033842086F));
        g.addOrReplaceChild("casco_ladod_81", CubeListBuilder.create().texOffs(376, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -20.583333333333332F, 22.0F, 1.5707963267948966F, 0.0F, 0.13547342516920977F));
    }

    private static void piezas14(PartDefinition g) {
        g.addOrReplaceChild("casco_ladod_82", CubeListBuilder.create().texOffs(384, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -20.25F, 22.0F, 1.5707963267948966F, 0.0F, 0.13547342516921063F));
        g.addOrReplaceChild("casco_ladod_83", CubeListBuilder.create().texOffs(48, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -19.97222222222222F, 22.0F, 1.5707963267948966F, 0.0F, 0.13547342516920965F));
        g.addOrReplaceChild("casco_ladod_84", CubeListBuilder.create().texOffs(704, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -19.75F, 22.0F, 1.5707963267948966F, 0.0F, 0.13547342516921104F));
        g.addOrReplaceChild("casco_ladod_85", CubeListBuilder.create().texOffs(708, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -19.583333333333336F, 22.0F, 1.5707963267948966F, 0.0F, 0.13547342516921065F));
        g.addOrReplaceChild("casco_ladod_86", CubeListBuilder.create().texOffs(712, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -19.47222222222222F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_87", CubeListBuilder.create().texOffs(120, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.232128906250004F, 22.0F, 1.5707963267948966F, 0.0F, -0.22836736238143945F));
        g.addOrReplaceChild("casco_ladod_88", CubeListBuilder.create().texOffs(126, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.511035156250003F, 22.0F, 1.5707963267948966F, 0.0F, -0.22836736238143773F));
        g.addOrReplaceChild("casco_ladod_89", CubeListBuilder.create().texOffs(682, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -19.5166015625F, 22.0F, 1.5707963267948966F, 0.0F, -0.4037715697853255F));
        g.addOrReplaceChild("casco_ladod_90", CubeListBuilder.create().texOffs(744, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-36.0F, -21.30078125F, 22.0F, 1.5707963267948966F, 0.0F, -0.43512919388924687F));
        g.addOrReplaceChild("casco_ladod_91", CubeListBuilder.create().texOffs(156, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-32.5F, -22.927734375F, 22.0F, 1.5707963267948966F, 0.0F, -0.21756459694462352F));
        g.addOrReplaceChild("casco_ladod_92", CubeListBuilder.create().texOffs(54, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-30.5F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_93", CubeListBuilder.create().texOffs(168, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-28.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_94", CubeListBuilder.create().texOffs(180, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-24.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_95", CubeListBuilder.create().texOffs(192, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-20.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_96", CubeListBuilder.create().texOffs(204, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-15.999999999999998F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_97", CubeListBuilder.create().texOffs(216, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_98", CubeListBuilder.create().texOffs(228, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_99", CubeListBuilder.create().texOffs(240, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_100", CubeListBuilder.create().texOffs(252, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_101", CubeListBuilder.create().texOffs(264, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(3.9999999999999964F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_102", CubeListBuilder.create().texOffs(276, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_103", CubeListBuilder.create().texOffs(288, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_104", CubeListBuilder.create().texOffs(300, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_105", CubeListBuilder.create().texOffs(312, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(20.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_106", CubeListBuilder.create().texOffs(324, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(24.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_107", CubeListBuilder.create().texOffs(336, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(28.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_108", CubeListBuilder.create().texOffs(348, 244).addBox(-2.0F, -1.0F, -1.0F, 4.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(32.0F, -23.625F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_109", CubeListBuilder.create().texOffs(758, 238).addBox(-2.5F, -1.0F, -1.0F, 5.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(36.0F, -22.84722222222222F, 22.0F, 1.5707963267948966F, 0.0F, 0.3708912888126627F));
        g.addOrReplaceChild("casco_ladod_110", CubeListBuilder.create().texOffs(392, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(38.65F, -21.816666666666666F, 22.0F, 1.5707963267948966F, 0.0F, 0.1854456444063307F));
        g.addOrReplaceChild("casco_ladod_111", CubeListBuilder.create().texOffs(400, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(39.85F, -21.349999999999998F, 22.0F, 1.5707963267948966F, 0.0F, 0.18544564440633182F));
        g.addOrReplaceChild("casco_ladod_112", CubeListBuilder.create().texOffs(60, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(40.85F, -20.96111111111111F, 22.0F, 1.5707963267948966F, 0.0F, 0.1854456444063309F));
        g.addOrReplaceChild("casco_ladod_113", CubeListBuilder.create().texOffs(716, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -20.65F, 22.0F, 1.5707963267948966F, 0.0F, 0.18544564440633143F));
        g.addOrReplaceChild("casco_ladod_114", CubeListBuilder.create().texOffs(720, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -20.416666666666664F, 22.0F, 1.5707963267948966F, 0.0F, 0.1854456444063313F));
        g.addOrReplaceChild("casco_ladod_115", CubeListBuilder.create().texOffs(724, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -20.26111111111111F, 22.0F, 1.5707963267948966F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_116", CubeListBuilder.create().texOffs(728, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.180367808226126F, 21.97826403838506F, 1.7735463742713533F, 0.009638353161039436F, -0.3064795174657339F));
        g.addOrReplaceChild("casco_ladod_117", CubeListBuilder.create().texOffs(132, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.496817951587115F, 21.968154288796715F, 1.7735463742713498F, 0.009638353161041288F, -0.3064795174657344F));
        g.addOrReplaceChild("casco_ladod_118", CubeListBuilder.create().texOffs(138, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -18.8765581236203F, 21.9560225892907F, 1.7735463742713529F, 0.009638353161041323F, -0.30647951746573376F));
        g.addOrReplaceChild("casco_ladod_119", CubeListBuilder.create().texOffs(694, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.07525664553938F, 21.94618045072087F, 1.7886368652024789F, 0.0014647890075800583F, -0.46084606897965286F));
        g.addOrReplaceChild("casco_ladod_120", CubeListBuilder.create().texOffs(706, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -22.130762574273817F, 21.942909649383466F, 1.7923385276323984F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_121", CubeListBuilder.create().texOffs(1000, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -23.990137574273817F, 21.942909649383466F, 1.7923385276323986F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_122", CubeListBuilder.create().texOffs(732, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_123", CubeListBuilder.create().texOffs(1010, 261).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_124", CubeListBuilder.create().texOffs(0, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_125", CubeListBuilder.create().texOffs(10, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_126", CubeListBuilder.create().texOffs(20, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_127", CubeListBuilder.create().texOffs(30, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_128", CubeListBuilder.create().texOffs(40, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_129", CubeListBuilder.create().texOffs(50, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_130", CubeListBuilder.create().texOffs(60, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_131", CubeListBuilder.create().texOffs(70, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_132", CubeListBuilder.create().texOffs(80, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_133", CubeListBuilder.create().texOffs(90, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_134", CubeListBuilder.create().texOffs(100, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_135", CubeListBuilder.create().texOffs(110, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_136", CubeListBuilder.create().texOffs(120, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_137", CubeListBuilder.create().texOffs(130, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_138", CubeListBuilder.create().texOffs(140, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -24.787012574273817F, 21.942909649383466F, 1.7671458676442608F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_139", CubeListBuilder.create().texOffs(718, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -23.89812368538493F, 21.942909649383466F, 1.785126256462946F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladod_140", CubeListBuilder.create().texOffs(144, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -22.72034590760715F, 21.942909649383466F, 1.785126256462946F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladod_141", CubeListBuilder.create().texOffs(150, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -22.187012574273815F, 21.942909649383466F, 1.7851262564629462F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladod_142", CubeListBuilder.create().texOffs(736, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -21.742568129829372F, 21.942909649383466F, 1.7807768282625926F, 0.043279581922705194F, 0.21793548935718107F));
        g.addOrReplaceChild("casco_ladod_143", CubeListBuilder.create().texOffs(740, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -21.387012574273815F, 21.942909649383466F, 1.7807768282625926F, 0.0432795819227055F, 0.2179354893571824F));
        g.addOrReplaceChild("casco_ladod_144", CubeListBuilder.create().texOffs(744, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -21.12034590760715F, 21.942909649383466F, 1.7807768282625926F, 0.04327958192270517F, 0.21793548935718102F));
        g.addOrReplaceChild("casco_ladod_145", CubeListBuilder.create().texOffs(748, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -20.94256812982937F, 21.942909649383466F, 1.7807768282625929F, 0.04327958192270562F, 0.2179354893571827F));
        g.addOrReplaceChild("casco_ladod_146", CubeListBuilder.create().texOffs(752, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.382279939885255F, 21.894629295044187F, 2.183480950305094F, 0.04530944696258163F, -0.3894077494538908F));
        g.addOrReplaceChild("casco_ladod_147", CubeListBuilder.create().texOffs(156, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -18.79264270262258F, 21.84561966483218F, 2.1834809503051F, 0.045309446962581615F, -0.3894077494538931F));
        g.addOrReplaceChild("casco_ladod_148", CubeListBuilder.create().texOffs(162, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.285078017907374F, 21.786808108577773F, 2.1834809503050985F, 0.04530944696258319F, -0.38940774945389084F));
        g.addOrReplaceChild("casco_ladod_149", CubeListBuilder.create().texOffs(730, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.575203236925184F, 21.739095792106674F, 2.212338445519162F, 0.0070576043602407585F, -0.4729595476997946F));
        g.addOrReplaceChild("casco_ladod_150", CubeListBuilder.create().texOffs(742, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -22.66109266016373F, 21.723239735273374F, 2.2185176378058538F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_151", CubeListBuilder.create().texOffs(150, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -24.52046766016373F, 21.723239735273374F, 2.2185176378058538F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_152", CubeListBuilder.create().texOffs(756, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_153", CubeListBuilder.create().texOffs(160, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_154", CubeListBuilder.create().texOffs(170, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_155", CubeListBuilder.create().texOffs(180, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_156", CubeListBuilder.create().texOffs(190, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_157", CubeListBuilder.create().texOffs(200, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_158", CubeListBuilder.create().texOffs(210, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_159", CubeListBuilder.create().texOffs(220, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_160", CubeListBuilder.create().texOffs(230, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_161", CubeListBuilder.create().texOffs(240, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_162", CubeListBuilder.create().texOffs(250, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_163", CubeListBuilder.create().texOffs(260, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_164", CubeListBuilder.create().texOffs(270, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_165", CubeListBuilder.create().texOffs(280, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_166", CubeListBuilder.create().texOffs(290, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_167", CubeListBuilder.create().texOffs(300, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_168", CubeListBuilder.create().texOffs(310, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.31734266016373F, 21.723239735273374F, 2.1598449493429768F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_169", CubeListBuilder.create().texOffs(754, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -24.42845377127484F, 21.723239735273374F, 2.202156205383196F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladod_170", CubeListBuilder.create().texOffs(168, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.25067599349706F, 21.723239735273374F, 2.202156205383196F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladod_171", CubeListBuilder.create().texOffs(174, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -22.717342660163723F, 21.723239735273374F, 2.2021562053831962F, 0.0F, 0.4182243295792303F));
    }

    private static void piezas15(PartDefinition g) {
        g.addOrReplaceChild("casco_ladod_172", CubeListBuilder.create().texOffs(760, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.27289821571928F, 21.723239735273374F, 2.1950704588806107F, 0.1013300717166445F, 0.2787153807148607F));
        g.addOrReplaceChild("casco_ladod_173", CubeListBuilder.create().texOffs(764, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -21.917342660163726F, 21.723239735273374F, 2.1950704588806116F, 0.10133007171664508F, 0.2787153807148624F));
        g.addOrReplaceChild("casco_ladod_174", CubeListBuilder.create().texOffs(768, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -21.65067599349706F, 21.723239735273374F, 2.1950704588806107F, 0.10133007171664438F, 0.27871538071486057F));
        g.addOrReplaceChild("casco_ladod_175", CubeListBuilder.create().texOffs(772, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -21.472898215719283F, 21.723239735273374F, 2.1950704588806116F, 0.10133007171664528F, 0.27871538071486296F));
        g.addOrReplaceChild("casco_ladod_176", CubeListBuilder.create().texOffs(180, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.53681679504419F, 21.740092439885252F, 2.582873959244832F, 0.10845998036298939F, -0.4493392298148658F));
        g.addOrReplaceChild("casco_ladod_177", CubeListBuilder.create().texOffs(186, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.019057164832184F, 21.61920520262258F, 2.5828739592448273F, 0.10845998036298805F, -0.44933922981486685F));
        g.addOrReplaceChild("casco_ladod_178", CubeListBuilder.create().texOffs(192, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.597745608577775F, 21.474140517907372F, 2.5828739592448273F, 0.10845998036298911F, -0.4493392298148642F));
        g.addOrReplaceChild("casco_ladod_179", CubeListBuilder.create().texOffs(766, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -20.95784579210667F, 21.356453236925184F, 2.6046386885488584F, 0.01732442858115882F, -0.4821306373393771F));
        g.addOrReplaceChild("casco_ladod_180", CubeListBuilder.create().texOffs(778, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -23.066989735273374F, 21.317342660163728F, 2.608499901014315F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_181", CubeListBuilder.create().texOffs(320, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -24.926364735273374F, 21.317342660163728F, 2.608499901014315F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_182", CubeListBuilder.create().texOffs(776, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_183", CubeListBuilder.create().texOffs(330, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_184", CubeListBuilder.create().texOffs(340, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_185", CubeListBuilder.create().texOffs(350, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_186", CubeListBuilder.create().texOffs(360, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_187", CubeListBuilder.create().texOffs(370, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_188", CubeListBuilder.create().texOffs(380, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_189", CubeListBuilder.create().texOffs(390, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_190", CubeListBuilder.create().texOffs(400, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_191", CubeListBuilder.create().texOffs(410, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_192", CubeListBuilder.create().texOffs(420, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_193", CubeListBuilder.create().texOffs(430, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_194", CubeListBuilder.create().texOffs(440, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_195", CubeListBuilder.create().texOffs(450, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_196", CubeListBuilder.create().texOffs(460, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_197", CubeListBuilder.create().texOffs(470, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_198", CubeListBuilder.create().texOffs(480, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.723239735273374F, 21.317342660163728F, 2.552544031041713F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_199", CubeListBuilder.create().texOffs(790, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -24.834350846384485F, 21.317342660163728F, 2.5934232240457846F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladod_200", CubeListBuilder.create().texOffs(198, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.65657306860671F, 21.317342660163728F, 2.5934232240457846F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladod_201", CubeListBuilder.create().texOffs(204, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -23.123239735273376F, 21.317342660163728F, 2.593423224045785F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladod_202", CubeListBuilder.create().texOffs(780, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.67879529082893F, 21.317342660163728F, 2.5905327765359143F, 0.09706816482927975F, 0.35873360420314093F));
        g.addOrReplaceChild("casco_ladod_203", CubeListBuilder.create().texOffs(784, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -22.32323973527338F, 21.317342660163728F, 2.5905327765359147F, 0.09706816482928023F, 0.35873360420314304F));
        g.addOrReplaceChild("casco_ladod_204", CubeListBuilder.create().texOffs(788, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -22.056573068606706F, 21.317342660163728F, 2.590532776535914F, 0.09706816482927975F, 0.3587336042031406F));
        g.addOrReplaceChild("casco_ladod_205", CubeListBuilder.create().texOffs(792, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -21.87879529082893F, 21.317342660163728F, 2.5905327765359147F, 0.09706816482928046F, 0.35873360420314365F));
        g.addOrReplaceChild("casco_ladod_206", CubeListBuilder.create().texOffs(210, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-44.85F, -18.620451538385062F, 21.538180308226124F, 2.9608197790121387F, 0.18823006473349232F, -0.48041642531146883F));
        g.addOrReplaceChild("casco_ladod_207", CubeListBuilder.create().texOffs(216, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.141591788796717F, 21.323380451587113F, 2.9608197790121413F, 0.18823006473349305F, -0.48041642531146833F));
        g.addOrReplaceChild("casco_ladod_208", CubeListBuilder.create().texOffs(222, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-42.65F, -19.766960089290702F, 21.065620623620298F, 2.960819779012138F, 0.18823006473349232F, -0.480416425311467F));
        g.addOrReplaceChild("casco_ladod_209", CubeListBuilder.create().texOffs(802, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-40.0F, -21.16493045072087F, 20.85650664553938F, 2.9670193348032075F, 0.030696788914183027F, -0.4870576488112398F));
        g.addOrReplaceChild("casco_ladod_210", CubeListBuilder.create().texOffs(814, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-36.0F, -23.286659649383466F, 20.787012574273817F, 2.967704111419101F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_211", CubeListBuilder.create().texOffs(490, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-32.5F, -25.146034649383466F, 20.787012574273817F, 2.967704111419101F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_ladod_212", CubeListBuilder.create().texOffs(796, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-30.5F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_213", CubeListBuilder.create().texOffs(500, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-28.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_214", CubeListBuilder.create().texOffs(510, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-24.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_215", CubeListBuilder.create().texOffs(520, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-20.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_216", CubeListBuilder.create().texOffs(530, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-15.999999999999998F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_217", CubeListBuilder.create().texOffs(540, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-12.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_218", CubeListBuilder.create().texOffs(550, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-8.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_219", CubeListBuilder.create().texOffs(560, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-4.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_220", CubeListBuilder.create().texOffs(570, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(0.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_221", CubeListBuilder.create().texOffs(580, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(3.9999999999999964F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_222", CubeListBuilder.create().texOffs(590, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(8.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_223", CubeListBuilder.create().texOffs(600, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(12.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_224", CubeListBuilder.create().texOffs(610, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(16.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_225", CubeListBuilder.create().texOffs(620, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(20.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_226", CubeListBuilder.create().texOffs(630, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(24.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_227", CubeListBuilder.create().texOffs(640, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(28.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_228", CubeListBuilder.create().texOffs(650, 263).addBox(-2.0F, -1.0F, -0.5F, 4.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(32.0F, -25.942909649383466F, 20.787012574273817F, 2.945243112740429F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_ladod_229", CubeListBuilder.create().texOffs(826, 256).addBox(-2.5F, -1.0F, -0.5F, 5.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(36.0F, -25.054020760494573F, 20.787012574273817F, 2.961787325135448F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_ladod_230", CubeListBuilder.create().texOffs(228, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(38.65F, -23.8762429827168F, 20.787012574273817F, 2.961787325135448F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_ladod_231", CubeListBuilder.create().texOffs(234, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(39.85F, -23.342909649383465F, 20.787012574273817F, 2.961787325135448F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_ladod_232", CubeListBuilder.create().texOffs(800, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(40.85F, -22.898465204939022F, 20.787012574273817F, 2.9616488678553012F, 0.03901873250032806F, 0.4111282952483033F));
        g.addOrReplaceChild("casco_ladod_233", CubeListBuilder.create().texOffs(804, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(41.65F, -22.542909649383464F, 20.787012574273817F, 2.9616488678553017F, 0.03901873250032821F, 0.41112829524830585F));
        g.addOrReplaceChild("casco_ladod_234", CubeListBuilder.create().texOffs(808, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.25F, -22.276242982716795F, 20.787012574273817F, 2.9616488678553012F, 0.03901873250032806F, 0.4111282952483032F));
        g.addOrReplaceChild("casco_ladod_235", CubeListBuilder.create().texOffs(812, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(42.65F, -22.09846520493902F, 20.787012574273817F, 2.9616488678553017F, 0.03901873250032829F, 0.4111282952483067F));
        g.addOrReplaceChild("casco_arriba0_0", CubeListBuilder.create().texOffs(80, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, -18.255859375F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_1", CubeListBuilder.create().texOffs(98, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, -18.167317708333332F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_2", CubeListBuilder.create().texOffs(116, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, -18.034505208333332F, -3.141592653589793F, 0.0F, -0.48833395105640703F));
        g.addOrReplaceChild("casco_arriba0_3", CubeListBuilder.create().texOffs(740, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, -17.857421875F, -3.141592653589793F, 0.0F, -0.48833395105640487F));
        g.addOrReplaceChild("casco_arriba0_4", CubeListBuilder.create().texOffs(760, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, -17.636067708333332F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_5", CubeListBuilder.create().texOffs(780, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, -17.370442708333332F, -3.141592653589793F, 0.0F, -0.48833395105640476F));
        g.addOrReplaceChild("casco_arriba0_6", CubeListBuilder.create().texOffs(404, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, -17.154947916666668F, 3.141592653589793F, -0.015805724165091586F, -0.4883339510564056F));
        g.addOrReplaceChild("casco_arriba0_7", CubeListBuilder.create().texOffs(428, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, -17.083333333333336F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_8", CubeListBuilder.create().texOffs(836, 159).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, -17.083333333333336F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_9", CubeListBuilder.create().texOffs(260, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_10", CubeListBuilder.create().texOffs(858, 159).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_11", CubeListBuilder.create().texOffs(880, 159).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_12", CubeListBuilder.create().texOffs(902, 159).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_13", CubeListBuilder.create().texOffs(924, 159).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_14", CubeListBuilder.create().texOffs(946, 159).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_15", CubeListBuilder.create().texOffs(968, 159).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_16", CubeListBuilder.create().texOffs(990, 159).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_17", CubeListBuilder.create().texOffs(0, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_18", CubeListBuilder.create().texOffs(22, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_19", CubeListBuilder.create().texOffs(44, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_20", CubeListBuilder.create().texOffs(66, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_21", CubeListBuilder.create().texOffs(88, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_22", CubeListBuilder.create().texOffs(110, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_23", CubeListBuilder.create().texOffs(132, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_24", CubeListBuilder.create().texOffs(154, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_25", CubeListBuilder.create().texOffs(176, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, -17.083333333333336F, 3.141592653589793F, 0.0F, 0.0F));
    }

    private static void piezas16(PartDefinition g) {
        g.addOrReplaceChild("casco_arriba0_26", CubeListBuilder.create().texOffs(452, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_27", CubeListBuilder.create().texOffs(44, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_28", CubeListBuilder.create().texOffs(62, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_29", CubeListBuilder.create().texOffs(276, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_30", CubeListBuilder.create().texOffs(292, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_31", CubeListBuilder.create().texOffs(308, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_32", CubeListBuilder.create().texOffs(324, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, -17.083333333333336F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_arriba0_33", CubeListBuilder.create().texOffs(134, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, -10.953515625F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_34", CubeListBuilder.create().texOffs(152, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, -10.900390625F, -3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_35", CubeListBuilder.create().texOffs(170, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, -10.820703125000001F, -3.141592653589793F, 0.0F, -0.488333951056407F));
        g.addOrReplaceChild("casco_arriba0_36", CubeListBuilder.create().texOffs(800, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, -10.714453125F, -3.141592653589793F, 0.0F, -0.4883339510564049F));
        g.addOrReplaceChild("casco_arriba0_37", CubeListBuilder.create().texOffs(820, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, -10.581640625000002F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_38", CubeListBuilder.create().texOffs(840, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, -10.422265625F, -3.141592653589793F, 0.0F, -0.4883339510564047F));
        g.addOrReplaceChild("casco_arriba0_39", CubeListBuilder.create().texOffs(476, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, -10.292968750000002F, -3.141592653589793F, -0.009485456554255301F, -0.4883339510564056F));
        g.addOrReplaceChild("casco_arriba0_40", CubeListBuilder.create().texOffs(500, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, -10.250000000000002F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_41", CubeListBuilder.create().texOffs(198, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, -10.250000000000002F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_42", CubeListBuilder.create().texOffs(340, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_43", CubeListBuilder.create().texOffs(220, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_44", CubeListBuilder.create().texOffs(242, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_45", CubeListBuilder.create().texOffs(264, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_46", CubeListBuilder.create().texOffs(286, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_47", CubeListBuilder.create().texOffs(308, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_48", CubeListBuilder.create().texOffs(330, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_49", CubeListBuilder.create().texOffs(352, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_50", CubeListBuilder.create().texOffs(374, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_51", CubeListBuilder.create().texOffs(396, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_52", CubeListBuilder.create().texOffs(418, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_53", CubeListBuilder.create().texOffs(440, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_54", CubeListBuilder.create().texOffs(462, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_55", CubeListBuilder.create().texOffs(484, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_56", CubeListBuilder.create().texOffs(506, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_57", CubeListBuilder.create().texOffs(528, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_58", CubeListBuilder.create().texOffs(550, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, -10.250000000000002F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_59", CubeListBuilder.create().texOffs(524, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_60", CubeListBuilder.create().texOffs(80, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_61", CubeListBuilder.create().texOffs(98, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_62", CubeListBuilder.create().texOffs(356, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_63", CubeListBuilder.create().texOffs(372, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_64", CubeListBuilder.create().texOffs(388, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_65", CubeListBuilder.create().texOffs(404, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, -10.250000000000002F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_arriba0_66", CubeListBuilder.create().texOffs(188, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, -3.651171875F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_67", CubeListBuilder.create().texOffs(206, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, -3.633463541666667F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_68", CubeListBuilder.create().texOffs(224, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, -3.606901041666667F, -3.141592653589793F, 0.0F, -0.488333951056407F));
        g.addOrReplaceChild("casco_arriba0_69", CubeListBuilder.create().texOffs(860, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, -3.5714843750000003F, -3.141592653589793F, 0.0F, -0.4883339510564049F));
        g.addOrReplaceChild("casco_arriba0_70", CubeListBuilder.create().texOffs(880, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, -3.527213541666667F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_71", CubeListBuilder.create().texOffs(900, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, -3.4740885416666667F, -3.141592653589793F, 0.0F, -0.48833395105640476F));
        g.addOrReplaceChild("casco_arriba0_72", CubeListBuilder.create().texOffs(548, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, -3.4309895833333335F, 3.141592653589793F, -0.00316215605469034F, -0.4883339510564054F));
        g.addOrReplaceChild("casco_arriba0_73", CubeListBuilder.create().texOffs(572, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, -3.416666666666667F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_74", CubeListBuilder.create().texOffs(572, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, -3.416666666666667F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_75", CubeListBuilder.create().texOffs(420, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_76", CubeListBuilder.create().texOffs(594, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_77", CubeListBuilder.create().texOffs(616, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_78", CubeListBuilder.create().texOffs(638, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_79", CubeListBuilder.create().texOffs(660, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_80", CubeListBuilder.create().texOffs(682, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_81", CubeListBuilder.create().texOffs(704, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_82", CubeListBuilder.create().texOffs(726, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_83", CubeListBuilder.create().texOffs(748, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_84", CubeListBuilder.create().texOffs(770, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_85", CubeListBuilder.create().texOffs(792, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_86", CubeListBuilder.create().texOffs(814, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_87", CubeListBuilder.create().texOffs(836, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_88", CubeListBuilder.create().texOffs(858, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_89", CubeListBuilder.create().texOffs(880, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_90", CubeListBuilder.create().texOffs(902, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_91", CubeListBuilder.create().texOffs(924, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, -3.416666666666667F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_92", CubeListBuilder.create().texOffs(596, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_93", CubeListBuilder.create().texOffs(116, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_94", CubeListBuilder.create().texOffs(134, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_95", CubeListBuilder.create().texOffs(436, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_96", CubeListBuilder.create().texOffs(452, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_97", CubeListBuilder.create().texOffs(468, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_98", CubeListBuilder.create().texOffs(484, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, -3.416666666666667F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_arriba0_99", CubeListBuilder.create().texOffs(242, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, 3.6511718749999993F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_100", CubeListBuilder.create().texOffs(260, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, 3.633463541666666F, -3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_101", CubeListBuilder.create().texOffs(278, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, 3.6069010416666654F, -3.141592653589793F, 0.0F, -0.488333951056407F));
        g.addOrReplaceChild("casco_arriba0_102", CubeListBuilder.create().texOffs(920, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, 3.571484374999999F, -3.141592653589793F, 0.0F, -0.4883339510564049F));
        g.addOrReplaceChild("casco_arriba0_103", CubeListBuilder.create().texOffs(940, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, 3.527213541666666F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_104", CubeListBuilder.create().texOffs(960, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, 3.4740885416666663F, -3.141592653589793F, 0.0F, -0.48833395105640476F));
        g.addOrReplaceChild("casco_arriba0_105", CubeListBuilder.create().texOffs(620, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, 3.430989583333333F, -3.141592653589793F, 0.0031621560546904186F, -0.4883339510564054F));
        g.addOrReplaceChild("casco_arriba0_106", CubeListBuilder.create().texOffs(644, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, 3.416666666666666F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_107", CubeListBuilder.create().texOffs(946, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, 3.416666666666666F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_108", CubeListBuilder.create().texOffs(500, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_109", CubeListBuilder.create().texOffs(968, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_110", CubeListBuilder.create().texOffs(990, 168).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_111", CubeListBuilder.create().texOffs(0, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_112", CubeListBuilder.create().texOffs(22, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_113", CubeListBuilder.create().texOffs(44, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_114", CubeListBuilder.create().texOffs(66, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_115", CubeListBuilder.create().texOffs(88, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
    }

    private static void piezas17(PartDefinition g) {
        g.addOrReplaceChild("casco_arriba0_116", CubeListBuilder.create().texOffs(110, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_117", CubeListBuilder.create().texOffs(132, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_118", CubeListBuilder.create().texOffs(154, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_119", CubeListBuilder.create().texOffs(176, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_120", CubeListBuilder.create().texOffs(198, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_121", CubeListBuilder.create().texOffs(220, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_122", CubeListBuilder.create().texOffs(242, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_123", CubeListBuilder.create().texOffs(264, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_124", CubeListBuilder.create().texOffs(286, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, 3.416666666666666F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_125", CubeListBuilder.create().texOffs(668, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_126", CubeListBuilder.create().texOffs(152, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_127", CubeListBuilder.create().texOffs(170, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_128", CubeListBuilder.create().texOffs(516, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_129", CubeListBuilder.create().texOffs(532, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_130", CubeListBuilder.create().texOffs(548, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_131", CubeListBuilder.create().texOffs(564, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, 3.416666666666666F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_arriba0_132", CubeListBuilder.create().texOffs(296, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, 10.953515624999998F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_133", CubeListBuilder.create().texOffs(314, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, 10.900390624999998F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_134", CubeListBuilder.create().texOffs(332, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, 10.820703124999996F, -3.141592653589793F, 0.0F, -0.488333951056407F));
        g.addOrReplaceChild("casco_arriba0_135", CubeListBuilder.create().texOffs(980, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, 10.714453124999995F, -3.141592653589793F, 0.0F, -0.4883339510564049F));
        g.addOrReplaceChild("casco_arriba0_136", CubeListBuilder.create().texOffs(1000, 146).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, 10.581640624999997F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_137", CubeListBuilder.create().texOffs(0, 159).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, 10.422265624999998F, -3.141592653589793F, 0.0F, -0.4883339510564047F));
        g.addOrReplaceChild("casco_arriba0_138", CubeListBuilder.create().texOffs(692, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, 10.29296875F, 3.141592653589793F, 0.009485456554255537F, -0.4883339510564056F));
        g.addOrReplaceChild("casco_arriba0_139", CubeListBuilder.create().texOffs(716, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, 10.249999999999998F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_140", CubeListBuilder.create().texOffs(308, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, 10.249999999999998F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_141", CubeListBuilder.create().texOffs(580, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_142", CubeListBuilder.create().texOffs(330, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_143", CubeListBuilder.create().texOffs(352, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_144", CubeListBuilder.create().texOffs(374, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_145", CubeListBuilder.create().texOffs(396, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_146", CubeListBuilder.create().texOffs(418, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_147", CubeListBuilder.create().texOffs(440, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_148", CubeListBuilder.create().texOffs(462, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_149", CubeListBuilder.create().texOffs(484, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_150", CubeListBuilder.create().texOffs(506, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_151", CubeListBuilder.create().texOffs(528, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_152", CubeListBuilder.create().texOffs(550, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_153", CubeListBuilder.create().texOffs(572, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_154", CubeListBuilder.create().texOffs(594, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_155", CubeListBuilder.create().texOffs(616, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_156", CubeListBuilder.create().texOffs(638, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_157", CubeListBuilder.create().texOffs(660, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, 10.249999999999998F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_158", CubeListBuilder.create().texOffs(740, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_159", CubeListBuilder.create().texOffs(188, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_160", CubeListBuilder.create().texOffs(206, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_161", CubeListBuilder.create().texOffs(596, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_162", CubeListBuilder.create().texOffs(612, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_163", CubeListBuilder.create().texOffs(628, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_164", CubeListBuilder.create().texOffs(644, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, 10.249999999999998F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_arriba0_165", CubeListBuilder.create().texOffs(350, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.65F, -17.6859375F, 18.255859375F, -3.141592653589793F, 0.0F, -0.48833395105640204F));
        g.addOrReplaceChild("casco_arriba0_166", CubeListBuilder.create().texOffs(368, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-46.25F, -17.8984375F, 18.167317708333332F, -3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_167", CubeListBuilder.create().texOffs(386, 159).addBox(-0.5F, -1.0F, -4.0F, 1.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-45.650000000000006F, -18.2171875F, 18.03450520833333F, -3.141592653589793F, 0.0F, -0.48833395105640703F));
        g.addOrReplaceChild("casco_arriba0_168", CubeListBuilder.create().texOffs(20, 159).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-44.85F, -18.642187500000002F, 17.857421874999996F, -3.141592653589793F, 0.0F, -0.488333951056405F));
        g.addOrReplaceChild("casco_arriba0_169", CubeListBuilder.create().texOffs(40, 159).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-43.849999999999994F, -19.173437500000002F, 17.63606770833333F, -3.141592653589793F, 0.0F, -0.488333951056406F));
        g.addOrReplaceChild("casco_arriba0_170", CubeListBuilder.create().texOffs(60, 159).addBox(-1.0F, -1.0F, -4.0F, 2.0F, 1.0F, 8.0F), PartPose.offsetAndRotation(-42.65F, -19.8109375F, 17.370442708333332F, -3.141592653589793F, 0.0F, -0.4883339510564048F));
        g.addOrReplaceChild("casco_arriba0_171", CubeListBuilder.create().texOffs(764, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-40.0F, -21.21875F, 17.154947916666664F, -3.141592653589793F, 0.015805724165091743F, -0.4883339510564056F));
        g.addOrReplaceChild("casco_arriba0_172", CubeListBuilder.create().texOffs(788, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-36.0F, -23.34375F, 17.083333333333332F, 3.141592653589793F, 0.0F, -0.4883339510564055F));
        g.addOrReplaceChild("casco_arriba0_173", CubeListBuilder.create().texOffs(682, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-32.5F, -25.203125F, 17.083333333333332F, -3.141592653589793F, 0.0F, -0.48833395105640554F));
        g.addOrReplaceChild("casco_arriba0_174", CubeListBuilder.create().texOffs(660, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-30.5F, -26.0F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_175", CubeListBuilder.create().texOffs(704, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-28.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_176", CubeListBuilder.create().texOffs(726, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-24.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_177", CubeListBuilder.create().texOffs(748, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-20.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_178", CubeListBuilder.create().texOffs(770, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-15.999999999999998F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_179", CubeListBuilder.create().texOffs(792, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-12.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_180", CubeListBuilder.create().texOffs(814, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-8.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_181", CubeListBuilder.create().texOffs(836, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(-4.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_182", CubeListBuilder.create().texOffs(858, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(0.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_183", CubeListBuilder.create().texOffs(880, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(3.9999999999999964F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_184", CubeListBuilder.create().texOffs(902, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(8.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_185", CubeListBuilder.create().texOffs(924, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(12.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_186", CubeListBuilder.create().texOffs(946, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(16.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_187", CubeListBuilder.create().texOffs(968, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(20.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_188", CubeListBuilder.create().texOffs(990, 176).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(24.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_189", CubeListBuilder.create().texOffs(0, 184).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(28.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_190", CubeListBuilder.create().texOffs(22, 184).addBox(-2.0F, -1.0F, -3.5F, 4.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(32.0F, -26.0F, 17.083333333333332F, 3.141592653589793F, 0.0F, 0.0F));
        g.addOrReplaceChild("casco_arriba0_191", CubeListBuilder.create().texOffs(812, 159).addBox(-2.5F, -1.0F, -3.5F, 5.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(36.0F, -25.111111111111114F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792292F));
        g.addOrReplaceChild("casco_arriba0_192", CubeListBuilder.create().texOffs(224, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(38.65F, -23.933333333333334F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792286F));
        g.addOrReplaceChild("casco_arriba0_193", CubeListBuilder.create().texOffs(242, 184).addBox(-1.0F, -1.0F, -3.5F, 2.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(39.85F, -23.4F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792303F));
        g.addOrReplaceChild("casco_arriba0_194", CubeListBuilder.create().texOffs(676, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(40.85F, -22.955555555555556F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.418224329579228F));
        g.addOrReplaceChild("casco_arriba0_195", CubeListBuilder.create().texOffs(692, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(41.65F, -22.599999999999998F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792305F));
        g.addOrReplaceChild("casco_arriba0_196", CubeListBuilder.create().texOffs(708, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.25F, -22.333333333333336F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792278F));
        g.addOrReplaceChild("casco_arriba0_197", CubeListBuilder.create().texOffs(724, 184).addBox(-0.5F, -1.0F, -3.5F, 1.0F, 1.0F, 7.0F), PartPose.offsetAndRotation(42.65F, -22.155555555555555F, 17.083333333333332F, -3.141592653589793F, 0.0F, 0.4182243295792313F));
        g.addOrReplaceChild("casco_trompa", CubeListBuilder.create().texOffs(0, 0).addBox(0.0F, -21.0F, 0.0F, 1.0F, 21.0F, 88.0F), PartPose.offset(-47.0F, -16.5F, -22.0F));
        g.addOrReplaceChild("casco_cola", CubeListBuilder.create().texOffs(178, 0).addBox(0.0F, -21.0F, 0.0F, 1.0F, 21.0F, 88.0F), PartPose.offset(42.0F, -16.5F, -22.0F));
        g.addOrReplaceChild("brocal_conductor", CubeListBuilder.create().texOffs(832, 109).addBox(-31.0F, -27.0F, -17.0F, 1.0F, 1.0F, 16.0F).texOffs(866, 109).addBox(-18.0F, -27.0F, -17.0F, 1.0F, 1.0F, 16.0F).texOffs(402, 256).addBox(-30.0F, -27.0F, -18.0F, 12.0F, 1.0F, 1.0F).texOffs(428, 256).addBox(-30.0F, -27.0F, -1.0F, 12.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("tapa_conductor", CubeListBuilder.create().texOffs(812, 0).addBox(-18.0F, 0.0F, -18.0F, 36.0F, 1.0F, 36.0F), PartPose.offsetAndRotation(-24.0F, -29.0F, -19.5F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("torreta_ladoi_0", CubeListBuilder.create().texOffs(66, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -27.0F, -3.4826435063320007F, -1.5707963267948966F, 0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_1", CubeListBuilder.create().texOffs(408, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -27.0F, -4.339958396679818F, -1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_2", CubeListBuilder.create().texOffs(416, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -27.0F, -5.803540081128164F, -1.5707963267948966F, 1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_3", CubeListBuilder.create().texOffs(424, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -27.0F, -7.255417854035452F, -1.5707963267948966F, 1.010362329413617F, 0.0F));
    }

    private static void piezas18(PartDefinition g) {
        g.addOrReplaceChild("torreta_ladoi_4", CubeListBuilder.create().texOffs(432, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -27.0F, -8.65750878476372F, -1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_5", CubeListBuilder.create().texOffs(440, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -27.0F, -9.983733334909786F, -1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_6", CubeListBuilder.create().texOffs(400, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -27.0F, -11.377641910438154F, -1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_7", CubeListBuilder.create().texOffs(410, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -27.0F, -12.68282077273567F, -1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_8", CubeListBuilder.create().texOffs(420, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -27.0F, -13.634988406141265F, -1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_9", CubeListBuilder.create().texOffs(430, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -27.0F, -14.306772954019928F, -1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_10", CubeListBuilder.create().texOffs(440, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -27.0F, -14.737347643231958F, -1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_11", CubeListBuilder.create().texOffs(450, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -27.0F, -14.947916036529765F, -1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_12", CubeListBuilder.create().texOffs(460, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -27.0F, -14.947916036529765F, -1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_13", CubeListBuilder.create().texOffs(470, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -27.0F, -14.737347643231958F, -1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_14", CubeListBuilder.create().texOffs(480, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -27.0F, -14.306772954019928F, -1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_15", CubeListBuilder.create().texOffs(490, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -27.0F, -13.634988406141265F, -1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_16", CubeListBuilder.create().texOffs(500, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -27.0F, -12.68282077273567F, -1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_17", CubeListBuilder.create().texOffs(510, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -27.0F, -11.377641910438154F, -1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_18", CubeListBuilder.create().texOffs(448, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -27.0F, -9.983733334909786F, -1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_19", CubeListBuilder.create().texOffs(456, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -27.0F, -8.657508784763722F, -1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_20", CubeListBuilder.create().texOffs(464, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -27.0F, -7.255417854035457F, -1.5707963267948966F, -1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_21", CubeListBuilder.create().texOffs(472, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -27.0F, -5.803540081128168F, -1.5707963267948966F, -1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_22", CubeListBuilder.create().texOffs(480, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -27.0F, -4.339958396679818F, -1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_23", CubeListBuilder.create().texOffs(72, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -27.0F, -3.482643506332001F, -1.5707963267948966F, -0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_24", CubeListBuilder.create().texOffs(78, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -29.0F, -3.4826435063320007F, -1.5707963267948966F, 0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_25", CubeListBuilder.create().texOffs(488, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -29.0F, -4.339958396679818F, -1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_26", CubeListBuilder.create().texOffs(496, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -29.0F, -5.803540081128164F, -1.5707963267948966F, 1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_27", CubeListBuilder.create().texOffs(504, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -29.0F, -7.255417854035452F, -1.5707963267948966F, 1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_28", CubeListBuilder.create().texOffs(512, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -29.0F, -8.65750878476372F, -1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_29", CubeListBuilder.create().texOffs(520, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -29.0F, -9.983733334909786F, -1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_30", CubeListBuilder.create().texOffs(520, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -29.0F, -11.377641910438154F, -1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_31", CubeListBuilder.create().texOffs(530, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -29.0F, -12.68282077273567F, -1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_32", CubeListBuilder.create().texOffs(540, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -29.0F, -13.634988406141265F, -1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_33", CubeListBuilder.create().texOffs(550, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -29.0F, -14.306772954019928F, -1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_34", CubeListBuilder.create().texOffs(560, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -29.0F, -14.737347643231958F, -1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_35", CubeListBuilder.create().texOffs(570, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -29.0F, -14.947916036529765F, -1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_36", CubeListBuilder.create().texOffs(580, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -29.0F, -14.947916036529765F, -1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_37", CubeListBuilder.create().texOffs(590, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -29.0F, -14.737347643231958F, -1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_38", CubeListBuilder.create().texOffs(600, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -29.0F, -14.306772954019928F, -1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_39", CubeListBuilder.create().texOffs(610, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -29.0F, -13.634988406141265F, -1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_40", CubeListBuilder.create().texOffs(620, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -29.0F, -12.68282077273567F, -1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_41", CubeListBuilder.create().texOffs(630, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -29.0F, -11.377641910438154F, -1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_42", CubeListBuilder.create().texOffs(528, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -29.0F, -9.983733334909786F, -1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_43", CubeListBuilder.create().texOffs(536, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -29.0F, -8.657508784763722F, -1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_44", CubeListBuilder.create().texOffs(544, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -29.0F, -7.255417854035457F, -1.5707963267948966F, -1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_45", CubeListBuilder.create().texOffs(552, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -29.0F, -5.803540081128168F, -1.5707963267948966F, -1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_46", CubeListBuilder.create().texOffs(560, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -29.0F, -4.339958396679818F, -1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_47", CubeListBuilder.create().texOffs(84, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -29.0F, -3.482643506332001F, -1.5707963267948966F, -0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_48", CubeListBuilder.create().texOffs(90, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -31.0F, -3.4826435063320007F, -1.5707963267948966F, 0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_49", CubeListBuilder.create().texOffs(568, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -31.0F, -4.339958396679818F, -1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_50", CubeListBuilder.create().texOffs(576, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -31.0F, -5.803540081128164F, -1.5707963267948966F, 1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_51", CubeListBuilder.create().texOffs(584, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -31.0F, -7.255417854035452F, -1.5707963267948966F, 1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_52", CubeListBuilder.create().texOffs(592, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -31.0F, -8.65750878476372F, -1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_53", CubeListBuilder.create().texOffs(600, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -31.0F, -9.983733334909786F, -1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_54", CubeListBuilder.create().texOffs(640, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -31.0F, -11.377641910438154F, -1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_55", CubeListBuilder.create().texOffs(650, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -31.0F, -12.68282077273567F, -1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_56", CubeListBuilder.create().texOffs(660, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -31.0F, -13.634988406141265F, -1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_57", CubeListBuilder.create().texOffs(670, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -31.0F, -14.306772954019928F, -1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_58", CubeListBuilder.create().texOffs(680, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -31.0F, -14.737347643231958F, -1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_59", CubeListBuilder.create().texOffs(690, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -31.0F, -14.947916036529765F, -1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_60", CubeListBuilder.create().texOffs(700, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -31.0F, -14.947916036529765F, -1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_61", CubeListBuilder.create().texOffs(710, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -31.0F, -14.737347643231958F, -1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_62", CubeListBuilder.create().texOffs(720, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -31.0F, -14.306772954019928F, -1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_63", CubeListBuilder.create().texOffs(730, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -31.0F, -13.634988406141265F, -1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_64", CubeListBuilder.create().texOffs(740, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -31.0F, -12.68282077273567F, -1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_65", CubeListBuilder.create().texOffs(750, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -31.0F, -11.377641910438154F, -1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_66", CubeListBuilder.create().texOffs(608, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -31.0F, -9.983733334909786F, -1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_67", CubeListBuilder.create().texOffs(616, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -31.0F, -8.657508784763722F, -1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_68", CubeListBuilder.create().texOffs(624, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -31.0F, -7.255417854035457F, -1.5707963267948966F, -1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_69", CubeListBuilder.create().texOffs(632, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -31.0F, -5.803540081128168F, -1.5707963267948966F, -1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_70", CubeListBuilder.create().texOffs(640, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -31.0F, -4.339958396679818F, -1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_71", CubeListBuilder.create().texOffs(96, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -31.0F, -3.482643506332001F, -1.5707963267948966F, -0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_72", CubeListBuilder.create().texOffs(102, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -33.0F, -3.4826435063320007F, -1.5707963267948966F, 0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_73", CubeListBuilder.create().texOffs(648, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -33.0F, -4.339958396679818F, -1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_74", CubeListBuilder.create().texOffs(656, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -33.0F, -5.803540081128164F, -1.5707963267948966F, 1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_75", CubeListBuilder.create().texOffs(664, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -33.0F, -7.255417854035452F, -1.5707963267948966F, 1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_76", CubeListBuilder.create().texOffs(672, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -33.0F, -8.65750878476372F, -1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_77", CubeListBuilder.create().texOffs(680, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -33.0F, -9.983733334909786F, -1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_78", CubeListBuilder.create().texOffs(760, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -33.0F, -11.377641910438154F, -1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_79", CubeListBuilder.create().texOffs(770, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -33.0F, -12.68282077273567F, -1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_80", CubeListBuilder.create().texOffs(780, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -33.0F, -13.634988406141265F, -1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_81", CubeListBuilder.create().texOffs(790, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -33.0F, -14.306772954019928F, -1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_82", CubeListBuilder.create().texOffs(800, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -33.0F, -14.737347643231958F, -1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_83", CubeListBuilder.create().texOffs(810, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -33.0F, -14.947916036529765F, -1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_84", CubeListBuilder.create().texOffs(820, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -33.0F, -14.947916036529765F, -1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_85", CubeListBuilder.create().texOffs(830, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -33.0F, -14.737347643231958F, -1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_86", CubeListBuilder.create().texOffs(840, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -33.0F, -14.306772954019928F, -1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_87", CubeListBuilder.create().texOffs(850, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -33.0F, -13.634988406141265F, -1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_88", CubeListBuilder.create().texOffs(860, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -33.0F, -12.68282077273567F, -1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_89", CubeListBuilder.create().texOffs(870, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -33.0F, -11.377641910438154F, -1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_90", CubeListBuilder.create().texOffs(688, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -33.0F, -9.983733334909786F, -1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_91", CubeListBuilder.create().texOffs(696, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -33.0F, -8.657508784763722F, -1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_92", CubeListBuilder.create().texOffs(704, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -33.0F, -7.255417854035457F, -1.5707963267948966F, -1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_93", CubeListBuilder.create().texOffs(712, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -33.0F, -5.803540081128168F, -1.5707963267948966F, -1.1262758723375514F, 0.0F));
    }

    private static void piezas19(PartDefinition g) {
        g.addOrReplaceChild("torreta_ladoi_94", CubeListBuilder.create().texOffs(720, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -33.0F, -4.339958396679818F, -1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_95", CubeListBuilder.create().texOffs(108, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -33.0F, -3.482643506332001F, -1.5707963267948966F, -0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_96", CubeListBuilder.create().texOffs(114, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -34.57402514854763F, -3.3684628050989307F, -1.8250125743264949F, 0.6828977330950954F, -0.16252283561685563F));
        g.addOrReplaceChild("torreta_ladoi_97", CubeListBuilder.create().texOffs(728, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -34.57402514854763F, -4.225777695446748F, -1.8940078886793636F, 1.2222952223879582F, -0.274218461605764F));
        g.addOrReplaceChild("torreta_ladoi_98", CubeListBuilder.create().texOffs(736, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -34.57402514854763F, -5.689359379895094F, -1.8359021474358057F, 1.110771209834459F, -0.19973945437795396F));
        g.addOrReplaceChild("torreta_ladoi_99", CubeListBuilder.create().texOffs(744, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -34.57402514854763F, -7.141237152802382F, -1.8046564746427858F, 0.9963153976068317F, -0.15231653509744F));
        g.addOrReplaceChild("torreta_ladoi_100", CubeListBuilder.create().texOffs(752, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -34.57402514854763F, -8.543328083530652F, -1.7872668221271308F, 0.8813405994108005F, -0.11928590581640346F));
        g.addOrReplaceChild("torreta_ladoi_101", CubeListBuilder.create().texOffs(760, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -34.57402514854763F, -9.869552633676715F, -1.7774867102570833F, 0.7666989132568279F, -0.0945404819847156F));
        g.addOrReplaceChild("torreta_ladoi_102", CubeListBuilder.create().texOffs(880, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -34.57402514854763F, -11.263461209205083F, -1.7284015597582516F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_103", CubeListBuilder.create().texOffs(890, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -34.57402514854763F, -12.5686400715026F, -1.7685726602340672F, 0.49604440927838767F, -0.052924265248671616F));
        g.addOrReplaceChild("torreta_ladoi_104", CubeListBuilder.create().texOffs(900, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -34.57402514854763F, -13.520807704908194F, -1.7675268706013907F, 0.3734096587135649F, -0.03827065184366676F));
        g.addOrReplaceChild("torreta_ladoi_105", CubeListBuilder.create().texOffs(910, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -34.57402514854763F, -14.19259225278686F, -1.7672005563238273F, 0.26074408856128006F, -0.026042315212402013F));
        g.addOrReplaceChild("torreta_ladoi_106", CubeListBuilder.create().texOffs(920, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -34.57402514854763F, -14.623166941998889F, -1.7671377204012728F, 0.15421558868568414F, -0.015164715370441974F));
        g.addOrReplaceChild("torreta_ladoi_107", CubeListBuilder.create().texOffs(930, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -34.57402514854763F, -14.833735335296694F, -1.767143573659609F, 0.051047752130763846F, -0.004983004511430807F));
        g.addOrReplaceChild("torreta_ladoi_108", CubeListBuilder.create().texOffs(940, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -34.57402514854763F, -14.833735335296694F, -1.767143573659609F, -0.051047752130763846F, 0.004983004511430807F));
        g.addOrReplaceChild("torreta_ladoi_109", CubeListBuilder.create().texOffs(950, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -34.57402514854763F, -14.623166941998889F, -1.7671377204012728F, -0.15421558868568414F, 0.015164715370441974F));
        g.addOrReplaceChild("torreta_ladoi_110", CubeListBuilder.create().texOffs(960, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -34.57402514854763F, -14.19259225278686F, -1.7672005563238273F, -0.26074408856128006F, 0.026042315212402013F));
        g.addOrReplaceChild("torreta_ladoi_111", CubeListBuilder.create().texOffs(970, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -34.57402514854763F, -13.520807704908194F, -1.7675268706013907F, -0.3734096587135649F, 0.03827065184366676F));
        g.addOrReplaceChild("torreta_ladoi_112", CubeListBuilder.create().texOffs(980, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -34.57402514854763F, -12.5686400715026F, -1.7685726602340672F, -0.49604440927838767F, 0.052924265248671616F));
        g.addOrReplaceChild("torreta_ladoi_113", CubeListBuilder.create().texOffs(990, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -34.57402514854763F, -11.263461209205083F, -1.7284015597582516F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_114", CubeListBuilder.create().texOffs(768, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -34.57402514854763F, -9.869552633676715F, -1.7774867102570833F, -0.7666989132568279F, 0.0945404819847156F));
        g.addOrReplaceChild("torreta_ladoi_115", CubeListBuilder.create().texOffs(776, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -34.57402514854763F, -8.543328083530652F, -1.7872668221271308F, -0.8813405994108003F, 0.11928590581640343F));
        g.addOrReplaceChild("torreta_ladoi_116", CubeListBuilder.create().texOffs(784, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -34.57402514854763F, -7.141237152802388F, -1.8046564746427853F, -0.9963153976068305F, 0.1523165350974396F));
        g.addOrReplaceChild("torreta_ladoi_117", CubeListBuilder.create().texOffs(792, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -34.57402514854763F, -5.689359379895098F, -1.835902147435806F, -1.1107712098344598F, 0.19973945437795393F));
        g.addOrReplaceChild("torreta_ladoi_118", CubeListBuilder.create().texOffs(800, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -34.57402514854763F, -4.225777695446748F, -1.8940078886793636F, -1.2222952223879582F, 0.274218461605764F));
        g.addOrReplaceChild("torreta_ladoi_119", CubeListBuilder.create().texOffs(120, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -34.57402514854763F, -3.368462805098931F, -1.8250125743264962F, -0.6828977330951009F, 0.16252283561685757F));
        g.addOrReplaceChild("torreta_ladoi_120", CubeListBuilder.create().texOffs(126, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -35.634685320327456F, -2.929122976878752F, -2.2578787740092774F, 0.5034964075333622F, -0.37692914871594485F));
        g.addOrReplaceChild("torreta_ladoi_121", CubeListBuilder.create().texOffs(808, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -35.634685320327456F, -3.7864378672265695F, -2.3677090703253425F, 1.0998607686473072F, -0.628997744924369F));
        g.addOrReplaceChild("torreta_ladoi_122", CubeListBuilder.create().texOffs(816, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -35.634685320327456F, -5.250019551674915F, -2.272241936664782F, 0.9991290541514302F, -0.47950331969790666F));
        g.addOrReplaceChild("torreta_ladoi_123", CubeListBuilder.create().texOffs(824, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -35.634685320327456F, -6.7018973245822036F, -2.217294122847617F, 0.8924117308485013F, -0.3727670399277488F));
        g.addOrReplaceChild("torreta_ladoi_124", CubeListBuilder.create().texOffs(832, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -35.634685320327456F, -8.103988255310473F, -2.1867420482879956F, 0.7846873388092357F, -0.2938464331408857F));
        g.addOrReplaceChild("torreta_ladoi_125", CubeListBuilder.create().texOffs(840, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -35.634685320327456F, -9.430212805456538F, -2.1704422095415867F, 0.6781360126157805F, -0.23293867028232346F));
        g.addOrReplaceChild("torreta_ladoi_126", CubeListBuilder.create().texOffs(1000, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -35.634685320327456F, -10.824121380984906F, -2.06115490473932F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_127", CubeListBuilder.create().texOffs(1010, 244).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -35.634685320327456F, -12.129300243282422F, -2.158498621692187F, 0.4325648064011882F, -0.12926946651335153F));
        g.addOrReplaceChild("torreta_ladoi_128", CubeListBuilder.create().texOffs(0, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -35.634685320327456F, -13.081467876688016F, -2.158246782790705F, 0.32404121878210596F, -0.09305056010223281F));
        g.addOrReplaceChild("torreta_ladoi_129", CubeListBuilder.create().texOffs(10, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -35.634685320327456F, -13.753252424566682F, -2.1588127735603417F, 0.22551326293700594F, -0.06309865243197618F));
        g.addOrReplaceChild("torreta_ladoi_130", CubeListBuilder.create().texOffs(20, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -35.634685320327456F, -14.183827113778708F, -2.159431746276033F, 0.13309768150826223F, -0.03665817218397761F));
        g.addOrReplaceChild("torreta_ladoi_131", CubeListBuilder.create().texOffs(30, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -35.634685320327456F, -14.394395507076517F, -2.159797010769914F, 0.044012582320067606F, -0.012031758744915015F));
        g.addOrReplaceChild("torreta_ladoi_132", CubeListBuilder.create().texOffs(40, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -35.634685320327456F, -14.394395507076517F, -2.159797010769914F, -0.044012582320067606F, 0.012031758744915015F));
        g.addOrReplaceChild("torreta_ladoi_133", CubeListBuilder.create().texOffs(50, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -35.634685320327456F, -14.183827113778712F, -2.159431746276033F, -0.13309768150826223F, 0.03665817218397761F));
        g.addOrReplaceChild("torreta_ladoi_134", CubeListBuilder.create().texOffs(60, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -35.634685320327456F, -13.753252424566679F, -2.1588127735603417F, -0.22551326293700594F, 0.06309865243197618F));
        g.addOrReplaceChild("torreta_ladoi_135", CubeListBuilder.create().texOffs(70, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -35.634685320327456F, -13.081467876688016F, -2.158246782790705F, -0.32404121878210596F, 0.09305056010223281F));
        g.addOrReplaceChild("torreta_ladoi_136", CubeListBuilder.create().texOffs(80, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -35.634685320327456F, -12.129300243282422F, -2.158498621692187F, -0.4325648064011882F, 0.12926946651335153F));
        g.addOrReplaceChild("torreta_ladoi_137", CubeListBuilder.create().texOffs(90, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -35.634685320327456F, -10.824121380984906F, -2.06115490473932F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_138", CubeListBuilder.create().texOffs(848, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -35.634685320327456F, -9.430212805456538F, -2.1704422095415867F, -0.6781360126157805F, 0.23293867028232346F));
        g.addOrReplaceChild("torreta_ladoi_139", CubeListBuilder.create().texOffs(856, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -35.634685320327456F, -8.103988255310474F, -2.1867420482879956F, -0.7846873388092352F, 0.29384643314088565F));
        g.addOrReplaceChild("torreta_ladoi_140", CubeListBuilder.create().texOffs(864, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -35.634685320327456F, -6.701897324582209F, -2.217294122847617F, -0.8924117308485006F, 0.3727670399277477F));
        g.addOrReplaceChild("torreta_ladoi_141", CubeListBuilder.create().texOffs(872, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -35.634685320327456F, -5.250019551674919F, -2.272241936664782F, -0.9991290541514304F, 0.4795033196979071F));
        g.addOrReplaceChild("torreta_ladoi_142", CubeListBuilder.create().texOffs(880, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -35.634685320327456F, -3.7864378672265695F, -2.3677090703253425F, -1.0998607686473072F, 0.628997744924369F));
        g.addOrReplaceChild("torreta_ladoi_143", CubeListBuilder.create().texOffs(132, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -35.634685320327456F, -2.929122976878752F, -2.257878774009279F, -0.5034964075333667F, 0.3769291487159489F));
        g.addOrReplaceChild("torreta_ladoi_144", CubeListBuilder.create().texOffs(138, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -36.44647947054675F, -2.117328826659457F, -2.598753816470744F, 0.24114862991549302F, -0.3769291487159447F));
        g.addOrReplaceChild("torreta_ladoi_145", CubeListBuilder.create().texOffs(888, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -36.44647947054675F, -2.9746437170072744F, -2.646882197954851F, 0.908687319993922F, -0.6942218599571065F));
        g.addOrReplaceChild("torreta_ladoi_146", CubeListBuilder.create().texOffs(896, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -36.44647947054675F, -4.43822540145562F, -2.5871272189455237F, 0.8136757082360025F, -0.5285634441564314F));
        g.addOrReplaceChild("torreta_ladoi_147", CubeListBuilder.create().texOffs(904, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -36.44647947054675F, -5.890103174362908F, -2.5569704520961185F, 0.7170542132884095F, -0.40650598371549607F));
        g.addOrReplaceChild("torreta_ladoi_148", CubeListBuilder.create().texOffs(912, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -36.44647947054675F, -7.292194105091178F, -2.543881142271684F, 0.6235142236609884F, -0.3157241341686806F));
        g.addOrReplaceChild("torreta_ladoi_149", CubeListBuilder.create().texOffs(920, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -36.44647947054675F, -8.618418655237242F, -2.5398491770032026F, 0.5342425053943934F, -0.24639886855663043F));
        g.addOrReplaceChild("torreta_ladoi_150", CubeListBuilder.create().texOffs(100, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -36.44647947054675F, -10.01232723076561F, -2.445100691176939F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_151", CubeListBuilder.create().texOffs(110, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -36.44647947054675F, -11.317506093063127F, -2.5439383439483017F, 0.33666875908037247F, -0.13244668739919516F));
        g.addOrReplaceChild("torreta_ladoi_152", CubeListBuilder.create().texOffs(120, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -36.44647947054675F, -12.269673726468719F, -2.5472378250725027F, 0.2514883403020788F, -0.09434563473580541F));
        g.addOrReplaceChild("torreta_ladoi_153", CubeListBuilder.create().texOffs(130, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -36.44647947054675F, -12.941458274347385F, -2.5498319804829115F, 0.17473151157429553F, -0.06352615433750113F));
        g.addOrReplaceChild("torreta_ladoi_154", CubeListBuilder.create().texOffs(140, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -36.44647947054675F, -13.372032963559414F, -2.5515703188345538F, 0.10303102981314574F, -0.03674492596973931F));
        g.addOrReplaceChild("torreta_ladoi_155", CubeListBuilder.create().texOffs(150, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -36.44647947054675F, -13.58260135685722F, -2.552436082334609F, 0.034055989131097086F, -0.012034876166478066F));
        g.addOrReplaceChild("torreta_ladoi_156", CubeListBuilder.create().texOffs(160, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -36.44647947054675F, -13.58260135685722F, -2.552436082334609F, -0.034055989131097086F, 0.012034876166478066F));
        g.addOrReplaceChild("torreta_ladoi_157", CubeListBuilder.create().texOffs(170, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -36.44647947054675F, -13.372032963559414F, -2.5515703188345538F, -0.10303102981314574F, 0.03674492596973931F));
        g.addOrReplaceChild("torreta_ladoi_158", CubeListBuilder.create().texOffs(180, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -36.44647947054675F, -12.941458274347385F, -2.5498319804829115F, -0.17473151157429553F, 0.06352615433750113F));
        g.addOrReplaceChild("torreta_ladoi_159", CubeListBuilder.create().texOffs(190, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -36.44647947054675F, -12.269673726468719F, -2.5472378250725027F, -0.2514883403020788F, 0.09434563473580541F));
        g.addOrReplaceChild("torreta_ladoi_160", CubeListBuilder.create().texOffs(200, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -36.44647947054675F, -11.317506093063125F, -2.5439383439483017F, -0.33666875908037247F, 0.13244668739919516F));
        g.addOrReplaceChild("torreta_ladoi_161", CubeListBuilder.create().texOffs(210, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -36.44647947054675F, -10.01232723076561F, -2.445100691176939F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_162", CubeListBuilder.create().texOffs(928, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -36.44647947054675F, -8.618418655237242F, -2.5398491770032026F, -0.5342425053943934F, 0.24639886855663043F));
        g.addOrReplaceChild("torreta_ladoi_163", CubeListBuilder.create().texOffs(936, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -36.44647947054675F, -7.292194105091179F, -2.5438811422716845F, -0.6235142236609883F, 0.31572413416868056F));
        g.addOrReplaceChild("torreta_ladoi_164", CubeListBuilder.create().texOffs(944, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -36.44647947054675F, -5.890103174362913F, -2.556970452096118F, -0.7170542132884088F, 0.40650598371549507F));
        g.addOrReplaceChild("torreta_ladoi_165", CubeListBuilder.create().texOffs(952, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -36.44647947054675F, -4.438225401455624F, -2.5871272189455237F, -0.8136757082360025F, 0.5285634441564321F));
        g.addOrReplaceChild("torreta_ladoi_166", CubeListBuilder.create().texOffs(960, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -36.44647947054675F, -2.9746437170072744F, -2.646882197954851F, -0.908687319993922F, 0.6942218599571065F));
        g.addOrReplaceChild("torreta_ladoi_167", CubeListBuilder.create().texOffs(144, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -36.44647947054675F, -2.117328826659457F, -2.5987538164707455F, -0.24114862991549538F, 0.3769291487159488F));
        g.addOrReplaceChild("torreta_ladoi_168", CubeListBuilder.create().texOffs(150, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -36.88581929876693F, -1.0566686548796358F, -2.947863658461724F, 0.03217456682924971F, -0.16252283561685643F));
        g.addOrReplaceChild("torreta_ladoi_169", CubeListBuilder.create().texOffs(968, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -36.88581929876693F, -1.913983545227453F, -2.9216958215217677F, 0.6801952653702865F, -0.38580917103667633F));
        g.addOrReplaceChild("torreta_ladoi_170", CubeListBuilder.create().texOffs(976, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -36.88581929876693F, -3.377565229675799F, -2.919931134485137F, 0.6073442168413676F, -0.26768124806761245F));
        g.addOrReplaceChild("torreta_ladoi_171", CubeListBuilder.create().texOffs(984, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -36.88581929876693F, -4.829443002583086F, -2.92284177961434F, 0.5385273383226048F, -0.19342140698198523F));
        g.addOrReplaceChild("torreta_ladoi_172", CubeListBuilder.create().texOffs(992, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -36.88581929876693F, -6.231533933311356F, -2.92701445852671F, 0.47281417535162973F, -0.14393282897091594F));
        g.addOrReplaceChild("torreta_ladoi_173", CubeListBuilder.create().texOffs(1000, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -36.88581929876693F, -7.557758483457421F, -2.931222914888397F, 0.4092743848412544F, -0.1089897339038653F));
        g.addOrReplaceChild("torreta_ladoi_174", CubeListBuilder.create().texOffs(220, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -36.88581929876693F, -8.951667058985787F, -2.8975895428459117F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_175", CubeListBuilder.create().texOffs(230, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -36.88581929876693F, -10.256845921283304F, -2.939333107103145F, 0.26317062304347216F, -0.05615919251254702F));
        g.addOrReplaceChild("torreta_ladoi_176", CubeListBuilder.create().texOffs(240, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -36.88581929876693F, -11.209013554688898F, -2.941898454257198F, 0.1978450531091149F, -0.03957674369467329F));
        g.addOrReplaceChild("torreta_ladoi_177", CubeListBuilder.create().texOffs(250, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -36.88581929876693F, -11.880798102567564F, -2.943614700534786F, 0.13804632169691153F, -0.026471359478096767F));
        g.addOrReplaceChild("torreta_ladoi_178", CubeListBuilder.create().texOffs(260, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -36.88581929876693F, -12.311372791779593F, -2.9446741260086937F, 0.08161247516690207F, -0.015251568973517744F));
        g.addOrReplaceChild("torreta_ladoi_179", CubeListBuilder.create().texOffs(270, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -36.88581929876693F, -12.521941185077399F, -2.9451808049999286F, 0.027009920152967524F, -0.004986122308240523F));
        g.addOrReplaceChild("torreta_ladoi_180", CubeListBuilder.create().texOffs(280, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -36.88581929876693F, -12.521941185077399F, -2.9451808049999286F, -0.027009920152967524F, 0.004986122308240523F));
        g.addOrReplaceChild("torreta_ladoi_181", CubeListBuilder.create().texOffs(290, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -36.88581929876693F, -12.311372791779593F, -2.9446741260086937F, -0.08161247516690207F, 0.015251568973517744F));
        g.addOrReplaceChild("torreta_ladoi_182", CubeListBuilder.create().texOffs(300, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -36.88581929876693F, -11.880798102567564F, -2.943614700534786F, -0.13804632169691153F, 0.026471359478096767F));
        g.addOrReplaceChild("torreta_ladoi_183", CubeListBuilder.create().texOffs(310, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -36.88581929876693F, -11.209013554688898F, -2.941898454257198F, -0.1978450531091149F, 0.03957674369467329F));
    }

    private static void piezas20(PartDefinition g) {
        g.addOrReplaceChild("torreta_ladoi_184", CubeListBuilder.create().texOffs(320, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -36.88581929876693F, -10.256845921283304F, -2.939333107103145F, -0.26317062304347216F, 0.05615919251254702F));
        g.addOrReplaceChild("torreta_ladoi_185", CubeListBuilder.create().texOffs(330, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -36.88581929876693F, -8.951667058985787F, -2.8975895428459117F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladoi_186", CubeListBuilder.create().texOffs(1008, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -36.88581929876693F, -7.5577584834574205F, -2.931222914888397F, -0.4092743848412544F, 0.1089897339038653F));
        g.addOrReplaceChild("torreta_ladoi_187", CubeListBuilder.create().texOffs(1016, 250).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -36.88581929876693F, -6.231533933311358F, -2.92701445852671F, -0.47281417535162956F, 0.1439328289709159F));
        g.addOrReplaceChild("torreta_ladoi_188", CubeListBuilder.create().texOffs(0, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -36.88581929876693F, -4.829443002583092F, -2.92284177961434F, -0.5385273383226046F, 0.19342140698198468F));
        g.addOrReplaceChild("torreta_ladoi_189", CubeListBuilder.create().texOffs(8, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -36.88581929876693F, -3.3775652296758025F, -2.919931134485137F, -0.607344216841368F, 0.2676812480676127F));
        g.addOrReplaceChild("torreta_ladoi_190", CubeListBuilder.create().texOffs(16, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -36.88581929876693F, -1.913983545227453F, -2.9216958215217677F, -0.6801952653702865F, 0.38580917103667633F));
        g.addOrReplaceChild("torreta_ladoi_191", CubeListBuilder.create().texOffs(156, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -36.88581929876693F, -1.0566686548796358F, -2.9478636584617246F, -0.032174566829250004F, 0.16252283561685835F));
        g.addOrReplaceChild("torreta_ladod_0", CubeListBuilder.create().texOffs(162, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -27.0F, 3.4826435063320007F, 1.5707963267948966F, -0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_1", CubeListBuilder.create().texOffs(24, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -27.0F, 4.339958396679818F, 1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_2", CubeListBuilder.create().texOffs(32, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -27.0F, 5.803540081128164F, 1.5707963267948966F, -1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_3", CubeListBuilder.create().texOffs(40, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -27.0F, 7.255417854035452F, 1.5707963267948966F, -1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_4", CubeListBuilder.create().texOffs(48, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -27.0F, 8.65750878476372F, 1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_5", CubeListBuilder.create().texOffs(56, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -27.0F, 9.983733334909786F, 1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_6", CubeListBuilder.create().texOffs(340, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -27.0F, 11.377641910438154F, 1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_7", CubeListBuilder.create().texOffs(350, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -27.0F, 12.68282077273567F, 1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_8", CubeListBuilder.create().texOffs(360, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -27.0F, 13.634988406141265F, 1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_9", CubeListBuilder.create().texOffs(370, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -27.0F, 14.306772954019928F, 1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_10", CubeListBuilder.create().texOffs(380, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -27.0F, 14.737347643231958F, 1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_11", CubeListBuilder.create().texOffs(390, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -27.0F, 14.947916036529765F, 1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_12", CubeListBuilder.create().texOffs(400, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -27.0F, 14.947916036529765F, 1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_13", CubeListBuilder.create().texOffs(410, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -27.0F, 14.737347643231958F, 1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_14", CubeListBuilder.create().texOffs(420, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -27.0F, 14.306772954019928F, 1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_15", CubeListBuilder.create().texOffs(430, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -27.0F, 13.634988406141265F, 1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_16", CubeListBuilder.create().texOffs(440, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -27.0F, 12.68282077273567F, 1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_17", CubeListBuilder.create().texOffs(450, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -27.0F, 11.377641910438154F, 1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_18", CubeListBuilder.create().texOffs(64, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -27.0F, 9.983733334909786F, 1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_19", CubeListBuilder.create().texOffs(72, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -27.0F, 8.657508784763722F, 1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_20", CubeListBuilder.create().texOffs(80, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -27.0F, 7.255417854035457F, 1.5707963267948966F, 1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_21", CubeListBuilder.create().texOffs(88, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -27.0F, 5.803540081128168F, 1.5707963267948966F, 1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_22", CubeListBuilder.create().texOffs(96, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -27.0F, 4.339958396679818F, 1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_23", CubeListBuilder.create().texOffs(168, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -27.0F, 3.482643506332001F, 1.5707963267948966F, 0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_24", CubeListBuilder.create().texOffs(174, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -29.0F, 3.4826435063320007F, 1.5707963267948966F, -0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_25", CubeListBuilder.create().texOffs(104, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -29.0F, 4.339958396679818F, 1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_26", CubeListBuilder.create().texOffs(112, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -29.0F, 5.803540081128164F, 1.5707963267948966F, -1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_27", CubeListBuilder.create().texOffs(120, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -29.0F, 7.255417854035452F, 1.5707963267948966F, -1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_28", CubeListBuilder.create().texOffs(128, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -29.0F, 8.65750878476372F, 1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_29", CubeListBuilder.create().texOffs(136, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -29.0F, 9.983733334909786F, 1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_30", CubeListBuilder.create().texOffs(460, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -29.0F, 11.377641910438154F, 1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_31", CubeListBuilder.create().texOffs(470, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -29.0F, 12.68282077273567F, 1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_32", CubeListBuilder.create().texOffs(480, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -29.0F, 13.634988406141265F, 1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_33", CubeListBuilder.create().texOffs(490, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -29.0F, 14.306772954019928F, 1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_34", CubeListBuilder.create().texOffs(500, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -29.0F, 14.737347643231958F, 1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_35", CubeListBuilder.create().texOffs(510, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -29.0F, 14.947916036529765F, 1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_36", CubeListBuilder.create().texOffs(520, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -29.0F, 14.947916036529765F, 1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_37", CubeListBuilder.create().texOffs(530, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -29.0F, 14.737347643231958F, 1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_38", CubeListBuilder.create().texOffs(540, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -29.0F, 14.306772954019928F, 1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_39", CubeListBuilder.create().texOffs(550, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -29.0F, 13.634988406141265F, 1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_40", CubeListBuilder.create().texOffs(560, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -29.0F, 12.68282077273567F, 1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_41", CubeListBuilder.create().texOffs(570, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -29.0F, 11.377641910438154F, 1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_42", CubeListBuilder.create().texOffs(144, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -29.0F, 9.983733334909786F, 1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_43", CubeListBuilder.create().texOffs(152, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -29.0F, 8.657508784763722F, 1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_44", CubeListBuilder.create().texOffs(160, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -29.0F, 7.255417854035457F, 1.5707963267948966F, 1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_45", CubeListBuilder.create().texOffs(168, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -29.0F, 5.803540081128168F, 1.5707963267948966F, 1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_46", CubeListBuilder.create().texOffs(176, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -29.0F, 4.339958396679818F, 1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_47", CubeListBuilder.create().texOffs(180, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -29.0F, 3.482643506332001F, 1.5707963267948966F, 0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_48", CubeListBuilder.create().texOffs(186, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -31.0F, 3.4826435063320007F, 1.5707963267948966F, -0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_49", CubeListBuilder.create().texOffs(184, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -31.0F, 4.339958396679818F, 1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_50", CubeListBuilder.create().texOffs(192, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -31.0F, 5.803540081128164F, 1.5707963267948966F, -1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_51", CubeListBuilder.create().texOffs(200, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -31.0F, 7.255417854035452F, 1.5707963267948966F, -1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_52", CubeListBuilder.create().texOffs(208, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -31.0F, 8.65750878476372F, 1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_53", CubeListBuilder.create().texOffs(216, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -31.0F, 9.983733334909786F, 1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_54", CubeListBuilder.create().texOffs(580, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -31.0F, 11.377641910438154F, 1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_55", CubeListBuilder.create().texOffs(590, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -31.0F, 12.68282077273567F, 1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_56", CubeListBuilder.create().texOffs(600, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -31.0F, 13.634988406141265F, 1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_57", CubeListBuilder.create().texOffs(610, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -31.0F, 14.306772954019928F, 1.5707963267948966F, -0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_58", CubeListBuilder.create().texOffs(620, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -31.0F, 14.737347643231958F, 1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_59", CubeListBuilder.create().texOffs(630, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -31.0F, 14.947916036529765F, 1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_60", CubeListBuilder.create().texOffs(640, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -31.0F, 14.947916036529765F, 1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_61", CubeListBuilder.create().texOffs(650, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -31.0F, 14.737347643231958F, 1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_62", CubeListBuilder.create().texOffs(660, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -31.0F, 14.306772954019928F, 1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_63", CubeListBuilder.create().texOffs(670, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -31.0F, 13.634988406141265F, 1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_64", CubeListBuilder.create().texOffs(680, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -31.0F, 12.68282077273567F, 1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_65", CubeListBuilder.create().texOffs(690, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -31.0F, 11.377641910438154F, 1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_66", CubeListBuilder.create().texOffs(224, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -31.0F, 9.983733334909786F, 1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_67", CubeListBuilder.create().texOffs(232, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -31.0F, 8.657508784763722F, 1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_68", CubeListBuilder.create().texOffs(240, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -31.0F, 7.255417854035457F, 1.5707963267948966F, 1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_69", CubeListBuilder.create().texOffs(248, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -31.0F, 5.803540081128168F, 1.5707963267948966F, 1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_70", CubeListBuilder.create().texOffs(256, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -31.0F, 4.339958396679818F, 1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_71", CubeListBuilder.create().texOffs(192, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -31.0F, 3.482643506332001F, 1.5707963267948966F, 0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_72", CubeListBuilder.create().texOffs(198, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -33.0F, 3.4826435063320007F, 1.5707963267948966F, -0.7085113952518352F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_73", CubeListBuilder.create().texOffs(264, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -33.0F, 4.339958396679818F, 1.5707963267948966F, -1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_74", CubeListBuilder.create().texOffs(272, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -33.0F, 5.803540081128164F, 1.5707963267948966F, -1.1262758723375508F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_75", CubeListBuilder.create().texOffs(280, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -33.0F, 7.255417854035452F, 1.5707963267948966F, -1.010362329413617F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_76", CubeListBuilder.create().texOffs(288, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -33.0F, 8.65750878476372F, 1.5707963267948966F, -0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_77", CubeListBuilder.create().texOffs(296, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -33.0F, 9.983733334909786F, 1.5707963267948966F, -0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_78", CubeListBuilder.create().texOffs(700, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -33.0F, 11.377641910438154F, 1.5707963267948966F, -0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_79", CubeListBuilder.create().texOffs(710, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -33.0F, 12.68282077273567F, 1.5707963267948966F, -0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_80", CubeListBuilder.create().texOffs(720, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -33.0F, 13.634988406141265F, 1.5707963267948966F, -0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_81", CubeListBuilder.create().texOffs(730, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -33.0F, 14.306772954019928F, 1.5707963267948966F, -0.26565904090990494F, 0.0F));
    }

    private static void piezas21(PartDefinition g) {
        g.addOrReplaceChild("torreta_ladod_82", CubeListBuilder.create().texOffs(740, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -33.0F, 14.737347643231958F, 1.5707963267948966F, -0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_83", CubeListBuilder.create().texOffs(750, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -33.0F, 14.947916036529765F, 1.5707963267948966F, -0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_84", CubeListBuilder.create().texOffs(760, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -33.0F, 14.947916036529765F, 1.5707963267948966F, 0.05203694324136662F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_85", CubeListBuilder.create().texOffs(770, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -33.0F, 14.737347643231958F, 1.5707963267948966F, 0.15717717375797396F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_86", CubeListBuilder.create().texOffs(780, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -33.0F, 14.306772954019928F, 1.5707963267948966F, 0.26565904090990494F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_87", CubeListBuilder.create().texOffs(790, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -33.0F, 13.634988406141265F, 1.5707963267948966F, 0.3802428049317318F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_88", CubeListBuilder.create().texOffs(800, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -33.0F, 12.68282077273567F, 1.5707963267948966F, 0.5047401487128393F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_89", CubeListBuilder.create().texOffs(810, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -33.0F, 11.377641910438154F, 1.5707963267948966F, 0.6452303924630274F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_90", CubeListBuilder.create().texOffs(304, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -33.0F, 9.983733334909786F, 1.5707963267948966F, 0.7785852878410321F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_91", CubeListBuilder.create().texOffs(312, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -33.0F, 8.657508784763722F, 1.5707963267948966F, 0.8942929254912351F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_92", CubeListBuilder.create().texOffs(320, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -33.0F, 7.255417854035457F, 1.5707963267948966F, 1.0103623294136161F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_93", CubeListBuilder.create().texOffs(328, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -33.0F, 5.803540081128168F, 1.5707963267948966F, 1.1262758723375514F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_94", CubeListBuilder.create().texOffs(336, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -33.0F, 4.339958396679818F, 1.5707963267948966F, 1.240333406117429F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_95", CubeListBuilder.create().texOffs(204, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -33.0F, 3.482643506332001F, 1.5707963267948966F, 0.708511395251841F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_96", CubeListBuilder.create().texOffs(210, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -34.57402514854763F, 3.3684628050989307F, 1.8250125743264949F, -0.6828977330950954F, -0.16252283561685563F));
        g.addOrReplaceChild("torreta_ladod_97", CubeListBuilder.create().texOffs(344, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -34.57402514854763F, 4.225777695446748F, 1.8940078886793636F, -1.2222952223879582F, -0.274218461605764F));
        g.addOrReplaceChild("torreta_ladod_98", CubeListBuilder.create().texOffs(352, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -34.57402514854763F, 5.689359379895094F, 1.8359021474358057F, -1.110771209834459F, -0.19973945437795396F));
        g.addOrReplaceChild("torreta_ladod_99", CubeListBuilder.create().texOffs(360, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -34.57402514854763F, 7.141237152802382F, 1.8046564746427858F, -0.9963153976068317F, -0.15231653509744F));
        g.addOrReplaceChild("torreta_ladod_100", CubeListBuilder.create().texOffs(368, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -34.57402514854763F, 8.543328083530652F, 1.7872668221271308F, -0.8813405994108005F, -0.11928590581640346F));
        g.addOrReplaceChild("torreta_ladod_101", CubeListBuilder.create().texOffs(376, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -34.57402514854763F, 9.869552633676715F, 1.7774867102570833F, -0.7666989132568279F, -0.0945404819847156F));
        g.addOrReplaceChild("torreta_ladod_102", CubeListBuilder.create().texOffs(820, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -34.57402514854763F, 11.263461209205083F, 1.7284015597582516F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_103", CubeListBuilder.create().texOffs(830, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -34.57402514854763F, 12.5686400715026F, 1.7685726602340672F, -0.49604440927838767F, -0.052924265248671616F));
        g.addOrReplaceChild("torreta_ladod_104", CubeListBuilder.create().texOffs(840, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -34.57402514854763F, 13.520807704908194F, 1.7675268706013907F, -0.3734096587135649F, -0.03827065184366676F));
        g.addOrReplaceChild("torreta_ladod_105", CubeListBuilder.create().texOffs(850, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -34.57402514854763F, 14.19259225278686F, 1.7672005563238273F, -0.26074408856128006F, -0.026042315212402013F));
        g.addOrReplaceChild("torreta_ladod_106", CubeListBuilder.create().texOffs(860, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -34.57402514854763F, 14.623166941998889F, 1.7671377204012728F, -0.15421558868568414F, -0.015164715370441974F));
        g.addOrReplaceChild("torreta_ladod_107", CubeListBuilder.create().texOffs(870, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -34.57402514854763F, 14.833735335296694F, 1.767143573659609F, -0.051047752130763846F, -0.004983004511430807F));
        g.addOrReplaceChild("torreta_ladod_108", CubeListBuilder.create().texOffs(880, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -34.57402514854763F, 14.833735335296694F, 1.767143573659609F, 0.051047752130763846F, 0.004983004511430807F));
        g.addOrReplaceChild("torreta_ladod_109", CubeListBuilder.create().texOffs(890, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -34.57402514854763F, 14.623166941998889F, 1.7671377204012728F, 0.15421558868568414F, 0.015164715370441974F));
        g.addOrReplaceChild("torreta_ladod_110", CubeListBuilder.create().texOffs(900, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -34.57402514854763F, 14.19259225278686F, 1.7672005563238273F, 0.26074408856128006F, 0.026042315212402013F));
        g.addOrReplaceChild("torreta_ladod_111", CubeListBuilder.create().texOffs(910, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -34.57402514854763F, 13.520807704908194F, 1.7675268706013907F, 0.3734096587135649F, 0.03827065184366676F));
        g.addOrReplaceChild("torreta_ladod_112", CubeListBuilder.create().texOffs(920, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -34.57402514854763F, 12.5686400715026F, 1.7685726602340672F, 0.49604440927838767F, 0.052924265248671616F));
        g.addOrReplaceChild("torreta_ladod_113", CubeListBuilder.create().texOffs(930, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -34.57402514854763F, 11.263461209205083F, 1.7284015597582516F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_114", CubeListBuilder.create().texOffs(384, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -34.57402514854763F, 9.869552633676715F, 1.7774867102570833F, 0.7666989132568279F, 0.0945404819847156F));
        g.addOrReplaceChild("torreta_ladod_115", CubeListBuilder.create().texOffs(392, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -34.57402514854763F, 8.543328083530652F, 1.7872668221271308F, 0.8813405994108003F, 0.11928590581640343F));
        g.addOrReplaceChild("torreta_ladod_116", CubeListBuilder.create().texOffs(400, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -34.57402514854763F, 7.141237152802388F, 1.8046564746427853F, 0.9963153976068305F, 0.1523165350974396F));
        g.addOrReplaceChild("torreta_ladod_117", CubeListBuilder.create().texOffs(408, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -34.57402514854763F, 5.689359379895098F, 1.835902147435806F, 1.1107712098344598F, 0.19973945437795393F));
        g.addOrReplaceChild("torreta_ladod_118", CubeListBuilder.create().texOffs(416, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -34.57402514854763F, 4.225777695446748F, 1.8940078886793636F, 1.2222952223879582F, 0.274218461605764F));
        g.addOrReplaceChild("torreta_ladod_119", CubeListBuilder.create().texOffs(216, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -34.57402514854763F, 3.368462805098931F, 1.8250125743264962F, 0.6828977330951009F, 0.16252283561685757F));
        g.addOrReplaceChild("torreta_ladod_120", CubeListBuilder.create().texOffs(222, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -35.634685320327456F, 2.929122976878752F, 2.2578787740092774F, -0.5034964075333622F, -0.37692914871594485F));
        g.addOrReplaceChild("torreta_ladod_121", CubeListBuilder.create().texOffs(424, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -35.634685320327456F, 3.7864378672265695F, 2.3677090703253425F, -1.0998607686473072F, -0.628997744924369F));
        g.addOrReplaceChild("torreta_ladod_122", CubeListBuilder.create().texOffs(432, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -35.634685320327456F, 5.250019551674915F, 2.272241936664782F, -0.9991290541514302F, -0.47950331969790666F));
        g.addOrReplaceChild("torreta_ladod_123", CubeListBuilder.create().texOffs(440, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -35.634685320327456F, 6.7018973245822036F, 2.217294122847617F, -0.8924117308485013F, -0.3727670399277488F));
        g.addOrReplaceChild("torreta_ladod_124", CubeListBuilder.create().texOffs(448, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -35.634685320327456F, 8.103988255310473F, 2.1867420482879956F, -0.7846873388092357F, -0.2938464331408857F));
        g.addOrReplaceChild("torreta_ladod_125", CubeListBuilder.create().texOffs(456, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -35.634685320327456F, 9.430212805456538F, 2.1704422095415867F, -0.6781360126157805F, -0.23293867028232346F));
        g.addOrReplaceChild("torreta_ladod_126", CubeListBuilder.create().texOffs(940, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -35.634685320327456F, 10.824121380984906F, 2.06115490473932F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_127", CubeListBuilder.create().texOffs(950, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -35.634685320327456F, 12.129300243282422F, 2.158498621692187F, -0.4325648064011882F, -0.12926946651335153F));
        g.addOrReplaceChild("torreta_ladod_128", CubeListBuilder.create().texOffs(960, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -35.634685320327456F, 13.081467876688016F, 2.158246782790705F, -0.32404121878210596F, -0.09305056010223281F));
        g.addOrReplaceChild("torreta_ladod_129", CubeListBuilder.create().texOffs(970, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -35.634685320327456F, 13.753252424566682F, 2.1588127735603417F, -0.22551326293700594F, -0.06309865243197618F));
        g.addOrReplaceChild("torreta_ladod_130", CubeListBuilder.create().texOffs(980, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -35.634685320327456F, 14.183827113778708F, 2.159431746276033F, -0.13309768150826223F, -0.03665817218397761F));
        g.addOrReplaceChild("torreta_ladod_131", CubeListBuilder.create().texOffs(990, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -35.634685320327456F, 14.394395507076517F, 2.159797010769914F, -0.044012582320067606F, -0.012031758744915015F));
        g.addOrReplaceChild("torreta_ladod_132", CubeListBuilder.create().texOffs(1000, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -35.634685320327456F, 14.394395507076517F, 2.159797010769914F, 0.044012582320067606F, 0.012031758744915015F));
        g.addOrReplaceChild("torreta_ladod_133", CubeListBuilder.create().texOffs(1010, 247).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -35.634685320327456F, 14.183827113778712F, 2.159431746276033F, 0.13309768150826223F, 0.03665817218397761F));
        g.addOrReplaceChild("torreta_ladod_134", CubeListBuilder.create().texOffs(0, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -35.634685320327456F, 13.753252424566679F, 2.1588127735603417F, 0.22551326293700594F, 0.06309865243197618F));
        g.addOrReplaceChild("torreta_ladod_135", CubeListBuilder.create().texOffs(10, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -35.634685320327456F, 13.081467876688016F, 2.158246782790705F, 0.32404121878210596F, 0.09305056010223281F));
        g.addOrReplaceChild("torreta_ladod_136", CubeListBuilder.create().texOffs(20, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -35.634685320327456F, 12.129300243282422F, 2.158498621692187F, 0.4325648064011882F, 0.12926946651335153F));
        g.addOrReplaceChild("torreta_ladod_137", CubeListBuilder.create().texOffs(30, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -35.634685320327456F, 10.824121380984906F, 2.06115490473932F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_138", CubeListBuilder.create().texOffs(464, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -35.634685320327456F, 9.430212805456538F, 2.1704422095415867F, 0.6781360126157805F, 0.23293867028232346F));
        g.addOrReplaceChild("torreta_ladod_139", CubeListBuilder.create().texOffs(472, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -35.634685320327456F, 8.103988255310474F, 2.1867420482879956F, 0.7846873388092352F, 0.29384643314088565F));
        g.addOrReplaceChild("torreta_ladod_140", CubeListBuilder.create().texOffs(480, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -35.634685320327456F, 6.701897324582209F, 2.217294122847617F, 0.8924117308485006F, 0.3727670399277477F));
        g.addOrReplaceChild("torreta_ladod_141", CubeListBuilder.create().texOffs(488, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -35.634685320327456F, 5.250019551674919F, 2.272241936664782F, 0.9991290541514304F, 0.4795033196979071F));
        g.addOrReplaceChild("torreta_ladod_142", CubeListBuilder.create().texOffs(496, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -35.634685320327456F, 3.7864378672265695F, 2.3677090703253425F, 1.0998607686473072F, 0.628997744924369F));
        g.addOrReplaceChild("torreta_ladod_143", CubeListBuilder.create().texOffs(228, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -35.634685320327456F, 2.929122976878752F, 2.257878774009279F, 0.5034964075333667F, 0.3769291487159489F));
        g.addOrReplaceChild("torreta_ladod_144", CubeListBuilder.create().texOffs(234, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -36.44647947054675F, 2.117328826659457F, 2.598753816470744F, -0.24114862991549302F, -0.3769291487159447F));
        g.addOrReplaceChild("torreta_ladod_145", CubeListBuilder.create().texOffs(504, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -36.44647947054675F, 2.9746437170072744F, 2.646882197954851F, -0.908687319993922F, -0.6942218599571065F));
        g.addOrReplaceChild("torreta_ladod_146", CubeListBuilder.create().texOffs(512, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -36.44647947054675F, 4.43822540145562F, 2.5871272189455237F, -0.8136757082360025F, -0.5285634441564314F));
        g.addOrReplaceChild("torreta_ladod_147", CubeListBuilder.create().texOffs(520, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -36.44647947054675F, 5.890103174362908F, 2.5569704520961185F, -0.7170542132884095F, -0.40650598371549607F));
        g.addOrReplaceChild("torreta_ladod_148", CubeListBuilder.create().texOffs(528, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -36.44647947054675F, 7.292194105091178F, 2.543881142271684F, -0.6235142236609884F, -0.3157241341686806F));
        g.addOrReplaceChild("torreta_ladod_149", CubeListBuilder.create().texOffs(536, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -36.44647947054675F, 8.618418655237242F, 2.5398491770032026F, -0.5342425053943934F, -0.24639886855663043F));
        g.addOrReplaceChild("torreta_ladod_150", CubeListBuilder.create().texOffs(40, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -36.44647947054675F, 10.01232723076561F, 2.445100691176939F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_151", CubeListBuilder.create().texOffs(50, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -36.44647947054675F, 11.317506093063127F, 2.5439383439483017F, -0.33666875908037247F, -0.13244668739919516F));
        g.addOrReplaceChild("torreta_ladod_152", CubeListBuilder.create().texOffs(60, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -36.44647947054675F, 12.269673726468719F, 2.5472378250725027F, -0.2514883403020788F, -0.09434563473580541F));
        g.addOrReplaceChild("torreta_ladod_153", CubeListBuilder.create().texOffs(70, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -36.44647947054675F, 12.941458274347385F, 2.5498319804829115F, -0.17473151157429553F, -0.06352615433750113F));
        g.addOrReplaceChild("torreta_ladod_154", CubeListBuilder.create().texOffs(80, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -36.44647947054675F, 13.372032963559414F, 2.5515703188345538F, -0.10303102981314574F, -0.03674492596973931F));
        g.addOrReplaceChild("torreta_ladod_155", CubeListBuilder.create().texOffs(90, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -36.44647947054675F, 13.58260135685722F, 2.552436082334609F, -0.034055989131097086F, -0.012034876166478066F));
        g.addOrReplaceChild("torreta_ladod_156", CubeListBuilder.create().texOffs(100, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -36.44647947054675F, 13.58260135685722F, 2.552436082334609F, 0.034055989131097086F, 0.012034876166478066F));
        g.addOrReplaceChild("torreta_ladod_157", CubeListBuilder.create().texOffs(110, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -36.44647947054675F, 13.372032963559414F, 2.5515703188345538F, 0.10303102981314574F, 0.03674492596973931F));
        g.addOrReplaceChild("torreta_ladod_158", CubeListBuilder.create().texOffs(120, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -36.44647947054675F, 12.941458274347385F, 2.5498319804829115F, 0.17473151157429553F, 0.06352615433750113F));
        g.addOrReplaceChild("torreta_ladod_159", CubeListBuilder.create().texOffs(130, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -36.44647947054675F, 12.269673726468719F, 2.5472378250725027F, 0.2514883403020788F, 0.09434563473580541F));
        g.addOrReplaceChild("torreta_ladod_160", CubeListBuilder.create().texOffs(140, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -36.44647947054675F, 11.317506093063125F, 2.5439383439483017F, 0.33666875908037247F, 0.13244668739919516F));
        g.addOrReplaceChild("torreta_ladod_161", CubeListBuilder.create().texOffs(150, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -36.44647947054675F, 10.01232723076561F, 2.445100691176939F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_162", CubeListBuilder.create().texOffs(544, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -36.44647947054675F, 8.618418655237242F, 2.5398491770032026F, 0.5342425053943934F, 0.24639886855663043F));
        g.addOrReplaceChild("torreta_ladod_163", CubeListBuilder.create().texOffs(552, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -36.44647947054675F, 7.292194105091179F, 2.5438811422716845F, 0.6235142236609883F, 0.31572413416868056F));
        g.addOrReplaceChild("torreta_ladod_164", CubeListBuilder.create().texOffs(560, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -36.44647947054675F, 5.890103174362913F, 2.556970452096118F, 0.7170542132884088F, 0.40650598371549507F));
        g.addOrReplaceChild("torreta_ladod_165", CubeListBuilder.create().texOffs(568, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -36.44647947054675F, 4.438225401455624F, 2.5871272189455237F, 0.8136757082360025F, 0.5285634441564321F));
        g.addOrReplaceChild("torreta_ladod_166", CubeListBuilder.create().texOffs(576, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -36.44647947054675F, 2.9746437170072744F, 2.646882197954851F, 0.908687319993922F, 0.6942218599571065F));
        g.addOrReplaceChild("torreta_ladod_167", CubeListBuilder.create().texOffs(240, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -36.44647947054675F, 2.117328826659457F, 2.5987538164707455F, 0.24114862991549538F, 0.3769291487159488F));
        g.addOrReplaceChild("torreta_ladod_168", CubeListBuilder.create().texOffs(246, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.65F, -36.88581929876693F, 1.0566686548796358F, 2.947863658461724F, -0.03217456682924971F, -0.16252283561685643F));
        g.addOrReplaceChild("torreta_ladod_169", CubeListBuilder.create().texOffs(584, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-13.25F, -36.88581929876693F, 1.913983545227453F, 2.9216958215217677F, -0.6801952653702865F, -0.38580917103667633F));
        g.addOrReplaceChild("torreta_ladod_170", CubeListBuilder.create().texOffs(592, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -36.88581929876693F, 3.377565229675799F, 2.919931134485137F, -0.6073442168413676F, -0.26768124806761245F));
        g.addOrReplaceChild("torreta_ladod_171", CubeListBuilder.create().texOffs(600, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -36.88581929876693F, 4.829443002583086F, 2.92284177961434F, -0.5385273383226048F, -0.19342140698198523F));
    }

    private static void piezas22(PartDefinition g) {
        g.addOrReplaceChild("torreta_ladod_172", CubeListBuilder.create().texOffs(608, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-10.850000000000001F, -36.88581929876693F, 6.231533933311356F, 2.92701445852671F, -0.47281417535162973F, -0.14393282897091594F));
        g.addOrReplaceChild("torreta_ladod_173", CubeListBuilder.create().texOffs(616, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-9.65F, -36.88581929876693F, 7.557758483457421F, 2.931222914888397F, -0.4092743848412544F, -0.1089897339038653F));
        g.addOrReplaceChild("torreta_ladod_174", CubeListBuilder.create().texOffs(160, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-8.0F, -36.88581929876693F, 8.951667058985787F, 2.8975895428459117F, -0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_175", CubeListBuilder.create().texOffs(170, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-6.0F, -36.88581929876693F, 10.256845921283304F, 2.939333107103145F, -0.26317062304347216F, -0.05615919251254702F));
        g.addOrReplaceChild("torreta_ladod_176", CubeListBuilder.create().texOffs(180, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-4.0F, -36.88581929876693F, 11.209013554688898F, 2.941898454257198F, -0.1978450531091149F, -0.03957674369467329F));
        g.addOrReplaceChild("torreta_ladod_177", CubeListBuilder.create().texOffs(190, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-2.0F, -36.88581929876693F, 11.880798102567564F, 2.943614700534786F, -0.13804632169691153F, -0.026471359478096767F));
        g.addOrReplaceChild("torreta_ladod_178", CubeListBuilder.create().texOffs(200, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(0.0F, -36.88581929876693F, 12.311372791779593F, 2.9446741260086937F, -0.08161247516690207F, -0.015251568973517744F));
        g.addOrReplaceChild("torreta_ladod_179", CubeListBuilder.create().texOffs(210, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(2.0F, -36.88581929876693F, 12.521941185077399F, 2.9451808049999286F, -0.027009920152967524F, -0.004986122308240523F));
        g.addOrReplaceChild("torreta_ladod_180", CubeListBuilder.create().texOffs(220, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(4.0F, -36.88581929876693F, 12.521941185077399F, 2.9451808049999286F, 0.027009920152967524F, 0.004986122308240523F));
        g.addOrReplaceChild("torreta_ladod_181", CubeListBuilder.create().texOffs(230, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(6.0F, -36.88581929876693F, 12.311372791779593F, 2.9446741260086937F, 0.08161247516690207F, 0.015251568973517744F));
        g.addOrReplaceChild("torreta_ladod_182", CubeListBuilder.create().texOffs(240, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(8.0F, -36.88581929876693F, 11.880798102567564F, 2.943614700534786F, 0.13804632169691153F, 0.026471359478096767F));
        g.addOrReplaceChild("torreta_ladod_183", CubeListBuilder.create().texOffs(250, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(10.0F, -36.88581929876693F, 11.209013554688898F, 2.941898454257198F, 0.1978450531091149F, 0.03957674369467329F));
        g.addOrReplaceChild("torreta_ladod_184", CubeListBuilder.create().texOffs(260, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(12.0F, -36.88581929876693F, 10.256845921283304F, 2.939333107103145F, 0.26317062304347216F, 0.05615919251254702F));
        g.addOrReplaceChild("torreta_ladod_185", CubeListBuilder.create().texOffs(270, 250).addBox(-1.5F, -1.0F, -1.0F, 3.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(14.0F, -36.88581929876693F, 8.951667058985787F, 2.8975895428459117F, 0.6452303924630275F, 0.0F));
        g.addOrReplaceChild("torreta_ladod_186", CubeListBuilder.create().texOffs(624, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(15.649999999999999F, -36.88581929876693F, 7.5577584834574205F, 2.931222914888397F, 0.4092743848412544F, 0.1089897339038653F));
        g.addOrReplaceChild("torreta_ladod_187", CubeListBuilder.create().texOffs(632, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(16.85F, -36.88581929876693F, 6.231533933311358F, 2.92701445852671F, 0.47281417535162956F, 0.1439328289709159F));
        g.addOrReplaceChild("torreta_ladod_188", CubeListBuilder.create().texOffs(640, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -36.88581929876693F, 4.829443002583092F, 2.92284177961434F, 0.5385273383226046F, 0.19342140698198468F));
        g.addOrReplaceChild("torreta_ladod_189", CubeListBuilder.create().texOffs(648, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -36.88581929876693F, 3.3775652296758025F, 2.919931134485137F, 0.607344216841368F, 0.2676812480676127F));
        g.addOrReplaceChild("torreta_ladod_190", CubeListBuilder.create().texOffs(656, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.25F, -36.88581929876693F, 1.913983545227453F, 2.9216958215217677F, 0.6801952653702865F, 0.38580917103667633F));
        g.addOrReplaceChild("torreta_ladod_191", CubeListBuilder.create().texOffs(252, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(19.65F, -36.88581929876693F, 1.0566686548796358F, 2.9478636584617246F, 0.032174566829250004F, 0.16252283561685835F));
        g.addOrReplaceChild("torreta_arriba0_0", CubeListBuilder.create().texOffs(816, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, -0.4022029219433341F, 3.141592653589793F, 0.3100697635999632F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_1", CubeListBuilder.create().texOffs(240, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, -1.1166319972331817F, -3.141592653589793F, 1.1802868355520546F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_2", CubeListBuilder.create().texOffs(664, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, -2.3362834009401365F, 3.141592653589793F, 0.525768929423935F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_3", CubeListBuilder.create().texOffs(672, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, -3.546181545029543F, 3.141592653589793F, 0.4626682052002364F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_4", CubeListBuilder.create().texOffs(636, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, -4.7145906539697675F, 3.141592653589793F, 0.4019995301782599F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_5", CubeListBuilder.create().texOffs(646, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, -5.819777779091488F, 3.141592653589793F, 0.3440226531458383F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_6", CubeListBuilder.create().texOffs(256, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, -6.9813682586984624F, 3.141592653589793F, 0.28010947828323F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_7", CubeListBuilder.create().texOffs(270, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, -8.06901731061306F, 3.141592653589793F, 0.21573212828874144F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_8", CubeListBuilder.create().texOffs(284, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, -8.862490338451053F, 3.141592653589793F, 0.16076062662315743F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_9", CubeListBuilder.create().texOffs(298, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, -9.422310795016607F, 3.141592653589793F, 0.11148588586348276F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_10", CubeListBuilder.create().texOffs(312, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, -9.781123036026631F, 3.141592653589793F, 0.06565520657082505F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_11", CubeListBuilder.create().texOffs(326, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, -9.956596697108136F, 3.141592653589793F, 0.021688039300371963F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_12", CubeListBuilder.create().texOffs(340, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, -9.956596697108138F, -3.141592653589793F, -0.021688039300371963F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_13", CubeListBuilder.create().texOffs(354, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, -9.781123036026631F, -3.141592653589793F, -0.06565520657082505F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_14", CubeListBuilder.create().texOffs(368, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, -9.422310795016607F, -3.141592653589793F, -0.11148588586348276F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_15", CubeListBuilder.create().texOffs(382, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, -8.862490338451053F, -3.141592653589793F, -0.16076062662315743F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_16", CubeListBuilder.create().texOffs(396, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, -8.06901731061306F, -3.141592653589793F, -0.21573212828874144F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_17", CubeListBuilder.create().texOffs(410, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, -6.981368258698462F, -3.141592653589793F, -0.28010947828323F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_18", CubeListBuilder.create().texOffs(656, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, -5.819777779091489F, -3.141592653589793F, -0.3440226531458383F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_19", CubeListBuilder.create().texOffs(666, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, -4.714590653969769F, -3.141592653589793F, -0.40199953017825985F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_20", CubeListBuilder.create().texOffs(680, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, -3.546181545029548F, -3.141592653589793F, -0.46266820520023566F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_21", CubeListBuilder.create().texOffs(688, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, -2.33628340094014F, -3.141592653589793F, -0.5257689294239354F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_22", CubeListBuilder.create().texOffs(246, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, -1.1166319972331817F, -3.141592653589793F, -1.1802868355520546F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_23", CubeListBuilder.create().texOffs(820, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, -0.4022029219433341F, -3.141592653589793F, -0.310069763599966F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_24", CubeListBuilder.create().texOffs(824, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, -0.24132175316600046F, 3.141592653589793F, 0.2024038072576524F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_25", CubeListBuilder.create().texOffs(252, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, -0.669979198339909F, 3.141592653589793F, 0.4847354486182298F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_26", CubeListBuilder.create().texOffs(696, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, -1.4017700405640818F, 3.141592653589793F, 0.4048266624432964F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_27", CubeListBuilder.create().texOffs(704, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, -2.127708927017726F, 3.141592653589793F, 0.3363761555098401F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_28", CubeListBuilder.create().texOffs(676, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, -2.8287543923818608F, 3.141592653589793F, 0.2784887017498119F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_29", CubeListBuilder.create().texOffs(686, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, -3.491866667454894F, 3.141592653589793F, 0.22910973342865612F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_30", CubeListBuilder.create().texOffs(424, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, -4.188820955219077F, 3.141592653589793F, 0.17997806135894623F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_31", CubeListBuilder.create().texOffs(438, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, -4.841410386367835F, 3.141592653589793F, 0.1347577857694709F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_32", CubeListBuilder.create().texOffs(452, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, -5.317494203070632F, 3.141592653589793F, 0.09862428942245241F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_33", CubeListBuilder.create().texOffs(466, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, -5.653386477009965F, 3.141592653589793F, 0.06760750425699437F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_34", CubeListBuilder.create().texOffs(480, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, -5.86867382161598F, 3.141592653589793F, 0.03953848719601994F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_35", CubeListBuilder.create().texOffs(494, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, -5.973958018264883F, 3.141592653589793F, 0.013018048518655675F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_36", CubeListBuilder.create().texOffs(508, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, -5.973958018264883F, -3.141592653589793F, -0.013018048518655675F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_37", CubeListBuilder.create().texOffs(522, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, -5.86867382161598F, -3.141592653589793F, -0.03953848719601994F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_38", CubeListBuilder.create().texOffs(536, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, -5.653386477009965F, -3.141592653589793F, -0.06760750425699437F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_39", CubeListBuilder.create().texOffs(550, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, -5.317494203070632F, -3.141592653589793F, -0.09862428942245241F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_40", CubeListBuilder.create().texOffs(564, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, -4.841410386367835F, -3.141592653589793F, -0.1347577857694709F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_41", CubeListBuilder.create().texOffs(578, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, -4.188820955219077F, -3.141592653589793F, -0.17997806135894623F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_42", CubeListBuilder.create().texOffs(696, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, -3.4918666674548935F, -3.141592653589793F, -0.22910973342865612F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_43", CubeListBuilder.create().texOffs(706, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, -2.8287543923818617F, -3.141592653589793F, -0.2784887017498119F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_44", CubeListBuilder.create().texOffs(712, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, -2.1277089270177285F, -3.141592653589793F, -0.33637615550983957F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_45", CubeListBuilder.create().texOffs(720, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, -1.401770040564084F, -3.141592653589793F, -0.4048266624432964F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_46", CubeListBuilder.create().texOffs(258, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, -0.669979198339909F, -3.141592653589793F, -0.4847354486182298F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_47", CubeListBuilder.create().texOffs(828, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, -0.2413217531660005F, -3.141592653589793F, -0.2024038072576547F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_48", CubeListBuilder.create().texOffs(832, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, -0.08044058438866683F, 3.141592653589793F, 0.0709322546045808F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_49", CubeListBuilder.create().texOffs(836, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, -0.22332639944663635F, 3.141592653589793F, 0.226131387547358F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_50", CubeListBuilder.create().texOffs(258, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, -0.46725668018802735F, 3.141592653589793F, 0.16829675399894287F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_51", CubeListBuilder.create().texOffs(728, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, -0.7092363090059087F, 3.141592653589793F, 0.1297943922103165F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_52", CubeListBuilder.create().texOffs(716, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, -0.9429181307939537F, 3.141592653589793F, 0.10233773027253709F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_53", CubeListBuilder.create().texOffs(726, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, -1.163955555818298F, 3.141592653589793F, 0.08147660732059007F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_54", CubeListBuilder.create().texOffs(592, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, -1.3962736517396925F, 3.141592653589793F, 0.062399476109604606F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_55", CubeListBuilder.create().texOffs(606, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, -1.613803462122612F, 3.141592653589793F, 0.045909987853499166F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_56", CubeListBuilder.create().texOffs(620, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, -1.772498067690211F, 3.141592653589793F, 0.03325871856882619F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_57", CubeListBuilder.create().texOffs(634, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, -1.8844621590033217F, 3.141592653589793F, 0.022658664463092667F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_58", CubeListBuilder.create().texOffs(648, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, -1.9562246072053266F, 3.141592653589793F, 0.01320396557383507F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_59", CubeListBuilder.create().texOffs(662, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, -1.9913193394216275F, 3.141592653589793F, 0.0043402212738897555F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_60", CubeListBuilder.create().texOffs(676, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, -1.9913193394216275F, -3.141592653589793F, -0.0043402212738897555F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_61", CubeListBuilder.create().texOffs(690, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, -1.9562246072053266F, -3.141592653589793F, -0.01320396557383507F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_62", CubeListBuilder.create().texOffs(704, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, -1.8844621590033217F, -3.141592653589793F, -0.022658664463092667F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_63", CubeListBuilder.create().texOffs(718, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, -1.772498067690211F, -3.141592653589793F, -0.03325871856882619F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_64", CubeListBuilder.create().texOffs(732, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, -1.613803462122612F, -3.141592653589793F, -0.045909987853499166F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_65", CubeListBuilder.create().texOffs(746, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, -1.3962736517396925F, -3.141592653589793F, -0.062399476109604606F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_66", CubeListBuilder.create().texOffs(736, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, -1.163955555818298F, -3.141592653589793F, -0.08147660732059007F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_67", CubeListBuilder.create().texOffs(746, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, -0.9429181307939539F, -3.141592653589793F, -0.10233773027253709F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_68", CubeListBuilder.create().texOffs(736, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, -0.7092363090059096F, -3.141592653589793F, -0.12979439221031625F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_69", CubeListBuilder.create().texOffs(264, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, -0.467256680188028F, -3.141592653589793F, -0.16829675399894287F, 0.0F));
    }

    private static void piezas23(PartDefinition g) {
        g.addOrReplaceChild("torreta_arriba0_70", CubeListBuilder.create().texOffs(840, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, -0.22332639944663635F, -3.141592653589793F, -0.226131387547358F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_71", CubeListBuilder.create().texOffs(844, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, -0.08044058438866683F, -3.141592653589793F, -0.07093225460458151F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_72", CubeListBuilder.create().texOffs(848, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, 0.08044058438866682F, -3.141592653589793F, -0.0709322546045808F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_73", CubeListBuilder.create().texOffs(852, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, 0.22332639944663635F, -3.141592653589793F, -0.226131387547358F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_74", CubeListBuilder.create().texOffs(270, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, 0.46725668018802713F, -3.141592653589793F, -0.1682967539989426F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_75", CubeListBuilder.create().texOffs(744, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, 0.7092363090059084F, -3.141592653589793F, -0.12979439221031658F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_76", CubeListBuilder.create().texOffs(756, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, 0.9429181307939531F, -3.141592653589793F, -0.10233773027253677F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_77", CubeListBuilder.create().texOffs(766, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, 1.1639555558182972F, -3.141592653589793F, -0.08147660732059007F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_78", CubeListBuilder.create().texOffs(760, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, 1.3962736517396919F, -3.141592653589793F, -0.062399476109604446F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_79", CubeListBuilder.create().texOffs(774, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, 1.6138034621226112F, -3.141592653589793F, -0.045909987853499166F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_80", CubeListBuilder.create().texOffs(788, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, 1.77249806769021F, -3.141592653589793F, -0.03325871856882619F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_81", CubeListBuilder.create().texOffs(802, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, 1.8844621590033208F, -3.141592653589793F, -0.022658664463092667F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_82", CubeListBuilder.create().texOffs(816, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, 1.9562246072053258F, -3.141592653589793F, -0.01320396557383507F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_83", CubeListBuilder.create().texOffs(830, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, 1.991319339421627F, -3.141592653589793F, -0.0043402212738899125F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_84", CubeListBuilder.create().texOffs(844, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, 1.991319339421627F, 3.141592653589793F, 0.0043402212738899125F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_85", CubeListBuilder.create().texOffs(858, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, 1.9562246072053258F, 3.141592653589793F, 0.01320396557383507F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_86", CubeListBuilder.create().texOffs(872, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, 1.8844621590033208F, 3.141592653589793F, 0.022658664463092667F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_87", CubeListBuilder.create().texOffs(886, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, 1.77249806769021F, 3.141592653589793F, 0.03325871856882619F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_88", CubeListBuilder.create().texOffs(900, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, 1.6138034621226112F, 3.141592653589793F, 0.045909987853499166F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_89", CubeListBuilder.create().texOffs(914, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, 1.3962736517396919F, 3.141592653589793F, 0.062399476109604446F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_90", CubeListBuilder.create().texOffs(776, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, 1.1639555558182972F, 3.141592653589793F, 0.08147660732059007F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_91", CubeListBuilder.create().texOffs(786, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, 0.9429181307939534F, 3.141592653589793F, 0.10233773027253686F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_92", CubeListBuilder.create().texOffs(752, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, 0.7092363090059095F, 3.141592653589793F, 0.1297943922103161F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_93", CubeListBuilder.create().texOffs(276, 256).addBox(-0.5F, -1.0F, -1.0F, 1.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, 0.467256680188028F, 3.141592653589793F, 0.16829675399894287F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_94", CubeListBuilder.create().texOffs(856, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, 0.22332639944663635F, 3.141592653589793F, 0.226131387547358F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_95", CubeListBuilder.create().texOffs(860, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, 0.08044058438866682F, 3.141592653589793F, 0.07093225460458151F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_96", CubeListBuilder.create().texOffs(864, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, 0.24132175316600046F, -3.141592653589793F, -0.20240380725765253F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_97", CubeListBuilder.create().texOffs(264, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, 0.6699791983399089F, -3.141592653589793F, -0.4847354486182298F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_98", CubeListBuilder.create().texOffs(760, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, 1.4017700405640814F, -3.141592653589793F, -0.4048266624432962F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_99", CubeListBuilder.create().texOffs(768, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, 2.127708927017725F, -3.141592653589793F, -0.3363761555098399F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_100", CubeListBuilder.create().texOffs(796, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, 2.8287543923818594F, -3.141592653589793F, -0.2784887017498119F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_101", CubeListBuilder.create().texOffs(806, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, 3.491866667454892F, -3.141592653589793F, -0.22910973342865612F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_102", CubeListBuilder.create().texOffs(928, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, 4.188820955219076F, -3.141592653589793F, -0.17997806135894623F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_103", CubeListBuilder.create().texOffs(942, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, 4.8414103863678335F, -3.141592653589793F, -0.13475778576947076F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_104", CubeListBuilder.create().texOffs(956, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, 5.3174942030706305F, -3.141592653589793F, -0.09862428942245273F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_105", CubeListBuilder.create().texOffs(970, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, 5.653386477009963F, -3.141592653589793F, -0.06760750425699437F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_106", CubeListBuilder.create().texOffs(984, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, 5.868673821615978F, -3.141592653589793F, -0.03953848719601994F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_107", CubeListBuilder.create().texOffs(998, 213).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, 5.973958018264882F, -3.141592653589793F, -0.013018048518655989F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_108", CubeListBuilder.create().texOffs(0, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, 5.973958018264882F, 3.141592653589793F, 0.013018048518655989F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_109", CubeListBuilder.create().texOffs(14, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, 5.868673821615978F, 3.141592653589793F, 0.03953848719601994F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_110", CubeListBuilder.create().texOffs(28, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, 5.653386477009963F, 3.141592653589793F, 0.06760750425699437F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_111", CubeListBuilder.create().texOffs(42, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, 5.3174942030706305F, 3.141592653589793F, 0.09862428942245273F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_112", CubeListBuilder.create().texOffs(56, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, 4.8414103863678335F, 3.141592653589793F, 0.13475778576947076F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_113", CubeListBuilder.create().texOffs(70, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, 4.188820955219076F, 3.141592653589793F, 0.17997806135894623F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_114", CubeListBuilder.create().texOffs(816, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, 3.491866667454892F, 3.141592653589793F, 0.22910973342865612F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_115", CubeListBuilder.create().texOffs(826, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, 2.8287543923818608F, 3.141592653589793F, 0.2784887017498117F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_116", CubeListBuilder.create().texOffs(776, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, 2.1277089270177285F, 3.141592653589793F, 0.3363761555098396F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_117", CubeListBuilder.create().texOffs(784, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, 1.4017700405640836F, 3.141592653589793F, 0.4048266624432964F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_118", CubeListBuilder.create().texOffs(270, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, 0.6699791983399089F, 3.141592653589793F, 0.4847354486182298F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_119", CubeListBuilder.create().texOffs(868, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, 0.24132175316600044F, 3.141592653589793F, 0.2024038072576546F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_120", CubeListBuilder.create().texOffs(872, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.65F, -37.0F, 0.40220292194333407F, -3.141592653589793F, -0.31006976359996324F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_121", CubeListBuilder.create().texOffs(276, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(-13.25F, -37.0F, 1.1166319972331817F, -3.141592653589793F, -1.1802868355520546F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_122", CubeListBuilder.create().texOffs(792, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-12.649999999999999F, -37.0F, 2.336283400940136F, -3.141592653589793F, -0.525768929423935F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_123", CubeListBuilder.create().texOffs(800, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-11.85F, -37.0F, 3.546181545029542F, -3.141592653589793F, -0.4626682052002364F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_124", CubeListBuilder.create().texOffs(836, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-10.850000000000001F, -37.0F, 4.714590653969767F, -3.141592653589793F, -0.40199953017826007F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_125", CubeListBuilder.create().texOffs(846, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(-9.65F, -37.0F, 5.819777779091488F, -3.141592653589793F, -0.3440226531458382F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_126", CubeListBuilder.create().texOffs(84, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-8.0F, -37.0F, 6.981368258698462F, -3.141592653589793F, -0.28010947828323F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_127", CubeListBuilder.create().texOffs(98, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-6.0F, -37.0F, 8.069017310613058F, -3.141592653589793F, -0.21573212828874122F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_128", CubeListBuilder.create().texOffs(112, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-4.0F, -37.0F, 8.862490338451053F, -3.141592653589793F, -0.16076062662315765F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_129", CubeListBuilder.create().texOffs(126, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(-2.0F, -37.0F, 9.422310795016607F, -3.141592653589793F, -0.11148588586348276F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_130", CubeListBuilder.create().texOffs(140, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(0.0F, -37.0F, 9.781123036026631F, -3.141592653589793F, -0.06565520657082505F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_131", CubeListBuilder.create().texOffs(154, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(2.0F, -37.0F, 9.956596697108136F, -3.141592653589793F, -0.021688039300371963F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_132", CubeListBuilder.create().texOffs(168, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(4.0F, -37.0F, 9.956596697108138F, 3.141592653589793F, 0.021688039300371963F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_133", CubeListBuilder.create().texOffs(182, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(6.0F, -37.0F, 9.781123036026631F, 3.141592653589793F, 0.06565520657082505F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_134", CubeListBuilder.create().texOffs(196, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(8.0F, -37.0F, 9.422310795016607F, 3.141592653589793F, 0.11148588586348276F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_135", CubeListBuilder.create().texOffs(210, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(10.0F, -37.0F, 8.862490338451053F, 3.141592653589793F, 0.16076062662315765F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_136", CubeListBuilder.create().texOffs(224, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(12.0F, -37.0F, 8.069017310613058F, 3.141592653589793F, 0.21573212828874122F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_137", CubeListBuilder.create().texOffs(238, 218).addBox(-1.5F, -1.0F, -2.0F, 3.0F, 1.0F, 4.0F), PartPose.offsetAndRotation(14.0F, -37.0F, 6.981368258698462F, 3.141592653589793F, 0.28010947828323F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_138", CubeListBuilder.create().texOffs(856, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(15.649999999999999F, -37.0F, 5.819777779091488F, 3.141592653589793F, 0.3440226531458382F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_139", CubeListBuilder.create().texOffs(866, 223).addBox(-1.0F, -1.0F, -1.5F, 2.0F, 1.0F, 3.0F), PartPose.offsetAndRotation(16.85F, -37.0F, 4.714590653969768F, 3.141592653589793F, 0.40199953017825985F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_140", CubeListBuilder.create().texOffs(808, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(17.849999999999998F, -37.0F, 3.5461815450295475F, 3.141592653589793F, 0.46266820520023566F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_141", CubeListBuilder.create().texOffs(816, 253).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(18.65F, -37.0F, 2.3362834009401396F, 3.141592653589793F, 0.5257689294239353F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_142", CubeListBuilder.create().texOffs(282, 265).addBox(-1.0F, -1.0F, -0.5F, 2.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.25F, -37.0F, 1.1166319972331817F, -3.141592653589793F, 1.1802868355520546F, 0.0F));
        g.addOrReplaceChild("torreta_arriba0_143", CubeListBuilder.create().texOffs(876, 265).addBox(-0.5F, -1.0F, -0.5F, 1.0F, 1.0F, 1.0F), PartPose.offsetAndRotation(19.65F, -37.0F, 0.40220292194333407F, 3.141592653589793F, 0.31006976359996596F, 0.0F));
        g.addOrReplaceChild("torreta_trompa", CubeListBuilder.create().texOffs(356, 0).addBox(0.0F, -26.0F, 0.0F, 1.0F, 26.0F, 60.0F), PartPose.offset(-14.0F, -25.0F, -15.0F));
        g.addOrReplaceChild("torreta_cola", CubeListBuilder.create().texOffs(478, 0).addBox(0.0F, -26.0F, 0.0F, 1.0F, 26.0F, 60.0F), PartPose.offset(19.0F, -25.0F, -15.0F));
        g.addOrReplaceChild("torreta_brocal", CubeListBuilder.create().texOffs(500, 109).addBox(1.0F, -38.0F, -9.0F, 1.0F, 1.0F, 18.0F).texOffs(538, 109).addBox(15.0F, -38.0F, -9.0F, 1.0F, 1.0F, 18.0F).texOffs(346, 256).addBox(2.0F, -38.0F, -10.0F, 13.0F, 1.0F, 1.0F).texOffs(374, 256).addBox(2.0F, -38.0F, 9.0F, 13.0F, 1.0F, 1.0F), PartPose.ZERO);
        g.addOrReplaceChild("torreta_tapa_i", CubeListBuilder.create().texOffs(142, 109).addBox(-16.0F, 0.0F, -16.0F, 32.0F, 1.0F, 32.0F), PartPose.offsetAndRotation(8.5F, -41.5F, -10.6F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("torreta_tapa_d", CubeListBuilder.create().texOffs(270, 109).addBox(-16.0F, 0.0F, -16.0F, 32.0F, 1.0F, 32.0F), PartPose.offsetAndRotation(8.5F, -41.5F, 10.6F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("torreta_mantelete", CubeListBuilder.create().texOffs(464, 109).addBox(-19.0F, -35.0F, -6.0F, 6.0F, 8.0F, 12.0F), PartPose.ZERO);
        g.addOrReplaceChild("torreta_canon_0", CubeListBuilder.create().texOffs(128, 228).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -31.325000000000003F, 1.212916512459885F, 1.3089969389957468F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_1", CubeListBuilder.create().texOffs(304, 228).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -31.887916512459885F, 0.8879165124598853F, 0.7853981633974508F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_2", CubeListBuilder.create().texOffs(480, 228).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -32.212916512459884F, 0.32500000000000007F, 0.26179938779914397F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_3", CubeListBuilder.create().texOffs(656, 228).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -32.212916512459884F, -0.3249999999999998F, -0.261799387799144F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_4", CubeListBuilder.create().texOffs(832, 228).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -31.88791651245989F, -0.8879165124598849F, -0.785398163397447F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_5", CubeListBuilder.create().texOffs(0, 232).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -31.325000000000003F, -1.212916512459885F, -1.3089969389957476F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_6", CubeListBuilder.create().texOffs(176, 232).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -30.674999999999997F, -1.2129165124598855F, -1.832595714594046F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_7", CubeListBuilder.create().texOffs(352, 232).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -30.112083487540115F, -0.8879165124598856F, -2.3561944901923426F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_8", CubeListBuilder.create().texOffs(528, 232).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -29.787083487540116F, -0.3250000000000004F, -2.8797932657906444F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_9", CubeListBuilder.create().texOffs(704, 232).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -29.787083487540116F, 0.32499999999999946F, 2.879793265790644F, 0.0F, -3.141592653589793F));
    }

    private static void piezas24(PartDefinition g) {
        g.addOrReplaceChild("torreta_canon_10", CubeListBuilder.create().texOffs(0, 235).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -30.11208348754011F, 0.8879165124598845F, 2.3561944901923466F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_11", CubeListBuilder.create().texOffs(176, 235).addBox(-43.0F, -1.0F, -1.0F, 86.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-40.5F, -30.674999999999997F, 1.212916512459885F, 1.832595714594046F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_canon_ta", CubeListBuilder.create().texOffs(336, 146).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-18.95F, -31.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("torreta_canon_tb", CubeListBuilder.create().texOffs(380, 146).addBox(-5.5F, 0.0F, -5.5F, 11.0F, 1.0F, 11.0F), PartPose.offsetAndRotation(-62.05F, -31.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("torreta_evacuador_0", CubeListBuilder.create().texOffs(992, 235).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -31.475F, 1.7727241335952169F, 1.3089969389957472F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_1", CubeListBuilder.create().texOffs(0, 238).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -32.29772413359522F, 1.2977241335952168F, 0.7853981633974475F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_2", CubeListBuilder.create().texOffs(28, 238).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -32.77272413359522F, 0.47500000000000014F, 0.26179938779914985F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_3", CubeListBuilder.create().texOffs(56, 238).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -32.77272413359522F, -0.4749999999999997F, -0.26179938779914996F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_4", CubeListBuilder.create().texOffs(84, 238).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -32.29772413359522F, -1.2977241335952163F, -0.7853981633974474F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_5", CubeListBuilder.create().texOffs(112, 238).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -31.475F, -1.7727241335952164F, -1.3089969389957468F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_6", CubeListBuilder.create().texOffs(140, 238).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -30.525F, -1.772724133595217F, -1.8325957145940455F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_7", CubeListBuilder.create().texOffs(168, 238).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -29.702275866404783F, -1.2977241335952174F, -2.3561944901923457F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_8", CubeListBuilder.create().texOffs(196, 238).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -29.22727586640478F, -0.47500000000000064F, -2.8797932657906435F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_9", CubeListBuilder.create().texOffs(224, 238).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -29.22727586640478F, 0.4749999999999992F, 2.8797932657906467F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_10", CubeListBuilder.create().texOffs(252, 238).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -29.702275866404783F, 1.2977241335952159F, 2.356194490192344F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_11", CubeListBuilder.create().texOffs(280, 238).addBox(-6.0F, -1.0F, -1.0F, 12.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-41.0F, -30.525F, 1.7727241335952164F, 1.8325957145940466F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_evacuador_ta", CubeListBuilder.create().texOffs(576, 109).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-37.95F, -31.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("torreta_evacuador_tb", CubeListBuilder.create().texOffs(640, 109).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-44.05F, -31.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("torreta_boca_0", CubeListBuilder.create().texOffs(308, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -31.475F, 1.7727241335952169F, 1.3089969389957472F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_1", CubeListBuilder.create().texOffs(328, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -32.29772413359522F, 1.2977241335952168F, 0.7853981633974475F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_2", CubeListBuilder.create().texOffs(348, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -32.77272413359522F, 0.47500000000000014F, 0.26179938779914985F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_3", CubeListBuilder.create().texOffs(368, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -32.77272413359522F, -0.4749999999999997F, -0.26179938779914996F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_4", CubeListBuilder.create().texOffs(388, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -32.29772413359522F, -1.2977241335952163F, -0.7853981633974474F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_5", CubeListBuilder.create().texOffs(408, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -31.475F, -1.7727241335952164F, -1.3089969389957468F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_6", CubeListBuilder.create().texOffs(428, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -30.525F, -1.772724133595217F, -1.8325957145940455F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_7", CubeListBuilder.create().texOffs(448, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -29.702275866404783F, -1.2977241335952174F, -2.3561944901923457F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_8", CubeListBuilder.create().texOffs(468, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -29.22727586640478F, -0.47500000000000064F, -2.8797932657906435F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_9", CubeListBuilder.create().texOffs(488, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -29.22727586640478F, 0.4749999999999992F, 2.8797932657906467F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_10", CubeListBuilder.create().texOffs(508, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -29.702275866404783F, 1.2977241335952159F, 2.356194490192344F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_11", CubeListBuilder.create().texOffs(528, 238).addBox(-4.0F, -1.0F, -1.0F, 8.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(-64.0F, -30.525F, 1.7727241335952164F, 1.8325957145940466F, 0.0F, -3.141592653589793F));
        g.addOrReplaceChild("torreta_boca_ta", CubeListBuilder.create().texOffs(704, 109).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-61.95F, -31.0F, 0.0F, 0.0F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("torreta_boca_tb", CubeListBuilder.create().texOffs(768, 109).addBox(-8.0F, 0.0F, -8.0F, 16.0F, 1.0F, 16.0F), PartPose.offsetAndRotation(-66.05F, -31.0F, 0.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("torreta_antena", CubeListBuilder.create().texOffs(460, 109).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 28.0F, 1.0F), PartPose.offsetAndRotation(14.0F, -37.0F, -10.0F, 0.0F, 0.0F, -3.067653615931853F));
        g.addOrReplaceChild("faro_i_0", CubeListBuilder.create().texOffs(124, 223).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(424, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, -17.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_1", CubeListBuilder.create().texOffs(148, 223).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(448, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, -17.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_2", CubeListBuilder.create().texOffs(172, 223).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(472, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, -17.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_3", CubeListBuilder.create().texOffs(196, 223).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(496, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, -17.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_i_vidrio", CubeListBuilder.create().texOffs(0, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-44.82F, -21.5F, -17.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("caja_herramientas_i", CubeListBuilder.create().texOffs(638, 146).addBox(16.0F, -30.0F, -21.0F, 14.0F, 4.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("escape_i_0", CubeListBuilder.create().texOffs(352, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(45.35676274578121F, -19.559161060780646F, -7.5F, 0.0F, 1.5707963267948966F, -1.2566370614359172F));
        g.addOrReplaceChild("escape_i_1", CubeListBuilder.create().texOffs(384, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.83852549156242F, -18.84586867355928F, -7.5F, 0.0F, 1.5707963267948966F, -0.62831853071796F));
        g.addOrReplaceChild("escape_i_2", CubeListBuilder.create().texOffs(416, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.0F, -18.57341522555727F, -7.5F, 0.0F, 1.5707963267948966F, 0.0F));
        g.addOrReplaceChild("escape_i_3", CubeListBuilder.create().texOffs(448, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(43.16147450843758F, -18.84586867355928F, -7.5F, 0.0F, 1.5707963267948966F, 0.62831853071796F));
        g.addOrReplaceChild("escape_i_4", CubeListBuilder.create().texOffs(480, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(42.64323725421879F, -19.559161060780646F, -7.5F, 0.0F, 1.5707963267948966F, 1.2566370614359172F));
        g.addOrReplaceChild("escape_i_5", CubeListBuilder.create().texOffs(512, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(42.64323725421879F, -20.440838939219354F, -7.5F, 0.0F, 1.5707963267948966F, 1.8849555921538759F));
        g.addOrReplaceChild("escape_i_6", CubeListBuilder.create().texOffs(544, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(43.16147450843758F, -21.15413132644072F, -7.5F, 0.0F, 1.5707963267948966F, 2.513274122871833F));
        g.addOrReplaceChild("escape_i_7", CubeListBuilder.create().texOffs(576, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.0F, -21.42658477444273F, -7.5F, 0.0F, 1.5707963267948966F, 3.141592653589793F));
        g.addOrReplaceChild("escape_i_8", CubeListBuilder.create().texOffs(608, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.83852549156242F, -21.15413132644072F, -7.5F, 0.0F, 1.5707963267948966F, -2.513274122871833F));
        g.addOrReplaceChild("escape_i_9", CubeListBuilder.create().texOffs(640, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(45.35676274578121F, -20.440838939219354F, -7.5F, 0.0F, 1.5707963267948966F, -1.8849555921538759F));
        g.addOrReplaceChild("escape_i_ta", CubeListBuilder.create().texOffs(48, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(44.0F, -20.0F, -3.95F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("escape_i_tb", CubeListBuilder.create().texOffs(96, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(44.0F, -20.0F, -11.05F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("gancho_i", CubeListBuilder.create().texOffs(112, 228).addBox(-46.0F, -16.0F, -9.0F, 2.0F, 2.0F, 2.0F), PartPose.ZERO);
        g.addOrReplaceChild("faro_d_0", CubeListBuilder.create().texOffs(220, 223).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(520, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, 17.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_1", CubeListBuilder.create().texOffs(244, 223).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(544, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, 17.0F, 0.0F, 0.39269908169872414F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_2", CubeListBuilder.create().texOffs(268, 223).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(568, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, 17.0F, 0.0F, 0.7853981633974482F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_3", CubeListBuilder.create().texOffs(292, 223).addBox(-5.0F, -0.8571428571428572F, -1.0F, 10.0F, 2.0F, 2.0F).texOffs(592, 146).addBox(-1.0F, -0.8571428571428572F, -5.0F, 2.0F, 2.0F, 10.0F), PartPose.offsetAndRotation(-44.0F, -21.5F, 17.0F, 0.0F, 1.1780972450961724F, 1.5707963267948966F));
        g.addOrReplaceChild("faro_d_vidrio", CubeListBuilder.create().texOffs(144, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(-44.82F, -21.5F, 17.0F, 0.0F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("caja_herramientas_d", CubeListBuilder.create().texOffs(678, 146).addBox(16.0F, -30.0F, 15.0F, 14.0F, 4.0F, 6.0F), PartPose.ZERO);
        g.addOrReplaceChild("escape_d_0", CubeListBuilder.create().texOffs(672, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(45.35676274578121F, -20.440838939219354F, 7.5F, 0.0F, -1.5707963267948966F, -1.8849555921538759F));
        g.addOrReplaceChild("escape_d_1", CubeListBuilder.create().texOffs(704, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.83852549156242F, -21.15413132644072F, 7.5F, 0.0F, -1.5707963267948966F, -2.513274122871833F));
        g.addOrReplaceChild("escape_d_2", CubeListBuilder.create().texOffs(736, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.0F, -21.42658477444273F, 7.5F, 0.0F, -1.5707963267948966F, 3.141592653589793F));
        g.addOrReplaceChild("escape_d_3", CubeListBuilder.create().texOffs(768, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(43.16147450843758F, -21.15413132644072F, 7.5F, 0.0F, -1.5707963267948966F, 2.513274122871833F));
        g.addOrReplaceChild("escape_d_4", CubeListBuilder.create().texOffs(800, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(42.64323725421879F, -20.440838939219354F, 7.5F, 0.0F, -1.5707963267948966F, 1.8849555921538759F));
        g.addOrReplaceChild("escape_d_5", CubeListBuilder.create().texOffs(832, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(42.64323725421879F, -19.559161060780646F, 7.5F, 0.0F, -1.5707963267948966F, 1.2566370614359172F));
        g.addOrReplaceChild("escape_d_6", CubeListBuilder.create().texOffs(864, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(43.16147450843758F, -18.84586867355928F, 7.5F, 0.0F, -1.5707963267948966F, 0.62831853071796F));
        g.addOrReplaceChild("escape_d_7", CubeListBuilder.create().texOffs(896, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.0F, -18.57341522555727F, 7.5F, 0.0F, -1.5707963267948966F, 0.0F));
        g.addOrReplaceChild("escape_d_8", CubeListBuilder.create().texOffs(928, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(44.83852549156242F, -18.84586867355928F, 7.5F, 0.0F, -1.5707963267948966F, -0.62831853071796F));
        g.addOrReplaceChild("escape_d_9", CubeListBuilder.create().texOffs(960, 235).addBox(-7.0F, -1.0F, -1.0F, 14.0F, 1.0F, 2.0F), PartPose.offsetAndRotation(45.35676274578121F, -19.559161060780646F, 7.5F, 0.0F, -1.5707963267948966F, -1.2566370614359172F));
        g.addOrReplaceChild("escape_d_ta", CubeListBuilder.create().texOffs(192, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(44.0F, -20.0F, 3.95F, -1.5707963267948966F, 0.0F, -1.5707963267948966F));
        g.addOrReplaceChild("escape_d_tb", CubeListBuilder.create().texOffs(240, 146).addBox(-6.0F, 0.0F, -6.0F, 12.0F, 1.0F, 12.0F), PartPose.offsetAndRotation(44.0F, -20.0F, 11.05F, 1.5707963267948966F, 0.0F, 1.5707963267948966F));
        g.addOrReplaceChild("gancho_d", CubeListBuilder.create().texOffs(120, 228).addBox(-46.0F, -16.0F, 7.0F, 2.0F, 2.0F, 2.0F), PartPose.ZERO);
    }

    private static void escalas0(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "oruga_i_0", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_1", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_2", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_3", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_4", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_5", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_6", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_7", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_8", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_9", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_10", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_11", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_12", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_13", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_14", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_15", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_16", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_17", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_18", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_19", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_20", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_21", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_22", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_23", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_24", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_25", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_26", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_27", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_28", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_29", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_30", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_31", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_32", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_33", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_34", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_35", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_36", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_37", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_38", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_39", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_40", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_41", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_42", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_43", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_44", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_45", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_46", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_47", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_48", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_49", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_50", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_51", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_52", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_53", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_54", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_55", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_56", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_57", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_58", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_59", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_60", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_61", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_62", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_63", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_64", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_65", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_66", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_67", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_68", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_69", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_70", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_71", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_72", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_73", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_74", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_75", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_i_76", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "rodillo_i0_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_i1_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_i2_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_i3_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_i4_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_i5_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "motriz_i_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "tensora_i_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_alto_i0_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_alto_i1_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "oruga_d_0", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_1", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_2", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_3", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_4", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_5", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_6", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_7", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_8", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_9", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_10", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_11", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_12", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_13", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_14", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_15", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_16", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_17", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_18", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_19", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_20", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_21", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_22", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_23", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_24", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_25", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_26", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_27", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_28", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_29", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_30", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_31", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_32", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_33", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_34", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_35", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_36", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_37", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_38", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_39", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_40", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_41", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_42", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_43", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_44", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_45", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_46", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_47", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_48", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_49", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_50", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_51", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_52", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_53", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_54", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_55", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_56", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_57", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_58", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_59", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_60", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_61", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_62", 0.7626483949320408F, 1.0F, 1.0F);
    }

    private static void escalas1(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "oruga_d_63", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_64", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_65", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_66", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_67", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_68", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_69", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_70", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_71", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_72", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_73", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_74", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_75", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "oruga_d_76", 0.7626483949320408F, 1.0F, 1.0F);
        escalar(g0, "rodillo_d0_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_d1_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_d2_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_d3_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_d4_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_d5_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "motriz_d_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "tensora_d_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_alto_d0_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "rodillo_alto_d1_cara", 0.3333333333333333F, 0.3333333333333333F, 1.0F);
        escalar(g0, "casco_bajo_ladoi_0", 0.4518043607061133F, 1.0F, 0.8725000000000005F);
        escalar(g0, "casco_bajo_ladoi_1", 0.6536087214122077F, 1.0F, 0.90625F);
        escalar(g0, "casco_bajo_ladoi_2", 0.922681202353685F, 1.0F, 0.9625000000000004F);
        escalar(g0, "casco_bajo_ladoi_3", 1.1917536832951634F, 1.0F, 1.0412499999999998F);
        escalar(g0, "casco_bajo_ladoi_4", 0.730413082118316F, 1.0F, 0.7616666666666667F);
        escalar(g0, "casco_bajo_ladoi_5", 0.8649493225890552F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladoi_6", 0.9994855630597892F, 1.0F, 0.9416666666666668F);
        escalar(g0, "casco_bajo_ladoi_7", 1.0151942809610923F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_8", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_9", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_10", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_11", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_12", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_13", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_14", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_15", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_16", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_17", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_18", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_19", 1.0624999999999982F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_20", 1.0625000000000018F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_21", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_22", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_23", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_24", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_25", 0.8700000000000001F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_26", 0.9994855630597892F, 1.0F, 0.8187500000000001F);
        escalar(g0, "casco_bajo_ladoi_27", 0.86494932258906F, 1.0F, 0.994166666666667F);
        escalar(g0, "casco_bajo_ladoi_28", 0.730413082118311F, 1.0F, 0.9116666666666665F);
        escalar(g0, "casco_bajo_ladoi_29", 1.1917536832951634F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladoi_30", 0.922681202353685F, 1.0F, 0.7916666666666666F);
        escalar(g0, "casco_bajo_ladoi_31", 0.6536087214122088F, 1.0F, 0.7541666666666664F);
        escalar(g0, "casco_bajo_ladoi_32", 0.4518043607061133F, 1.0F, 1.0975000000000001F);
        escalar(g0, "casco_bajo_ladoi_33", 0.6119478553604065F, 1.0F, 0.90625F);
        escalar(g0, "casco_bajo_ladoi_34", 0.8532464256006819F, 1.0F, 0.9624999999999995F);
        escalar(g0, "casco_bajo_ladoi_35", 1.0945449958409603F, 1.0F, 1.0412500000000007F);
        escalar(g0, "casco_bajo_ladoi_36", 0.6679217830406133F, 1.0F, 0.7616666666666667F);
        escalar(g0, "casco_bajo_ladoi_37", 0.788571068160752F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladoi_38", 0.9092203532808857F, 1.0F, 0.941666666666667F);
        escalar(g0, "casco_bajo_ladoi_39", 0.9466744113668015F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_40", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_41", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_42", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_43", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_44", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_45", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_46", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_47", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_48", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_49", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_50", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_51", 1.0624999999999982F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_52", 1.0625000000000018F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_53", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_54", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_55", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_56", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_57", 0.8613106679934635F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_58", 0.9092203532808857F, 1.0F, 0.8187499999999996F);
        escalar(g0, "casco_bajo_ladoi_59", 0.7885710681607564F, 1.0F, 0.9941666666666672F);
        escalar(g0, "casco_bajo_ladoi_60", 0.6679217830406089F, 1.0F, 0.9116666666666658F);
        escalar(g0, "casco_bajo_ladoi_61", 1.0945449958409592F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladoi_62", 0.8532464256006819F, 1.0F, 0.7916666666666666F);
        escalar(g0, "casco_bajo_ladoi_63", 0.6119478553604076F, 1.0F, 0.754166666666667F);
        escalar(g0, "casco_bajo_ladoi_64", 0.5789756829919162F, 1.0F, 0.90625F);
        escalar(g0, "casco_bajo_ladoi_65", 0.7982928049865325F, 1.0F, 0.9624999999999995F);
        escalar(g0, "casco_bajo_ladoi_66", 1.017609926981149F, 1.0F, 1.0412500000000007F);
        escalar(g0, "casco_bajo_ladoi_67", 1.2369270489757573F, 1.0F, 0.7616666666666667F);
        escalar(g0, "casco_bajo_ladoi_68", 0.7281220854851869F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladoi_69", 0.8377806464824906F, 1.0F, 0.9416666666666664F);
        escalar(g0, "casco_bajo_ladoi_70", 0.8943340571124679F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_71", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_72", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_73", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_74", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_75", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_76", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_77", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_78", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_79", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_80", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_81", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_82", 1.0624999999999982F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_83", 1.0625000000000018F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_84", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_85", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_86", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_87", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_88", 0.8550465825031492F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_89", 0.8377806464824914F, 1.0F, 0.8187500000000001F);
        escalar(g0, "casco_bajo_ladoi_90", 0.7281220854851904F, 1.0F, 0.9941666666666661F);
        escalar(g0, "casco_bajo_ladoi_91", 1.2369270489757493F, 1.0F, 0.9116666666666658F);
        escalar(g0, "casco_bajo_ladoi_92", 1.017609926981149F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladoi_93", 0.7982928049865325F, 1.0F, 0.7916666666666666F);
        escalar(g0, "casco_bajo_ladoi_94", 0.5789756829919169F, 1.0F, 0.754166666666667F);
        escalar(g0, "casco_bajo_ladoi_95", 0.557499999999997F, 1.0F, 0.90625F);
        escalar(g0, "casco_bajo_ladoi_96", 0.7625000000000002F, 1.0F, 0.9625000000000004F);
        escalar(g0, "casco_bajo_ladoi_97", 0.9675000000000026F, 1.0F, 1.0412499999999998F);
        escalar(g0, "casco_bajo_ladoi_98", 1.1724999999999988F, 1.0F, 0.7616666666666667F);
        escalar(g0, "casco_bajo_ladoi_99", 0.6887500000000008F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladoi_100", 0.7912499999999985F, 1.0F, 0.9416666666666664F);
        escalar(g0, "casco_bajo_ladoi_101", 0.8613106679934635F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_102", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_103", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_104", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_105", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_106", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_107", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_108", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_109", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_110", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_111", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_112", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_113", 1.0624999999999982F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_114", 1.0625000000000018F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_115", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_116", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_117", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_118", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_119", 0.851264625451542F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladoi_120", 0.7912499999999985F, 1.0F, 0.8187500000000001F);
        escalar(g0, "casco_bajo_ladoi_121", 0.6887500000000044F, 1.0F, 0.9941666666666672F);
        escalar(g0, "casco_bajo_ladoi_122", 1.1724999999999914F, 1.0F, 0.9116666666666665F);
        escalar(g0, "casco_bajo_ladoi_123", 0.9675000000000029F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladoi_124", 0.7625000000000002F, 1.0F, 0.7916666666666666F);
        escalar(g0, "casco_bajo_ladoi_125", 0.557499999999997F, 1.0F, 0.7541666666666664F);
    }

    private static void escalas2(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "casco_bajo_ladoi_126", 0.5499999999999972F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_127", 0.75F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_128", 0.9500000000000028F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_129", 1.1499999999999986F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_130", 0.6750000000000007F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_131", 0.7749999999999986F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_132", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_133", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_134", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_135", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_136", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_137", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_138", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_139", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_140", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_141", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_142", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_143", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_144", 1.0624999999999982F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_145", 1.0625000000000018F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_146", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_147", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_148", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_149", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_150", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_151", 0.7749999999999986F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_152", 0.6750000000000043F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_153", 1.1499999999999915F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_154", 0.9500000000000028F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_155", 0.75F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_156", 0.5499999999999972F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladoi_157", 0.5499999999999972F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_158", 0.75F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_159", 0.9500000000000028F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_160", 1.1499999999999986F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_161", 0.6750000000000007F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_162", 0.7749999999999986F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_163", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_164", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_165", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_166", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_167", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_168", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_169", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_170", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_171", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_172", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_173", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_174", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_175", 1.0624999999999982F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_176", 1.0625000000000018F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_177", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_178", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_179", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_180", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_181", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_182", 0.7749999999999986F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_183", 0.6750000000000043F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_184", 1.1499999999999915F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_185", 0.9500000000000028F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_186", 0.75F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_187", 0.5499999999999972F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladoi_188", 0.5499999999999972F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_189", 0.75F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_190", 0.9500000000000028F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_191", 1.1499999999999986F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_192", 0.6750000000000007F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_193", 0.7749999999999986F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_194", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_195", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_196", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_197", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_198", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_199", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_200", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_201", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_202", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_203", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_204", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_205", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_206", 1.0624999999999982F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_207", 1.0625000000000018F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_208", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_209", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_210", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_211", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_212", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_213", 0.7749999999999986F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_214", 0.6750000000000043F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_215", 1.1499999999999915F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_216", 0.9500000000000028F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_217", 0.75F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_218", 0.5499999999999972F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladoi_219", 0.5499999999999972F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_220", 0.75F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_221", 0.9500000000000028F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_222", 1.1499999999999986F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_223", 0.6750000000000007F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_224", 0.7749999999999986F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_225", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_226", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_227", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_228", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_229", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_230", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_231", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_232", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_233", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_234", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_235", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_236", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_237", 1.0624999999999982F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_238", 1.0625000000000018F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_239", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_240", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_241", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_242", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_243", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_244", 0.7749999999999986F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_245", 0.6750000000000043F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_246", 1.1499999999999915F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_247", 0.9500000000000028F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_248", 0.75F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladoi_249", 0.5499999999999972F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_0", 0.4518043607061133F, 1.0F, 0.8725000000000005F);
        escalar(g0, "casco_bajo_ladod_1", 0.6536087214122077F, 1.0F, 0.90625F);
        escalar(g0, "casco_bajo_ladod_2", 0.922681202353685F, 1.0F, 0.9625000000000004F);
        escalar(g0, "casco_bajo_ladod_3", 1.1917536832951634F, 1.0F, 1.0412499999999998F);
        escalar(g0, "casco_bajo_ladod_4", 0.730413082118316F, 1.0F, 0.7616666666666667F);
        escalar(g0, "casco_bajo_ladod_5", 0.8649493225890552F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladod_6", 0.9994855630597892F, 1.0F, 0.9416666666666668F);
        escalar(g0, "casco_bajo_ladod_7", 1.0151942809610923F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_8", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_9", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_10", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_11", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_12", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_13", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_14", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_15", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_16", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_17", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_18", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_19", 1.0624999999999982F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_20", 1.0625000000000018F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_21", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_22", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_23", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_24", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_25", 0.8700000000000001F, 1.0F, 0.875F);
    }

    private static void escalas3(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "casco_bajo_ladod_26", 0.9994855630597892F, 1.0F, 0.8187500000000001F);
        escalar(g0, "casco_bajo_ladod_27", 0.86494932258906F, 1.0F, 0.994166666666667F);
        escalar(g0, "casco_bajo_ladod_28", 0.730413082118311F, 1.0F, 0.9116666666666665F);
        escalar(g0, "casco_bajo_ladod_29", 1.1917536832951634F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladod_30", 0.922681202353685F, 1.0F, 0.7916666666666666F);
        escalar(g0, "casco_bajo_ladod_31", 0.6536087214122088F, 1.0F, 0.7541666666666664F);
        escalar(g0, "casco_bajo_ladod_32", 0.4518043607061133F, 1.0F, 1.0975000000000001F);
        escalar(g0, "casco_bajo_ladod_33", 0.6119478553604065F, 1.0F, 0.90625F);
        escalar(g0, "casco_bajo_ladod_34", 0.8532464256006819F, 1.0F, 0.9624999999999995F);
        escalar(g0, "casco_bajo_ladod_35", 1.0945449958409603F, 1.0F, 1.0412500000000007F);
        escalar(g0, "casco_bajo_ladod_36", 0.6679217830406133F, 1.0F, 0.7616666666666667F);
        escalar(g0, "casco_bajo_ladod_37", 0.788571068160752F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladod_38", 0.9092203532808857F, 1.0F, 0.941666666666667F);
        escalar(g0, "casco_bajo_ladod_39", 0.9466744113668015F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_40", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_41", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_42", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_43", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_44", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_45", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_46", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_47", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_48", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_49", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_50", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_51", 1.0624999999999982F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_52", 1.0625000000000018F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_53", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_54", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_55", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_56", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_57", 0.8613106679934635F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_58", 0.9092203532808857F, 1.0F, 0.8187499999999996F);
        escalar(g0, "casco_bajo_ladod_59", 0.7885710681607564F, 1.0F, 0.9941666666666672F);
        escalar(g0, "casco_bajo_ladod_60", 0.6679217830406089F, 1.0F, 0.9116666666666658F);
        escalar(g0, "casco_bajo_ladod_61", 1.0945449958409592F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladod_62", 0.8532464256006819F, 1.0F, 0.7916666666666666F);
        escalar(g0, "casco_bajo_ladod_63", 0.6119478553604076F, 1.0F, 0.754166666666667F);
        escalar(g0, "casco_bajo_ladod_64", 0.5789756829919162F, 1.0F, 0.90625F);
        escalar(g0, "casco_bajo_ladod_65", 0.7982928049865325F, 1.0F, 0.9624999999999995F);
        escalar(g0, "casco_bajo_ladod_66", 1.017609926981149F, 1.0F, 1.0412500000000007F);
        escalar(g0, "casco_bajo_ladod_67", 1.2369270489757573F, 1.0F, 0.7616666666666667F);
        escalar(g0, "casco_bajo_ladod_68", 0.7281220854851869F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladod_69", 0.8377806464824906F, 1.0F, 0.9416666666666664F);
        escalar(g0, "casco_bajo_ladod_70", 0.8943340571124679F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_71", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_72", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_73", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_74", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_75", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_76", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_77", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_78", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_79", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_80", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_81", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_82", 1.0624999999999982F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_83", 1.0625000000000018F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_84", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_85", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_86", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_87", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_88", 0.8550465825031492F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_89", 0.8377806464824914F, 1.0F, 0.8187500000000001F);
        escalar(g0, "casco_bajo_ladod_90", 0.7281220854851904F, 1.0F, 0.9941666666666661F);
        escalar(g0, "casco_bajo_ladod_91", 1.2369270489757493F, 1.0F, 0.9116666666666658F);
        escalar(g0, "casco_bajo_ladod_92", 1.017609926981149F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladod_93", 0.7982928049865325F, 1.0F, 0.7916666666666666F);
        escalar(g0, "casco_bajo_ladod_94", 0.5789756829919169F, 1.0F, 0.754166666666667F);
        escalar(g0, "casco_bajo_ladod_95", 0.557499999999997F, 1.0F, 0.90625F);
        escalar(g0, "casco_bajo_ladod_96", 0.7625000000000002F, 1.0F, 0.9625000000000004F);
        escalar(g0, "casco_bajo_ladod_97", 0.9675000000000026F, 1.0F, 1.0412499999999998F);
        escalar(g0, "casco_bajo_ladod_98", 1.1724999999999988F, 1.0F, 0.7616666666666667F);
        escalar(g0, "casco_bajo_ladod_99", 0.6887500000000008F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladod_100", 0.7912499999999985F, 1.0F, 0.9416666666666664F);
        escalar(g0, "casco_bajo_ladod_101", 0.8613106679934635F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_102", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_103", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_104", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_105", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_106", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_107", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_108", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_109", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_110", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_111", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_112", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_113", 1.0624999999999982F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_114", 1.0625000000000018F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_115", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_116", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_117", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_118", 1.0625F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_119", 0.851264625451542F, 1.0F, 0.875F);
        escalar(g0, "casco_bajo_ladod_120", 0.7912499999999985F, 1.0F, 0.8187500000000001F);
        escalar(g0, "casco_bajo_ladod_121", 0.6887500000000044F, 1.0F, 0.9941666666666672F);
        escalar(g0, "casco_bajo_ladod_122", 1.1724999999999914F, 1.0F, 0.9116666666666665F);
        escalar(g0, "casco_bajo_ladod_123", 0.9675000000000029F, 1.0F, 0.8441666666666668F);
        escalar(g0, "casco_bajo_ladod_124", 0.7625000000000002F, 1.0F, 0.7916666666666666F);
        escalar(g0, "casco_bajo_ladod_125", 0.557499999999997F, 1.0F, 0.7541666666666664F);
        escalar(g0, "casco_bajo_ladod_126", 0.5499999999999972F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_127", 0.75F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_128", 0.9500000000000028F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_129", 1.1499999999999986F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_130", 0.6750000000000007F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_131", 0.7749999999999986F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_132", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_133", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_134", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_135", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_136", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_137", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_138", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_139", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_140", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_141", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_142", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_143", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_144", 1.0624999999999982F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_145", 1.0625000000000018F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_146", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_147", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_148", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_149", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_150", 1.0625F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_151", 0.7749999999999986F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_152", 0.6750000000000043F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_153", 1.1499999999999915F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_154", 0.9500000000000028F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_155", 0.75F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_156", 0.5499999999999972F, 1.0F, 0.6401806440322583F);
        escalar(g0, "casco_bajo_ladod_157", 0.5499999999999972F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_158", 0.75F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_159", 0.9500000000000028F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_160", 1.1499999999999986F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_161", 0.6750000000000007F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_162", 0.7749999999999986F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_163", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_164", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_165", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_166", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_167", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_168", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_169", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_170", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_171", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_172", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_173", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_174", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_175", 1.0624999999999982F, 1.0F, 0.6401806440322535F);
    }

    private static void escalas4(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "casco_bajo_ladod_176", 1.0625000000000018F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_177", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_178", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_179", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_180", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_181", 1.0625F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_182", 0.7749999999999986F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_183", 0.6750000000000043F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_184", 1.1499999999999915F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_185", 0.9500000000000028F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_186", 0.75F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_187", 0.5499999999999972F, 1.0F, 0.6401806440322535F);
        escalar(g0, "casco_bajo_ladod_188", 0.5499999999999972F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_189", 0.75F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_190", 0.9500000000000028F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_191", 1.1499999999999986F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_192", 0.6750000000000007F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_193", 0.7749999999999986F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_194", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_195", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_196", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_197", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_198", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_199", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_200", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_201", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_202", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_203", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_204", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_205", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_206", 1.0624999999999982F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_207", 1.0625000000000018F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_208", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_209", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_210", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_211", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_212", 1.0625F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_213", 0.7749999999999986F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_214", 0.6750000000000043F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_215", 1.1499999999999915F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_216", 0.9500000000000028F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_217", 0.75F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_218", 0.5499999999999972F, 1.0F, 0.6401806440322574F);
        escalar(g0, "casco_bajo_ladod_219", 0.5499999999999972F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_220", 0.75F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_221", 0.9500000000000028F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_222", 1.1499999999999986F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_223", 0.6750000000000007F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_224", 0.7749999999999986F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_225", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_226", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_227", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_228", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_229", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_230", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_231", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_232", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_233", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_234", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_235", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_236", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_237", 1.0624999999999982F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_238", 1.0625000000000018F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_239", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_240", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_241", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_242", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_243", 1.0625F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_244", 0.7749999999999986F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_245", 0.6750000000000043F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_246", 1.1499999999999915F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_247", 0.9500000000000028F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_248", 0.75F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_ladod_249", 0.5499999999999972F, 1.0F, 0.6401806440322565F);
        escalar(g0, "casco_bajo_arriba0_0", 0.5499999999999972F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_1", 0.75F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_2", 0.9500000000000028F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_3", 1.1499999999999986F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_4", 0.6750000000000007F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_5", 0.7749999999999986F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_6", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_7", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_8", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_9", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_10", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_11", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_12", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_13", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_14", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_15", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_16", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_17", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_18", 1.0624999999999982F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_19", 1.0625000000000018F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_20", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_21", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_22", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_23", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_24", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_25", 0.7749999999999986F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_26", 0.6750000000000043F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_27", 1.1499999999999915F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_28", 0.9500000000000028F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_29", 0.75F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_30", 0.5499999999999972F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_31", 0.5499999999999972F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_32", 0.75F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_33", 0.9500000000000028F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_34", 1.1499999999999986F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_35", 0.6750000000000007F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_36", 0.7749999999999986F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_37", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_38", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_39", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_40", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_41", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_42", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_43", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_44", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_45", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_46", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_47", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_48", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_49", 1.0624999999999982F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_50", 1.0625000000000018F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_51", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_52", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_53", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_54", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_55", 1.0625F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_56", 0.7749999999999986F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_57", 0.6750000000000043F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_58", 1.1499999999999915F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_59", 0.9500000000000028F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_60", 0.75F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_61", 0.5499999999999972F, 1.0F, 1.0208333333333333F);
        escalar(g0, "casco_bajo_arriba0_62", 0.5499999999999972F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_63", 0.75F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_64", 0.9500000000000028F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_65", 1.1499999999999986F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_66", 0.6750000000000007F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_67", 0.7749999999999986F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_68", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_69", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_70", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_71", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_72", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_73", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_74", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_75", 1.0625F, 1.0F, 1.0208333333333335F);
    }

    private static void escalas5(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "casco_bajo_arriba0_76", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_77", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_78", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_79", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_80", 1.0624999999999982F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_81", 1.0625000000000018F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_82", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_83", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_84", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_85", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_86", 1.0625F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_87", 0.7749999999999986F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_88", 0.6750000000000043F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_89", 1.1499999999999915F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_90", 0.9500000000000028F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_91", 0.75F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_92", 0.5499999999999972F, 1.0F, 1.0208333333333335F);
        escalar(g0, "casco_bajo_arriba0_93", 0.5499999999999972F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_94", 0.75F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_95", 0.9500000000000028F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_96", 1.1499999999999986F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_97", 0.6750000000000007F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_98", 0.7749999999999986F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_99", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_100", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_101", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_102", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_103", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_104", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_105", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_106", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_107", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_108", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_109", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_110", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_111", 1.0624999999999982F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_112", 1.0625000000000018F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_113", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_114", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_115", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_116", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_117", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_118", 0.7749999999999986F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_119", 0.6750000000000043F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_120", 1.1499999999999915F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_121", 0.9500000000000028F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_122", 0.75F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_123", 0.5499999999999972F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_124", 0.5499999999999972F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_125", 0.75F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_126", 0.9500000000000028F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_127", 1.1499999999999986F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_128", 0.6750000000000007F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_129", 0.7749999999999986F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_130", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_131", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_132", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_133", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_134", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_135", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_136", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_137", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_138", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_139", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_140", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_141", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_142", 1.0624999999999982F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_143", 1.0625000000000018F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_144", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_145", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_146", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_147", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_148", 1.0625F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_149", 0.7749999999999986F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_150", 0.6750000000000043F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_151", 1.1499999999999915F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_152", 0.9500000000000028F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_153", 0.75F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_154", 0.5499999999999972F, 1.0F, 1.020833333333333F);
        escalar(g0, "casco_bajo_arriba0_155", 0.5499999999999972F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_156", 0.75F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_157", 0.9500000000000028F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_158", 1.1499999999999986F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_159", 0.6750000000000007F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_160", 0.7749999999999986F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_161", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_162", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_163", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_164", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_165", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_166", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_167", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_168", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_169", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_170", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_171", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_172", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_173", 1.0624999999999982F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_174", 1.0625000000000018F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_175", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_176", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_177", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_178", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_179", 1.0625F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_180", 0.7749999999999986F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_181", 0.6750000000000043F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_182", 1.1499999999999915F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_183", 0.9500000000000028F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_184", 0.75F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_arriba0_185", 0.5499999999999972F, 1.0F, 1.020833333333334F);
        escalar(g0, "casco_bajo_trompa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "casco_bajo_cola", 1.0F, 0.5F, 0.5F);
        escalar(g0, "casco_ladoi_0", 0.6762113582708698F, 1.0F, 0.4957031249999986F);
        escalar(g0, "casco_ladoi_1", 0.7764316052292075F, 1.0F, 0.58203125F);
        escalar(g0, "casco_ladoi_2", 0.8559384239283189F, 1.0F, 1.0703125F);
        escalar(g0, "casco_ladoi_3", 0.8570248214894013F, 1.0F, 0.80078125F);
        escalar(g0, "casco_ladoi_4", 0.8190857701463137F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_5", 1.25F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_6", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_7", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_8", 1.0625000000000009F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_9", 1.0624999999999991F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_10", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_11", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_12", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_13", 1.0624999999999982F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_14", 1.0625000000000018F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_15", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_16", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_17", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_18", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_19", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_20", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_21", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_22", 0.8549231233899925F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_23", 0.7790000377543677F, 1.0F, 0.7777777777777786F);
        escalar(g0, "casco_ladoi_24", 0.6783846473306242F, 1.0F, 0.7055555555555557F);
        escalar(g0, "casco_ladoi_25", 1.1555385138137328F, 1.0F, 0.6444444444444439F);
        escalar(g0, "casco_ladoi_26", 0.9543077329662465F, 1.0F, 1.18888888888889F);
        escalar(g0, "casco_ladoi_27", 0.7530769521187451F, 1.0F, 1.1111111111111107F);
        escalar(g0, "casco_ladoi_28", 0.5518461712712446F, 1.0F, 1.0555555555555571F);
        escalar(g0, "casco_ladoi_29", 0.6798295647739642F, 1.0F, 0.49570312500000213F);
        escalar(g0, "casco_ladoi_30", 0.7807076674601371F, 1.0F, 0.58203125F);
        escalar(g0, "casco_ladoi_31", 0.8734967957777675F, 1.0F, 1.0703125F);
        escalar(g0, "casco_ladoi_32", 0.8777416565571652F, 1.0F, 0.80078125F);
        escalar(g0, "casco_ladoi_33", 0.8385078030223424F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_34", 1.25F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_35", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_36", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_37", 1.0625000000000009F, 1.0F, 1.0F);
    }

    private static void escalas6(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "casco_ladoi_38", 1.0624999999999991F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_39", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_40", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_41", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_42", 1.0624999999999982F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_43", 1.0625000000000018F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_44", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_45", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_46", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_47", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_48", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_49", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_50", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_51", 0.869515062870479F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_52", 0.7908559885822626F, 1.0F, 0.7777777777777768F);
        escalar(g0, "casco_ladoi_53", 0.6884166057234588F, 1.0F, 0.7055555555555557F);
        escalar(g0, "casco_ladoi_54", 1.1719544457292794F, 1.0F, 0.6444444444444439F);
        escalar(g0, "casco_ladoi_55", 0.9670756800116724F, 1.0F, 1.18888888888889F);
        escalar(g0, "casco_ladoi_56", 0.7621969142940492F, 1.0F, 1.1111111111111107F);
        escalar(g0, "casco_ladoi_57", 0.5573181485764267F, 1.0F, 1.0555555555555536F);
        escalar(g0, "casco_ladoi_58", 0.685808036124081F, 1.0F, 0.49570312500000213F);
        escalar(g0, "casco_ladoi_59", 0.7877731336011841F, 1.0F, 0.58203125F);
        escalar(g0, "casco_ladoi_60", 0.9019569757191748F, 1.0F, 1.0703125F);
        escalar(g0, "casco_ladoi_61", 0.9111629128684072F, 1.0F, 0.80078125F);
        escalar(g0, "casco_ladoi_62", 0.8698402308141318F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_63", 1.25F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_64", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_65", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_66", 1.0625000000000009F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_67", 1.0624999999999991F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_68", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_69", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_70", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_71", 1.0624999999999982F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_72", 1.0625000000000018F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_73", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_74", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_75", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_76", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_77", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_78", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_79", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_80", 0.8932740427115681F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_81", 0.810160159703147F, 1.0F, 0.7777777777777768F);
        escalar(g0, "casco_ladoi_82", 0.7047509043642076F, 1.0F, 0.7055555555555557F);
        escalar(g0, "casco_ladoi_83", 1.1986832980505047F, 1.0F, 0.6444444444444439F);
        escalar(g0, "casco_ladoi_84", 0.9878647873726248F, 1.0F, 1.1888888888888864F);
        escalar(g0, "casco_ladoi_85", 0.7770462766947303F, 1.0F, 1.1111111111111107F);
        escalar(g0, "casco_ladoi_86", 0.5662277660168346F, 1.0F, 1.0555555555555536F);
        escalar(g0, "casco_ladoi_87", 0.6940723888830518F, 1.0F, 0.4957031249999986F);
        escalar(g0, "casco_ladoi_88", 0.7975400959526951F, 1.0F, 0.58203125F);
        escalar(g0, "casco_ladoi_89", 0.940274053662691F, 1.0F, 1.0703125F);
        escalar(g0, "casco_ladoi_90", 0.9558835465996719F, 1.0F, 0.80078125F);
        escalar(g0, "casco_ladoi_91", 0.9117658249371925F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_92", 1.25F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_93", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_94", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_95", 1.0625000000000009F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_96", 1.0624999999999991F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_97", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_98", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_99", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_100", 1.0624999999999982F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_101", 1.0625000000000018F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_102", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_103", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_104", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_105", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_106", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_107", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_108", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_109", 0.9254540268263204F, 1.0F, 1.0F);
        escalar(g0, "casco_ladoi_110", 0.8363063967963836F, 1.0F, 0.7777777777777786F);
        escalar(g0, "casco_ladoi_111", 0.7268746434431003F, 1.0F, 0.7055555555555557F);
        escalar(g0, "casco_ladoi_112", 1.2348857801796007F, 1.0F, 0.6444444444444439F);
        escalar(g0, "casco_ladoi_113", 1.016022273473034F, 1.0F, 1.18888888888889F);
        escalar(g0, "casco_ladoi_114", 0.7971587667664499F, 1.0F, 1.1111111111111107F);
        escalar(g0, "casco_ladoi_115", 0.5782952600598674F, 1.0F, 1.0555555555555571F);
        escalar(g0, "casco_ladoi_116", 1.2089541027342063F, 1.0F, 0.5194685072847771F);
        escalar(g0, "casco_ladoi_117", 0.7110275072264612F, 1.0F, 0.6334744142129524F);
        escalar(g0, "casco_ladoi_118", 0.8175779630858153F, 1.0F, 0.7682086678553413F);
        escalar(g0, "casco_ladoi_119", 0.9461277407030654F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_120", 0.9558835465996719F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_121", 0.9117658249371925F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_122", 1.25F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_123", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_124", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_125", 1.0625000000000009F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_126", 1.0624999999999991F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_127", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_128", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_129", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_130", 1.0624999999999982F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_131", 1.0625000000000018F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_132", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_133", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_134", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_135", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_136", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_137", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_138", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_139", 0.9254540268263204F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_140", 0.8363063967963836F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_141", 0.7268746434431003F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_142", 1.2348857801796007F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_143", 1.016022273473034F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_144", 0.7971587667664499F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_145", 0.5782952600598674F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_146", 1.240682914316556F, 1.0F, 0.5194685072847782F);
        escalar(g0, "casco_ladoi_147", 0.7304173365267871F, 1.0F, 0.6334744142129537F);
        escalar(g0, "casco_ladoi_148", 0.8404932158952902F, 1.0F, 0.7682086678553399F);
        escalar(g0, "casco_ladoi_149", 0.9512600977200437F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_150", 0.9558835465996719F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_151", 0.9117658249371925F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_152", 1.25F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_153", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_154", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_155", 1.0625000000000009F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_156", 1.0624999999999991F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_157", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_158", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_159", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_160", 1.0624999999999982F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_161", 1.0625000000000018F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_162", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_163", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_164", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_165", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_166", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_167", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_168", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_169", 0.9254540268263204F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_170", 0.8363063967963836F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_171", 0.7268746434431003F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_172", 1.2348857801796007F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_173", 1.016022273473034F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_174", 0.7971587667664499F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_175", 0.5782952600598674F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_176", 0.6357133007585393F, 1.0F, 0.5194685072847782F);
        escalar(g0, "casco_ladoi_177", 0.7492051453715491F, 1.0F, 0.6334744142129537F);
        escalar(g0, "casco_ladoi_178", 0.862696989984555F, 1.0F, 0.7682086678553399F);
        escalar(g0, "casco_ladoi_179", 0.9549077307707826F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_180", 0.9558835465996719F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_181", 0.9117658249371925F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_182", 1.25F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_183", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_184", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_185", 1.0625000000000009F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_186", 1.0624999999999991F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_187", 1.0625F, 1.0F, 0.8352709660483856F);
    }

    private static void escalas7(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "casco_ladoi_188", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_189", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_190", 1.0624999999999982F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_191", 1.0625000000000018F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_192", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_193", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_194", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_195", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_196", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_197", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_198", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_199", 0.9254540268263204F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_200", 0.8363063967963836F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_201", 0.7268746434431003F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_202", 1.2348857801796007F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_203", 1.016022273473034F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_204", 0.7971587667664499F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_205", 0.5782952600598674F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladoi_206", 0.6483914392047423F, 1.0F, 0.5194685072847771F);
        escalar(g0, "casco_ladoi_207", 0.7647006479169095F, 1.0F, 0.6334744142129523F);
        escalar(g0, "casco_ladoi_208", 0.8810098566290716F, 1.0F, 0.7682086678553413F);
        escalar(g0, "casco_ladoi_209", 0.9565355153688133F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_210", 0.9558835465996719F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_211", 0.9117658249371925F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_212", 1.25F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_213", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_214", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_215", 1.0625000000000009F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_216", 1.0624999999999991F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_217", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_218", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_219", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_220", 1.0624999999999982F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_221", 1.0625000000000018F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_222", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_223", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_224", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_225", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_226", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_227", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_228", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_229", 0.9254540268263204F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_230", 0.8363063967963836F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_231", 0.7268746434431003F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_232", 1.2348857801796007F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_233", 1.016022273473034F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_234", 0.7971587667664499F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladoi_235", 0.5782952600598674F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_0", 0.6762113582708698F, 1.0F, 0.4957031249999986F);
        escalar(g0, "casco_ladod_1", 0.7764316052292075F, 1.0F, 0.58203125F);
        escalar(g0, "casco_ladod_2", 0.8559384239283189F, 1.0F, 1.0703125F);
        escalar(g0, "casco_ladod_3", 0.8570248214894013F, 1.0F, 0.80078125F);
        escalar(g0, "casco_ladod_4", 0.8190857701463137F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_5", 1.25F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_6", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_7", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_8", 1.0625000000000009F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_9", 1.0624999999999991F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_10", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_11", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_12", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_13", 1.0624999999999982F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_14", 1.0625000000000018F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_15", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_16", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_17", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_18", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_19", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_20", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_21", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_22", 0.8549231233899925F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_23", 0.7790000377543677F, 1.0F, 0.7777777777777786F);
        escalar(g0, "casco_ladod_24", 0.6783846473306242F, 1.0F, 0.7055555555555557F);
        escalar(g0, "casco_ladod_25", 1.1555385138137328F, 1.0F, 0.6444444444444439F);
        escalar(g0, "casco_ladod_26", 0.9543077329662465F, 1.0F, 1.18888888888889F);
        escalar(g0, "casco_ladod_27", 0.7530769521187451F, 1.0F, 1.1111111111111107F);
        escalar(g0, "casco_ladod_28", 0.5518461712712446F, 1.0F, 1.0555555555555571F);
        escalar(g0, "casco_ladod_29", 0.6798295647739642F, 1.0F, 0.49570312500000213F);
        escalar(g0, "casco_ladod_30", 0.7807076674601371F, 1.0F, 0.58203125F);
        escalar(g0, "casco_ladod_31", 0.8734967957777675F, 1.0F, 1.0703125F);
        escalar(g0, "casco_ladod_32", 0.8777416565571652F, 1.0F, 0.80078125F);
        escalar(g0, "casco_ladod_33", 0.8385078030223424F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_34", 1.25F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_35", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_36", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_37", 1.0625000000000009F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_38", 1.0624999999999991F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_39", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_40", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_41", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_42", 1.0624999999999982F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_43", 1.0625000000000018F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_44", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_45", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_46", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_47", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_48", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_49", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_50", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_51", 0.869515062870479F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_52", 0.7908559885822626F, 1.0F, 0.7777777777777768F);
        escalar(g0, "casco_ladod_53", 0.6884166057234588F, 1.0F, 0.7055555555555557F);
        escalar(g0, "casco_ladod_54", 1.1719544457292794F, 1.0F, 0.6444444444444439F);
        escalar(g0, "casco_ladod_55", 0.9670756800116724F, 1.0F, 1.18888888888889F);
        escalar(g0, "casco_ladod_56", 0.7621969142940492F, 1.0F, 1.1111111111111107F);
        escalar(g0, "casco_ladod_57", 0.5573181485764267F, 1.0F, 1.0555555555555536F);
        escalar(g0, "casco_ladod_58", 0.685808036124081F, 1.0F, 0.49570312500000213F);
        escalar(g0, "casco_ladod_59", 0.7877731336011841F, 1.0F, 0.58203125F);
        escalar(g0, "casco_ladod_60", 0.9019569757191748F, 1.0F, 1.0703125F);
        escalar(g0, "casco_ladod_61", 0.9111629128684072F, 1.0F, 0.80078125F);
        escalar(g0, "casco_ladod_62", 0.8698402308141318F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_63", 1.25F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_64", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_65", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_66", 1.0625000000000009F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_67", 1.0624999999999991F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_68", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_69", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_70", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_71", 1.0624999999999982F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_72", 1.0625000000000018F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_73", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_74", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_75", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_76", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_77", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_78", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_79", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_80", 0.8932740427115681F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_81", 0.810160159703147F, 1.0F, 0.7777777777777768F);
        escalar(g0, "casco_ladod_82", 0.7047509043642076F, 1.0F, 0.7055555555555557F);
        escalar(g0, "casco_ladod_83", 1.1986832980505047F, 1.0F, 0.6444444444444439F);
        escalar(g0, "casco_ladod_84", 0.9878647873726248F, 1.0F, 1.1888888888888864F);
        escalar(g0, "casco_ladod_85", 0.7770462766947303F, 1.0F, 1.1111111111111107F);
        escalar(g0, "casco_ladod_86", 0.5662277660168346F, 1.0F, 1.0555555555555536F);
        escalar(g0, "casco_ladod_87", 0.6940723888830518F, 1.0F, 0.4957031249999986F);
        escalar(g0, "casco_ladod_88", 0.7975400959526951F, 1.0F, 0.58203125F);
        escalar(g0, "casco_ladod_89", 0.940274053662691F, 1.0F, 1.0703125F);
        escalar(g0, "casco_ladod_90", 0.9558835465996719F, 1.0F, 0.80078125F);
        escalar(g0, "casco_ladod_91", 0.9117658249371925F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_92", 1.25F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_93", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_94", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_95", 1.0625000000000009F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_96", 1.0624999999999991F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_97", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_98", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_99", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_100", 1.0624999999999982F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_101", 1.0625000000000018F, 1.0F, 1.0F);
    }

    private static void escalas8(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "casco_ladod_102", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_103", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_104", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_105", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_106", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_107", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_108", 1.0625F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_109", 0.9254540268263204F, 1.0F, 1.0F);
        escalar(g0, "casco_ladod_110", 0.8363063967963836F, 1.0F, 0.7777777777777786F);
        escalar(g0, "casco_ladod_111", 0.7268746434431003F, 1.0F, 0.7055555555555557F);
        escalar(g0, "casco_ladod_112", 1.2348857801796007F, 1.0F, 0.6444444444444439F);
        escalar(g0, "casco_ladod_113", 1.016022273473034F, 1.0F, 1.18888888888889F);
        escalar(g0, "casco_ladod_114", 0.7971587667664499F, 1.0F, 1.1111111111111107F);
        escalar(g0, "casco_ladod_115", 0.5782952600598674F, 1.0F, 1.0555555555555571F);
        escalar(g0, "casco_ladod_116", 1.2089541027342063F, 1.0F, 0.5194685072847771F);
        escalar(g0, "casco_ladod_117", 0.7110275072264612F, 1.0F, 0.6334744142129524F);
        escalar(g0, "casco_ladod_118", 0.8175779630858153F, 1.0F, 0.7682086678553413F);
        escalar(g0, "casco_ladod_119", 0.9461277407030654F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_120", 0.9558835465996719F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_121", 0.9117658249371925F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_122", 1.25F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_123", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_124", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_125", 1.0625000000000009F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_126", 1.0624999999999991F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_127", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_128", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_129", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_130", 1.0624999999999982F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_131", 1.0625000000000018F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_132", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_133", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_134", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_135", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_136", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_137", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_138", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_139", 0.9254540268263204F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_140", 0.8363063967963836F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_141", 0.7268746434431003F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_142", 1.2348857801796007F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_143", 1.016022273473034F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_144", 0.7971587667664499F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_145", 0.5782952600598674F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_146", 1.240682914316556F, 1.0F, 0.5194685072847782F);
        escalar(g0, "casco_ladod_147", 0.7304173365267871F, 1.0F, 0.6334744142129537F);
        escalar(g0, "casco_ladod_148", 0.8404932158952902F, 1.0F, 0.7682086678553399F);
        escalar(g0, "casco_ladod_149", 0.9512600977200437F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_150", 0.9558835465996719F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_151", 0.9117658249371925F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_152", 1.25F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_153", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_154", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_155", 1.0625000000000009F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_156", 1.0624999999999991F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_157", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_158", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_159", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_160", 1.0624999999999982F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_161", 1.0625000000000018F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_162", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_163", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_164", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_165", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_166", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_167", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_168", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_169", 0.9254540268263204F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_170", 0.8363063967963836F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_171", 0.7268746434431003F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_172", 1.2348857801796007F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_173", 1.016022273473034F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_174", 0.7971587667664499F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_175", 0.5782952600598674F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_176", 0.6357133007585393F, 1.0F, 0.5194685072847782F);
        escalar(g0, "casco_ladod_177", 0.7492051453715491F, 1.0F, 0.6334744142129537F);
        escalar(g0, "casco_ladod_178", 0.862696989984555F, 1.0F, 0.7682086678553399F);
        escalar(g0, "casco_ladod_179", 0.9549077307707826F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_180", 0.9558835465996719F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_181", 0.9117658249371925F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_182", 1.25F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_183", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_184", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_185", 1.0625000000000009F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_186", 1.0624999999999991F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_187", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_188", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_189", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_190", 1.0624999999999982F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_191", 1.0625000000000018F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_192", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_193", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_194", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_195", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_196", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_197", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_198", 1.0625F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_199", 0.9254540268263204F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_200", 0.8363063967963836F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_201", 0.7268746434431003F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_202", 1.2348857801796007F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_203", 1.016022273473034F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_204", 0.7971587667664499F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_205", 0.5782952600598674F, 1.0F, 0.8352709660483856F);
        escalar(g0, "casco_ladod_206", 0.6483914392047423F, 1.0F, 0.5194685072847771F);
        escalar(g0, "casco_ladod_207", 0.7647006479169095F, 1.0F, 0.6334744142129523F);
        escalar(g0, "casco_ladod_208", 0.8810098566290716F, 1.0F, 0.7682086678553413F);
        escalar(g0, "casco_ladod_209", 0.9565355153688133F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_210", 0.9558835465996719F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_211", 0.9117658249371925F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_212", 1.25F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_213", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_214", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_215", 1.0625000000000009F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_216", 1.0624999999999991F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_217", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_218", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_219", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_220", 1.0624999999999982F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_221", 1.0625000000000018F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_222", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_223", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_224", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_225", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_226", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_227", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_228", 1.0625F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_229", 0.9254540268263204F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_230", 0.8363063967963836F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_231", 0.7268746434431003F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_232", 1.2348857801796007F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_233", 1.016022273473034F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_234", 0.7971587667664499F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_ladod_235", 0.5782952600598674F, 1.0F, 0.8352709660483839F);
        escalar(g0, "casco_arriba0_0", 0.5989276261364915F, 1.0F, 0.9457031249999999F);
        escalar(g0, "casco_arriba0_1", 0.8315460435608258F, 1.0F, 0.9423828125F);
        escalar(g0, "casco_arriba0_2", 1.0641644609851602F, 1.0F, 0.9368489583333333F);
        escalar(g0, "casco_arriba0_3", 0.6483914392047423F, 1.0F, 0.9291015624999999F);
        escalar(g0, "casco_arriba0_4", 0.7647006479169095F, 1.0F, 0.9191406249999998F);
        escalar(g0, "casco_arriba0_5", 0.8810098566290716F, 1.0F, 0.9069661458333331F);
        escalar(g0, "casco_arriba0_6", 0.9565355153688133F, 1.0F, 1.0200892857142858F);
        escalar(g0, "casco_arriba0_7", 0.9558835465996719F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_8", 0.9117658249371925F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_9", 1.25F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_10", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_11", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_12", 1.0625000000000009F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_13", 1.0624999999999991F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_14", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_15", 1.0625F, 1.0F, 1.0119047619047616F);
    }

    private static void escalas9(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "casco_arriba0_16", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_17", 1.0624999999999982F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_18", 1.0625000000000018F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_19", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_20", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_21", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_22", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_23", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_24", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_25", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_26", 0.9254540268263204F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_27", 0.8363063967963836F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_28", 0.7268746434431003F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_29", 1.2348857801796007F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_30", 1.016022273473034F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_31", 0.7971587667664499F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_32", 0.5782952600598674F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_33", 0.5938352167099776F, 1.0F, 0.9457031249999999F);
        escalar(g0, "casco_arriba0_34", 0.8230586945166358F, 1.0F, 0.9423828125F);
        escalar(g0, "casco_arriba0_35", 1.0522821723232942F, 1.0F, 0.9368489583333333F);
        escalar(g0, "casco_arriba0_36", 0.6407528250649713F, 1.0F, 0.9291015624999999F);
        escalar(g0, "casco_arriba0_37", 0.7553645639683005F, 1.0F, 0.919140625F);
        escalar(g0, "casco_arriba0_38", 0.869976302871625F, 1.0F, 0.9069661458333333F);
        escalar(g0, "casco_arriba0_39", 0.9561733684075643F, 1.0F, 1.0200892857142858F);
        escalar(g0, "casco_arriba0_40", 0.9558835465996719F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_41", 0.9117658249371925F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_42", 1.25F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_43", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_44", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_45", 1.0625000000000009F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_46", 1.0624999999999991F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_47", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_48", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_49", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_50", 1.0624999999999982F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_51", 1.0625000000000018F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_52", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_53", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_54", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_55", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_56", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_57", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_58", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_59", 0.9254540268263204F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_60", 0.8363063967963836F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_61", 0.7268746434431003F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_62", 1.2348857801796007F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_63", 1.016022273473034F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_64", 0.7971587667664499F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_65", 0.5782952600598674F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_66", 0.590743242091824F, 1.0F, 0.9457031250000001F);
        escalar(g0, "casco_arriba0_67", 0.8179054034863796F, 1.0F, 0.9423828125F);
        escalar(g0, "casco_arriba0_68", 1.0450675648809356F, 1.0F, 0.9368489583333335F);
        escalar(g0, "casco_arriba0_69", 0.6361148631377408F, 1.0F, 0.9291015625000001F);
        escalar(g0, "casco_arriba0_70", 0.7496959438350187F, 1.0F, 0.919140625F);
        escalar(g0, "casco_arriba0_71", 0.8632770245322917F, 1.0F, 0.9069661458333333F);
        escalar(g0, "casco_arriba0_72", 0.9559560107437765F, 1.0F, 1.0200892857142858F);
        escalar(g0, "casco_arriba0_73", 0.9558835465996719F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_74", 0.9117658249371925F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_75", 1.25F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_76", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_77", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_78", 1.0625000000000009F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_79", 1.0624999999999991F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_80", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_81", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_82", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_83", 1.0624999999999982F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_84", 1.0625000000000018F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_85", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_86", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_87", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_88", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_89", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_90", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_91", 1.0625F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_92", 0.9254540268263204F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_93", 0.8363063967963836F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_94", 0.7268746434431003F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_95", 1.2348857801796007F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_96", 1.016022273473034F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_97", 0.7971587667664499F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_98", 0.5782952600598674F, 1.0F, 1.011904761904762F);
        escalar(g0, "casco_arriba0_99", 0.5907432420918237F, 1.0F, 0.9457031249999996F);
        escalar(g0, "casco_arriba0_100", 0.81790540348638F, 1.0F, 0.9423828125F);
        escalar(g0, "casco_arriba0_101", 1.0450675648809356F, 1.0F, 0.936848958333333F);
        escalar(g0, "casco_arriba0_102", 0.6361148631377408F, 1.0F, 0.9291015624999996F);
        escalar(g0, "casco_arriba0_103", 0.7496959438350187F, 1.0F, 0.9191406249999998F);
        escalar(g0, "casco_arriba0_104", 0.8632770245322916F, 1.0F, 0.9069661458333331F);
        escalar(g0, "casco_arriba0_105", 0.9559560107437765F, 1.0F, 1.0200892857142858F);
        escalar(g0, "casco_arriba0_106", 0.9558835465996719F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_107", 0.9117658249371925F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_108", 1.25F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_109", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_110", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_111", 1.0625000000000009F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_112", 1.0624999999999991F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_113", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_114", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_115", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_116", 1.0624999999999982F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_117", 1.0625000000000018F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_118", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_119", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_120", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_121", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_122", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_123", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_124", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_125", 0.9254540268263204F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_126", 0.8363063967963836F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_127", 0.7268746434431003F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_128", 1.2348857801796007F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_129", 1.016022273473034F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_130", 0.7971587667664499F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_131", 0.5782952600598674F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_132", 0.593835216709977F, 1.0F, 0.9457031249999996F);
        escalar(g0, "casco_arriba0_133", 0.8230586945166367F, 1.0F, 0.9423828125F);
        escalar(g0, "casco_arriba0_134", 1.0522821723232942F, 1.0F, 0.936848958333333F);
        escalar(g0, "casco_arriba0_135", 0.6407528250649714F, 1.0F, 0.9291015624999996F);
        escalar(g0, "casco_arriba0_136", 0.7553645639683003F, 1.0F, 0.9191406249999994F);
        escalar(g0, "casco_arriba0_137", 0.8699763028716246F, 1.0F, 0.9069661458333331F);
        escalar(g0, "casco_arriba0_138", 0.9561733684075643F, 1.0F, 1.0200892857142858F);
        escalar(g0, "casco_arriba0_139", 0.9558835465996719F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_140", 0.9117658249371925F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_141", 1.25F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_142", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_143", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_144", 1.0625000000000009F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_145", 1.0624999999999991F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_146", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_147", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_148", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_149", 1.0624999999999982F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_150", 1.0625000000000018F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_151", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_152", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_153", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_154", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_155", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_156", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_157", 1.0625F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_158", 0.9254540268263204F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_159", 0.8363063967963836F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_160", 0.7268746434431003F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_161", 1.2348857801796007F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_162", 1.016022273473034F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_163", 0.7971587667664499F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_164", 0.5782952600598674F, 1.0F, 1.0119047619047616F);
        escalar(g0, "casco_arriba0_165", 0.5989276261364915F, 1.0F, 0.9457031250000005F);
    }

    private static void escalas10(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "casco_arriba0_166", 0.8315460435608258F, 1.0F, 0.9423828125F);
        escalar(g0, "casco_arriba0_167", 1.0641644609851602F, 1.0F, 0.9368489583333339F);
        escalar(g0, "casco_arriba0_168", 0.6483914392047423F, 1.0F, 0.9291015625000005F);
        escalar(g0, "casco_arriba0_169", 0.7647006479169095F, 1.0F, 0.9191406250000007F);
        escalar(g0, "casco_arriba0_170", 0.8810098566290716F, 1.0F, 0.9069661458333336F);
        escalar(g0, "casco_arriba0_171", 0.9565355153688133F, 1.0F, 1.0200892857142858F);
        escalar(g0, "casco_arriba0_172", 0.9558835465996719F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_173", 0.9117658249371925F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_174", 1.25F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_175", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_176", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_177", 1.0625000000000009F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_178", 1.0624999999999991F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_179", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_180", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_181", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_182", 1.0624999999999982F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_183", 1.0625000000000018F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_184", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_185", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_186", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_187", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_188", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_189", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_190", 1.0625F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_191", 0.9254540268263204F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_192", 0.8363063967963836F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_193", 0.7268746434431003F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_194", 1.2348857801796007F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_195", 1.016022273473034F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_196", 0.7971587667664499F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_arriba0_197", 0.5782952600598674F, 1.0F, 1.0119047619047623F);
        escalar(g0, "casco_trompa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "casco_cola", 1.0F, 0.5F, 0.5F);
        escalar(g0, "tapa_conductor", 0.25F, 0.8F, 0.25F);
        escalar(g0, "torreta_ladoi_0", 0.6450844341491269F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_1", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_2", 0.9389061911452495F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_3", 0.9715746157029443F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_4", 1.003495557477184F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_5", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_6", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_7", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_8", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_9", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_10", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_11", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_12", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_13", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_14", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_15", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_16", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_17", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_18", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_19", 1.0034955574771824F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_20", 0.9715746157029411F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_21", 0.9389061911452543F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_22", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_23", 0.6450844341491241F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_24", 0.6450844341491269F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_25", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_26", 0.9389061911452495F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_27", 0.9715746157029443F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_28", 1.003495557477184F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_29", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_30", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_31", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_32", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_33", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_34", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_35", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_36", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_37", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_38", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_39", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_40", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_41", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_42", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_43", 1.0034955574771824F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_44", 0.9715746157029411F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_45", 0.9389061911452543F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_46", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_47", 0.6450844341491241F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_48", 0.6450844341491269F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_49", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_50", 0.9389061911452495F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_51", 0.9715746157029443F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_52", 1.003495557477184F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_53", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_54", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_55", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_56", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_57", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_58", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_59", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_60", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_61", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_62", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_63", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_64", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_65", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_66", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_67", 1.0034955574771824F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_68", 0.9715746157029411F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_69", 0.9389061911452543F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_70", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_71", 0.6450844341491241F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_72", 0.6450844341491269F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_73", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_74", 0.9389061911452495F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_75", 0.9715746157029443F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_76", 1.003495557477184F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_77", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_78", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_79", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_80", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_81", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_82", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_83", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_84", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_85", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_86", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_87", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_88", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_89", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_90", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_91", 1.0034955574771824F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_92", 0.9715746157029411F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_93", 0.9389061911452543F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_94", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_95", 0.6450844341491241F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladoi_96", 0.6450844341491269F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_97", 0.8954612878381378F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_98", 0.9389061911452495F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_99", 0.9715746157029443F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_100", 1.003495557477184F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_101", 1.038039627711174F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_102", 0.9177501212499717F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_103", 0.8449768185641062F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_104", 0.8012796402873003F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_105", 0.7742371244333685F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_106", 0.7583205149392822F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_107", 0.750903634001117F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_108", 0.750903634001117F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_109", 0.7583205149392822F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_110", 0.7742371244333685F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_111", 0.8012796402873003F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_112", 0.8449768185641062F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_113", 0.9177501212499717F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_114", 1.038039627711174F, 1.0F, 0.7102709660483837F);
    }

    private static void escalas11(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "torreta_ladoi_115", 1.0034955574771824F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_116", 0.9715746157029411F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_117", 0.9389061911452543F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_118", 0.8954612878381378F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_119", 0.6450844341491241F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladoi_120", 0.6450844341491269F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladoi_121", 0.8954612878381378F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladoi_122", 0.9389061911452495F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladoi_123", 0.9715746157029443F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladoi_124", 1.003495557477184F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_125", 1.038039627711174F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_126", 0.9177501212499717F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_127", 0.8449768185641062F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_128", 0.8012796402873005F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_129", 0.7742371244333685F, 1.0F, 0.7102709660483866F);
        escalar(g0, "torreta_ladoi_130", 0.7583205149392822F, 1.0F, 0.7102709660483866F);
        escalar(g0, "torreta_ladoi_131", 0.750903634001117F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_132", 0.750903634001117F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_133", 0.7583205149392822F, 1.0F, 0.7102709660483866F);
        escalar(g0, "torreta_ladoi_134", 0.7742371244333685F, 1.0F, 0.7102709660483866F);
        escalar(g0, "torreta_ladoi_135", 0.8012796402873005F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_136", 0.8449768185641062F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_137", 0.9177501212499717F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_138", 1.038039627711174F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_139", 1.0034955574771824F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladoi_140", 0.9715746157029411F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladoi_141", 0.9389061911452543F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladoi_142", 0.8954612878381378F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladoi_143", 0.6450844341491241F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladoi_144", 0.6450844341491269F, 1.0F, 0.7102709660483835F);
        escalar(g0, "torreta_ladoi_145", 0.8954612878381379F, 1.0F, 0.7102709660483835F);
        escalar(g0, "torreta_ladoi_146", 0.9389061911452495F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_147", 0.9715746157029443F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_148", 1.003495557477184F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_149", 1.038039627711174F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_150", 0.9177501212499717F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_151", 0.8449768185641062F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_152", 0.8012796402873005F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladoi_153", 0.7742371244333685F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladoi_154", 0.7583205149392822F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladoi_155", 0.750903634001117F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladoi_156", 0.750903634001117F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladoi_157", 0.7583205149392822F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladoi_158", 0.7742371244333685F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladoi_159", 0.8012796402873005F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladoi_160", 0.8449768185641062F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_161", 0.9177501212499717F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_162", 1.038039627711174F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_163", 1.0034955574771824F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_164", 0.9715746157029411F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_165", 0.9389061911452543F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladoi_166", 0.8954612878381379F, 1.0F, 0.7102709660483835F);
        escalar(g0, "torreta_ladoi_167", 0.6450844341491241F, 1.0F, 0.7102709660483835F);
        escalar(g0, "torreta_ladoi_168", 0.6450844341491269F, 1.0F, 0.710270966048385F);
        escalar(g0, "torreta_ladoi_169", 0.8954612878381379F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladoi_170", 0.9389061911452495F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladoi_171", 0.9715746157029443F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladoi_172", 1.003495557477184F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladoi_173", 1.038039627711174F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladoi_174", 0.9177501212499717F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_175", 0.8449768185641062F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_176", 0.8012796402873003F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_177", 0.7742371244333685F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_178", 0.7583205149392822F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_179", 0.750903634001117F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_180", 0.750903634001117F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_181", 0.7583205149392822F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_182", 0.7742371244333685F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_183", 0.8012796402873003F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_184", 0.8449768185641062F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_185", 0.9177501212499717F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladoi_186", 1.038039627711174F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladoi_187", 1.0034955574771824F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladoi_188", 0.9715746157029411F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladoi_189", 0.9389061911452543F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladoi_190", 0.8954612878381379F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladoi_191", 0.6450844341491242F, 1.0F, 0.710270966048385F);
        escalar(g0, "torreta_ladod_0", 0.6450844341491269F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_1", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_2", 0.9389061911452495F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_3", 0.9715746157029443F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_4", 1.003495557477184F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_5", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_6", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_7", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_8", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_9", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_10", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_11", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_12", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_13", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_14", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_15", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_16", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_17", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_18", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_19", 1.0034955574771824F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_20", 0.9715746157029411F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_21", 0.9389061911452543F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_22", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_23", 0.6450844341491241F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_24", 0.6450844341491269F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_25", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_26", 0.9389061911452495F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_27", 0.9715746157029443F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_28", 1.003495557477184F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_29", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_30", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_31", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_32", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_33", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_34", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_35", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_36", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_37", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_38", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_39", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_40", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_41", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_42", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_43", 1.0034955574771824F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_44", 0.9715746157029411F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_45", 0.9389061911452543F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_46", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_47", 0.6450844341491241F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_48", 0.6450844341491269F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_49", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_50", 0.9389061911452495F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_51", 0.9715746157029443F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_52", 1.003495557477184F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_53", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_54", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_55", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_56", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_57", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_58", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_59", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_60", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_61", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_62", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_63", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_64", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_65", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_66", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_67", 1.0034955574771824F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_68", 0.9715746157029411F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_69", 0.9389061911452543F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_70", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_71", 0.6450844341491241F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_72", 0.6450844341491269F, 1.0F, 1.125F);
    }

    private static void escalas12(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "torreta_ladod_73", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_74", 0.9389061911452495F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_75", 0.9715746157029443F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_76", 1.003495557477184F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_77", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_78", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_79", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_80", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_81", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_82", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_83", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_84", 0.750903634001117F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_85", 0.7583205149392822F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_86", 0.7742371244333685F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_87", 0.8012796402873003F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_88", 0.8449768185641062F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_89", 0.9177501212499717F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_90", 1.038039627711174F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_91", 1.0034955574771824F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_92", 0.9715746157029411F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_93", 0.9389061911452543F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_94", 0.8954612878381378F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_95", 0.6450844341491241F, 1.0F, 1.125F);
        escalar(g0, "torreta_ladod_96", 0.6450844341491269F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_97", 0.8954612878381378F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_98", 0.9389061911452495F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_99", 0.9715746157029443F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_100", 1.003495557477184F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_101", 1.038039627711174F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_102", 0.9177501212499717F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_103", 0.8449768185641062F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_104", 0.8012796402873003F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_105", 0.7742371244333685F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_106", 0.7583205149392822F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_107", 0.750903634001117F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_108", 0.750903634001117F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_109", 0.7583205149392822F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_110", 0.7742371244333685F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_111", 0.8012796402873003F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_112", 0.8449768185641062F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_113", 0.9177501212499717F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_114", 1.038039627711174F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_115", 1.0034955574771824F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_116", 0.9715746157029411F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_117", 0.9389061911452543F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_118", 0.8954612878381378F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_119", 0.6450844341491241F, 1.0F, 0.7102709660483837F);
        escalar(g0, "torreta_ladod_120", 0.6450844341491269F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladod_121", 0.8954612878381378F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladod_122", 0.9389061911452495F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladod_123", 0.9715746157029443F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladod_124", 1.003495557477184F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_125", 1.038039627711174F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_126", 0.9177501212499717F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_127", 0.8449768185641062F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_128", 0.8012796402873005F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_129", 0.7742371244333685F, 1.0F, 0.7102709660483866F);
        escalar(g0, "torreta_ladod_130", 0.7583205149392822F, 1.0F, 0.7102709660483866F);
        escalar(g0, "torreta_ladod_131", 0.750903634001117F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_132", 0.750903634001117F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_133", 0.7583205149392822F, 1.0F, 0.7102709660483866F);
        escalar(g0, "torreta_ladod_134", 0.7742371244333685F, 1.0F, 0.7102709660483866F);
        escalar(g0, "torreta_ladod_135", 0.8012796402873005F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_136", 0.8449768185641062F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_137", 0.9177501212499717F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_138", 1.038039627711174F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_139", 1.0034955574771824F, 1.0F, 0.710270966048387F);
        escalar(g0, "torreta_ladod_140", 0.9715746157029411F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladod_141", 0.9389061911452543F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladod_142", 0.8954612878381378F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladod_143", 0.6450844341491241F, 1.0F, 0.7102709660483868F);
        escalar(g0, "torreta_ladod_144", 0.6450844341491269F, 1.0F, 0.7102709660483835F);
        escalar(g0, "torreta_ladod_145", 0.8954612878381379F, 1.0F, 0.7102709660483835F);
        escalar(g0, "torreta_ladod_146", 0.9389061911452495F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_147", 0.9715746157029443F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_148", 1.003495557477184F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_149", 1.038039627711174F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_150", 0.9177501212499717F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_151", 0.8449768185641062F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_152", 0.8012796402873005F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladod_153", 0.7742371244333685F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladod_154", 0.7583205149392822F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladod_155", 0.750903634001117F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladod_156", 0.750903634001117F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladod_157", 0.7583205149392822F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladod_158", 0.7742371244333685F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladod_159", 0.8012796402873005F, 1.0F, 0.7102709660483841F);
        escalar(g0, "torreta_ladod_160", 0.8449768185641062F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_161", 0.9177501212499717F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_162", 1.038039627711174F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_163", 1.0034955574771824F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_164", 0.9715746157029411F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_165", 0.9389061911452543F, 1.0F, 0.7102709660483834F);
        escalar(g0, "torreta_ladod_166", 0.8954612878381379F, 1.0F, 0.7102709660483835F);
        escalar(g0, "torreta_ladod_167", 0.6450844341491241F, 1.0F, 0.7102709660483835F);
        escalar(g0, "torreta_ladod_168", 0.6450844341491269F, 1.0F, 0.710270966048385F);
        escalar(g0, "torreta_ladod_169", 0.8954612878381379F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladod_170", 0.9389061911452495F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladod_171", 0.9715746157029443F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladod_172", 1.003495557477184F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladod_173", 1.038039627711174F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladod_174", 0.9177501212499717F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_175", 0.8449768185641062F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_176", 0.8012796402873003F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_177", 0.7742371244333685F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_178", 0.7583205149392822F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_179", 0.750903634001117F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_180", 0.750903634001117F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_181", 0.7583205149392822F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_182", 0.7742371244333685F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_183", 0.8012796402873003F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_184", 0.8449768185641062F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_185", 0.9177501212499717F, 1.0F, 0.7102709660483848F);
        escalar(g0, "torreta_ladod_186", 1.038039627711174F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladod_187", 1.0034955574771824F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladod_188", 0.9715746157029411F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladod_189", 0.9389061911452543F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladod_190", 0.8954612878381379F, 1.0F, 0.7102709660483852F);
        escalar(g0, "torreta_ladod_191", 0.6450844341491242F, 1.0F, 0.710270966048385F);
        escalar(g0, "torreta_arriba0_0", 0.6450844341491269F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_arriba0_1", 0.8954612878381378F, 1.0F, 0.9395772489817729F);
        escalar(g0, "torreta_arriba0_2", 0.9389061911452495F, 1.0F, 0.714724735885168F);
        escalar(g0, "torreta_arriba0_3", 0.9715746157029443F, 1.0F, 0.953747882126649F);
        escalar(g0, "torreta_arriba0_4", 1.003495557477184F, 1.0F, 0.7880589196408385F);
        escalar(g0, "torreta_arriba0_5", 1.038039627711174F, 1.0F, 0.9305484881168914F);
        escalar(g0, "torreta_arriba0_6", 0.9177501212499717F, 1.0F, 0.8233622856520235F);
        escalar(g0, "torreta_arriba0_7", 0.8449768185641062F, 1.0F, 0.9154411764705881F);
        escalar(g0, "torreta_arriba0_8", 0.8012796402873003F, 1.0F, 0.9820568912196224F);
        escalar(g0, "torreta_arriba0_9", 0.7742371244333685F, 1.0F, 1.027405267783699F);
        escalar(g0, "torreta_arriba0_10", 0.7583205149392822F, 1.0F, 1.0538193394216273F);
        escalar(g0, "torreta_arriba0_11", 0.750903634001117F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_12", 0.750903634001117F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_13", 0.7583205149392822F, 1.0F, 1.0538193394216273F);
        escalar(g0, "torreta_arriba0_14", 0.7742371244333685F, 1.0F, 1.027405267783699F);
        escalar(g0, "torreta_arriba0_15", 0.8012796402873003F, 1.0F, 0.9820568912196224F);
        escalar(g0, "torreta_arriba0_16", 0.8449768185641062F, 1.0F, 0.9154411764705881F);
        escalar(g0, "torreta_arriba0_17", 0.9177501212499717F, 1.0F, 0.8233622856520235F);
        escalar(g0, "torreta_arriba0_18", 1.038039627711174F, 1.0F, 0.9305484881168914F);
        escalar(g0, "torreta_arriba0_19", 1.0034955574771824F, 1.0F, 0.7880589196408385F);
        escalar(g0, "torreta_arriba0_20", 0.9715746157029411F, 1.0F, 0.9537478821266494F);
        escalar(g0, "torreta_arriba0_21", 0.9389061911452543F, 1.0F, 0.7147247358851696F);
        escalar(g0, "torreta_arriba0_22", 0.8954612878381378F, 1.0F, 0.9395772489817729F);
        escalar(g0, "torreta_arriba0_23", 0.6450844341491241F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_arriba0_24", 0.5955055620114682F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_arriba0_25", 0.6713965170123258F, 1.0F, 0.9395772489817729F);
        escalar(g0, "torreta_arriba0_26", 0.7270587966800317F, 1.0F, 0.714724735885168F);
        escalar(g0, "torreta_arriba0_27", 0.7815274234612792F, 1.0F, 0.9537478821266492F);
        escalar(g0, "torreta_arriba0_28", 0.8398828791431964F, 1.0F, 0.7880589196408385F);
        escalar(g0, "torreta_arriba0_29", 0.9029649697257756F, 1.0F, 0.9305484881168917F);
        escalar(g0, "torreta_arriba0_30", 0.8292278541791805F, 1.0F, 0.8233622856520235F);
    }

    private static void escalas13(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "torreta_arriba0_31", 0.7937811902517811F, 1.0F, 0.9154411764705881F);
        escalar(g0, "torreta_arriba0_32", 0.7732616565748439F, 1.0F, 0.9820568912196224F);
        escalar(g0, "torreta_arriba0_33", 0.7608791018938069F, 1.0F, 1.027405267783699F);
        escalar(g0, "torreta_arriba0_34", 0.7537107563448114F, 1.0F, 1.0538193394216273F);
        escalar(g0, "torreta_arriba0_35", 0.75040176623433F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_36", 0.75040176623433F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_37", 0.7537107563448114F, 1.0F, 1.0538193394216273F);
        escalar(g0, "torreta_arriba0_38", 0.7608791018938069F, 1.0F, 1.027405267783699F);
        escalar(g0, "torreta_arriba0_39", 0.7732616565748439F, 1.0F, 0.9820568912196224F);
        escalar(g0, "torreta_arriba0_40", 0.7937811902517811F, 1.0F, 0.9154411764705881F);
        escalar(g0, "torreta_arriba0_41", 0.8292278541791805F, 1.0F, 0.8233622856520235F);
        escalar(g0, "torreta_arriba0_42", 0.9029649697257756F, 1.0F, 0.9305484881168917F);
        escalar(g0, "torreta_arriba0_43", 0.839882879143195F, 1.0F, 0.7880589196408385F);
        escalar(g0, "torreta_arriba0_44", 0.7815274234612771F, 1.0F, 0.9537478821266496F);
        escalar(g0, "torreta_arriba0_45", 0.727058796680035F, 1.0F, 0.7147247358851696F);
        escalar(g0, "torreta_arriba0_46", 0.6713965170123258F, 1.0F, 0.9395772489817729F);
        escalar(g0, "torreta_arriba0_47", 0.5955055620114652F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_arriba0_48", 0.5619992361292179F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_arriba0_49", 0.9471722554743561F, 1.0F, 0.9395772489817729F);
        escalar(g0, "torreta_arriba0_50", 1.1043856240947685F, 1.0F, 0.7147247358851683F);
        escalar(g0, "torreta_arriba0_51", 0.6345410331260639F, 1.0F, 0.9537478821266492F);
        escalar(g0, "torreta_arriba0_52", 0.7205160642023155F, 1.0F, 0.7880589196408389F);
        escalar(g0, "torreta_arriba0_53", 0.8092385355489027F, 1.0F, 0.9305484881168917F);
        escalar(g0, "torreta_arriba0_54", 0.7706636705004755F, 1.0F, 0.8233622856520237F);
        escalar(g0, "torreta_arriba0_55", 0.7612104406937582F, 1.0F, 0.9154411764705883F);
        escalar(g0, "torreta_arriba0_56", 0.7558908447299751F, 1.0F, 0.9820568912196226F);
        escalar(g0, "torreta_arriba0_57", 0.7527363512955203F, 1.0F, 1.0274052677836991F);
        escalar(g0, "torreta_arriba0_58", 0.75092962275847F, 1.0F, 1.0538193394216275F);
        escalar(g0, "torreta_arriba0_59", 0.7501004642543028F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_60", 0.7501004642543028F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_61", 0.75092962275847F, 1.0F, 1.0538193394216275F);
        escalar(g0, "torreta_arriba0_62", 0.7527363512955203F, 1.0F, 1.0274052677836991F);
        escalar(g0, "torreta_arriba0_63", 0.7558908447299751F, 1.0F, 0.9820568912196226F);
        escalar(g0, "torreta_arriba0_64", 0.7612104406937582F, 1.0F, 0.9154411764705883F);
        escalar(g0, "torreta_arriba0_65", 0.7706636705004755F, 1.0F, 0.8233622856520237F);
        escalar(g0, "torreta_arriba0_66", 0.8092385355489027F, 1.0F, 0.9305484881168917F);
        escalar(g0, "torreta_arriba0_67", 0.7205160642023145F, 1.0F, 0.7880589196408389F);
        escalar(g0, "torreta_arriba0_68", 0.6345410331260627F, 1.0F, 0.9537478821266496F);
        escalar(g0, "torreta_arriba0_69", 1.104385624094773F, 1.0F, 0.7147247358851696F);
        escalar(g0, "torreta_arriba0_70", 0.9471722554743561F, 1.0F, 0.9395772489817729F);
        escalar(g0, "torreta_arriba0_71", 0.5619992361292144F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_arriba0_72", 0.5619992361292179F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_arriba0_73", 0.9471722554743561F, 1.0F, 0.9395772489817729F);
        escalar(g0, "torreta_arriba0_74", 1.104385624094768F, 1.0F, 0.7147247358851678F);
        escalar(g0, "torreta_arriba0_75", 0.634541033126064F, 1.0F, 0.953747882126649F);
        escalar(g0, "torreta_arriba0_76", 0.7205160642023153F, 1.0F, 0.7880589196408382F);
        escalar(g0, "torreta_arriba0_77", 0.8092385355489028F, 1.0F, 0.9305484881168914F);
        escalar(g0, "torreta_arriba0_78", 0.7706636705004755F, 1.0F, 0.8233622856520233F);
        escalar(g0, "torreta_arriba0_79", 0.7612104406937582F, 1.0F, 0.9154411764705879F);
        escalar(g0, "torreta_arriba0_80", 0.7558908447299751F, 1.0F, 0.9820568912196221F);
        escalar(g0, "torreta_arriba0_81", 0.7527363512955203F, 1.0F, 1.0274052677836987F);
        escalar(g0, "torreta_arriba0_82", 0.75092962275847F, 1.0F, 1.053819339421627F);
        escalar(g0, "torreta_arriba0_83", 0.7501004642543028F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_84", 0.7501004642543028F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_85", 0.75092962275847F, 1.0F, 1.053819339421627F);
        escalar(g0, "torreta_arriba0_86", 0.7527363512955203F, 1.0F, 1.0274052677836987F);
        escalar(g0, "torreta_arriba0_87", 0.7558908447299751F, 1.0F, 0.9820568912196221F);
        escalar(g0, "torreta_arriba0_88", 0.7612104406937582F, 1.0F, 0.9154411764705879F);
        escalar(g0, "torreta_arriba0_89", 0.7706636705004755F, 1.0F, 0.8233622856520233F);
        escalar(g0, "torreta_arriba0_90", 0.8092385355489028F, 1.0F, 0.9305484881168914F);
        escalar(g0, "torreta_arriba0_91", 0.7205160642023143F, 1.0F, 0.7880589196408382F);
        escalar(g0, "torreta_arriba0_92", 0.6345410331260626F, 1.0F, 0.9537478821266494F);
        escalar(g0, "torreta_arriba0_93", 1.104385624094773F, 1.0F, 0.7147247358851696F);
        escalar(g0, "torreta_arriba0_94", 0.9471722554743561F, 1.0F, 0.9395772489817729F);
        escalar(g0, "torreta_arriba0_95", 0.5619992361292145F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_arriba0_96", 0.5955055620114683F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_arriba0_97", 0.6713965170123256F, 1.0F, 0.9395772489817724F);
        escalar(g0, "torreta_arriba0_98", 0.7270587966800317F, 1.0F, 0.7147247358851683F);
        escalar(g0, "torreta_arriba0_99", 0.7815274234612788F, 1.0F, 0.9537478821266485F);
        escalar(g0, "torreta_arriba0_100", 0.8398828791431966F, 1.0F, 0.7880589196408389F);
        escalar(g0, "torreta_arriba0_101", 0.9029649697257753F, 1.0F, 0.9305484881168914F);
        escalar(g0, "torreta_arriba0_102", 0.8292278541791805F, 1.0F, 0.8233622856520237F);
        escalar(g0, "torreta_arriba0_103", 0.793781190251781F, 1.0F, 0.9154411764705879F);
        escalar(g0, "torreta_arriba0_104", 0.773261656574844F, 1.0F, 0.9820568912196226F);
        escalar(g0, "torreta_arriba0_105", 0.7608791018938069F, 1.0F, 1.0274052677836991F);
        escalar(g0, "torreta_arriba0_106", 0.7537107563448114F, 1.0F, 1.0538193394216275F);
        escalar(g0, "torreta_arriba0_107", 0.75040176623433F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_108", 0.75040176623433F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_109", 0.7537107563448114F, 1.0F, 1.0538193394216275F);
        escalar(g0, "torreta_arriba0_110", 0.7608791018938069F, 1.0F, 1.0274052677836991F);
        escalar(g0, "torreta_arriba0_111", 0.773261656574844F, 1.0F, 0.9820568912196226F);
        escalar(g0, "torreta_arriba0_112", 0.793781190251781F, 1.0F, 0.9154411764705879F);
        escalar(g0, "torreta_arriba0_113", 0.8292278541791805F, 1.0F, 0.8233622856520237F);
        escalar(g0, "torreta_arriba0_114", 0.9029649697257753F, 1.0F, 0.9305484881168914F);
        escalar(g0, "torreta_arriba0_115", 0.839882879143195F, 1.0F, 0.7880589196408389F);
        escalar(g0, "torreta_arriba0_116", 0.7815274234612771F, 1.0F, 0.9537478821266494F);
        escalar(g0, "torreta_arriba0_117", 0.7270587966800349F, 1.0F, 0.7147247358851692F);
        escalar(g0, "torreta_arriba0_118", 0.6713965170123256F, 1.0F, 0.9395772489817724F);
        escalar(g0, "torreta_arriba0_119", 0.5955055620114652F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_arriba0_120", 0.6450844341491269F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_arriba0_121", 0.8954612878381378F, 1.0F, 0.9395772489817733F);
        escalar(g0, "torreta_arriba0_122", 0.9389061911452495F, 1.0F, 0.7147247358851683F);
        escalar(g0, "torreta_arriba0_123", 0.9715746157029443F, 1.0F, 0.9537478821266498F);
        escalar(g0, "torreta_arriba0_124", 1.003495557477184F, 1.0F, 0.7880589196408389F);
        escalar(g0, "torreta_arriba0_125", 1.038039627711174F, 1.0F, 0.9305484881168921F);
        escalar(g0, "torreta_arriba0_126", 0.9177501212499717F, 1.0F, 0.8233622856520237F);
        escalar(g0, "torreta_arriba0_127", 0.8449768185641062F, 1.0F, 0.9154411764705888F);
        escalar(g0, "torreta_arriba0_128", 0.8012796402873003F, 1.0F, 0.9820568912196226F);
        escalar(g0, "torreta_arriba0_129", 0.7742371244333685F, 1.0F, 1.0274052677836991F);
        escalar(g0, "torreta_arriba0_130", 0.7583205149392822F, 1.0F, 1.0538193394216275F);
        escalar(g0, "torreta_arriba0_131", 0.750903634001117F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_132", 0.750903634001117F, 1.0F, 1.0625F);
        escalar(g0, "torreta_arriba0_133", 0.7583205149392822F, 1.0F, 1.0538193394216275F);
        escalar(g0, "torreta_arriba0_134", 0.7742371244333685F, 1.0F, 1.0274052677836991F);
        escalar(g0, "torreta_arriba0_135", 0.8012796402873003F, 1.0F, 0.9820568912196226F);
        escalar(g0, "torreta_arriba0_136", 0.8449768185641062F, 1.0F, 0.9154411764705888F);
        escalar(g0, "torreta_arriba0_137", 0.9177501212499717F, 1.0F, 0.8233622856520237F);
        escalar(g0, "torreta_arriba0_138", 1.038039627711174F, 1.0F, 0.9305484881168921F);
        escalar(g0, "torreta_arriba0_139", 1.0034955574771824F, 1.0F, 0.7880589196408389F);
        escalar(g0, "torreta_arriba0_140", 0.9715746157029411F, 1.0F, 0.9537478821266498F);
        escalar(g0, "torreta_arriba0_141", 0.9389061911452543F, 1.0F, 0.71472473588517F);
        escalar(g0, "torreta_arriba0_142", 0.8954612878381378F, 1.0F, 0.9395772489817733F);
        escalar(g0, "torreta_arriba0_143", 0.6450844341491241F, 1.0F, 0.45372834880477253F);
        escalar(g0, "torreta_trompa", 1.0F, 0.5F, 0.5F);
        escalar(g0, "torreta_cola", 1.0F, 0.5F, 0.5F);
        escalar(g0, "torreta_tapa_i", 0.25F, 0.8F, 0.25F);
        escalar(g0, "torreta_tapa_d", 0.25F, 0.8F, 0.25F);
        escalar(g0, "torreta_canon_0", 0.5F, 1.0F, 0.3364647586332763F);
        escalar(g0, "torreta_canon_1", 0.5F, 1.0F, 0.3364647586332778F);
        escalar(g0, "torreta_canon_2", 0.5F, 1.0F, 0.3364647586332765F);
        escalar(g0, "torreta_canon_3", 0.5F, 1.0F, 0.3364647586332764F);
        escalar(g0, "torreta_canon_4", 0.5F, 1.0F, 0.33646475863327663F);
        escalar(g0, "torreta_canon_5", 0.5F, 1.0F, 0.33646475863327807F);
        escalar(g0, "torreta_canon_6", 0.5F, 1.0F, 0.33646475863327624F);
        escalar(g0, "torreta_canon_7", 0.5F, 1.0F, 0.3364647586332778F);
        escalar(g0, "torreta_canon_8", 0.5F, 1.0F, 0.33646475863327713F);
        escalar(g0, "torreta_canon_9", 0.5F, 1.0F, 0.33646475863327663F);
        escalar(g0, "torreta_canon_10", 0.5F, 1.0F, 0.3364647586332768F);
        escalar(g0, "torreta_canon_11", 0.5F, 1.0F, 0.33646475863327807F);
        escalar(g0, "torreta_canon_ta", 0.23636363636363636F, 0.6F, 0.23636363636363636F);
        escalar(g0, "torreta_canon_tb", 0.23636363636363636F, 0.6F, 0.23636363636363636F);
        escalar(g0, "torreta_evacuador_0", 0.5F, 1.0F, 0.49175618569478907F);
        escalar(g0, "torreta_evacuador_1", 0.5F, 1.0F, 0.491756185694789F);
        escalar(g0, "torreta_evacuador_2", 0.5F, 1.0F, 0.4917561856947895F);
        escalar(g0, "torreta_evacuador_3", 0.5F, 1.0F, 0.49175618569478935F);
        escalar(g0, "torreta_evacuador_4", 0.5F, 1.0F, 0.4917561856947891F);
        escalar(g0, "torreta_evacuador_5", 0.5F, 1.0F, 0.4917561856947891F);
        escalar(g0, "torreta_evacuador_6", 0.5F, 1.0F, 0.491756185694789F);
        escalar(g0, "torreta_evacuador_7", 0.5F, 1.0F, 0.49175618569478896F);
        escalar(g0, "torreta_evacuador_8", 0.5F, 1.0F, 0.49175618569478974F);
        escalar(g0, "torreta_evacuador_9", 0.5F, 1.0F, 0.4917561856947886F);
        escalar(g0, "torreta_evacuador_10", 0.5F, 1.0F, 0.49175618569479057F);
        escalar(g0, "torreta_evacuador_11", 0.5F, 1.0F, 0.4917561856947892F);
        escalar(g0, "torreta_evacuador_ta", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "torreta_evacuador_tb", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "torreta_boca_0", 0.5F, 1.0F, 0.49175618569478907F);
        escalar(g0, "torreta_boca_1", 0.5F, 1.0F, 0.491756185694789F);
        escalar(g0, "torreta_boca_2", 0.5F, 1.0F, 0.4917561856947895F);
        escalar(g0, "torreta_boca_3", 0.5F, 1.0F, 0.49175618569478935F);
        escalar(g0, "torreta_boca_4", 0.5F, 1.0F, 0.4917561856947891F);
    }

    private static void escalas14(ModelPart g0, ModelPart g1, ModelPart g2) {
        escalar(g0, "torreta_boca_5", 0.5F, 1.0F, 0.4917561856947891F);
        escalar(g0, "torreta_boca_6", 0.5F, 1.0F, 0.491756185694789F);
        escalar(g0, "torreta_boca_7", 0.5F, 1.0F, 0.49175618569478896F);
        escalar(g0, "torreta_boca_8", 0.5F, 1.0F, 0.49175618569478974F);
        escalar(g0, "torreta_boca_9", 0.5F, 1.0F, 0.4917561856947886F);
        escalar(g0, "torreta_boca_10", 0.5F, 1.0F, 0.49175618569479057F);
        escalar(g0, "torreta_boca_11", 0.5F, 1.0F, 0.4917561856947892F);
        escalar(g0, "torreta_boca_ta", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "torreta_boca_tb", 0.2375F, 0.6F, 0.2375F);
        escalar(g0, "torreta_antena", 0.4F, 0.9669275979057774F, 0.4F);
        escalar(g0, "faro_i_0", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_i_1", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_i_2", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_i_3", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_i_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "escape_i_0", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_i_1", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_i_2", 0.5F, 1.0F, 0.4635254915624216F);
        escalar(g0, "escape_i_3", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_i_4", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_i_5", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_i_6", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_i_7", 0.5F, 1.0F, 0.4635254915624216F);
        escalar(g0, "escape_i_8", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_i_9", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_i_ta", 0.25F, 0.6F, 0.25F);
        escalar(g0, "escape_i_tb", 0.25F, 0.6F, 0.25F);
        escalar(g0, "faro_d_0", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_d_1", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_d_2", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_d_3", 0.2942355841209691F, 0.7F, 0.2942355841209691F);
        escalar(g0, "faro_d_vidrio", 0.25F, 0.15F, 0.25F);
        escalar(g0, "escape_d_0", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_d_1", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_d_2", 0.5F, 1.0F, 0.4635254915624216F);
        escalar(g0, "escape_d_3", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_d_4", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_d_5", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_d_6", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_d_7", 0.5F, 1.0F, 0.4635254915624216F);
        escalar(g0, "escape_d_8", 0.5F, 1.0F, 0.46352549156242157F);
        escalar(g0, "escape_d_9", 0.5F, 1.0F, 0.4635254915624204F);
        escalar(g0, "escape_d_ta", 0.25F, 0.6F, 0.25F);
        escalar(g0, "escape_d_tb", 0.25F, 0.6F, 0.25F);
    }
}
