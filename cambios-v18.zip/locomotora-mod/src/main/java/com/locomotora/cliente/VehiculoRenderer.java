package com.locomotora.cliente;

import java.util.ArrayList;
import java.util.List;

import org.jetbrains.annotations.Nullable;

import com.locomotora.cliente.modelos.DatosModelo;
import com.locomotora.vehiculo.VehiculoEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Dibuja un vehículo de calle (modelo del estudio de diseño, frente hacia -X, suelo en Y = 0).
 * <ul>
 *   <li>Las ruedas giran según lo que anduvo; las de adelante además doblan, cada una alrededor de su propio eje
 *       vertical.</li>
 *   <li>La torreta del tanque y del camión blindado gira hacia donde apunta el tirador, y el caño del tanque sube y
 *       baja en su muñón.</li>
 *   <li>Lo que brilla de noche (faros, luces de cola, balizas, el cartel del autobús) está en
 *       {@code <nombre>_luces.png} y se dibuja encima sin sombra.</li>
 *   <li>Cuando le pegan se sacude, como un bote.</li>
 * </ul>
 */
public class VehiculoRenderer extends EntityRenderer<VehiculoEntity> {
    private static final double DOS_PI = Math.PI * 2.0;
    /** Luz de bloque y de cielo al máximo (LightTexture.FULL_BRIGHT). */
    private static final int BRILLO_TOTAL = 0xF000F0;

    private final DatosModelo datos;
    private final ModelPart raiz;
    /** Las piezas de las ruedas (giran en Z alrededor de su pivote). */
    private final List<Pieza> ruedas = new ArrayList<>();
    /** Las piezas que se dibujan aparte con su propio giro: ruedas que doblan, torreta y caño. */
    private final List<Pieza> aparte = new ArrayList<>();
    @Nullable
    private final ResourceLocation texturaLuces;

    /** Una pieza animada del modelo con sus datos. */
    private record Pieza(ModelPart parte, DatosModelo.Animada a) {
    }

    public VehiculoRenderer(EntityRendererProvider.Context contexto, DatosModelo datos, float sombra) {
        super(contexto);
        this.datos = datos;
        this.shadowRadius = sombra;
        this.raiz = contexto.bakeLayer(datos.capa());
        datos.preparar().accept(this.raiz);
        for (DatosModelo.Animada a : datos.animadas()) {
            ModelPart parte = a.grupo().isEmpty()
                    ? this.raiz.getChild(a.parte())
                    : this.raiz.getChild(a.grupo()).getChild(a.parte());
            Pieza p = new Pieza(parte, a);
            switch (a.tipo()) {
                case DatosModelo.RUEDA -> this.ruedas.add(p);
                case DatosModelo.RUEDA_DOBLA -> {
                    this.ruedas.add(p);
                    this.aparte.add(p);
                    parte.visible = false;
                }
                case DatosModelo.TORRETA, DatosModelo.CANON -> {
                    this.aparte.add(p);
                    parte.visible = false;
                }
                default -> {
                }
            }
        }
        ResourceLocation t = datos.textura();
        ResourceLocation luces = ResourceLocation.fromNamespaceAndPath(t.getNamespace(),
                t.getPath().replace(".png", "_luces.png"));
        this.texturaLuces = contexto.getResourceManager().getResource(luces).isPresent() ? luces : null;
    }

    @Override
    public void render(VehiculoEntity v, float yawEntidad, float tickParcial, PoseStack pose,
                       MultiBufferSource buffers, int luz) {
        super.render(v, yawEntidad, tickParcial, pose, buffers, luz);
        pose.pushPose();
        float rumbo = Mth.rotLerp(tickParcial, v.yRotO, v.getYRot());
        // el frente del modelo (-X) queda hacia el frente del vehículo, (-sin, cos) en el mundo
        pose.mulPose(Axis.YP.rotationDegrees(-(rumbo + 90.0F)));
        // sacudón cuando le pegan
        float golpe = v.getHurtTime() - tickParcial;
        float dano = Math.max(0.0F, v.getDamage() - tickParcial);
        if (golpe > 0.0F) {
            pose.mulPose(Axis.XP.rotationDegrees(Mth.sin(golpe) * golpe * dano / 20.0F * v.getHurtDir()));
        }
        pose.scale(-1.0F, -1.0F, 1.0F);

        // las ruedas giran (misma cuenta que las del tren: la distancia recorrida sobre el radio)
        double recorrido = v.getRecorrido(tickParcial) * this.datos.unidades();
        for (Pieza p : this.ruedas) {
            double vueltas = (recorrido / p.a().radio()) % DOS_PI;
            p.parte().zRot = p.a().rotZ() - (float) vueltas + p.a().fase();
        }
        float direccion = v.getDireccion(tickParcial);
        float giro = v.giroTorreta(tickParcial);
        float alza = v.alzaTorreta(tickParcial);
        pintar(pose, buffers.getBuffer(RenderType.entityCutout(this.datos.textura())), luz, direccion, giro, alza);
        if (this.texturaLuces != null) {
            pintar(pose, buffers.getBuffer(RenderType.entityTranslucentEmissive(this.texturaLuces)), BRILLO_TOTAL,
                    direccion, giro, alza);
        }
        pose.popPose();
    }

    /**
     * El modelo entero y después, cada una con su giro, las piezas que se dibujan aparte. Los giros se hacen en las
     * coordenadas del modelo (la Z hacia la derecha del que maneja): un giro en Y positivo lleva el frente hacia la
     * derecha, y uno en Z positivo levanta la boca del caño.
     */
    private void pintar(PoseStack pose, VertexConsumer buffer, int luz, float direccion, float giro, float alza) {
        this.raiz.render(pose, buffer, luz, OverlayTexture.NO_OVERLAY);
        for (Pieza p : this.aparte) {
            DatosModelo.Animada a = p.a();
            pose.pushPose();
            switch (a.tipo()) {
                case DatosModelo.RUEDA_DOBLA -> girarEnY(pose, a.x(), a.z(), direccion);
                case DatosModelo.TORRETA -> girarEnY(pose, a.x(), a.z(), giro);
                case DatosModelo.CANON -> {
                    girarEnY(pose, a.x(), a.z(), giro);
                    // el muñón: x en manivela, y en y (coordenadas del modelo, Y hacia abajo)
                    pose.translate(a.manivela() / 16.0F, a.y() / 16.0F, 0.0F);
                    pose.mulPose(Axis.ZP.rotation(alza));
                    pose.translate(-a.manivela() / 16.0F, -a.y() / 16.0F, 0.0F);
                }
                default -> {
                }
            }
            p.parte().visible = true;
            p.parte().render(pose, buffer, luz, OverlayTexture.NO_OVERLAY);
            p.parte().visible = false;
            pose.popPose();
        }
    }

    /** Gira lo que sigue alrededor de un eje vertical que pasa por (x, z) del modelo. */
    private static void girarEnY(PoseStack pose, float x, float z, float angulo) {
        pose.translate(x / 16.0F, 0.0F, z / 16.0F);
        pose.mulPose(Axis.YP.rotation(angulo));
        pose.translate(-x / 16.0F, 0.0F, -z / 16.0F);
    }

    @Override
    public ResourceLocation getTextureLocation(VehiculoEntity v) {
        return this.datos.textura();
    }
}
