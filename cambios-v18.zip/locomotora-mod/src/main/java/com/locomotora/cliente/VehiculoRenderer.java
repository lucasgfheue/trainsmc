package com.locomotora.cliente;

import java.util.ArrayList;
import java.util.List;

import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;

import com.locomotora.cliente.modelos.DatosModelo;
import com.locomotora.vehiculo.TipoVehiculo;
import com.locomotora.vehiculo.VehiculoEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Dibuja un vehículo de calle (modelo del estudio de diseño, frente hacia -X, suelo en Y = 0).
 * <ul>
 *   <li>Las ruedas giran según lo que anduvo; las de adelante de autos y camiones además doblan, cada una alrededor de
 *       su propio eje vertical.</li>
 *   <li>El volante gira sobre su columna cuando dobla y, en las motos, la rueda de adelante dobla con la horquilla, el
 *       faro y el manubrio alrededor del eje de dirección.</li>
 *   <li>Los eslabones de las orugas corren alrededor de las ruedas (al doblar en el lugar, una oruga va para adelante y
 *       la otra para atrás).</li>
 *   <li>Se inclina sobre las ruedas cuando sube o baja un escalón (el vehículo dice cómo quedó apoyado).</li>
 *   <li>La torreta del tanque y del camión blindado gira hacia donde apunta el tirador, y el caño del tanque sube y
 *       baja en su muñón.</li>
 *   <li>Lo que brilla de noche (faros, luces de cola, balizas, el cartel del autobús) está en
 *       {@code <nombre>_luces.png} y se dibuja encima sin sombra.</li>
 *   <li>Cuando le pegan se sacude, como un bote.</li>
 * </ul>
 */
public class VehiculoRenderer extends EntityRenderer<VehiculoEntity> {
    private static final double DOS_PI = Math.PI * 2.0;
    /** Luz de bloque y de cielo al máximo (LightTexture.FULL_BRIGHT). */
    private static final int BRILLO_TOTAL = 0xF000F0;

    private final DatosModelo datos;
    private final ModelPart raiz;
    /** Las piezas de las ruedas (giran en Z alrededor de su pivote). */
    private final List<Pieza> ruedas = new ArrayList<>();
    /** Las piezas que se dibujan aparte con su propio giro: ruedas que doblan, volante, horquilla, torreta y caño. */
    private final List<Pieza> aparte = new ArrayList<>();
    /** Los eslabones de las orugas (se mueven por el lazo y se dibujan con el resto). */
    private final List<Pieza> eslabones = new ArrayList<>();
    @Nullable
    private final ResourceLocation texturaLuces;
    /** El lazo de las orugas: puntos (x, y del diseño, en unidades del modelo) y el largo hasta cada uno. */
    @Nullable
    private final float[] lazo;
    @Nullable
    private final double[] lazoLargo;
    private final double lazoTotal;
    private final Quaternionf giroEje = new Quaternionf();

    /** Una pieza animada del modelo con sus datos. */
    private record Pieza(ModelPart parte, DatosModelo.Animada a) {
    }

    public VehiculoRenderer(EntityRendererProvider.Context contexto, DatosModelo datos, float sombra, TipoVehiculo tipo) {
        super(contexto);
        this.datos = datos;
        this.shadowRadius = sombra;
        this.raiz = contexto.bakeLayer(datos.capa());
        datos.preparar().accept(this.raiz);
        for (DatosModelo.Animada a : datos.animadas()) {
            ModelPart parte = a.grupo().isEmpty()
                    ? this.raiz.getChild(a.parte())
                    : this.raiz.getChild(a.grupo()).getChild(a.parte());
            Pieza p = new Pieza(parte, a);
            switch (a.tipo()) {
                case DatosModelo.RUEDA -> this.ruedas.add(p);
                case DatosModelo.RUEDA_DOBLA -> {
                    this.ruedas.add(p);
                    this.aparte.add(p);
                    parte.visible = false;
                }
                case DatosModelo.TORRETA, DatosModelo.CANON, DatosModelo.GIRA_EJE -> {
                    this.aparte.add(p);
                    parte.visible = false;
                }
                case DatosModelo.ESLABON -> this.eslabones.add(p);
                default -> {
                }
            }
        }
        ResourceLocation t = datos.textura();
        ResourceLocation luces = ResourceLocation.fromNamespaceAndPath(t.getNamespace(),
                t.getPath().replace(".png", "_luces.png"));
        this.texturaLuces = contexto.getResourceManager().getResource(luces).isPresent() ? luces : null;

        // el lazo de las orugas, con el largo acumulado hasta cada punto (el último tramo cierra la vuelta)
        float[] l = this.eslabones.isEmpty() ? null : tipo.lazoOruga();
        if (l != null && l.length >= 6) {
            int n = l.length / 2;
            double[] largo = new double[n + 1];
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                largo[i + 1] = largo[i] + Math.hypot(l[2 * j] - l[2 * i], l[2 * j + 1] - l[2 * i + 1]);
            }
            this.lazo = l;
            this.lazoLargo = largo;
            this.lazoTotal = largo[n];
        } else {
            this.lazo = null;
            this.lazoLargo = null;
            this.lazoTotal = 0.0;
        }
    }

    @Override
    public void render(VehiculoEntity v, float yawEntidad, float tickParcial, PoseStack pose,
                       MultiBufferSource buffers, int luz) {
        super.render(v, yawEntidad, tickParcial, pose, buffers, luz);
        pose.pushPose();
        // cómo quedó apoyado: más alto o más bajo que la caja de choque, e inclinado sobre el medio entre los ejes
        pose.translate(0.0F, (float) v.getAlzaVista(tickParcial), 0.0F);
        float rumbo = Mth.rotLerp(tickParcial, v.yRotO, v.getYRot());
        // el frente del modelo (-X) queda hacia el frente del vehículo, (-sin, cos) en el mundo
        pose.mulPose(Axis.YP.rotationDegrees(-(rumbo + 90.0F)));
        float cabeceo = v.getCabeceo(tickParcial);
        if (cabeceo != 0.0F) {
            // acá el frente está hacia +X: un giro positivo en Z levanta la trompa
            float medio = (float) v.adelanteMedioEjes();
            pose.translate(medio, 0.0F, 0.0F);
            pose.mulPose(Axis.ZP.rotation(cabeceo));
            pose.translate(-medio, 0.0F, 0.0F);
        }
        // sacudón cuando le pegan
        float golpe = v.getHurtTime() - tickParcial;
        float dano = Math.max(0.0F, v.getDamage() - tickParcial);
        if (golpe > 0.0F) {
            pose.mulPose(Axis.XP.rotationDegrees(Mth.sin(golpe) * golpe * dano / 20.0F * v.getHurtDir()));
        }
        pose.scale(-1.0F, -1.0F, 1.0F);

        // las ruedas giran (misma cuenta que las del tren: la distancia recorrida sobre el radio); lo que anda cada lado
        // es lo que anduvo el vehículo menos lo que giró por lo lejos que está del medio
        double recorrido = v.getRecorrido(tickParcial) * this.datos.unidades();
        double giroTotal = v.getGiroTotal(tickParcial);
        for (Pieza p : this.ruedas) {
            double anduvo = recorrido - p.a().z() * giroTotal;
            double vueltas = (anduvo / p.a().radio()) % DOS_PI;
            p.parte().zRot = p.a().rotZ() - (float) vueltas + p.a().fase();
        }
        // los eslabones corren alrededor del lazo: por abajo hacia atrás cuando el vehículo va hacia adelante
        if (this.lazo != null) {
            for (Pieza p : this.eslabones) {
                ponerEslabon(p, p.a().fase() + recorrido - p.a().z() * giroTotal);
            }
        }
        float direccion = v.getDireccion(tickParcial);
        float giro = v.giroTorreta(tickParcial);
        float alza = v.alzaTorreta(tickParcial);
        pintar(pose, buffers.getBuffer(RenderType.entityCutout(this.datos.textura())), luz, direccion, giro, alza);
        if (this.texturaLuces != null) {
            pintar(pose, buffers.getBuffer(RenderType.entityTranslucentEmissive(this.texturaLuces)), BRILLO_TOTAL,
                    direccion, giro, alza);
        }
        pose.popPose();
    }

    /**
     * Pone un eslabón en el lugar s del lazo (unidades del modelo, da la vuelta): con su centro sobre el lazo y apuntando
     * de una punta a la otra (su cara de afuera queda sobre el lazo y su grosor hacia adentro).
     */
    private void ponerEslabon(Pieza p, double s) {
        double medio = p.a().radio() / 2.0;
        double cx = enLazo(s, 0);
        double cy = enLazo(s, 1);
        double tx = enLazo(s + medio, 0) - enLazo(s - medio, 0);
        double ty = enLazo(s + medio, 1) - enLazo(s - medio, 1);
        ModelPart parte = p.parte();
        parte.x = (float) cx;
        parte.y = (float) -cy;
        // en el modelo de Java la y va para abajo
        parte.zRot = (float) Math.atan2(-ty, tx);
    }

    /** La coordenada c (0 = x, 1 = y del diseño) del punto del lazo a la distancia s del primero. */
    private double enLazo(double s, int c) {
        double[] largo = this.lazoLargo;
        float[] l = this.lazo;
        int n = l.length / 2;
        s %= this.lazoTotal;
        if (s < 0.0) {
            s += this.lazoTotal;
        }
        // búsqueda binaria del tramo [largo[i], largo[i + 1]] que contiene a s
        int a = 0;
        int b = n;
        while (b - a > 1) {
            int m = (a + b) >>> 1;
            if (largo[m] <= s) {
                a = m;
            } else {
                b = m;
            }
        }
        double tramo = largo[a + 1] - largo[a];
        double f = tramo > 1.0E-9 ? (s - largo[a]) / tramo : 0.0;
        int j = (a + 1) % n;
        return l[2 * a + c] + (l[2 * j + c] - l[2 * a + c]) * f;
    }

    /**
     * El modelo entero y después, cada una con su giro, las piezas que se dibujan aparte. Los giros se hacen en las
     * coordenadas del modelo (la Z hacia la derecha del que maneja, la Y hacia abajo): un giro en Y positivo lleva el
     * frente hacia la derecha, y uno en Z positivo levanta la boca del caño.
     */
    private void pintar(PoseStack pose, VertexConsumer buffer, int luz, float direccion, float giro, float alza) {
        this.raiz.render(pose, buffer, luz, OverlayTexture.NO_OVERLAY);
        for (Pieza p : this.aparte) {
            DatosModelo.Animada a = p.a();
            pose.pushPose();
            switch (a.tipo()) {
                case DatosModelo.RUEDA_DOBLA -> girarEnY(pose, a.x(), a.z(), direccion);
                case DatosModelo.GIRA_EJE -> girarEnEje(pose, a, direccion * a.radio());
                case DatosModelo.TORRETA -> girarEnY(pose, a.x(), a.z(), giro);
                case DatosModelo.CANON -> {
                    girarEnY(pose, a.x(), a.z(), giro);
                    // el muñón: x en manivela, y en y (coordenadas del modelo, Y hacia abajo)
                    pose.translate(a.manivela() / 16.0F, a.y() / 16.0F, 0.0F);
                    pose.mulPose(Axis.ZP.rotation(alza));
                    pose.translate(-a.manivela() / 16.0F, -a.y() / 16.0F, 0.0F);
                }
                default -> {
                }
            }
            p.parte().visible = true;
            p.parte().render(pose, buffer, luz, OverlayTexture.NO_OVERLAY);
            p.parte().visible = false;
            pose.popPose();
        }
    }

    /** Gira lo que sigue alrededor de un eje vertical que pasa por (x, z) del modelo. */
    private static void girarEnY(PoseStack pose, float x, float z, float angulo) {
        pose.translate(x / 16.0F, 0.0F, z / 16.0F);
        pose.mulPose(Axis.YP.rotation(angulo));
        pose.translate(-x / 16.0F, 0.0F, -z / 16.0F);
    }

    /** Gira lo que sigue alrededor del eje de la pieza: pasa por (x, y, z) con la dirección (rotX, rotY, rotZ). */
    private void girarEnEje(PoseStack pose, DatosModelo.Animada a, float angulo) {
        if (angulo == 0.0F) {
            return;
        }
        pose.translate(a.x() / 16.0F, a.y() / 16.0F, a.z() / 16.0F);
        pose.mulPose(this.giroEje.rotationAxis(angulo, a.rotX(), a.rotY(), a.rotZ()));
        pose.translate(-a.x() / 16.0F, -a.y() / 16.0F, -a.z() / 16.0F);
    }

    @Override
    public ResourceLocation getTextureLocation(VehiculoEntity v) {
        return this.datos.textura();
    }
}
