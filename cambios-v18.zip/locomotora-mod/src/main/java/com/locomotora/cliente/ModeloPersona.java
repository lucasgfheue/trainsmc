package com.locomotora.cliente;

import com.locomotora.gente.PersonaEntity;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.world.entity.HumanoidArm;

/**
 * El muñeco de la gente de las carreteras: el del jugador (brazos de 4), con el arma en la mano y, cuando apunta, los
 * dos brazos adelante siguiendo la mirada (como con la ballesta cargada).
 */
public class ModeloPersona extends PlayerModel<PersonaEntity> {
    public ModeloPersona(ModelPart raiz) {
        super(raiz, false);
    }

    @Override
    public void prepareMobModel(PersonaEntity persona, float balanceo, float cuanto, float tickParcial) {
        super.prepareMobModel(persona, balanceo, cuanto, tickParcial);
        HumanoidModel.ArmPose pose = persona.apunta() ? HumanoidModel.ArmPose.CROSSBOW_HOLD
                : (persona.getMainHandItem().isEmpty() ? HumanoidModel.ArmPose.EMPTY : HumanoidModel.ArmPose.ITEM);
        if (persona.getMainArm() == HumanoidArm.RIGHT) {
            this.rightArmPose = pose;
            this.leftArmPose = HumanoidModel.ArmPose.EMPTY;
        } else {
            this.leftArmPose = pose;
            this.rightArmPose = HumanoidModel.ArmPose.EMPTY;
        }
    }
}
