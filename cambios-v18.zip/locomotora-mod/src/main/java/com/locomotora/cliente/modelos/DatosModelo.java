package com.locomotora.cliente.modelos;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Todo lo que el renderer necesita de un modelo de locomotora: capa, textura, piezas animadas y, en los trenes
 * largos, los cuerpos rígidos que se apoyan en la vía por sus bogies.
 *
 * @param unidades  unidades del modelo por bloque (32 en los modelos de alto detalle, 16 en los de estilo Traincraft)
 * @param preparar  se llama una vez con el modelo recién horneado (por ejemplo, para escalar piezas)
 * @param segmentos cuerpos que siguen la vía (vacío = el modelo entero gira alrededor del centro, como una vagoneta)
 */
public record DatosModelo(ModelLayerLocation capa, ResourceLocation textura, List<Animada> animadas,
                          Supplier<LayerDefinition> fabricaCapa, float unidades, Consumer<ModelPart> preparar,
                          List<Segmento> segmentos) {

    /** Rueda: gira sobre su eje. */
    public static final int RUEDA = 0;
    /** Biela de acoplamiento: se traslada en círculo con la manivela. */
    public static final int BIELA = 1;
    /** Biela motriz simple: sigue a la manivela y pivota un poco (modelos viejos). */
    public static final int BIELA_MOTRIZ = 2;
    /** Biela motriz con cinemática real: va del perno de la manivela a la cruceta. */
    public static final int MOTRIZ = 3;
    /** Cruceta y vástago del pistón: se deslizan derechos a la altura del eje. */
    public static final int CRUCETA = 4;
    /** Cruceta de un cilindro inclinado (Rocket): corre por la línea del cilindro, que pasa por el eje motriz. */
    public static final int CRUCETA_INCLINADA = 5;
    /** Biela de un cilindro inclinado: va del perno de la manivela a la cruceta inclinada. */
    public static final int MOTRIZ_INCLINADA = 6;
    /** Árbol de transmisión o cigüeñal que gira a lo largo de X (locomotora engranada Shay). */
    public static final int EJE_X = 7;
    /**
     * Biela de un cilindro vertical que baja a un cigüeñal tendido a lo largo de X (Shay): el muñón da vueltas en el
     * plano Y-Z y la biela se inclina hacia los costados.
     */
    public static final int MOTRIZ_X = 8;
    /**
     * Palanca de la cabina (cambio de marcha, acelerador): gira alrededor de Z según la marcha
     * ({@code angulo} radianes por marcha, desde su giro de reposo).
     */
    public static final int PALANCA = 9;
    /** Aguja del velocímetro de la cabina: gira alrededor de X según la velocidad ({@code angulo} = a toda marcha). */
    public static final int AGUJA = 10;
    /** Torreta (tren artillero): gira alrededor de su eje vertical hacia el blanco. */
    public static final int TORRETA = 11;
    /**
     * Cañón de una torreta: gira con ella alrededor del eje vertical y además sube y baja (el caño está armado a lo
     * largo de -Z y la pieza lleva un giro de reposo de 90° en Y, así la elevación es un giro en X).
     */
    public static final int CANON = 12;
    /**
     * Rueda de adelante de un vehículo de calle: gira sobre su eje como {@link #RUEDA} y además dobla alrededor de un eje
     * vertical que pasa por su centro ({@code x}, {@code z}).
     */
    public static final int RUEDA_DOBLA = 13;
    /**
     * Pieza (o grupo de piezas) de un vehículo de calle que gira entera alrededor de un eje cualquiera según lo que
     * doblan las ruedas de adelante: el volante sobre su columna y, en las motos, la rueda de adelante con la horquilla
     * y el manubrio. El eje pasa por ({@code x}, {@code y}, {@code z}) con la dirección ({@code rotX}, {@code rotY},
     * {@code rotZ}), y gira {@code radio} radianes por cada radián que doblan las ruedas.
     */
    public static final int GIRA_EJE = 14;
    /**
     * Eslabón de una oruga: corre alrededor del lazo de la oruga según lo que anda ese lado del vehículo. {@code fase}
     * es dónde está en el lazo (distancia desde el primer punto), {@code radio} su largo y {@code z} de qué lado va.
     */
    public static final int ESLABON = 15;

    /** Modelos de 1/32 de bloque que giran enteros alrededor del centro. */
    public DatosModelo(ModelLayerLocation capa, ResourceLocation textura, List<Animada> animadas,
                       Supplier<LayerDefinition> fabricaCapa) {
        this(capa, textura, animadas, fabricaCapa, 32.0F, raiz -> { }, List.of());
    }

    /**
     * Cuerpo rígido (por ejemplo la locomotora o el ténder): un grupo de piezas del modelo que se apoya en la vía
     * por dos puntos, en X del modelo (frente hacia -X).
     * <p>
     * Un cuerpo articulado (la unidad motriz delantera de una locomotora articulada, como la Big Boy) no se apoya
     * atrás en la vía sino en una bisagra del cuerpo {@code articuladoA}: gira alrededor de ella para que su bogie
     * delantero siga la vía, pero nunca más de {@code giroMaximo} grados respecto de ese cuerpo.
     *
     * @param articuladoA índice del cuerpo que lleva la bisagra (-1 = cuerpo normal, apoyado en sus dos bogies)
     * @param bisagra     X de la bisagra en el modelo
     * @param giroMaximo  cuánto puede girar respecto del otro cuerpo, en grados
     */
    public record Segmento(String grupo, float bogieDelantero, float bogieTrasero, int articuladoA, float bisagra,
                           float giroMaximo) {

        public Segmento(String grupo, float bogieDelantero, float bogieTrasero) {
            this(grupo, bogieDelantero, bogieTrasero, -1, 0.0F, 0.0F);
        }
    }

    /**
     * Pieza animada (medidas en unidades del modelo).
     *
     * @param radio    radio de la rueda que la mueve
     * @param manivela distancia del eje al perno de la biela
     * @param fase     desfase en radianes (el lado derecho va a 90° del izquierdo)
     * @param largo    largo de la biela motriz (negativo si el cilindro está adelante)
     * @param x        posición de reposo de la pieza (X del modelo)
     * @param y        posición de reposo de la pieza (Y del modelo)
     * @param rotZ     giro de reposo de la pieza (las ruedas lisas están hechas de varias piezas giradas)
     * @param grupo    cuerpo al que pertenece ("" = directo en la raíz)
     * @param angulo   inclinación del cilindro sobre la horizontal, hacia atrás, en radianes (solo los tipos inclinados);
     *                 en la palanca, cuánto gira por marcha; en la aguja, cuánto gira a toda velocidad
     * @param z        posición de reposo de la pieza (Z del modelo; {@link #MOTRIZ_X}, las ruedas de los vehículos de calle,
     *                 {@link #GIRA_EJE} y {@link #ESLABON})
     * @param rotX     giro de reposo alrededor de X ({@link #EJE_X}, {@link #MOTRIZ_X}, {@link #AGUJA} y {@link #CANON});
     *                 en {@link #GIRA_EJE}, la X de la dirección del eje
     * @param rotY     giro de reposo alrededor de Y ({@link #TORRETA} y {@link #CANON}); en {@link #GIRA_EJE}, la Y de la
     *                 dirección del eje
     */
    public record Animada(String parte, int tipo, float radio, float manivela, float fase, float largo, float x, float y,
                          float rotZ, String grupo, float angulo, float z, float rotX, float rotY) {

        public Animada(String parte, int tipo, float radio, float manivela, float fase, float largo, float x, float y,
                       float rotZ, String grupo, float angulo, float z, float rotX) {
            this(parte, tipo, radio, manivela, fase, largo, x, y, rotZ, grupo, angulo, z, rotX, 0.0F);
        }

        public Animada(String parte, int tipo, float radio, float manivela, float fase, float largo, float x, float y,
                       float rotZ, String grupo, float angulo) {
            this(parte, tipo, radio, manivela, fase, largo, x, y, rotZ, grupo, angulo, 0.0F, 0.0F, 0.0F);
        }

        public Animada(String parte, int tipo, float radio, float manivela, float fase, float largo, float x, float y,
                       float rotZ, String grupo) {
            this(parte, tipo, radio, manivela, fase, largo, x, y, rotZ, grupo, 0.0F, 0.0F, 0.0F, 0.0F);
        }

        public Animada(String parte, int tipo, float radio, float manivela, float fase, float largo, float x, float y) {
            this(parte, tipo, radio, manivela, fase, largo, x, y, 0.0F, "", 0.0F, 0.0F, 0.0F, 0.0F);
        }
    }
}
