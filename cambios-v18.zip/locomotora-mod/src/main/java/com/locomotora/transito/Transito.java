package com.locomotora.transito;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.jetbrains.annotations.Nullable;

import com.locomotora.aereo.DespachanteAereo;
import com.locomotora.carretera.CarreteraBlock;
import com.locomotora.generacion.Carreteras;
import com.locomotora.gente.Grupo;
import com.locomotora.gente.PersonaEntity;
import com.locomotora.mundo.Carretera;
import com.locomotora.registro.ModEntidades;
import com.locomotora.registro.ModReglas;
import com.locomotora.vehiculo.TipoVehiculo;
import com.locomotora.vehiculo.VehiculoEntity;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.event.tick.LevelTickEvent;

/**
 * El tránsito de las carreteras: cada tantos minutos (regla {@code locomotoraMinutosTransito}, 4 de fábrica), a cada
 * jugador que esté cerca de una carretera le aparece un vehículo, a unos 50-100 bloques, que viene por su carril con
 * gente adentro. Puede ser gente común (cualquier vehículo menos los militares), bandidos (cualquiera) o militares
 * (solo los militares); estos dos últimos nunca en pacífico (regla {@code locomotoraTransitoHostil}).
 * Los que quedan lejos de todos los jugadores se quitan (con su gente).
 */
public final class Transito {
    /** Los vehículos y la gente del tránsito que andan por ahí. */
    private static final Set<UUID> ACTIVOS = new HashSet<>();
    private static final Map<UUID, Long> ULTIMO = new HashMap<>();
    /** Más lejos que esto de todos los jugadores, se quitan. */
    private static final double LEJOS = 160.0;
    /** A esta distancia (o menos) del centro de una carretera, al jugador le aparece tránsito. */
    private static final double CERCA = 96.0;

    private Transito() {
    }

    public static boolean conocido(UUID id) {
        return ACTIVOS.contains(id);
    }

    public static void registrar(Entity e) {
        ACTIVOS.add(e.getUUID());
    }

    public static void alTick(LevelTickEvent.Post evento) {
        if (!(evento.getLevel() instanceof ServerLevel nivel) || nivel.dimension() != Level.OVERWORLD) {
            return;
        }
        long ahora = nivel.getGameTime();
        if (ahora % 20L != 7L) {
            return;
        }
        administrar(nivel);
        if (!ModReglas.transito(nivel.getGameRules())) {
            return;
        }
        long espera = 20L * 60L * Math.max(1, ModReglas.minutosTransito(nivel.getGameRules()));
        for (ServerPlayer jugador : nivel.players()) {
            if (jugador.isSpectator()) {
                continue;
            }
            // el primero, a la mitad de la espera; si se abrió otro mundo con la hora más atrás, se cuenta desde ahora
            long ultimo = ULTIMO.computeIfAbsent(jugador.getUUID(), k -> ahora - espera / 2L);
            if (ultimo > ahora) {
                ultimo = ahora - espera / 2L;
                ULTIMO.put(jugador.getUUID(), ultimo);
            }
            if (ahora - ultimo < espera || hayUnoCerca(nivel, jugador)) {
                continue;
            }
            if (lanzar(nivel, jugador)) {
                ULTIMO.put(jugador.getUUID(), ahora);
            }
        }
    }

    /** Quita los que quedaron lejos de todos (o donde el mundo ya no se mueve), con la gente que llevan. */
    private static void administrar(ServerLevel nivel) {
        Iterator<UUID> it = ACTIVOS.iterator();
        List<Entity> quitar = new ArrayList<>();
        while (it.hasNext()) {
            Entity e = nivel.getEntity(it.next());
            if (e == null || e.isRemoved()) {
                it.remove();
                continue;
            }
            // un vehículo que agarró un jugador ya es suyo
            if ((e instanceof VehiculoEntity v && !v.isTransito()) || (e instanceof PersonaEntity p && !p.isTransito())) {
                it.remove();
                continue;
            }
            if (e.isPassenger()) {
                continue;
            }
            if (DespachanteAereo.distanciaAlMasCercano(nivel, e) > LEJOS || !nivel.isPositionEntityTicking(e.blockPosition())) {
                quitar.add(e);
                it.remove();
            }
        }
        for (Entity e : quitar) {
            for (Entity q : List.copyOf(e.getPassengers())) {
                if (q instanceof PersonaEntity) {
                    q.discard();
                }
            }
            e.discard();
        }
    }

    private static boolean hayUnoCerca(ServerLevel nivel, ServerPlayer jugador) {
        for (UUID id : ACTIVOS) {
            if (nivel.getEntity(id) instanceof VehiculoEntity v && !v.isRemoved()) {
                double dx = v.getX() - jugador.getX();
                double dz = v.getZ() - jugador.getZ();
                if (dx * dx + dz * dz < 128.0 * 128.0) {
                    return true;
                }
            }
        }
        return false;
    }

    private static Grupo elegirGrupo(ServerLevel nivel, RandomSource azar) {
        if (nivel.getDifficulty() == Difficulty.PEACEFUL || !ModReglas.transitoHostil(nivel.getGameRules())) {
            return Grupo.CIVIL;
        }
        float r = azar.nextFloat();
        return r < 0.6F ? Grupo.CIVIL : (r < 0.82F ? Grupo.BANDIDO : Grupo.MILITAR);
    }

    /** La gente común, cualquier vehículo menos los militares; los bandidos, cualquiera; los militares, los suyos. */
    public static TipoVehiculo elegirVehiculo(Grupo g, RandomSource azar) {
        List<TipoVehiculo> lista = new ArrayList<>();
        for (TipoVehiculo t : TipoVehiculo.values()) {
            boolean militar = t.clase() == TipoVehiculo.Clase.MILITAR;
            if (g == Grupo.BANDIDO || (g == Grupo.MILITAR) == militar) {
                lista.add(t);
            }
        }
        return lista.get(azar.nextInt(lista.size()));
    }

    /** Le manda un vehículo al jugador, si está cerca de una carretera. */
    private static boolean lanzar(ServerLevel nivel, ServerPlayer jugador) {
        Carretera c = Carreteras.de(nivel);
        int fila = Carretera.fila(jugador.getZ());
        double[] l = c.lugar(fila, jugador.getX(), jugador.getZ());
        if (Math.abs(l[0]) > CERCA) {
            return false;
        }
        RandomSource azar = nivel.getRandom();
        Grupo g = elegirGrupo(nivel, azar);
        TipoVehiculo tipo = elegirVehiculo(g, azar);
        int primero = azar.nextBoolean() ? 1 : -1;
        for (int sentido : new int[]{primero, -primero}) {
            for (double atras : new double[]{84.0, 64.0, 104.0, 48.0}) {
                // viene hacia el jugador: aparece atrás (según hacia dónde va) y por su carril
                double x = l[1] - sentido * atras;
                double zm = c.centro(fila, x);
                double p = c.pendiente(fila, x);
                double n = Math.sqrt(1.0 + p * p);
                double d = Carretera.CARRIL * sentido;
                double cx = x - d * p / n;
                double cz = zm + d / n;
                BlockPos pos = BlockPos.containing(cx, jugador.getY(), cz);
                if (!nivel.isPositionEntityTicking(pos)) {
                    continue;
                }
                int alto = c.alto(fila, Mth.floor(x));
                if (!esCarretera(nivel, cx, cz, alto)) {
                    continue;
                }
                double y = alto * 0.5 + 0.02;
                if (nivel.getNearestPlayer(cx, y, cz, 32.0, false) != null) {
                    continue;
                }
                float rumbo = (float) Math.toDegrees(Math.atan2(-sentido, sentido * p));
                return aparecer(nivel, g, tipo, cx, y, cz, rumbo, azar) != null;
            }
        }
        return false;
    }

    /** ¿Ahí hay carretera de verdad? (los chunks generados antes de esta versión no tienen) */
    private static boolean esCarretera(ServerLevel nivel, double x, double z, int alto) {
        int piso = alto >> 1;
        int bx = Mth.floor(x);
        int bz = Mth.floor(z);
        BlockState abajo = nivel.getBlockState(new BlockPos(bx, (alto & 1) != 0 ? piso : piso - 1, bz));
        if (!(abajo.getBlock() instanceof CarreteraBlock)) {
            return false;
        }
        for (int y = piso + 1; y <= piso + 2; y++) {
            if (!nivel.getBlockState(new BlockPos(bx, y, bz)).getCollisionShape(nivel, new BlockPos(bx, y, bz)).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    /** Un vehículo del tránsito con su gente adentro (el primero, al volante). */
    @Nullable
    public static VehiculoEntity aparecer(ServerLevel nivel, Grupo g, TipoVehiculo tipo, double x, double y, double z,
                                          float rumbo, RandomSource azar) {
        VehiculoEntity v = new VehiculoEntity(ModEntidades.porTipo(tipo).get(), nivel, tipo);
        v.moveTo(x, y, z, rumbo, 0.0F);
        v.setTransito(true);
        int asientos = tipo.cantidadAsientos();
        int cuantos = switch (g) {
            case MILITAR -> Math.min(asientos, 2 + azar.nextInt(3));
            case BANDIDO -> Math.min(asientos, 2 + azar.nextInt(2));
            default -> Math.min(asientos, 1 + azar.nextInt(Math.min(3, asientos)));
        };
        EntityType<PersonaEntity> tipoPersona = g == Grupo.MILITAR ? ModEntidades.MILITAR.get()
                : (g == Grupo.BANDIDO ? ModEntidades.BANDIDO.get() : ModEntidades.PERSONA.get());
        DifficultyInstance dificultad = nivel.getCurrentDifficultyAt(BlockPos.containing(x, y, z));
        List<PersonaEntity> gente = new ArrayList<>();
        for (int i = 0; i < cuantos; i++) {
            PersonaEntity p = tipoPersona.create(nivel);
            if (p == null) {
                break;
            }
            p.moveTo(x, y, z, rumbo, 0.0F);
            p.finalizeSpawn(nivel, dificultad, MobSpawnType.EVENT, null);
            p.setTransito(true);
            p.setVehiculo(v.getUUID());
            if (v.subirNPC(p)) {
                gente.add(p);
            }
        }
        if (gente.isEmpty()) {
            return null;
        }
        nivel.addFreshEntityWithPassengers(v);
        registrar(v);
        for (PersonaEntity p : gente) {
            registrar(p);
        }
        return v;
    }
}
