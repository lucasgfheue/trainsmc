package com.locomotora.registro;

import com.locomotora.LocomotoraMod;
import com.locomotora.carretera.CarreteraBlock;
import com.locomotora.carretera.LineaBlock;
import com.locomotora.via.TipoVia;
import com.locomotora.via.ViaBlock;
import com.locomotora.via.ViaBlockEntity;
import com.locomotora.via.ViaCurvaBlock;
import com.locomotora.via.ViaDesvioBlock;
import com.locomotora.via.ViaMenu;
import com.locomotora.via.ViaRectaBlock;
import com.locomotora.via.ViaSubidaBlock;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Bloques de las vías nuevas (y el balasto), su entidad de bloque y el menú para configurarlas; y los de las carreteras:
 * el asfalto, las líneas, el hormigón de los puentes y los túneles, y la baranda de defensa.
 */
public final class ModBloques {
    public static final DeferredRegister.Blocks BLOQUES = DeferredRegister.createBlocks(LocomotoraMod.MODID);
    public static final DeferredRegister<BlockEntityType<?>> ENTIDADES_BLOQUE =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, LocomotoraMod.MODID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(Registries.MENU, LocomotoraMod.MODID);

    public static final DeferredBlock<ViaRectaBlock> VIA_RECTA =
            BLOQUES.register("via_recta", () -> new ViaRectaBlock(ViaBlock.propiedades()));
    public static final DeferredBlock<ViaCurvaBlock> VIA_CURVA =
            BLOQUES.register("via_curva", () -> new ViaCurvaBlock(ViaBlock.propiedades()));
    public static final DeferredBlock<ViaDesvioBlock> VIA_DESVIO =
            BLOQUES.register("via_dos_caminos", () -> new ViaDesvioBlock(ViaBlock.propiedades()));
    public static final DeferredBlock<ViaSubidaBlock> VIA_SUBIDA =
            BLOQUES.register("via_subida", () -> new ViaSubidaBlock(ViaBlock.propiedades()));

    /** Piedra partida que ponen las vías donde falta piso (no se cae como la grava). */
    public static final DeferredBlock<Block> BALASTO = BLOQUES.register("balasto",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE)
                    .strength(0.8F)
                    .sound(SoundType.GRAVEL)));
    /** Media losa de balasto: va debajo de los tramos de la subida donde la rampa queda más baja que el bloque. */
    public static final DeferredBlock<SlabBlock> LOSA_BALASTO = BLOQUES.register("losa_balasto",
            () -> new SlabBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE)
                    .strength(0.8F)
                    .sound(SoundType.GRAVEL)));

    // ------------------------------------------------------------------ carreteras
    /** El asfalto (bloque entero o, donde la carretera sube de a media altura, losa). */
    public static final DeferredBlock<CarreteraBlock> ASFALTO = BLOQUES.register("asfalto",
            () -> new CarreteraBlock(propiedadesAsfalto()));
    /** Asfalto con un pedazo de la línea blanca del costado. */
    public static final DeferredBlock<LineaBlock> LINEA_BLANCA = BLOQUES.register("linea_blanca",
            () -> new LineaBlock(propiedadesAsfalto()));
    /** Asfalto con un pedazo de la línea amarilla del medio. */
    public static final DeferredBlock<LineaBlock> LINEA_AMARILLA = BLOQUES.register("linea_amarilla",
            () -> new LineaBlock(propiedadesAsfalto()));
    /** El hormigón de los puentes y de los túneles de las carreteras. */
    public static final DeferredBlock<Block> HORMIGON = BLOQUES.register("hormigon",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE)
                    .requiresCorrectToolForDrops()
                    .strength(1.8F, 6.0F)
                    .sound(SoundType.STONE)));
    /** La baranda de defensa de los puentes: se une con las de al lado, como una cerca. */
    public static final DeferredBlock<FenceBlock> BARANDA = BLOQUES.register("baranda",
            () -> new FenceBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL)
                    .requiresCorrectToolForDrops()
                    .strength(2.5F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()));

    private static BlockBehaviour.Properties propiedadesAsfalto() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_GRAY)
                .requiresCorrectToolForDrops()
                .strength(1.5F, 6.0F)
                .sound(SoundType.STONE);
    }

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ViaBlockEntity>> VIA_ENTIDAD =
            ENTIDADES_BLOQUE.register("via", () -> BlockEntityType.Builder.of(ViaBlockEntity::new,
                    VIA_RECTA.get(), VIA_CURVA.get(), VIA_DESVIO.get(), VIA_SUBIDA.get()).build(null));

    public static final DeferredHolder<MenuType<?>, MenuType<ViaMenu>> VIA_MENU =
            MENUS.register("via", () -> new MenuType<ViaMenu>(ViaMenu::new, FeatureFlags.DEFAULT_FLAGS));

    public static DeferredBlock<? extends ViaBlock> bloquePara(TipoVia tipo) {
        return switch (tipo) {
            case RECTA -> VIA_RECTA;
            case CURVA -> VIA_CURVA;
            case DOS_CAMINOS -> VIA_DESVIO;
            case SUBIDA -> VIA_SUBIDA;
        };
    }

    private ModBloques() {
    }
}
