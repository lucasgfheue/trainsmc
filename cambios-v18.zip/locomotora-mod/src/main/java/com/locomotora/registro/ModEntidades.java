package com.locomotora.registro;

import java.util.EnumMap;
import java.util.Map;

import com.locomotora.LocomotoraMod;
import com.locomotora.aereo.AeronaveEntity;
import com.locomotora.aereo.BombaEntity;
import com.locomotora.aereo.TipoAeronave;
import com.locomotora.artillero.ArtilleroEntity;
import com.locomotora.artillero.ObusEntity;
import com.locomotora.armas.BalaEntity;
import com.locomotora.gente.PersonaEntity;
import com.locomotora.artillero.VagonArmadoEntity;
import com.locomotora.entidad.LocomotoraEntity;
import com.locomotora.entidad.TipoLocomotora;
import com.locomotora.entidad.TipoVagon;
import com.locomotora.entidad.VagonEntity;
import com.locomotora.vehiculo.TipoVehiculo;
import com.locomotora.vehiculo.VehiculoEntity;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntidades {
    public static final DeferredRegister<EntityType<?>> ENTIDADES =
            DeferredRegister.create(Registries.ENTITY_TYPE, LocomotoraMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> SCOTSMAN = registrar(TipoLocomotora.SCOTSMAN);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> F7 = registrar(TipoLocomotora.F7);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> V200 = registrar(TipoLocomotora.V200);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> MALLARD = registrar(TipoLocomotora.MALLARD);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> BIG_BOY = registrar(TipoLocomotora.BIG_BOY);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> GS4 = registrar(TipoLocomotora.GS4);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> BR01 = registrar(TipoLocomotora.BR01);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> PANNIER = registrar(TipoLocomotora.PANNIER);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> HST = registrar(TipoLocomotora.HST);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> DELTIC = registrar(TipoLocomotora.DELTIC);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> SD40 = registrar(TipoLocomotora.SD40);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> ES44 = registrar(TipoLocomotora.ES44);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> DD51 = registrar(TipoLocomotora.DD51);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> CLASS08 = registrar(TipoLocomotora.CLASS08);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> ROCKET = registrar(TipoLocomotora.ROCKET);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> JUPITER = registrar(TipoLocomotora.JUPITER);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> HIAWATHA = registrar(TipoLocomotora.HIAWATHA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> T1 = registrar(TipoLocomotora.T1);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> NWJ = registrar(TipoLocomotora.NWJ);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> MERCHANT = registrar(TipoLocomotora.MERCHANT);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> BR9F = registrar(TipoLocomotora.BR9F);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> D51 = registrar(TipoLocomotora.D51);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> P36 = registrar(TipoLocomotora.P36);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> GARRATT = registrar(TipoLocomotora.GARRATT);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> ZEPHYR = registrar(TipoLocomotora.ZEPHYR);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> HAMBURGER = registrar(TipoLocomotora.HAMBURGER);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> V160 = registrar(TipoLocomotora.V160);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> CC72000 = registrar(TipoLocomotora.CC72000);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> CHME3 = registrar(TipoLocomotora.CHME3);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> DF4 = registrar(TipoLocomotora.DF4);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> WDM2 = registrar(TipoLocomotora.WDM2);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> P42 = registrar(TipoLocomotora.P42);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> DF200 = registrar(TipoLocomotora.DF200);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> GP9_ABANDONADA = registrar(TipoLocomotora.GP9_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> E8_ABANDONADA = registrar(TipoLocomotora.E8_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> RS3_ABANDONADA = registrar(TipoLocomotora.RS3_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> RDC_ABANDONADO = registrar(TipoLocomotora.RDC_ABANDONADO);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> CLASS37_ABANDONADA = registrar(TipoLocomotora.CLASS37_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> CLASS20_ABANDONADA = registrar(TipoLocomotora.CLASS20_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> M62_ABANDONADA = registrar(TipoLocomotora.M62_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> TEP60_ABANDONADA = registrar(TipoLocomotora.TEP60_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> T478_ABANDONADA = registrar(TipoLocomotora.T478_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> KIHA40_ABANDONADO = registrar(TipoLocomotora.KIHA40_ABANDONADO);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> SHARKNOSE_ABANDONADA = registrar(TipoLocomotora.SHARKNOSE_ABANDONADA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> LOCOMOTION = registrar(TipoLocomotora.LOCOMOTION);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> BEST_FRIEND = registrar(TipoLocomotora.BEST_FRIEND);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> JOHN_BULL = registrar(TipoLocomotora.JOHN_BULL);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> ADLER = registrar(TipoLocomotora.ADLER);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> COPPERNOB = registrar(TipoLocomotora.COPPERNOB);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> PORTENA = registrar(TipoLocomotora.PORTENA);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> SHAY = registrar(TipoLocomotora.SHAY);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> SIMPLEX = registrar(TipoLocomotora.SIMPLEX);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> DEUTZ = registrar(TipoLocomotora.DEUTZ);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> GE44 = registrar(TipoLocomotora.GE44);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> PLYMOUTH = registrar(TipoLocomotora.PLYMOUTH);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> TGM23 = registrar(TipoLocomotora.TGM23);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> TUNEL = registrar(TipoLocomotora.TUNEL);
    public static final DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> ARTILLERO = registrar(TipoLocomotora.ARTILLERO);

    // ------------------------------------------------------------------ vagones
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_SKIP = registrarVagon(TipoVagon.SKIP);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_LADRILLOS = registrarVagon(TipoVagon.LADRILLOS);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_CARBON = registrarVagon(TipoVagon.CARBON);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_TOLVA = registrarVagon(TipoVagon.TOLVA);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_VOLTEO = registrarVagon(TipoVagon.VOLTEO);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_CISTERNA = registrarVagon(TipoVagon.CISTERNA);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_DOVELAS = registrarVagon(TipoVagon.DOVELAS);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_G10 = registrarVagon(TipoVagon.G10);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_REFRIGERADO = registrarVagon(TipoVagon.REFRIGERADO);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_TRONCOS = registrarVagon(TipoVagon.TRONCOS);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_CONTENEDORES = registrarVagon(TipoVagon.CONTENEDORES);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_PETROLERO = registrarVagon(TipoVagon.PETROLERO);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_TAKI = registrarVagon(TipoVagon.TAKI);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_GLP = registrarVagon(TipoVagon.GLP);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_CANON = registrarVagon(TipoVagon.CANON);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> VAGON_ANTIAEREO = registrarVagon(TipoVagon.ANTIAEREO);

    // ------------------------------------------------------------------ coches de pasajeros
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> COCHE_DILIGENCIA = registrarVagon(TipoVagon.DILIGENCIA);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> COCHE_OESTE = registrarVagon(TipoVagon.OESTE);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> COCHE_TECA = registrarVagon(TipoVagon.TECA);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> COCHE_CAMA = registrarVagon(TipoVagon.CAMA);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> COCHE_DAYLIGHT = registrarVagon(TipoVagon.DAYLIGHT);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> COCHE_MIRADOR = registrarVagon(TipoVagon.MIRADOR);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> COCHE_DOMO = registrarVagon(TipoVagon.DOMO);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> COCHE_INDIO = registrarVagon(TipoVagon.INDIO);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> COCHE_TREN_AZUL = registrarVagon(TipoVagon.TREN_AZUL);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> COCHE_MK3 = registrarVagon(TipoVagon.MK3);
    public static final DeferredHolder<EntityType<?>, EntityType<VagonEntity>> COCHE_DOS_PISOS = registrarVagon(TipoVagon.DOS_PISOS);

    // ------------------------------------------------------------------ el obús que tiran las torretas del tren artillero
    public static final DeferredHolder<EntityType<?>, EntityType<ObusEntity>> OBUS = ENTIDADES.register("obus",
            () -> EntityType.Builder.<ObusEntity>of(ObusEntity::new, MobCategory.MISC)
                    .sized(0.3125F, 0.3125F)
                    .clientTrackingRange(8)
                    .updateInterval(2)
                    .build(LocomotoraMod.id("obus").toString()));

    // ------------------------------------------------------------------ la gente de las carreteras y sus balas
    public static final DeferredHolder<EntityType<?>, EntityType<PersonaEntity>> PERSONA = registrarPersona("persona");
    public static final DeferredHolder<EntityType<?>, EntityType<PersonaEntity>> BANDIDO = registrarPersona("bandido");
    public static final DeferredHolder<EntityType<?>, EntityType<PersonaEntity>> MILITAR = registrarPersona("militar");

    public static final DeferredHolder<EntityType<?>, EntityType<BalaEntity>> BALA = ENTIDADES.register("bala",
            () -> EntityType.Builder.<BalaEntity>of(BalaEntity::new, MobCategory.MISC)
                    .sized(0.15F, 0.15F)
                    .clientTrackingRange(6)
                    .updateInterval(1)
                    .build(LocomotoraMod.id("bala").toString()));

    /** Del tamaño y la altura de los ojos de un jugador. */
    private static DeferredHolder<EntityType<?>, EntityType<PersonaEntity>> registrarPersona(String nombre) {
        return ENTIDADES.register(nombre, () -> EntityType.Builder.<PersonaEntity>of(PersonaEntity::new, MobCategory.MISC)
                .sized(0.6F, 1.8F)
                .eyeHeight(1.62F)
                .clientTrackingRange(10)
                .build(LocomotoraMod.id(nombre).toString()));
    }

    // ------------------------------------------------------------------ globos y zeppelines, y sus bombas
    public static final DeferredHolder<EntityType<?>, EntityType<BombaEntity>> BOMBA = ENTIDADES.register("bomba",
            () -> EntityType.Builder.<BombaEntity>of(BombaEntity::new, MobCategory.MISC)
                    .sized(0.4F, 0.4F)
                    .clientTrackingRange(10)
                    .updateInterval(2)
                    .build(LocomotoraMod.id("bomba").toString()));

    private static final Map<TipoAeronave, DeferredHolder<EntityType<?>, EntityType<AeronaveEntity>>> AERONAVES =
            new EnumMap<>(TipoAeronave.class);

    static {
        for (TipoAeronave tipo : TipoAeronave.values()) {
            AERONAVES.put(tipo, registrarAeronave(tipo));
        }
    }

    /**
     * Un globo o un zeppelin: la caja de choque es el globo entero o el tramo del medio del zeppelin (el resto del
     * casco son sus tramos). Se manda a los clientes de bien lejos (vuela alto y se ve desde lejos).
     */
    private static DeferredHolder<EntityType<?>, EntityType<AeronaveEntity>> registrarAeronave(TipoAeronave tipo) {
        String nombre = tipo.nombreRegistro();
        return ENTIDADES.register(nombre, () -> EntityType.Builder
                .<AeronaveEntity>of((tipoEntidad, level) -> new AeronaveEntity(tipoEntidad, level, tipo), MobCategory.MISC)
                .sized(tipo.ancho(), tipo.alto())
                .clientTrackingRange(20)
                .updateInterval(2)
                .build(LocomotoraMod.id(nombre).toString()));
    }

    public static DeferredHolder<EntityType<?>, EntityType<AeronaveEntity>> porTipo(TipoAeronave tipo) {
        return AERONAVES.get(tipo);
    }

    // ------------------------------------------------------------------ vehículos de calle
    private static final Map<TipoVehiculo, DeferredHolder<EntityType<?>, EntityType<VehiculoEntity>>> VEHICULOS =
            new EnumMap<>(TipoVehiculo.class);

    static {
        for (TipoVehiculo tipo : TipoVehiculo.values()) {
            VEHICULOS.put(tipo, registrarVehiculo(tipo));
        }
    }

    /**
     * Un auto, una moto, un camión...: la caja de choque es el medio del vehículo, del ancho del modelo (el resto del
     * largo son sus tramos). La posición va al cliente en cada tick: así se ve andar suave.
     */
    private static DeferredHolder<EntityType<?>, EntityType<VehiculoEntity>> registrarVehiculo(TipoVehiculo tipo) {
        String nombre = tipo.nombreRegistro();
        return ENTIDADES.register(nombre, () -> EntityType.Builder
                .<VehiculoEntity>of((tipoEntidad, level) -> new VehiculoEntity(tipoEntidad, level, tipo), MobCategory.MISC)
                .sized(tipo.anchoCaja(), tipo.altoCaja())
                .clientTrackingRange(10)
                .updateInterval(1)
                .build(LocomotoraMod.id(nombre).toString()));
    }

    public static DeferredHolder<EntityType<?>, EntityType<VehiculoEntity>> porTipo(TipoVehiculo tipo) {
        return VEHICULOS.get(tipo);
    }

    private static DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> registrar(TipoLocomotora tipo) {
        String nombre = "locomotora_" + tipo.id();
        return ENTIDADES.register(nombre, () -> EntityType.Builder
                // la del tren artillero tiene su torreta, su blindaje y su cabeza propia
                .<LocomotoraEntity>of((tipoEntidad, level) -> tipo.artillero()
                        ? new ArtilleroEntity(tipoEntidad, level, tipo)
                        : new LocomotoraEntity(tipoEntidad, level, tipo), MobCategory.MISC)
                // Ancho de vagoneta para que encaje en los rieles; necesita 2 bloques de alto libres
                .sized(0.98F, 1.4F)
                // Altura del asiento del maquinista en la cabina
                .passengerAttachments(tipo.alturaAsiento())
                .clientTrackingRange(12)
                // Posición al cliente en cada tick: así la locomotora y sus vagones se ven siempre a la misma distancia
                .updateInterval(1)
                .build(LocomotoraMod.id(nombre).toString()));
    }

    private static DeferredHolder<EntityType<?>, EntityType<VagonEntity>> registrarVagon(TipoVagon tipo) {
        String nombre = tipo.nombreRegistro();
        return ENTIDADES.register(nombre, () -> EntityType.Builder
                .<VagonEntity>of((tipoEntidad, level) -> tipo.armado()
                        ? new VagonArmadoEntity(tipoEntidad, level, tipo)
                        : new VagonEntity(tipoEntidad, level, tipo), MobCategory.MISC)
                // Del tamaño de una vagoneta para que encaje en los rieles
                .sized(0.98F, 0.7F)
                .clientTrackingRange(12)
                .updateInterval(1)
                .build(LocomotoraMod.id(nombre).toString()));
    }

    public static DeferredHolder<EntityType<?>, EntityType<LocomotoraEntity>> porTipo(TipoLocomotora tipo) {
        return switch (tipo) {
            case SCOTSMAN -> SCOTSMAN;
            case F7 -> F7;
            case V200 -> V200;
            case MALLARD -> MALLARD;
            case BIG_BOY -> BIG_BOY;
            case GS4 -> GS4;
            case BR01 -> BR01;
            case PANNIER -> PANNIER;
            case HST -> HST;
            case DELTIC -> DELTIC;
            case SD40 -> SD40;
            case ES44 -> ES44;
            case DD51 -> DD51;
            case CLASS08 -> CLASS08;
            case ROCKET -> ROCKET;
            case JUPITER -> JUPITER;
            case HIAWATHA -> HIAWATHA;
            case T1 -> T1;
            case NWJ -> NWJ;
            case MERCHANT -> MERCHANT;
            case BR9F -> BR9F;
            case D51 -> D51;
            case P36 -> P36;
            case GARRATT -> GARRATT;
            case ZEPHYR -> ZEPHYR;
            case HAMBURGER -> HAMBURGER;
            case V160 -> V160;
            case CC72000 -> CC72000;
            case CHME3 -> CHME3;
            case DF4 -> DF4;
            case WDM2 -> WDM2;
            case P42 -> P42;
            case DF200 -> DF200;
            case GP9_ABANDONADA -> GP9_ABANDONADA;
            case E8_ABANDONADA -> E8_ABANDONADA;
            case RS3_ABANDONADA -> RS3_ABANDONADA;
            case RDC_ABANDONADO -> RDC_ABANDONADO;
            case CLASS37_ABANDONADA -> CLASS37_ABANDONADA;
            case CLASS20_ABANDONADA -> CLASS20_ABANDONADA;
            case M62_ABANDONADA -> M62_ABANDONADA;
            case TEP60_ABANDONADA -> TEP60_ABANDONADA;
            case T478_ABANDONADA -> T478_ABANDONADA;
            case KIHA40_ABANDONADO -> KIHA40_ABANDONADO;
            case SHARKNOSE_ABANDONADA -> SHARKNOSE_ABANDONADA;
            case LOCOMOTION -> LOCOMOTION;
            case BEST_FRIEND -> BEST_FRIEND;
            case JOHN_BULL -> JOHN_BULL;
            case ADLER -> ADLER;
            case COPPERNOB -> COPPERNOB;
            case PORTENA -> PORTENA;
            case SHAY -> SHAY;
            case SIMPLEX -> SIMPLEX;
            case DEUTZ -> DEUTZ;
            case GE44 -> GE44;
            case PLYMOUTH -> PLYMOUTH;
            case TGM23 -> TGM23;
            case TUNEL -> TUNEL;
            case ARTILLERO -> ARTILLERO;
        };
    }

    public static DeferredHolder<EntityType<?>, EntityType<VagonEntity>> porTipo(TipoVagon tipo) {
        return switch (tipo) {
            case SKIP -> VAGON_SKIP;
            case LADRILLOS -> VAGON_LADRILLOS;
            case CARBON -> VAGON_CARBON;
            case TOLVA -> VAGON_TOLVA;
            case VOLTEO -> VAGON_VOLTEO;
            case CISTERNA -> VAGON_CISTERNA;
            case DOVELAS -> VAGON_DOVELAS;
            case G10 -> VAGON_G10;
            case REFRIGERADO -> VAGON_REFRIGERADO;
            case TRONCOS -> VAGON_TRONCOS;
            case CONTENEDORES -> VAGON_CONTENEDORES;
            case PETROLERO -> VAGON_PETROLERO;
            case TAKI -> VAGON_TAKI;
            case GLP -> VAGON_GLP;
            case CANON -> VAGON_CANON;
            case ANTIAEREO -> VAGON_ANTIAEREO;
            case DILIGENCIA -> COCHE_DILIGENCIA;
            case OESTE -> COCHE_OESTE;
            case TECA -> COCHE_TECA;
            case CAMA -> COCHE_CAMA;
            case DAYLIGHT -> COCHE_DAYLIGHT;
            case MIRADOR -> COCHE_MIRADOR;
            case DOMO -> COCHE_DOMO;
            case INDIO -> COCHE_INDIO;
            case TREN_AZUL -> COCHE_TREN_AZUL;
            case MK3 -> COCHE_MK3;
            case DOS_PISOS -> COCHE_DOS_PISOS;
        };
    }

    private ModEntidades() {
    }
}
