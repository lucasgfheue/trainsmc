package com.locomotora.registro;

import com.locomotora.LocomotoraMod;
import com.locomotora.aereo.TipoAeronave;
import com.locomotora.entidad.TipoLocomotora;
import com.locomotora.entidad.TipoVagon;
import com.locomotora.via.TipoVia;
import com.locomotora.vehiculo.TipoVehiculo;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/**
 * Pestañas del modo creativo: las locomotoras (con el bidón de diésel), los vagones, los coches, las vías, los globos y
 * zeppelines y los vehículos de calle.
 */
public final class ModPestanas {
    public static final DeferredRegister<CreativeModeTab> PESTANAS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LocomotoraMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> LOCOMOTORAS = PESTANAS.register("locomotoras",
            () -> CreativeModeTab.builder()
                    .withTabsBefore(CreativeModeTabs.SPAWN_EGGS)
                    .title(Component.translatable("itemGroup.locomotora.locomotoras"))
                    .icon(() -> new ItemStack(ModItems.SCOTSMAN.get()))
                    .displayItems((parametros, salida) -> {
                        for (TipoLocomotora tipo : TipoLocomotora.values()) {
                            salida.accept(ModItems.porTipo(tipo).get());
                        }
                        salida.accept(ModItems.BIDON_DIESEL.get());
                        salida.accept(ModItems.ARTILLERO_HOSTIL.get());
                    })
                    .build());

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> VAGONES = PESTANAS.register("vagones",
            () -> CreativeModeTab.builder()
                    .withTabsBefore(LOCOMOTORAS.getId())
                    .title(Component.translatable("itemGroup.locomotora.vagones"))
                    .icon(() -> new ItemStack(ModItems.porTipo(TipoVagon.TOLVA).get()))
                    .displayItems((parametros, salida) -> {
                        for (TipoVagon tipo : TipoVagon.values()) {
                            if (!tipo.esCoche()) {
                                salida.accept(ModItems.porTipo(tipo).get());
                            }
                        }
                    })
                    .build());

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> COCHES = PESTANAS.register("coches",
            () -> CreativeModeTab.builder()
                    .withTabsBefore(VAGONES.getId())
                    .title(Component.translatable("itemGroup.locomotora.coches"))
                    .icon(() -> new ItemStack(ModItems.porTipo(TipoVagon.DAYLIGHT).get()))
                    .displayItems((parametros, salida) -> {
                        for (TipoVagon tipo : TipoVagon.values()) {
                            if (tipo.esCoche()) {
                                salida.accept(ModItems.porTipo(tipo).get());
                            }
                        }
                    })
                    .build());

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> VIAS = PESTANAS.register("vias",
            () -> CreativeModeTab.builder()
                    .withTabsBefore(COCHES.getId())
                    .title(Component.translatable("itemGroup.locomotora.vias"))
                    .icon(() -> new ItemStack(ModItems.VIA_CURVA.get()))
                    .displayItems((parametros, salida) -> {
                        for (TipoVia tipo : TipoVia.values()) {
                            salida.accept(ModItems.viaPorTipo(tipo).get());
                        }
                        salida.accept(ModItems.BALASTO.get());
                        salida.accept(ModItems.LOSA_BALASTO.get());
                    })
                    .build());

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> AERONAVES = PESTANAS.register("aeronaves",
            () -> CreativeModeTab.builder()
                    .withTabsBefore(VIAS.getId())
                    .title(Component.translatable("itemGroup.locomotora.aeronaves"))
                    .icon(() -> new ItemStack(ModItems.porTipo(TipoAeronave.ZEPPELIN_PLATEADO).get()))
                    .displayItems((parametros, salida) -> {
                        for (TipoAeronave tipo : TipoAeronave.values()) {
                            salida.accept(ModItems.porTipo(tipo).get());
                        }
                    })
                    .build());

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> VEHICULOS = PESTANAS.register("vehiculos",
            () -> CreativeModeTab.builder()
                    .withTabsBefore(AERONAVES.getId())
                    .title(Component.translatable("itemGroup.locomotora.vehiculos"))
                    .icon(() -> new ItemStack(ModItems.porTipo(TipoVehiculo.AUTO_CONVERTIBLE).get()))
                    .displayItems((parametros, salida) -> {
                        for (TipoVehiculo tipo : TipoVehiculo.values()) {
                            salida.accept(ModItems.porTipo(tipo).get());
                        }
                    })
                    .build());

    private ModPestanas() {
    }
}
