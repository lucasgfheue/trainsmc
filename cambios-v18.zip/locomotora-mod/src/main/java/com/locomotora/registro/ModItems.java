package com.locomotora.registro;

import java.util.EnumMap;
import java.util.Map;

import com.locomotora.LocomotoraMod;
import com.locomotora.aereo.TipoAeronave;
import com.locomotora.entidad.TipoLocomotora;
import com.locomotora.entidad.TipoVagon;
import com.locomotora.item.AeronaveItem;
import com.locomotora.item.ArtilleroHostilItem;
import com.locomotora.item.LocomotoraItem;
import com.locomotora.item.VagonItem;
import com.locomotora.item.VehiculoItem;
import com.locomotora.via.TipoVia;
import com.locomotora.via.ViaItem;
import com.locomotora.vehiculo.TipoVehiculo;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(LocomotoraMod.MODID);

    public static final DeferredItem<LocomotoraItem> SCOTSMAN = registrar(TipoLocomotora.SCOTSMAN);
    public static final DeferredItem<LocomotoraItem> F7 = registrar(TipoLocomotora.F7);
    public static final DeferredItem<LocomotoraItem> V200 = registrar(TipoLocomotora.V200);
    public static final DeferredItem<LocomotoraItem> MALLARD = registrar(TipoLocomotora.MALLARD);
    public static final DeferredItem<LocomotoraItem> BIG_BOY = registrar(TipoLocomotora.BIG_BOY);
    public static final DeferredItem<LocomotoraItem> GS4 = registrar(TipoLocomotora.GS4);
    public static final DeferredItem<LocomotoraItem> BR01 = registrar(TipoLocomotora.BR01);
    public static final DeferredItem<LocomotoraItem> PANNIER = registrar(TipoLocomotora.PANNIER);
    public static final DeferredItem<LocomotoraItem> HST = registrar(TipoLocomotora.HST);
    public static final DeferredItem<LocomotoraItem> DELTIC = registrar(TipoLocomotora.DELTIC);
    public static final DeferredItem<LocomotoraItem> SD40 = registrar(TipoLocomotora.SD40);
    public static final DeferredItem<LocomotoraItem> ES44 = registrar(TipoLocomotora.ES44);
    public static final DeferredItem<LocomotoraItem> DD51 = registrar(TipoLocomotora.DD51);
    public static final DeferredItem<LocomotoraItem> CLASS08 = registrar(TipoLocomotora.CLASS08);
    public static final DeferredItem<LocomotoraItem> ROCKET = registrar(TipoLocomotora.ROCKET);
    public static final DeferredItem<LocomotoraItem> JUPITER = registrar(TipoLocomotora.JUPITER);
    public static final DeferredItem<LocomotoraItem> HIAWATHA = registrar(TipoLocomotora.HIAWATHA);
    public static final DeferredItem<LocomotoraItem> T1 = registrar(TipoLocomotora.T1);
    public static final DeferredItem<LocomotoraItem> NWJ = registrar(TipoLocomotora.NWJ);
    public static final DeferredItem<LocomotoraItem> MERCHANT = registrar(TipoLocomotora.MERCHANT);
    public static final DeferredItem<LocomotoraItem> BR9F = registrar(TipoLocomotora.BR9F);
    public static final DeferredItem<LocomotoraItem> D51 = registrar(TipoLocomotora.D51);
    public static final DeferredItem<LocomotoraItem> P36 = registrar(TipoLocomotora.P36);
    public static final DeferredItem<LocomotoraItem> GARRATT = registrar(TipoLocomotora.GARRATT);
    public static final DeferredItem<LocomotoraItem> ZEPHYR = registrar(TipoLocomotora.ZEPHYR);
    public static final DeferredItem<LocomotoraItem> HAMBURGER = registrar(TipoLocomotora.HAMBURGER);
    public static final DeferredItem<LocomotoraItem> V160 = registrar(TipoLocomotora.V160);
    public static final DeferredItem<LocomotoraItem> CC72000 = registrar(TipoLocomotora.CC72000);
    public static final DeferredItem<LocomotoraItem> CHME3 = registrar(TipoLocomotora.CHME3);
    public static final DeferredItem<LocomotoraItem> DF4 = registrar(TipoLocomotora.DF4);
    public static final DeferredItem<LocomotoraItem> WDM2 = registrar(TipoLocomotora.WDM2);
    public static final DeferredItem<LocomotoraItem> P42 = registrar(TipoLocomotora.P42);
    public static final DeferredItem<LocomotoraItem> DF200 = registrar(TipoLocomotora.DF200);
    public static final DeferredItem<LocomotoraItem> GP9_ABANDONADA = registrar(TipoLocomotora.GP9_ABANDONADA);
    public static final DeferredItem<LocomotoraItem> E8_ABANDONADA = registrar(TipoLocomotora.E8_ABANDONADA);
    public static final DeferredItem<LocomotoraItem> RS3_ABANDONADA = registrar(TipoLocomotora.RS3_ABANDONADA);
    public static final DeferredItem<LocomotoraItem> RDC_ABANDONADO = registrar(TipoLocomotora.RDC_ABANDONADO);
    public static final DeferredItem<LocomotoraItem> CLASS37_ABANDONADA = registrar(TipoLocomotora.CLASS37_ABANDONADA);
    public static final DeferredItem<LocomotoraItem> CLASS20_ABANDONADA = registrar(TipoLocomotora.CLASS20_ABANDONADA);
    public static final DeferredItem<LocomotoraItem> M62_ABANDONADA = registrar(TipoLocomotora.M62_ABANDONADA);
    public static final DeferredItem<LocomotoraItem> TEP60_ABANDONADA = registrar(TipoLocomotora.TEP60_ABANDONADA);
    public static final DeferredItem<LocomotoraItem> T478_ABANDONADA = registrar(TipoLocomotora.T478_ABANDONADA);
    public static final DeferredItem<LocomotoraItem> KIHA40_ABANDONADO = registrar(TipoLocomotora.KIHA40_ABANDONADO);
    public static final DeferredItem<LocomotoraItem> SHARKNOSE_ABANDONADA = registrar(TipoLocomotora.SHARKNOSE_ABANDONADA);
    public static final DeferredItem<LocomotoraItem> LOCOMOTION = registrar(TipoLocomotora.LOCOMOTION);
    public static final DeferredItem<LocomotoraItem> BEST_FRIEND = registrar(TipoLocomotora.BEST_FRIEND);
    public static final DeferredItem<LocomotoraItem> JOHN_BULL = registrar(TipoLocomotora.JOHN_BULL);
    public static final DeferredItem<LocomotoraItem> ADLER = registrar(TipoLocomotora.ADLER);
    public static final DeferredItem<LocomotoraItem> COPPERNOB = registrar(TipoLocomotora.COPPERNOB);
    public static final DeferredItem<LocomotoraItem> PORTENA = registrar(TipoLocomotora.PORTENA);
    public static final DeferredItem<LocomotoraItem> SHAY = registrar(TipoLocomotora.SHAY);
    public static final DeferredItem<LocomotoraItem> SIMPLEX = registrar(TipoLocomotora.SIMPLEX);
    public static final DeferredItem<LocomotoraItem> DEUTZ = registrar(TipoLocomotora.DEUTZ);
    public static final DeferredItem<LocomotoraItem> GE44 = registrar(TipoLocomotora.GE44);
    public static final DeferredItem<LocomotoraItem> PLYMOUTH = registrar(TipoLocomotora.PLYMOUTH);
    public static final DeferredItem<LocomotoraItem> TGM23 = registrar(TipoLocomotora.TGM23);
    public static final DeferredItem<LocomotoraItem> TUNEL = registrar(TipoLocomotora.TUNEL);
    public static final DeferredItem<LocomotoraItem> ARTILLERO = registrar(TipoLocomotora.ARTILLERO);

    // ------------------------------------------------------------------ vagones
    public static final DeferredItem<VagonItem> VAGON_SKIP = registrarVagon(TipoVagon.SKIP);
    public static final DeferredItem<VagonItem> VAGON_LADRILLOS = registrarVagon(TipoVagon.LADRILLOS);
    public static final DeferredItem<VagonItem> VAGON_CARBON = registrarVagon(TipoVagon.CARBON);
    public static final DeferredItem<VagonItem> VAGON_TOLVA = registrarVagon(TipoVagon.TOLVA);
    public static final DeferredItem<VagonItem> VAGON_VOLTEO = registrarVagon(TipoVagon.VOLTEO);
    public static final DeferredItem<VagonItem> VAGON_CISTERNA = registrarVagon(TipoVagon.CISTERNA);
    public static final DeferredItem<VagonItem> VAGON_DOVELAS = registrarVagon(TipoVagon.DOVELAS);
    public static final DeferredItem<VagonItem> VAGON_G10 = registrarVagon(TipoVagon.G10);
    public static final DeferredItem<VagonItem> VAGON_REFRIGERADO = registrarVagon(TipoVagon.REFRIGERADO);
    public static final DeferredItem<VagonItem> VAGON_TRONCOS = registrarVagon(TipoVagon.TRONCOS);
    public static final DeferredItem<VagonItem> VAGON_CONTENEDORES = registrarVagon(TipoVagon.CONTENEDORES);
    public static final DeferredItem<VagonItem> VAGON_PETROLERO = registrarVagon(TipoVagon.PETROLERO);
    public static final DeferredItem<VagonItem> VAGON_TAKI = registrarVagon(TipoVagon.TAKI);
    public static final DeferredItem<VagonItem> VAGON_GLP = registrarVagon(TipoVagon.GLP);
    public static final DeferredItem<VagonItem> VAGON_CANON = registrarVagon(TipoVagon.CANON);
    public static final DeferredItem<VagonItem> VAGON_ANTIAEREO = registrarVagon(TipoVagon.ANTIAEREO);

    // ------------------------------------------------------------------ coches de pasajeros
    public static final DeferredItem<VagonItem> COCHE_DILIGENCIA = registrarVagon(TipoVagon.DILIGENCIA);
    public static final DeferredItem<VagonItem> COCHE_OESTE = registrarVagon(TipoVagon.OESTE);
    public static final DeferredItem<VagonItem> COCHE_TECA = registrarVagon(TipoVagon.TECA);
    public static final DeferredItem<VagonItem> COCHE_CAMA = registrarVagon(TipoVagon.CAMA);
    public static final DeferredItem<VagonItem> COCHE_DAYLIGHT = registrarVagon(TipoVagon.DAYLIGHT);
    public static final DeferredItem<VagonItem> COCHE_MIRADOR = registrarVagon(TipoVagon.MIRADOR);
    public static final DeferredItem<VagonItem> COCHE_DOMO = registrarVagon(TipoVagon.DOMO);
    public static final DeferredItem<VagonItem> COCHE_INDIO = registrarVagon(TipoVagon.INDIO);
    public static final DeferredItem<VagonItem> COCHE_TREN_AZUL = registrarVagon(TipoVagon.TREN_AZUL);
    public static final DeferredItem<VagonItem> COCHE_MK3 = registrarVagon(TipoVagon.MK3);
    public static final DeferredItem<VagonItem> COCHE_DOS_PISOS = registrarVagon(TipoVagon.DOS_PISOS);

    // ------------------------------------------------------------------ vías
    public static final DeferredItem<ViaItem> VIA_RECTA = registrarVia(TipoVia.RECTA);
    public static final DeferredItem<ViaItem> VIA_CURVA = registrarVia(TipoVia.CURVA);
    public static final DeferredItem<ViaItem> VIA_DOS_CAMINOS = registrarVia(TipoVia.DOS_CAMINOS);
    public static final DeferredItem<ViaItem> VIA_SUBIDA = registrarVia(TipoVia.SUBIDA);
    public static final DeferredItem<BlockItem> BALASTO = ITEMS.register("balasto",
            () -> new BlockItem(ModBloques.BALASTO.get(), new Item.Properties()));
    public static final DeferredItem<BlockItem> LOSA_BALASTO = ITEMS.register("losa_balasto",
            () -> new BlockItem(ModBloques.LOSA_BALASTO.get(), new Item.Properties()));

    /** Combustible de las locomotoras diésel. */
    public static final DeferredItem<Item> BIDON_DIESEL = ITEMS.register("bidon_diesel",
            () -> new Item(new Item.Properties().stacksTo(16)));

    /** Para probarlo en creativo: pone un tren artillero hostil con sus vagones. */
    public static final DeferredItem<ArtilleroHostilItem> ARTILLERO_HOSTIL = ITEMS.register("artillero_hostil",
            () -> new ArtilleroHostilItem(new Item.Properties().stacksTo(16)));
    /** El obús de las torretas (no está en las pestañas: es lo que se ve volar). */
    public static final DeferredItem<Item> OBUS = ITEMS.register("obus", () -> new Item(new Item.Properties()));
    /** La bomba de los globos y zeppelines bombarderos (no está en las pestañas: es lo que se ve caer). */
    public static final DeferredItem<Item> BOMBA = ITEMS.register("bomba", () -> new Item(new Item.Properties()));

    // ------------------------------------------------------------------ globos y zeppelines (para probarlos en creativo)
    private static final Map<TipoAeronave, DeferredItem<AeronaveItem>> AERONAVES = new EnumMap<>(TipoAeronave.class);

    static {
        for (TipoAeronave tipo : TipoAeronave.values()) {
            AERONAVES.put(tipo, ITEMS.register(tipo.nombreRegistro(),
                    () -> new AeronaveItem(new Item.Properties().stacksTo(16), tipo)));
        }
    }

    public static DeferredItem<AeronaveItem> porTipo(TipoAeronave tipo) {
        return AERONAVES.get(tipo);
    }

    // ------------------------------------------------------------------ vehículos de calle
    private static final Map<TipoVehiculo, DeferredItem<VehiculoItem>> VEHICULOS = new EnumMap<>(TipoVehiculo.class);

    static {
        for (TipoVehiculo tipo : TipoVehiculo.values()) {
            VEHICULOS.put(tipo, ITEMS.register(tipo.nombreRegistro(),
                    () -> new VehiculoItem(new Item.Properties().stacksTo(1), tipo)));
        }
    }

    public static DeferredItem<VehiculoItem> porTipo(TipoVehiculo tipo) {
        return VEHICULOS.get(tipo);
    }

    private static DeferredItem<LocomotoraItem> registrar(TipoLocomotora tipo) {
        return ITEMS.register("locomotora_" + tipo.id(),
                () -> new LocomotoraItem(new Item.Properties().stacksTo(1), tipo));
    }

    private static DeferredItem<VagonItem> registrarVagon(TipoVagon tipo) {
        return ITEMS.register(tipo.nombreRegistro(), () -> new VagonItem(new Item.Properties().stacksTo(1), tipo));
    }

    private static DeferredItem<ViaItem> registrarVia(TipoVia tipo) {
        return ITEMS.register("via_" + tipo.id(), () -> new ViaItem(new Item.Properties().stacksTo(16), tipo));
    }

    public static DeferredItem<ViaItem> viaPorTipo(TipoVia tipo) {
        return switch (tipo) {
            case RECTA -> VIA_RECTA;
            case CURVA -> VIA_CURVA;
            case DOS_CAMINOS -> VIA_DOS_CAMINOS;
            case SUBIDA -> VIA_SUBIDA;
        };
    }

    public static DeferredItem<VagonItem> porTipo(TipoVagon tipo) {
        return switch (tipo) {
            case SKIP -> VAGON_SKIP;
            case LADRILLOS -> VAGON_LADRILLOS;
            case CARBON -> VAGON_CARBON;
            case TOLVA -> VAGON_TOLVA;
            case VOLTEO -> VAGON_VOLTEO;
            case CISTERNA -> VAGON_CISTERNA;
            case DOVELAS -> VAGON_DOVELAS;
            case G10 -> VAGON_G10;
            case REFRIGERADO -> VAGON_REFRIGERADO;
            case TRONCOS -> VAGON_TRONCOS;
            case CONTENEDORES -> VAGON_CONTENEDORES;
            case PETROLERO -> VAGON_PETROLERO;
            case TAKI -> VAGON_TAKI;
            case GLP -> VAGON_GLP;
            case CANON -> VAGON_CANON;
            case ANTIAEREO -> VAGON_ANTIAEREO;
            case DILIGENCIA -> COCHE_DILIGENCIA;
            case OESTE -> COCHE_OESTE;
            case TECA -> COCHE_TECA;
            case CAMA -> COCHE_CAMA;
            case DAYLIGHT -> COCHE_DAYLIGHT;
            case MIRADOR -> COCHE_MIRADOR;
            case DOMO -> COCHE_DOMO;
            case INDIO -> COCHE_INDIO;
            case TREN_AZUL -> COCHE_TREN_AZUL;
            case MK3 -> COCHE_MK3;
            case DOS_PISOS -> COCHE_DOS_PISOS;
        };
    }

    public static DeferredItem<LocomotoraItem> porTipo(TipoLocomotora tipo) {
        return switch (tipo) {
            case SCOTSMAN -> SCOTSMAN;
            case F7 -> F7;
            case V200 -> V200;
            case MALLARD -> MALLARD;
            case BIG_BOY -> BIG_BOY;
            case GS4 -> GS4;
            case BR01 -> BR01;
            case PANNIER -> PANNIER;
            case HST -> HST;
            case DELTIC -> DELTIC;
            case SD40 -> SD40;
            case ES44 -> ES44;
            case DD51 -> DD51;
            case CLASS08 -> CLASS08;
            case ROCKET -> ROCKET;
            case JUPITER -> JUPITER;
            case HIAWATHA -> HIAWATHA;
            case T1 -> T1;
            case NWJ -> NWJ;
            case MERCHANT -> MERCHANT;
            case BR9F -> BR9F;
            case D51 -> D51;
            case P36 -> P36;
            case GARRATT -> GARRATT;
            case ZEPHYR -> ZEPHYR;
            case HAMBURGER -> HAMBURGER;
            case V160 -> V160;
            case CC72000 -> CC72000;
            case CHME3 -> CHME3;
            case DF4 -> DF4;
            case WDM2 -> WDM2;
            case P42 -> P42;
            case DF200 -> DF200;
            case GP9_ABANDONADA -> GP9_ABANDONADA;
            case E8_ABANDONADA -> E8_ABANDONADA;
            case RS3_ABANDONADA -> RS3_ABANDONADA;
            case RDC_ABANDONADO -> RDC_ABANDONADO;
            case CLASS37_ABANDONADA -> CLASS37_ABANDONADA;
            case CLASS20_ABANDONADA -> CLASS20_ABANDONADA;
            case M62_ABANDONADA -> M62_ABANDONADA;
            case TEP60_ABANDONADA -> TEP60_ABANDONADA;
            case T478_ABANDONADA -> T478_ABANDONADA;
            case KIHA40_ABANDONADO -> KIHA40_ABANDONADO;
            case SHARKNOSE_ABANDONADA -> SHARKNOSE_ABANDONADA;
            case LOCOMOTION -> LOCOMOTION;
            case BEST_FRIEND -> BEST_FRIEND;
            case JOHN_BULL -> JOHN_BULL;
            case ADLER -> ADLER;
            case COPPERNOB -> COPPERNOB;
            case PORTENA -> PORTENA;
            case SHAY -> SHAY;
            case SIMPLEX -> SIMPLEX;
            case DEUTZ -> DEUTZ;
            case GE44 -> GE44;
            case PLYMOUTH -> PLYMOUTH;
            case TGM23 -> TGM23;
            case TUNEL -> TUNEL;
            case ARTILLERO -> ARTILLERO;
        };
    }

    private ModItems() {
    }
}
