package com.locomotora.registro;

import com.locomotora.LocomotoraMod;

import net.minecraft.core.registries.Registries;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModSonidos {
    public static final DeferredRegister<SoundEvent> SONIDOS =
            DeferredRegister.create(Registries.SOUND_EVENT, LocomotoraMod.MODID);

    /** Silbato de vapor (se oye de lejos). */
    public static final DeferredHolder<SoundEvent, SoundEvent> SILBATO = registrar("silbato");
    /** "Chuf" del vapor saliendo de los cilindros, al ritmo de las ruedas. */
    public static final DeferredHolder<SoundEvent, SoundEvent> RESOPLIDO = registrar("resoplido");
    /** Bocina de cinco tonos de las diésel. */
    public static final DeferredHolder<SoundEvent, SoundEvent> BOCINA = registrar("bocina");
    /** Ruido del motor diésel (se repite encimado mientras está encendido). */
    public static final DeferredHolder<SoundEvent, SoundEvent> MOTOR = registrar("motor");

    // ------------------------------------------------- tren artillero (usan los sonidos del juego, ver sounds.json)
    /** Cañonazo de las torretas (el estampido de una explosión, más agudo). */
    public static final DeferredHolder<SoundEvent, SoundEvent> CANONAZO = registrar("canonazo");
    /** Cada tiro de los caños antiaéreos. */
    public static final DeferredHolder<SoundEvent, SoundEvent> RAFAGA = registrar("rafaga");
    /** Un obús que explota. */
    public static final DeferredHolder<SoundEvent, SoundEvent> OBUS = registrar("obus");
    /** Un golpe al blindaje. */
    public static final DeferredHolder<SoundEvent, SoundEvent> BLINDAJE = registrar("blindaje");
    /** ¡Tren artillero derrotado! */
    public static final DeferredHolder<SoundEvent, SoundEvent> VICTORIA = registrar("victoria");

    // ------------------------------------------------- globos y zeppelines (también con sonidos del juego)
    /** La llamarada del quemador de un globo. */
    public static final DeferredHolder<SoundEvent, SoundEvent> QUEMADOR = registrar("quemador");
    /** Los motores de un zeppelin (el del diésel, bien grave; se repite encimado). */
    public static final DeferredHolder<SoundEvent, SoundEvent> MOTOR_ZEPPELIN = registrar("motor_zeppelin");
    /** La alarma de un bombardero que te encontró. */
    public static final DeferredHolder<SoundEvent, SoundEvent> ALARMA_AEREA = registrar("alarma_aerea");
    /** Una bomba que cae con la mecha encendida. */
    public static final DeferredHolder<SoundEvent, SoundEvent> BOMBA = registrar("bomba");
    /** Un golpe a la tela de un globo o de un zeppelin. */
    public static final DeferredHolder<SoundEvent, SoundEvent> AERONAVE_GOLPE = registrar("aeronave_golpe");
    /** El fuego de una aeronave que cae derribada. */
    public static final DeferredHolder<SoundEvent, SoundEvent> AERONAVE_FUEGO = registrar("aeronave_fuego");

    // ------------------------------------------------- vehículos de calle
    /** La bocina de los autos, las motos y las camionetas (dos tonos). */
    public static final DeferredHolder<SoundEvent, SoundEvent> BOCINA_AUTO = registrar("bocina_auto");
    /** La sirena de la autobomba (sube y baja). */
    public static final DeferredHolder<SoundEvent, SoundEvent> SIRENA = registrar("sirena");

    // ------------------------------------------------- armas (con sonidos del juego, ver sounds.json)
    public static final DeferredHolder<SoundEvent, SoundEvent> DISPARO_PISTOLA = registrar("disparo_pistola");
    public static final DeferredHolder<SoundEvent, SoundEvent> DISPARO_RIFLE = registrar("disparo_rifle");
    public static final DeferredHolder<SoundEvent, SoundEvent> DISPARO_AMETRALLADORA = registrar("disparo_ametralladora");
    /** El clic del gatillo sin munición. */
    public static final DeferredHolder<SoundEvent, SoundEvent> SIN_MUNICION = registrar("sin_municion");

    private static DeferredHolder<SoundEvent, SoundEvent> registrar(String nombre) {
        return SONIDOS.register(nombre, () -> SoundEvent.createVariableRangeEvent(LocomotoraMod.id(nombre)));
    }

    private ModSonidos() {
    }
}
