package com.locomotora.carretera;

import org.jetbrains.annotations.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * El asfalto de la carretera: un bloque entero o, donde la carretera sube de a media altura, una losa (la de abajo).
 * Al ponerlo a mano, con Shift va la losa.
 */
public class CarreteraBlock extends Block {
    public static final BooleanProperty LOSA = BooleanProperty.create("losa");
    private static final VoxelShape MEDIO = Block.box(0.0, 0.0, 0.0, 16.0, 8.0, 16.0);

    public CarreteraBlock(Properties propiedades) {
        super(propiedades);
        this.registerDefaultState(this.stateDefinition.any().setValue(LOSA, false));
    }

    @Override
    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LOSA);
    }

    @Override
    public VoxelShape getShape(BlockState estado, BlockGetter nivel, BlockPos pos, CollisionContext contexto) {
        return estado.getValue(LOSA) ? MEDIO : Shapes.block();
    }

    @Override
    public boolean useShapeForLightOcclusion(BlockState estado) {
        return estado.getValue(LOSA);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext contexto) {
        boolean losa = contexto.getPlayer() != null && contexto.getPlayer().isSecondaryUseActive();
        return this.defaultBlockState().setValue(LOSA, losa);
    }
}
