package com.locomotora.carretera;

import org.jetbrains.annotations.Nullable;

import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/**
 * Asfalto con una raya pintada (la línea blanca del costado o la amarilla del medio). La raya va en una de 8
 * direcciones (de a 22,5°, desde el este hacia el sur) y corrida de a 1/8 de bloque: así, bloque a bloque, la línea
 * sigue las curvas de la carretera. Al ponerla a mano, la raya va hacia donde mira el jugador.
 */
public class LineaBlock extends CarreteraBlock {
    public static final IntegerProperty ANGULO = IntegerProperty.create("angulo", 0, 7);
    public static final IntegerProperty POS = IntegerProperty.create("pos", 0, 11);

    public LineaBlock(Properties propiedades) {
        super(propiedades);
        this.registerDefaultState(this.stateDefinition.any().setValue(LOSA, false).setValue(ANGULO, 0).setValue(POS, 5));
    }

    @Override
    public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(ANGULO, POS);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext contexto) {
        BlockState estado = super.getStateForPlacement(contexto);
        if (estado == null) {
            return null;
        }
        // hacia dónde mira: (-sen, cos) del rumbo; el ángulo de la raya se mide desde +x hacia +z (sin sentido)
        double rumbo = Math.toRadians(contexto.getRotation());
        double ang = Math.toDegrees(Math.atan2(Math.cos(rumbo), -Math.sin(rumbo)));
        ang = ((ang % 180.0) + 180.0) % 180.0;
        int a = (int) Math.round(ang / 22.5) % 8;
        return estado.setValue(ANGULO, a).setValue(POS, 5);
    }
}
