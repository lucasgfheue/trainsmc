package com.locomotora.item;

import java.util.List;

import com.locomotora.registro.ModEntidades;
import com.locomotora.vehiculo.TipoVehiculo;
import com.locomotora.vehiculo.VehiculoEntity;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;

/** Ítem que pone un vehículo de calle sobre el bloque al que se le hace clic, mirando hacia donde mira el jugador. */
public class VehiculoItem extends Item {
    private final TipoVehiculo tipo;

    public VehiculoItem(Properties propiedades, TipoVehiculo tipo) {
        super(propiedades);
        this.tipo = tipo;
    }

    public TipoVehiculo getTipo() {
        return this.tipo;
    }

    @Override
    public InteractionResult useOn(UseOnContext contexto) {
        Level level = contexto.getLevel();
        BlockPos clic = contexto.getClickedPos();
        Direction cara = contexto.getClickedFace();
        BlockPos pos = level.getBlockState(clic).getCollisionShape(level, clic).isEmpty() ? clic : clic.relative(cara);
        ItemStack stack = contexto.getItemInHand();
        Player jugador = contexto.getPlayer();
        if (level instanceof ServerLevel servidor) {
            VehiculoEntity v = ModEntidades.porTipo(this.tipo).get().create(servidor);
            if (v == null) {
                return InteractionResult.FAIL;
            }
            float rumbo = jugador != null ? jugador.getYRot() : contexto.getHorizontalDirection().toYRot();
            v.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, rumbo, 0.0F);
            if (!servidor.noCollision(v, v.getBoundingBox())) {
                if (jugador != null) {
                    jugador.displayClientMessage(Component.translatable("mensaje.locomotora.vehiculo_no_entra")
                            .withStyle(ChatFormatting.RED), true);
                }
                return InteractionResult.FAIL;
            }
            Component nombre = stack.get(DataComponents.CUSTOM_NAME);
            if (nombre != null) {
                v.setCustomName(nombre);
            }
            servidor.addFreshEntity(v);
            servidor.gameEvent(GameEvent.ENTITY_PLACE, pos, GameEvent.Context.of(jugador, servidor.getBlockState(pos.below())));
        }
        if (jugador == null || !jugador.getAbilities().instabuild) {
            stack.shrink(1);
        }
        return InteractionResult.sidedSuccess(level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext contexto, List<Component> lineas, TooltipFlag opciones) {
        lineas.add(Component.translatable("tooltip.locomotora." + this.tipo.nombreRegistro()).withStyle(ChatFormatting.GOLD));
        lineas.add(Component.translatable("tooltip.locomotora.vehiculo.velocidad",
                Math.round(this.tipo.velocidadMaxima() * 72.0F), this.tipo.cantidadAsientos())
                .withStyle(ChatFormatting.GRAY));
        lineas.add(Component.translatable("tooltip.locomotora.vehiculo.colocar").withStyle(ChatFormatting.GRAY));
        lineas.add(Component.translatable("tooltip.locomotora.vehiculo.manejar").withStyle(ChatFormatting.GRAY));
        String clic = switch (this.tipo.arma()) {
            case CANON, AMETRALLADORA -> "tooltip.locomotora.vehiculo.torreta";
            default -> this.tipo.bocina() == TipoVehiculo.Bocina.SIRENA
                    ? "tooltip.locomotora.vehiculo.sirena" : "tooltip.locomotora.vehiculo.bocina";
        };
        lineas.add(Component.translatable(clic).withStyle(ChatFormatting.DARK_AQUA));
    }
}
